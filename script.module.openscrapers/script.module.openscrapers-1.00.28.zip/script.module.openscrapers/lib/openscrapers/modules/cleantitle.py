# -*- coding: utf-8 -*-
"""
	OpenScrapers Module
"""

import re


def get_title(title):
	if title is None: return
	try:
		title = re.sub(r'(\d{4})', '', title).lower()
		title = re.sub(r'&#(\d+);', '', title)
		title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
		title = title.replace('&quot;', '\"').replace('&amp;', '&')
		# title = re.sub(r'\n|[()[\]{}]|\s(vs[.]?|v[.])\s|[:;–\-",\'!_.?~]|\s', '', title) # keeps bracketed content unlike .get()
		title = re.sub(r'\n|[()[\]{}]|[:;–\-",\'!_.?~$@]|\s', '', title) # stop trying to remove alpha characters "vs" or "v", they're part of a title
		title = re.sub(r'<.*?>', '', title) # removes tags
		return title
	except:
		from openscrapers.modules import log_utils
		log_utils.error()
		return title


def get(title):
	try:
		if not title: return
		title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title) # fix html codes with missing semicolon between groups
		title = re.sub(r'&#(\d+);', '', title).lower()
		title = title.replace('&quot;', '\"').replace('&amp;', '&').replace('&nbsp;', '')
		title = re.sub(r'([<\[({].*?[})\]>])|([^\w0-9])', '', title)
		#title = re.sub(r'\n|([\[({].+?[})\]])|([:;–\-"\',!_.?~$@])|\s', '', title) # stop trying to remove alpha characters "vs" or "v", they're part of a title
		return title
	except:
		from openscrapers.modules import log_utils
		log_utils.error()
		return title


def getsearch(title):
	if not title: return
	title = title.lower()
	title = re.sub(r'&#(\d+);', '', title)
	title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
	title = title.replace(r'&quot;', '\"').replace('&amp;', '&').replace('–', '-')
	title = re.sub(r'\\\|/|-|–|:|;|!|\*|\?|"|\'|<|>|\|', '', title).lower()
	return title


def geturl(title):
	if not title: return title.lower()
	try:
		title = title.lower().rstrip()
		try: title = title.translate(None, r':*?"\'\.<>|&!,')
		except:
			try: title = title.translate(title.maketrans('', '', r':*?"\'\.<>|&!,'))
			except:
				for c in r':*?"\'\.<>|&!,': title = title.replace(c, '')
		title = title.replace('/', '-').replace(' ', '-').replace('--', '-').replace('–', '-').replace('!', '').replace(':', '')
		return title.lower()
	except:
		from openscrapers.modules import log_utils
		log_utils.error()
		return title.lower()


def get_under(title):
	if title is None: return
	title = getsearch(title)
	title = title.replace(' ', '_')
	title = title.replace('__', '_')
	return title


def get_dash(title):
	if title is None: return
	title = getsearch(title)
	title = title.replace(' ', '-')
	title = title.replace('--', '-')
	return title


def get_plus(title):
	if title is None: return
	title = getsearch(title)
	title = title.replace(' ', '+')
	title = title.replace('++', '+')
	return title


def get_utf8(title):
	if title is None: return
	title = getsearch(title)
	title = title.replace(' ', '%20')
	title = title.replace('%20%20', '%20')
	return title


def match_alias(title, aliases):
	try:
		for alias in aliases:
			if get(title) == get(alias['title']):
				return True
		return False
	except:
		return False


def normalize(title):
	try:
		import unicodedata
		title = ''.join(c for c in unicodedata.normalize('NFKD', title) if unicodedata.category(c) != 'Mn')
		return str(title)
	except:
		from openscrapers.modules import log_utils
		log_utils.error()
		return title


def scene_title(title, year):
	title = normalize(title)
	title = title.replace('&', 'and').replace('-', ' ').replace('–', ' ').replace('/', ' ').replace('*', ' ').replace('.', ' ')
	title = re.sub('[^A-Za-z0-9 ]+', '', title)
	title = re.sub(' {2,}', ' ', title).strip()
	if title.startswith('Birdman or') and year == '2014': title = 'Birdman'
	if title == 'Birds of Prey and the Fantabulous Emancipation of One Harley Quinn' and year == '2020': title = 'Birds of Prey'
	if title == "Roald Dahls The Witches" and year == '2020': title = 'The Witches'
	return title, year


def scene_tvtitle(title, year, season, episode):
	title = normalize(title)
	title = title.replace('&', 'and').replace('-', ' ').replace('–', ' ').replace('/', ' ').replace('*', ' ').replace('.', ' ')
	title = re.sub('[^A-Za-z0-9 ]+', '', title)
	title = re.sub(' {2,}', ' ', title).strip()
	if title in ['The Haunting', 'The Haunting of Bly Manor', 'The Haunting of Hill House'] and year == '2018':
		if season == '1': title = 'The Haunting of Hill House'
		elif season == '2': title = 'The Haunting of Bly Manor'; year = '2020'; season = '1'
	if title in ['Cosmos', 'Cosmos A Spacetime Odyssey', 'Cosmos Possible Worlds'] and year == '2014':
		if season == '1': title = 'Cosmos A Spacetime Odyssey'
		elif season == '2': title = 'Cosmos Possible Worlds'; year = '2020'; season = '1'
	if 'Special Victims Unit' in title: title = title.replace('Special Victims Unit', 'SVU')
	if title == 'Cobra Kai' and year == '1984': year = '2018'
	#if title == 'The Office' and year == '2001': title = 'The Office UK'
	if title == 'The End of the F ing World': title = 'The End of the Fucking World'
	if title == 'M A S H': title = 'MASH'
	if title == 'Lupin' and year == '2021':
		if season == '1' and int(episode) > 5: season = '2'; episode = str(int(episode) - 5)
	return title, year, season, episode


def get_url(title):
	if not title: return
	title = title.replace(' ', '%20').replace('–', '-').replace('!', '')
	return title


def get_gan_url(title):
	if not title: return
	title = title.lower()
	title = title.replace('-', '+')
	title = title.replace(' + ', '+-+')
	title = title.replace(' ', '%20')
	return title


def get_query_(title):
	if title is None: return
	title = title.replace(' ', '_').replace("'", "_").replace('-', '_').replace('–', '_').replace(':', '').replace(',', '').replace('!', '')
	return title.lower()


def query(title):
	if not title: return
	title = title.replace('\'', '').rsplit(':', 1)[0].rsplit(' -', 1)[0].replace('-', ' ').replace('–', ' ').replace('!', '')
	return title


def get_query(title):
	if not title: return
	title = title.replace(':', '').replace(' ', '.').replace('.-.', '.').replace('\'', '').replace("'", "").lower()
	return title


def clean_search_query(url):
	url = url.replace('-','+').replace(' ', '+').replace('–', '+').replace('!', '')
	return url


def comper_title(title):
	if not title: return
	title = title.replace(' ', '-').replace(':', '').replace('.-.', '.').replace('\'', '').lower()
	return title


def get_simple(title):
	try:
		if not title: return
		title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title).lower()# fix html codes with missing semicolon between groups
		title = re.sub(r'&#(\d+);', '', title)
		title = re.sub(r'(\d{4})', '', title)
		title = title.replace('&quot;', '\"').replace('&amp;', '&').replace('&nbsp;', '')
		# title = re.sub(r'\n|[()[\]{}]|\s(vs[.]?|v[.])\s|[:;–\-",\'!_.?~]|\s', '', title) # keeps bracketed content unlike .get()
		title = re.sub(r'\n|[()[\]{}]|[:;–\-",\'!_.?~$@]|\s', '', title) # stop trying to remove alpha characters "vs" or "v", they're part of a title
		title = re.sub(r'<.*?>', '', title) # removes tags
		return title
	except:
		from openscrapers.modules import log_utils
		log_utils.error()
		return title
