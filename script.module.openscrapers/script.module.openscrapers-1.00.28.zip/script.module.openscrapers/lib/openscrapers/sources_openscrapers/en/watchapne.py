# -*- coding: UTF-8 -*-

import re
from openscrapers import urlencode

import requests

from openscrapers.modules.hindi_sources import get_source_dict, link_extractor, host, append_headers, get_headersfrom_url
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.client import agent, r_request, request
# from openscrapers.modules.hindi_sources import read_write_file


class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "watchapne"
        self.domains = ['watchapne.co']
        self.base_link = 'https://watchapne.co'
        self.referer = self.base_link
        self.headers = {'User-Agent': agent(),}
        self.apneembed = ['newstalks.co', 'newstrendz.co', 'newscurrent.co', 'newsdeskroom.co',
                     'newsapne.co', 'newshook.co', 'newsbaba.co', 'articlesnewz.com',
                     'articlesnew.com', 'webnewsarticles.com']

    def movie(self, imdb, title, localtitle, aliases, year):
        # log(f"From: {__name__}\nimdb: {imdb}\ntitle: {title}\nlocaltitle: {localtitle}\naliases: {aliases}\nyear: {year}")
        try:
            query = title.replace(' ', '-').replace(':', '')
            start_url = f"https://watchapne.co/movie/{query}"
            return start_url
        except:
            error(f'{__name__}_ movie: ')
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f"From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year} ")
        try:
            query = tvshowtitle.replace(' ', '-')
            url = query
            return url
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f"From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}")
        try:
            if type(tvdb) == int: return
            if '|' in tvdb:
                query = f'{url}'.replace(' ', '-')
                # log(f"query {query} title: {title} ")
                if 'Indian-Idol-13' in query: query = 'Indian-Idol-Season-13'
                if 'episode' in title.lower(): 
                    url = f'https://watchapne.co/web-series/{query}'
                    # self.referer = 'https://watchapne.co/web-series/'
                    release_title = title.strip()
                else:
                    url = f'https://apnetv.to/Hindi-Serial/{query}'
                    # self.referer = 'https://apnetv.co/Hindi-Serials'
                    release_title = re.sub(r'\d{4}', '', title).strip()  # remove year from title
                # log(f"From: {__name__} show url {url}")
                result = r_request(url, headers=self.headers).text
                # result = read_write_file(file_n='JSTesting/apnetv.me.html')
                # log(f"watchapne release_title: {release_title}")
                try:
                    if 'web-series' in url:
                        results = parseDOM(result, 'div', attrs={'class': 's-epidode clearfix'})
                        results += parseDOM(result, 'div', attrs={'class': 'web-series-grid'})
                    else:
                        results = parseDOM(result, 'ul', attrs={'class': 'ul'})
                        results = parseDOM(results, 'li')
                    for result in results:
                        # log(f"watchapne episode result: {result}")
                        if release_title in result:
                            url = parseDOM(result, "a", ret="href")[0]
                            return url
                except:
                    error(f'{__name__}_ episode: ')
            return
        except:
            error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict, hostprDict):
        # log(f"From: {__name__}\nurl {url}")
        sources = []
        try:
            if not url:	return sources
            result = requests.get(url, headers=self.headers).text
            if not result: return
            result = parseDOM(result, 'div', attrs={'class': 'bottom_episode_list'})
            items = parseDOM(result, 'li')
            for item in items:
                urls = parseDOM(item, 'a', ret='href')
                # log(f'urls: {urls}')
                furls = []
                vidhost = None
                for j in range(0, len(urls)):
                    try:
                        vhdr = {'Referer': self.referer}
                        link = f'{urls[j]}{append_headers(vhdr)}'
                        furls.append(link)
                    except:
                        error(f'{__name__}_ sources: ')
                if len(furls) > 0:
                    sources = get_source_dict(furls, sources, vidhost)
            return sources
        except:
            error(f'{__name__}_ sources: ')
            return sources

    def apne_twostop(self, url, headers):
        # headers.update(self.headers)
        # url = url.replace('www.hindistoponline.com', 'hindigostop.com')
        # log(f'headers >>> : {headers}')
        html = requests.get(url, headers=headers).text
        try:
            urltopost = re.search(r'''<form.*action=["'](.+?)["']''', html)
            urltopost = urltopost.group(1)
            inputNameValue = re.compile('''input.*?name=["'](.+?)["'].+?value=["'](.+?)["']''', re.M)
            formFields = inputNameValue.findall(html)
            # log(f'0 formFields {formFields}')
            postFields = {}
            for field in formFields:
                # log(f'0 field {field}')
                postFields[field[0].encode("ascii")] = field[1].encode("ascii")
            # log(f'0 postFields {postFields}')
            html = requests.post(urltopost, headers=headers, data=postFields).text
            # log(f'html >>> : {html}')
            return html
        except Exception as e:
            error(f'{__name__}_ apne_twostop: ')

    def post_get_vidurl(self, url,  html, headers):
        # log(f'headers >>> : {headers}')
        try:
            r = re.findall(r'''<form.+?action="([^"]+).+?name='([^']+)'\s*value='([^']+)''', html, re.DOTALL)
            if r:
                purl, name, value = r[0]
                html = request(purl, post={name: value}, headers=headers)
                s = re.findall(r"<iframe.+?src='([^']+)", html)
                # log(f'headers >>> s: {s} r[-1]: {-1}')
                if not s:
                    purl, name, value = r[-1]
                    headers.update({'Referer': url})
                    ehtml = request(purl, post=' ', headers=headers)
                    s = re.findall(r"<iframe.+?src='([^']+)", ehtml)
                # log(f'headers >>> s2: {s}')
                if s:
                    strurl = s[0]
                    if 'articlesnew.com' in strurl: strurl = strurl.split('url=')[-1]
                    elif 'url=' in strurl: strurl = strurl.split('url=')[-1]
                    if 'hls' in strurl and 'videoapne' in strurl: strurl = strurl.replace('hls/,', '').replace(',.urlset/master.m3u8', '/v.mp4')
                    if strurl: return strurl
        except Exception as e:
            error(f'{__name__}_ post_get_vidurl: ')
            return

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        try:
            if not any(re.findall(r'dailymotion|vup|streamtape|vidoza|mixdrop|mystream|doodstream|watchvideo|vkprime|vkspeed', url, re.IGNORECASE)):
                if ' , ' in url: iurl = url.split(' , ')
                else: iurl = [url]
                # log(f'In len of iurl {len(iurl)} iurl: {iurl}')
                furl = links = []
                headers = get_headersfrom_url(url)
                headers.update({'User-Agent': agent()})
                # log(f'In type of headers {type(headers)} headers: {headers}')
                for url in range(0, len(iurl)):
                    url=iurl[url]
                    # log(f'watchapne type of url {type(url)} url: {url}')
                    if 'articlesnew.' in url or 'newscurrent.co' in url:
                        url = 'https://articlesnew.com/medium/?' + url.split('?')[-1]
                        html = request(url, headers=headers)
                        strurl = self.post_get_vidurl(url, html, headers)
                        if strurl not in furl: furl.append(strurl)
                    elif any([x in url for x in self.apneembed]):
                        refresh = True
                        while refresh:
                            url = url.replace('/go.', '/')
                            if '/?' not in url: url = url.replace('?', '/?')
                            r = request(url, headers=headers, output='extended')
                            if r[2].get('Refresh'): url = r[2].get('Refresh').split(' ')[-1]
                            else:
                                html = r[0]
                                refresh = False
                        strurl = self.post_get_vidurl(url, html, headers)
                        if strurl not in furl: furl.append(strurl)
                # log(f'watchapne len furl: {len(furl)} type furl {type(furl)} furl: {furl}')
                if len(furl) > 0: url = ' , '.join(furl)
                else: url = furl[0]
                # log(f'watchapne type of url {type(url)} url: {url}')
            return url
        except Exception as e:
            error(f'{__name__}_ url: {url} resolve: {e}')
            return
