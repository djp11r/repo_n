# -*- coding: UTF-8 -*-

# import json
# import re
import re


import requests

from openscrapers.modules.hindi_sources import get_source_dict, resolve_gen, host, keepclean_title
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.client import agent

class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "playdesi"
        self.domains = ['playdesi.org']
        self.base_link = 'https://playdesi.tv'
        self.headers = {'User-Agent': agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f"From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year} ")
        try:
            try:
                url = aliases[0]['url']
                if 'playdesi' in url: return url
            except: pass
            return f'{tvshowtitle}'
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f"From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}")
        try:
            if type(tvdb) == int: return
            if 'episode' not in title.lower(): return
            if 'watch-online' in url: return url
            if '|' in tvdb:
                tvdb = tvdb.split('|')
                title = keepclean_title(tvdb[1]).lower().replace(' ', '-')#.replace('.', '').replace('season', '')
                urls = []
                urls.append(f'{self.base_link}/{title}-season-{season}-{episode}-watch-online')
                urls.append(f'{self.base_link}/{title}-{episode}-watch-online')
                for url in urls:
                    url = url.replace(' ', '-')
                    result = requests.get(url, headers=self.headers)
                    # print(f'status_code: {result.status_code} url: {url}')
                    if result.status_code == 200: return url
        except:
            error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict, hostprDict):
        # log(f"From: {__name__}\nurl {url}")
        sources = []
        try:
            if not url:	return sources
            result = requests.get(url, headers=self.headers).text
            if not result: return
            result = parseDOM(result, 'div', attrs={'class': 'entry-content'})
            # log(f'result: {result}')
            items = parseDOM(result, 'p')
            for item in items:
                urls = parseDOM(item, 'a', ret='href')
                # log(f'url: {urls}')
                furls = []
                vidhost = None
                for j in range(0, len(urls)):
                    try:
                        headers = {'Referer': urls[j]}
                        self.headers.update(headers)
                        result = requests.get(urls[j], headers = self.headers).text
                        if result:
                            links = parseDOM(result, 'iframe', ret = 'src')
                            for link in links:
                                # log(f'link: {link}')
                                if 'vkprime' in link or 'speed' in link or 'watchvideo.us' in link:
                                    vidhost = host(link)
                                    furls.append(link)
                                elif any(re.findall(r'index.php|embed|plyr20a|nflix20', link, re.IGNORECASE)):
                                    furls.append(urls[j])
                    except: pass
                if len(furls) > 0: sources = get_source_dict(furls, sources, vidhost)
            return sources
        except:
            error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        url = resolve_gen(url)
        return url
