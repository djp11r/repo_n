# -*- coding: UTF-8 -*-

# import json
import re


import requests

from openscrapers.modules.hindi_sources import get_source_dict, resolve_gen, host
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.client import agent


class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "desiserials"
        self.domains = ['desiserials.org']
        self.base_link = 'https://www.desi-serials.cc'
        self.headers = {'User-Agent': agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f"From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year} ")
        try:
            try:
                url = aliases[0]['url']
                # log(f'show url: {url}')
                if 'desi-serials' in url: return url
            except: pass
            query = '%s' % (tvshowtitle)
            url = query.replace("’", '')
            return url
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f"From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}")
        try:
            if type(tvdb) == int: return
            if 'episode' in title.lower(): return
            if 'watch-online' in url: return url
            if '|' in tvdb:
                title = title.lower()
                query = f'{url}-episode-{title}-watch-online'
                if 'bigg boss' in url: query = f'{url}-2020-season-14-episode-{title}-watch-online'
                query = query.lower().replace(' ', '-').replace('.', '').replace("’", '')
                url = f'{self.base_link}/{query}/'
                # log(f'From: {__name__} episode url :  {url} episode: {episode}')
                return url
        except:
            error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict, hostprDict):
        # log(f"From: {__name__}\nurl {url}")
        sources = []
        try:
            if not url: return sources
            result = requests.get(url, headers=self.headers).text
            if not result: return sources
            # read_write_file(read=False, result=result)
            result = parseDOM(result, 'div', attrs={'class': 'post-content'})
            items = parseDOM(result, 'p')
            for item in items:
                urls = parseDOM(item, 'a', ret='href')
                # log(f'total: {len(urls)} urls: {urls}')
                furls = []
                vidhost = None
                if 0 < len(urls) < 6:
                    sources = get_source_dict(urls, sources, vidhost)
            return sources
        except:
            error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        url = resolve_gen(url)
        return url
