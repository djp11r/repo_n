# -*- coding: UTF-8 -*-

import re

from openscrapers.modules.hindi_sources import get_source_dict, urlRewrite, host
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.client import agent, r_request


class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "bollyfuntv"
        self.domains = ['serialghar.me']
        self.base_link = 'https://serialghar.me/'
        self.headers = {'User-Agent': agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f"From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year} ")
        try:
            query = f'{tvshowtitle}'
            url = query
            # log(f'>>> #### 0AAAA - yodesi EP url : {url}')
            return url
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f"From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}")
        try:
            if type(tvdb) == int: return
            if 'episode' in title.lower(): return
            if '|' in tvdb:
                stitle = url.lower().replace(' ', '-').replace('.', '')
                # result = r_request(url, headers=self.headers).text
                # if not result: return
                # log(f"result {result}")
                title = title.lower().replace(' ', '-').replace('.', '')
                eurl = f'{self.base_link}/{stitle}-{title}-video-episode/'
                # log(f"eurl {eurl}")
                return eurl
            else: return
        except:
            error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict, hostprDict):
        # log(f"From: {__name__}\nurl {url}")
        sources = []
        try:
            if not url: return sources
            result = r_request(url, headers=self.headers).text
            if not result: return sources
            # read_write_file(read=False, result=result)
            result = parseDOM(result, 'div', attrs={'class': 'entry'})
            items = parseDOM(result, 'p')
            for item in items:
                # log(f"item: {item}")
                urls = parseDOM(item, 'a', ret='href')
                if urls:
                    furks = []
                    for i in range(0, len(urls)):
                        if any(re.findall(r'vkprime|vkspeed', str(urls[0]), re.IGNORECASE)) and 'vid' in urls[i]:
                            furks.append(urlRewrite(urls[i]))
                    # log(f"furks: {furks}")
                    if furks: sources = get_source_dict(furks, sources)
            return sources
        except:
            error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return url
