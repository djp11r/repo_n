# -*- coding: utf-8 -*-
"""
    **Created by Tempest**
    **If you see this in a addon other than Tempest and says it was
    created by someone other than Tempest they stole it from me**
"""
import re
import traceback

from openscrapers import parse_qs, urlencode, quote_plus
from openscrapers.modules import cleantitle, source_utils
from openscrapers.modules import client
from openscrapers.modules import log_utils
from openscrapers.modules.hindi_sources import convert_youtube_duration_to_minutes


class source:
    def __init__(self):
        self.priority = 40
        self.language = ['en']
        self.domain = ['youtube.com']
        self.base_link = 'https://www.youtube.com/'
        self.key = 'AIzaSyCjf8izIeXa1oFZo7_HeL0WgrOq1WF_I1k'
        # self.key_link = f'&key={self.key}'
        self.search_link = f'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=15&q=%s&key={self.key}'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict):
        sources = []
        if url is None: return sources
        try:
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            query = '%s %s' % (data['title'], int(data['year']))
            
            squery = query + ' full|Full' + ' movie|Movie'
            query_url = self.search_link % quote_plus(squery)
            # log_utils.log(f"query_url: {query_url}")

            query_url += "&relevanceLanguage=en"
            headers = {"Accept": "application/json"}
            response = client.scrapePage(query_url, headers=headers).json()
            # logger(f'search json response {response} ')
            error = response.get('error', [])
            if error:
                message = error.get('message', [])
                log_utils.log(f"message: {message}")
                return None

            json_items = response.get('items', [])
            # log_utils.log(f'search json_items {json_items} ')
            for search_result in json_items:
                query = query.split('-')[0].lower().replace('.', '')
                item_title = str(search_result["snippet"]["title"].replace('.', ''))
                if any(re.findall(r'Full Movie|Movie', item_title, re.IGNORECASE)) and re.findall(data['title'], item_title, re.IGNORECASE):
                    # log_utils.log(f'search item {query} == {item_title}')
                    if search_result["id"]["kind"] == "youtube#video":
                        vid_id = search_result["id"]["videoId"]
                        payload = {
                            'id': vid_id,
                            'part': 'contentDetails',
                            'key': self.key}
                        url = 'https://www.googleapis.com/youtube/v3/videos/?&%s' % urlencode(payload)
                        resp_dict = client.scrapePage(url).json()
                        # resp_dict = self.session.get('https://www.googleapis.com/youtube/v3/videos', params=payload).json()
                        dur = resp_dict["items"][0]["contentDetails"]["duration"]
                        duration = convert_youtube_duration_to_minutes(dur)
                        # log_utils.log(f'dur: {dur} duration: {duration}')
                        if duration > 70:
                            v_link = f'plugin://plugin.video.youtube/play/?video_id={vid_id}'
                            sources.append({'source': 'youtube', 'quality': 'SD', 'url': v_link, 'info': f'{duration} minutes', 'name_info': item_title, 'direct': True})
            return sources
        except Exception:
            log_utils.error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        return url
