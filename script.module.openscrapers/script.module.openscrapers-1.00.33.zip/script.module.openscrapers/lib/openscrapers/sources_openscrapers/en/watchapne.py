# -*- coding: UTF-8 -*-

import re

from openscrapers.modules.hindi_sources import resolve_gen, get_source_dict, get_query
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.client import agent, scrapePage, request


class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "watchapne"
        self.domains = ['watchapne.co']
        self.base_link = 'https://watchapne.co'
        self.referer = ''
        self.headers = {'User-Agent': agent(),}
        self.apneembed = ['newstalks.co', 'newstrendz.co', 'newscurrent.co', 'newsdeskroom.co',
                     'newsapne.co', 'newshook.co', 'newsbaba.co', 'articlesnewz.com',
                     'articlesnew.com', 'webnewsarticles.com']

    def movie(self, imdb, title, localtitle, aliases, year):
        # log(f'From: {__name__}\nimdb: {imdb}\ntitle: {title}\nlocaltitle: {localtitle}\naliases: {aliases}\nyear: {year}')
        try:
            query = title.replace(' ', '-').replace(':', '')
            start_url = f"https://movieapne.co/movie/{query}"
            return start_url
        except:
            error(f'{__name__}_ movie: ')
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f'From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year}')
        try:
            return f'{tvshowtitle}'
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f'From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}')
        try:
            if type(tvdb) == int: return
            if '|' in tvdb:
                query = get_query(url)
                # log(f'query {query} title: {title}')
                # if re.search(r'indian-idol-13', query, re.I): query = 'Indian-Idol-Season-13'
                # elif re.search(r'crime-patrol', query, re.I): query = 'Crime-Patrol-2.0'
                # elif re.search(r'the-kapil-sharma-show', query, re.I): query = 'The-Kapil-Sharma-Show-Season-4'
                # elif re.search(r'kaun-banega-crorepati', query, re.I): query = 'Kaun-Banega-Crorepati-14'
                # elif re.search(r'masterchef-india', query, re.I): query = f'Masterchef-India-Season-7'
                if re.search(r'episode', title, re.I):
                    self.base_link = 'https://watchapne.co/web-series'
                    if season == 1: query = query.replace('Season-1', '').replace('season-1', '')
                    url = f'{self.base_link}/{query}'
                    release_title = title.strip()
                else:
                    self.base_link = 'https://apnetv.to/Hindi-Serial'
                    url = f'{self.base_link}/{query}'
                    release_title = re.sub(r'\d{4}', '', title).strip()  # remove year from title
                # log(f'From: {__name__} show release_title: {release_title} url {url}')
                result = scrapePage(url, headers=self.headers).text
                # result = read_write_file(file_n='JSTesting/watchapne.co.html')
                next_result = parseDOM(result, 'div', attrs={'class': 'pagination_btns'})
                if next_result:
                    nurl = parseDOM(next_result, "a", attrs={'class': 'prev_next_btns'}, ret="href")[0]
                    # log(f'{__name__} nurl: {nurl} from next_result: {next_result}')
                    if nurl: result += scrapePage(nurl, headers=self.headers).text
                if 'web-series' in url:
                    results = parseDOM(result, 'div', attrs={'class': 's-epidode clearfix'})
                    results += parseDOM(result, 'div', attrs={'class': 'web-series-grid'})
                else:
                    results = parseDOM(result, 'ul', attrs={'class': 'ul'})
                    results = parseDOM(results, 'li')
                for item in results:
                    # log(f'{__name__} episode item: {item}')
                    if release_title in item:
                        # log(f'{__name__} episode item: {item}')
                        url = parseDOM(item, "a", ret="href")[0]
                        return url
            return
        except:
            error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict):
        # log(f'From: {__name__} url {url}')
        sources = []
        try:
            if not url: return sources
            result = scrapePage(url).text
            if not result: return
            result = parseDOM(result, 'div', attrs={'class': 'bottom_episode_list'})
            items = parseDOM(result, 'li')
            # log(f'sources result: {result}\nitems: {items}')
            for item in items:
                urls = parseDOM(item, 'a', attrs={'target': '_blank'}, ret='href')
                # log(f'sources urls: {urls} item: {item}')
                final_url = []
                for iurl in urls:
                    link = f'{iurl}|Referer={self.base_link}'
                    if link not in final_url: final_url.append(link)
                if final_url: sources = get_source_dict(final_url, sources)
            if not sources: log(f'From: {__name__} no sources on url {url}')
            return sources
        except:
            error(f'{__name__}_ sources url: {url} ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return resolve_gen(url)
