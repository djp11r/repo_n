# -*- coding: utf-8 -*-

from openscrapers.modules import client
from openscrapers.modules import cleantitle
from openscrapers.modules import log_utils
from openscrapers.modules import scrape_sources
from openscrapers.modules import source_utils


class source:
    def __init__(self):
        self.results = []
        self.domains = ['database.gdriveplayer.us']
        self.base_link = 'https://database.gdriveplayer.us'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = self.base_link + '/player.php?imdb=%s' % imdb
            return url
        except Exception:
            #log_utils.log('movie', 1)
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = self.base_link + '/player.php?type=series&imdb=%s' % imdb
            return url
        except Exception:
            #log_utils.log('tvshow', 1)
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return
            url = url + '&season=%s&episode=%s' % (season, episode)
            return url
        except Exception:
            #log_utils.log('episode', 1)
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            if url == None:
                return self.results
            html = client.scrapePage(url).text
            servers = client.parseDOM(html, 'ul', attrs={'class': 'list-server-items'})[0]
            links = client.parseDOM(servers, 'a', ret='href')
            for link in links:
                if not link or link.startswith('/player.php'):
                    continue
                for source in scrape_sources.process(hostDict, link):
                    # log_utils.log(f'sources getMore link: {link}')
                    self.results.append(source)
                valid, host = source_utils.is_host_valid(link, hostDict)
                if valid:
                    link = link.split('&title=')[0]
                    if link.startswith('//'): link = 'https:%s' % link
                    # log_utils.log(f'sources ready link: {link}')
                    self.results.append({'source': host, 'quality': '720p', 'url': link, 'direct': False, 'language': 'en', 'info': '', 'debridonly': False})
            return self.results
        except Exception:
            log_utils.error(f'{__name__}_ sources: ')
            return self.results


    def resolve(self, url):
        return url


