# -*- coding: UTF-8 -*-

import re

from openscrapers.modules import client
from openscrapers.modules import source_utils
from openscrapers.modules import log_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['tagstream.eu']
        self.base_link = 'https://tagstream.eu'
        self.search_link = '/player/movie/%s'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = imdb
            return url
        except Exception:
            log_utils.log('Testing Exception', 1)
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            hostDict = hostprDict + hostDict
            sources = []
            if url == None:
                return sources
            imdb = url

            url = self.base_link + self.search_link % imdb
            html = client.r_request(url)
            regex = r'''\{\s*file:\s*"(.+?)",\s*label:\s*"(.+?)"\s*\}'''
            urls = re.compile(regex).findall(html)
            if urls:
                for link, qual in urls:
                    link =  "https:" + link if not link.startswith('http') else link
                    log_utils.log('Addon Testing search_link link: \n' + repr(link))
                    valid, host = source_utils.is_host_valid(link, hostDict)
                    qual, info = source_utils.get_release_quality(qual, link)
                    sources.append({'source': host, 'quality': qual, 'language': 'en', 'url': link, 'info': info, 'direct': True, 'debridonly': False})

            return sources
        except Exception:
            log_utils.log('Testing Exception', 1)
            return sources


    def resolve(self, url):
        return url


