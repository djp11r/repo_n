# -*- coding: UTF-8 -*-

import re
import traceback

try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import quote_plus

from bs4 import BeautifulSoup, SoupStrainer
from openscrapers.modules import client, log_utils, genericresolver, source_utils


class source:

    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.name = "tvyaar"
        self.domains = ['tvyaar.cc']
        self.base_link = 'https://tvyaar.cc/Hindi-Serial/'
        self.search_link = '/?s=%s&submit=Search'
        self.info_link = 'http://www.yo-desi.com/player.php?id=%s'

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log_utils.log("!!!!!!! yodesi \n{} ... \n{} .. \n{}\n {} {} {}  ".format(imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))
        try:
            query = '%s' % (tvshowtitle)
            url = query
            # log_utils.log('>>> #### 0AAAA - yodesi EP url : %s' % ( url))
            return url
        except:
            log_utils.log('yodesi tvshow Exception : %s' % (traceback.format_exc()))
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log_utils.log("!!!!!!! yodesi \n{} ... \n{} .. \n{}\n {} {} {} {} ".format(url, imdb, tvdb, title, premiered, season, episode))
        try:
            # log_utils.debug('>>> #### 0AAAA - apnetv EP url : %s' % (episode))
            query = self.base_link + '/' + title.replace(' ', '-')
            # log_utils.debug('>>> #### 0AAAA - apnetv EP url : %s' % (query))
            result = client.request(query)
            mlink = SoupStrainer('div', {'class': re.compile('cont_box_blue episode_main')})
            mdiv = BeautifulSoup(result, 'html.parser', parse_only=mlink)
            items = mdiv.findAll('li')
            for item in items:
                # print('>>>>>>>>> {}'.format(item.prettify()))
                ititle = item.find('p').text
                rurl = item.find('a')['href']
                epi_day = episode.replace('th', '').replace('nd', '').replace('st', '').replace(' ', '-')
                # print('>>>>>>>>> \n{}\n{}'.format(epi_day.lower(),ititle.lower()))
                if epi_day.lower() in ititle.lower():
                    url = rurl
                    # print('>>>>>>>>> {}'.format(url))
            return url
        except:
            log_utils.log('yodesi episode Exception : %s' % (traceback.format_exc()))
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        # log_utils.log("!!!!!!! yodesi \n{} ... \n{} .. \n{}".format(url, hostDict, hostprDict))
        try:
            html = client.request(url, referer=self.base_link)
            # print('>>>>>>>>> {}'.format(html))
            mlink = SoupStrainer('div', {'class': ' download_link1'})
            mdiv = BeautifulSoup(html, features="html.parser", parse_only=mlink)
            items = mdiv.findAll('li')
            urls = []
            for item in items:
                # print('>>>>>>>>> {}'.format(item.prettify()))
                vid_link = item.find('a')['href']
                result = client.request(vid_link, referer=self.base_link)
                link = re.findall('''<iframe.+?src=["']?([^'" ]+)''', result, re.IGNORECASE)
                urls.append(link[0])
            for uri in urls:
                host = client.host(uri)
                rUrl = uri
                # print('>>>>>>>>> rUrl {}'.format(rUrl))
                self.srcs.append({'source': host, 'parts': 'All:1', 'quality': 'SD', 'scraper': self.name, 'url': rUrl, 'direct': False})
        except:
            log_utils.log('yodesi sources Exception : %s' % (traceback.format_exc()))
            return sources

    def getVideoID(self, url):
        try:
            return re.compile('(id|url|v|si|sim|data-config)=(.+?)/').findall(url + '/')[0][1]
        except:
            return


    def resolve(self, url):
        # url = genericresolver.resolve(url)
        return url
