# -*- coding: UTF-8 -*-

# import json
import re

# try: from urllib import quote_plus
# except ImportError: from urllib.parse import quote_plus
import requests

from openscrapers.modules.hindi_sources import get_source_dict, urlRewrite, resolve_gen, host
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.client import agent, r_request


class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "desitelly"
        self.domains = ['desitellybox.me']
        self.base_link = 'https://www.desitellybox.me'
        self.headers = {'User-Agent': agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f"From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year} ")
        try:
            return f'{tvshowtitle}'
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f"From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}")
        try:
            if type(tvdb) == int: return
            if '|' in tvdb:
                title = title.lower()
                if 'episode' in title: furl = f'{url}-watch-online-{title}/'
                elif 'indian idol 13' in url.lower(): furl = f'{url}-{title}-watch-online/'
                else: furl = f'{url}-{title}-episode-watch-online/'
                url = furl.lower().replace(' ', '-').replace('.', '').replace('---', '-').replace("’", '')
                url = f"{self.base_link}/{url}"
                return url
            else: return
        except:
            error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict, hostprDict):
        # log(f"From: {__name__}\nurl {url}")
        sources = []
        try:
            if not url: return sources
            result = r_request(url).text
            if not result: return sources
            result = parseDOM(result, 'div', attrs={'class': 'entry_content'})
            items = parseDOM(result, 'p')
            for item in items:
                urls = parseDOM(item, 'a', ret='href')
                # log(f'total: {len(urls)} urls: {urls}')
                furls = []
                vidhost = None
                for j in range(0, len(urls)):
                    # log(f'urls[j]: {urls[j]}')
                    try:
                        headers = {'Referer': urls[j]}
                        self.headers.update(headers)
                        result = requests.get(urls[j], headers=self.headers).text
                        if result:
                            links = parseDOM(result, 'iframe', ret='src')
                            for link in links:
                                if 'vkprime' in link or 'speed' in link or 'watchvideo.us' in link:
                                    vidhost = host(link)
                                    furls.append(link)
                                elif 'flow.' in link:
                                    furls.append(urls[j])
                    except:
                        error(f'{__name__}_ sources: ')
                if len(furls) > 0: sources = get_source_dict(furls, sources, vidhost)
            return sources
        except:
            error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        url = resolve_gen(url)
        return url
