# -*- coding: utf-8 -*-
"""
    OpenScrapers Module
"""

import json
import re
import time
from base64 import b64decode
from urllib.parse import quote_plus

from openscrapers import urljoin

from openscrapers.modules import cleandate
from openscrapers.modules import cache
from openscrapers.modules.client import requests, make_session
from openscrapers.modules import client_utils
from openscrapers.modules.log_utils import log, error
from openscrapers.modules import utils
from openscrapers.modules import control
from openscrapers.windows.base import getProgressWindow

BASE_URL = 'https://api.trakt.tv'
V2_API_KEY = control.setting('trakt.client') or '1038ef327e86e7f6d39d80d2eb5479bff66dd8394e813c5e0e387af0f84d89fb' #'e3a8d1c673dfecb7f669b23ecbf77c75fcfd24d3e8c3dbc7f79ed995262fa1db'
CLIENT_SECRET = control.setting('trakt.secret') or '8d27a92e1d17334dae4a0590083a4f26401cb8f721f477a79fd3f218f8534fd1' # '73bee6aeee29cb75db4d8771458a440017f7cfe842e85f457ed9d81f7910b349'
REDIRECT_URI = 'urn:ietf:wg:oauth:2.0:oob'
session = make_session(BASE_URL)

if V2_API_KEY == "" or CLIENT_SECRET == "":
    V2_API_KEY = b64decode("OGQ5Njg1M2Y0MGQ1MWJkMDY2MWI2Mzc4ZjUzYzM0ZTM2YzVjZTQzZjM0MmI0YTg0NWI3Nzk4N2Q0NjZjMjY0ZQ==")
    CLIENT_SECRET = b64decode("NTg2ZDAzNGJhNzM3OGU2ZDY4Y2NjODE5ZWE4M2M5ZmU5N2I5ODg1Yjk2YTQ1ZGQ2OTQ1OWI3OWNkZGU0MmU4OQ==")


def getTraktCredentialsInfo():
    user = control.setting('trakt.user').strip()
    token = control.setting('trakt.token')
    refresh = control.setting('trakt.refresh')
    return user != '' and token != '' and refresh != ''


class Trakt():
    def __init__(self):
        self.api_endpoint = 'https://api.trakt.tv/%s'
        self.client_id = self.traktClientID()
        self.client_secret = self.traktClientSecret()
        self.expires_at = control.setting('trakt.expires')
        self.token = control.setting('trakt.token')

    def call(self, path, data=None, with_auth=True, suppress_error_notification=False):
        try:
            def send_query():
                resp = None
                if with_auth:
                    try:
                        if time.time() > self.expires_at: self.token = self.refresh_token()
                    except: pass
                    headers['Authorization'] = f'Bearer {self.token}'
                try:
                    if data is not None: resp = session.post(self.api_endpoint % path, json=data, headers=headers, timeout=timeout)
                    else: resp = session.get(self.api_endpoint % path, headers=headers, timeout=timeout)
                except Exception as e:
                    log(f'Error:{e} response: {resp}')
                return resp

            timeout = 15.0
            headers = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': self.client_id}
            response = send_query()
            try: status_code = response.status_code
            except: return None
            self.error_handler(self.api_endpoint % path, response, str(status_code), silent=suppress_error_notification)
            if status_code == 401: # Re-Auth token
                if self.auth():
                    response = send_query()
            elif status_code == 429: # API requests are being throttled so retry
                headers = response.headers
                if 'Retry-After' in headers:
                    control.sleep(1000 * headers['Retry-After'])
                    response = send_query()
            response.encoding = 'utf-8'
            try: result = response.json()
            except: result = None
            if 'error' in result and result['error'] == 'invalid_grant':
                log(f'from path: {path} Please Re-Authorize your Trakt Account \nresponse: {result}')
                control.notification(title='Trakt', message='Please Re-Authorize your Trakt Account')
            return result
        except:
            error('Trakt().call')

    def error_handler(self, url, response, status_code, silent=False):
        if status_code.startswith('5') or (response and isinstance(response, str) and '<html' in response) or not str(response): # covers Maintenance html responses ["Bad Gateway", "We're sorry, but something went wrong (500)"])
            log(f'Temporary Trakt Server Problem: {status_code}:{response}')
            if not silent: control.notification(title='Trakt', message='Temporary Trakt Server Problems')
        elif status_code == '423':
            log(f'Locked User Account - Contact Trakt Support: {str(response.text)}')
            if not silent: control.notification(title='Trakt', message='Locked User Account - contact Trakt support')
        elif status_code == '404':
            log(f'getTrakt() (404:NOT FOUND): URL=({url}): {str(response.text)}')
        return

    def get_device_code(self):
        data = {'client_id': self.client_id}
        return self.call("oauth/device/code", data=data, with_auth=False)

    def get_device_token(self, device_codes):
        try:
            data = {"code": device_codes["device_code"],
                    "client_id": self.client_id,
                    "client_secret": self.client_secret}
            start = time.time()
            expires_in = device_codes['expires_in']
            verification_url = f'1) Open this link in a browser:[CR]{str(device_codes["verification_url"])}'
            user_code = f'2) When prompted enter: [COLOR FF6CB201]{str(device_codes["user_code"])}[/COLOR]'
            token_url = f'https://trakt.tv/activate?code={str(device_codes["user_code"])}'
            qr_code = utils.make_qrcode(token_url, 'trakt') or ''
            progressD = getProgressWindow('TMDb Account Authorization', qr_code, 1)
            progressD.set_controls()
            user_code = f'{verification_url}[CR]{user_code}[CR]'
            progressD.update(0, user_code)
            try:
                time_passed = 0
                while not progressD.iscanceled() and time_passed < expires_in:
                    try:
                        response = self.call("oauth/device/token", data=data, with_auth=False, suppress_error_notification=True)
                    except requests.HTTPError as e:
                        log(f'Request Error: {str(e)}')
                        if e.response.status_code != 400: raise e
                        progress = int(100 * time_passed / expires_in)
                        progressD.update(progress, user_code)
                        control.sleep(max(device_codes['interval'], 1)*1000)
                    else:
                        if not response: continue
                        else: return response
                    time_passed = time.time() - start
            finally:
                progressD.close()
        except:
            error(f'device_codes: {device_codes}')
            return None

    def refresh_token(self):
        data = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "redirect_uri": 'urn:ietf:wg:oauth:2.0:oob',
            "grant_type": "refresh_token",
            "refresh_token": control.setting('trakt.refresh')
        }

        if response := self.call("oauth/token", data=data, with_auth=False):
            token = response["access_token"]
            control.setSetting('trakt.token', token)
            control.setSetting('trakt.refresh', response["refresh_token"])
            control.setSetting('trakt.expires', str(time.time() + 7776000))
            return token
        return False

    def auth(self):
        try:
            code = self.get_device_code()
            if token := self.get_device_token(code):
                expires_at = time.time() + 7776000
                # token_expires = float(token["created_at"] + token["expires_in"])
                # log(f'expires_at   : {expires_at}')
                # log(f'token_expires: {token_expires}')
                control.homeWindow.setProperty('openscrapers_settings', 'false')
                control.setSetting('trakt.expires', str(expires_at))
                control.setSetting('trakt.token', token["access_token"])
                control.setSetting('trakt.refresh', token["refresh_token"])
                self.expires_at = expires_at
                self.token = token["access_token"]
                control.sleep(10)
                try:
                    user = self.call("users/me", with_auth=True)
                    control.setSetting('trakt.user', str(user['username']))
                except: error()
                control.homeWindow.setProperty('openscrapers_settings', 'true')
                control.notification(message='Trakt Successfully Authorized')
                return True
            control.notification(message='Error Authorizing Re-Authenticate Trakt Access')
            return False
        except:
            error('Trakt().auth')

    def revoke(self):
        data = {"token": control.setting('trakt.token')}
        try: self.call("oauth/revoke", data=data, with_auth=False)
        except: error('Trakt().revoke')
        control.homeWindow.setProperty('openscrapers_settings', 'false')
        control.setSetting('trakt.user', '')
        control.setSetting('trakt.expires', '')
        control.setSetting('trakt.token', '')
        control.setSetting('trakt.refresh', '')
        control.homeWindow.setProperty('openscrapers_settings', 'true')
        control.dialog.ok('Trakt', 'Auth Revoked')

    def account_info(self):
        return self.call("users/me", with_auth=True)

    def extended_account_info(self):
        account_info = self.call("users/settings", with_auth=True)
        stats = self.call(f'users/{account_info["user"]["ids"]["slug"]}/stats', with_auth=True)
        return account_info, stats

    def account_info_to_dialog(self):
        from datetime import datetime, timedelta
        try:
            account_info, stats = self.extended_account_info()
            username = account_info['user']['username']
            timezone = account_info['account']['timezone']
            joined = control.jsondate_to_datetime(account_info['user']['joined_at'], "%Y-%m-%dT%H:%M:%S.%fZ")
            private = account_info['user']['private']
            vip = account_info['user']['vip']
            if vip: vip = f'{str(account_info["user"]["vip_years"])} Years'
            total_given_ratings = stats['ratings']['total']
            movies_collected = stats['movies']['collected']
            movies_watched = stats['movies']['watched']
            movie_minutes = stats['movies']['minutes']
            if movie_minutes == 0: movies_watched_minutes = ['0 days', '0:00:00']
            elif movie_minutes < 1440: movies_watched_minutes = ['0 days', "{:0>8}".format(str(timedelta(minutes=movie_minutes)))]
            else: movies_watched_minutes = ("{:0>8}".format(str(timedelta(minutes=movie_minutes)))).split(', ')
            movies_watched_minutes = '%s %s hours %s minutes' % (movies_watched_minutes[0], movies_watched_minutes[1].split(':')[0], movies_watched_minutes[1].split(':')[1])
            shows_collected = stats['shows']['collected']
            shows_watched = stats['shows']['watched']
            episodes_watched = stats['episodes']['watched']
            episode_minutes = stats['episodes']['minutes']
            if episode_minutes == 0: episodes_watched_minutes = ['0 days', '0:00:00']
            elif episode_minutes < 1440: episodes_watched_minutes = ['0 days', "{:0>8}".format(str(timedelta(minutes=episode_minutes)))]
            else: episodes_watched_minutes = ("{:0>8}".format(str(timedelta(minutes=episode_minutes)))).split(', ')
            episodes_watched_minutes = '%s %s hours %s minutes' % (episodes_watched_minutes[0], episodes_watched_minutes[1].split(':')[0], episodes_watched_minutes[1].split(':')[1])
            heading = 'Trakt'
            items = []
            items += ['Username: %s' % username]
            items += ['Timezone: %s' % timezone]
            items += ['Joined: %s' % joined]
            items += ['Private: %s' % private]
            items += ['VIP Status: %s' % vip]
            items += ['Ratings Given: %s' % str(total_given_ratings)]
            items += ['Movies: %s Collected, %s Watched for %s' % (movies_collected, movies_watched, movies_watched_minutes)]
            items += ['Shows: %s Collected, %s Watched' % (shows_collected, shows_watched)]
            items += ['Episodes: %s Watched for %s' % (episodes_watched, episodes_watched_minutes)]
            return control.selectDialog(items, heading)
        except:
            control.notification(message='Error to Get Info')
            error()
            return

    def traktClientID(self):
        if (control.setting('trakt.client.id') != '' or control.setting('trakt.client.id') is not None) and control.setting('traktuserkey.enabled') == 'true':
            traktId = control.setting('trakt.client.id')
        else: traktId = V2_API_KEY
        return traktId

    def traktClientSecret(self):
        if (control.setting('trakt.client.secret') != '' or control.setting('trakt.client.secret') is not None) and control.setting('traktuserkey.enabled') == 'true':
            traktSecret = control.setting('trakt.client.secret')
        else: traktSecret = CLIENT_SECRET
        return traktSecret


def __getTrakt(url, post=None):
    try:
        url = url if url.startswith(BASE_URL) else urljoin(BASE_URL, url)
        post = json.dumps(post) if post else None
        headers = {'Content-Type': 'application/json', 'trakt-api-key': V2_API_KEY, 'trakt-api-version': '2'}
        if getTraktCredentialsInfo():
            headers['Authorization'] = f'Bearer {control.setting("trakt.token")}'
        if not post:
            r = requests.get(url, headers=headers, timeout=30)
        else:
            r = requests.post(url, data=post, headers=headers, timeout=30)
        r.encoding = 'utf-8'
        resp_code = str(r.status_code)
        resp_header = r.headers
        result = r.text
        if resp_code in ['423', '500', '502', '503', '504', '520', '521', '522', '524']:
            log(f'Trakt Error: {resp_code}')
            control.infoDialog(f'Trakt Error: {resp_code}')
            return
        elif resp_code in {'429'}:
            log(f'Trakt Rate Limit Reached: {resp_code}')
            control.infoDialog(f'Trakt Rate Limit Reached: {resp_code}')
            return
        elif resp_code in {'404'}:
            log(f'Trakt Object Not Found : {resp_code}')
            return
        if resp_code not in ['401', '405', '403']:
            return result, resp_header
        oauth = urljoin(BASE_URL, '/oauth/token')
        opost = {'client_id': V2_API_KEY, 'client_secret': CLIENT_SECRET, 'redirect_uri': REDIRECT_URI, 'grant_type': 'refresh_token', 'refresh_token': control.setting('trakt.refresh')}
        result = requests.post(oauth, data=json.dumps(opost), headers=headers, timeout=30).json()
        token, refresh = result['access_token'], result['refresh_token']
        control.setSetting(id='trakt.token', value=token)
        control.setSetting(id='trakt.refresh', value=refresh)
        headers['Authorization'] = f'Bearer {token}'
        if not post:
            r = requests.get(url, headers=headers, timeout=30)
        else:
            r = requests.post(url, data=post, headers=headers, timeout=30)
        r.encoding = 'utf-8'
        return r.text, r.headers
    except:
        error('__getTrakt')


def getTraktAsJson(url, post=None):
    try:
        r, res_headers = __getTrakt(url, post)
        r = client_utils.json_loads_as_str(r)
        if 'X-Sort-By' in res_headers and 'X-Sort-How' in res_headers:
            r = sort_list(res_headers['X-Sort-By'], res_headers['X-Sort-How'], r)
        return r
    except:
        error()
    return


def getTraktIndicatorsInfo():
    indicators = control.setting('indicators') if getTraktCredentialsInfo() == False else control.setting('indicators.alt')
    return True if indicators == '1' else False


def getTraktAddonMovieInfo():
    try: scrobble = control.addon('script.trakt').getSetting('scrobble_movie')
    except: scrobble = ''
    try: ExcludeHTTP = control.addon('script.trakt').getSetting('ExcludeHTTP')
    except: ExcludeHTTP = ''
    try: authorization = control.addon('script.trakt').getSetting('authorization')
    except: authorization = ''
    return scrobble == 'true' and ExcludeHTTP == 'false' and not not authorization


def getTraktAddonEpisodeInfo():
    try: scrobble = control.addon('script.trakt').getSetting('scrobble_episode')
    except: scrobble = ''
    try: ExcludeHTTP = control.addon('script.trakt').getSetting('ExcludeHTTP')
    except: ExcludeHTTP = ''
    try: authorization = control.addon('script.trakt').getSetting('authorization')
    except: authorization = ''
    return scrobble == 'true' and ExcludeHTTP == 'false' and not not authorization


def manager(name, imdb, tmdb, content):
    try:
        post = {"movies": [{"ids": {"imdb": imdb}}]} if content == 'movie' else {"shows": [{"ids": {"tmdb": tmdb}}]}
        items = [('Add to Collection', '/sync/collection')]
        items += [('Remove from Collection', '/sync/collection/remove')]
        items += [('Add to Watchlist', '/sync/watchlist')]
        items += [('Remove from Watchlist', '/sync/watchlist/remove')]
        items += [('Add to new List', '/users/me/lists/%s/items')]
        result = getTraktAsJson('/users/me/lists')
        lists = [(i['name'], i['ids']['slug']) for i in result]
        lists = [lists[i//2] for i in range(len(lists)*2)]
        for i in range(0, len(lists), 2):
            lists[i] = (str(f'Add to {lists[i][0]}'), f'/users/me/lists/{lists[i][1]}/items',)
        for i in range(1, len(lists), 2):
            lists[i] = (str(f'Remove from {lists[i][0]}'), f'/users/me/lists/{lists[i][1]}/items/remove',)
        items += lists
        select = control.selectDialog([i[0] for i in items], 'Trakt Manager')
        if select == -1: return
        elif select == 4:
            t = 'Add to new List'
            k = control.keyboard('', t)
            k.doModal()
            new = k.getText() if k.isConfirmed() else None
            if new is None or new == '': return
            result = __getTrakt('/users/me/lists', post={"name": new, "privacy": "private"})[0]
            try: slug = client_utils.json_loads_as_str(result)['ids']['slug']
            except: return control.infoDialog('Trakt Manager', heading=str(name), sound=True, icon='ERROR')
            result = __getTrakt(items[select][1] % slug, post=post)[0]
        else: result = __getTrakt(items[select][1], post=post)[0]
        icon = control.infoLabel('ListItem.Icon') if result is not None else 'ERROR'
    except:
        return


def slug(name):
    name = name.strip()
    name = name.lower()
    name = re.sub(r'[^a-z0-9_]', '-', name)
    name = re.sub(r'--+', '-', name)
    if name.endswith('-'): name = name.rstrip('-')
    return name


def sort_list(sort_key, sort_direction, list_data):
    reverse = sort_direction != 'asc'
    if sort_key == 'rank': return sorted(list_data, key=lambda x: x['rank'], reverse=reverse)
    elif sort_key == 'added': return sorted(list_data, key=lambda x: x['listed_at'], reverse=reverse)
    elif sort_key == 'title': return sorted(list_data, key=lambda x: x[x['type']].get('title'), reverse=reverse)
    elif sort_key == 'released': return sorted(list_data, key=lambda x: _released_key(x[x['type']]), reverse=reverse)
    elif sort_key == 'runtime': return sorted(list_data, key=lambda x: x[x['type']].get('runtime', 0), reverse=reverse)
    elif sort_key == 'popularity': return sorted(list_data, key=lambda x: x[x['type']].get('votes', 0), reverse=reverse)
    elif sort_key == 'percentage': return sorted(list_data, key=lambda x: x[x['type']].get('rating', 0), reverse=reverse)
    elif sort_key == 'votes': return sorted(list_data, key=lambda x: x[x['type']].get('votes', 0), reverse=reverse)
    else: return list_data

def _released_key(item):
    if 'released' in item: return item['released'] or '0'
    elif 'first_aired' in item: return item['first_aired'] or '0'
    else: return '0'


def getActivity():
    try:
        i = getTraktAsJson('/sync/last_activities')
        activity = [
            i['movies']['collected_at'],
            i['episodes']['collected_at'],
            i['movies']['watchlisted_at'],
            i['shows']['watchlisted_at'],
            i['seasons']['watchlisted_at'],
            i['episodes']['watchlisted_at'],
            i['lists']['updated_at'],
            i['lists']['liked_at'],
        ]
        activity = [int(cleandate.iso_2_utc(i)) for i in activity]
        activity = sorted(activity, key=int)[-1]
        return activity
    except:
        pass


def getWatchedActivity():
    try:
        i = getTraktAsJson('/sync/last_activities')
        activity = [i['movies']['watched_at'], i['episodes']['watched_at']]
        activity = [int(cleandate.iso_2_utc(i)) for i in activity]
        activity = sorted(activity, key=int)[-1]
        return activity
    except:
        pass


def cachesyncMovies(timeout=0):
    return cache.get(syncMovies, timeout, control.setting('trakt.user').strip())


def syncMovies():
    try:
        if not getTraktCredentialsInfo(): return
        indicators = getTraktAsJson('/users/me/watched/movies')
        indicators = [i['movie']['ids'] for i in indicators]
        return [str(i['imdb']) for i in indicators if 'imdb' in i]
    except:
        pass


def timeoutsyncMovies():
    timeout = cache.timeout(syncMovies, control.setting('trakt.user').strip())
    return timeout


def syncTVShows():
    try:
        if not getTraktCredentialsInfo(): return
        indicators = getTraktAsJson('/users/me/watched/shows?extended=full')
        indicators = [(i['show']['ids']['tmdb'], i['show']['aired_episodes'], sum(([(s['number'], e['number']) for e in s['episodes']] for s in i['seasons']), [],),) for i in indicators]
        return [(str(i[0]), int(i[1]), i[2]) for i in indicators]
    except:
        pass


def cachesyncTVShows(timeout=0):
    return cache.get(syncTVShows, timeout, control.setting('trakt.user').strip())


def timeoutsyncTVShows():
    return cache.timeout(syncTVShows, control.setting('trakt.user').strip()) or 0


def syncSeason(imdb):
    try:
        if not getTraktCredentialsInfo(): return
        indicators = getTraktAsJson(f'/shows/{imdb}/progress/watched?specials=false&hidden=false')
        indicators = indicators['seasons']
        indicators = [(i['number'], [x['completed'] for x in i['episodes']]) for i in indicators]
        return ['%01d' % int(i[0]) for i in indicators if False not in i[1]]
    except:
        pass


def syncTraktStatus():
    try:
        cachesyncMovies()
        cachesyncTVShows()
        control.infoDialog(control.lang(32092))
    except:
        control.infoDialog('Trakt sync failed')
        pass


def markMovieAsWatched(imdb):
    if not imdb.startswith('tt'): imdb = f'tt{imdb}'
    return __getTrakt('/sync/history', {"movies": [{"ids": {"imdb": imdb}}]})[0]


def markMovieAsNotWatched(imdb):
    if not imdb.startswith('tt'): imdb = f'tt{imdb}'
    return __getTrakt('/sync/history/remove', {"movies": [{"ids": {"imdb": imdb}}]})[0]


def markTVShowAsWatched(imdb):
    return __getTrakt('/sync/history', {"shows": [{"ids": {"imdb": imdb}}]})[0]


def markTVShowAsNotWatched(imdb):
    return __getTrakt('/sync/history/remove', {"shows": [{"ids": {"imdb": imdb}}]})[0]


def markEpisodeAsWatched(imdb, season, episode):
    season, episode = int('%01d' % int(season)), int('%01d' % int(episode))
    return __getTrakt('/sync/history', {"shows": [{"seasons": [{"episodes": [{"number": episode}], "number": season}], "ids": {"imdb": imdb}}]})[0]


def markEpisodeAsNotWatched(imdb, season, episode):
    season, episode = int('%01d' % int(season)), int('%01d' % int(episode))
    return __getTrakt('/sync/history/remove', {"shows": [{"seasons": [{"episodes": [{"number": episode}], "number": season}], "ids": {"imdb": imdb}}]})[0]


def scrobbleMovie(imdb, watched_percent, action):
    if not imdb.startswith('tt'): imdb = 'tt' + imdb
    return __getTrakt('/scrobble/%s' % action, {"movie": {"ids": {"imdb": imdb}}, "progress": watched_percent})[0]


def scrobbleEpisode(imdb, season, episode, watched_percent, action):
    if not imdb.startswith('tt'): imdb = 'tt' + imdb
    season, episode = int('%01d' % int(season)), int('%01d' % int(episode))
    return __getTrakt('/scrobble/%s' % action, {"show": {"ids": {"imdb": imdb}}, "episode": {"season": season, "number": episode}, "progress": watched_percent})[0]


def getMovieTranslation(id, lang, full=False):
    url = f'/movies/{id}/translations/{lang}'
    try:
        item = getTraktAsJson(url)[0]
        return item if full else item.get('title')
    except:
        pass


def getTVShowTranslation(id, lang, season='', episode='', full=False):
    if season and episode:
        url = f'/shows/{id}/seasons/{season}/episodes/{episode}/translations/{lang}'
    else:
        url = f'/shows/{id}/translations/{lang}'
    try:
        item = getTraktAsJson(url)[0]
        return item if full else item.get('title')
    except:
        pass


def getMovieAliases(id):
    try: return getTraktAsJson(f'/movies/{id}/aliases')
    except: return []


def getTVShowAliases(id):
    try: return getTraktAsJson(f'/shows/{id}/aliases')
    except: return []


def getMovieSummary(id, full=False):
    try:
        url = f'/movies/{id}'
        if full: url += '?extended=full'
        return getTraktAsJson(url)
    except:
        return


def getTVShowSummary(id, full=False):
    try:
        url = f'/shows/{id}'
        if full: url += '?extended=full'
        return getTraktAsJson(url)
    except:
        return


def getPeople(id, content_type, full=False): #Uses imdb_id
    try:
        url = f'/{content_type}/{id}/people'
        if full: url += '?extended=full'
        return getTraktAsJson(url)
    except:
        return


def SearchAll(title, year='', full=True):
    try:
        return SearchMovie(title, year, full) + SearchTVShow(title, year, full)
    except:
        return


def SearchMovie(title, year='', full=True):
    try:
        url = f'/search/movie?query={quote_plus(title)}'
        if year: url += f'&year={year}'
        if full: url += '&extended=full'
        return getTraktAsJson(url)
    except:
        return


def SearchTVShow(title, year='', full=False):
    try:
        url = f'/search/show?query={quote_plus(title)}'
        if year: url += f'&year={year}'
        if full: url += '&extended=full'
        return getTraktAsJson(url)
    except:
        return


def IdLookup(content, type, type_id):
    try:
        r = getTraktAsJson('/search/%s/%s?type=%s' % (type, type_id, content))
        return r[0].get(content, {}).get('ids', [])
    except:
        return {}


def getGenre(content, type, type_id):
    try:
        r = getTraktAsJson(f'/search/{type}/{type_id}?type={content}&extended=full')
        return r[0].get(content, {}).get('genres', [])
    except:
        error()
        return []


def getEpisodeRating(imdb, season, episode):
    try:
        if not imdb.startswith('tt'): imdb = 'tt' + imdb
        url = '/shows/%s/seasons/%s/episodes/%s/ratings' % (imdb, season, episode)
        r = getTraktAsJson(url)
        r1 = r.get('rating', '0')
        r2 = r.get('votes', '0')
        return str(r1), str(r2)
    except:
        return


def getEpisodeSummary(db_id, season, episode='', full=False):
    try:
        if not episode: url = f'/shows/{db_id}/seasons/{season}' #url += '?translations=en'
        else: url = f'/shows/{db_id}/seasons/{season}/episodes/{episode}'
        if full: url += '?extended=full'
        return getTraktAsJson(url)
    except:
        return


#/shows/game-of-thrones/seasons/1/people
#/shows/game-of-thrones/seasons/1/people?extended=guest_stars

#/shows/game-of-thrones/seasons/1/episodes/1/people
#/shows/game-of-thrones/seasons/1/episodes/1/people?extended=guest_stars


def getSeasonsSummary(db_id, full=False, episodes=False):  #Uses imdb_id, full or episodes but not both.
    try:
        url = f'/shows/{db_id}/seasons'
        if full: url += '?extended=full'
        if episodes: url += '?extended=episodes'
        return getTraktAsJson(url)
    except:
        return


def getStudio(db_id, content_type): #Uses imdb_id
    try:
        url = f'/{content_type}/{db_id}/studios'
        return getTraktAsJson(url)
    except:
        return


def SearchEpisode(title, season, episode, full=False):
    try:
        url = f'/search/{title}/seasons/{season}/episodes/{episode}'
        if full: url += '&extended=full'
        return getTraktAsJson(url)
    except:
        return
