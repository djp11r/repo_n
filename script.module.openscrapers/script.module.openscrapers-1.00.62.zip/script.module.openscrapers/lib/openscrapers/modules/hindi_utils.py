# -*- coding: utf-8 -*-
import json
import re

from traceback import print_exc

try:
    from openscrapers import quote_plus, urlencode, urljoin, urlparse, testing
    from openscrapers.modules.client import request, agent, get_page_server, scrapePage, refresh_redirect
    from openscrapers.modules.log_utils import log, error
    from openscrapers.modules.client_utils import get_jsunpack_unjuice, replaceHTMLCodes as replace_html_codes
    from openscrapers.modules.dom_parser import parseDOM
    from openscrapers.modules.utils import get_datetime, get_findall
    from openscrapers.modules.tmdb_utils import tmdb_search
except:
    import os, sys

    from modules.client import request, agent, get_page_server, scrapePage, refresh_redirect
    from modules.client_utils import get_jsunpack_unjuice, replaceHTMLCodes as replace_html_codes
    from modules.dom_parser import parseDOM
    from modules.utils import get_datetime, get_findall
    from modules.tmdb_utils import tmdb_search
    nextpage = 'https://i.imgur.com/onBTdVr.png'
    testing = True
    log = error = print

exctract_date = re.compile(r'(\d{1,2}[th|st|nd|rd]* [Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|August|Sep|September|Oct|October|Nov|November|Dec|December]* \d{2,4})', flags=re.I)   # date like 18th April 2021
exctract_episod = re.compile(r'Episode \d{1,2}', flags=re.I)
season_data = re.compile(r'season.+?(\d{1,2})|season(\d{1,2})|s(\d{1,2})', flags=re.I) # remove season 12 or s1 etc
episode_cleaner = re.compile(r'Watch Online|Video Episode Update Online|-', flags=re.I)
episode_data = re.compile(r'episodes.+?(\d+)|ep\s*(\d+)|e(\d+)', flags=re.I)  # episod 12, e12  etc
ansi_pattern = re.compile(r'(\x9B|\x1B\[)[0-?]*[ -\/]*[@-~]|[^\x00-\x7f]', flags=re.I)  # ansi_pattern
# ansi_pattern1 = re.compile(r'[^\x00-\x7f]', flags=re.I)  # ansi_pattern
multiple_spaces = re.compile(r'\s+', flags=re.I) # Multiple Spaces
monthdict = {'January': '01', 'February': '02', 'March': '03', 'April': '04', 'May': '05', 'June': '06', 'July': '07', 'August': '08', 'September': '09', 'October': '10', 'November': '11', 'December': '12'}

non_str_list = ['olangal.', 'desihome.', 'thiruttuvcd', '.filmlinks4u', '#', '/t.me/',
                'cineview', 'bollyheaven', 'videolinkz', 'moviefk.co', 'goo.gl', '/ads/',
                'imdb.', 'mgid.', 'atemda.', 'movierulz.ht', 'facebook.', 'twitter.',
                'm2pub', 'abcmalayalam', 'india4movie.co', 'embedupload.', 'bit.ly',
                'tamilraja.', 'multiup.', 'filesupload.', 'fileorbs.', 'tamil.ws',
                'insurance-donate.', '.blogspot.', 'yodesi.net', 'desi-tashan.',
                'yomasti.co/ads', 'ads.yodesi', 'mylifeads.', 'yaartv.', '/cdn-cgi/',
                'steepto.', '/movierulztv', '/email-protection', 'oneload.xyz', 'about:',
                'tvnation.me/drive.php?', 'p2p.drivewires', 'tvcine.me', '/ad', 'tvnation.me/include', 'drivewire.xyz', 'magnet:',
                'google.com', 'whatsapp.com', 'linkedin.com']

remove_ads_js_urls = ['.js', '.jpg', 'adv1/', 'ads.', '.ads', '/ad', '/ads/']

embed_list = ['cineview', 'bollyheaven', 'videolinkz', 'vidzcode', 'escr.',
              'embedzone', 'embedsr', 'fullmovie-hd', 'links4.pw', 'esr.',
              'embedscr', 'embedrip', 'movembed', 'power4link.us', 'adly.biz',
              'watchmoviesonline4u', 'nobuffer.info', 'yomasti.co', 'hd-rulez.',
              'techking.me', 'onlinemoviesworld.xyz', 'cinebix.com', 'vids.xyz',
              'desihome.', 'loan-', 'filmshowonline.', 'hinditwostop.', 'media.php',
              'hindistoponline', 'telly-news.', 'tellytimes.', 'tellynews.', 'tvcine.',
              'business-', 'businessvoip.', 'toptencar.', 'serialinsurance.',
              'youpdates', 'loanadvisor.', 'tamilray.', 'embedrip.', 'xpressvids.',
              'beststopapne.', 'bestinforoom.', '?trembed=', 'tamilserene.',
              'tvnation.', 'techking.', 'etcscrs.', 'etcsr1.', 'etcrips.', 'etcsrs.',
              'tvpost.cc', 'tellygossips.', 'tvarticles.', 'insurancehubportal.',
              'directlinktx.', 'filmstream2x.com', 'watchlinksinfo.com',
              'videoemx2.com', 'movierulz.io', 'coinztechnews.', 'thegadgetsreviewer.']

apneembed = ['newstalks.co', 'newstrendz.co', 'newscurrent.co', 'newsdeskroom.co',
             'newsapne.co', 'newshook.co', 'newsbaba.co', 'articlesnewz.com',
             'articlesnew.com', 'webnewsarticles.com', 'htnews.me', 'gamewisetalks.com']

articlesembed = ['articleweb.', 'serialghar.', 'tvarticles.', 'bollyfunmaza.']


def find_season_in_title(release_title):
    release_title = re.sub(r'\d{4}', '', release_title)  # remove year from title
    match = 1
    regex_list = [r'season(\d+)', r'season\.(\d+)', r'season.+?(\d+)',  r's(\d+)', r's\.(\d+)', r'chapter.+?(\d+)', r'^[a-z\s]+?(\d{1,2})', r'(\d+)x', r'(\d+)\.x']
    for item in regex_list:
        if match := re.search(item, release_title, flags=re.I):
            try:
                match = int(str(match[1]).lstrip('0'))
                break
            except: continue
    if match: return match
    else: return 1


def get_episode_date(name, title=''):
    episode_name = xname = ''
    xname = re.sub(episode_cleaner, '', name)
    xname = xname.replace(title, '').replace('  ', ' ')
    try:
        episode_name = exctract_date.findall(xname)[0]
        episode_name = re.sub(r'(\w)([A-Z])', r'\1 \2', episode_name)
    except: episode_name = exctract_episod.findall(xname)
    if isinstance(episode_name, list):
        try: episode_name = episode_name[0]
        except: episode_name = ''
    if episode_name == '': episode_name = re.sub(r'(\w)([A-Z])', r'\1 \2', xname)
    return episode_name.strip()


def get_ch_name(ch_name):
    ch_name = ch_name.lower()
    if 'sony' in ch_name: return 'sony-tv'
    elif 'sab' in ch_name: return 'sab-tv'
    elif 'colors' in ch_name: return 'colors-tv'
    elif 'zee' in ch_name: return 'zee-tv'
    elif 'star' in ch_name: return 'star-plus'
    return ch_name.replace(' ', '-')


def host(url):
    if isinstance(url, bytes): url = url.decode('utf-8')
    host = get_findall(r'([\w]+[.][\w]+)$', urlparse(url.strip().lower()).netloc)[0]
    return str(host.split('.')[0])


def get_source_dict(urls, sources, ihost=None, direct=False):
    # log(f'get_source_dict urls: {urls}')
    if isinstance(urls, str): urls = [urls]
    if any(x in str(urls) for x in remove_ads_js_urls): return sources
    if ihost is None: ihost = host(urls[0])
    # if re.search(r'speed|vkprime', urls[0], re.I): ihost = 'speed|vkprime'
    # log(f'ihost {ihost} len(urls) {len(urls)} type of urls {type(urls)}')
    for i in range(len(urls)):
        # if any(get_findall(r'speed|vkprime|business-loans.pw|bestarticles|tvnation.me', urls[i])):
        try:
            vid_url = str(urls[i])
            if any(x in vid_url.lower() for x in ['vkspeed', 'vkprime']): urls[i] = iurl if (iurl := get_mod_url(vid_url)) else None
            # if re.search(r'vkspeed|vkprime', vid_url, re.I): urls[i] = iurl if (iurl := get_mod_url(vid_url)) else None
            # log(f'In urls[i]: {vid_url}')
            if len(urls) > 1 and any(x in vid_url.lower() for x in ['vkspeed', 'vkprime']): #(re.search(r'vkspeed|vkprime', vid_url, re.I)):
                for j, ji in enumerate(urls, start=1):
                    if ji not in str(sources): sources.append({'source': ihost, 'quality': '720p', 'info': f'Part:{j}', 'url': ji, 'direct': False})
        except: error(f'Error i: {i} from: {__name__}: ')

    if len(urls) > 1: unfo, url = f'All parts: {len(urls)}', ' , '.join(urls)
    else: unfo, url = 'All part: Single', urls[0]
    sources.append({'source': ihost, 'quality': '720p', 'info': unfo, 'url': url, 'direct': direct})
    return sources


def get_query(title, s):
    query = query_cleaner(title)
    # log(f'query {query} title: {title}')
    if 'superstar-singer' in query: return f'superstar-singer-{s}'
    elif 'indias-best-dancer-vs-super-dancer' in query: return 'indias-best-dancer-vs-super-dancer'
    elif 'dance-deewane' in query: return f'dance-deewane-{s}'
    elif 'india-got-talent' in query: return f'india-got-talent-season-{s}'
    elif 'jhalak-dikhhla-jaa' in query: return f'jhalak-dikhhla-jaa-season-{s}'
    # elif 'crime-patrol' in query: return 'crime-patrol-48-hours'
    elif 'indias-best-dancer' in query: return f'indias-best-dancer-{s}'
    elif 'kaun-banega-crorepati' in query: return f'kaun-banega-crorepati-{s}'
    elif 'bigg-boss-ott' in query: return f'bigg-boss-ott-{s}'
    elif 'bigg-boss' in query: return f'bigg-boss-{s}'
    elif 'indian-idol' in query: return f'indian-idol-{s}'
    elif 'khatron-ke-khiladi' in query: return f'khatron-ke-khiladi-{s}'
    elif 'the-kapil-sharma-show' in query: return f'the-kapil-sharma-show-season-{s}'
    return query


def gettmdb_id(m_type, title, year=None, studio=None):
    if m_type == 'movie' and not year: year = get_datetime().year
    # title = clean_title_for_imdb_search(title)
    return f'{title}|{year}' if m_type == 'movie' else f'{studio.lower()}|{title}'


def _metacache_set(meta_cache, m_type, meta):
    if m_type == 'movie': meta_cache.set('movie', 'tmdb_id', meta, 3840)
    else: meta_cache.set('tvshow', 'tmdb_id', meta, 3840)


def fetch_meta(meta_cache, m_type, title, tmdb_id, homepage, season=1, studio='', poster='hindi_movies.png', imdb_id='', plot='', genre=None, year=None, cast=None, rating=5.0):
    if genre is None: genre = []
    if cast is None: cast = []
    if year is None: year = get_datetime().year
    meta = meta_cache.get(m_type, 'tvdb_id', tmdb_id)
    if meta is None: meta = meta_cache.get(m_type, 'tmdb_id', tmdb_id)
    if meta is None or meta.get('blank_entry'):
        meta = tmdb_search(tmdb_id, season, False)
        if not meta:
            if not plot and re.search(r'desi-serials|playdesi', str(homepage), re.I):
                plot, rating, genre = get_plot_tvshow(homepage, genre)
            meta = populet_dict(m_type, title, tmdb_id, homepage, season, studio, poster, imdb_id, plot, genre, year, cast, rating)
            if imdbdata := get_datajson_imdb(meta):
                log(f'imdb_id imdbdata: {imdbdata}')
                meta = meta_merge_update(meta, imdbdata)
        _metacache_set(meta_cache, m_type, meta)
    return meta


def query_cleaner(query):
    query = query.lower().replace(' ', '-').replace('.', '-').replace('---', '-').replace("'", '').replace('’', '').replace(':', '')
    return query


def getVideoID(url):
    try: return re.compile(r'(id|url|v|si|sin|sim|data-config|file|dm|wat|vid)=(.+?)##').findall(f'{url}##')[0][1]
    except: return


def get_mod_url(url):
    url_id = getVideoID(url)
    if not url_id: return
    if 'vkprime.php' in url: return f'https://vkprime.com/embed-{url_id}.html'
    elif 'vkspeed.php' in url: return f'https://vkspeed.com/embed-{url_id}.html'
    elif 'speed.php' in url: return f'https://vkspeed.com/embed-{url_id}-600x380.html'
    # elif 'viralnews.site/tech/xstrm.php' in url: return f'https://techautomate.in/news.php?cid={url_id}&type=xstrm'
    # elif 'viralnews.site/tech/vp.php' in url: return f'https://techautomate.in/technology.php?id={url_id}'
    # elif 'viralnews.site/tech/vk.php' in url: return f'https://techautomate.in/media.php?id={url_id}'
    # elif 'tere-sheher-mein' in url: return f'https://flow.business-loans.pw/plyr2/{url_id}'
    # elif 'ishqbaaz' in url: return f'http://flow.bestarticles.me/embed2//{url_id}'
    return url


def find_domain_notin(url):
    """
    useges:
    if not find_domain_notin(url):
        print(f'url: {url}')
    slower option:
    def re_domain_notin(url):
        return bool((re.search(r'dailymotion|vup|streamtape|vidoza|mixdrop|mystream|doodstream|watchvideo|vkprime|vkspeed', str(url), re.I,)))
    def find_domain_intersection(url):
        itemfound = [s for s in [url] if keys.intersection(s)]
        return bool(itemfound)
    """
    url = url.lower()
    filter_items = {'dailymotion', 'vup', 'streamtape', 'vidoza', 'mixdrop', 'mystream', 'doodstream', 'watchvideo', 'vkprime', 'vkspeed'}
    return any(item in url for item in filter_items)


def meta_redirect(content):
    redirect_re = re.compile(r'<meta[^>]*?[refresh|]*?url=(.*?)["\']', re.IGNORECASE)
    return match.groups()[0].strip() if (match := redirect_re.search(str(content))) else None


def form_action(url, headers, bhtml):
    try:
        if r := get_findall(r'''<form.+?action="([^"]+)''', bhtml):
            purl = r[-1]
            headers.update({'Referer': f'{url}/', 'Origin': url})
            pd = (dict(r1) if (r1 := get_findall(r"type='hidden'\s*name='([^']+)'\s*value='([^']+)", bhtml,)) else ' ')
            bhtml2 = request(purl, post=pd, headers=headers)
            if s := get_findall(r'''<iframe.+?src=['"]([^"']+)''', bhtml2):
                return s
            if r2 := get_findall(r'''<form.+?action="([^"]+)''', bhtml2):
                purl = r2[-1]
                # headers.update({'Referer': url, 'Origin': urljoin(url, '/')[:-1]})
                pd = (dict(r1) if (r1 := get_findall(r"type='hidden'\s*name='([^']+)'\s*value='([^']+)", bhtml2,)) else ' ')
                ehtml = request(purl, post=pd, headers=headers)
                if s := get_findall(r'''<iframe.+?src=['"]([^"']+)''', ehtml):
                    return s
        elif s := get_findall(r'''<iframe.+?src=['"]([^"']+)''', bhtml):
            return s
    except: error(f'Error from: {__name__}: url: {url} ')
    return


def articleweb(url, headers):
    # log(f'headers >>> : {headers}')
    try:
        if '/vid/' not in url or 'multiup' in url: ehtml = refresh_redirect(url, headers)
        else: ehtml = request(url, headers=headers)
        if not (s := re.search(r'''<iframe.+?src=\s*['"]([^'"]+)''', ehtml, re.I)):
            return
        return s[1]
    except: error(f'Error from: {__name__}: url: {url} ')


def get_apneurl(link, headers=None):
    vidurl = None
    html = scrapePage(link, headers=headers).text
    # log(f'{__name__} sources link: {link} headers: {headers} result: {html}')
    if s := form_action(link, headers, html):
        try:
            vidurl = s[0]
            # log(f'get_apneurl In vidurl  {vidurl}')
            if 'url=' in vidurl: vidurl = vidurl.split('url=')[-1]
            if 'hls' in vidurl: vidurl = vidurl.replace(',.urlset/master.m3u8', '/v.mp4').replace('hls/,', '')
            else: vidurl = vidurl
        except: error(f'Error from: {__name__}: link: {link} ')
    return vidurl


def get_embed_url(url, headers):
    # log(f'get_embed_url url: {repr(url)} headers: {repr(headers)}')
    try:
        result = refresh_redirect(url, headers=headers)
        # log(f'result: {result}')
        url = meta_redirect(result)
        if url: result = refresh_redirect(url, headers=headers)
        if not result: return
        vidurl = get_vid_url(result, headers, url)
        if not vidurl: log(f'get_embed_url not returning vidurl: {vidurl} url: {repr(url)}') #\nresult: {result}\n')
        return vidurl
    except: error(f'Error from: {__name__}: url: {url} ')
    return


def get_okmalayalam_url(url, headers):
    # log(f'get_okmalayalam_url url: {repr(url)}')
    try:
        mid = url.split('/')[-1]
        params = {'data': mid, 'do': 'getVideo'}
        data = {'hash': mid, 'r': ''}
        if jd := request('https://v.okmalayalam.org/player/index.php', XHR=True, referer=url, post=data, params=params,):
            log(f'jd: {jd}')
            jd = json.loads(jd)
            # surl = jd.get('videoSource')
            vidurl = jd.get('securedLink')
            if not vidurl: log(f'get_okmalayalam_url not returning vidurl: {vidurl} url: {repr(url)}') #\nresult: {result}\n')
            return vidurl
    except: error(f'Error from: {__name__}: url: {url} ')
    return


def get_directurl(link, headers, url):
    vhdr = {'Referer': f'{url}/', 'Origin': url, 'User-Agent': 'iPad'}
    return f'Direct_{link}|{urlencode(vhdr)}'


def get_vid_url(shtml, headers, url):
    try:

        # links = parseDOM(shtml, 'iframe', ret='src')
        # log(f'get_vid_url Total: {len(links)} links1: {links}')
        shtml = get_jsunpack_unjuice(shtml)
        # log(f'shtml: {len(shtml)} shtml: {shtml}')
        # links = get_findall(r'''<iframe.+?src=['"]([^'"]+)''', shtml)
        links = get_findall(r'''(?:iframe|source).+?(?:src|file)\s*["']?\s*[:=,]?\s*["']([^"']+)''', shtml)
        # links += get_findall(r'''["']?\s*(?:file|src)\s*["']?\s*[:=,]?\s*["']([^"']+)''', shtml)
        # log(f'get_vid_url Total: {len(links)} links2: {links}')
        links = [url for url in links if url.startswith('http') and all(x not in url for x in remove_ads_js_urls)]
        for link in links:
            link = link.lower()
            # log(f'get_vid_url link: {link}')
            if any(x in link for x in ['speed', 'vkprime', 'tvlogy']): return link
            elif any(x in link for x in articlesembed): return articleweb(link, headers)
            elif any(x in link for x in apneembed): return get_apneurl(link, headers)
            elif 'okmalayalam.' in link: return get_okmalayalam_url(link, headers)
            elif 'flow.' in link: return get_embed_url(link, headers)
            elif all(x not in link for x in non_str_list) and all(x not in link for x in embed_list): return link
            elif 'tvlogy' not in link: return get_directurl(link, headers, url)
    except: error(f'Error from: {__name__}: url: {url} ')
    return


def resolve_gen(url, headers=None):
    # log(f'In resolve_gen(url) type of url {type(url)} url: {url}')
    # if not any(get_findall(r'dailymotion|vup|streamtape|vidoza|mixdrop|mystream|doodstream|watchvideo|vkprime|vkspeed', url, re.I)):
    _headers = headers if headers else {'User-Agent': agent()}
    if not find_domain_notin(str(url)):
        urls = url.split(' , ') if ' , ' in url else [url]
        # log(f'In len of urls {len(urls)} urls: {urls} _headers: {_headers}')
        furl = []
        for iurl in urls:
            # log(f'resolve_gen iurl: {iurl}')
            if any(x in iurl for x in apneembed): url = get_apneurl(iurl, _headers)
            elif any(x in iurl for x in articlesembed): url = articleweb(iurl, _headers)
            else: url = get_embed_url(iurl, _headers)
            if url: furl.append(url)
        # log(f'resolve_gen len furl: {len(furl)} type furl {type(furl)} furl: {furl}')
        if furl:
            if testing: log(f'Out resolve_gen(url)type of furl {type(furl)} furl: {furl}')
            return ' , '.join(furl) if furl else furl[0]
    return url


def meta_merge_update(meta, imdbdata):
    try:
        if isinstance(meta['genre'], list) and isinstance(imdbdata['genre'], list):
            genre = meta['genre'] + imdbdata['genre']
            if len(genre) > 0: genre = generes_unify(genre, meta['mediatype'])
            meta.update({'genre': genre})
    except: log(f'meta_merge_update Error: {print_exc()}')
    return meta


def generes_unify(genres, m_type):
    fgenre = []
    if isinstance(genres, str):
        genre = replace_html_codes(genres)
        genres = genre.split(',')
    for genr in genres:
        genr = genr.replace('<span data-sheets-value="{"1"', '').replace('–', '-').replace('-', '-').replace('.', '')
        genr = replace_html_codes(genr)
        fgenre.append(genr.strip())
    if not fgenre:
        fgenre = ['Movie'] if m_type == 'movie' else ['TV']
    if fgenre: fgenre = list(set(fgenre))  #remove duplicate items from list
    return fgenre


def populet_dict(m_type, title, tmdb_id, homepage, season, studio, poster, imdb_id, plot, genre, year, cast, rating):
    """
    :useges
    meta = populet_dict(m_type, title, tmdb_id, homepage, season, studio, poster, imdb_id, plot, genre, year, cast, rating):
    :return: dict
    """
    if imdb_id == '': imdb_id = tmdb_id
    try:
        if 'addons\\plugin.video.infinite' in poster:
            poster = f'special://home/addons/{poster.split("addons")[1]}'
            poster = poster.replace('\\', '/')
    except: log(f'homepath not found: {print_exc()}')
    if cast is None: cast = [{'role': '', 'name': '', 'thumbnail': ''}]
    if not rating: rating = 4
    plot = replace_html_codes(plot)
    plot = plot.replace('\\n', ' ').replace('\\u2009', ' ').replace("\\'", "'").replace('\\r', '').strip()
    if isinstance(studio, str):
        studio = studio.replace('-tv', '').replace('-hd', '').replace('-hdepisodes', '')
        studio = studio.split(',')
    if not isinstance(studio, list): list(studio)
    if not genre: genre = []
    fgenre = generes_unify(genre, m_type)  #remove duplicate items from list
    dic_meta = {'mediatype': m_type, 'year': year, 'plot': plot, 'title': title, 'studio': studio, 'poster': poster, 'homepage': homepage, 'genre': fgenre, 'cast': cast, 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tmdb_id,'rating': rating, 'clearlogo': '', 'trailer': '', 'votes': 50, 'tagline': '', 'director': [], 'writer': [], 'episodes': 0, 'seasons': 0}
    if m_type == 'movie': dic_meta.update({'duration': 5400, 'mpaa': 'R'})
    else: dic_meta.update({'duration': 1320, 'mpaa': 'TV-MA', 'season': season, 'total_aired_eps': 2, 'seasons': season, 'episode': 1, 'tvshowtitle': title})
    return dic_meta


def clean_season_fromtitle(title):
    ctitle = re.sub(season_data, '', title)
    ctitle = re.sub(r'(\d{1,2})', '', ctitle)
    if not ctitle: return title
    return ctitle.strip().lower()


def clean_title_for_imdb_search(title):
    title = keepclean_title(title, True)
    return clean_season_fromtitle(title)


def clean_poster_url(poster):
    if '/nopicture/' in poster: poster = '0'
    poster = re.sub(r'(?:_SX|_SY|_UX|_UY|_CR|_AL)(?:\d+|_).+?\.', '_SX500.', poster)
    if poster := replace_html_codes(poster): return poster


def get_imdb_id(title, meta_type=None):
    meta_type = 'movie' if not meta_type or meta_type == 'movie' else 'series'
    title = clean_title_for_imdb_search(title)
    api_url = f'http://www.omdbapi.com/?apikey=dd7e2fc7&s={quote_plus(title)}'
    result = request(api_url)
    if not result: return
    item_meta = json.loads(result)
    if not item_meta.get('Search'): return
    # log(f'item: {item_meta}')
    for item in item_meta.get('Search'):
        otitle = clean_title_for_imdb_search(item['Title'])
        if title.lower() in otitle.lower() and item['Type'] == meta_type:
            return item['imdbID']


def get_datajson_imdb(metadict):
    oimdb_id = metadict['imdb_id']
    title = clean_title_for_imdb_search(metadict['title'])
    imdb_id = None
    if not oimdb_id.startswith('tt'): imdb_id = get_imdb_id(title, metadict['mediatype'])
    if imdb_id:
        oimdb_id = metadict['imdb_id']
        if oimdb_id.startswith('tt'):
            url = f'https://www.imdb.com/title/{oimdb_id}/'
            result = request(url)
            if _metadict := imdb_json_parser(title, result, metadict):
                return _metadict
    if metadict['mediatype'] == 'movie': url = f'https://www.imdb.com/search/title/?title={quote_plus(title)}&title_type=feature,tv_movie&countries=in'
    else: url = f'https://www.imdb.com/search/title/?title={quote_plus(title)}&title_type=tv_series,tv_episode,tv_miniseries&countries=in'
    # url = f'https://www.imdb.com/find/?q={quote_plus(title)}&s=tt&exact=true
    log(f'for : {title} checking url: {url}')
    result = request(url)
    return imdb_html_parser(title, result, metadict)


def imdb_json_parser(title, result, metadict):
    try:
        scripts = parseDOM(result, 'script', attrs={'id': '__NEXT_DATA__'})
        item_meta = json.loads(scripts[0])
        item_meta1 = item_meta['props']['pageProps']['aboveTheFoldData']
        try:
            if year := item_meta1['releaseYear']['year']:
                metadict['year'] = year
        except: pass
        try:
            if rating := item_meta1['ratingsSummary']['aggregateRating']:
                metadict['rating'] = float(rating)
        except: pass
        try:
            rgen = item_meta1['genres']['genres']
            if genres := [str(x['text']) for x in rgen if x != '']:
                metadict['genre'] = genres
            if metadict['plot'] == '':
                if plot := item_meta1['plot']['plotText']['plainText']:
                    metadict['plot'] = span_clening(plot)
        except: pass
        try:
            if certf := item_meta1['certificate']['rating']:
                if certf in ('Not Rated', 'Passed'): certf = 'R'
                metadict['mpaa'] = certf
        except: pass
        item_meta2 = item_meta['props']['pageProps']['mainColumnData']
        try:
            if runtime := item_meta2['runtime']['seconds']:
                metadict['duration'] = runtime
        except: pass
        try:
            if metadict['poster'] in ['', 'hindi_movies.png']:
                if poster := item_meta2['titleMainImages']['edges'][0]['node']['url']:
                    metadict['poster'] = clean_poster_url(poster)
        except: pass
        try:
            if seasons := item_meta2['episodes']['seasons'][-1]:
                metadict['seasons'] = int(seasons.get('number', 1))
                metadict['season'] = int(seasons.get('number', 1))
            if episodes := item_meta2['episodes']['episodes']['total']:
                metadict['total_aired_eps'] = int(episodes)
        except: pass
        if ctitle := item_meta1['titleText']['text']:
            if re.search(title, str(ctitle), re.I): metadict['alternative_titles'] = [keepclean_title(ctitle)]
    except:
        pass
    return metadict


def imdb_html_parser(title, result, metadict):
    try:
        items = parseDOM(result, 'div', attrs={'class': 'lister-item mode-advanced'})
        for item in items:
            header = parseDOM(item, 'h3', attrs={'class': 'lister-item-header'})
            fheader = parseDOM(header, 'a')
            found_title = clean_title_for_imdb_search(fheader[0])
            if re.search(title, str(found_title), re.I):
                href = parseDOM(header, 'a', ret='href')
                if imdb_id := re.search(r'(tt\d*)', str(href)).group():
                    metadict['imdb_id'] = imdb_id
                    url = f'https://www.imdb.com/title/{imdb_id}/'
                    result = request(url)
                    if rter_metadict := imdb_json_parser(title, result, metadict):
                        return rter_metadict
                uitem = item
                break
        try:
            year_wrapper = parseDOM(uitem, 'span', attrs={'class': 'lister-item-year text-muted unbold'})
            try: year = re.search(r'\d{4}', year_wrapper).group()
            except: year = get_datetime().year
            if year: metadict['year'] = year
        except: pass
        try:
            if metadict['poster'] in ['', 'hindi_movies.png']:
                poster = parseDOM(uitem, 'img', attrs={'class': 'loadlate'}, ret='loadlate')[0]
                if poster := clean_poster_url(poster):
                    metadict['poster'] = poster
        except: pass
        try:
            # genresplot_wrapper = parseDOM(items, 'div', attrs={'class': '.+?GenresAndPlot__ContentParent.+?'})
            genres_wrapper = parseDOM(uitem, 'span', attrs={'class': 'genre'})
            if genre := [item.replace('<span class="ipc-chip__text" role="presentation">', '').replace('</span>', '').strip() for item in genres_wrapper if item]:
                metadict['genre'] = genre
        except: pass
        try:
            if metadict['plot'] == '':
                plot_wrapper = parseDOM(items, 'p', attrs={'class': 'text-muted'})
                if plot := span_clening(plot_wrapper[0]):
                    metadict['plot'] = plot
        except: pass
        try:
            rating_wrapper = parseDOM(uitem, 'span', attrs={'class': 'rating-rating.+?'})
            if rating := parseDOM(rating_wrapper, 'span', attrs={'class': 'value'}, )[0]:
                metadict['rating'] = float(rating)
        except: pass
    except: log(f'Error: {print_exc()}')
    return metadict


def span_clening(span_text):
    span_text = span_text.rsplit('<span>', 1)[0].strip()
    span_text = re.sub(r'<.+?>|</.+?>', '', span_text)
    span_text.replace('\xa0', ' ').replace('See all certifications', '').replace('See full summary', '')
    if 'add a plot' not in span_text.lower():
        span_text = replace_html_codes(span_text)
        span_text.strip().replace('\\n', '')
    else: span_text = ''
    return span_text.strip()


def get_plot_tvshow(show_url=None, genre=None):
    episo_page = request(show_url)
    result1 = parseDOM(episo_page, 'div', attrs={'class': 'main-content col-lg-9'})
    result1 += parseDOM(episo_page, 'div', attrs={'class': 'blog-posts posts-large posts-container'})
    plot = ''
    genres = []
    rating = 5.0

    result = parseDOM(result1, 'div', attrs={'id': 'content'})
    p = parseDOM(result, 'div', attrs={'class': 'page-content'})
    if p := parseDOM(p, 'div', attrs={'class': 'page-content'}):
        title_overview = get_findall(r'<p>(.+?)</p>', str(p))
        try: plot = title_overview[0].replace('<br/><br/>', '').replace('\\n', '').strip()
        except: pass
        try:
            rest_ofp = title_overview[1].replace('<br/><br/>', '').replace('\\n', '').strip()
            rating = get_findall(r'Show Rating: </span>\s+(.+?)/.+? <p>', rest_ofp)[0]
            genres = get_findall(r'Genre: </span>\s+(.+?)$', rest_ofp)  #[0]
        except: pass
    else:
        try: plot = get_findall(r'loading="lazy" \/><\/div>(.*?)<p>.+?<span', str(result), re.M)[0].strip()
        except: pass
        try:
            genres = get_findall(r'<span.+?font-weight:bold">(.+?)<\/span>', str(result), re.M)  #[0]
        except: pass
    for item in genres:
        if 'on:' in item: item = item.split(':')[1].strip()
        if item: genre.append(item)
    plot = replace_html_codes(plot)
    return plot, rating, genre


def get_int_epi(episode):
    if episode_int := re.search(r'(\d{1,2}(st|nd|rd|th))(.*?)(\d{2,4})', episode):
        episode_int = episode_int.group()
        month = monthdict.get(episode_int.split(' ')[1])
        try:
            # d = re.search(r'^\d+(st|nd|rd|th)', episode).group()
            # day = re.sub(r'(st|nd|rd|th)', '', d)
            day = re.search(r'^\d{1,2}', episode_int).group()
            day = day.rjust(2, '0')
            # day = re.search(r'\d{2}', episode).group()
            year = re.search(r'\d{4}$', episode).group()
        except: day, year = '0', str(get_datetime().year)
        season = day if month is None else f'{month}{day}'
        return season, year
    else:
        epis_no = re.search(r'\d{1,2}', episode)
        epis_no = epis_no.group() if epis_no else 0
        return epis_no, str(get_datetime().year)


def string_date_to_num(string):
    # date_str = re.search(r'(\d{1,2}(st|nd|rd|th))(.*?)(\d{2,4})', string).group()
    if date_str := re.search(exctract_date, string):
        date_str = date_str.group()
        month = monthdict.get(date_str.split(' ')[1])
        # d = re.search(r'^\d+(st|nd|rd|th)', date_str).group()
        # day = re.sub(r'(st|nd|rd|th)', '', d)
        day = re.search(r'^\d{1,2}', date_str).group()
        year = re.search(r'\d{4}$', date_str).group()
        return f'{year}-{month:0>2}-{day:0>2}'
    else: return get_datetime(True)


def additional_title_cleaner(title):
    title = title.replace('&#8211;', '').replace('–', '').replace('&lt;', '<').replace('&gt;', '>').replace('&#38;', '&').replace('&nbsp;', '').replace('&#8211;', '-').replace('&#8217;', '\'').replace('&#8230;', ' ')
    title = title.replace('&quot;', '\"').replace('&amp;', '&').replace('&Amp;', '&').replace('...', '').replace('---', '-').replace("'", '').replace('’', '').replace(':', '')
    return re.sub(multiple_spaces, ' ', title)


def convert_youtube_duration_to_minutes(duration):
    """
    :param duration:
    convert_YouTube_duration_to_minits('P2DT1S')
    172801
    convert_YouTube_duration_to_minits('PT2H12M51S')
    7971
    :return:
    """
    day_time = duration.split('T')
    day_duration = day_time[0].replace('P', '')
    day_list = day_duration.split('D')
    hour = minute = second = day = 0
    if len(day_list) == 2: day = int(day_list[0]) * 60 * 60 * 24  # day_list = day_list[1]
    hour_list = day_time[1].split('H')
    if len(hour_list) == 2:
        hour = int(hour_list[0]) * 60 * 60
        hour_list = hour_list[1]
    else: hour_list = hour_list[0]
    minute_list = hour_list.split('M')
    if len(minute_list) == 2:
        minute = int(minute_list[0]) * 60
        minute_list = minute_list[1]
    else: minute_list = minute_list[0]
    second_list = minute_list.split('S')
    if len(second_list) == 2: second = int(second_list[0])
    minutes = (day + hour + minute + second) / 60
    return int(minutes)


def keepclean_title(title, episod=False):
    if title is None: return
    try:
        if re.search(r"(?=.*\d).0", title): title = title.replace('.0', '')
        if ':' in title: title = title.replace(':', ' ')
        if not episod:
            title = re.sub(exctract_date, '', title)  # remove date like 18th April 2021
            title = re.sub(episode_data, '', title)  # remove episod 12 or ep 1 etc
        # title = re.sub(season_data, '', title)  # remove season 12 or s1 etc
        title = re.sub(ansi_pattern, '', title)  # remove ansi_pattern
        # title = re.sub(ansi_pattern1, '', title)  # remove ansi_pattern
        title = re.sub(r'&#(\d+);', '', title)
        title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
        title = additional_title_cleaner(title)
        title = re.sub(r'([:;\-"\',!_.?~$@])', ' ', title)  # remove all characters in bracket
        title = re.sub(r'\<[^>]*\>|\([^>]*\)', '', title) # remove in bracket like this <anything> or (any thing)
        # title = re.sub(r'\([^>]*\)', '', title)  # remove in bracket like (anything) etc
        # title = re.sub(r'\n|([[].+?[]])|([(].+?[)])|\s(vs|v[.])\s|(:|;|-|"|,|\'|\_|\.|\?)|\(|\)|\[|\]|\{|\}|\s', '', title).lower()
        # title = re.sub(r'\n|([\[({].+?[})\]])|([:;\-"\',!_.?~$@])|\s+', '', title)
        title = re.sub(multiple_spaces, ' ', title) # remove Multiple Spaces
    except: pass
    return title.strip()


def ordinal(integer):
    int_to_string = str(integer)
    if int_to_string in {'1', '-1'}: return f'{int_to_string}st'
    elif int_to_string in {'2', '-2'}: return f'{int_to_string}nd'
    elif int_to_string in {'3', '-3'}: return f'{int_to_string}rd'
    elif int_to_string[-1] == '1' and int_to_string[-2] != '1': return f'{int_to_string}st'
    elif int_to_string[-1] == '2' and int_to_string[-2] != '1': return f'{int_to_string}nd'
    elif int_to_string[-1] == '3' and int_to_string[-2] != '1': return f'{int_to_string}rd'
    else: return f'{int_to_string}th'


def get_next_hepisode(meta):
    from datetime import datetime, timedelta, date
    e_name = meta.get('ep_name', meta['title'])
    if 'Episode' in e_name:
        e_name = int(e_name.replace('Episode', ''))
        n_ep = e_name + 1
        n_ep_name = f'Episode {n_ep}'
        url = meta['url']
        n_url = url.replace(f'episode-{e_name}', f'episode-{n_ep}')
        meta.update({'ep_name': n_ep_name, 'episode': f'{n_ep}', 'url': n_url})
    else:
        e_name = e_name.replace(' ', '-').lower()
        premiered = meta['premiered']
        current_episode = datetime.strptime(premiered, "%Y-%m-%d")
        # calculating end date by adding 1 day
        Enddate = current_episode + timedelta(days=1)
        day = Enddate.strftime('%d')
        month = Enddate.strftime('%m')
        year = Enddate.strftime('%Y')
        n_premiered = f'{year}-{month}-{day}'
        n_episode = f'{month.lstrip("0")}{day}'
        day = ordinal(day.lstrip("0"))
        mont = Enddate.strftime('%B')
        n_ep_name = f'{day} {mont} {year}'
        next_ep_name = n_ep_name.replace(' ', '-').lower()
        url = meta['url']
        n_url = url.replace(e_name, next_ep_name)
        meta.update({'ep_name': n_ep_name, 'episode': n_episode, 'premiered': n_premiered, 'url': n_url})
    # log(f'updated meta: {repr(meta)}')
    return meta


def replace_quotes(match):
    return '"' + match.group(1).replace('"', r'\"') + '"'


def get_script_json(result):
    # Find all <script> tags
    script_tags = parseDOM(result, 'script', attrs={'id': '__NEXT_DATA__'})
    # print(f'script_tags: {script_tags}')
    # Parse the HTML
    # soup = BeautifulSoup(result, "html.parser")
    # script_tags = soup.find_all("script")
    # Look for the script starting with "window.__data"
    # target_script = None
    # for script in script_tags:
    #     if script.string and script.string.strip().startswith("window.__data"):
    #         target_script = script.string
    #         break
    # print(f'script_tags: {script_tags}')
    if script_tags is None:
        return f'Error: No Data located'

    # Extract JSON part from the string
    # Find the start and end positions of the JSON part
    target_script = script_tags[0]
    start_index = target_script.find("{")
    end_index = target_script.rfind("}") + 1

    # Extract the JSON part
    json_string = target_script[start_index:end_index]

    # Replace 'undefined' with 'null' to make it valid JSON
    json_string = re.sub(r'\bundefined\b', 'null', json_string)

    # More corrections for valid JSON
    pattern = r'(new\s+Date\("[^"]*"\)|read\s+Date\("[^"]*"\))'
    data = re.sub(pattern, replace_quotes, json_string)
    # print(f'data: {data}')

    try:
        return json.loads(data)
    except Exception as e:
        return f'read_from_tubi json Exception type Error: {type(e).__name__}'


def get_m3ulist(list_type):
    from openscrapers.modules.utils import decode
    gapp_url = 'w4nCqMOfw4PDlsKswpDCn8OYw5XDpcOKwqTDn8KBw4rDocOQw5fDkcOXwqHDhMKjw5jCgsOQw5PDhMOiw5TDpcKiw5RjwqzCnsOJw6vDhMOSw57DrMOpwrDCgcOSwoDCr8OgwrfCscOTwrnDmcKuwpvDlcK8w5HCu8K7w5TDl8KjwqrDhMKWwp3Ci8OWwqLCmMOJwpLDhcKnw4bCpcK/wpnCpsOZwqLDmcKpw5/DncKmbcK4wrbCpsOowo7Dm8OLw4XDmsKOwonDmcOBw4jDhMOTw4DClMOXw6vDhsKXwqo='
    # list_type = "plex" ,
    url = decode(gapp_url)
    link = f'{url}region=us&service={list_type}'
    data = request(link)