# -*- coding: UTF-8 -*-
# import json
import re

from openscrapers.modules.client import agent, request
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.hindi_utils import get_query, get_source_dict, query_cleaner, resolve_gen
from openscrapers.modules.utils import regex_from_to
from openscrapers.modules.log_utils import error, log
from openscrapers.modules.control import setting
from openscrapers.modules.source_utils import get_host
from openscrapers import custom_base_link
custom_base = custom_base_link(__name__)


class source:

    def __init__(self):
        self.name = 'yodesi'
        self.base_link = custom_base or 'https://www.yodesitv.cc'
        self.domains = list(get_host(self.base_link)) # ['yodesitv.cc']
        self.search_link = '/feed/?s=%s&submit=Search'
        self.info_link = 'https://www.yo-desi.com/player.php?id=%s'
        self.headers = {'User-Agent': agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f'From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year}')
        try:
            try:
                url = aliases[0]['url']
                if 'yodesitv' in url: return url
            except: pass
            return f'{tvshowtitle}'
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f'From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}')
        try:
            # if type(tvdb) == int: return
            # if '|' not in tvdb: return
            if 'watch-online' in url: return url
            query = get_query(url)
            # log(f'query {query} title: {title}')
            # if re.search(r'indias-got-talent-season-10', query, re.I): query = 'india-got-talent-season-10'
            # elif re.search(r'the-kapil-sharma-show', query, re.I): query = f'the-kapil-sharma-show-season-4'
            if re.search(r'episode', title, re.I): query = f'{query}-watch-online-{title}'
            else: query = f'{query}-{title}-watch-online'
            query = query_cleaner(query)
            return f'{self.base_link}/{query}/'
        except:
            error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict):
        sources = []
        # log(f'From: {__name__} url {url}')
        try:
            if not url: return sources
            result = request(url, headers=self.headers)
            if not result and '-watch-online/' in url:
                url = url.replace('-watch-online/', '-video-episode-update-online/')
                result = request(url, headers=self.headers)
            if not result: return sources
            result = parseDOM(result, 'div', attrs={'class': 'thecontent'})
            items = regex_from_to(result[0], r'single-heading', r'</a></p>')
            for item in items:
                # result = parseDOM(item, 'span', attrs={'class': 'single-heading'})
                # item = parseDOM(item, 'p')
                if all(x not in item for x in ['Flash Player', 'Dailymotion', 'Netflix']):
                    # print(f'item: {repr(item)}')
                    item = parseDOM(item, 'a', attrs={'target': '_blank'}, ret='href')
                    if item: sources = get_source_dict(item, sources)
            if not sources: log(f'From: {__name__} no sources on url {url}')
            return sources
        except:
            error(f'{__name__}_ sources url: {url} ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return resolve_gen(url)
