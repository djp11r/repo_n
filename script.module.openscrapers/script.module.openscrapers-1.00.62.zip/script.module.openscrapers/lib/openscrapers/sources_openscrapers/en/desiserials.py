# -*- coding: UTF-8 -*-

import re
from openscrapers import parse_qs, urlencode
from openscrapers.modules.client import agent, scrapePage
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.hindi_utils import get_query, get_source_dict, query_cleaner, resolve_gen, get_ch_name
from openscrapers.modules.log_utils import error, log
from openscrapers.modules.control import setting
from openscrapers.modules.source_utils import get_host
from openscrapers import custom_base_link
custom_base = custom_base_link(__name__)

class source:

    def __init__(self):
        self.name = 'desiserials'
        self.base_link = custom_base or 'https://www.desi-serials.cc'
        self.domains = list(get_host(self.base_link)) #  ['desi-serials.cc']
        self.headers = {'User-Agent': agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f'From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year}')
        try:
            try:
                url = aliases[0]['url']
                # log(f'show url: {url}')
                if 'desi-serials' in url: return url
            except: pass
            return f'{tvshowtitle}'
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f'From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}')
        try:
            if type(tvdb) == int: return
            if '|' not in tvdb: return
            if 'episode' in title.lower(): return
            # if 'watch-online' in url: return urlencode(url)
            ch_name = get_ch_name(str(tvdb))
            query = get_query(url)
            if re.search(r'masterchef-india', query, re.I): query = f'{query}-{title}-watch-online'
            # elif re.search(r'jhalak-dikhhla-jaa', query, re.I): query = f'jhalak-dikhhla-jaa-season-11-episode-{title}-watch-online'
            else: query = f'{query}-episode-{title}-watch-online'
            fquery = query_cleaner(query)
            url = {'url': f'{self.base_link}/{fquery}/', 'referer': f'{self.base_link}/{ch_name}/'}
            url = urlencode(url)
            return url
        except:
            error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict):
        # log(f'From: {__name__} url {url}')
        sources = []
        try:
            if not url: return sources
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            url = data['url']
            self.headers['referer'] = data['referer']
            result = scrapePage(url, headers=self.headers).text
            if not result: return sources
            # read_write_file(read=False, result=result)
            result = parseDOM(result, 'div', attrs={'class': 'post-content'})
            items = parseDOM(result, 'p')
            for item in items:
                urls = parseDOM(item, 'a', attrs={'target': '_blank'}, ret='href')
                # log(f'total: {len(urls)} urls: {urls}')
                iurls = []
                if iurls := [iurl for iurl in urls if iurl not in iurls]: sources = get_source_dict(iurls, sources)
            if not sources: log(f'From: {__name__} no sources on url {url}')
            return sources
        except:
            error(f'{__name__}_ sources url: {url} ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return resolve_gen(url)
