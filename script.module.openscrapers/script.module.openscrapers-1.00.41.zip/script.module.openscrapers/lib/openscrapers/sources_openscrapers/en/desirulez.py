# -*- coding: UTF-8 -*-
import json
import re, traceback

import requests
from openscrapers import urlencode, parse_qs, urljoin, quote
from openscrapers.modules import cleantitle
from openscrapers.modules.hindi_sources import get_source_dict, resolve_gen, read_write_file
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.client import agent, scrapePage, request
from openscrapers.modules.scrape_sources import get_search_startpage


class source:

    def __init__(self):
        self.name = "desirulez"
        self.domains = ['desirulez.cc']
        self.base_link = 'http://www.desirulez.cc'
        self.base_link_2 = 'http://www.desirulez.me'
        self.base_link_3 = 'https://www.desirulez.cc:443'
        self.headers = {'User-Agent': agent(), }

    def movie(self, imdb, title, localtitle, aliases, year):
        # log(f'From: {__name__}\nimdb: {imdb}\ntitle: {title}\nlocaltitle: {localtitle}\naliases: {aliases}\nyear: {year}')
        try:
            link = 'http://www.desirulez.cc/forumdisplay.php?f=20'
            movies_page = scrapePage(link, headers=self.headers).text # read_write_file(file_n='www.desirulez.cc.html')#
            result = parseDOM(movies_page, "h3", attrs={"class": "threadtitle"})
            for item in result:
                if title in item:
                    url = parseDOM(item, "a", ret="href")[0]
                    url = urljoin(self.base_link_3, quote(url)) if not url.startswith(self.base_link_3) else url
                    # log(f'url: {url}')
                    url = {'imdb': imdb, 'title': title, 'year': year, 'aliases': aliases, 'url': url}
                    url = urlencode(url)
                    return url
        except:
            error(f'{__name__}_ movie: ')
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f'From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year}')
        try:
            try:
                url = aliases[0]['url']
                # log(f'show url: {url}')
                if 'desirulez' in url: return url
            except: pass
            title, urls = get_search_startpage(tvshowtitle, 'desirulez.cc')
            for url in urls:
                if 'forumdisplay.php' in str(url) and title in str(url).lower():
                    # url = f'{self.base_link}/{url}'
                    url = re.sub(r'page(\d+)', '', str(url))
                    log(f'desirulez tvshow title: {title} url: {url}')
                    return url
            return
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f'From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}')
        try:
            if type(tvdb) == int: return
            if 'watch-online' in url.lower(): 
                url = {'imdb': imdb, 'title': title, 'url': url}
                url = urlencode(url)
                return url
            if '|' in tvdb:
                # exctract_date = re.compile(r' Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|August|Sep|September|Oct|October|Nov|November|Dec|December ')
                # q_item = re.sub(exctract_date, '', title)
                # q_item = q_item.replace('  ', '-')
                # log(f'desirulez episode q_item: {q_item} episode >>>  : {episode}')
                episode = title.lower().replace(' ', '-').replace('.', '-')
                # log(f'desirulez episode type: {type(url)} url >>>  : {url}')
                result = requests.get(url, headers=self.headers).text
                result = parseDOM(result, "h3", attrs={"class": "threadtitle"})
                # log(f'desirulez episode result 2  : {result}')
                url = ''
                for item in result:
                    # log(f'desirulez episode item : \n{item}\n')
                    urls = parseDOM(item, "a", ret="href")
                    for url in urls:
                        # log(f'### episode: {episode} title: {title} url:  {url} ')
                        if 'watch-online' in str(url).lower() and episode in str(url).lower(): # and season in url:
                            log(f'>>>> episode: {episode} url:  {url}')
                            url = {'imdb': imdb, 'title': title, 'url': f'{self.base_link}/{url}'}
                            url = urlencode(url)
                            return url
                if url == '': return ''
        except:
            error(f'{__name__}_ episode: ')
            return

    def searchShow(self, title, season, episode, aliases):
        # aliases = [{'title': title}]
        try:
            url = '%s/tv-show/%s/season/%01d/episode/%01d' % (self.base_link, cleantitle.geturl(title), int(season), int(episode))
            # url = '%s/show/%s/season/%01d/episode/%01d' % (self.base_link, cleantitle.geturl(alias['title']), int(season), int(episode))
            url = request(url, headers=self.headers, output='geturl', timeout='10')
            if self.base_link in url:
                return url
        except:
            error(f'{__name__}_ searchShow: ')
            return

    def sources(self, url, hostDict):
        # log(f'From: {__name__} url {url}')
        sources = []
        try:
            if not url: return sources
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            url = data['url']
            # log(f'url to get: {url}')
            result = requests.get(url, headers=self.headers).text
            if not result: return sources
            result = result.replace('\n', '')
            links = parseDOM(result, 'blockquote', attrs={'class': r'.*?postcontent.*?'})
            # log(f'links[0]: {links[0]}')
            # pattern = re.compile(r'(?<=font color)(.+?)(((?=font color)|##)+)', re.S)  # all a in after font color
            pattern = re.compile(r'(?<=<b>)(.+?)((?=<b>)|##)', re.S)  # find all a after <b> and before <b>
            ndata = re.findall(pattern, links[0] + '##') # add ## to get to the end of string
            for ai in ndata:
                urls = re.findall(r'href=[\'"]?([^\'" >]+)', ai[0])
                final_url = []
                for iurl in urls:
                    if 'imdb.com' in iurl: continue
                    if iurl not in final_url: final_url.append(iurl)
                if final_url: sources = get_source_dict(final_url, sources)
            return sources
        except:
            error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return resolve_gen(url)
