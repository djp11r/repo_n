# -*- coding: utf-8 -*-
import json
import os
import random
import re
import ssl
import threading
import time
import traceback
from collections import OrderedDict, namedtuple

import requests
import urllib3
from requests import Session, adapters
from requests.compat import urlparse, urlunparse
from requests.packages.urllib3.exceptions import InsecureRequestWarning

urllib3.disable_warnings(InsecureRequestWarning)

try:
    from openscrapers.modules.cache import get, cache_get, cache_insert
    from openscrapers.modules import cfscrape as cloudscraper
except:
    from modules.cache import get, cache_get, cache_insert
    import modules.cfscrape as cloudscraper

try:
    from openscrapers.modules.log_utils import log, error
    testing = False
    cache_responce = False
    loglevel = 1
except:
    import functools
    print = functools.partial(print, flush=True)
    log = error = print
    cache_responce = True
    loglevel = 1


UrlParts = namedtuple('UrlParts', 'base search default_search')
_head_checks = {}


def _request_cache_save(key, cache):
    data = OrderedDict(sorted(cache.items()))
    # log("_request_cache_save key: %s data: %s" % (key, data))
    cache_insert(key, data)


def _response_cache_save(key, data):
    # data = cache = OrderedDict(sorted(cache.items()))
    # log("_response_cache_save key: %s data: %s" % (key, data))
    cache_insert(key, data)


def _response_cache_get(key):
    data = cache_get(key, 12)
    # log("_response_cache_get key: %s data: %s" % (key, data))
    return data


def _update_request_options(request_options):
    domain = _get_domain(request_options['url'])
    # log("domain: %s" % domain)
    headers = cache_get(domain)
    if not headers: headers = {}
    headers['X-Domain'] = domain
    request_options.setdefault('headers', {})
    request_options['headers'].update(headers)


def _save_cf_cookies(cfscrape, response):
    cookies = ''
    set_cookie = response.headers.get('Set-Cookie', '')
    cf_cookies = re.findall(r'(PHPSESSID|__cf.*?|cf.*?)=(.*?);', set_cookie)
    cookies_dict = {key: value for (key, value) in cf_cookies}

    cf_cookies = re.findall(r'(PHPSESSID|__cf.*?|cf.*?)=(.*?);', response.request.headers.get('Cookie', ''))
    original_cookies = {key: value for (key, value) in cf_cookies}

    for key in original_cookies.keys():
        if cookies_dict.get(key, None) is None:
            cookies_dict[key] = original_cookies[key]

    try:
        cf_cookies = cfscrape.cookies.items()
        for (key, value) in cf_cookies:
            cookies_dict[key] = value
    except: error('error: %s' % traceback.print_exc())

    cookies_dict = OrderedDict(sorted(cookies_dict.items()))
    for key in cookies_dict.keys():
        cookies += '%s=%s; ' % (key, cookies_dict[key])

    cookies = cookies.strip()
    if cookies == '':
        return

    headers = {
        'User-Agent': response.request.headers['User-Agent'],
        'Cookie': cookies.strip()
    }

    cache_key = response.request.headers['X-Domain']
    _request_cache_save(cache_key, headers)


def _get(cfscrape, url, headers, timeout, allow_redirects, update_options_fn):
    request_options = {
        'method': 'GET',
        'url': url,
        'headers': headers,
        'timeout': timeout,
        'allow_redirects': allow_redirects
    }

    if update_options_fn is not None:
        update_options_fn(request_options)

    return cfscrape.request(**request_options)


def _is_cloudflare_iuam_challenge(resp, allow_empty_body=False):
    try:
        return (
            resp.headers.get('Server', '').startswith('cloudflare')
            and resp.status_code in [429, 503]
            and (allow_empty_body or re.search(
                r'action="/.*?__cf_chl_jschl_tk__=\S+".*?name="jschl_vc"\svalue=.*?',
                resp.text,
                re.M | re.DOTALL
            ))
        )
    except AttributeError:
        error('error: %s' % traceback.print_exc())

    return False


def _get_domain(url):
    parsed_url = urlparse(url)
    scheme = parsed_url.scheme if parsed_url.scheme != '' else 'https'
    return "%s://%s" % (scheme, parsed_url.netloc)


def _get_head_check(url):
    result = _head_checks.get(url, None)
    if isinstance(result, bool):
        return url, result
    elif result is not None:
        return _get_head_check(result)
    return url, None


USER_AGENTS = ["Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36", "Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36", "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36",
               "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36",
               "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36",
               "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36", "Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36",
               "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36",
               "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36",
               "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36",
               "Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36", "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36",
               "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36",
               "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36"]


class randomUserAgentRequests(Session):
    def __init__(self, *args, **kwargs):
        super(randomUserAgentRequests, self).__init__(*args, **kwargs)
        if "requests" in self.headers["User-Agent"]:
            # Spoof common and random user agent
            self.headers["User-Agent"] = random.choice(USER_AGENTS)


class Request(object):
    """
    :useges:
        from openscrapers.modules.request import Request
        # initiate class
        request = Request(timeout=20)
    """
    def __init__(self, sequental=False, timeout=None, wait=1, skip_head=True):
        self._request = randomUserAgentRequests()
        self._cfscrape = cloudscraper.create_scraper(interpreter='native')
        self._sequental = sequental
        self._wait = wait
        self._should_wait = False
        self._lock = threading.Lock()
        self._timeout = 15
        if timeout is not None:
            self._timeout = timeout
        self.exc_msg = ''
        self.skip_head = skip_head
        self.request_time = 99
        self.cache_resp = cache_responce

    def _verify_response(self, response):
        if response.status_code >= 400:
            self.exc_msg = 'response status code %s' % response.status_code
            if response.status_code in [429, 503]:
                self.exc_msg = '%s (probably Cloudflare)' % self.exc_msg
            raise Exception()

    def _request_core(self, request, sequental=None, cf_retries=3):
        self.exc_msg = ''

        response = _response_cache_get(request.url)
        if response:
            # log("_request_core from cache response: %s" % response)
            return response
        if sequental is None:
            sequental = self._sequental

        response_err = lambda: None
        response_err.status_code = 501

        try:
            response = None
            if sequental is False:
                self._request_start = time.time()
                response = request(None)
                self._request_end = time.time()
                self.request_time = round(self._request_end - self._request_start)
                response_err = response
                self._verify_response(response)
                if self.cache_resp: _response_cache_save(request.url, response.text)
                response = {'key': '{}'.format(request.url), 'value': '{}'.format(response.text)}
                return response

            with self._lock:
                if self._should_wait:
                    time.sleep(self._wait)
                self._should_wait = True
                self._request_start = time.time()
                response = request(_update_request_options)
                self._request_end = time.time()
                self.request_time = round(self._request_end - self._request_start)

            response_err = response
            self._verify_response(response)

            try:
                if self.exc_msg == '' and response.request.headers.get('X-Domain', None) is not None:
                    _save_cf_cookies(self._cfscrape, response)
            except:
                error('error: %s' % traceback.print_exc())
            if self.cache_resp: _response_cache_save(request.url, response.text)
            response = {'key': '{}'.format(request.url), 'value': '{}'.format(response.text)}
            return response
        except:
            self._request_end = time.time()
            self.request_time = round(self._request_end - self._request_start)

            if self.exc_msg == '':
                exc = traceback.format_exc(limit=1)
                if 'ConnectTimeout' in exc or 'ReadTimeout' in exc:
                    self.exc_msg = 'request timed out'
                if 'Detected the new Cloudflare challenge.' in exc and cf_retries > 0 and self.request_time < 2:
                    cf_retries -= 1
                    log('cf_new_challenge_retry: %s' % request.url)
                    return self._request_core(request, sequental, cf_retries)
                elif 'Cloudflare' in exc or '!!Loop Protection!!' in exc:
                    self.exc_msg = 'failed Cloudflare protection'
                elif 'Max retries exceeded with url' in exc:
                    self.exc_msg = 'Max retries exceeded'
                else:
                    self.exc_msg = 'failed - %s' % exc

            log('%s %s' % (request.url, self.exc_msg))

            return response_err

    def _check_redirect(self, src, response):
        if response.status_code in [301, 302]:
            redirect_url = response.headers['Location']
            # log('redirect_url: %s' % redirect_url)
            if not redirect_url.endswith('127.0.0.1') and not redirect_url.endswith('localhost') and response.url != redirect_url:
                dest = redirect_url
                src_clean = re.sub(r'https?://', '', src)
                dest_clean = re.sub(r'https?://', '', _get_domain(dest))
                if src_clean != dest_clean or 'https://' in dest:
                    log('redirect url: %s' % dest)
        return False

    def _head(self, url):
        global _head_checks

        if self.skip_head:
            return url, 200

        (url, head_check) = _get_head_check(url)
        if head_check:
            return url, 200
        elif head_check is False:
            return url, 500

        url = _get_domain(url)
        # log('HEAD: %s' % url)
        request = lambda _: self._request.head(url, timeout=2)
        request.url = url

        try:
            response = self._request_core(request, sequental=False)
            if _is_cloudflare_iuam_challenge(response, allow_empty_body=True):
                response = lambda: None
                response.url = url
                response.status_code = 200

            if response.status_code >= 400:
                response = lambda: None
                response.url = url
                response.status_code = 200

        except:
            response = lambda: None
            response.url = url
            response.status_code = 200

        try:
            head_check_key = _get_domain(response.url)
        except:
            response.url = url
            head_check_key = _get_domain(url)

        redirect_url = self._check_redirect(head_check_key, response)
        if redirect_url:
            _head_checks[head_check_key] = redirect_url
            return self._head(redirect_url)

        _head_checks[head_check_key] = response.status_code == 200

        return response.url, response.status_code

    def head(self, url):
        # log("head url: %s" % url)
        return get(self._head, 12, url)

    def find_url(self, urls):
        for url in urls:
            (response_url, status_code) = self.head(url.base)
            if status_code != 200:
                continue

            if response_url.endswith("/"):
                response_url = response_url[:-1]

            return UrlParts(base=response_url, search=url.search, default_search=url.default_search)

        return None

    def get(self, url, headers={}, allow_redirects=True, cache_resp=cache_responce):
        """
        :useges:
        from openscrapers.modules.request import Request
        # initiate class
        request = Request(timeout=20)
        response = request.get(url, headers={"User-Agent": agent()}, cache_responce=True)
        # print("response['value']: {}".format(response['value']))

        :param url:
        :param headers:
        :param allow_redirects:
        :param cache_resp:
        :return:
        """
        parsed_url = urlparse(url)

        response = self.head(_get_domain(url))
        # log('self.head response: %s' % str(response))
        if response is None:
            return None

        (url, status_code) = response
        # log('url: %s status_code: %s' % (url, status_code))
        if status_code != 200:
            return None

        resolved_url = urlparse(url)
        url = urlunparse(
            (
                resolved_url.scheme,
                resolved_url.netloc,
                parsed_url.path,
                parsed_url.params,
                parsed_url.query,
                parsed_url.fragment,
            )
        )

        log('GET url: %s' % url)
        request = lambda x: _get(self._cfscrape, url, headers, self._timeout, allow_redirects, x)
        request.url = url
        self.cache_resp = cache_resp
        return self._request_core(request)

    def post(self, url, data, headers={}, cache_resp=cache_responce):
        log('POST url: %s' % url)
        request = lambda _: self._cfscrape.post(url, data, headers=headers, timeout=self._timeout)
        request.url = url
        self.cache_resp = cache_resp
        return self._request_core(request)


class TLSAdapter(adapters.HTTPAdapter):
    def init_poolmanager(self, connections, maxsize, block=False):
        ctx = ssl.create_default_context()
        ctx.set_ciphers('DEFAULT@SECLEVEL=1')
        self.poolmanager = urllib3.poolmanager.PoolManager(num_pools=connections,
                                                           maxsize=maxsize,
                                                           block=block,
                                                           ssl_version=ssl.PROTOCOL_TLSv1_2,
                                                           ssl_context=ctx)


def __retry(request, response, next, cfscrape, retry=0):
    if retry > 5:
        return None

    if response.status_code in [503, 429, 403]:
        if response.status_code == 503:
            time.sleep(2)
            retry = 5
        if response.status_code == 429:
            time.sleep(3)

        retry += 1
        request['validate'] = lambda response: __retry(request, response, next, cfscrape, retry)
        request['next'] = next
        request['cfscrape'] = cfscrape
        return request


def execute(request, session=None):
    request.setdefault('timeout')
    next = request.pop('next', None)
    cfscrape = 'cfscrape' in request
    request.pop('cfscrape', None)
    validate = request.pop('validate', None)
    if not validate:
        # print(f'0request: {repr(request)}')
        validate = lambda response: __retry(request, response, next, cfscrape)

    if next: request.pop('stream', None)

    # log('%s ^ - %s, %s' % (request['method'], request['url'], json.dumps(request.get('params', {}))))
    try:
        if cfscrape:
            request.pop('cfscrape', None)
            # print(f'1request: {repr(request)}')
            if not session: session = cloudscraper.create_scraper()
            response = session.request(**request)
        else:
            session = Session()
            session.mount('https://', TLSAdapter())
            response = session.request(**request)
        exc = ''
    except:  # pragma: no cover
        try:
            if cfscrape:
                # print(f'2request: {repr(request)}')
                if not session: session = cloudscraper.create_scraper()
                response = session.request(verify=False, **request)
            else: response = requests.request(verify=False, **request)
            exc = ''
        except:  # pragma: no cover
            exc = traceback.format_exc()
            response = lambda: None
            response.text = ''
            response.content = ''
            response.status_code = 500
            log('%s $ - %s - %s, %s' % (request['method'], request['url'], response.status_code, exc))

    alt_request = validate(response)
    if alt_request: return execute(alt_request)

    if next and response.status_code == 200:
        next_request = next(response)
        if next_request: return execute(next_request, session)
        else: return None
    return response


def r_request(url, method='GET', timeout=20, session=None, cfscrape=True):
    if '|' in url:
        headers = {}
        url, hdrs = url.split('|')
        hitems = hdrs.split('&')
        for hitem in hitems:
            hdr, value = hitem.split('=')
            headers.update({hdr: value})
    else:
        headers = {"User-Agent": random.choice(USER_AGENTS), }

    request = {'method': method,
               'url': url,
               'timeout': 10,
               'headers': headers,
               'cfscrape': cfscrape
               }
    return execute(request, session=session)
