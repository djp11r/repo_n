# -*- coding: utf-8 -*-

from sys import argv
from urllib.parse import parse_qsl
from openscrapers.sources_openscrapers import all_providers, hoster_providers

params = dict(parse_qsl(argv[2].replace('?', '')))
action = params.get('action')


if action is None:
	from openscrapers.modules.control import openSettings
	openSettings()
# if action == 'openscraperssettings':
	# from openscrapers.modules.control import openSettings
	# openSettings('0.0')
elif action == 'ShowChangelog':
	from openscrapers.modules import changelog
	changelog.get()
elif action == 'ShowHelp':
	from openscrapers.help import help
	help.get(params.get('name'))
elif action == 'Defaults':
	from openscrapers.modules.control import setProviderDefaults
	sourceList = []
	sourceList = all_providers
	setProviderDefaults()
	# for i in sourceList:
		# source_setting = f'provider.{i}'
		# value = getSettingDefault(source_setting)
		# setSetting(source_setting, value)
elif action == 'toggleAll':
	from openscrapers.modules.control import setSetting, homeWindow
	sourceList = []
	sourceList = all_providers
	homeWindow.setProperty('openscrapers_settings', 'false')
	for i in sourceList:
		source_setting = f'provider.{i}'
		setSetting(source_setting, params['setting'])
	homeWindow.setProperty('openscrapers_settings', 'true')
elif action == 'toggleAllHosters':
	from openscrapers.modules.control import setSetting, homeWindow
	sourceList = []
	sourceList = hoster_providers
	homeWindow.setProperty('openscrapers_settings', 'false')
	for i in sourceList:
		source_setting = f'provider.{i}'
		setSetting(source_setting, params['setting'])
	homeWindow.setProperty('openscrapers_settings', 'true')

# elif action == 'toggleAllTorrent':
	# sourceList = []
	# sourceList = sources_openscrapers.torrent_providers
	# for i in sourceList:
		# source_setting = f'provider.{i}'
		# setSetting(source_setting, params['setting'])
# elif action == 'toggleAllPackTorrent':
	# execute('RunPlugin(plugin://script.module.openscrapers/?action=toggleAllTorrent&amp;setting=false)')
	# sleep(500)
	# sourceList = []
	# from openscrapers import pack_sources
	# sourceList = pack_sources()
	# for i in sourceList:
		# source_setting = f'provider.{i}'
		# setSetting(source_setting, params['setting'])

elif action == 'cleanSettings':
	from openscrapers.modules.control import clean_settings
	clean_settings()
elif action == 'reset_url':
	from openscrapers.modules.control import set_default
	set_default()
elif action == 'reset_stats':
	from openscrapers.modules.control import notification
	from openscrapers import external_scrapers_reset_stats
	external_scrapers_reset_stats()
	notification(message='ReSet scrapers Stats')

elif action == 'get_m3ufor_iptv':
	from openscrapers.modules.m3u_merge_inone import generate_and_write_playlist_sync
	generate_and_write_playlist_sync()
elif action == 'updateuseragent':
	from openscrapers.modules.control import get_useragent, notification
	from openscrapers.modules import cache
	_useragent = get_useragent(True)
	cache.cache_insert('get_useragent', str(_useragent), 5)
	notification(message='Update UserAgent...')
elif action == 'undesirablesUserRemove':
	from openscrapers.modules.undesirables import undesirablesUserRemove
	undesirablesUserRemove()
elif action == 'undesirablesUserRemoveAll':
	from openscrapers.modules.undesirables import undesirablesUserRemoveAll
	undesirablesUserRemoveAll()

elif action == 'tools_resolveurl':
	from openscrapers.modules.control import openSettings, notification
	openSettings('0.0', "script.module.resolveurl")
	notification(message='clearing script.module.resolveurl')
elif action == 'tools_clearLogFile':
	from openscrapers.modules.control import notification
	from openscrapers.modules.log_utils import clear_logFile
	cleared = clear_logFile()
	if cleared == 'canceled': pass
	elif cleared: notification(message='openscrapers Log File Successfully Cleared')
	else: notification(message='Error clearing openscrapers Log File, see kodi.log for more info')
elif action == 'tools_viewLogFile':
	from openscrapers.modules.log_utils import view_LogFile
	view_LogFile()
elif action == 'tools_uploadLogFile':
	from openscrapers.modules.log_utils import upload_LogFile
	upload_LogFile()
elif action == 'tmdb_author':
	from openscrapers.modules.tmdb_utils import tmdb_list_api
	# tmdb_author()
	tmdb_list_api.auth()
elif action == 'tmdb_deauthor':
	from openscrapers.modules.tmdb_utils import tmdb_list_api
	# deauthorize()
	tmdb_list_api.revoke()
elif action == 'tmdb_get_session_id':
	from openscrapers.modules.tmdb_utils import tmdb_list_api
	tmdb_list_api.get_session_id()
# elif action == 'toggleAllPaid':
	# sourceList = []
	# sourceList = sources_openscrapers.all_paid_providers
	# for i in sourceList:
		# source_setting = f'provider.{i}'
		# setSetting(source_setting, params['setting'])
	# xbmc.log('All Paid providers = %s' % sourceList,2)
	# sleep(200)
	# openSettings(query)
# elif action == 'toggleAllDebrid':
	# sourceList = []
	# sourceList = sources_openscrapers.debrid_providers
	# for i in sourceList:
		# source_setting = f'provider.{i}'
		# setSetting(source_setting, params['setting'])
# elif action == 'plexAuth':
	# from openscrapers.modules import plex
	# plex.Plex().auth()
# elif action == 'plexRevoke':
	# from openscrapers.modules import plex
	# plex.Plex().revoke()
# elif action == 'plexSelectShare':
	# from openscrapers.modules import plex
	# plex.Plex().get_plexshare_resource()

# elif action == 'ShowOKDialog':
	# okDialog(params.get('title', 'default'), int(params.get('message', '')))


elif action == 'traktAcct':
	from openscrapers.modules.trakt import account_info_to_dialog
	account_info_to_dialog()
elif action == 'traktAuth':
	from openscrapers.modules.trakt import authTrakt
	authTrakt()
elif action == 'traktRevoke':
	from openscrapers.modules.trakt import revoke
	revoke(1)

elif action == 'action_test_func':
	from openscrapers import action_test_func
	action_test_func()