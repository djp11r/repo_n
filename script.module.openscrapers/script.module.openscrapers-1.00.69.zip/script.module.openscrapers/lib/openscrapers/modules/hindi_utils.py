# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional
from pathlib import Path

try:
    from openscrapers import quote_plus, urlencode, urljoin, urlparse, testing
    from openscrapers.modules.client import request, agent, get_page_server, scrapePage, refresh_redirect
    from openscrapers.modules.log_utils import log, error
    from openscrapers.modules.client_utils import get_jsunpack_unjuice, replaceHTMLCodes
    from openscrapers.modules.dom_parser import parseDOM
    from openscrapers.modules.utils import get_datetime, get_findall
    from openscrapers.modules.tmdb_utils import tmdb_search
except:
    import os, sys

    from modules.client import request, agent, get_page_server, scrapePage, refresh_redirect
    from modules.client_utils import get_jsunpack_unjuice, replaceHTMLCodes
    from modules.dom_parser import parseDOM
    from modules.utils import get_datetime, get_findall
    from modules.tmdb_utils import tmdb_search
    nextpage = 'https://i.imgur.com/onBTdVr.png'
    testing = True
    log = error = print


RULES_FILE = Path("special://profile/addon_data/plugin.video.infinite/query_rules.json")
LOG_FILE   = Path("special://profile/addon_data/plugin.video.infinite/query_learning.log")

extract_date = re.compile(
    r'(\d{1,2}(?:th|st|nd|rd)?\s+'
    r'(?:Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|Aug|August|'
    r'Sep|September|Oct|October|Nov|November|Dec|December)\s+\d{2,4})',
    flags=re.I,) # date like 18th April 2021
extract_episode = re.compile(r'Episode\s+\d{1,2}', flags=re.I)
season_data = re.compile(
    r'season.+?(\d{1,2})|season(\d{1,2})|s(\d{1,2})',
    flags=re.I,) # remove season 12 or s1 etc
episode_cleaner = re.compile(r'Watch Online|Video Episode Update Online|-', flags=re.I)
episode_data = re.compile(
    r'episodes.+?(\d+)|ep\s*(\d+)|e(\d+)',
    flags=re.I,) # episod 12, e12  etc
ansi_pattern = re.compile(
    r'(\x9B|\x1B\[)[0-?]*[ -/]*[@-~]|[^\x00-\x7f]',
    flags=re.I,
) # ansi_pattern # ansi_pattern1 = re.compile(r'[^\x00-\x7f]', flags=re.I)  # ansi_pattern
multiple_spaces = re.compile(r'\s+', flags=re.I) # Multiple Spaces
monthdict = {'January': '01', 'February': '02', 'March': '03', 'April': '04', 'May': '05', 'June': '06', 'July': '07', 'August': '08', 'September': '09', 'October': '10', 'November': '11', 'December': '12'}

#  PRE‑COMPILED REGEX (massive speed improvement)
RE_VIDEO_ID = re.compile(r'(id|url|v|si|sin|sim|data-config|file|dm|wat|vid)=(.+?)##')
RE_META_REFRESH = re.compile(r'''<meta[^>]*?[refresh|]*?url=(.*?)["']''', re.I)
RE_IFRAME_SRC = re.compile(r'''(?:iframe|source).+?(?:src|file)\s*["']?\s*[:=,]?\s*["']([^"']+)''', re.I)

NON_STR = {'olangal.', 'desihome.', 'thiruttuvcd', '.filmlinks4u', '#', '/t.me/',
    'cineview', 'bollyheaven', 'videolinkz', 'moviefk.co', 'goo.gl', '/ads/',
    'imdb.', 'mgid.', 'atemda.', 'movierulz.ht', 'facebook.', 'twitter.',
    'm2pub', 'abcmalayalam', 'india4movie.co', 'embedupload.', 'bit.ly',
    'tamilraja.', 'multiup.', 'filesupload.', 'fileorbs.', 'tamil.ws',
    'insurance-donate.', '.blogspot.', 'yodesi.net', 'desi-tashan.',
    'yomasti.co/ads', 'ads.yodesi', 'mylifeads.', 'yaartv.', '/cdn-cgi/',
    'steepto.', '/movierulztv', '/email-protection', 'oneload.xyz', 'about:',
    'tvnation.me/drive.php?', 'p2p.drivewires', 'tvcine.me', '/ad', 'tvnation.me/include', 'drivewire.xyz', 'magnet:',
    'google.com', 'whatsapp.com', 'linkedin.com'}

FILTER_ITEMS = {
    'dailymotion', 'vup', 'streamtape', 'vidoza', 'mixdrop', 'mystream',
    'doodstream', 'watchvideo', 'vkprime', 'vkspeed'
}
REMOVE_ADS_JS = {'.js', '.jpg', 'adv1/', 'ads.', '.ads', '/ad', '/ads/'}

EMBED_LIST = {'cineview', 'bollyheaven', 'videolinkz', 'vidzcode', 'escr.',
    'embedzone', 'embedsr', 'fullmovie-hd', 'links4.pw', 'esr.',
    'embedscr', 'embedrip', 'movembed', 'power4link.us', 'adly.biz',
    'watchmoviesonline4u', 'nobuffer.info', 'yomasti.co', 'hd-rulez.',
    'techking.me', 'onlinemoviesworld.xyz', 'cinebix.com', 'vids.xyz',
    'desihome.', 'loan-', 'filmshowonline.', 'hinditwostop.', 'media.php',
    'hindistoponline', 'telly-news.', 'tellytimes.', 'tellynews.', 'tvcine.',
    'business-', 'businessvoip.', 'toptencar.', 'serialinsurance.',
    'youpdates', 'loanadvisor.', 'tamilray.', 'embedrip.', 'xpressvids.',
    'beststopapne.', 'bestinforoom.', '?trembed=', 'tamilserene.',
    'tvnation.', 'techking.', 'etcscrs.', 'etcsr1.', 'etcrips.', 'etcsrs.',
    'tvpost.cc', 'tellygossips.', 'tvarticles.', 'insurancehubportal.',
    'directlinktx.', 'filmstream2x.com', 'watchlinksinfo.com',
    'videoemx2.com', 'movierulz.io', 'coinztechnews.', 'thegadgetsreviewer.', 'post.php?id='}

APNE_EMBED = {'newstalks.co', 'newstrendz.co', 'newscurrent.co', 'newsdeskroom.co',
    'newsapne.co', 'newshook.co', 'newsbaba.co', 'articlesnewz.com',
    'articlesnew.com', 'webnewsarticles.com', 'htnews.me', 'gamewisetalks.com'}
streamer_list = {'tamilgun', 'mersalaayitten', 'mhdtvworld.', '/hls/', 'poovee.',
    'watchtamiltv.', 'cloudspro.', 'abroadindia.', 'nextvnow.', 'harpalgeo.',
    'hindilyrics4u.', '.mp4', 'googlevideo.', 'playembed.', 'akamaihd.',
    'tamilhdtv.', 'andhrawatch.', 'tamiltv.', 'athavantv', 'cinemalayalam',
    'justmoviesonline.', '.mp3', 'googleapis.', '.m3u8', 'telugunxt.',
    'playallu.', 'bharat-movies.', 'googleusercontent.', 'arydigital.',
    'space-cdn.', 'einthusan.', 'd0stream.', 'telugugold.', '.xdiv.',
    'hum.tv', 'apnevideotwo.', 'player.business', 'tamilian.'}

ARTICLE_EMBED = {'articleweb.', 'serialghar.', 'tvarticles.', 'bollyfunmaza.'}


def find_season_in_title(release_title: str) -> int:
    """
    Extracts season number from messy titles like:
    'Season 2', 'Season.02', 'S02', 'S.2', 'Chapter 3', 'Show Name 4', '4x01'
    Falls back to 1 if nothing meaningful is found.
    """
    if not release_title: return 1
    t = release_title.lower().strip()
    # Remove 4‑digit years ONLY when they look like years
    t = re.sub(r"\b(19|20)\d{2}\b", "", t)
    # 1. Strong patterns (Season 2, Season.02)
    m = re.search(r"season[\s.]*([0-9]{1,2})", t)
    if m: return int(m.group(1).lstrip("0") or "0")
    # 2. S02, S.02, S2
    m = re.search(r"\bs[.\s]*([0-9]{1,2})\b", t)
    if m: return int(m.group(1).lstrip("0") or "0")
    # 3. Chapter 3, Chapter.03
    m = re.search(r"chapter[\s.]*([0-9]{1,2})", t)
    if m: return int(m.group(1).lstrip("0") or "0")
    # 4. 4x01, 3.x, 10x2
    m = re.search(r"\b([0-9]{1,2})x[0-9]{1,2}\b", t)
    if m: return int(m.group(1).lstrip("0") or "0")
    # 5. Trailing standalone number (Show Name 4)
    m = re.search(r"(\d{1,2})\b", t)
    if m: return int(m.group(1).lstrip("0") or "0")
    # Default
    return 1


def get_episode_date(name, title=''):
    episode_name = xname = ''
    xname = re.sub(episode_cleaner, '', name)
    xname = xname.replace(title, '').replace('  ', ' ')
    try:
        episode_name = extract_date.findall(xname)[0]
        episode_name = re.sub(r'(\w)([A-Z])', r'\1 \2', episode_name)
    except: episode_name = extract_episode.findall(xname)
    if isinstance(episode_name, list):
        try: episode_name = episode_name[0]
        except: episode_name = ''
    if episode_name == '': episode_name = re.sub(r'(\w)([A-Z])', r'\1 \2', xname)
    return episode_name.strip()


def get_ch_name(ch_name: str) -> str:
    if not ch_name: return ""
    name = ch_name.lower().strip()
    # Ordered rules (first match wins)
    RULES = [
        ("sony",        "sony-tv"),
        ("sab tv",      "sab-tv"),
        ("sab",         "sab-tv"),
        ("colors",      "colors"),
        ("zee",         "zee-tv"),
        ("star plus",   "star-plus"),
        ("star",        "star-plus"),
    ]
    for key, out in RULES:
        if key in name:
            return out
    # Fallback: normalize to slug
    return re.sub(r"\s+", "-", name)



def host(url):
    if isinstance(url, bytes): url = url.decode('utf-8')
    host = get_findall(r'([\w]+[.][\w]+)$', urlparse(url.strip().lower()).netloc)[0]
    return str(host.split('.')[0])


def get_source_dict(urls, sources, ihost=None, direct=False):
    # log(f'get_source_dict urls: {urls}')
    if isinstance(urls, str): urls = [urls]
    if any(x in str(urls) for x in REMOVE_ADS_JS): return sources
    if ihost is None: ihost = host(urls[0])
    # if re.search(r'speed|vkprime', urls[0], re.I): ihost = 'speed|vkprime'
    # log(f'ihost {ihost} len(urls) {len(urls)} type of urls {type(urls)}')
    for i in range(len(urls)):
        # if any(get_findall(r'speed|vkprime|business-loans.pw|bestarticles|tvnation.me', urls[i])):
        try:
            vid_url = str(urls[i])
            if any(x in vid_url.lower() for x in ['vkspeed', 'vkprime']): urls[i] = iurl if (iurl := get_mod_url(vid_url)) else None
            # if re.search(r'vkspeed|vkprime', vid_url, re.I): urls[i] = iurl if (iurl := get_mod_url(vid_url)) else None
            # log(f'In urls[i]: {vid_url}')
            if len(urls) > 1 and any(x in vid_url.lower() for x in ['vkspeed', 'vkprime']): #(re.search(r'vkspeed|vkprime', vid_url, re.I)):
                for j, ji in enumerate(urls, start=1):
                    if ji not in str(sources): sources.append({'source': ihost, 'quality': '720p', 'info': f'Part:{j}', 'url': ji, 'direct': False})
        except: error(f'Error i: {i} from: {__name__}: ')

    if len(urls) > 1: unfo, url = f'All parts: {len(urls)}', ' , '.join(urls)
    else: unfo, url = 'All part: Single', urls[0]
    sources.append({'source': ihost, 'quality': '720p', 'info': unfo, 'url': url, 'direct': direct})
    return sources


def query_cleaner(query: str) -> str:
    if not query: return ""
    q = query.lower()
    q = q.replace("’", "").replace("'", "") # Normalize apostrophes and punctuation
    q = re.sub(r"[.\s:]+", "-", q) # Replace separators with hyphens
    q = re.sub(r"-{2,}", "-", q) # Collapse multiple hyphens
    return q.strip("-") # Strip leading/trailing hyphens


def get_query(title: str, s: int | str) -> str:
    q = query_cleaner(title)
    # Ordered rules: first match wins
    RULES = [
        ("superstar-singer",            lambda s: f"superstar-singer-{s}"),
        ("indias-best-dancer-vs-super-dancer", lambda s: "indias-best-dancer-vs-super-dancer"),
        ("dance-deewane",               lambda s: f"dance-deewane-{s}"),
        ("india-got-talent",            lambda s: f"india-got-talent-season-{s}"),
        ("jhalak-dikhhla-jaa",          lambda s: f"jhalak-dikhhla-jaa-season-{s}"),
        ("indias-best-dancer",          lambda s: f"indias-best-dancer-{s}"),
        ("kaun-banega-crorepati",       lambda s: f"kaun-banega-crorepati-{s}"),
        ("bigg-boss-ott",               lambda s: f"bigg-boss-ott-{s}"),
        ("bigg-boss",                   lambda s: f"bigg-boss-{s}"),
        ("indian-idol",                 lambda s: f"indian-idol-{s}"),
        ("khatron-ke-khiladi",          lambda s: f"khatron-ke-khiladi-{s}"),
        ("the-kapil-sharma-show",       lambda s: f"the-kapil-sharma-show-season-{s}"),
    ]

    for key, builder in RULES:
        if key in q:
            return builder(s)
    return q


def log_learning(event: str, data: dict):
    """Structured JSON log for learning events."""
    try:
        entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "event": event,
            "data": data}
        LOG_FILE.write_text(
            LOG_FILE.read_text() + json.dumps(entry) + "\n"
            if LOG_FILE.exists()
            else json.dumps(entry) + "\n")
    except Exception: pass


class QueryRuleEngine:
    '''
    engine = QueryRuleEngine()
    query = engine.get(title, season)
    '''
    def __init__(self):
        self.rules = self._load_rules()

    # Load / Save
    def _load_rules(self):
        try:
            if RULES_FILE.exists(): return json.loads(RULES_FILE.read_text())
        except Exception: pass
        return {}

    def _save_rules(self):
        try: RULES_FILE.write_text(json.dumps(self.rules, indent=2))
        except Exception: pass

    # Public API
    def get(self, title: str, season: str | int) -> str:
        q = query_cleaner(title)

        # 1. Learned rules first
        for key, pattern in self.rules.items():
            if key in q:
                out = pattern.replace("{s}", str(season))
                log_learning("rule_applied", {
                    "matched_key": key,
                    "pattern": pattern,
                    "output": out,
                    "input_title": title,
                    "cleaned_query": q
                })
                return out

        # 2. Built‑in rules
        out = self._builtin_rules(q, season)
        if out != q:
            # Learn this new rule
            self.learn(q, out, title)
        return out

    # Auto‑learning
    def learn(self, cleaned_query: str, output: str, original_title: str):
        """
        cleaned_query: "bigg-boss"
        output: "bigg-boss-17"
        stored rule: {"bigg-boss": "bigg-boss-{s}"}
        """
        pattern = re.sub(r"\d+$", "{s}", output)

        if "{s}" not in pattern:
            log_learning("learning_skipped", {
                "reason": "no_season_placeholder",
                "cleaned_query": cleaned_query,
                "output": output,
                "original_title": original_title
            })
            return

        # Save rule
        self.rules[cleaned_query] = pattern
        self._save_rules()
        log_learning("rule_learned", {
            "cleaned_query": cleaned_query,
            "pattern": pattern,
            "output": output,
            "original_title": original_title
        })

    # Built‑in rules (fallback)
    def _builtin_rules(self, q: str, s: int | str) -> str:
        RULES = [
            ("superstar-singer",            lambda s: f"superstar-singer-{s}"),
            ("indias-best-dancer-vs-super-dancer", lambda s: "indias-best-dancer-vs-super-dancer"),
            ("dance-deewane",               lambda s: f"dance-deewane-{s}"),
            ("india-got-talent",            lambda s: f"india-got-talent-season-{s}"),
            ("jhalak-dikhhla-jaa",          lambda s: f"jhalak-dikhhla-jaa-season-{s}"),
            ("indias-best-dancer",          lambda s: f"indias-best-dancer-{s}"),
            ("kaun-banega-crorepati",       lambda s: f"kaun-banega-crorepati-{s}"),
            ("bigg-boss-ott",               lambda s: f"bigg-boss-ott-{s}"),
            ("bigg-boss",                   lambda s: f"bigg-boss-{s}"),
            ("indian-idol",                 lambda s: f"indian-idol-{s}"),
            ("khatron-ke-khiladi",          lambda s: f"khatron-ke-khiladi-{s}"),
            ("the-kapil-sharma-show",       lambda s: f"the-kapil-sharma-show-season-{s}"),
        ]

        for key, builder in RULES:
            if key in q:
                return builder(s)
        return q


def get_int_epi(episode: str):
    """
    Extracts (season_code, year) from episode strings like:
    '12th March 2023', '1st Jan 24', '5th Aug 2022', etc.
    Falls back to episode number + current year.
    """

    if not episode: return 0, str(get_datetime().year)

    text = episode.strip()

    # Match patterns like "12th March 2023" or "1st Jan 24"
    m = re.search(
        r"(?P<day>\d{1,2})(?:st|nd|rd|th)\s*"
        r"(?P<month>[A-Za-z]+)\s*"
        r"(?P<year>\d{2,4})",
        text,
        flags=re.I
    )

    if m:
        day = m.group("day").zfill(2)
        month_name = m.group("month").lower()
        year = m.group("year")
        # Normalize 2‑digit years → 4‑digit
        if len(year) == 2: year = f"20{year}"
        # Lookup month number
        month_num = monthdict.get(month_name)
        # If month not recognized, fallback to day only
        season_code = day if month_num is None else f"{month_num}{day}"
        return season_code, year

    # Fallback: extract episode number
    ep = re.search(r"\d{1,2}", text)
    ep_no = ep.group() if ep else "0"
    return ep_no, str(get_datetime().year)

def string_date_to_num(string):
    # date_str = re.search(r'(\d{1,2}(st|nd|rd|th))(.*?)(\d{2,4})', string).group()
    if date_str := re.search(extract_date, string):
        date_str = date_str.group()
        month = monthdict.get(date_str.split(' ')[1])
        # d = re.search(r'^\d+(st|nd|rd|th)', date_str).group()
        # day = re.sub(r'(st|nd|rd|th)', '', d)
        day = re.search(r'^\d{1,2}', date_str).group()
        year = re.search(r'\d{4}$', date_str).group()
        return f'{year}-{month:0>2}-{day:0>2}'
    else: return get_datetime(True)

def convert_youtube_duration_to_minutes(duration: str) -> int:
    """
    Convert ISO‑8601 YouTube duration (e.g., 'PT2H12M51S', 'P2DT1S') to total minutes.
    """
    if not duration or not duration.startswith("P"): return 0
    # Default values
    days = hours = minutes = 0
    seconds = 1
    # Extract day part: P2D
    m = re.search(r"(\d+)D", duration)
    if m: days = int(m.group(1)) * 86400
    # Extract hour part: T2H
    m = re.search(r"(\d+)H", duration)
    if m: hours = int(m.group(1)) * 3600
    # Extract minute part: 12M
    m = re.search(r"(\d+)M", duration)
    if m: minutes = int(m.group(1)) * 60
    # Extract seconds part: 51S
    m = re.search(r"(\d+)S", duration)
    if m: seconds = int(m.group(1))
    total_seconds = (days + hours + minutes + seconds)
    return total_seconds // 60


# Precompile multi-space pattern
MULTI_SPACE = re.compile(r"\s+")
# Translation table for single-character replacements
_TRANSLATE_TABLE = str.maketrans({
    "–": "-", "—": "-", "…": " ", "’": "'", "“": '"', "”": '"',
    "'": "",  # remove apostrophes
    ":": "",  # remove colons
})
# Regex for multi-character HTML entities & sequences
_HTML_UNICODE_PATTERN = re.compile(r"&#8211;|&#8217;|&#8230;|&#38;|&amp;|&Amp;|&lt;|&gt;|&nbsp;|&quot;|\.{3}|-{2,}")
_HTML_UNICODE_MAP = {"&#8211;": "-", "&#8217;": "'", "&#8230;": " ", "&#38;": "&", "&amp;": "&", "&Amp;": "&", "&lt;": "<", "&gt;": ">", "&nbsp;": " ", "&quot;": '"', "...": "",}

def additional_title_cleaner(title: str) -> str:
    if not title: return ""
    t = str(title)
    # 1. Multi-token replacements (regex sweep)
    t = _HTML_UNICODE_PATTERN.sub(lambda m: _HTML_UNICODE_MAP[m.group(0)], t)
    # 2. Single-character replacements (translation table)
    t = t.translate(_TRANSLATE_TABLE)
    t = "-".join(part for part in t.split("-") if part != "") # collapse --- dashes to one -
    # 3. Collapse whitespace
    t = MULTI_SPACE.sub(" ", t)
    return t.strip()

# Precompile heavy patterns once
REMOVE_BRACKETS_TAGS = re.compile(
    r"<[^>]*>|"          # HTML tags
    r"\([^)]*\)|"        # ( ... )
    r"\[[^\]]*]|"        # [ ... ]
    r"\{[^}]*}"          # { ... }
)
PUNCTUATION_CLEAN = re.compile(r'[:;\-"\',!_.?~$@]')
TRAILING_DOT_ZERO = re.compile(r"(?<=\d)\.0\b")

def keepclean_title(title: str, episod: bool = False) -> str:
    """
    Fully normalized title cleaner for Python 3.14.
    Removes dates, episode numbers, HTML, punctuation, Unicode noise,
    ANSI escapes, bracketed text, and normalizes whitespace.
    """
    if not title: return ""
    t = str(title).strip()
    # 1. Remove trailing .0
    t = TRAILING_DOT_ZERO.sub("", t)
    # 2. Replace colon with space (Kodi-safe)
    t = t.replace(":", " ")
    # 3. Remove dates + episode numbers
    if not episod:
        t = re.sub(extract_date, "", t)
        t = re.sub(episode_data, "", t)
    # 4. Remove ANSI + non-ASCII noise
    t = re.sub(ansi_pattern, "", t)
    # 5. Fix malformed HTML entities
    t = re.sub(r"&#(\d+);", "", t)
    t = re.sub(r"(&#[0-9]+)([^;0-9]+)", r"\1;\2", t)
    # 6. Remove HTML tags + all bracketed text
    t = REMOVE_BRACKETS_TAGS.sub("", t)
    # 7. Remove punctuation
    t = PUNCTUATION_CLEAN.sub(" ", t)
    # 8. Custom cleaner hook (optimized)
    t = additional_title_cleaner(t)
    # 9. Normalize unicode & spacing
    t = replaceHTMLCodes(t)
    # 10. Final whitespace collapse
    t = MULTI_SPACE.sub(" ", t)
    return t.strip()


def ordinal(n: int) -> str:
    s = str(n)
    # Handle negative numbers by stripping sign, applying rule, then restoring sign
    sign = "-" if s.startswith("-") else ""
    num = abs(n)
    # Special case: 11th, 12th, 13th
    if 10 <= num % 100 <= 13: suffix = "th"
    else:
        last = num % 10
        if last == 1: suffix = "st"
        elif last == 2: suffix = "nd"
        elif last == 3: suffix = "rd"
        else: suffix = "th"
    return f"{sign}{num}{suffix}"


def get_next_hepisode(meta):
    from datetime import datetime, timedelta
    e_name = meta.get('ep_name', meta['title'])
    if 'Episode' in e_name:
        e_name = int(e_name.replace('Episode', ''))
        n_ep = e_name + 1
        n_ep_name = f'Episode {n_ep}'
        url = meta['url']
        n_url = url.replace(f'episode-{e_name}', f'episode-{n_ep}')
        meta.update({'ep_name': n_ep_name, 'episode': f'{n_ep}', 'url': n_url})
    else:
        e_name = e_name.replace(' ', '-').lower()
        premiered = meta['premiered']
        current_episode = datetime.strptime(premiered, "%Y-%m-%d")
        # calculating end date by adding 1 day
        Enddate = current_episode + timedelta(days=1)
        day = Enddate.strftime('%d')
        month = Enddate.strftime('%m')
        year = Enddate.strftime('%Y')
        n_premiered = f'{year}-{month}-{day}'
        n_episode = f'{month.lstrip("0")}{day}'
        day = ordinal(int(day.lstrip("0")))
        mont = Enddate.strftime('%B')
        n_ep_name = f'{day} {mont} {year}'
        next_ep_name = n_ep_name.replace(' ', '-').lower()
        url = meta['url']
        n_url = url.replace(e_name, next_ep_name)
        meta.update({'ep_name': n_ep_name, 'episode': n_episode, 'premiered': n_premiered, 'url': n_url})
    # log(f'updated meta: {repr(meta)}')
    return meta


def get_script_json(result: str):
    """
    Extracts JSON from <script id="__NEXT_DATA__">...</script>
    Handles undefined, new Date(), malformed HTML, and stray JS.
    """

    def replace_quotes(match):
        inner = match.group(1)
        inner = inner.replace('"', r'\"')
        return f"\"{inner}\""

    if not result: return "Error: Empty HTML"
    # Extract script tag content
    scripts = parseDOM(result, "script", attrs={"id": "__NEXT_DATA__"})
    if not scripts: return "Error: No __NEXT_DATA__ script found"
    raw = scripts[0].strip()
    # 1. Extract JSON block safely
    # Find the FIRST '{' and the LAST '}' — but validate structure
    start = raw.find("{")
    end = raw.rfind("}")

    if start == -1 or end == -1 or end <= start:
        return "Error: JSON block not found"

    json_str = raw[start:end + 1]
    # 2. Normalize JS → valid JSON
    # Replace undefined → null
    json_str = re.sub(r"\bundefined\b", "null", json_str)
    # Replace JS Date constructors → quoted strings
    json_str = re.sub(
        r"new\s+Date\((.*?)\)",
        replace_quotes,
        json_str
    )
    # Replace read Date(...) → quoted
    json_str = re.sub(
        r"read\s+Date\((.*?)\)",
        replace_quotes,
        json_str
    )
    # Remove trailing commas inside objects/arrays
    json_str = re.sub(r",\s*([}\]])", r"\1", json_str)
    # 3. Parse JSON
    try:
        return json.loads(json_str)
    except Exception as e:
        return f"JSON parse error: {type(e).__name__}"

def normalize_js_to_json(text: str) -> str:
    """
    Convert messy JS-like objects into valid JSON:
    - Handles constructors: Date, ObjectId, Number, String, Boolean, BigInt, RegExp, Map, Set
    - Normalizes literals: undefined, NaN, Infinity
    - Removes JS comments
    - Converts single quotes → double quotes
    - Quotes unquoted keys
    - Removes trailing commas
    useges:
    sanitized = normalize_js_to_json(raw_js_like)
    data = json.loads(sanitized)
    """
    if not text: return ""
    t = text
    # 1) Remove JS comments
    # t = re.sub(r"//.*?$", "", t, flags=re.M)
    # t = re.sub(r"/\*.*?\*/", "", t, flags=re.S)
    # Remove JS comments
    t = re.sub(r"//.*?$|/\*.*?\*/", "", t, flags=re.M | re.S)
    # 2) Normalize JS literals
    t = re.sub(r"\bundefined\b", "null", t)
    t = re.sub(r"\bNaN\b", "null", t)
    t = re.sub(r"\b-?Infinity\b", "null", t)
    # Replace new Date(...) → "Date(...)"
    t = re.sub(r"new\s+Date\((.*?)\)", lambda m: f"\"Date({m.group(1)})\"", t)
    # 3) Constructors → JSON-friendly new Date("...") / Date("...") → "..."
    t = re.sub(r"new\s+Date\(\"([^\"]*)\"\)", r'"\1"', t)
    t = re.sub(r"\bDate\(\"([^\"]*)\"\)", r'"\1"', t)
    # ObjectId("...") → "..."
    t = re.sub(r"ObjectId\(\"([^\"]*)\"\)", r'"\1"', t)
    # Number(123) → 123
    t = re.sub(r"\bNumber\(([^)]+)\)", r"\1", t)
    # String("abc") → "abc"
    t = re.sub(r"\bString\(\"([^\"]*)\"\)", r'"\1"', t)
    # Boolean(true/false) → true/false
    # t = re.sub(r"\bBoolean\((true|false)\)", r"\1", t)
    # true/false/null → True/False/None
    t = re.sub(r"\btrue\b", "True", t)
    t = re.sub(r"\bfalse\b", "False", t)
    t = re.sub(r"\bnull\b", "None", t)
    # BigInt(123) → 123
    t = re.sub(r"\bBigInt\(([^)]+)\)", r"\1", t)
    # RegExp("pattern") → "pattern"
    t = re.sub(r"\bRegExp\(\"([^\"]*)\"[^)]*\)", r'"\1"', t)
    # Map([...]) / Set([...]) → [...]
    t = re.sub(r"\bMap\((\[[^)]*])\)", r"\1", t)
    # Set([...]) → [...]
    t = re.sub(r"\bSet\((\[[^)]*])\)", r"\1", t)
    # 4) Single quotes → double quotes (best-effort)
    t = re.sub(r"'", r'"', t)
    # 5) Quote unquoted object keys: {foo: 1} → {"foo": 1}  t = re.sub(r"(\{|,)\s*([A-Za-z_][A-Za-z0-9_]*)\s*:", r'\1 "\2":', t)
    t = re.sub(r"([,{])\s*([A-Za-z_][A-Za-z0-9_]*)\s*:", r'\1 "\2":', t)
    # Add quotes around unquoted keys: key: → "key":
    #t = re.sub(r'(?<!")(\b[a-zA-Z0-9_]+\b)\s*:', r'"\1":', t)
    # 6) Remove trailing commas in objects/arrays
    t = re.sub(r",\s*([}\]])", r"\1", t)
    return t


def extract_any_json_like_block(html: str) -> list[dict]:
    """
    Extract ANY JSON-like block from HTML or JS:
    - Handles <script> tags
    - Handles JS variables (window.__data = {...})
    - Handles hydration blocks
    - Handles malformed JSON
    - Returns a list of parsed JSON objects
    """

    if not html: return []
    blocks = []
    # 1. Extract all <script> contents
    scripts = parseDOM(html, "script")
    script_texts = [s.strip() for s in scripts if s.strip()]
    # Also include raw HTML (for inline JSON)
    script_texts.append(html)
    # 2. Regex to find ANY {...} or [...] block
    # This finds nested JSON-like structures
    json_like_pattern = r"(\{(?:[^{}]|(?1))*\}|\[(?:[^\[\]]|(?1))*\])"
    for text in script_texts:
        for match in re.finditer(json_like_pattern, text, flags=re.S):
            raw_block = match.group(0)
            # Normalize JS → JSON
            normalized = normalize_js_to_json(raw_block)
            # Try parsing
            try:
                parsed = json.loads(normalized)
                blocks.append(parsed)
            except Exception:
                continue
    return blocks


def get_m3ulist(list_type):
    from openscrapers.modules.utils import decode
    gapp_url = 'w4nCqMOfw4PDlsKswpDCn8OYw5XDpcOKwqTDn8KBw4rDocOQw5fDkcOXwqHDhMKjw5jCgsOQw5PDhMOiw5TDpcKiw5RjwqzCnsOJw6vDhMOSw57DrMOpwrDCgcOSwoDCr8OgwrfCscOTwrnDmcKuwpvDlcK8w5HCu8K7w5TDl8KjwqrDhMKWwp3Ci8OWwqLCmMOJwpLDhcKnw4bCpcK/wpnCpsOZwqLDmcKpw5/DncKmbcK4wrbCpsOowo7Dm8OLw4XDmsKOwonDmcOBw4jDhMOTw4DClMOXw6vDhsKXwqo='
    # list_type = "plex" ,
    url = decode(gapp_url)
    link = f'{url}region=us&service={list_type}'
    data = request(link)

# Data model

@dataclass(slots=True)
class MetadataModel:
    __dataclass_fields__ = None
    mediatype: str
    title: str
    year: int
    plot: str
    studio: List[str]
    poster: str = ""
    homepage: str = ""
    genre: List[str] = field(default_factory=list)
    cast: List[Dict[str, Any]] = field(default_factory=list)
    tmdb_id: str = ""
    imdb_id: str = ""
    tvdb_id: str = ""
    rating: float = 0.0
    duration: int = 0
    mpaa: str = ""

    season: Optional[int] = None
    episode: Optional[int] = None
    total_aired_eps: Optional[int] = None
    seasons: Optional[int] = None
    tvshowtitle: Optional[str] = None

    clearlogo: str = ""
    trailer: str = ""
    votes: int = 50
    tagline: str = ""

    director: List[str] = field(default_factory=list)
    writer: List[str] = field(default_factory=list)

    # This field is NOT in slots, so we must allow it explicitly
    _extra_fields: Dict[str, Any] = field(default_factory=dict, repr=False)

    # dict‑style access support
    def __getitem__(self, key):
        if key in self.__dataclass_fields__:
            return getattr(self, key)
        return self._extra_fields.get(key)

    def __setitem__(self, key, value):
        if key in self.__dataclass_fields__:
            setattr(self, key, value)
        else:
            self._extra_fields[key] = value

    # from_dict normalizer
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MetadataModel":
        # Normalize aliases
        if "episodes" in data and "episode" not in data:
            data["episode"] = data.pop("episodes")

        if "imdbnumber" in data and "imdb_id" not in data:
            data["imdb_id"] = data["imdbnumber"]

        # Defaults for list fields
        data.setdefault("cast", [{"role": "", "name": "", "thumbnail": ""}])
        data.setdefault("studio", [])
        data.setdefault("genre", [])
        data.setdefault("director", [])
        data.setdefault("writer", [])

        # Allowed fields = dataclass fields
        allowed = cls.__dataclass_fields__.keys()

        clean = {}
        extra = {}

        for k, v in data.items():
            if k in allowed:
                clean[k] = v
            else:
                extra[k] = v

        obj = cls(**clean)
        obj._extra_fields = extra
        return obj

    def to_dict(self) -> Dict[str, Any]:
        """
        Export all known fields + extra fields into a normal Python dict.
        Works with slots=True and preserves nested structures.
        """
        out = {}
        # Export dataclass fields
        for name in self.__dataclass_fields__:
            if name == "_extra_fields":
                continue
            out[name] = getattr(self, name)
        # Merge extra fields
        out.update(self._extra_fields)
        return out

# IMDb client

class IMDbClient:
    def __init__(self, api_key: str = "56044779") -> None:
        self.api_key = api_key

    # ---------- public API ----------

    def search_id(self, title: str, media_type: str) -> Optional[str]:
        media_type = "movie" if media_type == "movie" else "series"
        clean_title = clean_title_for_imdb_search(title)
        url = f"http://www.omdbapi.com/?apikey={self.api_key}&s={quote_plus(clean_title)}"
        result = request(url)
        if not result:
            return None

        try:
            data = json.loads(result)
        except Exception:
            return None

        for item in data.get("Search", []):
            otitle = clean_title_for_imdb_search(item.get("Title", ""))
            if clean_title.lower() in otitle.lower() and item.get("Type") == media_type:
                return item.get("imdbID")
        return None

    def fetch_page_json(self, imdb_id: str) -> Optional[Dict[str, Any]]:
        url = f"https://www.imdb.com/title/{imdb_id}/"
        html = request(url)
        if not html:
            return None

        scripts = parseDOM(html, "script", attrs={"id": "__NEXT_DATA__"})
        if not scripts:
            return None

        try:
            return json.loads(scripts[0])
        except Exception:
            return None

    def enrich_from_json(self, title: str, imdb_json: Dict[str, Any], meta: Dict[str, Any]) -> Dict[str, Any]:
        try:
            props = imdb_json["props"]["pageProps"]["aboveTheFoldData"]
            main = imdb_json["props"]["pageProps"]["mainColumnData"]
        except Exception:
            return meta

        # alternative title
        try:
            ctitle = props["titleText"]["text"]
            if re.search(title, str(ctitle), re.I):
                meta["alternative_titles"] = [keepclean_title(ctitle)]
        except Exception:
            pass

        # year
        try:
            year = props["releaseYear"]["year"]
            meta["year"] = year
        except Exception:
            pass

        # rating
        try:
            rating = props["ratingsSummary"]["aggregateRating"]
            if rating:
                meta["rating"] = float(rating)
        except Exception:
            pass

        # genre
        try:
            rgen = props["genres"]["genres"]
            genres = [str(x["text"]) for x in rgen if x]
            if genres:
                meta["genre"] = genres
        except Exception:
            pass

        # plot
        try:
            if not meta.get("plot"):
                plot = props["plot"]["plotText"]["plainText"]
                meta["plot"] = span_cleaning(plot)
        except Exception:
            pass

        # certificate
        try:
            certf = props["certificate"]["rating"]
            if certf in ("Not Rated", "Passed"):
                certf = "R"
            meta["mpaa"] = certf
        except Exception:
            pass

        # runtime
        try:
            runtime = main["runtime"]["seconds"]
            meta["duration"] = runtime
        except Exception:
            pass

        # poster
        try:
            if meta.get("poster") in ("", "movies.png"):
                poster = main["titleMainImages"]["edges"][0]["node"]["url"]
                meta["poster"] = clean_poster_url(poster)
        except Exception:
            pass

        # seasons
        try:
            seasons = main["episodes"]["seasons"][-1]
            num = int(seasons.get("number", 1))
            meta["seasons"] = num
            meta["season"] = num
        except Exception:
            pass

        # total episodes
        try:
            episodes = main["episodes"]["episodes"]["total"]
            meta["total_aired_eps"] = int(episodes)
        except Exception:
            pass

        return meta

    def enrich_from_search_html(self, title: str, html: str, meta: Dict[str, Any]) -> Dict[str, Any]:
        try:
            items = parseDOM(html, "div", attrs={"class": "lister-item mode-advanced"})
        except Exception:
            return meta

        uitem = None
        for item in items:
            header = parseDOM(item, "h3", attrs={"class": "lister-item-header"})
            fheader = parseDOM(header, "a")
            if not fheader:
                continue
            found_title = clean_title_for_imdb_search(fheader[0])
            if re.search(title, str(found_title), re.I):
                href = parseDOM(header, "a", ret="href")
                match = re.search(r"(tt\d+)", str(href))
                if match:
                    imdb_id = match.group(1)
                    meta["imdb_id"] = imdb_id
                    page_json = self.fetch_page_json(imdb_id)
                    if page_json:
                        return self.enrich_from_json(title, page_json, meta)
                uitem = item
                break

        if not uitem:
            return meta

        # year
        try:
            year_wrapper = parseDOM(uitem, "span", attrs={"class": "lister-item-year text-muted unbold"})
            year_match = re.search(r"\d{4}", str(year_wrapper))
            year = int(year_match.group()) if year_match else get_datetime().year
            meta["year"] = year
        except Exception:
            pass

        # poster
        try:
            if meta.get("poster") in ("", "movies.png"):
                poster = parseDOM(uitem, "img", attrs={"class": "loadlate"}, ret="loadlate")[0]
                meta["poster"] = clean_poster_url(poster)
        except Exception:
            pass

        # genre
        try:
            genres_wrapper = parseDOM(uitem, "span", attrs={"class": "genre"})
            genre = [
                item.replace('<span class="ipc-chip__text" role="presentation">', "")
                .replace("</span>", "")
                .strip()
                for item in genres_wrapper
                if item
            ]
            if genre:
                meta["genre"] = genre
        except Exception:
            pass

        # plot
        try:
            plot_wrapper = parseDOM(items, "p", attrs={"class": "text-muted"})
            if plot_wrapper:
                plot = span_cleaning(plot_wrapper[0])
                if plot:
                    meta["plot"] = plot
        except Exception:
            pass

        # rating
        try:
            rating_wrapper = parseDOM(uitem, "span", attrs={"class": "rating-rating.+?"})
            rating = parseDOM(rating_wrapper, "span", attrs={"class": "value"})[0]
            meta["rating"] = float(rating)
        except Exception:
            pass

        return meta

    def enrich_with_imdb(self, meta: Dict[str, Any]) -> Dict[str, Any]:
        title = clean_title_for_imdb_search(meta.get("title", ""))
        imdb_id = meta.get("imdb_id", "")

        # If imdb_id is not a proper tt id, try OMDb search
        if not imdb_id.startswith("tt"):
            found = self.search_id(title, meta.get("mediatype", "movie"))
            if found:
                imdb_id = found
                meta["imdb_id"] = imdb_id

        # Try JSON page first
        if imdb_id.startswith("tt"):
            page_json = self.fetch_page_json(imdb_id)
            if page_json:
                return self.enrich_from_json(title, page_json, meta)

        # Fallback: IMDb search HTML
        if meta.get("mediatype") == "movie":
            url = f"https://www.imdb.com/search/title/?title={quote_plus(title)}&title_type=feature,tv_movie&countries=in"
        else:
            url = f"https://www.imdb.com/search/title/?title={quote_plus(title)}&title_type=tv_series,tv_episode,tv_miniseries&countries=in"

        html = request(url)
        if not html:
            return meta

        return self.enrich_from_search_html(title, html, meta)


# Metadata fetcher (main orchestrator)

class MetadataFetcher:
    def __init__(self, meta_cache: Any, imdb_client: Optional[IMDbClient] = None) -> None:
        self.meta_cache = meta_cache
        self.imdb = imdb_client or IMDbClient()

    # ---------- public API ----------

    def fetch(
        self,
        m_type: str,
        title: str,
        tmdb_id: str,
        homepage: str,
        season: int = 1,
        studio: str = "",
        poster: str = "movies.png",
        imdb_id: str = "",
        plot: str = "",
        genre: Optional[List[str]] = None,
        year: Optional[int] = None,
        cast: Optional[List[Dict[str, Any]]] = None,
        rating: float = 5.0,
    ) -> MetadataModel:
        genre = genre or []
        cast = cast or []
        year = year or get_datetime().year

        cached = self._get_cached(m_type, tmdb_id)
        if cached and not cached.get("blank_entry"):
            # log(f'cached → {repr(cached)}')
            return MetadataModel.from_dict(cached).to_dict()

        meta = tmdb_search(tmdb_id, season, False)
        if not meta:
            if not plot and re.search(r"desi-serials|playdesi", str(homepage), re.I):
                plot, rating, genre = get_plot_tvshow(homepage, genre)

            meta = self._build_base_dict(
                m_type=m_type,
                title=title,
                tmdb_id=tmdb_id,
                homepage=homepage,
                season=season,
                studio=studio,
                poster=poster,
                imdb_id=imdb_id,
                plot=plot,
                genre=genre,
                year=year,
                cast=cast,
                rating=rating,
            )

            meta = self.imdb.enrich_with_imdb(meta)

        self._store_cache(m_type, meta)
        return MetadataModel.from_dict(meta).to_dict()

    # ---------- internal helpers ----------

    def _get_cached(self, m_type: str, tmdb_id: str) -> Optional[Dict[str, Any]]:
        return (
            self.meta_cache.get(m_type, "tvdb_id", tmdb_id)
            or self.meta_cache.get(m_type, "tmdb_id", tmdb_id)
        )

    def _store_cache(self, m_type: str, meta: Dict[str, Any]) -> None:
        key = "movie" if m_type == "movie" else "tvshow"
        self.meta_cache.set(key, "tmdb_id", meta, 3840)

    def _build_base_dict(
        self,
        m_type: str,
        title: str,
        tmdb_id: str,
        homepage: str,
        season: int,
        studio: str,
        poster: str,
        imdb_id: str,
        plot: str,
        genre: List[str],
        year: int,
        cast: List[Dict[str, Any]],
        rating: float,
    ) -> Dict[str, Any]:
        if not imdb_id:
            imdb_id = tmdb_id

        # normalize poster path for addon
        try:
            if "addons\\plugin.video.infinite" in poster:
                poster = f"special://home/addons/{poster.split('addons')[1]}".replace("\\", "/")
        except Exception:
            pass

        plot = replaceHTMLCodes(plot)
        plot = (
            plot.replace("\\n", " ")
            .replace("\\r", "")
            .strip()
        )

        if isinstance(studio, str):
            studio = (
                studio.replace("-tv", "")
                .replace("-hd", "")
                .replace("-hdepisodes", "")
                .split(",")
            )

        if not isinstance(studio, list):
            studio = list(studio)

        fgenre = generes_unify(genre, m_type)

        base: Dict[str, Any] = {
            "mediatype": m_type,
            "year": year,
            "plot": plot,
            "title": title,
            "studio": studio,
            "poster": poster,
            "homepage": homepage,
            "genre": fgenre,
            "cast": cast or [{"role": "", "name": "", "thumbnail": ""}],
            "tmdb_id": tmdb_id,
            "imdb_id": imdb_id,
            "tvdb_id": tmdb_id,
            "rating": rating or 4.0,
            "clearlogo": "",
            "trailer": "",
            "votes": 50,
            "tagline": "",
            "director": [],
            "writer": [],
            "episodes": 0,
            "seasons": 0,
        }

        if m_type == "movie":
            base.update({"duration": 5400, "mpaa": "R"})
        else:
            base.update(
                {
                    "duration": 1320,
                    "mpaa": "TV-MA",
                    "season": season,
                    "total_aired_eps": 2,
                    "seasons": season,
                    "episode": 1,
                    "tvshowtitle": title,
                }
            )

        return base


# Utility functions (adapted from original)

def gettmdb_id(m_type: str, title: str, year: Optional[int] = None, studio: Optional[str] = None) -> str:
    if m_type == "movie" and not year:
        year = get_datetime().year
    return f"{title}|{year}" if m_type == "movie" else f"{(studio or '').lower()}|{title}"


def generes_unify(genres: Any, m_type: str) -> List[str]:
    if isinstance(genres, str):
        genres = replaceHTMLCodes(genres).split(",")

    cleaned: List[str] = []
    for genr in genres:
        genr = (
            genr.replace('<span data-sheets-value="{"1"', "")
            .replace("–", "-")
            .replace("-", "-")
            .replace(".", "")
        )
        genr = replaceHTMLCodes(genr)
        genr = genr.strip()
        if genr:
            cleaned.append(genr)

    if not cleaned:
        cleaned = ["Movie"] if m_type == "movie" else ["TV"]

    return list(set(cleaned))


def clean_season_fromtitle(title: str) -> str:
    ctitle = re.sub(season_data, "", title)
    ctitle = re.sub(r"(\d{1,2})", "", ctitle)
    if not ctitle:
        return title
    return ctitle.strip().lower()


def clean_title_for_imdb_search(title: str) -> str:
    title = keepclean_title(title)
    return clean_season_fromtitle(title)


def clean_poster_url(poster: str) -> str:
    if "/nopicture/" in poster:
        return "0"
    poster = re.sub(r"(?:_SX|_SY|_UX|_UY|_CR|_AL)(?:\d+|_).+?\.", "_SX500.", poster)
    return replaceHTMLCodes(poster)


def span_cleaning(span_text: str) -> str:
    span_text = span_text.rsplit("<span>", 1)[0].strip()
    span_text = re.sub(r"<.+?>|</.+?>", "", span_text)
    span_text = (
        span_text.replace("\xa0", " ")
        .replace("See all certifications", "")
        .replace("See full summary", "")
    )
    if "add a plot" not in span_text.lower():
        span_text = replaceHTMLCodes(span_text)
        span_text = span_text.strip().replace("\\n", "")
    else:
        span_text = ""
    return span_text.strip()


def get_plot_tvshow(show_url: Optional[str] = None, genre: Optional[List[str]] = None) -> (str, float, List[str]):
    plot = ""
    genres: List[str] = []
    rating: float = 5.0
    genre = genre or []

    episo_page = request(show_url)
    if not episo_page:
        return plot, rating, genre

    result1 = parseDOM(episo_page, "div", attrs={"class": "main-content col-lg-9"})
    result1 += parseDOM(episo_page, "div", attrs={"class": "blog-posts posts-large posts-container"})

    result = parseDOM(result1, "div", attrs={"id": "content"})
    p = parseDOM(result, "div", attrs={"class": "page-content"})
    p = parseDOM(p, "div", attrs={"class": "page-content"}) or p

    if p:
        title_overview = get_findall(r"<p>(.+?)</p>", str(p))
        try:
            plot = title_overview[0].replace("<br/><br/>", "").replace("\\n", "").strip()
        except Exception:
            pass
        try:
            rest_ofp = title_overview[1].replace("<br/><br/>", "").replace("\\n", "").strip()
            rating_match = get_findall(r"Show Rating: </span>\s+(.+?)/.+? <p>", rest_ofp)
            if rating_match:
                rating = float(rating_match[0])
            genres_found = get_findall(r"Genre: </span>\s+(.+?)$", rest_ofp)
            genres.extend(genres_found)
        except Exception:
            pass
    else:
        try:
            plot_match = get_findall(r'loading="lazy" \/><\/div>(.*?)<p>.+?<span', str(result), re.M)
            if plot_match:
                plot = plot_match[0].strip()
        except Exception:
            pass
        try:
            genres_found = get_findall(r'<span.+?font-weight:bold">(.+?)<\/span>', str(result), re.M)
            genres.extend(genres_found)
        except Exception:
            pass

    for item in genres:
        if "on:" in item:
            item = item.split(":")[1].strip()
        if item:
            genre.append(item)

    plot = replaceHTMLCodes(plot)
    return plot, rating, genre

def get_metadata(params):
    # 1. Create your cache instance (yours may differ)
    # meta_cache = MetaCache()

    # 2. Create the fetcher (inject IMDbClient if you want custom API key)
    fetcher = MetadataFetcher(meta_cache, imdb_client=IMDbClient())

    # 3. Call fetch() with the same arguments your old code used
    meta = fetcher.fetch(
        m_type="tvshow",
        title=params.get("title"),
        tmdb_id=params.get("tmdb_id"),
        homepage=params.get("url"),
        season=int(params.get("season", 1)),
        studio=params.get("studio", ""),
        poster=params.get("poster", "movies.png"),
        imdb_id=params.get("imdb_id", ""),
        plot="",
        genre=[],
        year=None,
        cast=[],
        rating=5.0,
    )

    # 4. You now have a MetadataModel instance
    return meta




# ============================
#  OPTIMIZED RESOLVER MODULE
#  Drop‑in replacement
# ============================

#  HELPERS

def find_domain_notin(url: str) -> bool:
    url_l = url.lower()
    return any(item in url_l for item in FILTER_ITEMS)

def getVideoID(url):
    m = RE_VIDEO_ID.search(f'{url}##')
    return m.group(2) if m else None

def get_mod_url(url):
    url_id = getVideoID(url)
    if not url_id:
        return

    if 'vkprime.php' in url:
        return f'https://vkprime.com/embed-{url_id}.html'
    if 'vkspeed.php' in url:
        return f'https://vkspeed.com/embed-{url_id}.html'
    if 'speed.php' in url:
        return f'https://vkspeed.com/embed-{url_id}-600x380.html'

    return url

def meta_redirect(content):
    m = RE_META_REFRESH.search(content)
    return m.group(1).strip() if m else None


#  FORM / ARTICLE / APNE / OKMALAYALAM HANDLERS

def form_action(url, headers, bhtml):
    try:
        if r := get_findall(r'''<form.+?action="([^"]+)''', bhtml):
            purl = r[-1]
            headers.update({'Referer': f'{url}/', 'Origin': url})

            pd = dict(r1) if (r1 := get_findall(r"type='hidden'\s*name='([^']+)'\s*value='([^']+)", bhtml)) else {}

            bhtml2 = request(purl, post=pd, headers=headers)

            if s := get_findall(r'''<iframe.+?src=['"]([^"']+)''', bhtml2):
                return s

            if r2 := get_findall(r'''<form.+?action="([^"]+)''', bhtml2):
                purl = r2[-1]
                pd = dict(r1) if (r1 := get_findall(r"type='hidden'\s*name='([^']+)'\s*value='([^']+)", bhtml2)) else {}
                ehtml = request(purl, post=pd, headers=headers)

                if s := get_findall(r'''<iframe.+?src=['"]([^"']+)''', ehtml):
                    return s

        elif s := get_findall(r'''<iframe.+?src=['"]([^"']+)''', bhtml):
            return s

    except Exception as e:
        error(f'Error form_action: {url} {e}')

    return None

def articleweb(url, headers):
    try:
        ehtml = refresh_redirect(url, headers) if '/vid/' not in url or 'multiup' in url else request(url, headers=headers)
        m = re.search(r'''<iframe.+?src=\s*['"]([^'"]+)''', ehtml, re.I)
        return m[1] if m else None
    except Exception as e:
        error(f'Error articleweb: {url} {e}')

def get_apneurl(link, headers=None):
    try:
        html = scrapePage.srp_page(link, headers=headers).text

        if s := form_action(link, headers, html):
            vidurl = s[0]
            if 'url=' in vidurl:
                vidurl = vidurl.split('url=')[-1]
            if 'hls' in vidurl:
                vidurl = vidurl.replace(',.urlset/master.m3u8', '/v.mp4').replace('hls/,', '')
            return vidurl

    except Exception as e:
        error(f'Error get_apneurl: {link} {e}')

    return None

def get_okmalayalam_url(url, headers):
    try:
        mid = url.split('/')[-1]
        params = {'data': mid, 'do': 'getVideo'}
        data = {'hash': mid, 'r': ''}

        jd = request('https://v.okmalayalam.org/player/index.php',
                     XHR=True, referer=url, post=data, params=params)

        if jd:
            jd = json.loads(jd)
            return jd.get('securedLink')

    except Exception as e:
        error(f'Error okmalayalam: {url} {e}')

    return None

def get_directurl(link, headers, url):
    vhdr = {'Referer': f'{url}/', 'Origin': url, 'User-Agent': 'iPad'}
    return f'Direct_{link}|{urlencode(vhdr)}'


#  MAIN VIDEO URL EXTRACTOR

def get_vid_url(shtml, headers, url):
    try:
        shtml = get_jsunpack_unjuice(shtml)
        links = RE_IFRAME_SRC.findall(shtml)

        for link in links:
            if not link.startswith('http'):
                continue
            if any(x in link for x in REMOVE_ADS_JS):
                continue

            link_l = link.lower()

            if 'speed' in link_l or 'vkprime' in link_l or 'tvlogy' in link_l:
                return link

            if any(x in link_l for x in ARTICLE_EMBED):
                return articleweb(link, headers)

            if any(x in link_l for x in APNE_EMBED):
                return get_apneurl(link, headers)

            if 'okmalayalam.' in link_l:
                return get_okmalayalam_url(link, headers)

            if 'flow.' in link_l:
                return get_embed_url(link, headers)

            if not any(x in link_l for x in NON_STR) and not any(x in link_l for x in EMBED_LIST):
                return link

            return get_directurl(link, headers, url)

    except Exception as e:
        error(f'Error get_vid_url: {url} {e}')

    return None


#  EMBED RESOLVER

def get_embed_url(url, headers):
    try:
        result = refresh_redirect(url, headers=headers)
        if not result:
            return None

        if (redir := meta_redirect(result)):
            result = refresh_redirect(redir, headers=headers)

        return get_vid_url(result, headers, url)

    except Exception as e:
        error(f'Error embed_url: {url} {e}')

    return None


#  PUBLIC RESOLVER

def resolve_gen(url, headers=None):
    _headers = headers or {'User-Agent': agent()}

    if not find_domain_notin(str(url)):
        urls = url.split(' , ') if ' , ' in url else [url]
        resolved = []

        for iurl in urls:
            iurl_l = iurl.lower()

            if any(x in iurl_l for x in APNE_EMBED):
                out = get_apneurl(iurl, _headers)
            elif any(x in iurl_l for x in ARTICLE_EMBED):
                out = articleweb(iurl, _headers)
            else:
                out = get_embed_url(iurl, _headers)

            if out:
                resolved.append(out)

        if resolved:
            if testing:
                log(f'resolve_gen → {resolved}')
            return ' , '.join(resolved)

    return url
