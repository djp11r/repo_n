# -*- coding: utf-8 -*-
import json
from random import choice

import requests
import time
from urllib.parse import quote
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.utils import get_datetime, make_tinyurl, make_qrcode, make_thread_list
from openscrapers.modules.build_session import build_session
from openscrapers.modules.control import setting, setSetting, notification, selectDialog, sleep
from openscrapers.windows.base import getProgressWindow
API_URL = 'https://api.themoviedb.org/3'
ART_URL = 'https://image.tmdb.org/t/p/original'
HEADERS = {'Content-Type': 'application/json;charset=utf-8'}
API_KEY = 'c8b7db701bac0b26edfcc93b39858972'
timeout = 3.05
tmdb_api_key = ['c8b7db701bac0b26edfcc93b39858972', '6a5be4999abf74eba1f9a8311294c267', '1fab5f2129742be63561c063075a1535', 'd848316a33e79095beb945a2bd2d53b1', '8877595a1e6647d272148c99133df1fb', 'bc96b19479c7db6c8ae805744d0bdfe2', 'edde6b5e41246ab79a2697cd125e1781', 'af3a53eb387d57fc935e9128468b1899', 'f090bb54758cabf231fb605d3e3e0468']

def find_movie_by_external_source(imdb):
    try:
        url = f'{API_URL}/find/{imdb}?api_key={API_KEY}&language=en-US&external_source=imdb_id'
        result = requests.get(url, headers=HEADERS).json()
        return result['movie_results'][0]
    except Exception as err:
        error(f'find_movie_by_external_source: {err}')
        return


def find_tvshow_by_external_source(imdb=None, tvdb=None):
    try:
        if imdb: url = f'{API_URL}/find/{imdb}?api_key={API_KEY}&language=en-US&external_source=imdb_id'
        elif tvdb: url = f'{API_URL}/find/{tvdb}?api_key={API_KEY}&language=en-US&external_source=tvdb_id'
        result = requests.get(url, headers=HEADERS).json()
        return result['tv_results'][0]
    except Exception as err:
        error(f'find_tvshow_by_external_source: {err}')
        return


def clean_title_to_comparisons(s):
    """
        Method that takes a string and returns it cleaned of any special characters in order to do proper string comparisons
    
    Lowercase, replace '&' with 'and', strip non-alphanumeric, collapse spaces.
    This makes matching more robust across small variations.
    Simple normalisation for comparing titles:
      - lowercase
      - replace '&' with 'and'
      - remove non-alphanumeric chars
      - collapse spaces
    """
    try: 
        s = (s or "").lower().replace("&", "and")
        out = []
        last_space = False
        for ch in s:
            if "a" <= ch <= "z" or "0" <= ch <= "9":
                out.append(ch)
                last_space = False
            else:
                if not last_space:
                    out.append(" ")
                    last_space = True
        norm = "".join(out).strip()
        while "  " in norm:
            norm = norm.replace("  ", " ")
        return norm
    except:
        try: return ''.join(e for e in s.lower() if e.isalnum())
        except: return s


def clean_title_to_search(title):
    ftitle = ''
    for word in title.split(' '):
        if word.isalnum() is False:
            w = ""
            for i in range(len(word)):
                if word[i].isalnum():
                    w += word[i]
            word = w
        ftitle += ' ' + word
    return ftitle.strip()


def get_query(title):
    title = title.lower()
    if 'superstar singer' in title: return 'superstar singer'
    elif 'dance deewane' in title: return 'dance deewane'
    elif 'india got talent' in title: return 'india got talent'
    elif 'jhalak dikhhla jaa' in title: return 'jhalak dikhhla jaa'
    elif 'crime patrol' in title: return 'crime patrol'
    elif 'indias best dancer' in title: return 'indias best dancer'
    elif 'kaun banega crorepati' in title: return 'kaun banega crorepati'
    elif 'bigg boss ott' in title: return 'bigg boss ott'
    elif 'bigg boss' in title: return 'bigg boss'
    elif 'indian idol' in title: return 'indian idol'
    elif 'the kapil sharma show' in title: return 'the kapil sharma show'
    return title


def _do_tmdb_request(values, method='search/multi', lang='en'):
    api_key = choice(tmdb_api_key)
    url = f'{API_URL}/{method}?language={lang}&api_key={api_key}&{values}'
    try: response = requests.get(url, headers=HEADERS, timeout=20)
    except: response = None
    data = response.json()
    # log(f'from url: {url}\ndata: {data}')
    return data


def _tmdb_search_movie_or_tv(title, year, is_tv=False):
    """
    Calls TMDB /search/movie or /search/tv and returns a simplified list:
      [ { "id": int, "title": str, "year": int or None }, ... ]
    """
    api_key = choice(tmdb_api_key)

    endpoint = "/search/tv" if is_tv else "/search/movie"
    url = API_URL + endpoint

    params = {"api_key": api_key, "query": title,}

    # TMDB supports filtering by year for movies; for TV we just use the query.
    if year is not None and not is_tv: params["year"] = year

    resp = requests.get(url, params=params, timeout=30)
    if not resp.ok: return []

    data = resp.json()
    out = []

    for r in data.get("results", []):
        if is_tv:
            name = r.get("name") or r.get("original_name") or ""
            date_str = r.get("first_air_date") or ""
        else:
            name = r.get("title") or r.get("original_title") or ""
            date_str = r.get("release_date") or ""

        year_int = None
        if date_str:
            try: year_int = int(date_str[:4])
            except: year_int = None
        out.append({"id": r.get("id"), "title": name, "year": year_int,})
    return out


def tmdb_search(query, season=1, only_tmbdid=True, want_lang='hi', want_country=['IN']):
    """
    :param query:
    :return: dict for meta
    """
    do_req = _do_tmdb_request
    q0, q1 = query.split('|')
    if q1.isdigit(): title, year, m_type, runtime, year_match = q0, q1, 'movie', 120, 'release_date'
    else: title, year, m_type, runtime, year_match = q1, None, 'tv', 30, 'first_air_date'
    name = get_query(title)
    if not year: year = str(get_datetime().year)
    # log(f'name: {name} title: {title} year: {year}')
    meta = do_req(f'query={name}', f'search/{m_type}', 'en,hi')
    results = meta.get('results') or []
    # log(f'query: {query} meta: {results}\nmeta: {meta}')
    if not results: return query if only_tmbdid else None
    # total = meta.get('total_results', 0)
    # Early filtering: mediatype + language
    # if m_type: results = [r for r in results if r.get('media_type') == m_type]
    # log(f'm_type: {m_type} results: {results}')
    if want_lang: results = [r for r in results if r.get('original_language') == want_lang]
    # log(f'want_lang: {want_lang} results2: {results}')
    if not results: return query if only_tmbdid else None
    clean_name = clean_title_to_comparisons(name.lower())
    filtered = []
    append = filtered.append
    for r in results:
        t = r.get('title') or r.get('name')
        if not t: continue
        if clean_name in clean_title_to_comparisons(t.lower()):
            # Year match if available
            if r.get(year_match, '0000')[:4] == year:
                year = r.get(year_match, '0000')[:4]
                # log(f'year: {year} r: {r}')
                append(r)
    if not filtered: # fallback: title-only match
        for r in results:
            t = r.get('title') or r.get('name')
            if t and clean_title_to_comparisons(t.lower()) in clean_name:
                year = r.get(year_match, '0000')[:4]
                append(r)
    # log(f'filtered: {filtered}')
    if not filtered: return query if only_tmbdid else None
    # Batch metadata filter (country)
    tmdb_id = None
    if want_country:
        results = [r for r in results if r.get('origin_country') == want_country or r.get('production_countries') == want_country]
        # log(f'results: {repr(results)}')
        if results:
            if len(results) > 1: pick = results[0]
            else: pick = results[0]
            tmdb_id = pick.get('id')
    # log(f'tmdb_id: {tmdb_id}')
    if not tmdb_id:
        # fallback: if No country filtering → pick best match
        if len(filtered) > 1: pick = filtered[0]
        else: pick = filtered[0]
        tmdb_id = pick.get('id')
    # log(f'tmdb_id2: {tmdb_id}')
    # Return ID or full metadata
    # query = f'{title}|{year}' if m_type == 'movie' else query
    tmdb_id = str(tmdb_id) if tmdb_id else query
    # log(f'{repr(tmdb_id)}, {repr(m_type)}, {repr(title)}, {repr(query)}, {repr(year)}, {repr(season)}, {repr(runtime)}')
    return tmdb_id if only_tmbdid else get_meta_tmbd(str(tmdb_id), m_type, title, query, year, season, runtime)


def get_meta_tmbd(tmdb_id, media_type, title, query, year, season, runtime):
    if not tmdb_id or '|' in str(tmdb_id): return None
    do_req = _do_tmdb_request
    img_base = 'https://image.tmdb.org/t/p/'
    if media_type == 'movie': extra_append = 'append_to_response=external_ids,videos,credits,release_dates,alternative_titles,translations,images,keywords&include_image_language=en,hi'
    else: extra_append = 'append_to_response=external_ids,videos,credits,content_ratings,alternative_titles,translations,images,keywords&include_image_language=en,hi'
    meta = do_req(extra_append, f'{media_type}/{tmdb_id}', 'en,hi')
    # log(f'title: {title} meta: {meta}')
    if not meta: return None
    g = meta.get  # local binding (fast)
    title = title.title()
    # Pre-extract fields
    production_countries = g('production_countries') or ()
    spoken_languages = g('spoken_languages') or ()
    companies = g('networks') or g('production_companies') or ()
    alt_titles = g('alternative_titles') or {}
    premiered = g('release_date') or g('first_air_date')
    genres = g('genres') or ()
    videos = g('videos') or g('trailers') or {}
    casts = g('casts') or g('credits') or {}
    poster_path = g('poster_path')
    backdrop_path = g('backdrop_path')

    country = [c['name'] for c in production_countries]
    country_codes = [c['iso_3166_1'] for c in production_countries]
    spoken_language = spoken_languages[0].get('english_name', '') if spoken_languages else ''

    studio = ()
    if companies:
        for c in companies:
            if c.get('logo_path'):
                studio = (c['name'],)
                break
        else: studio = (companies[0]['name'],)

    alt_list = alt_titles.get('titles') or alt_titles.get('results') or ()
    alternative_titles = [i['title'] for i in alt_list if i.get('iso_3166_1') in ('US', 'GB', 'UK', 'IN', '')]

    md = {'tmdb_id': str(g('id')), 'tvdb_id': query, 'title': title, 'tagline': g('tagline'), 'mediatype': 'tvshow' if media_type != 'movie' else 'movie', 'plot': g('overview'), 'country': country, 'studio': studio, 'mpaa': 'NR', 'rating': g('vote_average') or 5, 'votes': g('vote_count') or 10, 'premiered': premiered, 'duration': runtime * 60, 'year': year, 'alternative_titles': alternative_titles, 'country_codes': country_codes, 'spoken_language': spoken_language, 'genre': [], 'cast': [], 'director': [], 'writer': [], 'trailer': [], 'all_trailers': []}

    # External IDs
    ext = g('external_ids') or {}
    imdb_id = ext.get('imdb_id') or query
    md['imdb_id'] = imdb_id
    md['imdbnumber'] = imdb_id

    if premiered: md['year'] = premiered[:4]
    if rt := g('runtime'): md['duration'] = rt * 60
    elif ert := g('episode_run_time'): md['duration'] = ert[0] * 60

    cast_list = casts.get('cast') or ()
    if cast_list:
        md['cast'] = [
            {'name': c.get('name') or 'none', 'role': c.get('character'), 'thumbnail': f'{img_base}w138_and_h175_face{c.get("profile_path")}'}
            for c in cast_list[:10]
        ]
    crew = casts.get('crew') or ()
    if crew:
        md['writer'] = [c['name'] for c in crew if c.get('job') in ('Author', 'Writer', 'Screenplay', 'Characters')]
        md['director'] = [c['name'] for c in crew if c.get('job') == 'Director']

    if genres: md['genre'] = [g['name'] for g in genres]
    results = videos.get('results') or videos.get('youtube') or ()
    md['all_trailers'] = results
    for v in results:
        if v.get('site') == 'YouTube' and v.get('type') in ('Trailer', 'Teaser'):
            md['trailer'] = f'plugin://plugin.video.youtube/play/?video_id={v["key"]}'
            break

    if poster_path: md['poster'] = f'{img_base}w500{poster_path}'
    if backdrop_path: md['fanart'] = f'{img_base}w1280{backdrop_path}'
    if md['mediatype'] == 'movie':
        md['extra_info'] = {'status': g('status'), 'budget': g('budget') or '$0', 'revenue': g('revenue') or '$0', 'homepage': g('homepage'), 'collection_name': g('collection_name'), 'collection_id': g('collection_id')}
    else:
        seasons = g('number_of_seasons') or g('seasons') or 1
        if isinstance(seasons, list): seasons = len(seasons)
        if seasons > season: season = seasons
        created_by = g('created_by') or ()
        created_names = ', '.join(c['name'] for c in created_by) if created_by else 'N/A'
        md.update({'tvshowtitle': title, 'seasons': seasons, 'season': season, 'extra_info': {'status': g('status'), 'homepage': g('homepage'), 'created_by': created_names, 'type': g('type'), 'last_episode_to_air': g('last_episode_to_air'), 'next_episode_to_air': g('next_episode_to_air')}, 'season_data': g('seasons') or [], 'total_aired_eps': g('number_of_episodes') or 1})
    return md


class TMDbListAPI:
    def __init__(self):
        self.base_url = 'https://api.themoviedb.org/4'
        self.base_url_v3 = 'https://api.themoviedb.org/3'
        self.read_access_token = setting('tmdb_read_token') or 'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJkODQ4MzE2YTMzZTc5MDk1YmViOTQ1YTJiZDJkNTNiMSIsIm5iZiI6MTcxMTQ3Mzg1NC45MzQsInN1YiI6IjY2MDMwNGJlYjAyZjVlMDE3ZDIxNDAzZSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ._uRCLIwLIE2gOlH8q04gcM3ywIXpxuZ-uyel-UMRRg4'
        self.token = setting('tmdb.token')
        self.headers = {'Authorization': 'Bearer %s' % self.read_access_token}
        self.session = build_session('https://api.themoviedb.org')

    def base2_url(self, path):
        return 'https://api.themoviedb.org/%s' % path

    def auth(self):
        notice = 'Failed'
        headers = {'accept': 'application/json', 'content-type': 'application/json', 'Authorization': 'Bearer %s' % self.read_access_token}
        data = requests.post(f'{self.base_url}/auth/request_token', headers=headers, timeout=20).json()
        if not 'success' in data: return notification('Failed to Auth Account')
        request_token = data['request_token']
        token_url = f'https://www.themoviedb.org/auth/access?request_token={request_token}'
        qr_code = make_qrcode(token_url, 'tmdb') or ''
        short_url = make_tinyurl(token_url)
        # copy2clip(short_url)
        if short_url: p_dialog_insert = f'Please Scan the QR Code[CR][CR]OR visit this URL: [B]{short_url}[/B]'
        else: p_dialog_insert = 'Please Scan the QR Code'
        progressD = getProgressWindow('TMDb Account Authorization', qr_code, 1)
        progressD.set_controls()
        progressD.update(0, p_dialog_insert)
        start = time.time()
        progress, expires_in, success = 0, 120 + time.time(), None
        while not progressD.iscanceled() and progress < expires_in:
            try:
                progres_ = '%02d:%02d' % divmod(expires_in - time.time(), 60)
                if progres_ == '00:00' or progressD.iscanceled(): break
                progress = max((time.time() - start), 0)
                response = requests.post(f'{self.base_url}/auth/access_token', json={'request_token': request_token}, headers=headers, timeout=20).json()
                if response.get('success') and response.get('access_token'):
                    self.token = response['access_token']
                    setSetting('tmdb.token', self.token)
                    setSetting('tmdb.account_id', response['account_id'])
                    notice = 'Success'
                    break
                progressD.update(progress, f'Remaining Time: [B]{progres_}[/B][CR]{p_dialog_insert}')
                sleep(500)
            except: pass
        try: progressD.close()
        except: pass
        self.get_session_id()
        notification(notice)

    def get_session_id(self):
        response = self.session.post(self.base2_url('3/authentication/session/convert/4'), json={'access_token': self.token}, headers=self.headers, timeout=timeout).json()
        session_id = response.get('session_id')
        if response.get('success') and session_id: success = True
        else: success = False
        if success:
            response = self.session.get(self.base2_url('3/account'), params={'session_id': session_id}, headers=self.headers, timeout=timeout).json()
            username, session_account_id = response.get('username'), response.get('id')
            if not session_id: success == False
        if success:
            # setSetting('tmdb.token', access_token)
            # setSetting('tmdb.account_id', account_id)
            setSetting('tmdb.user', username)
            setSetting('tmdb.session_id', session_id)
            setSetting('tmdb.session_account_id', str(session_account_id))
            return True
        return False

    def revoke(self):
        import requests
        headers = {'accept': 'application/json', 'content-type': 'application/json', 'Authorization': 'Bearer %s' % self.read_access_token}
        data = requests.delete('%s/auth/access_token' % self.base_url_v3, json={'access_token': self.read_access_token}, headers=headers, timeout=20).json()
        if not 'success' in data: notice = 'Failed to Revoke Account Auth'
        else:
            notice = 'Success! Auth Revoke'
            setSetting('tmdb.token', '')
            setSetting('tmdb.account_id', '')
            setSetting('tmdb.session_id', '')
            setSetting('tmdb.session_account_id', '')
        return notification(notice)

    def get_user_lists(self):
        def _process_multi(page_no):
            try: results_extend(self.request_data(url % (self.base_url, account_id, page_no))['results'])
            except: pass
        def _process(dummy):
            result = self.request_data(url % (self.base_url, account_id, 1))
            results_extend(result['results'])
            total_pages = result['total_pages']
            if total_pages > 1:
                threads = list(make_thread_list(_process_multi, range(2, total_pages + 1)))
                [i.join() for i in threads]
            return results
        account_id = setting('tmdb.account_id')
        url = '%s/account/%s/lists?page=%s'
        results = []
        results_extend = results.extend
        return _process('d')

    def get_watchfavrecs_list_details(self, list_id, media_type):
        def _process_multi(page_no):
            try:
                results_extend([dict(i, **{'original_order': c}) for c, i in enumerate(self.request_data(url % (self.base_url, account_id, media_type, list_id, page_no))['results'], (page_no * 20) - 20)])
            except: pass
        def _process(dummy):
            result = self.request_data(url % (self.base_url, account_id, media_type, list_id, 1))
            results_extend([dict(i, **{'original_order': c}) for c, i in enumerate(result['results'])])
            total_pages = result['total_pages']
            if list_id == 'recommendations': total_pages = 2
            if total_pages > 1:
                threads = list(make_thread_list(_process_multi, range(2, total_pages + 1)))
                [i.join() for i in threads]
            return results
        if media_type != 'movie': media_type = 'tv'
        account_id = setting('tmdb.account_id')
        # string = 'get_%s_details_%s' % (list_id, media_type)
        url = '%s/account/%s/%s/%s?page=%s'
        if list_id == 'recommendations': url += '&language=en-US&region=US'
        results = []
        results_extend = results.extend
        return _process('d')

    def get_list_details(self, list_id):
        def _process_multi(page_no):
            try: results_extend([dict(i, **{'original_order': c}) for c, i in enumerate(self.request_data(url % (self.base_url, list_id, page_no))['results'], (page_no * 20) - 20)])
            except: pass
        def _process(dummy):
            result = self.request_data(url % (self.base_url, list_id, 1))
            results_extend([dict(i, **{'original_order': c}) for c, i in enumerate(result['results'])])
            total_pages = result['total_pages']
            if total_pages > 1:
                threads = list(make_thread_list(_process_multi, range(2, total_pages + 1)))
                [i.join() for i in threads]
            return results
        url = '%s/list/%s?page=%s'
        results = []
        results_extend = results.extend
        return _process('d')

    def add_remove_from_list(self, list_id, items, action):
        url = '%s/list/%s/items' % (self.base_url, list_id)
        return self.request_data(url, data=items, method=action)

    def add_remove_from_watchfavs(self, media_type, media_id, list_type, status):
        if list_type == 'favorites': list_type = 'favorite'
        account_session_id = setting('tmdb.session_account_id')
        session_id = setting('tmdb.session_id')
        if not session_id:
            notification('Please Re-Authenticate you TMDB account')
            return {'success': False}
        url = f'{self.base_url_v3}/account/{account_session_id}/{list_type}'
        return self.request_data(url, params={'session_id': session_id}, data={'media_type': media_type, 'media_id': str(media_id), list_type: status}, method='post')

    def make_list(self, list_name):
        url = '%s/list' % self.base_url
        return self.request_data(url, data={'description': '', 'name': list_name, 'iso_3166_1': 'US', 'iso_639_1': 'en', 'public': True}, method='post')

    def delete_list(self, list_id):
        url = '%s/list/%s' % (self.base_url, list_id)
        return self.request_data(url, method='delete')

    def rename_list(self, list_id, new_name):
        data = {'description': '', 'name': new_name, 'iso_3166_1': 'US', 'iso_639_1': 'en', 'public': True}
        url = '%s/list/%s' % (self.base_url, list_id)
        return self.request_data(url, data=data, method='put')

    def clear_list(self, list_id):
        url = '%s/list/%s/clear' % (self.base_url, list_id)
        return self.request_data(url)

    def item_status(self, list_id, media_type, media_id):
        url = '%s/list/%s/item_status' % (self.base_url, list_id)
        return self.request_data(url, params={'media_type': media_type, 'media_id': int(media_id)})

    def request_data(self, url, params=None, data=None, method='get'):
        headers = {'accept': 'application/json', 'content-type': 'application/json', 'Authorization': 'Bearer %s' % self.token}
        try: result = self.session.request(method, url, params=params, json=data, headers=headers, timeout=90).json()
        except: result = None
        return result

tmdb_list_api = TMDbListAPI()