import functools
import os
import random
import re
import shutil
import sys
import socket
from ast import literal_eval
from gzip import GzipFile
from ssl import OPENSSL_VERSION
from io import BytesIO
from time import sleep, time
from json import loads
from traceback import print_exc
from urllib.parse import urlparse

import requests
import urllib3
from requests.adapters import HTTPAdapter
from _socket import gaierror
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

try:
    import dns.resolver
    DNS_CACHE = dns.resolver.Cache()
except:
    DNS_CACHE = None

from .log_utils import log, error

try: from openscrapers.modules import cache
except: from . import cache
try: translatePath = xbmc.translatePath
except: translatePath = object()

SSL_OPTIONS = urllib3.util.ssl_.OP_NO_SSLv2 | urllib3.util.ssl_.OP_NO_SSLv3 | urllib3.util.ssl_.OP_NO_COMPRESSION | urllib3.util.ssl_.OP_NO_TICKET
cipher_suite = 'ECDHE-ECDSA-AES128-SHA:ECDHE-ECDSA-AES256-SHA384:DHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-SHA256:TLS_AES_128_GCM_SHA256:DHE-RSA-AES128-SHA256:TLS_CHACHA20_POLY1305_SHA256:AES128-SHA256:ECDHE-RSA-AES256-SHA:AES128-GCM-SHA256:ECDHE-ECDSA-CHACHA20-POLY1305:DHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-SHA:ECDHE-RSA-CHACHA20-POLY1305:ECDHE-RSA-AES128-GCM-SHA256:AES256-SHA:TLS_AES_256_GCM_SHA384:ECDHE-RSA-AES128-SHA:DHE-RSA-AES128-SHA:DHE-RSA-AES256-SHA256:ECDHE-RSA-AES256-SHA384:ECDHE-RSA-AES256-GCM-SHA384:AES256-SHA256:AES256-GCM-SHA384:DHE-RSA-AES256-SHA:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES128-SHA256:AES128-SHA@SECLEVEL=0'
chrome_browser = {'cipher_suite': cipher_suite, 'headers': {'sec-ch-ua-mobile': '?0', 'sec-ch-ua-platform': '"Windows"', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', 'Sec-Fetch-Site': 'none', 'Upgrade-Insecure-Requests': '1', 'Sec-Fetch-Mode': 'navigate', 'Sec-Fetch-User': '?1', 'Sec-Fetch-Dest': 'document', 'Accept-Encoding': 'gzip, deflate', 'Accept-Language': 'en-US,en;q=0.9', }}
firef_browser = {'cipher_suite': cipher_suite, 'headers': {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8', 'Accept-Language': 'en-US,en;q=0.5', 'Accept-Encoding': 'gzip, deflate', 'Upgrade-Insecure-Requests': '1', 'Sec-Fetch-Dest': 'document', 'Sec-Fetch-Mode': 'navigate', 'Sec-Fetch-Site': 'none', 'Sec-Fetch-User': '?1', 'TE': 'Trailers', }}
random_browser = random.choice((chrome_browser, firef_browser))
CHUNK_SIZE = 64 * 1024
OPEN_SESSIONS = []
DEFAULT_USERAGENT = 'okhttp/4.9.3'
DNS_OVERRIDE_DOMAINS = ['slyguy.uk', 'i.mjh.nz', 'dai.google.com']
DNS_OVERRIDE_SERVER = '1.1.1.1' # format('1.1.1.1' if KODI_VERSION >= 19 else 'cloudflare-dns.com')
INVALID_IPS = ['0.0.0.0', '::']
try:
    from openscrapers.modules.control import getKodiVersion, dataPath, addonId, setting
    KODI_VERSION = getKodiVersion()
    ADDON_PROFILE, ADDON_ID = dataPath, addonId
    http_retries, cache_resp, proxy_server, http_timeout, verify_ssl = int(setting('http_retries') or 2), setting('cache_resp') == 'true', 'kodi', int(setting('http_timeout') or 10), True
except:
    KODI_VERSION, ADDON_PROFILE, ADDON_ID = 21, '', ''
    http_retries, cache_resp, proxy_server, http_timeout, verify_ssl = 2, True, 'kodi', 20, True

common_settings = {'only_ipv4': 'only_ipv4'}
COMMON_ADDON = {'id': '', 'profile': ''}

"""
    from session import Session
useges:
    data = Session().request('get', DATA_URL)
    OR
    data = cache.get(Session().request, 1, 'get', DATA_URL)
    OR
    url = Session().head(url).headers.get('location', '')
    OR
    data = Session().gz_json(DATA_URL)
"""


def get_kodi_proxy():
    usehttpproxy = {'network.usehttpproxy': False, 'network.httpproxytype': 'https', 'network.httpproxyserver': '', 'network.httpproxyport': '', 'network.httpproxyusername': '', 'network.httpproxypassword': ''}
    # usehttpproxy = usehttpproxy.get('network.usehttpproxy')
    if usehttpproxy.get('network.usehttpproxy') is not True: return None
    try: httpproxytype = int(usehttpproxy.get('network.httpproxytype'))
    except ValueError: httpproxytype = 0
    proxy_types = ['http', 'socks4', 'socks4a', 'socks5', 'socks5h']
    proxy = dict(scheme=proxy_types[httpproxytype] if 0 <= httpproxytype < 5 else 'http', server=usehttpproxy.get('network.httpproxyserver'), port=usehttpproxy.get('network.httpproxyport'), username=usehttpproxy.get('network.httpproxyusername'), password=usehttpproxy.get('network.httpproxypassword'), )
    if proxy.get('username') and proxy.get('password') and proxy.get('server') and proxy.get('port'): proxy_address = '{scheme}://{username}:{password}@{server}:{port}'.format(**proxy)
    elif proxy.get('username') and proxy.get('server') and proxy.get('port'): proxy_address = '{scheme}://{username}@{server}:{port}'.format(**proxy)
    elif proxy.get('server') and proxy.get('port'): proxy_address = '{scheme}://{server}:{port}'.format(**proxy)
    elif proxy.get('server'): proxy_address = '{scheme}://{server}'.format(**proxy)
    else: return None
    return proxy_address


def _get_url(url):
    # log(f'Request DNS URL: {url}')
    data = cache.get(requests.get, 24, url)
    return data


def _load_rewrites(directory):
    rewrites = []
    file_names = ['urls.txt', 'dns_rewrites.txt', ]
    found = False
    for name in file_names:
        try: file_path = os.path.join(translatePath(directory), name)
        except: file_path = f'F:/GitHub/repo_testing/matrix_plus_testing/M_repository.jpb/openscraper/script.module.openscrapers/{name}'
        if os.path.exists(file_path):
            found = True
            break
    if not found: return rewrites

    try:
        def _process_lines(lines):
            for line in lines:
                entry = line.strip()
                if not entry or entry.startswith('#'): continue
                entries = [x.strip() for x in entry.split() if x.strip()]
                if len(entries) == 1 and entries[0].lower().startswith('http'):
                    text = _get_url(entry)
                    _process_lines(text.split('\n'))
                    continue
                if len(entries) < 2: continue
                rewrites.append(entries)
        with open(file_path, 'r') as f:
            text = f.read()
        _process_lines(text.split('\n'))
    except Exception as e: log(f'Error: {e} DNS Rewrites Failed: {print_exc()}')
    return rewrites


def get_dns_rewrites(dns_rewrites=None):
    rewrites = _load_rewrites(ADDON_PROFILE)

    if COMMON_ADDON.get('id') != ADDON_ID:
        rewrites.extend(_load_rewrites(COMMON_ADDON.get('profile')))
    if dns_rewrites: rewrites.extend(dns_rewrites)

    # add some defaults that are often blocked by networkwide dns
    # rewrites.extend([['r:https://cloudflare-dns.com/dns-query', 'dai.google.com'],])
    # if rewrites: log(f'Rewrites Loaded: {len(rewrites)}')
    for domain in DNS_OVERRIDE_DOMAINS:
        rewrites.append(['r:{}'.format(DNS_OVERRIDE_SERVER), domain])
    return rewrites



class IPMode:
    SYSTEM_DEFAULT = 'system_default'
    PREFER_IPV4 = 'prefer_ipv4'
    PREFER_IPV6 = 'prefer_ipv6'
    ONLY_IPV4 = 'only_ipv4'
    ONLY_IPV6 = 'only_ipv6'


class Error(Exception):
    def __init__(self, message='', heading=None):
        self.message = message
        self.heading = heading or 'Infinite'
        super(Error, self).__init__(message)


class SessionError(Error):
    pass


def json_override(func, error_msg):
    try: return func()
    except Exception as e: raise SessionError(f'error_msg: {error_msg} e: {e}')


def remove_duplicates(seq):
    seen = set()
    return [x for x in seq if not (x in seen or seen.add(x))]

def close_sessions():
    for session in OPEN_SESSIONS:
        session.close()


class DOHResolver(object):
    def __init__(self, nameservers=None):
        self.nameservers = nameservers or []

    def resolve(self, host, family, interface_ip=None):
        ip_type = 'AAAA' if family == socket.AF_INET6 else 'A'
        for server in self.nameservers:
            key = (server, host, ip_type)
            ips = cache.get(key)

            if ips is None:
                headers = {'accept': 'application/dns-json'}
                params = {'name': host, 'type': ip_type}
                log(f'DOH Request: {server} for {host} type {ip_type}')
                try:
                    session = RawSession(ip_mode=IPMode.ONLY_IPV6 if ip_type == 'AAAA' else IPMode.ONLY_IPV4, interface_ip=interface_ip)
                    data = super(RawSession, session).request('get', server, params=params, headers=headers).json()
                except Exception as e:
                    log(f'DOH request failed: {e}')
                    continue

                ip_type = 28 if ip_type == 'AAAA' else 1
                suitable = [x for x in data['Answer'] if x['type'] == ip_type]
                ttl = min([x['TTL'] for x in suitable])
                ips = [x['data'] for x in suitable]
                cache.cache_insert(key, ips, expires=ttl)
            if ips: return ips
        # raise SessionError(f'Unable to resolve host: {host} with nameservers: {self.nameservers}')
        return []


class SocketResolver(object):
    def __init__(self):
        self.nameservers = ['system dns']

    def resolve(self, host, family, interface_ip=None):
        if interface_ip:
            log(f'DNS leak! DNS request sent using default interface and not specified "{interface_ip}". Specify a DNS server in smart urls to fix')

        try:
            return [x[4][0] for x in socket.getaddrinfo(host, None, family)]
        except:
            return []


# class DNSResolver(dns.resolver.Resolver):
#     def resolve(self, host, family, interface_ip=None):
#         try: return [x.to_text() for x in self.query(host, rdtype='AAAA' if family == socket.AF_INET6 else 'A', source=interface_ip)]
#         except: return []


class SessionAdapter(HTTPAdapter):
    def __init__(self):
        self.session_data = {}
        self._context_cache = {}
        super(SessionAdapter, self).__init__()

    def send(self, *args, **kwargs):
        try:
            return super(SessionAdapter, self).send(*args, **kwargs)
        except ConnectionError as e:
            error(f'Connection error: {e}. Retrying...')
            # retry on connectionerror (pool or socket closed)
            return super(SessionAdapter, self).send(*args, **kwargs)

    def init_poolmanager(self, *args, **kwargs):
        # Set keep alive socket options
        # Stolen from https://github.com/requests/toolbelt/blob/master/requests_toolbelt/adapters/socket_options.py#L74
        idle = 60
        interval = 20
        count = 5

        kwargs['socket_options'] = [
            (socket.IPPROTO_TCP, socket.TCP_NODELAY, 1),
            (socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1),
        ]

        # OSX does not have these constants defined, so we set them conditionally.
        if getattr(socket, 'TCP_KEEPINTVL', None) is not None:
            kwargs['socket_options'] += [(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL,
                                interval)]
        elif sys.platform == 'darwin':
            # On OSX, TCP_KEEPALIVE from netinet/tcp.h is not exported
            # by python's socket module
            TCP_KEEPALIVE = getattr(socket, 'TCP_KEEPALIVE', 0x10)
            kwargs['socket_options'] += [(socket.IPPROTO_TCP, TCP_KEEPALIVE, interval)]

        if getattr(socket, 'TCP_KEEPCNT', None) is not None:
            kwargs['socket_options'] += [(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, count)]

        if getattr(socket, 'TCP_KEEPIDLE', None) is not None:
            kwargs['socket_options'] += [(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, idle)]
        #######################
        super(SessionAdapter, self).init_poolmanager(*args, **kwargs)
        self.poolmanager.connection_from_pool_key = functools.partial(self.connection_from_pool_key, self.poolmanager.connection_from_pool_key)

    def proxy_manager_for(self, *args, **kwargs):
        manager = super(SessionAdapter, self).proxy_manager_for(*args, **kwargs)
        manager.connection_from_pool_key = functools.partial(self.connection_from_pool_key, manager.connection_from_pool_key)
        return manager

    def connection_from_pool_key(self, func, pool_key, request_context):
        context_key = (self.session_data['ssl_ciphers'], self.session_data['ssl_options'])
        context = self._context_cache.get(context_key)
        if not context:
            context = urllib3.util.ssl_.create_urllib3_context(
                ciphers=self.session_data['ssl_ciphers'],
                options=self.session_data['ssl_options'],
            )
            #loads in any windows certstore certs (eg business proxy)
            context.load_default_certs()
        request_context['ssl_context'] = self._context_cache[context_key] = context
        pool_key = pool_key._replace(key_ssl_context=context_key)

        if self.session_data['interface_ip']:
            request_context['source_address'] = (self.session_data['interface_ip'], 0)
            pool_key = pool_key._replace(key_source_address=request_context['source_address'])

        # ensure we get a unique pool (socket) for same domain on different rewrite ips
        if self.session_data['rewrite'] and self.session_data['rewrite'][0] == request_context['host']:
            pool_key = pool_key._replace(key_server_hostname=self.session_data['rewrite'][1])

        # ensure we get a unique pool (socket) for same domain on different resolvers
        if self.session_data['resolver'] and self.session_data['resolver'][0] == request_context['host']:
            pool_key = pool_key._replace(key_server_hostname=self.session_data['resolver'][1].nameservers[0])

        pool = func(pool_key, request_context)
        pool._new_conn = functools.partial(self._new_pool_conn, pool._new_conn)
        return pool

    def _new_pool_conn(self, func, *args, **kwargs):
        conn = func(*args, **kwargs)
        conn.connect = functools.partial(self.connect, conn.connect, conn)
        conn.getaddrinfo = self.getaddrinfo
        return conn

    def connect(self, func, conn, *args, **kwargs):
        retval = func(*args, **kwargs)
        ip, port = conn.sock.getpeername()[:2]
        # if hasattr(conn.sock, 'server_hostname'): log(f'Opening secure connection on port: {port} to IP: {ip} cipher: {conn.sock.cipher()}')
        # else: log(f'Opening connection on port: {port} to IP: {ip}')
        return retval

    def getaddrinfo(self, host, port, family=0, type=0):
        resolvers = []

        if self.session_data['rewrite'] and self.session_data['rewrite'][0] == host:
            host = self.session_data['rewrite'][1]
            log(f'DNS Rewrite: -> {host} -> {host}')
        elif self.session_data['resolver'] and self.session_data['resolver'][0] == host:
            resolvers.append(self.session_data['resolver'][1])
        # fallback to socket resolver
        resolvers.append(SocketResolver())

        def is_ip(address):
            return not address.split('.')[-1].isalpha()

        def resolve(host):
            if is_ip(host): return [host]

            if self.session_data['ip_mode'] == IPMode.ONLY_IPV4: families = (socket.AF_INET,)
            elif self.session_data['ip_mode'] == IPMode.ONLY_IPV6: families = (socket.AF_INET6,)
            elif self.session_data['ip_mode'] == IPMode.PREFER_IPV6: families = (socket.AF_INET6, socket.AF_INET)
            else: families = (socket.AF_INET, socket.AF_INET6)

            for resolver in resolvers:
                for address_family in families:
                    if not address_family: continue
                    start = time()
                    ips = remove_duplicates(resolver.resolve(host, family=address_family, interface_ip=self.session_data['interface_ip']))
                    ips = [ip for ip in ips if ip not in INVALID_IPS]
                    if ips:
                        log(f'DNS Resolve: {host} -> {", ".join(resolver.nameservers)} -> {", ".join(ips)} ({time()-start:.5f}s)')
                        return ips
            raise gaierror(f'Unable to resolve host: {host} using ip mode: {self.session_data["ip_mode"]}')

        ips = resolve(host)
        # convert ips into correct object
        addresses = []
        for ip in ips:
            addresses.extend(socket.getaddrinfo(ip, port, family, type))
        return addresses


class RawSession(requests.Session):
    def __init__(self, verify=None, timeout=None, auto_close=True, ssl_ciphers=None, ssl_options=SSL_OPTIONS, proxy=None, ip_mode=None, interface_ip=None):
        super(RawSession, self).__init__()
        self._verify = verify
        self._timeout = timeout
        self._rewrites = []
        self._session_cache = {}
        self._proxy = proxy
        self._ip_mode = ip_mode
        self._interface_ip = interface_ip
        self._cert = None
        _browser = random_browser
        # log(f'using::: {_browser}')
        if not ssl_ciphers: ssl_ciphers = _browser.get('cipher_suite')
        self.headers = _browser.get('headers')
        self._ssl_ciphers = ssl_ciphers if verify else []
        self._ssl_options = ssl_options if verify else []

        if auto_close:
            OPEN_SESSIONS.append(self)

        self._adapter = SessionAdapter()
        for prefix in ('http://', 'https://'):
            self.mount(prefix, self._adapter)

        session_data = {
            'ip_mode': self._ip_mode,
            'interface_ip': self._interface_ip,
            'ssl_ciphers': self._ssl_ciphers,
            'ssl_options': self._ssl_options,
            'proxy': None,
            'rewrite': None,
            'resolver': None,
            'url': None,
        }
        self._adapter.session_data = session_data

    def set_dns_rewrites(self, rewrites):
        for entries in rewrites:
            pattern = entries[-1]
            pattern = re.escape(pattern).replace(r'\*', '.*')
            pattern = re.compile(pattern, flags=re.IGNORECASE)

            new_entries = []
            for entry in entries[:-1]:
                _type = 'skip'
                if entry.startswith('p:'):
                    _type = 'proxy'
                    entry = entry[2:]
                elif entry.startswith('r:'):
                    _type = 'resolver'
                    entry = entry[2:]
                elif entry.startswith('i:'):
                    _type = 'interface_ip'
                    entry = entry[2:]
                elif entry.startswith('d:'):
                    _type = 'dns'
                    entry = entry[2:]
                elif entry.startswith('s:'):
                    _type = 'url_sub'
                    entry = entry[2:]
                # legacies
                elif entry[0].isdigit(): _type = 'dns'
                else: _type = 'url_sub'
                new_entries.append([_type, entry])
            # Make sure dns is done last
            self._rewrites.append([pattern, sorted(new_entries, key=lambda x: x[0] == 'dns')])

    def set_cert(self, cert):
        self._cert = cert
        if cert: log(f'SSL CERT SET TO: {cert}')

    def _get_cert(self):
        if not self._cert: return None

        if self._cert.lower().startswith('http'):
            url = self._cert
            self._cert = None
            log(f'Downloading cert: {url}')
            resp = self.request('get', url, stream=True)
            self._cert = translatePath('special://temp/temp.pem')
            with open(self._cert, 'wb') as f:
                shutil.copyfileobj(resp.raw, f)
        return translatePath(self._cert)

    def set_proxy(self, proxy):
        self._proxy = proxy

    def _get_proxy(self):
        if not self._proxy or self._proxy.lower().strip() == 'kodi': self._proxy = get_kodi_proxy()
        return self._proxy

    def close(self):
        super(RawSession, self).close()
        if self in OPEN_SESSIONS:
            OPEN_SESSIONS.remove(self)

    def __del__(self):
        self.close()

    def request(self, method, url, **kwargs):
        req = requests.Request(method, url, params=kwargs.pop('params', None))
        url = req.prepare().url

        session_data = {
            'ip_mode': self._ip_mode,
            'interface_ip': self._interface_ip,
            'ssl_ciphers': self._ssl_ciphers,
            'ssl_options': self._ssl_options,
            'proxy': None,
            'rewrite': None,
            'resolver': None,
            'url': url,
        }

        if url in self._session_cache:
            session_data = self._session_cache[url]
        elif self._rewrites:
            for row in self._rewrites:
                if not row[0].search(url): continue
                for entry in row[1]:
                    if entry[0] == 'skip': continue
                    if entry[0] == 'url_sub': session_data['url'] = re.sub(row[0], entry[1], url, count=1)
                    elif entry[0] == 'proxy': session_data['proxy'] = entry[1]
                    elif entry[0] == 'interface_ip':
                        session_data['interface_ip'] = entry[1]
                    elif entry[0] == 'dns': session_data['rewrite'] = [urlparse(session_data['url']).netloc.lower(), entry[1]]
                    elif entry[0] == 'resolver' and entry[1]:
                        resolver = DOHResolver()
                        # if entry[1].lower().startswith('http'): resolver = DOHResolver()
                        # else:
                        #     resolver = DNSResolver(configure=False)
                        #     resolver.cache = DNS_CACHE
                        resolver.nameservers = [entry[1], ]
                        session_data['resolver'] = [urlparse(session_data['url']).netloc.lower(), resolver]
                break

            self._session_cache[url] = session_data

        if session_data['url'] != url:
            log("URL Changed: {}".format(session_data['url']))

        if session_data['proxy'] is None:
            session_data['proxy'] = self._get_proxy()

        if session_data['proxy']:
            # remove username, password from proxy for logging
            parsed = urlparse(session_data['proxy'])
            replaced = parsed._replace(netloc=f'{"username"}:{"password"}@{parsed.hostname}' if parsed.username else parsed.hostname)
            log(f'Proxy: {replaced.geturl()}:{parsed.port}')
            kwargs['proxies'] = {'http': session_data['proxy'], 'https': session_data['proxy'], }
        if self._cert:
            kwargs['verify'] = False
            kwargs['cert'] = self._get_cert()

        self._adapter.session_data = session_data

        if 'verify' not in kwargs: kwargs['verify'] = self._verify
        if 'timeout' not in kwargs: kwargs['timeout'] = self._timeout

        # Do request
        try: result = super(RawSession, self).request(method, session_data['url'], **kwargs)
        except requests.exceptions.ConnectionError as e:
            # log.exception(e)
            raise SessionError(f'error: {e} Failed to connect to host: {urlparse(session_data["url"]).netloc.lower()}')
            # if session_data['proxy']: raise SessionError(_(_.CONNECTION_ERROR_PROXY, host=urlparse(session_data['url']).netloc.lower()))
            # else: raise SessionError(_(_.CONNECTION_ERROR, host=urlparse(session_data['url']).netloc.lower()))
        return result


class Cresponse():
    """ Adding Attribute to cache response return"""
    pass


class Session(RawSession):
    def __init__(self, headers=None, cookies_key=None, base_url='{}', timeout=None, attempts=None, verify=None, dns_rewrites=None, auto_close=True, return_json=False, **kwargs):
        super(Session, self).__init__(verify=verify_ssl if verify is None else verify, timeout=http_retries if timeout is None else timeout, auto_close=auto_close, ip_mode=common_settings.get('only_ipv4', 'only_ipv4'), **kwargs)

        self._headers = headers or {}
        self._cookies_key = cookies_key
        self._base_url = base_url
        self._attempts = http_retries if attempts is None else attempts
        self._return_json = return_json
        self.before_request = None
        self.after_request = None
        self.cache_resp = cache_resp
        self.set_dns_rewrites(get_dns_rewrites() if dns_rewrites is None else dns_rewrites)
        self.set_proxy(proxy_server or None)
        # self.headers.update({'User-Agent': DEFAULT_USERAGENT})
        self.headers.update(self._headers)
        self.userdata = {}
        # log(f'self.headers: {self.headers}')
        if self._cookies_key: self.cookies.update(self.userdata.get(self._cookies_key, {}))

    def gz_json(self, *args, **kwargs):
        kwargs['return_json'] = False
        # log(f'gz_json args: {args}  kwargs: {kwargs}')
        resp = self.get(*args, **kwargs)
        # log(f'type result: {type(resp)} : {resp.text}')
        json_text = GzipFile(fileobj=BytesIO(resp.content)).read()
        return loads(json_text)

    def request(self, method, url, timeout=None, attempts=None, verify=None, error_msg=None, retry_not_ok=False, retry_delay=50, log_url=None, return_json=None, **kwargs):
        method = method.upper()

        if not url.startswith('http'): url = self._base_url.format(url)
        if self.cache_resp:
            data = cache.cache_get(url)
            # log(f'cache.cache_get data type: {type(data)} response.__dict__: {repr(data)}')
            if data:
                try: fdata = literal_eval(data['value'])
                except: fdata = eval(data['value'])
                # log(f'from cache type: {type(fdata)} response.__dict__: {repr(fdata)}')
                response = Cresponse()
                # content = fdata.get('_content')
                response.text = fdata.get('text')# content.decode(fdata.get('encoding') or 'UTF-8', errors='ignore')
                response.status_code = fdata.get('status_code')
                response.headers = fdata.get('headers')
                response.cookies = fdata.get('cookies')
                response.url = fdata.get('url')
                return response

        attempts = max(self._attempts if attempts is None else attempts, 1)
        return_json = self._return_json if return_json is None else return_json

        if timeout is not None: kwargs['timeout'] = timeout
        if verify is not None: kwargs['verify'] = verify

        for i in range(1, attempts + 1):
            if i > 1 and retry_delay: sleep(retry_delay)
            if self.before_request: self.before_request()
            try: resp = super(Session, self).request(method, url, **kwargs)
            except SessionError:
                log(f'attempt: {i}/{attempts} method :{method} url: {log_url or url}\nkwargs: {kwargs}')
                resp = None
                if i == attempts: raise
                else: continue
            except Exception as e:
                error(f'err: {e} attempt: {i}/{attempts} method: {method} url: {log_url or url}', __name__)
                resp = None
            if resp is None: raise SessionError(f'URL returned no response from url: {url}\nerror_msg {error_msg}')
            if retry_not_ok and not resp.ok: continue
            if i == attempts or resp.ok: break

            if return_json:
                try:
                    data = resp.json()
                except:
                    if i == attempts: raise
                    else: continue
                break

        resp.json = lambda func=resp.json, errormsg=error_msg: json_override(func, error_msg)

        if self.after_request:
            self.after_request(resp)
        if self.cache_resp:
            # log(f'set cache type: {type(resp)} response.__dict__: {repr(resp.__dict__)}')
            # try: _text = GzipFile(fileobj=BytesIO(resp.content)).read()
            # except: _text = resp.text
            # respo = resp.__dict__
            # myDict = {key: str(val) for key, val in respo.items() if key not in ('elapsed', 'raw', 'cookies', 'request', 'connection')}
            cache_resp = {'text': resp.text, 'status_code': resp.status_code, 'headers': resp.headers, 'url': resp.url, 'cookies': resp.cookies.get_dict()}
            # log(f'cache.cache_get data type: {type(cache_resp)} response.__dict__: {repr(cache_resp)}')
            cache.cache_insert(url, repr(cache_resp))
        if return_json: return data
        else: return resp

    def save_cookies(self):
        if not self._cookies_key: raise Exception('A cookies key needs to be set to save cookies')
        self.userdata.set(self._cookies_key, self.cookies.get_dict())

    def clear_cookies(self):
        if self._cookies_key: self.userdata.delete(self._cookies_key)
        self.cookies.clear()

    def chunked_dl(self, url, dst_path, method='GET', **kwargs):
        kwargs['stream'] = True
        kwargs['return_json'] = False
        resp = self.request(method, url, **kwargs)
        resp.raise_for_status()

        with open(dst_path, 'wb') as f:
            for chunk in resp.iter_content(CHUNK_SIZE):
                f.write(chunk)
        return resp