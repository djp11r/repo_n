# -*- coding: utf-8 -*-
import json
from random import choice

import requests
import time
from urllib.parse import quote
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.utils import get_datetime, make_tinyurl, make_qrcode, make_thread_list
from openscrapers.modules.client import make_session
from openscrapers.modules.control import setting, setSetting, notification, selectDialog, progressDialog, sleep
from openscrapers.windows.base import getProgressWindow
API_URL = 'https://api.themoviedb.org/3/'
ART_URL = 'https://image.tmdb.org/t/p/original'
HEADERS = {'Content-Type': 'application/json;charset=utf-8'}
API_KEY = 'c8b7db701bac0b26edfcc93b39858972'
timeout = 3.05
session = make_session('https://api.themoviedb.org')

def find_movie_by_external_source(imdb):
    try:
        url = f'{API_URL}find/{imdb}?api_key={API_KEY}&language=en-US&external_source=imdb_id'
        result = requests.get(url, headers=HEADERS).json()
        return result['movie_results'][0]
    except Exception as err:
        error(f'find_movie_by_external_source: {err}')
        return


def find_tvshow_by_external_source(imdb=None, tvdb=None):
    try:
        if imdb: url = f'{API_URL}find/{imdb}?api_key={API_KEY}&language=en-US&external_source=imdb_id'
        elif tvdb: url = f'{API_URL}find/{tvdb}?api_key={API_KEY}&language=en-US&external_source=tvdb_id'
        result = requests.get(url, headers=HEADERS).json()
        return result['tv_results'][0]
    except Exception as err:
        error(f'find_tvshow_by_external_source: {err}')
        return


def clean_title_to_comparisons(string):
    """
        Method that takes a string and returns it cleaned of any special characters in order to do proper string comparisons
    """
    try: return ''.join(e for e in string.lower() if e.isalnum())
    except: return string


def clean_title_to_search(title):
    ftitle = ''
    for word in title.split(' '):
        if word.isalnum() is False:
            w = ""
            for i in range(len(word)):
                if word[i].isalnum():
                    w += word[i]
            word = w
        ftitle += ' ' + word
    return ftitle.strip()


def get_query(title):
    title = title.lower()
    if 'superstar singer' in title: return 'superstar singer'
    elif 'dance deewane' in title: return 'dance deewane'
    elif 'india got talent' in title: return 'india got talent'
    elif 'jhalak dikhhla jaa' in title: return 'jhalak dikhhla jaa'
    elif 'crime patrol' in title: return 'crime patrol'
    elif 'indias best dancer' in title: return 'indias best dancer'
    elif 'kaun banega crorepati' in title: return 'kaun banega crorepati'
    elif 'bigg boss ott' in title: return 'bigg boss ott'
    elif 'bigg boss' in title: return 'bigg boss'
    elif 'indian idol' in title: return 'indian idol'
    elif 'the kapil sharma show' in title: return 'the kapil sharma show'
    return title


def _do_tmdb_request(values, method='search/multi', lang='en'):
    api_key = choice(['d848316a33e79095beb945a2bd2d53b1', '8877595a1e6647d272148c99133df1fb', 'bc96b19479c7db6c8ae805744d0bdfe2', 'b370b60447737762ca38457bd77579b3', 'edde6b5e41246ab79a2697cd125e1781', 'c8b7db701bac0b26edfcc93b39858972', 'af3a53eb387d57fc935e9128468b1899']) # 6a5be4999abf74eba1f9a8311294c267
    url = f'http://api.themoviedb.org/3/{method}?language={lang}&api_key={api_key}&{values}'
    try: response = requests.get(url, headers=HEADERS, timeout=20)
    except: response = None
    data = response.json()
    # log(f'from method: {method} values: {values} url: {url}\ndata: {data}')
    return data


def tmdb_search(query, season=1, only_tmbdid=True):
    """
    :param query:
    :return: dict for meta
    """

    query_part = query.split('|')
    if query_part[1].isdigit(): title, year, media_type, runtime = query_part[0], query_part[1], 'movie', 120
    else: title, year, media_type, runtime = query_part[1], None, 'tvshow', 30
    name = get_query(title)
    tmdb_id = None
    if year: name = name + '&year=' + year
    else: name, year = name, str(get_datetime().year)
    # log(f'name: {name} title: {title} year: {year}')
    meta = _do_tmdb_request('query=' + name, 'search/multi')
    data_get = meta.get
    if meta and data_get('total_results') == 1 and data_get('results'):
        tmdb_id = data_get('results')[0].get('id')
        media_type = data_get('results')[0].get('media_type')
    elif meta and data_get('total_results') > 1 and data_get('results'):
        results = [r for r in data_get('results') if (r.get('title') and clean_title_to_comparisons(r.get('title').lower()) in clean_title_to_comparisons(name.lower())) and r.get('release_date', '0000')[:4] == year]
        if not results: results = [r for r in data_get('results') if (r.get('name') and clean_title_to_comparisons(r.get('name').lower()) in clean_title_to_comparisons(name.lower()))]
        if len(results) > 1:
            fresults = [r for r in results if r.get('original_language') != 'en']
            if len(fresults) > 0:
                tmdb_id = fresults[0].get('id')
                media_type = fresults[0].get('media_type')
            else:
                tmdb_id = results[0].get('id')
                media_type = results[0].get('media_type')
        elif len(results) == 1:
            tmdb_id = results[0].get('id')
            media_type = results[0].get('media_type')
    # log(f'{repr(tmdb_id)}, {repr(media_type)}, {repr(title)}, {repr(query)}, {repr(year)}, {repr(season)}, {repr(runtime)}')
    if only_tmbdid: return tmdb_id
    else: return get_meta_tmbd(tmdb_id, media_type, title, query, year, season, runtime)


def get_meta_tmbd(tmdb_id, media_type, title, query, year, season, runtime):
    md = None
    if tmdb_id:
        tmdb_image_url = 'https://image.tmdb.org/t/p/'
        # Attempt to grab all info in one request
        extra_append = 'append_to_response=casts,trailers,external_ids,videos,credits,content_ratings,release_dates,alternative_titles,translations,images'
        meta = _do_tmdb_request(extra_append, f'{media_type}/{tmdb_id}')
        # log(f'meta: {meta}')
        if meta is not None: # Parse out extra info from request
            data_get = meta.get
            cast, writer, director, studio, trailer, all_trailers, country, country_codes, alternative_titles = [], [], [], [], [], [], [], [], []
            mpaa, spoken_language = 'NR', ''
            title = title.title()
            # if not data_get('title'): title = title.title()
            # else: title = data_get('title')
            if production_countries := data_get('production_countries'):
                country = [i['name'] for i in production_countries]
                country_codes = [i['iso_3166_1'] for i in production_countries]
            if spoken_languages := data_get('spoken_languages'):
                try: spoken_language = spoken_languages[0]['english_name']
                except: pass
            if companies := data_get('networks') or data_get('production_companies'):
                if len(companies) == 1: studio = ([i['name'] for i in companies][0],)
                else:
                    try: studio = (next(i['name'] for i in companies if i['logo_path'] not in empty_value_check) or next(i['name'] for i in companies),)
                    except: pass
            if alternative_titles := data_get('alternative_titles'):
                alternatives = alternative_titles.get('titles') or alternative_titles.get('results') or []
                alternative_titles = [i['title'] for i in alternatives if i['iso_3166_1'] in ('US', 'GB', 'UK', 'IN', '')] if alternatives else []

            premiered = data_get('release_date') or data_get('first_air_date')
            media_type = 'tvshow' if media_type != 'movie' else 'movie'
            md = {'tmdb_id': str(data_get('id')), 'tvdb_id': query,
                'title': title, 'tagline': data_get('tagline'), 'mediatype': media_type,
                'plot': data_get('overview'), 'country': country,
                'studio': studio, 'mpaa': mpaa, 'rating': data_get('vote_average'),
                'votes': data_get('vote_count'), 'premiered': premiered,
                'duration': runtime * 60, 'year': year, 'alternative_titles': alternative_titles, 'country_codes': country_codes, 'spoken_language': spoken_language,
                'genre': [], 'cast': [], 'director': [], 'writer': [], 'trailer': [], 'all_trailers': []}

            iddata = data_get('external_ids')
            imdb_id = iddata.get('imdb_id') if iddata else query
            md.update({'imdb_id': imdb_id, 'imdbnumber': imdb_id, })
            if premiered: md.update({'year': str(premiered[:4])})
            if data_get('runtime'): md.update({'duration': data_get('runtime') * 60})
            if data_get('episode_run_time'): md.update({'duration': data_get('episode_run_time')[0] * 60})

            if casts := data_get('casts') or data_get('credits'):
                if casts.get('cast'):
                    cast = [{'name': x.get('name') or 'none', 'role': x.get('character'), 'thumbnail': f'{tmdb_image_url}w138_and_h175_face{x.get("profile_path")}'} for x in casts['cast']]
                    md.update({'cast': cast[:10]})
                if crew := casts.get('crew'):
                    try: writer = [i['name'] for i in crew if i['job'] in ('Author', 'Writer', 'Screenplay', 'Characters')]
                    except: pass
                    try: director = [i['name'] for i in crew if i['job'] == 'Director']
                    except: pass
                    md.update({'director': director, 'writer': writer})

            if genres := data_get('genres'):
                genre = [x.get('name') for x in genres]
                md.update({'genre': genre})

            if trailers := data_get('videos') or data_get('trailers'):
                all_trailers = trailers.get('results') or trailers.get('youtube') or []
                try: trailer = ['plugin://plugin.video.youtube/play/?video_id=%s' % i['key'] for i in all_trailers if i['site'] == 'YouTube' and i['type'] in ('Trailer', 'Teaser')][0]
                except: pass
                md.update({'trailer': trailer, 'all_trailers': all_trailers})

            if poster_path := data_get('poster_path'): md.update({'poster': f'{tmdb_image_url}w500{poster_path}'})
            if backdrop_path := data_get('backdrop_path'): md.update({'fanart': f'{tmdb_image_url}w1280{backdrop_path}'})
            if media_type == 'movie': md['extra_info'] = {'status': data_get('status'), 'budget': data_get('budget') or '$0', 'revenue': data_get('revenue') or '$0', 'homepage': data_get('homepage'), 'collection_name': data_get('collection_name'), 'collection_id': data_get('collection_id')}
            else:
                season_n = data_get('number_of_seasons') or data_get('seasons')
                # log(f'season_n: {season_n}')
                if not season_n: season_n = 1
                if isinstance(season_n, list): season_n = len(season_n)
                if season_n > season: season = season_n
                created_by = data_get('created_by', None)
                try: ei_created_by = ', '.join([i['name'] for i in created_by])
                except: ei_created_by = 'N/A'
                extra_info = {'status': data_get('status'), 'homepage': data_get('homepage'), 'created_by': ei_created_by, 'type': data_get('type'), 'last_episode_to_air': data_get('last_episode_to_air'), 'next_episode_to_air': data_get('next_episode_to_air')}
                md.update({'tvshowtitle': title, 'seasons': season_n, 'season': season, 'extra_info': extra_info, 'season_data': data_get('seasons') or [], 'total_aired_eps': data_get('number_of_episodes') or 1})
        # log(f'md: {md}')
    return md



def convert_to_session_id(token=None):
    if not setting('tmdb.token') and not token: return
    read_token, access_token = setting('tmdb_read_token'), token or setting('tmdb.token')
    headers = {'Authorization': f'Bearer {read_token}'}
    data = {'access_token': access_token}
    url = 'https://api.themoviedb.org/3/authentication/session/convert/4'
    response = requests.post(url, data=data, headers=headers, timeout=4)
    result = response.json()
    if not result['success']: return
    session_id = result['session_id']
    params = {'session_id': session_id}
    url = 'https://api.themoviedb.org/3/account'
    response = requests.get(url, params=params, headers=headers, timeout=4)
    result = response.json()
    if not 'id' in result: return
    username, session_account_id = str(result['username']), str(result['id'])
    setSetting('tmdb.user', username)
    setSetting('tmdb.session_id', session_id)
    setSetting('tmdb.session_account_id', session_account_id)
    return session_account_id, session_id


def authorize():
    read_token = setting('tmdb_read_token')
    headers = {'Authorization': f"Bearer {read_token}"}
    url = 'https://api.themoviedb.org/4/auth/request_token'
    response = requests.post(url, headers=headers, timeout=4)
    result = response.json()
    if not result['success']: return
    url = 'https://www.themoviedb.org/auth/access?request_token=%s' % result['request_token']
    qr_url = '&data=%s' % quote(url)
    qr_icon = 'https://api.qrserver.com/v1/create-qr-code/?size=256x256&qzone=1%s' % qr_url
    tiny_url = 'http://tinyurl.com/api-create.php'
    try: tiny_url = requests.get(tiny_url, params={'url': url}, timeout=4).text
    except: pass
    log(f'tmdblist {tiny_url}\n{url}')
    choices = [f'Step 1: For approve access at TMDB\n            Navigate to: {tiny_url}', 'Step 2: Access approved at TMDB', 'Cancel']
    choice = selectDialog([i for i in choices], 'TMDBList')
    if choice != 1: return
    data = {'request_token': result['request_token']}
    url = 'https://api.themoviedb.org/4/auth/access_token'
    response = requests.post(url, json=data, headers=headers, timeout=4)
    result = response.json()
    if not result['success']: return notification('Error')
    access_token = str(result['access_token'])
    setSetting('tmdb.account_id', str(result['account_id']))
    setSetting('tmdb.token', access_token)
    notification('Success TMDBList')
    convert_to_session_id(access_token)


def deauthorize():
    read_token, access_token = setting('tmdb_read_token'), setting('tmdb.token')
    headers = {'Authorization': f"Bearer {read_token}"}
    data = {'access_token': access_token}
    url = 'https://api.themoviedb.org/4/auth/access_token'
    response = requests.delete(url, json=data, headers=headers, timeout=4)
    result = response.json()
    if not result['success']: return notification('Error')
    setSetting('tmdb.account_id', '')
    setSetting('tmdb.token', '')
    notification('Success TMDBList')
    # clear_tmdbl_cache()


class TMDbListAPI:
    def __init__(self):
        self.base_url = 'https://api.themoviedb.org/4'
        self.read_access_token = setting('tmdb_read_token') or 'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJkODQ4MzE2YTMzZTc5MDk1YmViOTQ1YTJiZDJkNTNiMSIsIm5iZiI6MTcxMTQ3Mzg1NC45MzQsInN1YiI6IjY2MDMwNGJlYjAyZjVlMDE3ZDIxNDAzZSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ._uRCLIwLIE2gOlH8q04gcM3ywIXpxuZ-uyel-UMRRg4'
        self.token = setting('tmdb.token')
        self.headers = {'Authorization': 'Bearer %s' % self.read_access_token}

    def base2_url(self, path):
        return 'https://api.themoviedb.org/%s' % path

    def auth(self):
        headers = {'accept': 'application/json', 'content-type': 'application/json', 'Authorization': 'Bearer %s' % self.read_access_token}
        data = requests.post(f'{self.base_url}/auth/request_token', headers=headers, timeout=20).json()
        if not 'success' in data: return notification('Failed to Auth Account')
        request_token = data['request_token']
        token_url = f'https://www.themoviedb.org/auth/access?request_token={request_token}'
        qr_code = make_qrcode(token_url, 'tmdb') or ''
        short_url = make_tinyurl(token_url)
        # copy2clip(short_url)
        if short_url: p_dialog_insert = f'Please Scan the QR Code[CR][CR]OR visit this URL: [B]{short_url}[/B]'
        else: p_dialog_insert = 'Please Scan the QR Code'
        progressD = getProgressWindow('TMDb Account Authorization', qr_code, 1)
        progressD.set_controls()
        progressD.update(0, p_dialog_insert)
        start = time.time()
        progress, expires_in, success = 0, 60 + time.time(), None
        while not progressD.iscanceled() and progress < expires_in:
            try:
                progres_ = '%02d:%02d' % divmod(expires_in - time.time(), 60)
                if progres_ == '00:00' or progressD.iscanceled(): break
                progress = max((time.time() - start), 0)
                response = requests.post(f'{self.base_url}/auth/access_token', json={'request_token': request_token}, headers=headers, timeout=20).json()
                if response.get('success') and response.get('access_token'): success = True; break
                progressD.update(progress, f'Remaining Time: [B]{progres_}[/B][CR]{p_dialog_insert}')
                sleep(500)
            except: success = False
        try: progressD.close()
        except: pass
        if success:
            self.token = response['access_token']
            setSetting('tmdb.token', self.token)
            setSetting('tmdb.account_id', response['account_id'])
            data = {'access_token': self.token}
            response = requests.post(self.base2_url('3/authentication/session/convert/4'), json=data, headers=self.headers, timeout=timeout)
            result = response.json()
            if not result['success']: return
            session_id = result['session_id']
            params = {'session_id': session_id}
            response = requests.get(self.base2_url('3/account'), params=params, headers=self.headers, timeout=timeout)
            result = response.json()
            if not 'id' in result: return
            username, session_account_id = str(result['username']), str(result['id'])
            setSetting('tmdb.user', username)
            setSetting('tmdb.session_id', session_id)
            setSetting('tmdb.session_account_id', session_account_id)
            notice = 'Success'
        else: notice = 'Failed'
        notification(notice)

    def revoke(self):
        import requests
        headers = {'accept': 'application/json', 'content-type': 'application/json', 'Authorization': 'Bearer %s' % self.read_access_token}
        data = requests.delete('%s/auth/access_token' % self.base_url, json={'access_token': self.read_access_token}, headers=headers, timeout=20).json()
        if not 'success' in data: notice = 'Failed to Revoke Account Auth'
        else:
            notice = 'Success Auth Revoke'
            setSetting('tmdb.token', '')
            setSetting('tmdb.account_id', '')
        return notification(notice)

    def get_user_lists(self):
        def _process_multi(page_no):
            try: results_extend(self.request_data(url % (self.base_url, account_id, page_no))['results'])
            except: pass
        def _process(dummy):
            result = self.request_data(url % (self.base_url, account_id, 1))
            results_extend(result['results'])
            total_pages = result['total_pages']
            if total_pages > 1:
                threads = list(make_thread_list(_process_multi, range(2, total_pages + 1)))
                [i.join() for i in threads]
            return results
        account_id = setting('tmdb.account_id')
        url = '%s/account/%s/lists?page=%s'
        results = []
        results_extend = results.extend
        return _process('d')

    def get_list_details(self, list_id):
        def _process_multi(page_no):
            try: results_extend(self.request_data(url % (self.base_url, list_id, page_no))['results'])
            except: pass
        def _process(dummy):
            result = self.request_data(url % (self.base_url, list_id, 1))
            results_extend(result['results'])
            total_pages = result['total_pages']
            if total_pages > 1:
                threads = list(make_thread_list(_process_multi, range(2, total_pages + 1)))
                [i.join() for i in threads]
            return results
        url = '%s/list/%s?page=%s'
        results = []
        results_extend = results.extend
        return _process('d')

    def add_remove_from_list(self, list_id, items, action):
        url = '%s/list/%s/items' % (self.base_url, list_id)
        return self.request_data(url, data=items, method=action)

    def make_list(self, list_name):
        url = '%s/list' % self.base_url
        return self.request_data(url, data={'description': '', 'name': list_name, 'iso_3166_1': 'US', 'iso_639_1': 'en', 'public': True}, method='post')

    def delete_list(self, list_id):
        url = '%s/list/%s' % (self.base_url, list_id)
        return self.request_data(url, method='delete')

    def rename_list(self, list_id, new_name):
        data = {'description': '', 'name': new_name, 'iso_3166_1': 'US', 'iso_639_1': 'en', 'public': True}
        url = '%s/list/%s' % (self.base_url, list_id)
        return self.request_data(url, data=data, method='put')

    def clear_list(self, list_id):
        url = '%s/list/%s/clear' % (self.base_url, list_id)
        return self.request_data(url)

    def item_status(self, list_id, media_type, media_id):
        url = '%s/list/%s/item_status' % (self.base_url, list_id)
        return self.request_data(url, params={'media_type': media_type, 'media_id': int(media_id)})

    def request_data(self, url, params=None, data=None, method='get'):
        headers = {'accept': 'application/json', 'content-type': 'application/json', 'Authorization': 'Bearer %s' % self.token}
        try: result = session.request(method, url, params=params, json=data, headers=headers, timeout=90).json()
        except: result = None
        return result


tmdb_list_api = TMDbListAPI()