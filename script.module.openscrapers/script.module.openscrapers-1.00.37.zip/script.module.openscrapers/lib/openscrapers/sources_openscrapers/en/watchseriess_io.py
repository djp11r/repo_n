# -*- coding: UTF-8 -*-

import re

from openscrapers import parse_qs, urlencode

from openscrapers.modules import client
from openscrapers.modules import client_utils
from openscrapers.modules import cleantitle
from openscrapers.modules import scrape_sources
from openscrapers.modules import log_utils


class source:
    def __init__(self):
        self.results = []
        self.domains = ['watchseriess.io', 'watchseriess.net']
        self.base_link = 'https://watchseriess.io'
        self.search_link = '/watchseries/ajax/search?keyword=%s'
        self.headers = {'User-Agent': client.randomagent(), 'Referer': self.base_link}


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'aliases': aliases, 'year': year}
            url = urlencode(url)
            return url
        except:
            #log_utils.log('movie', 1)
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvshowtitle': tvshowtitle, 'aliases': aliases, 'year': year}
            url = urlencode(url)
            return url
        except:
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            return


    def sources(self, url, hostDict):
        try:
            if url is None:
                return self.results
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            aliases = eval(data['aliases'])
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            season, episode = (data['season'], data['episode']) if 'tvshowtitle' in data else ('0', '0')
            year = data['premiered'].split('-')[0] if 'tvshowtitle' in data else data['year']
            search_term = '%s Season %s' % (title, season) if 'tvshowtitle' in data else title
            search_url = self.base_link + self.search_link % cleantitle.get_plus(search_term)
            r = client.scrapePage(search_url).text
            r = client_utils.parseDOM(r, 'li', attrs={'class': 'video-block'})
            r = [(client_utils.parseDOM(i, 'a', ret='href'), client_utils.parseDOM(i, 'a', ret='title')) for i in r]
            r = [(i[0][0], i[1][0]) for i in r if len(i[0]) > 0 and len(i[1]) > 0]
            if 'tvshowtitle' in data:
                r = [(i[0], re.findall('(.+?) Season (\d+)$', i[1])) for i in r]
                r = [(i[0], i[1][0]) for i in r if len(i[1]) > 0]
                url = [i[0] for i in r if cleantitle.match_alias(i[1][0], aliases) and i[1][1] == season][0]
            else:
                results = [(i[0], i[1], re.findall('\((\d{4})', i[1])) for i in r]
                try:
                    r = [(i[0], i[1], i[2][0]) for i in results if len(i[2]) > 0]
                    url = [i[0] for i in r if cleantitle.match_alias(i[1], aliases) and cleantitle.match_year(i[2], year)][0]
                except:
                    url = [i[0] for i in results if cleantitle.match_alias(i[1], aliases)][0]
            url = '/' + url if not url.startswith('/') else url
            url = self.base_link +'%s-episode-%s' % (url, episode)
            html = client.scrapePage(url).text
            if not 'tvshowtitle' in data:
                try:
                    qual = client_utils.parseDOM(html, 'span', attrs={'class': 'current'})[0]
                except:
                    qual = 'SD'
            else:
                qual = 'SD'
            links = client_utils.parseDOM(html, 'div', attrs={'class': 'anime_muti_link'})[0]
            links = client_utils.parseDOM(links, 'a', ret='data-video')
            for link in links:
                for source in scrape_sources.process(hostDict, link, info=qual):
                    self.results.append(source)
            return self.results
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return self.results


    def resolve(self, url):
        return url


