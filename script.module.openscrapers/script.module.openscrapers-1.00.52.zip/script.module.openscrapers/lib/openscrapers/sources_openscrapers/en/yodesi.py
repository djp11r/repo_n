# -*- coding: UTF-8 -*-
# import json
import re

from openscrapers.modules.client import agent, request
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.hindi_sources import get_query, get_source_dict, query_cleaner, resolve_gen
from openscrapers.modules.log_utils import error, log


class source:

    def __init__(self):
        self.name = "yodesi"
        self.domains = ['yodesitv.info']
        self.base_link = 'https://www.yodesitv.info'
        self.search_link = 'https://www.yodesitv.info/feed/?s=%s&submit=Search'
        self.info_link = 'https://www.yo-desi.com/player.php?id=%s'
        self.headers = {'User-Agent': agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f'From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year}')
        try:
            try:
                url = aliases[0]['url']
                if 'yodesitv' in url: return url
            except: pass
            return f'{tvshowtitle}'
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f'From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}')
        try:
            if type(tvdb) == int: return
            if 'watch-online' in url: return url
            if '|' not in tvdb: return
            query = get_query(url)
            # log(f'query {query} title: {title}')
            # if re.search('indias-got-talent-season-10', query, re.I): query = 'india-got-talent-season-10'
            if re.search('kaun-banega-crorepati', query, re.I): query = 'kaun-banega-crorepati-15'
            # elif re.search('bigg-boss', query, re.I): query = f'bigg-boss-16'
            # elif re.search('the-kapil-sharma-show', query, re.I): query = f'the-kapil-sharma-show-season-4'
            # elif re.search('masterchef-india', query, re.I): query = f'masterchef-india-season-7'
            if re.search('episode', title, re.I): query = f'{query}-watch-online-{title}'
            elif re.search('jhalak-dikhhla-jaa', query, re.I): query = f'jhalak-dikhhla-jaa-season-11-{title}'
            else: query = f'{query}-{title}-video-episode-update-online'
            query = query_cleaner(query)
            return f'{self.base_link}/{query}/'
        except:
            error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict):
        sources = []
        # log(f'From: {__name__} url {url}')
        try:
            if not url: return sources
            result = request(url, headers=self.headers)
            if not result: return sources
            result = parseDOM(result, 'div', attrs={'class': 'thecontent'})
            items = parseDOM(result, 'p')
            for item in items:
                # log(f'item: {item}')
                urls = parseDOM(item, 'a', attrs={'target': '_blank'}, ret='href')
                # log(f'total: {len(urls)} urls: {urls}')
                iurls = []
                if iurls := [iurl for iurl in urls if iurl not in iurls]: sources = get_source_dict(iurls, sources)
            if not sources: log(f'From: {__name__} no sources on url {url}')
            return sources
        except:
            error(f'{__name__}_ sources url: {url} ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return resolve_gen(url)
