# -*- coding: utf-8 -*-

import re

from openscrapers.modules import client
from openscrapers.modules import client_utils
from openscrapers.modules import cleantitle
from openscrapers.modules import scrape_sources
#from openscrapers.modules import log_utils


class source:
    def __init__(self):
        self.results = []
        self.domains = ['databasegdriveplayer.co', 'series.databasegdriveplayer.co', 'database.gdriveplayer.us']
        self.base_link = 'https://databasegdriveplayer.co' # 'https://database.gdriveplayer.us'


    def movie(self, imdb, title, localtitle, aliases, year):
        return self.base_link + '/player.php?imdb=%s' % imdb


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        return self.base_link + '/player.php?type=series&imdb=%s' % imdb


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        return url + '&season=%s&episode=%s' % (season, episode)


    def sources(self, url, hostDict):
        try:
            if url == None:
                return self.results
            html = client.request(url)
            servers = client_utils.parseDOM(html, 'ul', attrs={'class': 'list-server-items'})[0]
            links = client_utils.parseDOM(servers, 'a', ret='href')
            for link in links:
                if not link or link.startswith('/player.php'):
                    continue
                for source in scrape_sources.process(hostDict, link):
                    self.results.append(source)
            return self.results
        except Exception:
            #log_utils.log('sources', 1)
            return self.results


    def resolve(self, url):
        return url


