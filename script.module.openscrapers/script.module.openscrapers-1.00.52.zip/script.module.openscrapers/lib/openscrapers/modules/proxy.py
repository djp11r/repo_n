# -*- coding: utf-8 -*-
"""
    OpenScrapers Module
"""

import random
import re
from openscrapers import parse_qs, urlparse, urlencode, quote_plus
from openscrapers.modules.client import request, replaceHTMLCodes
from openscrapers.modules.utils import byteify


def proxy_request(url, check, close=True, redirect=True, error=False, proxy=None, post=None, headers=None, mobile=False, XHR=False, limit=None, referer=None, cookie=None, compression=True, output='', timeout='30'):
    try:
        if proxy_url := get_proxy_url(url):
            if post is not None and isinstance(post, dict):
                post = byteify(post)
                post = urlencode(post)
            r = request(proxy_url, post=post, close=close, redirect=redirect, error=error, proxy=proxy, headers=headers, mobile=mobile, XHR=XHR, limit=limit, referer=referer, cookie=cookie, compression=compression, output=output, timeout=timeout)
            if check in str(r) or str(r): return r
    except:
        pass


def get_proxy_url(url, url_try=3):
    try:
        # r = client.request(url, output='geturl')
        # if r is None: return r
        # host1 = re.findall(r'([\w]+)[.][\w]+$', urlparse(url.strip().lower()).netloc)[0]
        # host2 = re.findall(r'([\w]+)[.][\w]+$', urlparse(r.strip().lower()).netloc)[0]
        # if host1 == host2: return r
        proxies = sorted(get(), key=lambda x: random.random())
        proxies = proxies[:url_try]
        for p in proxies:
            p += quote_plus(url)
            r = request(p, output='geturl')
            if r is not None: return p #parse(r)
    except:
        pass


def get():
    return [
        'https://corsproxy.io/?',
        'https://proxy.iamcdn.net/sub?url=',
        'https://api.allorigins.win/raw?url=',
        'http://buka.link/browse.php?b=20&u=',
        'http://buka.link/browse.php?u=%s&b=2',
        'http://dontfilter.us/browse.php?b=20&u=%s',
        'http://www.xxlproxy.com/index.php?hl=3e4&q=',
        'http://free-proxyserver.com/browse.php?b=20&u=',
        'http://proxite.net/browse.php?b=20&u=',
        'http://proxydash.com/browse.php?b=20&u=',
        'http://webproxy.stealthy.co/browse.php?b=20&u=',
        'http://sslpro.eu/browse.php?b=20&u=',
        'http://webtunnel.org/browse.php?b=20&u=',
        'http://proxycloud.net/browse.php?b=20&u=',
        'http://www.onlineipchanger.com/browse.php?b=20&u=',
        'http://buka.link/browse.php?b=20&u=',
        'http://www.unblockmyweb.com/browse.php?b=20&u=',
        'http://mlproxy.science/surf.php?b=20&u=',
        'https://www.prontoproxy.com/browse.php?b=20&u=',
        'http://fproxy.net/browse.php?b=20&u=',
        'http://www.mybriefonline.xyz/browse.php?b=20&u=']


def parse(url):
    try: url = replaceHTMLCodes(url)
    except: pass
    try: url = parse_qs(urlparse(url).query)['u'][0]
    except: pass
    try: url = parse_qs(urlparse(url).query)['q'][0]
    except: pass
    return url