# -*- coding: UTF-8 -*-

# import json
# import re
import re


import requests

from openscrapers.modules.hindi_sources import refresh_redirect, get_source_dict, resolve_gen, host, keepclean_title, get_vid_url, query_cleaner
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.client import agent

class source:

    def __init__(self):
        self.name = "playdesi"
        self.domains = ['playdesi.org']
        self.base_link = 'https://playdesi.tv'
        self.headers = {'User-Agent': agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f'From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year}')
        try:
            try:
                url = aliases[0]['url']
                if 'playdesi' in url: return url
            except: pass
            return f'{tvshowtitle}'
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f'From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}')
        try:
            if type(tvdb) == int: return
            if 'episode' not in title.lower(): return
            if 'watch-online' in url: return url
            if '|' in tvdb:
                tvdb = tvdb.split('|')
                # episode = episode.replace('Episode', '')
                show_name = tvdb[1]
                chanel_name = keepclean_title(tvdb[0])
                # log(f'From: {__name__} show_name {show_name}')
                show_name = query_cleaner(show_name)
                show_name = re.sub(re.compile(r'-[sS]eason.+?(\d+)|[sS]eason(\d+)|[sS](\d+)'), '', show_name)
                show_url = f'https://playdesi.net/watch-online/{chanel_name}/{show_name}-season-{season}/'
                show_url = show_url.lower().replace(' ', '-').replace('  ', '-')
                # log(f'From: {__name__} show_url {show_url}')
                result = requests.get(show_url, headers=self.headers)
                if result.status_code == 200:
                    qepisode = title.replace('Episode ', '')
                    release_title = f'season-{season}-episode-{qepisode}'
                    results = parseDOM(result.text, 'div', attrs={'class': 'post-content'})
                    # log(f'From: {__name__} total: {len(results)} result1 {results}')
                    # results = parseDOM(result.text, 'div', attrs={'class': 'blog-posts posts-medium posts-container'})
                    # log(f'From: {__name__} total: {len(results)} result2 {results}')
                    for item in results:
                        # log(f'{__name__} episode item: {item}')
                        urls = parseDOM(item, "a", ret="href")
                        # log(f'{__name__} release_title: {release_title} url: {urls}')
                        for url in urls:
                            if release_title in url:
                                # log(f'@@@@@ {__name__} episode item: {item}')
                                break
                    return url
                return
        except:
            error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict):
        # log(f'From: {__name__} url {url}')
        sources = []
        try:
            if not url:	return sources
            result = requests.get(url, headers=self.headers).text
            if not result: return
            result = parseDOM(result, 'div', attrs={'class': 'entry-content'})
            # log(f'result: {result}')
            items = parseDOM(result, 'p')
            for item in items:
                urls = parseDOM(item, 'a', attrs={'target': '_blank'}, ret='href')
                # log(f'sources url: {urls}')
                final_url = []
                if urls:
                    link = urls[0]
                    if link not in final_url: final_url.append(link)
                if final_url: sources = get_source_dict(final_url, sources)
            if not sources: log(f'From: {__name__} no sources on url {url}')
            return sources
        except:
            error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        # url = resolve_gen(url)
        try:
            if result := refresh_redirect(url, headers=self.headers):
                vidhost, strurl = get_vid_url(result, self.headers)
                return strurl
        except:
            pass
        return
