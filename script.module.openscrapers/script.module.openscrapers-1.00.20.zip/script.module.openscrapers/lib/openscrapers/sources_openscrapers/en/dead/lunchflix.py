# -*- coding: utf-8 -*-
"""
    **Created by Tempest**
    **If you see this in a addon other than Tempest and says it was
    created by someone other than Tempest they stole it from me**
"""

import re, requests
import traceback
from openscrapers import parse_qs, quote_plus, urljoin, urlencode
from openscrapers.modules import log_utils
from openscrapers.modules import client
from openscrapers.modules import source_utils


class source:
    def __init__(self):
        self.priority = 40
        self.language = ['en']
        self.domains = ['www.lunchflix.net', 'www.lunchflix.com']
        self.base_link = 'https://www.lunchflix.net'
        self.search_link = '/?s=%s'
        self.headers = {'User-Agent': client.agent(), 'Referer': self.base_link}

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        items = []
        try:
            if url is None: return sources

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            hdlr = '%s (%s)' % (data['title'].replace("Philosopher's", "Sorcerer&#8217;s"), int(data['year']))
            query = '%s %s' % (data['title'], int(data['year']))

            url = self.search_link % quote_plus(query)
            url = urljoin(self.base_link, url).replace('Philosopher', 'Sorcerer')
            try:
                posts = requests.get(url, headers=self.headers).text
                r = [i for i in re.findall(r'title="(.+?)" href="(.+?)"', posts) if hdlr in i[0]]
                items += r
            except:
                pass

            for item in items:
                r = requests.get(item[1], headers=self.headers).text
                url = re.findall(r'playlist: "(.+?)"', r)[0]
                url = requests.get(url, headers=self.headers).text
                url = re.findall(r'"file":"(.+?)",', url)[0]
                quality, info = source_utils.get_release_quality(url)
                sources.append(
                    {'source': 'CDN', 'quality': quality, 'language': 'en', 'url': url,
                     'info': info, 'direct': True, 'debridonly': False})

            return sources
        except Exception:
            log_utils.error(f'{__name__}_ sources: ')
            return []

    def resolve(self, url):
        return url
