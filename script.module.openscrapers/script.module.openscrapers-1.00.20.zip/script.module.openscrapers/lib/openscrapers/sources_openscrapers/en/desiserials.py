# -*- coding: UTF-8 -*-

# import json
import re


import requests
from openscrapers.modules import client, log_utils
from openscrapers.modules.hindi_sources import scraper_debug, get_source_dict, resolve_gen, host


class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "desiserials"
        self.domains = ['desiserials.org']
        self.base_link = 'https://www.desi-serials.cc'
        self.headers = {'User-Agent': client.agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # scraper_debug("From: {} \nimdb {} \ntvdb {}\n tvshowtitle {}, localtvshowtitle {}, aliases {}, year {} ".format(self.name, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))
        try:
            try:
                url = aliases[0]['url']
                # log_utils.log(f'show url: {url}')
                if 'desi-serials' in url: return url
            except: pass #log_utils.error(f'{__name__}_ tvshow: ')
            query = '%s' % (tvshowtitle)
            url = query
            # scraper_debug('>>> #### 0AAAA - yodesi EP url : %s' % ( url))
            return url
        except:
            log_utils.error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # scraper_debug("From: {} url {} ... \nimdb {} .. tvdb {}\n title {}, premiered {}, season {}, episode {} ".format(self.name, url, imdb, tvdb, title, premiered, season, episode))
        try:
            if type(tvdb) == int: return
            if 'episode' in title.lower(): return
            if 'watch-online' in url: return url
            if '|' in tvdb:
                # scraper_debug("type desiserials tvdb %s" % type(tvdb))
                # tvdb = tvdb.split('|')
                # ch_name = tvdb[0]
                # title = tvdb[1]
                title = title.lower().replace(' ', '-').replace('.', '')
                query = '{}-episode-{}-watch-online'.format(url, title)
                if 'bigg boss' in url:
                    query = '{}-2020-season-14-episode-{}-watch-online'.format(url, title)
                query = query.lower().replace(' ', '-').replace('.', '')
                url = '%s/%s/' % (self.base_link, query)
                # scraper_debug('out episode url :  %s episode: %s' % (url, episode))
                return url
                # scraper_debug('\nout episode url :  %s \nepisode: %s' % (url, episode))
                # if episode in url:
                    # # scraper_debug('>>>> episode url :  %s \nepisode: %s' % (url, episode))
                    # return url
            # else: return
        except:
            log_utils.error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict, hostprDict):
        # scraper_debug("From: {} \nurl {}".format(self.name, url))
        sources = []
        try:
            if not url: return sources
            # result = client.request(url)
            result = requests.get(url, headers=self.headers).text
            if not result: return sources
            # read_write_file(read=False, result=result)
            result = client.parseDOM(result, 'div', attrs={'class': 'post-content'})
            # scraper_debug(result)
            items = client.parseDOM(result, 'p')
            # scraper_debug(items)
            for item in items:
                # scraper_debug(item)
                urls = client.parseDOM(item, 'a', ret='href')
                # log_utils.log('total: %s urls: %s' % (len(urls), urls))
                furls = []
                vidhost = None
                # for j in range(0, len(urls)):
                    # furls.append(urls[j])
                    # scraper_debug('total: %s url: %s' % (len(urls), urls[j]))
                    # try:
                    #     headers = {'Referer': urls[j]}
                    #     self.headers.update(headers)
                    #     result = requests.get(urls[j], headers=self.headers).text
                    #     if result:
                    #         links = client.parseDOM(result, 'iframe', ret = 'src')
                    #         for link in links:
                    #             if 'vkprime' in link or 'speed' in link or 'watchvideo.us' in link:
                    #                 vidhost = host(link)
                    #                 furls.append(link)
                    #             elif 'flow.' in link:
                    #                 vidhost = 'CDN'
                    #                 furls.append(urls[j])
                    # except:
                    #     pass
                if 0 < len(urls) < 6:
                    sources = get_source_dict(urls, sources, vidhost)
            # dumper = dumper
            # scraper_debug('SOURCES \n\n%s' % json.dumps(sources, default = dumper, indent = 2))
            return sources
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # scraper_debug('In type of url {} url: {}'.format(type(url), url))
        url = resolve_gen(url)
        return url
