# -*- coding: UTF-8 -*-
import json
import re, traceback

import requests
from openscrapers import urlencode, parse_qs, urljoin, quote
from openscrapers.modules import client, log_utils, cleantitle
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.hindi_sources import scraper_debug, get_source_dict, urlRewrite, get_mod_url, resolve_gen, getVideoID, read_write_file


class source:

    def __init__(self):
        self.priority = 40
        self.language = ['en']
        self.name = "desirulez"
        self.domains = ['desirulez.cc']
        self.base_link = 'http://www.desirulez.cc'
        self.base_link_2 = 'http://www.desirulez.me'
        self.base_link_3 = 'https://www.desirulez.cc:443'
        self.headers = {'User-Agent': client.agent(), }

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            # scraper_debug("From: {} \nimdb: {} \ntitle: {}\nlocaltitle: {} \naliases: {}\nyear: {} ".format(self.name, imdb, title, localtitle, aliases, year))
            # scraper_debug('desirulez movie repr(aliases): {}'.format(repr(aliases)))
            link = 'http://www.desirulez.cc/forumdisplay.php?f=20'
            movies_page = client.r_request(link, headers=self.headers).text # read_write_file(file_n='www.desirulez.cc.html')#
            result = parseDOM(movies_page, "h3", attrs={"class": "threadtitle"})
            # print("title: {}".format(title))
            # print("title: {}".format(cleantitle.geturl(title)))
            for item in result:
                url = parseDOM(item, "a", ret="href")[0]
                if title in item:
                    url = urljoin(self.base_link_3, quote(url)) if not url.startswith(self.base_link_3) else url
                    # print("url: {}".format(url))
                    url = {'imdb': imdb, 'title': title, 'year': year, 'aliases': aliases, 'url': url}
                    url = urlencode(url)
                    return url
        except:
            log_utils.error(f'{__name__}_ movie: ')
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # scraper_debug("From: {} \nimdb {} \ntvdb {}\ntvshowtitle {}\nlocaltvshowtitle {} \naliases {}\n year {} ".format(self.name, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))
        try:
            try:
                url = aliases[0]['url']
                # log_utils.log(f'show url: {url}')
                if 'desirulez' in url: return url
            except: pass #log_utils.error(f'{__name__}_ tvshow: ')
            tvshowtitle = tvshowtitle.lower().replace(' ', '-').replace('.', '-')
            # if "indian-idol" in tvshowtitle:
            #     tvshowtitle = 'indian-idol-2020-season-12-a-6674'
            # elif "super-dancer" in tvshowtitle.lower():
            #     tvshowtitle = "super-dancer-chapter-4-a-6732"
            # elif "dance-deewane" in tvshowtitle.lower():
            #     tvshowtitle = "dance-deewane-3-a-6749"
            query = '%s/forumdisplay.php/%s' % (self.base_link, tvshowtitle)
            url = query
            # scraper_debug('desirulez tvshow url : %s' % url)
            return url
        except:
            log_utils.error(f'{__name__}_ tvshow: ')
            return
    
    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # scraper_debug("From: {} url {} ... \nimdb {} .. tvdb {}\n title {}, premiered {}, season {}, episode {} ".format(self.name, url, imdb, tvdb, title, premiered, season, episode))
        # log_utils.log(f'episode url: {url}')
        try:
            if type(tvdb) == int: return
            if 'watch-online' in url.lower(): 
                url = {'imdb': imdb, 'title': title, 'url': url}
                url = urlencode(url)
                return url
            # if 'episode' in title.lower(): return
            if '|' in tvdb:
                # scraper_debug("type episode %s" % type(episode))
                exctract_date = re.compile(r' Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|August|Sep|September|Oct|October|Nov|November|Dec|December ')
                q_item = re.sub(exctract_date, '', title)
                q_item = q_item.replace('  ', '-')
                # scraper_debug('desirulez episode q_item: {} episode >>>  : {}'.format(q_item, episode))
                episode = title.lower().replace(' ', '-').replace('.', '-')
                # season = season.lower().replace(' ', '-').replace('.', '-')
                # log_utils.log(f'desirulez episode type: {type(url)} url >>>  : {url}')
                result = requests.get(url, headers=self.headers).text
                # episo_page = result.decode('iso-8859-1').encode('utf-8')
                # result = client.parseDOM(result, "h3", attrs = {
                #     "class": "title threadtitle_unread"})
                result = client.parseDOM(result, "h3", attrs={"class": "threadtitle"})
                # scraper_debug('desirulez episode result 2  : %s' % result)
                url = ''
                for item in result:
                    # log_utils.log(f'desirulez episode item : \n{item}\n')
                    urls = client.parseDOM(item, "a", ret="href")
                    for url in urls:
                        # log_utils.log(f'q_item: {q_item} episode: {episode} url :  {url} ')
                        if 'watch-online' in url and (title in url or q_item in url): # and season in url:
                            log_utils.log(f'>>>> episode url :  {url} \nepisode: {episode}')
                            url = {'imdb': imdb, 'title': title, 'url': url}
                            url = urlencode(url)
                            return url
                if url == '': return ''
            # else: return
        except:
            log_utils.error(f'{__name__}_ episode: ')
            return

    def searchShow(self, title, season, episode, aliases):
        # aliases = [{'title': title}]
        try:
            url = '%s/tv-show/%s/season/%01d/episode/%01d' % (self.base_link, cleantitle.geturl(title), int(season), int(episode))
            # url = '%s/show/%s/season/%01d/episode/%01d' % (self.base_link, cleantitle.geturl(alias['title']), int(season), int(episode))
            url = client.request(url, headers=self.headers, output='geturl', timeout='10')
            if self.base_link in url:
                return url
        except:
            log_utils.error(f'{__name__}_ searchShow: ')
            return

    def sources(self, url, hostDict, hostprDict):
        # scraper_debug("From sources : {} \nurl {}".format(self.name, url))
        # log_utils.log(f'sources url: {url}')
        sources = []
        try:
            if not url: return sources
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            # log_utils.log(f"url to data: {data}")
            # title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            # imdb = data['imdb']
            # aliases = eval(data['aliases'])
            # if 'tvshowtitle' not in data:
            url = data['url']
            # log_utils.log("url to get: %s" % url)

            result = requests.get(url, headers=self.headers).text
            if not result: return sources

            # result = result.decode('iso-8859-1').encode('utf-8')
            result = result.replace('\n', '')
            links = client.parseDOM(result, 'blockquote', attrs={'class': r'.*?postcontent.*?'})
            # scraper_debug(links[0])
            # pattern = re.compile(r'(?<=font color)(.+?)(((?=font color)|##)+)', re.S)  # all a in after font color
            pattern = re.compile(r'(?<=<b>)(.+?)((?=<b>)|##)', re.S)  # find all a after <b> and before <b>
            ndata = re.findall(pattern, links[0] + '##') # add ## to get to the end of string
            for ai in ndata:
                urls = re.findall(r'href=[\'"]?([^\'" >]+)', ai[0])
                host = None
                if len(urls) > 0:
                    # log_utils.log('desirulez total: %s urls: %s' % (len(urls), urls))
                    for i in range(0, len(urls)):
                        try:
                            # scraper_debug('retun url and host %s iurl: %s' % ('host', urls[i]))
                            if any(re.findall(r'speed|vkprime', urls[i], re.IGNORECASE)):
                                urls[i] = urlRewrite(urls[i])
                            elif any(re.findall(r'business-loans.pw|bestarticles|tvnation.me', urls[i], re.IGNORECASE)) and 'drive.php' not in urls[i]:
                                iurl = get_mod_url(urls[i])
                                # scraper_debug('In urls[i]: %s Out iurl: %s' % (urls[i], iurl))
                                if iurl: urls[i] = urls[i]
                                # headers = {'Referer': urls[i]}
                                # self.headers.update(headers)
                                # result = requests.get(iurl, headers = self.headers).text
                                # if result:
                                #     host = 'CDN'
                                #     urls[i] = urls[i]
                                # else: urls[i] = None
                            elif 'articlesmania.me' in urls[i]:
                                # scraper_debug('>>> articlesmania iurl: %s' % (urls[i]))
                                urls[i] = urls[i]
                                # host, url = link_extractor(urls[i])
                                # if url: urls[i] = urls[i]
                                # else: urls[i] = None
                            else: urls[i] = None
                        except: urls[i] = None

                    if urls[0] is not None and len(urls) > 0:
                        sources = get_source_dict(urls, sources, host)
                urls = []
            # scraper_debug('SOURCES %s\n\n%s' % (self.name, json.dumps(sources, default = dumper, indent = 2)))
            return sources
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # scraper_debug('In type of url {} url: {}'.format(type(url), url))
        url = resolve_gen(url)
        return url
