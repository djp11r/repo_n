# -*- coding: UTF-8 -*-
# import json
import re
import traceback
# from openscrapers import parse_qs, urlencode, urlparse, urljoin

import requests
from openscrapers.modules import client
from openscrapers.modules import log_utils
# from openscrapers.modules import cfscrape
from openscrapers.modules.hindi_sources import scraper_debug, get_source_dict, meta_redirect, append_headers, resolve_gen, link_cfscraper_extractor, host


class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "desicinemas"
        self.domains = ['desicinemas.tv']
        self.base_link = 'https://desicinemas.tv'
        self.search_link = '/movies/%s/'
        self.headers = {'User-Agent': client.agent(), }
        # self.scraper = cfscrape.create_scraper()

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            # scraper_debug("From: {} \nimdb: {} \ntitle: {}\nlocaltitle: {} \naliases: {}\nyear: {} ".format(self.name, imdb, title, localtitle, aliases, year))
            try:
                url = aliases[0]['url']
                if 'desicinemas' in aliases: return url
            except: pass
            scrape = title.lower().replace(' ', '-').replace(':', '')
            start_url = self.base_link + self.search_link % scrape
            # print('movie url: {}'.format(start_url))
            return start_url
        except:
            log_utils.error(f'{__name__}_ movie: ')
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        # scraper_debug("From: {} \nurl: {}".format(self.name, url))
        try:
            if not url: return sources
            result = requests.get(url, headers=self.headers).text
            if not result: return sources
            result = client.parseDOM(result, 'div', attrs={'class': 'TPMvCn'})
            items = client.parseDOM(result, 'ul', attrs={'class': 'MovieList Rows BX B06 C20 D03 E20'})
            # scraper_debug("items: {}".format(items))
            for item in items:
                # print("link urls: {}".format(item))
                urls = client.parseDOM(item, 'a', ret='href')
                # print("len(urls): {} urls: {}".format(len(urls), urls))
                # scraper_debug("urls: {}".format(urls))
                for link in urls:
                    # print('link: {}'.format(link))
                    if 'cinemas.php?id':
                        # vidhost = 'CDN'
                        furls = [link]
                        sources = get_source_dict(furls, sources)

            # scraper_debug('SOURCES %s\n\n%s' % (self.name, json.dumps(sources, default = dumper, indent = 2)))
            return sources
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # scraper_debug('In type of url {} url: {}'.format(type(url), url))
        url = resolve_gen(url)
        return url
