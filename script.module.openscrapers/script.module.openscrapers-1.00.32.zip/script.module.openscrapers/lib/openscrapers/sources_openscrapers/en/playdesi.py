# -*- coding: UTF-8 -*-

# import json
# import re
import re


import requests

from openscrapers.modules.hindi_sources import refresh_redirect, get_source_dict, resolve_gen, host, keepclean_title, get_vid_url
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.client import agent

class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "playdesi"
        self.domains = ['playdesi.org']
        self.base_link = 'https://playdesi.tv'
        self.headers = {'User-Agent': agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f'From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year}')
        try:
            try:
                url = aliases[0]['url']
                if 'playdesi' in url: return url
            except: pass
            return f'{tvshowtitle}'
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f'From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}')
        try:
            if type(tvdb) == int: return
            if 'episode' not in title.lower(): return
            if 'watch-online' in url: return url
            if '|' in tvdb:
                tvdb = tvdb.split('|')
                # episode = episode.replace('Episode', '')
                show_name = tvdb[1]
                chanel_name = keepclean_title(tvdb[0])
                show_url = f'https://playdesi.net/watch-online/{chanel_name}/{show_name}-season-{season}/'
                show_url = show_url.lower().replace(' ', '-').replace('  ', '-')
                # log(f'From: {__name__} show_url {show_url}')
                result = requests.get(show_url, headers=self.headers)
                if result.status_code == 200:
                    release_title = f'season-{season}-episode-{episode}'
                    results = parseDOM(result.text, 'div', attrs={'class': 'blog-posts posts-medium posts-container'})
                    # log(f'From: {__name__} result {result}')
                    for item in results:
                        # log(f'{__name__} episode item: {item}')
                        if release_title in item:
                            # log(f'@@@@@ {__name__} episode item: {item}')
                            url = parseDOM(item, "a", ret="href")[0]
                            return url
                return
        except:
            error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict):
        # log(f'From: {__name__} url {url}')
        sources = []
        try:
            if not url:	return sources
            result = requests.get(url, headers=self.headers).text
            if not result: return
            result = parseDOM(result, 'div', attrs={'class': 'entry-content'})
            # log(f'result: {result}')
            items = parseDOM(result, 'p')
            for item in items:
                urls = parseDOM(item, 'a', attrs={'target': '_blank'}, ret='href')
                # log(f'sources url: {urls}')
                final_url = []
                if urls:
                    link = urls[0]
                    if link not in final_url: final_url.append(link)
                if final_url: sources = get_source_dict(final_url, sources)
            return sources
        except:
            error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        # url = resolve_gen(url)
        try:
            result = refresh_redirect(url, headers=self.headers)
            if result:
                vidhost, strurl = get_vid_url(result, self.headers)
                return strurl
        except:
            pass
        return
