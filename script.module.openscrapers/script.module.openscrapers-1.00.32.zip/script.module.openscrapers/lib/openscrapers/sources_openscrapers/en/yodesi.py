# -*- coding: UTF-8 -*-
# import json
import re

# from openscrapers import quote_plus

import requests
# from bs4 import BeautifulSoup, SoupStrainer
from openscrapers.modules.hindi_sources import get_source_dict, resolve_gen, host, remove_url
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.client import agent


class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "yodesi"
        self.domains = ['yodesitv.info']
        self.base_link = 'https://www.yodesitv.info'
        self.search_link = 'https://www.yodesitv.info/feed/?s=%s&submit=Search'
        self.info_link = 'https://www.yo-desi.com/player.php?id=%s'
        self.headers = {'User-Agent': agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f'From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year}')
        try:
            try:
                url = aliases[0]['url']
                if 'yodesitv' in url: return url
            except: pass
            return f'{tvshowtitle}'
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f'From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}')
        try:
            if type(tvdb) == int: return
            if 'watch-online' in url: return url
            if '|' in tvdb:
                query = f'{url}'.replace(' ', '-')
                # log(f'query {query} title: {title}')
                if re.search(r'indian-idol-13', query, re.I): query = f'indian-idol-13-{title}-watch-online'
                elif re.search(r'bigg-boss', query, re.I): query = f'bigg-boss-16-{title}-watch-online'
                elif re.search(r'the-kapil-sharma-show', query, re.I): query = f'the-kapil-sharma-show-season-4-{title}-watch-online'
                elif re.search(r'kaun-banega-crorepati', query, re.I): query = f'kaun-banega-crorepati-season-14-{title}-watch-online'
                elif re.search(r'masterchef-india', query, re.I): query = f'masterchef-india-season-7-{title}-watch-online'
                elif re.search(r'episode', title, re.I): query = f'{query}-watch-online-{title}'
                else: query = f'{query}-{title}-watch-online'

                query = query.lower().replace(' ', '-').replace('.', '-').replace('---', '-').replace("'", '').replace("’", '')
                url = f'{self.base_link}/{query}/'
                # log(f'episode url :  {url}\nepisode: {episode}')
                return url
        except:
            error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict):
        sources = []
        # log(f'From: {__name__} url {url}')
        try:
            if not url: return sources
            result = requests.get(url, headers=self.headers).text
            if not result: return sources
            result = parseDOM(result, 'div', attrs={'class': 'thecontent'})
            items = parseDOM(result, 'p')
            for item in items:
                # log(f'item: {item}')
                urls = parseDOM(item, 'a', attrs={'target': '_blank'}, ret='href')
                # log(f'total: {len(urls)} urls: {urls}')
                final_url = []
                for iurl in urls:
                    if iurl not in final_url: final_url.append(iurl)
                if final_url: sources = get_source_dict(final_url, sources)
            return sources
        except:
            error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return resolve_gen(url)
