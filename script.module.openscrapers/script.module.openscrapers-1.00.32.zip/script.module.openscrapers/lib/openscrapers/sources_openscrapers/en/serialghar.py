# -*- coding: UTF-8 -*-

import re

from openscrapers.modules.hindi_sources import get_source_dict, resolve_gen
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.client import agent, scrapePage


class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "serialghar"
        self.domains = ['serialghar.me']
        self.base_link = 'https://serialghar.me'
        self.headers = {'User-Agent': agent(), }


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f"From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year} ")
        try:
            query = f'{tvshowtitle}'
            url = query
            # log(f'>>> #### 0AAAA - yodesi EP url : {url}')
            return url
        except:
            error(f'{__name__}_ tvshow: ')
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f"From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}")
        try:
            if type(tvdb) == int: return
            if 'episode' in title.lower(): return
            if '|' in tvdb:
                query = f'{url}'.replace(' ', '-')
                # log(f"query {query} title: {title} ")
                if re.search(r'the-kapil-sharma-show', url, re.I): query = f'the-kapil-sharma-show-{title}'
                elif re.search(r'bigg-boss', query, re.I): query = f'bigg-boss-16-{title}'
                else: query = f'{url}-{title}'
                query = query.lower().replace(' ', '-').replace('.', '-').replace('---', '-').replace("'", '').replace("’", '')
                eurl = f'{self.base_link}/{query}/'
                # log(f"eurl {eurl}")
                return eurl
            else: return
        except:
            error(f'{__name__}_ episode: ')
            return


    def sources(self, url, hostDict):
        # log(f"From: {__name__} url {url}")
        sources = []
        try:
            if not url: return sources
            result = scrapePage(url, headers=self.headers).text
            if not result: return sources
            # read_write_file(read=False, result=result)
            result = parseDOM(result, 'div', attrs={'class': 'entry'})
            items = parseDOM(result, 'p')
            for item in items:
                urls = parseDOM(item, 'a', attrs={'target': '_blank'}, ret='href')
                # log(f'total: {len(urls)} urls: {urls}')
                final_url = []
                for iurl in urls:
                    if iurl not in final_url: final_url.append(iurl)
                if final_url: sources = get_source_dict(final_url, sources)
            return sources
        except:
            error(f'{__name__}_ sources: ')
            return sources


    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return resolve_gen(url)