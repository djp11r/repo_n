# -*- coding: UTF-8 -*-

import re

from openscrapers.modules.hindi_sources import get_source_dict, resolve_gen, host, remove_url
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.client import agent, scrapePage


class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "desitelly"
        self.domains = ['desitellybox.me']
        self.base_link = 'https://www.desitellybox.me'
        self.headers = {'User-Agent': agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f'From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year}')
        try:
            return f'{tvshowtitle}'
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f'From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}')
        try:
            if type(tvdb) == int: return
            if '|' in tvdb:
                query = f'{url}'.replace(' ', '-')
                # log(f'query {query} title: {title}')
                if re.search(r'bigg-boss', query, re.I): query = f'bigg-boss-16-{title}-episode-watch-online'
                elif re.search(r'masterchef-india', query, re.I): query = f'masterchef-india-season-7-{title}-watch-online'
                else: query = f'{url}-{title}-episode-watch-online/'
                query = query.lower().replace(' ', '-').replace('.', '-').replace('---', '-').replace("'", '').replace("’", '')
                url = f'{self.base_link}/{query}'
                return url
            else: return
        except:
            error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict):
        # log(f'From: {__name__} url {url}')
        sources = []
        try:
            if not url: return sources
            result = scrapePage(url).text
            if not result: return sources
            result = parseDOM(result, 'div', attrs={'class': 'entry_content'})
            items = parseDOM(result, 'p')
            for item in items:
                urls = parseDOM(item, 'a', attrs={'target': '_blank'}, ret='href')
                # log(f'total: {len(urls)} urls: {urls}')
                final_url = []
                for iurl in urls:
                    if iurl not in final_url: final_url.append(iurl)
                if final_url: sources = get_source_dict(final_url, sources)
            return sources
        except:
            error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return resolve_gen(url)
