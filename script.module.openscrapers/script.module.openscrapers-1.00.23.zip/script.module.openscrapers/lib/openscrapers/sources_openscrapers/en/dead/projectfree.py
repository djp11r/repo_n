# -*- coding: UTF-8 -*-

import re

from openscrapers.modules import py_tools

from openscrapers import cfScraper
from urllib.parse import parse_qs, urljoin, urlencode, quote_plus
from openscrapers.modules import cleantitle, client, source_utils, log_utils

from openscrapers import custom_base_link
custom_base = custom_base_link(__name__)


class source:
    def __init__(self):
        self.priority = 40
        self.language = ['en']
        self.domains = ['project-free-tv.ag', 'projecfreetv.co', 'my-project-free.tv']
        self.base_link = custom_base if custom_base else 'https://projecfreetv.co'
        self.search_link = '/episode/%s/'

    # def movie(self, imdb, title, localtitle, aliases, year):
    #     try:
    #         aliases.append({'country': 'us', 'title': title})
    #         url = {'imdb': imdb, 'title': title, 'year': year, 'aliases': aliases}
    #         url = urlencode(url)
    #         return url
    #     except:
    #         return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None:
                return

            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url is None:
                return sources

            hostDict = hostprDict + hostDict

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']

            hdlr = 's%02de%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']

            query = '%s-%s' % (title, hdlr)
            query = re.sub(r'(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            url = self.search_link % quote_plus(query.lower())
            url = urljoin(self.base_link, url).replace('+', '-').replace('--', '-')
            # log_utils.log('projectfree - url: ' + repr(url))

            r = cfScraper.get(url, timeout=20).text
            #r = py_tools.ensure_text(r, errors='ignore')
            try:
                data = re.compile('<a href="(.+?)" target="_blank" rel="nofollow" title=').findall(r)
                log_utils.log('projectfree - data: ' + repr(data))
                for url in data:
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    if valid:
                        quality, info = source_utils.get_release_quality(url, url)
                        sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'direct': False, 'debridonly': False})
            except:
                log_utils.error(f'{__name__}_ sources: ')
            return sources
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return sources


    def resolve(self, url):
        return url

