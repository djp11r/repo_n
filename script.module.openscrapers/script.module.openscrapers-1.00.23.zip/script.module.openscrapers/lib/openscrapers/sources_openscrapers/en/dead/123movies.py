# -*- coding: utf-8 -*-

import re

from openscrapers import cfScraper
from openscrapers import parse_qs, urljoin, urlparse, urlencode
from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import directstream
from openscrapers.modules import log_utils
from openscrapers.modules import source_utils
from openscrapers import custom_base_link
custom_base = custom_base_link(__name__)


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['www11.123movie.movie', '123moviesfree.so']
        self.base_link = custom_base if custom_base else 'https://123moviesfree.so'
        self.search_link = '/movie/search/%s'

    def matchAlias(self, title, aliases):
        try:
            for alias in aliases:
                if cleantitle.get(title) == cleantitle.get(alias['title']):
                    return True
        except:
            return False

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            # aliases.append({'country': 'us', 'title': title})
            url = {'imdb': imdb, 'title': title, 'year': year, 'aliases': aliases}
            url = urlencode(url)
            return url
        except:
            log_utils.error(f'{__name__}_ movie: ')
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            # aliases.append({'country': 'us', 'title': tvshowtitle})
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year, 'aliases': aliases}
            url = urlencode(url)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url == None: return
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            log_utils.error(f'{__name__}_ episode: ')
            return

    def searchShow(self, title, season, aliases):
        try:
            #title = cleantitle.normalize(title)
            search = '%s Season %01d' % (title, int(season))
            url = urljoin(self.base_link, self.search_link % cleantitle.geturl(search))
            r = cfScraper.get(url, timeout=10).text
            r = client.parseDOM(r, 'div', attrs={'class': 'ml-item'})
            r = zip(client.parseDOM(r, 'a', ret='href'), client.parseDOM(r, 'a', ret='title'))
            r = [(i[0], i[1], re.findall('(.*?)\s+-\s+Season\s+(\d)', i[1])) for i in r]
            r = [(i[0], i[1], i[2][0]) for i in r if len(i[2]) > 0]
            url = [i[0] for i in r if self.matchAlias(i[2][0], aliases) and i[2][1] == season][0]
            url = urljoin(self.base_link, '%s/watching.html' % url)
            return url
        except:
            log_utils.error(f'{__name__}_ searchShow: ')
            return

    def searchMovie(self, title, year, aliases):
        try:
            #title = cleantitle.normalize(title)
            url = urljoin(self.base_link, self.search_link % cleantitle.geturl(title))
            r = cfScraper.get(url, timeout=10).text
            r = client.parseDOM(r, 'div', attrs={'class': 'ml-item'})
            r = zip(client.parseDOM(r, 'a', ret='href'), client.parseDOM(r, 'a', ret='title'))
            results = [(i[0], i[1], re.findall('\((\d{4})', i[1])) for i in r]
            try:
                r = [(i[0], i[1], i[2][0]) for i in results if len(i[2]) > 0]
                url = [i[0] for i in r if self.matchAlias(i[1], aliases) and (year == i[2])][0]
            except:
                url = None
                pass

            if url == None:
                url = [i[0] for i in results if self.matchAlias(i[1], aliases)][0]

            url = urljoin(self.base_link, '%s/watching.html' % url)
            return url
        except:
            log_utils.error(f'{__name__}_ searchMovie: ')
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:

            if url == None: return sources

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            aliases = eval(data['aliases'])

            if 'tvshowtitle' in data:
                ep = data['episode']
                url = '%s/film/%s-season-%01d/watching.html?ep=%s' % (self.base_link, cleantitle.geturl(data['tvshowtitle']), int(data['season']), ep)
                # url = f"{self.base_link}/watch-the-{cleantitle.geturl(data['tvshowtitle'])}-{data['year']}/season-{int(data['season'])}/episode-1-123movies.html"
                # r = client.request(url, timeout='10', output='geturl')
                # url = r if r else self.searchShow(data['tvshowtitle'], data['season'], aliases)
                # log_utils.log('123movies url: ' + repr(url))

            else:
                url = self.searchMovie(data['title'], data['year'], aliases)

            #print(f'url: {url}')
            if url is None: raise Exception()

            r = cfScraper.get(url, timeout=10).text
            # client.testing_write_html(url, r)
            if "Oops, sorry we can't find that page!" in r: return sources
            #print(f'r: {r}')
            r = client.parseDOM(r, 'div', attrs={'class': 'les-content'})
            if 'tvshowtitle' in data:
                ep = data['episode']
                links = client.parseDOM(r, 'a', attrs={'episode-data': ep}, ret='player-data')
            else:
                links = client.parseDOM(r, 'a', ret='player-data')

            for link in links:
                try:
                    if link.startswith('//'):
                        link = 'https:' + link
                    host = re.findall(r'([\w]+[.][\w]+)$', urlparse(link.strip().lower()).netloc)[0]
                    if not host in hostDict: raise Exception()
                    host = client.replaceHTMLCodes(host)
                    # host = host.encode('utf-8')

                    if 'load.php' not in link:
                        sources.append({'source': host, 'quality': '720p', 'language': 'en', 'url': link, 'direct': False, 'debridonly': False})
                except:
                    log_utils.error(f'{__name__}_ sources: ')
                    pass
            return sources
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        if "google" in url:
            return directstream.googlepass(url)
        else:
            return url


    def tunestream(self, url, hostDict):
        sources = [] # 'https://tunestream.net/embed-f1m4uqrfm987.html'
        try:
            header = {'User-Agent': client.agent(), 'Referer': 'https://tunestream.net'}
            # page = ensure_text(client.request(url, headers=header), errors='replace')
            page = cfScraper.get(url, headers=header).text
            results = re.compile(r'sources\s*:\s*\[(.+?)\]').findall(page)[0]
            items = re.findall(r'''{(.+?)}''', results)
            for item in items:
                try:
                    link = re.findall(r'''file:"(.+?)"''', item)[0]
                    label = re.findall(r'''label:"(.+?)"''', item)[0]
                except:
                    link = re.findall(r'''file:"(.+?)"''', item)[0]
                    label = 'SD'
                valid, host = source_utils.is_host_valid(link, hostDict)
                quality, info = source_utils.get_release_quality(label, link)
                # log_utils.log('Addon Testing tunestream src link: \n' + repr(link))
                link += '|%s' % urlencode(header)
                sources.append({'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': link, 'direct': True, 'debridonly': False})
            return sources
        except Exception:
            log_utils.error(f'{__name__}_ tunestream: ')
            return sources



"""
https://123movies.sc/watch-the-tomorrow-war-2021-123movies.html

<div class="server_plugins">
    <a class="btn-server">Playing on <span class="playing-on"></span></a>
    <div id="servers-list" data-id="1">
        <ul id="ip_server">
            <li>
            <a class="server_6" data-film="28064" data-name="1" data-server="6" href="https://123movies.sc/watch-the-tomorrow-war-2021-123movies.html?p=1&s=6">Server VIP</a>
            </li>
            <li>
            <a class="server_15" data-film="28064" data-name="1" data-server="15" href="https://123movies.sc/watch-the-tomorrow-war-2021-123movies.html?p=1&s=15">Netu.TV</a>
            </li>
            <li>
            <a class="server_25" data-film="28064" data-name="1" data-server="25" href="https://123movies.sc/watch-the-tomorrow-war-2021-123movies.html?p=1&s=25">Fembed</a>
            </li>
        </ul>
    </div>
</div>


"""
