# -*- coding: utf-8 -*-

# import re
# import requests
# import simplejson as json

from openscrapers import parse_qs, urljoin, urlencode, quote_plus
from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import source_utils, log_utils
#from openscrapers import cfScraper
from openscrapers.modules.hindi_sources import read_write_file

from openscrapers import custom_base_link
custom_base = custom_base_link(__name__)

class source:
    def __init__(self):
        self.priority = 40
        self.language = ['en']
        self.domains = ['levidia.ch']
        self.base_link = custom_base if custom_base else 'https://www.levidia.ch'
        self.search_link = '/search.php?q=%s'
        self.headers = {'User-Agent': client.agent(), 'Referer': self.base_link}

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            search_id = cleantitle.getsearch(title)
            url = urljoin(self.base_link, self.search_link)
            url = url % '%s+%s&v=movies' % (search_id.replace(' ', '+').replace('-', '+').replace('++', '+'), year)
            print('movie url: {}'.format(url))
            search_results = client.r_request(url, headers=self.headers, timeout=10).text
            # search_results = read_write_file(file_n='m1www.levidia.ch.html')
            videoArea = client.parseDOM(search_results, 'li', attrs={'class': 'mlist'})
            # print('videoArea {}'.format(videoArea))
            for item in videoArea:
                # print('item {}'.format(item))
                if search_id in item.lower():
                    if year in str(item):
                        url = client.parseDOM(videoArea, 'a', ret='href')[0]
                        url = urljoin(self.base_link, url) if not url.startswith(self.base_link) else url
                        # print('>>> url {}'.format(url))
                        return url
            return
        except:
            log_utils.error(f'{__name__}_ movie: ')
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            tvshowtitle = 'Friends'
            year = '1994'
            tvshowTitle = cleantitle.clean_search_query(tvshowtitle)
            link = urljoin(self.base_link, self.search_link % (tvshowTitle))
            print('tvshow tvshowTitle: {} link: {}'.format(tvshowTitle, link))
            # search_results = client.r_request(link, headers=self.headers).text
            search_results = read_write_file(file_n='tv1www.levidia.ch.html')
            videoArea = client.parseDOM(search_results, 'li', attrs={'class': 'mlist'})
            # print('videoArea {}'.format(videoArea))
            for item in videoArea:
                # print('item {}'.format(item))
                if tvshowTitle.lower() in item.lower():
                    # print('item {}'.format(item))
                    if year in str(item):
                        url = client.parseDOM(videoArea, 'a', ret='href')[0]
                        url = urljoin(self.base_link, url) if not url.startswith(self.base_link) else url
                        # print('>>> url {}'.format(url))
                        url = {'tvshowtitle': tvshowtitle, 'url': url}
                        return url
        except Exception:
            log_utils.error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return
            # print('url {}'.format(url['url']))
            # episodePage = client.r_request(url, headers=self.headers).text
            search_results = read_write_file(file_n='tv2www.levidia.ch.html')
            videoArea = client.parseDOM(search_results, 'li', attrs={'class': 'mlist links'})
            search_id = '{}-s{}e{}'.format(url['tvshowtitle'].lower(), season, episode)

            for item in videoArea:
                # print('item {}'.format(item))
                if search_id in item.lower():
                    # print('>>>>> item {}'.format(item))
                    url = client.parseDOM(item, 'a', ret='href')[0]
                    url = urljoin(self.base_link, url) if not url.startswith(self.base_link) else url
                    return url
        except Exception:
            log_utils.error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url is None: return sources
            # host_dict = hostprDict + hostDict

            # r = client.r_request(url, headers=self.headers).text
            r = read_write_file(file_n='tv3www.levidia.ch.html')
            # videoArea = client.parseDOM(r, 'span', attrs={'class': 'mainlink .*?'})
            videoArea = client.parseDOM(r, 'li', attrs={'class': 'xxx0'})
            # print('videoArea {}'.format(videoArea))
            for item in videoArea:
                # print('item {}'.format(item))
                urlitem = client.parseDOM(item, 'span', attrs={'class': 'mainlink .*?'})[0]
                # print('urlitem {}'.format(urlitem))
                url = client.parseDOM(urlitem, 'a', ret='href')[0]
                source = client.parseDOM(item, 'img', ret='alt')[0]
                # print('url {}'.format(url))
                url = "%s%s" % (url, source_utils.append_headers(self.headers))
                sources.append({'source': source, 'quality': 'SD', 'language': 'en', 'info': '', 'url': url, 'direct': False, 'debridonly': False})
            return sources
        except:
            log_utils.error('%s_ sources: ' % __name__)
            return sources

    def resolve(self, url):
        return url



