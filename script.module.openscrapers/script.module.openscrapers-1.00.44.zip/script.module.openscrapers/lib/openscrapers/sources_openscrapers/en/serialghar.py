# -*- coding: UTF-8 -*-

import re
from openscrapers.modules.hindi_sources import get_source_dict, resolve_gen, get_query, query_cleaner
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.client import agent, request


class source:

    def __init__(self):
        self.name = 'serialghar'
        self.domains = ['serialghar.co']
        self.base_link = 'https://serialghar.co'
        self.headers = {'User-Agent': agent(), }


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f'From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year}')
        try:
            return f'{tvshowtitle}'
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def get_channel_name(self, tvdb):
        channel_name = tvdb.split('|')[1]
        if 'Sony' in channel_name: return 'sony-tv'
        elif 'Colors' in channel_name: return 'colors-tv'
        elif 'Sab TV' in channel_name: return 'sab-tv'
        elif 'Zee' in channel_name: return 'zee-tv'
        elif 'Star Plus' in channel_name: return 'star-plus'

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f'From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}')
        try:
            if type(tvdb) == int: return
            if 'episode' in title.lower(): return
            if '|' not in tvdb: return
            query = get_query(url)
            channel_name = self.get_channel_name(tvdb)
            # log(f'query {query} title: {title}')
            if re.search(r'the-kapil-sharma-show', query, re.I): query = 'the-kapil-sharma-show'
            elif re.search(r'indias-best-dancer', query, re.I): query = 'indias-best-dancer-3'
            elif re.search(r'india-got-talent-season-10', query, re.I): query = 'indias-got-talent'
            # elif re.search('crime-patrol', query, re.I): query = f'{query}-{title}-episode'
            # else: query = f'{query}-{title}-full-episode'
            query = query_cleaner(query)
            # show_url = f'{self.base_link}/{query}/'
            show_url = f'{self.base_link}/category/{channel_name}/{query}/'
            # log(f'show_url: {show_url}')
            if result := request(show_url, headers=self.headers):
                qepisode = title.replace('Episode ', '')
                release_title = f'season-{season}-episode-{qepisode}'
                results = parseDOM(result, 'h2', attrs={'class': 'post-box-title'})
                # log(f'From: {__name__} total: {len(results)} result1 {results}')
                # results = parseDOM(result.text, 'div', attrs={'class': 'blog-posts posts-medium posts-container'})
                # log(f'From: {__name__} total: {len(results)} result2 {results}')
                for item in results:
                    # log(f'{__name__} episode item: {item}')
                    urls = parseDOM(item, "a", ret="href")
                    # log(f'{__name__} release_title: {release_title} url: {urls}')
                    for url in urls:
                        if release_title in url:
                            # log(f'@@@@@ {__name__} episode item: {item}')
                            break
                return url
        except:
            error(f'{__name__}_ episode: ')
            return


    def sources(self, url, hostDict):
        # log(f'From: {__name__} url {url}')
        sources = []
        try:
            if not url: return sources
            result = request(url, headers=self.headers)
            if not result: return sources
            # read_write_file(read=False, result=result)
            result = parseDOM(result, 'div', attrs={'class': 'entry'})
            items = parseDOM(result, 'p')
            for item in items:
                urls = parseDOM(item, 'a', attrs={'target': '_blank'}, ret='href')
                # log(f'total: {len(urls)} urls: {urls}')
                final_url = []
                for iurl in urls:
                    if iurl not in final_url: final_url.append(iurl)
                if final_url: sources = get_source_dict(final_url, sources)
            if not sources: log(f'From: {__name__} no sources on url {url}')
            return sources
        except:
            error(f'{__name__}_ sources url: {url} ')
            return sources


    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return resolve_gen(url)