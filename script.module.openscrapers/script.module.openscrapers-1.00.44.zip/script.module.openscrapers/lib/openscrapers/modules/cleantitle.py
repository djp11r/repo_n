# -*- coding: utf-8 -*-
"""
    OpenScrapers Module
"""

import re
import unicodedata
from string import printable
from six import ensure_str, ensure_text, PY2
from six.moves.urllib_parse import unquote

from openscrapers.modules import client
from openscrapers.modules import client_utils
andToggle = False


def normalize(title):
    try:
        title = ''.join(c for c in unicodedata.normalize('NFKD', title) if unicodedata.category(c) != 'Mn')
        # title = u''.join(c for c in unicodedata.normalize('NFKD', ensure_text(title)) if c in printable)
        return title
    except:
        from openscrapers.modules import log_utils
        log_utils.error()
        return title


def get_title(title, sep=' '):
    if not title: return
    try: title = ensure_str(title)
    except: title = title
    title = title.lower()
    title = re.sub(r'(\d{4})', '', title)
    title = re.sub(r'&#(\d+);', '', title)
    title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
    # title = re.sub(r'\n|[()[\]{}]|\s(vs[.]?|v[.])\s|[:;–\-",\'!_.?~]|\s', '', title) # keeps bracketed content unlike .get()
    #title = re.sub(r'\n|[()[\]{}]|[:;–\-",\'!_.?~$@]|\s', '', title) # stop trying to remove alpha characters "vs" or "v", they're part of a title
    #title = re.sub(r'<.*?>', '', title) # removes tags
    title = title.replace('&quot;', '\"').replace('&amp;', 'and').replace('&', 'and').replace('.html', '').replace('_', sep)
    title = normalize(title)
    title = re.sub('[^\w\%s]+' % sep, sep, title)
    title = re.sub('\%s{2,}' % sep, sep, title)
    title = title.strip(sep)
    return title


def get(title):
    if not title: return
    try:
        title = ensure_str(title)
    except:
        title = title
    title = title.lower()
    title = re.sub(r'&#(\d+);', '', title)
    title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title) # fix html codes with missing semicolon between groups
    title = title.replace('&quot;', '\"').replace('&amp;', '&').replace('&nbsp;', '').replace('–', '-').replace('!', '')
    #title = re.sub(r'[<\[({].*?[})\]>]|[^\w0-9]|[_]', '', title) #replaced with lines below to stop removing () and everything between.
    title = re.sub(r'\([^\d]*(\d+)[^\d]*\)', '', title) #eliminate all numbers between ()
    title = re.sub(r'[<\[{].*?[}\]>]|[^\w0-9]|[_]', '', title)
    #title = re.sub(r'\n|([\[({].+?[})\]])|([:;–\-"\',!_.?~$@])|\s', '', title) # stop trying to remove alpha characters "vs" or "v", they're part of a title
    return title


def getsearch(title):
    if not title: return
    try: title = ensure_str(title, errors='ignore')
    except: title = title
    title = title.lower()
    title = re.sub(r'&#(\d+);', '', title)
    title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
    title = title.replace(r'&quot;', '\"').replace('&amp;', '&').replace('–', '-')
    title = re.sub(r'\\\|/|-|–|:|;|!|\*|\?|"|\'|<|>|\|', '', title)
    return title


def geturl(title):
    if not title: return
    try: title = ensure_str(title, errors='ignore')
    except: title = title
    title = title.lower()
    title = title.rstrip()
    try:
        try: title = title.translate(None, ':*?"\'\.<>|&!,')
        except:
            try: title = title.translate(str.maketrans('', '', ':*?"\'\.<>|&!,'))
            except:
                for c in r':*?"\'\.<>|&!,': title = title.replace(c, '')
        title = title.replace('/', '-').replace(' ', '-').replace('--', '-').replace('–', '-')
        return title
    except:
        from openscrapers.modules import log_utils
        log_utils.error()
        return title


def get_under(title):
    if title is None: return
    title = getsearch(title)
    title = title.replace(' ', '_')
    title = title.replace('__', '_')
    return title


def get_dash(title):
    if title is None: return
    title = getsearch(title)
    title = title.replace(' ', '-')
    title = title.replace('--', '-')
    return title


def get_plus(title):
    if title is None: return
    title = getsearch(title)
    title = title.replace(' ', '+')
    title = title.replace('++', '+')
    return title


def get_utf8(title):
    if title is None: return
    title = getsearch(title)
    title = title.replace(' ', '%20')
    title = title.replace('%20%20', '%20')
    return title


def match_alias(title, aliases):
    try:
        return any(get(title) == get(alias['title']) for alias in aliases)
    except:
        return False


def match_year(item, year, premiered=None):
    try:
        if premiered is None:
            check1 = [(int(year))]
            check2 = [(int(year)-1), (int(year)), (int(year)+1)]
        else:
            check1 = [(int(year)), (int(premiered))]
            check2 = [(int(year)-1), (int(year)), (int(year)+1), (int(premiered)-1), (int(premiered)), (int(premiered)+1)]
        if any(str(y) in str(item) for y in check1):
            return True
        return any((str(y) in str(item) for y in check2))
    except:
        return False


def scene_title(title, imdb, year):
    title = normalize(title)
    try:
        title = ensure_str(title, errors='ignore')
    except:
        title = title
    title = title.replace('&', 'AAANNNDDD').replace('-', ' ').replace('–', ' ').replace('/', ' ').replace('*', ' ').replace('.', ' ')
    #title = re.sub('[^A-Za-z0-9 ]+', '', title)
    title = re.sub('[^\w\s]+', '', title)
    title = re.sub(' {2,}', ' ', title).strip()
    if andToggle == 'true':
        title = title.replace('AAANNNDDD', '&')
    else:
        title = title.replace('AAANNNDDD', 'and')
    if title.startswith('Birdman or') and year == '2014':
        title = 'Birdman'
    if title == 'Birds of Prey and the Fantabulous Emancipation of One Harley Quinn' and year == '2020':
        title = 'Birds of Prey'
    if title == "Roald Dahls The Witches" and year == '2020':
        title = 'The Witches'
    return title, imdb, year


def scene_tvtitle(title, imdb, year, season, episode):
    title = normalize(title)
    try:
        title = ensure_str(title, errors='ignore')
    except:
        title = title
    title = title.replace('&', 'AAANNNDDD').replace('-', ' ').replace('–', ' ').replace('/', ' ').replace('*', ' ').replace('.', ' ')
    #title = re.sub('[^A-Za-z0-9 ]+', '', title)
    title = re.sub('[^\w\s]+', '', title)
    title = re.sub(' {2,}', ' ', title).strip()
    if andToggle == 'true':
        title = title.replace('AAANNNDDD', '&')
    else:
        title = title.replace('AAANNNDDD', 'and')
    if title in ['The Haunting', 'The Haunting of Bly Manor', 'The Haunting of Hill House'] and year == '2018':
        if season == '1':
            title = 'The Haunting of Hill House'
        elif season == '2':
            title = 'The Haunting of Bly Manor'
            year = '2020'
            season = '1'
    if title in ['Cosmos', 'Cosmos A Spacetime Odyssey', 'Cosmos Possible Worlds'] and year == '2014':
        if season == '1':
            title = 'Cosmos A Spacetime Odyssey'
        elif season == '2':
            title = 'Cosmos Possible Worlds'
            year = '2020'
            season = '1'
    if 'Special Victims Unit' in title:
        title = title.replace('Special Victims Unit', 'SVU')
    if title == 'Cobra Kai' and year == '1984':
        year = '2018'
    if title == 'The End of the F ing World':
        title = 'The End of the Fucking World'
    if title == 'M A S H':
        title = 'MASH'
    if title == 'Lupin' and year == '2021' and (season == '1' and int(episode) > 5):
        season = '2'
        episode = str(int(episode) - 5)
    if title == 'Bleach' and year == '2004' and season == '2':
        title = 'Bleach: Thousand-Year Blood War'
        #title = 'Bleach: Sennen Kessen-hen'
        year = '2022'
        season = '1'
        imdb = 'tt14986406'
    #if title == ('King and Maxwell' or 'King & Maxwell'):
        #title = 'King & Maxwell'
    #if title == 'The Office' and year == '2001':
        #title = 'The Office UK'
    #if title == 'House': #Isnt really needed but gives more accurate results this way. might just add it to the scrapers it works on.
        #title = 'House M.D.'
    return title, imdb, year, season, episode


def get_url(title):
    if not title: return
    title = title.replace(' ', '%20').replace('–', '-').replace('!', '')
    return title


def get_gan_url(title):
    if not title: return
    title = title.lower()
    title = title.replace('-', '+')
    title = title.replace(' + ', '+-+')
    title = title.replace(' ', '%20')
    return title


def get_query_(title):
    if title is None: return
    title = title.replace(' ', '_').replace("'", "_").replace('-', '_').replace('–', '_').replace(':', '').replace(',', '').replace('!', '')
    return title.lower()


def query(title):
    if not title: return
    title = title.replace('\'', '').rsplit(':', 1)[0].rsplit(' -', 1)[0].replace('-', ' ').replace('–', ' ').replace('!', '')
    return title


def get_query(title):
    if not title: return
    title = title.replace(':', '').replace(' ', '.').replace('.-.', '.').replace('\'', '').replace("'", "").lower()
    return title


def clean_search_query(url):
    url = url.replace('-','+').replace(' ', '+').replace('–', '+').replace('!', '')
    return url


def comper_title(title):
    if not title: return
    title = title.replace(' ', '-').replace(':', '').replace('.-.', '.').replace('\'', '').lower()
    return title


def get_simple(title):
    try:
        if not title: return
        title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title).lower()# fix html codes with missing semicolon between groups
        title = re.sub(r'&#(\d+);', '', title)
        title = re.sub(r'(\d{4})', '', title)
        title = title.replace('&quot;', '\"').replace('&amp;', '&').replace('&nbsp;', '')
        # title = re.sub(r'\n|[()[\]{}]|\s(vs[.]?|v[.])\s|[:;–\-",\'!_.?~]|\s', '', title) # keeps bracketed content unlike .get()
        title = re.sub(r'\n|[()[\]{}]|[:;–\-",\'!_.?~$@]|\s', '', title) # stop trying to remove alpha characters "vs" or "v", they're part of a title
        title = re.sub(r'<.*?>', '', title) # removes tags
        return title
    except:
        from openscrapers.modules import log_utils
        log_utils.error()
        return title
