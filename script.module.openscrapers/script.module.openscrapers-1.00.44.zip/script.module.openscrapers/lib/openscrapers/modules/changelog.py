# -*- coding: utf-8 -*-
"""
	OpenScrapers Module
"""

from openscrapers.modules.control import addonPath, addonVersion, joinPath
from openscrapers.windows.textviewer import TextViewerXML


def get():
	scrapers_path = addonPath()
	scrapers_version = addonVersion()
	changelogfile = joinPath(scrapers_path, 'changelog.txt')
	with open(changelogfile, mode='r', encoding='utf-8', errors='ignore') as f:
		text = f.read()
	heading = f'[B]OpenScrapers -  v{scrapers_version} - ChangeLog[/B]'
	windows = TextViewerXML('textviewer.xml', scrapers_path, heading=heading, text=text)
	windows.run()
	del windows
