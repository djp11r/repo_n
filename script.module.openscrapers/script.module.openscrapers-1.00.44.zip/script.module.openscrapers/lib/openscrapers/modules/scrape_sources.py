# -*- coding: utf-8 -*-

"""Example...
from resources.lib.modules import scrape_sources
for source in scrape_sources.process(hostDict, link, host=None, info=None):
    sources.append(source)
scrape_sources.rescrape(url, regex=None)
scrape_sources.prepare_link(url)
if not link: continue
"""

import base64
import re, json
import requests

from openscrapers import parse_qs, urlencode

from openscrapers.modules.client import request, parseDOM, agent, UserAgent, dnt_headers
from openscrapers.modules import client_utils
from openscrapers.modules import jsunpack
from openscrapers.modules.source_utils import get_release_quality, is_host_valid, check_url, checkHost, supported_video_extensions, append_headers
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.py_tools import six_decode, ensure_str, ensure_text

host_limit = 'true'
# Using these gdriveplayer_domains in prepare_link to be lazy. Some are just fake-makes that i tossed in incase they ever show up lol.
gdriveplayer_domains = ['database.gdriveplayer.co', 'database.gdriveplayer.io', 'database.gdriveplayer.me', 'database.gdriveplayer.us', 'database.gdriveplayer.xyz',
    'database,gdriveplayer.co', 'database,gdriveplayer.io', 'database,gdriveplayer.me', 'database,gdriveplayer.us', 'database,gdriveplayer.xyz', # This lines just ghetto made alts incase the api links are fuckered.
    'databasegdriveplayer.co', 'databasegdriveplayer.io', 'databasegdriveplayer.me', 'databasegdriveplayer.us', 'databasegdriveplayer.xyz',
    'series.databasegdriveplayer.co', 'series.databasegdriveplayer.io', 'series.databasegdriveplayer.me', 'series.databasegdriveplayer.us', 'series.databasegdriveplayer.xyz' # Lazy line beisdes the first one lol.
]
gomo_domains = ['playerhost.net', 'gomo.to', 'gomostream.com', 'gomoplayer.com']
hlspanel_domains = ['hlspanel.xyz']
linkbin_domains = ['linkbin.me']
ronemo_domains = ['ronemo.com']
source_stream_domains = [] # Saved for ramdom odd ones found later lol.
superembed_domains = ['streamembed.net']
twoembed_domains = ['2embed.ru', '2embed.to', '2embed.cc']
vidembed_domains = ['goload.io', 'goload.pro', 'membed1.com', 'membed.co', 'membed.net', 'movembed.cc',
    'vidcloud9.com', 'vidembed.cc', 'vidembed.io', 'vidembed.me', 'vidembed.net', 'vidnext.net', 'vidnode.net',
    'anihdplay.com', 'gotaku1.com', 'playtaku.net', 'playtaku.online'
]
vidlink_domains = ['vidlink.org']
vidsrc_domains = ['v2.vidsrc.me', 'vidsrc.me']
voxzer_domains = ['voxzer.org']
######################################################
############ Used for prepare_link.
######################################################
# these redirect to a new domain: clicknupload.click
clicknupload_redir_domains = ['clicknupload.click', 'clicknupload.com', 'clicknupload.link', 'clicknupload.me', 'clicknupload.to']
clicknupload_working_domains = ['clicknupload.cc', 'clicknupload.club', 'clicknupload.co', 'clicknupload.org', 'clicknupload.red']
######################################################
# Spare Alt  doodstream.co | dood.cx fails and all others redirect to doodstream.com
doodstream_redir_domains = ['dood.cx', 'dood.la', 'dood.pm', 'dood.re', 'dood.sh',
    'dood.so', 'dood.to', 'dood.watch', 'dood.wf', 'dood.ws', 'dood.yt', 'dooood.com'
]
######################################################
entervideo_failing_domains = ['entervideo.net', 'eplayvid.com']
######################################################
# Spare Alt  gotaku1.com, playtaku.net, playtaku.online
goload_failing_domains = ['gogohd.pro', 'goload.io', 'streamani.net', 'vidstreaming.io', 'anihdplay.com']
goload_redir_domains = ['gembedhd.com', 'gogo-play.net', 'gogohd.net', 'goload.pro', 'playgo1.cc']
goload_failing_domains += goload_redir_domains
######################################################
gomoplayer_failing_domains = ['gomoplayer.com', 'tunestream.net']
######################################################
streamsb_failing_domains = ['p1ayerjavseen.com', 'sbplay1.com', 'sbplay2.xyz', 'sbplay.org', 'sbface.com']
streamsb_working_domains = ['aintahalu.sbs', 'arslanrocky.xyz', 'cloudemb.com', 'embedsb.com', 'embedtv.fun',
    'gomovizplay.com', 'japopav.tv', 'javplaya.com', 'javside.com', 'lvturbo.com', 'playersb.com', 'sbanh.com',
    'sbani.pro', 'sbasian.pro', 'sbbrisk.com', 'sbchill.com', 'sbembed1.com', 'sbembed.com', 'sbface.com',
    'sbfast.com', 'sbfull.com', 'sbhight.com', 'sblanh.com', 'sblongvu.com', 'sbnet.one', 'sbone.pro',
    'sbplay2.com', 'sbplay.one', 'sbrapid.com', 'sbrity.com', 'sbspeed.com', 'sbthe.com', 'sbvideo.net',
    'ssbstream.net', 'streamovies.xyz', 'streamsb.net', 'streamsss.net', 'tubesb.com', 'tvmshow.com',
    'vidmovie.xyz', 'vidmoviesb.xyz', 'viewsb.com', 'watchsb.com'
]
######################################################
# These redirect to ahvsh.com but swapped to streamhide.com for dupe checks.
streamhide_redir_domains = ['ahvsh.com', 'guccihide.com', 'louishide.com']
streamhide_working_domains = ['streamhide.com', 'streamhide.to', 'movhide.pro', 'moviesm4u.com', 'bikurathulw.sbs', 'javb1.com']
######################################################
# Spare Alt  movembed.cc | The redirects goto membed1.com i think but done now to be lazy and for dupe checks.
vidcloud9_failing_domains = ['membed.co', 'vidembed.io', 'vidembed.me', 'vidembed.net', 'vidcloud.icu']
vidcloud9_redir_domains = ['membed.net', 'vidcloud9.com', 'vidembed.cc', 'vidnext.net', 'vidnode.net']
vidcloud9_failing_domains += vidcloud9_redir_domains
######################################################
vidcloud_failing_domains = ['vidcloud.pro', 'vidcloud.is']
######################################################
twoembed_failing_domains = ['2embed.ru', '2embed.to']
######################################################
video_extensions = ['.m4v', '.3g2', '.3gp', '.nsv', '.tp', '.ts', '.ty', '.strm', '.pls', '.rm', '.rmvb', '.mpd', '.m3u', '.m3u8', '.mov', '.qt', '.divx', '.xvid', '.bivx', '.vob', '.udf', '.pva', '.wmv', '.asf', '.m2v', '.avi', '.mpg', '.mpeg', '.mp4', '.mkv', '.mk3d', '.avc', '.vp3', '.svq3', '.nuv', '.viv', '.dv', '.fli', '.flv', '.001', '.wpl', '.xspf', '.vdr', '.dvr-ms', '.xsp', '.mts', '.m2t', '.m2ts', '.evo', '.ogv', '.sdp', '.avs', '.rec', '.url', '.pxml', '.vc1', '.h264', '.rcv', '.mpls', '.mpl', '.webm', '.bdmv', '.bdm', '.wtv', '.trp', '.f4v', '.pvr']

def prepare_link(url):
    if not url:
        return
    url = url.replace("\/", "/")
    url = url.replace("\\", "")
    url = url.replace('///', '//')
    url = f'https:{url}' if url.startswith('//') else url
    if not url.startswith('http'):
        url = re.sub('\s+', '', url)
    if not url.startswith('http'):
        #log_utils.log('scrape_sources - prepare_link NOT-link: ' + str(url))
        return
    u = url.replace('//www.', '//')
    try:
        old_domain = re.findall('//(.+?)/', u)[0]
    except:
        log(f'scrape_sources - prepare_link - old_domain failed-url: {u}')
        return
    if old_domain in clicknupload_redir_domains:
        url = url.replace(old_domain, 'clicknupload.org')
    elif old_domain in doodstream_redir_domains:
        url = url.replace(old_domain, 'doodstream.com')
    elif old_domain in entervideo_failing_domains:
        url = url.replace(old_domain, 'eplayvid.net')
    elif old_domain in gdriveplayer_domains:
        url = url.replace(old_domain, 'databasegdriveplayer.xyz')
    elif old_domain in goload_failing_domains:
        url = url.replace(old_domain, 'gotaku1.com')
    elif old_domain in gomoplayer_failing_domains:
        url = url.replace(old_domain, 'xvideosharing.com')
    elif old_domain in streamhide_redir_domains:
        url = url.replace(old_domain, 'streamhide.com')
    elif old_domain in streamsb_failing_domains:
        url = url.replace(old_domain, 'embedsb.com')
    elif old_domain in vidcloud9_failing_domains:
        url = url.replace(old_domain, 'membed1.com')
    elif old_domain in vidcloud_failing_domains:
        url = url.replace(old_domain, 'vidcloud.co')
    elif old_domain in twoembed_failing_domains:
        url = url.replace(old_domain, '2embed.cc')
    elif old_domain == 'aparat.cam':
        url = url.replace(old_domain, 'wolfstream.tv')
    elif old_domain == 'clipwatching.com':
        url = url.replace(old_domain, 'highstream.tv')
    elif old_domain == 'cloudvid.co':
        url = url.replace(old_domain, 'cloudvideo.tv')
    elif old_domain == 'fastclick.to':
        url = url.replace(old_domain, 'drop.download')
    elif old_domain == 'gomostream.com':
        url = url.replace(old_domain, 'gomo.to')
    elif old_domain == 'sendit.cloud':
        url = url.replace(old_domain, 'send.cm')
    elif old_domain == 'streamvid.co':
        url = url.replace(old_domain, 'streamvid.cc')
    if '//vidcloud.co/embed/' in u:
        url = url.replace('/embed/', '/v/')  # Ghetto fix to get the resolver pattern to notice the url
    #log_utils.log('scrape_sources - prepare_link link: ' + str(url))
    # this log line should log atleast 90% of the source links when used. altho its gonna have dupes and links from before and after various process steps.
    return url


def check_host_limit(item, items): # lazy way to not import source_utils if i dont gotta and a little less code use sorta.
    return host_limit == 'true' and item in str(items)


def check_direct(hostDict, url, host=None): # unused code saved. now works like is_host_valid but as direct lol.
    try:
        url = prepare_link(url)
        if not url:
            raise Exception()
        host = host or url
        direct_check = tuple(supported_video_extensions())
        valid, host = is_host_valid(host, hostDict)
        if valid:
            return False, url
        elif '/hls/' in url or url.endswith(direct_check):
            return True, url
        return False, url
    except Exception as Err:
        log(f'check_direct: {Err}', 1)
        return False, url


def make_direct_item(hostDict, link, host=None, info=None, referer=None, prep=False):
    item = {}
    try:
        if prep:
            link = prepare_link(link)
        if not link:
            return item
        host = link if host is None else host
        info = link if info is None else info
        valid, host = is_host_valid(host, hostDict)
        quality, info = get_release_quality(link, info)
        if not any(x in link.lower() for x in video_extensions): direct = False
        else: direct = True
        if referer:
            link += append_headers({'Referer': referer})
        return {'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': direct,}
    except Exception as Err:
        log(f'make_direct_item: Err: {Err}', 1)
        return item


def make_item(hostDict, link, host=None, info=None, prep=False):
    item = {}
    try:
        if prep:
            link = prepare_link(link)
        if not link:
            return item
        host = link if host is None else host
        info = link if info is None else info
        valid, host = is_host_valid(host, hostDict)
        if valid:
            quality, info = get_release_quality(link, info)
            item = {'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False}
        #else: log_utils.log('scrape_sources - make_item - non-valid link: ' + str(link))
        #log_utils.log('scrape_sources - make_item item: ' + str(item))
        return item
    except Exception as Err:
        log(f'make_item: Err: {Err}', 1)
        return item


def process(hostDict, link, host=None, info=None):
    sources = []
    try:
        link = prepare_link(link)
        if link is None: return sources
        # print("getMore url In: {}".format(link))
        host = link if host is None else host
        info = link if info is None else info
        if any(i in host for i in gdriveplayer_domains):
            sources.extend(iter(gdriveplayer(link, hostDict, info=info)))
        elif any(i in host for i in gomo_domains):
            sources.extend(iter(gomo(link, hostDict, info=info)))
        elif any(i in host for i in hlspanel_domains):
            sources.extend(iter(hlspanel(link, hostDict, info=info)))
        elif any(i in host for i in linkbin_domains):
            sources.extend(iter(linkbin(link, hostDict, info=info)))
        elif any(i in host for i in ronemo_domains):
            sources.extend(iter(ronemo(link, hostDict, info=info)))
        elif any(i in host for i in source_stream_domains):
            sources.extend(iter(source_stream(link, hostDict, info=info)))
        elif any(i in host for i in superembed_domains):
            sources.extend(iter(superembed(link, hostDict, info=info)))
        # elif any(i in host for i in twoembed_domains):
            # sources.extend(iter(twoembed(link, hostDict, info=info)))
        elif any(i in host for i in vidembed_domains):
            sources.extend(iter(vidembed(link, hostDict, info=info)))
        elif any(i in host for i in vidlink_domains):
            sources.extend(iter(vidlink(link, hostDict, info=info)))
        # elif any(i in host for i in vidsrc_domains):
            # sources.extend(iter(vidsrc(link, hostDict, info=info)))
        elif any(i in host for i in voxzer_domains):
            sources.extend(iter(voxzer(link, hostDict, info=info)))
        else:
            try:
                if item := make_item(hostDict, link, host=host, info=info):
                    sources.append(item)
            except:
                pass
        return sources
    except Exception:
        return sources
        # elif "cloudvideo.tv" in link:
            # for source in cloudvideo(link, hostDict):
                # sources.append(source)
        # elif "abcvideo.cc" in link:
            # for source in abcvideo(link, hostDict):
                # sources.append(source)
        # elif "vidoza.net" in link:
            # for source in vidoza(link, hostDict):
                # sources.append(source)
        # elif "upstream.to" in link:
            # for source in upstream(link, hostDict):
                # sources.append(source)
        # elif "mixdrop.co" in link:
            # for source in mixdrop(link, hostDict):
                # sources.append(source)
        # elif "mediashore.org" in link:
            # for source in mediashore(link, hostDict):
                # sources.append(source)
        # elif "movcloud" in link:
            # for source in movcloud(link, hostDict):
                # sources.append(source)
        # elif "vidcloud.pro" in link:
            # for source in vidcloud_pro(link, hostDict):
                # sources.append(source)
        # elif 'vidcloud9' in link:
            # for source in vidcloud9(link, hostDict):
                # sources.append(source)
        # elif 'vidsrc' in link:
            # for source in vidsrc(link, hostDict):
                # sources.append(source)
        # elif 'vidsrc.me' in link:
            # for source in vidsrc_me(link, hostDict):
                # sources.append(source)
        # elif 'vidnext.net' in link:
            # for source in vidnext_net(link, hostDict):
                # sources.append(source)
        # elif 'vidoo' in link:
            # for source in vidoo(link, hostDict):
                # sources.append(source)
        # elif 'hls3x.vidcloud9.com' in link:
            # for source in hls3x(link, hostDict):
                # sources.append(source)
        # elif 'fmovies' in link:
            # for source in fmovies_to(link, hostDict):
                # sources.append(source)


def rescrape(url, regex=None): # unused old code saved.
    try:
        link = prepare_link(url)
        html = request(link, headers={'User-Agent': UserAgent, 'Referer': link})
        if regex:
            link = re.findall(regex, html)[0]
        else:
            link = re.findall(r'(?:file|source)(?:\:)\s*(?:\"|\')(.+?)(?:\"|\')', html)[0]
        return link
    except Exception as Err:
        log(f'rescrape: Err: {Err}', 1)
        return url


def linkbin(link, hostDict, info=None):
    sources = [] # Last Tested/Checked: 6-28-2023  Status: Working.
    try:
        html = request(link, headers={'User-Agent': UserAgent, 'Referer': link})
        results = parseDOM(html, 'li', attrs={'class': 'signle-link'})
        results = [(parseDOM(i, 'a', ret='href'), parseDOM(i, 'a')) for i in results]
        results = [(i[0][0], i[1][0]) for i in results if len(i[0]) > 0 and len(i[1]) > 0]
        for result in results:
            try:
                url = prepare_link(result[0])
                if not url:
                    continue
                if info:
                    info += f' {result[1]}'
                else:
                    info = result[1]
                if item := make_item(hostDict, url, host=None, info=info):
                    sources.append(item)
            except:
                #log('linkbin', 1)
                pass
        return sources
    except Exception as Err:
        log(f'linkbin Err: {Err}', 1)
        return sources


def gomo(link, hostDict, info=None):
    sources = [] # Last Tested/Checked: 6-28-2023  Status: Working.
    try:
        domain = re.findall('(?://|\.)(playerhost\.net|gomo\.to|gomostream\.com|gomoplayer\.com)/', link)[0]
        #domain = re.findall(r'(?://|\.)(gomo(?:stream|player|)\.(?:com|to))', html, re.MULTILINE)[0]
        gomo_link = f'https://{domain}/decoding_v3.php'
        result = request(link, headers={'User-Agent': UserAgent, 'Referer': link})
        tc = re.compile('tc = \'(.+?)\';').findall(result)[0]
        if tc:
            token = re.compile('"_token": "(.+?)",').findall(result)[0]
            post = {'tokenCode': tc, '_token': token}
            def tsd(tokenCode):
                _13x48X = tokenCode
                # print(_13x48X[6:19]) # get 6 to 19 char
                # print(_13x48X[6:19][::-1]) # revers the srting
                #_71Wxx199 = _13x48X[6:19][::-1]
                #return _71Wxx199 + "19" + "666979"
                _71Wxx199 = _13x48X[4:18][::-1]
                return f"{_71Wxx199}18432782"
            headers = {'Host': domain, 'Referer': link, 'User-Agent': UserAgent, 'x-token': tsd(tc)}
            urls = request(gomo_link, XHR=True, post=post, headers=headers, output='json', timeout='5')
            for url in urls:
                try:
                    url = prepare_link(url)
                    if not url:
                        continue
                    if 'gomo.to' in url or 'playerhost.net' in url:
                        headers = {'User-Agent': UserAgent, 'Referer': url}
                        url = request(url, headers=headers, output='geturl', timeout='5')
                        url = prepare_link(url)
                        if not url:
                            continue
                        if url == 'http://ww1.gomoplayer.com/':
                            continue
                        if any(i in url for i in gdriveplayer_domains):
                            for source in gdriveplayer(url, hostDict):
                                sources.append(source)
                        else:
                            item = make_item(hostDict, url, host=None, info=info)
                            if item:
                                sources.append(item)
                            #else: log_utils.log('scrape_sources - gomo - non-item link1: ' + str(url))
                            #sources.append({'source': 'gomo', 'quality': 'SD', 'url': url, 'direct': True})
                    else:
                        item = make_item(hostDict, url, host=None, info=info)
                        if item:
                            sources.append(item)
                        #else: log_utils.log('scrape_sources - gomo - non-item link2: ' + str(url))
                except Exception as Err:
                    log(f'gomo: Err: {Err}', 1)
        return sources
    except Exception as Err:
        log(f'gomo: Err: {Err}', 1)
        return sources


def gdriveplayer(link, hostDict, info=None):
    sources = [] # Last Tested/Checked: 6-28-2023  Status: Working.
    try:
        html = request(link, headers={'User-Agent': UserAgent, 'Referer': link})
        servers = parseDOM(html, 'ul', attrs={'class': 'list-server-items'})[0]
        urls = parseDOM(servers, 'a', ret='href')
        for url in urls:
            try:
                if not url or url.startswith('/player.php'):
                    continue
                url = prepare_link(url)
                if not url:
                    continue
                if item := make_item(hostDict, url, host=None, info=info):
                    sources.append(item)
            except Exception as Err:
                log(f'gdriveplayer: Err: {Err}', 1)
        return sources
    except:
        return []


def vidembed(link, hostDict, info=None):
    sources = [] # Last Tested/Checked: 6-28-2023  Status: Working.
    try:
        try:
            html = request(link, headers={'User-Agent': UserAgent, 'Referer': link})
            urls = []
            urls += client_utils.parseDOM(html, 'li', ret='data-video')
            urls += client_utils.parseDOM(html, 'iframe', ret='src')
            if urls:
                for url in urls:
                    try:
                        url = prepare_link(url)
                        if not url:
                            continue
                        if item := make_direct_item(hostDict, url, host=None, info=info):
                            sources.append(item)
                    except Exception as Err:
                        log(f'vidembed: Err: {Err}', 1)
        except Exception as Err:
            log(f'vidembed: Err: {Err}', 1)
        # try:
            # if item := make_direct_item(hostDict, url, host=None, info=info):
                # sources.append(item)
            # else: log_utils.log('scrape_sources - vidembed - non-item link2: ' + str(link))
        # except:
            # log(f'vidembed: Err: {Err}', 1)
        return sources
    except Exception as Err:
        log(f'vidembed: Err: {Err}', 1)
        return sources


def vidlink(link, hostDict, info=None):
    sources = [] # Last Tested/Checked: 6-28-2023  Status: Blocked.(update_views page)
    try:
        #return sources # site for update_views bit needs cfscrape so the links are trash.
        # return sources is added to cock block the urls from being seen lol.
        postID = link.split('/embed/')[1]
        post_link = 'https://vidlink.org/embed/update_views'
        headers = {'User-Agent': UserAgent, 'Referer': link}
        if ihtml := request(
            post_link, post={'postID': postID}, headers=headers, XHR=True
        ):
            linkcode = client_utils.unpacked(ihtml)
            linkcode = linkcode.replace('\\', '')
            links = re.findall(r'var file1="(.+?)"', linkcode)[0]
            stream_link = links.split('/pl/')[0]
            headers = {'Referer': 'https://vidlink.org/', 'User-Agent': UserAgent}
            response = request(links, headers=headers)
            if urls := re.findall(
                r'[A-Z]{10}=\d+x(\d+)\W[A-Z]+=\"\w+\"\s+\/(.+?)\.', response
            ):
                for qual, url in urls:
                    url = f'{stream_link}/{url}.m3u8'
                    qual = qual if info is None else f'{qual} {info}'
                    #log('scrape_sources - process vidlink link: ' + str(url))
                    if item := make_direct_item(hostDict, url, host=None, info=info):
                        sources.append(item)
        return sources
    except Exception as Err:
        log(f'vidlink: Err: {Err}', 1)
        return sources


def vidsrc(link, hostDict, info=None):
    sources = [] # Last Tested/Checked: 6-28-2023  Status: Working.
    try:
        headers = {'User-Agent': UserAgent, 'Referer': 'https://v2.vidsrc.me/'}
        html = request(link, headers=headers)
        items = client_utils.parseDOM(html, 'div', ret='data-hash')
        for item in items:
            try:
                item_url = f'https://source.vidsrc.me/source/{item}'
                item_html = request(item_url, headers=headers)
                if not item_html:
                    continue
                item_html = str(item_html).replace("\'", '"')
                item_src = re.findall('src:\s*"([^"]+)"', item_html, re.DOTALL)[0]
                item_src = f'https:{item_src}' if item_src.startswith('//') else item_src
                item_link = request(item_src, headers=headers, output='geturl')
                url = prepare_link(item_link)
                if not url:
                    continue
                if item := make_direct_item(hostDict, url, host=None, info=info):
                    sources.append(item)
            except Exception as Err:
                log(f'vidsrc: Err: {Err}', 1)
        return sources
    except Exception as Err:
        log(f'vidsrc: Err: {Err}', 1)
        return sources


def twoembed(link, hostDict, info=None):
    sources = [] # Last Tested/Checked: 6-28-2023  Status: Working.
    try:
        
        headers = {'User-Agent': UserAgent, 'Referer': 'https://www.2embed.cc/'}
        link = link.replace('/embed/imdb/tv?id=', '/embed/')
        link = link.replace('/embed/imdb/movie?id=', '/embed/')
        link = link.replace('/embed/tmdb/tv?id=', '/embed/')
        link = link.replace('/embed/tmdb/movie?id=', '/embed/')
        html = request(link, headers=headers)
        iframe = client_utils.parseDOM(html, 'iframe', ret='src')[0]
        iframe_html = request(iframe, headers=headers)
        iframe_unpacked = client_utils.unpacked(iframe_html)
        iframe_sources = re.findall(r'sources:\[(.+?)\]', iframe_unpacked, re.S)[0]
        source_link = re.findall(r'(?:file|src)\s*(?:\:)\s*(?:\"|\')(.+?)(?:\"|\')', iframe_sources)[0]
        if item := make_direct_item(hostDict, source_link, host='2embed.cc', info=info, referer=link):
            sources.append(item)
        #else: log_utils.log('scrape_sources - twoembed - non-item link: ' + str(url))
        return sources
    except Exception as Err:
        log(f'twoembed: Err: {Err}', 1)
        return sources


def hlspanel(link, hostDict, info=None):
    sources = []
    try:
        headers = {'User-Agent': UserAgent, 'Referer': link, 'X-Requested-With': 'XMLHttpRequest'}
        url_hash = link.split('/video/')[1]
        getvid_link = f'https://hlspanel.xyz/player/index.php?data={url_hash}&do=getVideo'
        data = {"hash": url_hash, "r": link}
        page = request(getvid_link, headers=headers, post=data, output='json')
        url = page["securedLink"]
        if item := make_direct_item(hostDict, url, host=None, info=info, referer=link):
            sources.append(item)
        return sources
    except Exception as Err:
        log(f'hlspanel: Err: {Err}', 1)
        return sources


def superembed(link, hostDict, info=None):
    sources = []
    try:
        #return sources # Not done looking into or coding.
        r = request(link, headers={'User-Agent': UserAgent, 'Referer': link})
        i = parseDOM(r, 'iframe', ret='src')[0]
        p = re.findall(r'''window.atob\('(.+?)'\)''', i)[0]
        link = base64.b64decode(p)
        link = ensure_text(link, errors='ignore')
        url = link.replace('\/', '/').replace('///', '//')
        if item := make_direct_item(hostDict, url, host=None, info=info):
            sources.append(item)
        #else: log_utils.log('scrape_sources - superembed - non-item link: ' + str(url))
        return sources
    except Exception as Err:
        log(f'superembed: Err: {Err}', 1)
        return sources


def ronemo(link, hostDict, info=None):
    sources = []
    try:
        html = request(link, headers={'User-Agent': UserAgent, 'Referer': link})
        url = re.findall('"link":"(.+?)",', html)[0]
        if item := make_direct_item(hostDict, url, host=None, info=info, referer=link):
            sources.append(item)
        return sources
    except Exception as Err:
        log(f'ronemo: Err: {Err}', 1)
        return sources


def voxzer(link, hostDict, info=None):
    sources = []
    try:
        link = link.replace('/view/', '/list/')
        html = request(link, headers={'User-Agent': UserAgent, 'Referer': link}, output='json')
        url = html['link']
        if item := make_direct_item(hostDict, url, host=None, info=info, referer=link):
            sources.append(item)
        return sources
    except Exception as Err:
        log(f'voxzer: Err: {Err}', 1)
        return sources


def source_stream(link, hostDict, info=None):
    sources = []
    try:
        html = request(link, headers={'User-Agent': UserAgent, 'Referer': link})
        url = parseDOM(html, 'source', ret='src')[0]
        if item := make_direct_item(hostDict, url, host=None, info=info, referer=link):
            sources.append(item)
        return sources
    except Exception as Err:
        log(f'source_stream: Err: {Err}', 1)
        return sources


def get_recaptcha():
    response = requests.get(
        "https://recaptcha.harp.workers.dev/?anchor=https%3A%2F%2Fwww.google.com%2Frecaptcha%2Fapi2%2Fanchor%3Far%3D1%26k%3D6Lf2aYsgAAAAAFvU3-ybajmezOYy87U4fcEpWS4C%26co%3DaHR0cHM6Ly93d3cuMmVtYmVkLnRvOjQ0Mw..%26hl%3Den%26v%3DPRMRaAwB3KlylGQR57Dyk-pF%26size%3Dinvisible%26cb%3D7rsdercrealf&reload=https%3A%2F%2Fwww.google.com%2Frecaptcha%2Fapi2%2Freload%3Fk%3D6Lf2aYsgAAAAAFvU3-ybajmezOYy87U4fcEpWS4C"
    )
    return response.json()["rresp"]


def odnoklassniki(url):
    try:
        if '/safe.php?link=' in url:
            url = url.split('/safe.php?link=')[1]
        url = f'https:{url}' if url.startswith('//') else url
        #log_utils.log('scrape_sources - odnoklassniki - starting url: ' + str(url))
        media_id = re.compile('//.+?/.+?/([\w]+)').findall(url)[0]
        #log_utils.log('scrape_sources - odnoklassniki - media_id: ' + str(media_id))
        result = request('http://ok.ru/dk', post={'cmd': 'videoPlayerMetadata', 'mid': media_id})
        result = re.sub(r'[^\x00-\x7F]+', ' ', result)
        result = json.loads(result).get('videos', [])
        #log_utils.log('scrape_sources - odnoklassniki - result: ' + str(result))
        hd = []
        for name, quali in {'ultra': '4K', 'quad': '1440p', 'full': '1080p', 'hd': 'HD'}.items():
            hd += [{'quality': quali, 'url': i.get('url')} for i in result if i.get('name').lower() == name]
        #log_utils.log('scrape_sources - odnoklassniki - hd: ' + str(hd))
        sd = []
        for name, quali in {'sd': 'SD', 'low': 'SD', 'lowest': 'SD', 'mobile': 'SD'}.items():
            sd += [{'quality': quali, 'url': i.get('url')} for i in result if i.get('name').lower() == name]
        #log_utils.log('scrape_sources - odnoklassniki - sd: ' + str(sd))
        url = hd + sd[:1]
        #log_utils.log('scrape_sources - odnoklassniki - final url: ' + str(url))
        if url != []:
            return url
    except Exception as Err:
        log(f'odnoklassniki: Err: {Err}', 1)
        return url

################

def get_search_startpage(title, site_domain, year=None, search_site='startpage'):
    """
    :Usages: title, r = get_search_startpage('desirulez.cc', tvshowtitle)
    :param title: 'Mere Sai'
    :type title: str
    :param site_domain: 'desirulez.cc'
    :type site_domain: str
    :param year: 2023
    :type year: int
    :param search_site: 'startpage' default or use Google
    :type search_site: str
    :return: to compare title in url with other filter
    :rtype: tuple
    """
    if year: title = f'{title}+{year}'
    title = title.lower().replace(' ', '-').replace('.', '-').replace("’", '%92')
    if 'startpage' in search_site: search_url = f'https://www.startpage.com/do/search?q={title}+sites:{site_domain}'
    else: search_url = f'https://www.google.com/search?hl=en&as_q={title}&as_epq=&as_oq=&as_eq=&as_nlo=&as_nhi=&lr=&cr=&as_qdr=all&as_sitesearch={site_domain}&as_occt=&safe=images&as_filetype=&as_rights=not+filtered+by+license&tbs='

    log(f'title: {title} search_url: {search_url}')
    result = request(search_url, headers=dnt_headers)
    if 'startpage' in search_url: r = parseDOM(result, 'div', attrs={'class': 'w-gl__result-second-line-container'})
    else: r = parseDOM(result, 'div', attrs={'id': 'search'})
    if 'startpage' in search_url: urls = parseDOM(r, 'a', ret='href')
    # log(f'title: {title} urls: {urls}')
    return title, urls


def movcloud(link, hostDict):
    sources = []
    try:
        url = link.replace('https://movcloud.net/embed/', 'https://api.movcloud.net/stream/')
        url = request(url, headers={'User-Agent': agent(), 'Referer': 'https://movcloud.net'})
        resp = ensure_str(url, errors='replace')
        url = json.loads(resp)
        url = url['data']
        url = url['sources']
        for url in url:
            label = url['label']
            url = url['file']
            quality, info = get_release_quality(label, label)
            if url.startswith('http'):
                sources.append({'source': 'movcloud', 'quality': quality, 'info': info, 'url': url, 'direct': False})
        return sources
    except Exception as Err:
        error(f'movcloud: {link} Err: {Err}')
        return []


def vidcloud9(link, hostDict):
    sources = []
    try:
        # print("link:%s" % link)
        if not link.endswith('.m3u8'):
            url = request(link, headers={'User-Agent': agent(), 'Referer': link})
            resp = ensure_str(url, errors='replace')
            # print("resp:%s" % resp)
            url = re.compile('data-video="(.+?)">.+?</li>').findall(resp)
            for url in url:
                if url.startswith('//'):
                    url = f'https:{url}'
                if 'vidnext.net' in url:
                    if '&typesub' in url:
                        url = request(link, headers={'User-Agent': agent(), 'Referer': link})
                        resp = ensure_str(url, errors='ignore')
                        url = re.findall("file: '(.+?)'", resp)[0]
                        if url.startswith('http'):
                            sources.append(
                                {'source': 'hls', 'quality': 'SD', 'url': url, 'direct': False})
                    else:
                        iurl = request(url, headers={'User-Agent': agent(), 'Referer': link})
                        resp = ensure_str(iurl, errors='ignore')
                        urls = re.findall('data-video="(.+?)">', resp)
                        for url in urls:
                            if url.startswith('//'):
                                url = f'https:{url}'
                            if 'vidnext.net' in url:
                                url = request(url, headers={'User-Agent': agent(), 'Referer': url})
                                resp = ensure_str(url, errors='ignore')
                                r = re.findall('(ep.+?.m3u8)', resp)
                                for r in r:
                                    url = url.split('ep')[0]
                                    url = url + r
                                    quality = '720p' if '.720.m3u8' in url else 'SD'
                                    if url.startswith('http'):
                                        sources.append(
                                            {'source': 'hls3x', 'quality': quality, 'info': '', 'url': url, 'direct': False})
                            else:
                                valid, host = is_host_valid(url, hostDict)
                                if valid:
                                    quality, info = get_release_quality(url, url)
                                    if url.startswith('http'):
                                        sources.append(
                                            {'source': host, 'quality': quality, 'info': info, 'url': url, 'direct': False})

                elif 'movcloud' in url:
                    url = url.replace('https://movcloud.net/embed/', 'https://api.movcloud.net/stream/')
                    url = request(url, headers={'User-Agent': agent(), 'Referer': 'https://movcloud.net'})
                    url = json.loads(url)
                    url = url['data']
                    url = url['sources']
                    for url in url:
                        label = url['label']
                        url = url['file']
                        quality, info = get_release_quality(label, label)
                        if url.startswith('http'):
                            sources.append(
                                {'source': 'movcloud', 'quality': quality, 'info': info, 'url': url, 'direct': False})
                else:
                    valid, host = is_host_valid(url, hostDict)
                    if valid:
                        quality, info = get_release_quality(url, url)
                        if url.startswith('http'):
                            sources.append(
                                {'source': host, 'quality': quality, 'info': info, 'url': url, 'direct': False})
        # else:
        #     valid, host = is_host_valid(link, hostDict)
        #     sources.append({'source': host, 'quality': '720p', 'url': link, 'direct': True})
        return sources
    except Exception as Err:
        error(f'vidcloud9: {link} Err: {Err}')
        return []


def vidcloud_pro(link, hostDict):
    sources = []
    try:
        url = request(link, headers={'User-Agent': agent(), 'Referer': link})
        resp = ensure_str(url, errors='ignore')
        url = re.findall(r'sources = \[{"file":"(.+?)","type"', resp)[0]
        url = url.replace('\\', '')
        valid, host = is_host_valid(link, hostDict)
        if valid:
            quality, info = get_release_quality(url, url)
            if url.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': url, 'direct': False})
        return sources
    except Exception as Err:
        error(f'vidcloud_pro: {link} Err: {Err}')
        return []


def vidsrc_me(link, hostDict):
    sources = []
    try:
        r = request(link, headers={'User-Agent': agent(), 'Referer': 'https://v2.vidsrc.me'})
        resp = ensure_str(r, errors='ignore')
        r = re.findall('data-hash="(.+?)"', resp)[0]
        r = f'https://v2.vidsrc.me/src/{r}'
        url = request(r, headers={'User-Agent': agent(), 'Referer': 'https://v2.vidsrc.me'})
        resp = ensure_str(url, errors='ignore')
        url = re.findall("'player' src='(.+?)'", resp)[0]
        url = f'{url}|Referer=https://vidsrc.me'
        quality, info = get_release_quality(url, url)
        if url.startswith('http'):
            sources.append(
                {'source': 'cdn', 'quality': quality, 'info': info, 'url': url, 'direct': True})
        return sources
    except Exception as Err:
        error(f'vidsrc_me: {link} Err: {Err}')
        return []


def vidnext_net(link, hostDict):
    sources = []
    try:
        if 'vidnext.net' in link:
            if '&typesub' in link:
                url = request(link, headers={'User-Agent': agent(), 'Referer': link})
                resp = ensure_str(url, errors='ignore')
                url = re.findall("file: '(.+?)'", resp)[0]
                if url.startswith('http'):
                    sources.append({'source': 'hls', 'quality': 'SD', 'url': url, 'direct': False})
            else:
                url = request(link, headers={'User-Agent': agent(), 'Referer': link})
                resp = ensure_str(url, errors='ignore')
                url = re.findall('data-video="(.+?)">', resp)
                for url in url:
                    if url.startswith('//'):
                        url = f'https:{url}'
                    if 'vidnext.net' in url:
                        url = request(url, headers={'User-Agent': agent(), 'Referer': url})
                        resp = ensure_str(url, errors='ignore')
                        r = re.findall('(ep.+?.m3u8)', resp)
                        for r in r:
                            url = url.split('ep')[0]
                            url = url + r
                            quality = '720p' if '.720.m3u8' in url else 'SD'
                            if url.startswith('http'):
                                sources.append(
                                    {'source': 'hls3x', 'quality': quality, 'info': '', 'url': url, 'direct': False})

        else:
            valid, host = is_host_valid(link, hostDict)
            if valid:
                quality, info = get_release_quality(link, link)
                if link.startswith('http'):
                    sources.append(
                        {'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False})

        return sources
    except Exception as Err:
        error(f'vidnext_net: {link} Err: {Err}')
        return []


def hls3x(link, hostDict):
    sources = []
    try:
        url = request(link, headers={'User-Agent': agent(), 'Referer': link})
        resp = ensure_str(url, errors='ignore')
        r = re.findall('(ep.+?.m3u8)', resp)
        for r in r:
            url = url.split('ep')[0]
            url = url + r
            quality = '720p' if '.720.m3u8' in url else 'SD'
            info = get_release_quality(url)
            if url.startswith('http'):
                sources.append(
                    {'source': 'hlx3x', 'quality': quality, 'info': info, 'url': url, 'direct': False})
        return sources
    except Exception as Err:
        error(f'hls3x: {link} Err: {Err}')
        return []


def vidoo(link, hostDict):
    sources = []
    try:
        url = request(link, headers={'User-Agent': agent(), 'Referer': link})
        resp = ensure_str(url, errors='ignore')
        r = re.findall(r'file:"(.+?)"\},\{file:".+?",label:"(.+?)"', resp)
        for r in r:
            quality, info = get_release_quality(r[1], r[0])
            r = request(r[0], headers={'User-Agent': agent(), 'Referer': link})
            resp = ensure_str(r, errors='ignore')
            r = re.findall('(https://.+?m3u8)', resp)[0]
            if r.startswith('http'):
                sources.append(
                    {'source': 'vidoo', 'quality': quality, 'info': info, 'url': r, 'direct': False})
        return sources
    except Exception as Err:
        error(f'vidoo: {link} Err: {Err}')
        return []


def mediashore(link, hostDict):
    sources = []
    try:
        try:
            url = request(link, headers={'User-Agent': agent(), 'Referer': link})
            resp = ensure_str(url, errors='ignore')
            r = re.findall('<title>(.+?)</title>', resp)[0]
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(r, r)
            if r.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': r, 'direct': False})
        except:
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(link, link)
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False})
        return sources
    except Exception as Err:
        error(f'mediashore: {link} Err: {Err}')
        return []


def abcvideo(link, hostDict):
    sources = []
    try:
        try:
            if 'html' in link:
                url = request(link, headers={'User-Agent': agent(), 'Referer': link})
                resp = ensure_str(url, errors='ignore')
                r = re.findall('jwplayer.qualityLabel\', \'(.+?)\'', resp)[0]
            else:
                url = request(link, headers={'User-Agent': agent(), 'Referer': link})
                resp = ensure_str(url, errors='ignore')
                r = re.findall('<title>(.+?)</title>', resp)[0]
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(r, r)
            if r.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': r, 'direct': False})
        except:
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(link, link)
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False})
        return sources
    except Exception as Err:
        error(f'abcvideo: {link} Err: {Err}')
        return []


def cloudvideo(link, hostDict):
    sources = []
    try:
        try:
            url = request(link, headers={'User-Agent': agent(), 'Referer': link})
            resp = ensure_str(url, errors='ignore')
            r = re.findall('<title>(.+?)</title>', resp)[0]
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(r, r)
            if r.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': r, 'direct': False})
        except:
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(link, link)
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False})
        return sources
    except Exception as Err:
        error(f'cloudvideo: {link} Err: {Err}')
        return []


def mixdrop(link, hostDict):
    sources = []
    try:
        try:
            if '?' in link: link = link.split('?')[0]
            try: url = request(link, headers={'User-Agent': agent(), 'Referer': link})
            except: url = request(link, verifySsl=False, headers={'User-Agent': agent(), 'Referer': link})
            resp = ensure_str(url, errors='ignore')
            r = re.findall('target="_blank">(.+?)</a>', resp)[0]
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(r, r)
            if r.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': r, 'direct': False})
        except:
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(link, link)
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False})
        return sources
    except Exception as Err:
        error(f'mixdrop: {link} Err: {Err}')
        return []


def upstream(link, hostDict):
    sources = []
    try:
        try:
            url = request(link, headers={'User-Agent': agent(), 'Referer': link})
            resp = ensure_str(url, errors='ignore')
            r = re.findall('</i>(.+?)</span>', resp)[0]
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(r, r)
            if r.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': r, 'direct': False})
        except:
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(link, link)
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False})
        return sources
    except Exception as Err:
        error(f'upstream: {link} Err: {Err}')
        return []


def vidoza(link, hostDict):
    sources = []
    try:
        try:
            url = request(link, headers={'User-Agent': agent(), 'Referer': link})
            resp = ensure_str(url, errors='ignore')
            r = re.findall('CONTENT="(.+?)">', resp)[0]
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(r, r)
            if r.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': r, 'direct': False})
        except:
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(link, link)
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False})
        return sources
    except Exception as Err:
        error(f'vidoza: {link} Err: {Err}')
        return []


def fmovies_to(link, hostDict):
    sources = []
    try:
        r = request(link)
        # links = re.findall(r'''(?:src|file)[:=]\s*['"]([^"']+)''', r)
        # links = parseDOM(r, 'ul', ret='data-video')
        # links = parseDOM(r, 'ul', attrs={'class': r'list-server-items.*?'})
        links = parseDOM(r, 'iframe', ret='src')
        # log("fmovies_to links: {}".format(links))
        sources.extend(
            {
                'source': 'fmovies',
                'quality': '720p',
                'url': url,
                'direct': True,
            }
            for url in links
        )
        return sources
    except Exception as Err:
        error(f'fmovies_to: {link} Err: {Err}')
        return []


def gamovideo(link, hostDict):
    sources = []
    try:
        try:
            # url = request(link, headers={'User-Agent': agent(), 'Referer': link})
            url = request(link, headers={'User-Agent': agent(), 'Referer': link})
            # url = read_write_file(file_n='gomostream.com.html')
            r = re.findall('<Title>(.+?)</Title>', url)
            # print(f'r: {r}')
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(r[0], r[0])
            if r[0].startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': r, 'direct': False})
        except:
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(link, link)
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False})
        return sources
    except Exception as Err:
        error(f'gamovideo: {link} Err: {Err}')
        return []


def sgoogle(link, hostDict):
    sources = []
    try:
        if link.startswith('http'):
            sources.append({'source': 'gvideo', 'quality': 'SD', 'info': '', 'url': link, 'direct': True})
        return sources
    except:
        return []


def more_rapidvideo(link, hostDict, lang, info):
    if "rapidvideo.com" not in link:
        return []
    sources = []
    try:
        headers = {
            'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3555.0 Safari/537.36"}
        response = request(link, headers=headers)
        test = re.findall(r"""(https:\/\/www.rapidvideo.com\/e\/.*)">""", response)
        numGroups = len(test)
        for i in range(1, numGroups):
            url = test[i]
            valid, host = is_host_valid(url, hostDict)
            q = check_url(url)
            sources.append({'source': host, 'quality': q, 'url': url, 'info': info, 'direct': False})
        return sources
    except:
        return sources


def more_cdapl(link, hostDict, lang, info):
    if "cda.pl" not in link:
        return []
    sources = []
    try:
        headers = {
            'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3555.0 Safari/537.36"}
        response = request(link, headers=headers)
        test = parseDOM(response, 'div', attrs={'class': 'wrapqualitybtn'})
        if urls := parseDOM(test, 'a', ret='href'):
            for url in urls:
                valid, host = is_host_valid(url, hostDict)
                q = check_url(url)
                direct = re.findall("""file":"(.*)","file_cast""", request(url, headers=headers))[
                    0].replace("\\/", "/")
                sources.append({'source': 'cda', 'quality': q, 'url': direct, 'info': info, 'direct': True})
        return sources
    except:
        return sources


def more_vidnode(link, hostDict):
    sources = []  # By Shellc0de
    try:
        headers = {'Host': 'vidnode.net', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 'Upgrade-Insecure-Requests': '1', 'Accept-Language': 'en-US,en;q=0.9'}
        response = request(link, headers=headers, timeout=5)
        if urls := re.findall(
            r'''\{file:\s*['"]([^'"]+).*?label:\s*['"](\d+\s*P)['"]''',
            response,
            re.DOTALL | re.I,
        ):
            for url, qual in urls:
                quality, info = get_release_quality(qual, url)
                host = url.split('//')[1].replace('www.', '')
                host = host.split('/')[0].lower()  # 'CDN'
                sources.append({'source': host, 'quality': quality, 'url': url, 'info': info, 'direct': True})
        return sources
    except:
        return sources
