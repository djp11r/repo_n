# -*- coding: UTF-8 -*-

import re

from openscrapers.modules.hindi_sources import get_source_dict, resolve_gen, get_query
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.client import agent, request, parseDOM


class source:

    def __init__(self):
        self.name = "gomovies"
        self.domains = ['0gomovies.si']
        self.base_link = 'https://ww0.0gomovies.it'
        self.search_link = f'{self.base_link}/search-query/'
        self.headers = {'User-Agent': agent(), }

    def movie(self, imdb, title, localtitle, aliases, year):
        # log(f'From: {__name__}\nimdb: {imdb}\ntitle: {title}\nlocaltitle: {localtitle}\naliases: {aliases}\nyear: {year}')
        try:
            # log(f'title: {repr(title)} year: {repr(year)}')
            scrape = title.lower().replace(' ', '-')
            iurl = f'{self.search_link}{scrape}'
            # log(f'iurl: {repr(iurl)}')
            result = request(iurl, headers=self.headers, verify=False)
            # log(f'result: {result}')
            if not result: return
            result = parseDOM(result, 'div', attrs={'class': 'movies-list movies-list-full'})
            # log(f'total: {len(result)}')
            for item in result:
                if re.search(scrape, item, re.I):
                    # log(f'item: {item}')
                    if url := parseDOM(item, 'a', ret="href")[0]:
                        return f'{url}watching/'
            return
        except:
            error(f'{__name__}_ movie: ')
            return

    def sources(self, url, hostDict):
        log(f'From: {__name__} url {url}')
        sources = []
        try:
            if not url: return sources
            result = request(url, headers=self.headers, verify=False)
            if not result: return sources
            items = parseDOM(result, 'ul', attrs={'class': 'dropdown-menu'})
            # log(f'1total: {len(items)} items: {repr(items)}')
            result = parseDOM(items, 'li', ret="data-drive")
            result += parseDOM(items, 'li', ret="data-openload")
            # result = parseDOM(items, 'a', attrs={'target': '_blank'}, ret="href")
            # log(f'total: {len(result)} result: {repr(result)}')
            for item in result:
                if not item.startswith('https://t.me'):
                    # log(f'item: {item}')
                    html1 = request(item, verify=False)
                    # log(f'html1: {html1}')
                    videoclass1 = parseDOM(html1, 'div', attrs={'class': 'content-pt'})
                    # log(f'total: {len(videoclass1)} videoclass1: {repr(videoclass1)}')
                    vtabs1 = parseDOM(videoclass1, 'a', ret="href")
                    # log(f'total: {len(vtabs1)} vtabs1: {repr(vtabs1)}')
                    videourls = []
                    for vtab1 in vtabs1:
                        # log(f'vtab1: {vtab1}')
                        videourl = vtab1.split('?link=')[-1]
                        # log(f'videourl: {videourl}')
                        videourls.append(videourl)
                        # title = re.sub(r'PLAYER\s*\d', '', vtab1.text).strip()
                        sources = get_source_dict([str(videourl)], sources)
            return sources
        except:
            error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return resolve_gen(url)
