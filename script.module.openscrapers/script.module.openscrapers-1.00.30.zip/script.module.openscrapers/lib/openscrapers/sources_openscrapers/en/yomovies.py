# -*- coding: utf-8 -*-

import re

from openscrapers import parse_qs, urlencode

from openscrapers.modules import client
from openscrapers.modules import cleantitle
from openscrapers.modules import log_utils
from openscrapers.modules import scrape_sources


class source:
    def __init__(self):
        try:
            self.results = []
            self.domains = ['yomovies.fyi', 'yomovies.rs', 'yomovies.cloud', 'yomovies.skin',
                'yomovies.vip', 'yomovies.ws', 'yomovies.bz', 'yomovies.lol'
            ]
            self.base_link = 'https://yomovies.fyi'
            self.search_link = '/?s=%s'
        except Exception:
            #log_utils.log('__init__', 1)
            return


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            #log_utils.log('movie', 1)
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            #log_utils.log('tvshow', 1)
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            #log_utils.log('episode', 1)
            return


    def sources(self, url, hostDict):
        try:
            if url == None:
                return self.results
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            season, episode = (data['season'], data['episode']) if 'tvshowtitle' in data else ('0', '0')
            year = data['year']
            check_term = '%s Season %s' % (title, season) if 'tvshowtitle' in data else '%s (%s)' % (title, year)
            search_title = cleantitle.get_plus(check_term) if 'tvshowtitle' in data else cleantitle.get_plus(title)
            check_title = cleantitle.get(check_term)
            search_url = self.base_link + self.search_link % search_title
            r = client.scrapePage(search_url).text
            r = client.parseDOM(r, 'div', attrs={'class': 'ml-item'})
            r = [(client.parseDOM(i, 'a', ret='href'), client.parseDOM(i, 'a', ret='oldtitle'), re.findall('/release-year/(\d{4})/"', i)) for i in r]
            r = [(i[0][0], i[1][0], i[2][0]) for i in r if len(i[0]) > 0 and len(i[1]) > 0 and len(i[2]) > 0]
            url = [i[0] for i in r if check_title == cleantitle.get(i[1]) and year == i[2]][0]
            if 'tvshowtitle' in data:
                url = url[:-1]
                url = url.replace('/series/', '/episode/')
                url = url + '-episode-%s/' % episode
            r = client.scrapePage(url).text
            links = client.parseDOM(r, 'iframe', ret='src')
            for link in links:
                if 'youtube.com' in link:
                    continue
                for source in scrape_sources.process(hostDict, link):
                    self.results.append(source)
            return self.results
        except:
            #log_utils.log('sources', 1)
            return self.results


    def resolve(self, url):
        return url


