# -*- coding: utf-8 -*-

import re

from openscrapers import urlencode, parse_qs, quote_plus, urljoin
from openscrapers.modules import client
from openscrapers.modules import cleantitle
from openscrapers.modules import log_utils
from openscrapers.modules import cfscrape
from openscrapers.modules import scrape_sources

class source:
    def __init__(self):
        self.priority = 40
        self.results = []
        self.language = ['en']
        self.domains = ['fmovies.vision', 'gostream.cool']
        self.base_link = 'https://fmovies.vision'
        self.search_link = '/index.php?do=search&filter=true'
        self.headers = {'User-Agent': client.agent()}

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            movie_title = cleantitle.get_plus(title)
            check_title = cleantitle.get(title)
            search_url = self.base_link + self.search_link
            post = ('do=search&subaction=search&search_start=0&full_search=0&result_from=1&story=%s' % movie_title)
            html = client.request(search_url, post=post).replace('\n', '')
            r = client.parseDOM(html, 'div', attrs={'class': 'item'})
            # print(f'1r: {r}')
            r = [(client.parseDOM(i, 'a', attrs={'class': 'poster'}, ret='href'), client.parseDOM(i, 'img', ret='alt'), re.findall('<div class="meta">(\d{4}) <i class="dot">', i)) for i in r]
            # print(f'2r: {r}')
            r = [(i[0][0], i[1][0], i[2][0]) for i in r if len(i[0]) > 0 and len(i[1]) > 0 and len(i[2]) > 0]
            # print(f'3r: {r}')
            url = [i[0] for i in r if check_title == cleantitle.get(i[1]) and year == i[2]][0]
            return url
        except Exception:
            log_utils.error(f'{__name__}_ movie: ')
            return


    def sources(self, url, hostDict):
        try:
            if url is None:
                return self.results
            html = client.request(url)
            try:
                links = client.parseDOM(html, 'div', ret='data-link')
                for link in links:
                    for source in scrape_sources.process(hostDict, link):
                        self.results.append(source)
            except:
                log_utils.error(f'{__name__}_ sources: ')
                pass
            try:
                result = re.compile('<script src="https://simplemovie.xyz/(.+?)" type').findall(html)[0]
                result_url = 'https://simplemovie.xyz/' + result
                result_html = client.request(result_url).replace("\\", "")
                links = re.compile('''<tr onclick="window\.open\( \\'(.+?)\\' \)">''').findall(result_html)
                for link in links:
                    for source in scrape_sources.process(hostDict, link):
                        self.results.append(source)
            except:
                log_utils.error(f'{__name__}_ sources: ')
                pass
            return self.results
        except Exception:
            log_utils.error(f'{__name__}_ sources: ')
            return []

    def fmovies_to(self, link, hostDict):
        sources = []
        try:
            # r = client.r_request(link).text
            r = self.cfscraper.get(link, headers=self.headers).text
            # print(f'resp: {r}')
            # links = re.findall(r'''(?:src|file)[:=]\s*['"]([^"']+)''', r)
            # links = client.parseDOM(r, 'ul', ret='data-video')
            # links = client.parseDOM(r, 'ul', attrs={'class': r'list-server-items.*?'})
            links = client.parseDOM(r, 'iframe', ret='src')
            # log_utils.log("fmovies_to links: {}".format(links))
            for url in links:
                # url = "%s|%s" % (url, source_utils.append_headers(self.headers))
                sources.append({'source': 'fmovies', 'quality': '720p', 'language': 'en', 'info': '', 'url': url, 'direct': True, 'debridonly': False})
            return sources
        except:
            log_utils.error(f'{__name__}_ fmovies_to: {link}')
            return []

    def resolve(self, url):
        try:
            url = client.request(url)
            url = re.findall(r'sources: \[\{file:"*(.+?)"\}\]', url)[0]
            url = url.replace('https://', 'http://')
            return url
        except:
            return url
