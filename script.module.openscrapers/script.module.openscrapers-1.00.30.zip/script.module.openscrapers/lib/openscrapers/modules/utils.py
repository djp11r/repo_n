# -*- coding: utf-8 -*-
"""
	OpenScrapers Module

"""
import hashlib
from json import loads as jsloads
import re
from importlib import import_module
from openscrapers.modules import py_tools


def json_load_as_str(file_handle):
	return byteify(jsloads(file_handle, object_hook=byteify), ignore_dicts=True)


def json_loads_as_str(json_text):
	return byteify(jsloads(json_text, object_hook=byteify), ignore_dicts=True)


def byteify(data, ignore_dicts=False):
	if isinstance(data, str): return data
	if isinstance(data, list): return [byteify(item, ignore_dicts=True) for item in data]
	if isinstance(data, dict) and not ignore_dicts: return dict([(byteify(key, ignore_dicts=True), byteify(value, ignore_dicts=True)) for key, value in iter(data.items())])
	if str(type(data)) == "<type 'unicode'>": return data.encode('utf-8')
	return data


def title_key(title):
	try:
		if not title: title = ''
		articles_en = ['the', 'a', 'an']
		articles_de = ['der', 'die', 'das']
		articles = articles_en + articles_de
		match = re.match(r'^((\w+)\s+)', title.lower())
		if match and match.group(2) in articles: offset = len(match.group(1))
		else: offset = 0
		return title[offset:]
	except:
		return title


def chunks(l, n):
	"""
	Yield successive n-sized chunks from l.
	"""
	for i in range(0, len(l), n):
		yield l[i:i + n]


def traverse(o, tree_types=(list, tuple)):
	"""
	Yield values from irregularly nested lists/tuples.
	"""
	if isinstance(o, tree_types):
		for value in o:
			for subvalue in traverse(value, tree_types):
				yield subvalue
	else: yield o


try: from resources.lib.modules import database
except:
	database_dict = {}
	def alt_get_or_add(fn, *args, **kwargs):
		key = _hash_function(fn, *args)
		if database_dict.get(key, None): return database_dict[key]
		return database_dict.setdefault(key, fn(*args, **kwargs))

	database = lambda: None
	database.get = lambda fn, duration, *args, **kwargs: alt_get_or_add(fn, *args, **kwargs)
	database.cache_get = lambda key: {}
	database.cache_insert = lambda key, value: {}


def _generate_md5(*args):
	md5_hash = hashlib.md5()
	try: [md5_hash.update(str(arg)) for arg in args]
	except: [md5_hash.update(str(arg).encode('utf-8')) for arg in args]
	return str(md5_hash.hexdigest())


def _get_function_name(function_instance):
	return re.sub(r'.+?\s*method\s*|.+function\s*|\sat\s*?.+|\s*?of\s*?.+', '', repr(function_instance))


def _hash_function(function_instance, *args):
	return _get_function_name(function_instance) + _generate_md5(args)


def cache_save(key, data):
	return database.cache_insert(key, data)


def cache_get(key):
	return database.cache_get(key)


def manual_function_import(location, function_name):
	return getattr(import_module(location), function_name)


def manual_module_import(location):
	return import_module(location)


def get_headersfrom_url(url):
	headers = {}
	# print(f'>>>> from _base vid_link: {url}')
	if '|' in url:
		url, hdrs = url.split('|')
		hitems = hdrs.split('&')
		for hitem in hitems:
			hdr, value = hitem.split('=')
			headers.update({hdr: value})
	return url, headers