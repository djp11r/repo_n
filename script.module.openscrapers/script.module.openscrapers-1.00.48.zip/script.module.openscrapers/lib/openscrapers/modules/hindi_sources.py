# -*- coding: utf-8 -*-
import datetime
import json
import random
import re
from traceback import print_exc

from openscrapers import quote_plus, urlencode, urljoin, urlparse, testing
from openscrapers.modules.client import agent, refresh_redirect, request
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.log_utils import error, log

bytes = bytes
str = unicode = basestring = str


def get_query(title):
    query = f'{title}'.replace("’", '').replace(' ', '-').lower()
    # log(f'query {query} title: {title}')
    if 'india-got-talent' in query: return 'india-got-talent-season-10'
    elif 'crime-patrol' in query: return 'crime-patrol-48-hours'
    elif 'indias-best-dancer' in query: return 'indias-best-dancer-season-3'
    elif 'kaun-banega-crorepati' in query: return 'kaun-banega-crorepati-season-15'
    elif 'bigg-boss-ott' in query: return 'bigg-boss-ott-2'
    elif 'bigg-boss' in query: return 'bigg-boss-17'
    elif 'indian-idol' in query: return 'indian-idol-14'
    elif 'the-kapil-sharma-show' in query: return 'the-kapil-sharma-show-season-4'
    elif 'masterchef-india' in query: return 'masterchef-india-season-7'
    return query


def query_cleaner(query):
    query = query.lower().replace(' ', '-').replace('.', '-').replace('---', '-').replace("'", '').replace('’', '').replace(':', '')
    return query


def getVideoID(url):
    try: return re.compile('(id|url|v|si|sin|sim|data-config|file|dm|wat|vid)=(.+?)##').findall(f'{url}##')[0][1]
    except: return


def get_mod_url(url):
    url_id = getVideoID(url)
    if not url_id: return
    if 'vkprime.php' in url: return f'http://vkprime.com/embed-{url_id}.html'
    elif 'vkspeed.php' in url: return f'http://vkspeed.com/embed-{url_id}.html'
    elif 'speed.php' in url: return f'http://vkspeed.com/embed-{url_id}-600x380.html'
    # elif 'viralnews.site/tech/xstrm.php' in url: return f'https://techautomate.in/news.php?cid={url_id}&type=xstrm'
    # elif 'viralnews.site/tech/vp.php' in url: return f'https://techautomate.in/technology.php?id={url_id}'
    # elif 'viralnews.site/tech/vk.php' in url: return f'https://techautomate.in/media.php?id={url_id}'
    # elif 'tere-sheher-mein' in url: return f'https://flow.business-loans.pw/plyr2/{url_id}'
    # elif 'ishqbaaz' in url: return f'http://flow.bestarticles.me/embed2//{url_id}'
    return url


def byte_to_str(bytes_or_str):
    # Check if it's in bytes
    if isinstance(bytes_or_str, bytes): bytes_or_str = bytes_or_str.decode('utf-8')
    # else: log('Object not of byte type')
    return bytes_or_str


def host(url):
    try: url = byte_to_str(url)
    except: pass
    host = re.findall(r'([\w]+[.][\w]+)$', urlparse(url.strip().lower()).netloc)[0]
    return str(host.split('.')[0])


def to_utf8(obj):
    try:
        if isinstance(obj, unicode): obj = obj.encode('utf-8', 'ignore')
        elif isinstance(obj, dict):
            import copy
            obj = copy.deepcopy(obj)
            for key, val in obj.items():
                obj[key] = to_utf8(val)
        elif obj is not None and hasattr(obj, '__iter__'): obj = obj.__class__([to_utf8(x) for x in obj])
    except: pass
    return obj


def stringify_nodes(data):
    if isinstance(data, list): return [stringify_nodes(x) for x in data]
    elif isinstance(data, dict):
        dkeys = list(data.keys())
        for i, k in enumerate(dkeys):
            try: dkeys[i] = k.decode()
            except: pass
        data = dict(zip(dkeys, list(data.values())))
        return {stringify_nodes(key): stringify_nodes(val) for key, val in data.items()}
    elif isinstance(data, bytes):
        try: return data.decode()
        except: return data
    else: return data


def clean_title(title):
    items = 'watch|online|movie|onilne|tamil|dubbed|free|full|length|latest|telugu|rip|dvdrip|dvdscr|uncensored|hd|downlaod|bluray|malayalam|movies|wach|songs|hindi|korean|hilarious|comedy|scenes|super|ultimate|bdrip|todaypk|sun|tv|show|vijay|film|download|starring|horror|hdrip|audio|pdvdrip|hq|brrip|pre hdrip|predvdrip|webrip|punjabi|tcrip|hdtvrip|hd|tc|hdtv|tvrip|720p|dvd|uncut|clear|dthrip|line|kannada|hollywood|ts|cam|streaming|permalink|english|bengali|bhojpuri|print|amzn|scr|web|gujarati|webdl|esubs'
    title = re.sub(r'([:;\-"\',!_.?~$@])', '', title)
    title = re.sub(items, ' ', title, flags=re.I)
    title = re.sub(r'\s+', ' ', title, flags=re.I)
    title = title.strip()
    return title.title()


def keepclean_title(title):
    if title is None: return
    exctract_date = re.compile(r'(\d{1,2}[th|st|nd|rd]* [Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|August|Sep|September|Oct|October|Nov|November|Dec|December]* \d{2,4})')
    episode_data = re.compile(r'[Ee]pisodes.+?(\d+)|[Ee]p (\d+)|[Ee](\d+)|[sS]eason.+?(\d+)|[sS]eason(\d+)|[sS](\d+)')
    # ansi_pattern = re.compile(r'(\x9B|\x1B\[)[0-?]*[ -\/]*[@-~]')
    ansi_pattern = re.compile(r'[^\x00-\x7f]')
    try:
        if cl_title := re.search("(?=.*\d).0", title): title = title.replace('.0', '')
        if ':' in title: title = title.replace(':', ' ')
        title = re.sub(exctract_date, '', title)  # remove date like 18th April 2021
        title = re.sub(episode_data, '', title)  # remove episod 12 or season 1 etc
        title = re.sub(ansi_pattern, '', title)  # remove ansi_pattern
        title = re.sub(r'&#(\d+);', '', title)
        title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
        title = title.replace('&quot;', '\"').replace('&amp;', '&').replace('&Amp;', '&')
        title = re.sub(r'([:;\-"\',!_.?~$@])', '', title)  # remove all characters in bracket
        title = re.sub(r'\<[^>]*\>|\([^>]*\)', '', title) # remove like this <anything> or (any thing)
        # title = re.sub(r'\([^>]*\)', '', title)  # remove in bracket like (anything) etc
        # title = re.sub(r'\n|([[].+?[]])|([(].+?[)])|\s(vs|v[.])\s|(:|;|-|"|,|\'|\_|\.|\?)|\(|\)|\[|\]|\{|\}|\s', '', title).lower()
        # title = re.sub(r'\n|([\[({].+?[})\]])|([:;\-"\',!_.?~$@])|\s', '', title)
        title = re.sub(r'\s+', ' ', title, flags=re.I)
        return title.strip()
    except: return title


def replace_html_codes(txt):
    from html import unescape
    txt = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', txt)
    txt = re.sub(r'[^\x00-\x7f]', r'', txt)  # remove all non-ASCII characters
    txt = unescape(txt)
    txt = txt.replace('&quot;', '\"')
    txt = txt.replace('&amp;', '&').replace('&Amp;', '&')
    txt = txt.replace('&lt;', '<').replace('&gt;', '>').replace('&#38;', '&').replace('&nbsp;', '').replace('&#8211;', '-').replace('&#8217;', '\'').replace('&#8230;', ' ')
    return txt


non_str_list = ['olangal.', 'desihome.', 'thiruttuvcd', '.filmlinks4u', '#', '/t.me/',
                'cineview', 'bollyheaven', 'videolinkz', 'moviefk.co', 'goo.gl', '/ads/',
                'imdb.', 'mgid.', 'atemda.', 'movierulz.ht', 'facebook.', 'twitter.',
                'm2pub', 'abcmalayalam', 'india4movie.co', 'embedupload.', 'bit.ly',
                'tamilraja.', 'multiup.', 'filesupload.', 'fileorbs.', 'tamil.ws',
                'insurance-donate.', '.blogspot.', 'yodesi.net', 'desi-tashan.',
                'yomasti.co/ads', 'ads.yodesi', 'mylifeads.', 'yaartv.', '/cdn-cgi/',
                'steepto.', '/movierulztv', '/email-protection', 'oneload.xyz', 'about:',
                'tvnation.me/drive.php?', 'p2p.drivewires', 'tvcine.me', '/ad',
                'tvnation.me/include', 'drivewire.xyz',
                'magnet:', 'google.com', 'whatsapp.com', 'linkedin.com']

remove_ads_js_urls = ['.js', 'adv1/', 'ads.', '.ads', '/ad', '/ads/']

embed_list = ['cineview', 'bollyheaven', 'videolinkz', 'vidzcode', 'escr.',
              'embedzone', 'embedsr', 'fullmovie-hd', 'links4.pw', 'esr.',
              'embedscr', 'embedrip', 'movembed', 'power4link.us', 'adly.biz',
              'watchmoviesonline4u', 'nobuffer.info', 'yomasti.co', 'hd-rulez.',
              'techking.me', 'onlinemoviesworld.xyz', 'cinebix.com', 'vids.xyz',
              'desihome.', 'loan-', 'filmshowonline.', 'hinditwostop.', 'media.php',
              'hindistoponline', 'telly-news.', 'tellytimes.', 'tellynews.', 'tvcine.',
              'business-', 'businessvoip.', 'toptencar.', 'serialinsurance.',
              'youpdates', 'loanadvisor.', 'tamilray.', 'embedrip.', 'xpressvids.',
              'beststopapne.', 'bestinforoom.', '?trembed=', 'tamilserene.',
              'tvnation.', 'techking.', 'etcscrs.', 'etcsr1.', 'etcrips.', 'etcsrs.',
              'tvpost.cc', 'tellygossips.', 'tvarticles.', 'insurancehubportal.']

apneembed = ['newstalks.co', 'newstrendz.co', 'newscurrent.co', 'newsdeskroom.co',
             'newsapne.co', 'newshook.co', 'newsbaba.co', 'articlesnewz.com',
             'articlesnew.com', 'webnewsarticles.com']

articlesembed = ['articleweb.', 'serialghar.', 'tvarticles.', 'bollyfunmaza.']

def find_domain_notin(url):
    """
    useges:
    if not find_domain_notin(url):
        print(f'url: {url}')
    slower option:
    def re_domain_notin(url):
        return bool((re.search(r'dailymotion|vup|streamtape|vidoza|mixdrop|mystream|doodstream|watchvideo|vkprime|vkspeed', str(url), re.I,)))
    def find_domain_intersection(url):
        itemfound = [s for s in [url] if keys.intersection(s)]
        return bool(itemfound)
    """
    url = url.lower()
    filter_items = {'dailymotion', 'vup', 'streamtape', 'vidoza', 'mixdrop', 'mystream', 'doodstream', 'watchvideo', 'vkprime', 'vkspeed'}
    return any(item in url for item in filter_items)


def get_source_dict(urls, sources, ihost=None, direct=False):
    # log(f'get_source_dict urls: {urls}')
    if isinstance(urls, str): urls = [urls]
    if any(x in str(urls) for x in remove_ads_js_urls): return sources
    if ihost is None: ihost = host(urls[0])
    # if re.search(r'speed|vkprime', urls[0], re.I): ihost = 'speed|vkprime'
    # log(f'ihost {ihost} len(urls) {len(urls)} type of urls {type(urls)}')
    for i in range(len(urls)):
        # if any(re.findall(r'speed|vkprime|business-loans.pw|bestarticles|tvnation.me', urls[i], re.IGNORECASE)):
        try:
            vid_url = str(urls[i])
            if any(x in vid_url.lower() for x in ['vkspeed', 'vkprime']): urls[i] = iurl if (iurl := get_mod_url(vid_url)) else None
            # if re.search(r'vkspeed|vkprime', vid_url, re.I): urls[i] = iurl if (iurl := get_mod_url(vid_url)) else None
            # log(f'In urls[i]: {vid_url}')
            if len(urls) > 1 and any(x in vid_url.lower() for x in ['vkspeed', 'vkprime']): #(re.search(r'vkspeed|vkprime', vid_url, re.I)):
                for j, ji in enumerate(urls, start=1):
                    if ji not in str(sources): sources.append({'source': ihost, 'quality': '720p', 'info': f'Part:{j}', 'url': ji, 'direct': False})
        except: error(f'{__name__}_ Error: {print_exc()}')

    if len(urls) > 1: unfo, url = f'All parts: {len(urls)}', ' , '.join(urls)
    else: unfo, url = 'All part: Single', urls[0]
    sources.append({'source': ihost, 'quality': '720p', 'info': unfo, 'url': url, 'direct': direct})
    return sources


def append_headers(headers):
    return f'|{"&".join([f"{key}={quote_plus(headers[key])}" for key in headers])}'


def meta_redirect(content):
    redirect_re = re.compile('<meta[^>]*?[refresh|]*?url=(.*?)["\']', re.IGNORECASE)
    return match.groups()[0].strip() if (match := redirect_re.search(str(content))) else None


def form_action(url, headers, bhtml):
    try:
        if r := re.findall(r'''<form.+?action="([^"]+)''', bhtml, re.DOTALL):
            purl = r[-1]
            headers.update({'Referer': url, 'Origin': urljoin(url, '/')[:-1]})
            pd = (dict(r1) if (r1 := re.findall(r"type='hidden'\s*name='([^']+)'\s*value='([^']+)", bhtml,)) else ' ')
            bhtml2 = request(purl, post=pd, headers=headers)
            if s := re.findall(r'''<iframe.+?src=['"]([^"']+)''', bhtml2, re.I):
                return s
            if r2 := re.findall(r'''<form.+?action="([^"]+)''', bhtml2, re.DOTALL):
                purl = r2[-1]
                headers.update({'Referer': url, 'Origin': urljoin(url, '/')[:-1]})
                if r1 := re.findall(r"type='hidden'\s*name='([^']+)'\s*value='([^']+)", bhtml2): pd = dict(r1)
                else: pd = ' '
                ehtml = request(purl, post=pd, headers=headers)
                if s := re.findall(r'''<iframe.+?src=['"]([^"']+)''', ehtml, re.I):
                    return s
        elif s := re.findall(r'''<iframe.+?src=['"]([^"']+)''', bhtml, re.I):
            return s
    except Exception as e:
        log(f'apne_twostop Error: {e} traceback: {print_exc()}', 'error')
        return


def articleweb(url, headers):
    # log(f'headers >>> : {headers}')
    try:
        if '/vid/' not in url or 'multiup' in url:
            url, ehtml = refresh_redirect(url, headers)
        else: ehtml = request(url, headers=headers)
        if not (s := re.search(r'''<iframe.+?src=['"]([^'"]+)''', ehtml, re.I)):
            return
        return s[1]
    except Exception as e:
        error(f'{__name__}_ articleweb: ')


def get_apneurl(link, headers):
    vidurl = None
    url, html = refresh_redirect(link, headers)
    if s := form_action(link, headers, html):
        try:
            vidurl = s[0]
            # log(f'get_apneurl In vidurl  {vidurl}')
            if 'url=' in vidurl: vidurl = vidurl.split('url=')[-1]
            if 'hls' in vidurl: vidurl = vidurl.replace(',.urlset/master.m3u8', '/v.mp4').replace('hls/,', '')
            else: vidurl = vidurl
        except Exception as e: log(f'Error {e}: in get_embed_url: {print_exc()}')
    return vidurl


def get_embed_url(url, headers):
    # log(f'get_embed_url url: {repr(url)}')
    try:
        # log(f'headers: {headers}')
        url, result = refresh_redirect(url, headers=headers)
        # log(f'result: {result}')
        url = meta_redirect(result)
        if url: url, result = refresh_redirect(url, headers=headers)
        if not result: return
        vidurl = get_vid_url(result, headers, url)
        if not vidurl: log(f'get_embed_url not returning vidurl: {vidurl} url: {repr(url)}') #\nresult: {result}\n')
        return vidurl
    except Exception as e: log(f'Error {e}: in get_embed_url: {print_exc()}')
    return


def get_okmalayalam_url(url, headers):
    # log(f'get_okmalayalam_url url: {repr(url)}')
    try:
        mid = url.split('/')[-1]
        params = {'data': mid, 'do': 'getVideo'}
        data = {'hash': mid, 'r': ''}
        if jd := request('https://v.okmalayalam.org/player/index.php', XHR=True, referer=url, post=data, params=params,):
            log(f'jd: {jd}')
            jd = json.loads(jd)
            # surl = jd.get('videoSource')
            vidurl = jd.get('securedLink')
            if not vidurl: log(f'get_okmalayalam_url not returning vidurl: {vidurl} url: {repr(url)}') #\nresult: {result}\n')
            return vidurl
    except Exception as e: log(f'Error {e}: in get_okmalayalam_url: {print_exc()}')
    return


def get_directurl(link, headers, url):
    refr = urljoin(url, '/')
    vhdr = {'Referer': refr, 'Origin': refr[:-1], 'User-Agent': 'iPad'}
    return f'Direct_{link}|{urlencode(vhdr)}'


def get_vid_url(shtml, headers, url):
    try:
        from openscrapers.modules import jsunpack, unjuice
        # links = parseDOM(shtml, 'iframe', ret='src')
        # log(f'get_vid_url Total: {len(links)} links1: {links}')
        # log(f'get_vid_url Total: {len(links)} links1: {links}')
        if unjuice.test(shtml): shtml += unjuice.run(shtml)
        if jsunpack.detect(shtml): shtml += jsunpack.unpack(shtml)
        # log(f'shtml: {len(shtml)} shtml: {shtml}')
        links = re.findall(r'''<iframe.+?src=['"]([^'"]+)''', shtml, re.I)
        # links += re.findall(r'''(?:iframe|source).+?(?:src|file)\s*["']?\s*[:=,]?\s*["']([^"']+)''', shtml, re.DOTALL)
        # links += re.findall(r'''["']?\s*(?:file|src)\s*["']?\s*[:=,]?\s*["']([^"']+)''', str(shtml), re.I)
        # log(f'get_vid_url Total: {len(links)} links2: {links}')
        links = [url for url in links if all(x not in url for x in remove_ads_js_urls)]
        for link in links:
            link = link.lower()
            # log(f'get_vid_url link: {link}')
            if any(x in link for x in ['speed', 'vkprime', 'tvlogy']): return link
            elif any(x in link for x in articlesembed): return articleweb(link, headers)
            elif any(x in link for x in apneembed): return get_apneurl(link, headers)
            elif 'okmalayalam.' in link: return get_okmalayalam_url(link, headers)
            elif 'flow.' in link: return get_embed_url(link, headers)
            elif all(x not in link for x in non_str_list) and all(x not in link for x in embed_list): return link
            elif 'tvlogy' not in link: return get_directurl(link, headers, url)
    except Exception as e: log(f'Error {e}: in get_vid_url: {print_exc()}')
    return


def resolve_gen(url, headers=None):
    # log(f'In resolve_gen(url) type of url {type(url)} url: {url}')
    # if not any(re.findall(r'dailymotion|vup|streamtape|vidoza|mixdrop|mystream|doodstream|watchvideo|vkprime|vkspeed', url, re.IGNORECASE)):
    if headers is None: headers = {}
    if not find_domain_notin(str(url)):
        urls = url.split(' , ') if ' , ' in url else [url]
        if not headers: headers = {'User-Agent': agent()}
        # log(f'In len of urls {len(urls)} urls: {urls} headers: {headers}')
        furl = []
        for iurl in urls:
            # log(f'resolve_gen iurl: {iurl}')
            if any(x in iurl for x in apneembed): url = get_apneurl(iurl, headers)
            elif any(x in iurl for x in articlesembed): url = articleweb(iurl, headers)
            else: url = get_embed_url(iurl, headers)
            if url: furl.append(url)
        # log(f'resolve_gen len furl: {len(furl)} type furl {type(furl)} furl: {furl}')
        if furl:
            if testing: log(f'Out resolve_gen(url)type of furl {type(furl)} furl: {furl}')
            return ' , '.join(furl) if furl else furl[0]
    return url


def convert_youtube_duration_to_minutes(duration):
    """
    :param duration:
    convert_YouTube_duration_to_minits('P2DT1S')
    172801
    convert_YouTube_duration_to_minits('PT2H12M51S')
    7971
    :return:
    """
    day_time = duration.split('T')
    day_duration = day_time[0].replace('P', '')
    day_list = day_duration.split('D')
    hour = minute = second = day = 0
    if len(day_list) == 2: day = int(day_list[0]) * 60 * 60 * 24  # day_list = day_list[1]
    hour_list = day_time[1].split('H')
    if len(hour_list) == 2:
        hour = int(hour_list[0]) * 60 * 60
        hour_list = hour_list[1]
    else: hour_list = hour_list[0]
    minute_list = hour_list.split('M')
    if len(minute_list) == 2:
        minute = int(minute_list[0]) * 60
        minute_list = minute_list[1]
    else: minute_list = minute_list[0]
    second_list = minute_list.split('S')
    if len(second_list) == 2: second = int(second_list[0])
    minutes = (day + hour + minute + second) / 60
    return int(minutes)


def threadwrap(func, extr_iurl, que):
    """
    :useges:
    from Queue import Queue
    que = Queue()
    furls = hindi_sources.threadwrap(hindi_sources.get_embed_url, extr_iurl, que)
    log(f'ilink: {str(que.get())}')
    :param func:
    :param extr_iurl:
    :param que:
    :param furls:

    :return:
    """
    # from Queue import Queue
    import threading
    # que = Queue()
    # log(f'extr_iurl: {extr_iurl}')
    threads = [
        threading.Thread(target=lambda q, arg: q.put(func(iurl)), args=(que, iurl))
        for iurl in extr_iurl
        ]
    [i.start() for i in threads]
    [i.join() for i in threads]
    # log(f'threads: {threads}')
    # if str(que.get()) is not None:
    # while not que.empty():
    #     log(f'ilink: {str(que.get())}')
    #     if str(que.get()) is not None:
    #         furls.append(que.get())
    # return furls


def scrape_sources(html, result_blacklist=None, scheme='http', patterns=None, generic_patterns=True):
    if patterns is None: patterns = []

    def __parse_to_list(_html, regex):
        _blacklist = ['.jpg', '.jpeg', '.gif', '.png', '.js', '.css', '.htm', '.html', '.php', '.srt', '.sub', '.xml', '.swf', '.vtt', '.mpd']
        _blacklist = set(_blacklist + result_blacklist)
        streams = []
        labels = []
        for r in re.finditer(regex, _html, re.DOTALL):
            match = r.groupdict()
            stream_url = match['url'].replace('&amp;', '&')
            file_name = urlparse(stream_url[:-1]).path.split('/')[-1] if stream_url.endswith('/') else urlparse(stream_url).path.split('/')[-1]
            label = match.get('label', file_name)
            if label is None: label = file_name
            blocked = not file_name or any(item in file_name.lower() for item in _blacklist) or any(item in label for item in _blacklist)
            if stream_url.startswith('//'): stream_url = f'{scheme}:{stream_url}'
            if '://' not in stream_url or blocked or (stream_url in streams) or any(stream_url == t[1] for t in source_list): continue
            labels.append(label)
            streams.append(stream_url)

        matches = list(zip(labels, streams))
        if matches: log(f'@@@@ Scrape sources |{regex}| found |{matches}|', __name__)
        return matches #labels, streams

    if result_blacklist is None: result_blacklist = []
    elif isinstance(result_blacklist, str): result_blacklist = [result_blacklist]

    html = html.replace(r'\/', '/')
    html += get_packed_data(html)

    source_list = []
    if generic_patterns or not patterns:
        source_list += __parse_to_list(html, r'''["']?label\s*["']?\s*[:=]\s*["']?(?P<label>[^"',]+)["']?(?:[^}\]]+)["']?\s*file\s*["']?\s*[:=,]?\s*["'](?P<url>[^"']+)''')
        source_list += __parse_to_list(html, r'''["']?\s*(?:file|src)\s*["']?\s*[:=,]?\s*["'](?P<url>[^"']+)(?:[^}>\]]+)["']?\s*label\s*["']?\s*[:=]\s*["']?(?P<label>[^"',]+)''')
        source_list += __parse_to_list(html, r'''video[^><]+src\s*[=:]\s*['"](?P<url>[^'"]+)''')
        source_list += __parse_to_list(html, r'''source\s+src\s*=\s*['"](?P<url>[^'"]+)['"](?:.*?res\s*=\s*['"](?P<label>[^'"]+))?''')
        source_list += __parse_to_list(html, r'''["'](?:file|url)["']\s*[:=]\s*["'](?P<url>[^"']+)''')
        source_list += __parse_to_list(html, r'''param\s+name\s*=\s*"src"\s*value\s*=\s*"(?P<url>[^"]+)''')
        # source_list += __parse_to_list(html, r'''["']?\s*(?:file|url)\s*["']?\s*[:=]\s*["'](?P<url>[^"']+)''')
        # source_list += __parse_to_list(html, '''(?i)<iframe.+?src=["']([^'"]+)''')
    for regex in patterns:
        source_list += __parse_to_list(html, regex)

    source_list = list(set(source_list))
    log(f'@@@@ last source_list [{source_list}]', __name__)
    # source_list = sort_sources_list(source_list)
    return source_list


def get_packed_data(html):
    from jsunpack import unpack, detect
    packed_data = ''
    for match in re.finditer(r'''(eval\s*\(function\(p,a,c,k,e,.*?)</script>''', html, re.DOTALL | re.I):
        r = match.group(1)
        t = re.findall(r'(eval\s*\(function\(p,a,c,k,e,)', r, re.DOTALL | re.IGNORECASE)
        if len(t) == 1:
            if detect(r):
                packed_data += unpack(r)
        else:
            t = r.split('eval')
            t = [f'eval{x}' for x in t if x]
            for r in t:
                if detect(r):
                    packed_data += unpack(r)
    return packed_data


def _patterns(text, patterns=[]):
    """Given source text and a list of patterns, look for
    matches for each pattern within the text and print
    them to stdout.
    useges:
    test_patterns('abbaaabbbbaaaaa',
              [ 'ab*',     # a followed by zero or more b
                'ab+',     # a followed by one or more b
                'ab?',     # a followed by zero or one b
                'ab{3}',   # a followed by three b
                'ab{2,3}', # a followed by two to three b
                ])
    :return:
    """
    # Show the character positions and input text
    log(''.join(str(i / 10 or ' ') for i in range(len(text))))
    log(''.join(str(i % 10) for i in range(len(text))))
    log(text)

    # Look for each pattern in the text and print the results
    for pattern in patterns:
        log(f'Matching {pattern}')
        for match in re.finditer(pattern, text):
            s = match.start()
            e = match.end()
            log(f'  {s:2d} : {e - 1:2d} = {text[s:e]}')
    return


def regex_patterns():
    """
    Use this regular expression to find all of Positive look behind and positive look ahead with contained m3u8
    :return:
    """
    start = '''source:['"]'''
    containe = '''m3u8'''
    end_ = '''['"],'''
    pattern = f'''(?<={start})(.*?){containe}(?={end_})'''
    text = '''This is (a simple) sentence
//source:'https://webudit.webdicdn.lol/lb/premium347/index.m3u8?auth=MjE2LjIxMS4xNTMuMTU4',   
source:'https://webudit.webdicdn.lol/lb/premium347/index.m3u8',   
          //      hideVolumeBar: true
//poster: "https://videocdn.click/loading.gif",'''
    data = re.search(pattern, text)
    log(f'data: {data[0]}')
    """
    Use this regular expression to find all of consecutive whitespaces. Very useful for text editing purposes to cure text
    :return:
    """
    pattern = r'''(?:\s)\s'''
    text = '''330                                                                  
      
    layout (location = 0) in vec3 Position;                                       
    
    void main()    '''
    data = re.sub(pattern, '', text)
    log(f'data: {data.strip()}')
    """
    remove Matches all non-ascii characters including spaces until reaching an ascii character in text
    """
    pattern = r'''[^\x00-\x7F]+\ *(?:[^\x00-\x7F]| )*'''
    text = '''ABCabc~ |	*	Õ×ë
                テ  スト。
                －Τα εννέα πουλιά －
                ＭＩＲＲＯＲ'''
    data = re.sub(pattern, '', text)
    log(f'data: {data.strip()}')
    """
    get text between 2 marker
    as-is will fail with an AttributeError if there are no "AAA" and "ZZZ" in text
    """
    text = 'gfgfdAAA1234ZZZuijjk'
    data = re.search(r'(?<=AAA).*?(?=ZZZ)', text).group(0)
    log(f'data: {data}')
    """Get URL and Lable from:
    """
    result = """value="87"/>
    <td class="line-content">  sources:[{file: 'https://hls2x.vidembed.net/load/hls/YcZQc1FGQYWuj_fAI2F7Pg/1625270480/242436/a8d172bb473a8ba8e2feddc34c478e4b/ep.11.1618011076.m3u8',label: 'hls P','type' : 'hls'}],</td>
    </tr>"""
    data = re.search(r'''["']?\s*(?:file|src)\s*["']?\s*[:=,]?\s*["'](?P<url>[^"']+)(?:[^}>\]]+)["']?\s*label\s*["']?\s*[:=]\s*["']?(?P<label>[^"',]+)''', result)
    log(f'data: {data.group("url")}')
    log(f'data: {data.group("label")}')
    """It will remove all the control characters"""
    text = 'Saina\xa0(2021)'
    # result = re.sub(r'[^\x00-\x7f]', '', text)
    result = re.sub(pattern, '', text)
    log(f'remove all the control char: {result}')
    """clean title from (Season 1|Season 2|S01|S02)"""
    text = 'suite Season 1|F.B.I. Season 2|S01|S02'
    result = re.sub(r'([Ss]eason) \d{1,2}|[Ss]\d{1,2}', '', text)
    log(f'clean title from (Seaso: {result}')
    """Removing Digits from a String"""
    text = 'The film Pulp Fiction was released in year 1994'
    result = re.sub(r'\d', '', text)
    log(f'Removing Digit: {result}') # The film Pulp Fiction was released in year
    """Removing Alphabet Letters from a String"""
    text = 'The film Pulp Fiction was released in year 1994'
    result = re.sub(r'[a-z]', '', text, flags=re.I)
    log(f'Removing Alphabet: {result}') # 1994
    """Removing Word Characters"""
    text = 'The film, @Pulp Fiction was ? released in % $ year 1994.'
    result = re.sub(r'\w', '', text, flags=re.I)
    log(f'Removing Word: {result}') # , '@ '  ?   % $  .
    """Removing Non-Word Characters"""
    text = 'The film, @Pulp Fiction was ? released in % $ year 1994.'
    result = re.sub(r'\W', '', text, flags=re.I)
    log(f'Removing Non-Word: {result}') # ThefilmPulpFictionwasreleasedinyear1994
    """Grouping Multiple Patterns"""
    text = 'The film, @Pulp Fiction was ? released _ in % $ year 1994.'
    result = re.sub(r'[,@\'?\.$%_]', '', text, flags=re.I)
    log(f'Grouping Multiple Patterns: {result}') # The film Pulp Fiction was  released  in   year 1994
    """Removing Multiple Spaces"""
    text = 'The film      Pulp Fiction      was released in   year 1994.'
    result = re.sub(r'\s+', ' ', text, flags=re.I)
    log(f'Removing Multiple Spaces: {result}') # The film Pulp Fiction was released in year 1994.
    """Removing Spaces from Start and End"""
    text = '         The film Pulp Fiction was released in year 1994'
    result = re.sub(r'^\s+', '', text)
    log(f'Removing Spaces from Start and End: {result}')
    """"remove space at the end of the string"""
    text = 'The film Pulp Fiction was released in year 1994      '
    result = re.sub(r'\s+$', '', text)
    log(f'remove space at the end: {result}') # The film Pulp Fiction was released in year 1994
    """Removing a Single Character"""
    text = 'The film Pulp Fiction     s was b released in year 1994'
    result = re.sub(r'\s+[a-zA-Z]\s+', ' ', text)
    log(f'Removing a Single Characte: {result}') # The film Pulp Fiction was released in year 1994
    """Splitting a String"""
    text = 'The film      Pulp   Fiction was released in year 1994      '
    result = re.split(r'\s+', text)
    log(f'Splitting a String: {result}') # ['The', 'film', 'Pulp', 'Fiction', 'was', 'released', 'in', 'year', '1994', '']
    text = 'The film, Pulp Fiction, was released in year 1994'
    result = re.split(r'\,', text)
    log(f'Splitting a String: {result}') # ['The film', ' Pulp Fiction', ' was released in year 1994']
    """split str by date split from date like-21st-may-2023"""
    text = 'https://desirulez.co/naagin-6-20th-may-2023-video-episode-update-online/'
    result = re.split('(-\d{1,2}(st|nd|rd|th))(.*?)(\d{2,4})', text)
    log(f'split str: {result}')  # ['200', '400']
    """Finding All Instances"""
    text = 'I want to buy a mobile between 200 and 400 euros'
    result = re.findall(r'\d+', text)
    log(f'Finding All Instances: {result}') # ['200', '400']


def extractJS(data, function=False, variable=False, match=False, evaluate=False, values=False):
    log('')
    scripts = parseDOM(data, 'script')
    if len(scripts) == 0:
        log('Could not find any script tags. Assuming javascript file was given.')
        scripts = [data]

    lst = []
    log('Extracting', 0)
    for script in scripts:
        tmp_lst = []
        if function:
            tmp_lst = re.compile(r'\(.*?\).*?;', re.M | re.S).findall(script)
            # tmp_lst = re.compile(function + r'\(.*?\).*?;', re.M | re.S).findall(script)
        elif variable:
            # tmp_lst = re.compile(variable.replace('[', r'\[').replace(']', r'\]') + '[ ]+=.*?;', re.M | re.S).findall(script)
            # log('script: ' + repr(script), 0)
            tmp_lst = re.compile(r'var.*?=.*?(.+)[,;]{1}', re.M | re.S).findall(script)
            # log('tmp_lst: ' + repr(tmp_lst))
            # log('????tmp_lst: ' + repr(tmp_lst), 0)
        else:
            tmp_lst = [script]
        if len(tmp_lst) > 0:
            log(f'Found: {repr(tmp_lst)}', 0)
            lst += tmp_lst
        else:
            log(f'Found nothing on: {script}', 0)

    lst = [i for i in lst if i != u''] # remove empty item from list
    test = range(len(lst))
    log(f'lst: {lst}')

    # test.reverse()
    for i in test:
        if match and lst[i].find(match) == -1:
            log(f'Removing item: {repr(lst[i])}', 0)
            del lst[i]
        else:
            log(f'Cleaning item: {repr(lst[i])}', 0)
            if lst[i][0] == u'\n':
                lst[i] = lst[i][1:]
            if lst[i][len(lst) - 1] == u'\n':
                lst[i] = lst[i][:len(lst) - 2]
            lst[i] = lst[i].strip()

    if values or evaluate:
        for i in range(len(lst)):
            log(f'Getting values {lst[i]}')
            if function:
                data = (
                    re.compile(r'(\(.*?\))', re.M | re.S).findall(lst[i])
                    if evaluate
                    else re.compile(r'\((.*?)\)', re.M | re.S).findall(lst[i])
                )
            elif variable:
                tlst = re.compile(f'{variable}.*?=.*?;', re.M | re.S).findall(lst[i])
                data = []
                for tmp in tlst:  # This breaks for some stuff. 'ad_tag': 'http://ad-emea.doubleclick.net/N4061/pfadx/com.ytpwatch.entertainment/main_563326' # ends early, must end with }
                    cont_char = tmp[0]
                    cont_char = tmp[tmp.find('=') + 1:].strip()
                    cont_char = cont_char[0]
                    if cont_char in "'\"":
                        log(f'Using {cont_char} as quotation mark', 1)
                        tmp = tmp[tmp.find(cont_char) + 1:tmp.rfind(cont_char)]
                    else:
                        log('No quotation mark found', 1)
                        tmp = tmp[tmp.find('=') + 1: tmp.rfind(';')]

                    tmp = tmp.strip()
                    if len(tmp) > 0:
                        data.append(tmp)
            else:
                log('ERROR: Don\'t know what to extract values from')

            log(f'Values extracted: {repr(data)}')
            if len(data) > 0:
                lst[i] = data[0]

    if evaluate:
        for i in range(len(lst)):
            log(f'Evaluating {lst[i]}')
            data = lst[i].strip()
            try:
                try:
                    lst[i] = json.loads(data)
                except:
                    log('Couldn\'t json.loads, trying eval')
                    lst[i] = eval(data)
            except:
                log(f'Couldn\'t eval: {repr(data)} from {repr(lst[i])}')

    log(f'Done: {len(lst)}')
    return lst


def find_match(regex, text, index=0):
    results = re.findall(text, regex, flags=re.DOTALL | re.IGNORECASE)
    return results[index]


def ordinal(integer):
    int_to_string = str(integer)
    # log(f'{int_to_string}st')
    if int_to_string in {'1', '-1'}: return f'{int_to_string}st'
    elif int_to_string in {'2', '-2'}: return f'{int_to_string}nd'
    elif int_to_string in {'3', '-3'}: return f'{int_to_string}rd'
    elif int_to_string[-1] == '1' and int_to_string[-2] != '1': return f'{int_to_string}st'
    elif int_to_string[-1] == '2' and int_to_string[-2] != '1': return f'{int_to_string}nd'
    elif int_to_string[-1] == '3' and int_to_string[-2] != '1': return f'{int_to_string}rd'
    else: return f'{int_to_string}th'

def daterange(weekend=False):
    weekday_dict = []
    weekend_dict = []
    end_date = datetime.date.today()  # end_date = date(2018, 1, 1)
    start_date = (end_date - datetime.timedelta(.25*365 / 12))  # start_date = date(2017, 1, 1)
    # log(f'start_date : {start_date}')
    for n in range(int((end_date - start_date).days)):
        d = start_date + datetime.timedelta(n)
        weekno = d.weekday()
        # log(f'start_date : {d} :: {weekno}')
        day = d.strftime('%d').lstrip('0')
        day = ordinal(day)
        mont = d.strftime('%B')
        year = d.strftime('%Y')
        if weekend and weekno >= 5: weekend_dict.append(f'{day} {mont} {year}')
        if weekno < 5: weekday_dict.append(f'{day} {mont} {year}')
    return weekend_dict if weekend else weekday_dict


def get_hindi_show_episod(tvshowtitle):
    if tvshowtitle in 'the kapil sharma show': episodes = daterange(weekend=True)
    else: episodes = daterange()
    episode = random.choice(episodes)
    serattearm = f'{tvshowtitle}-{episode}'
    return serattearm.lower().replace(' ', '-').replace('.', '-')


def read_write_file(file_n='test.html', read=True, result=''):
    """
    :useged:
    from openscrapers.modules.hindi_sources import read_write_file
    read_write_file('test_%s.html' % hdlr, read=False, result=r)
    :param file_n:
    :param read:
    :param result:
    :return:

    """
    if read:
        with open(file_n, mode='r', encoding='utf-8', errors='ignore') as f:
            result = f.read()
        return result
    else:
        try:
            result = result.replace('\n', ' ').replace('\t', '').replace('&nbsp;', '').replace('&#8211;', '')
            with open(file_n, mode='w', encoding='utf-8') as f:
                f.write(str(result))
        except: log(f'Error: in read_write_file: {print_exc()}')


def testing_write_html(url, responce):
    elements = urlparse(url)
    html_filename = f'{elements.netloc or elements.path}.html'
    html_filename = f'JSTesting/{html_filename}'
    log(f'USE html_filename: {html_filename}')
    try: data = responce.text
    except: data = responce
    read_write_file(file_n=html_filename, read=False, result=data)


def find_season_in_title(release_title):
    match = 1
    release_title = re.sub(r'\d{4}', '', release_title)  # remove year from title
    regex_list = [r'.+?(\d{1,2})', r'[sS]eason.+?(\d+)', r'[sS]eason(\d+)', r'[sS](\d+)', r'[cC]hapter.+?(\d+)']
    for item in regex_list:
        try:
            match = re.search(item, release_title)
            if match:
                match = int(str(match[1]).lstrip('0'))
                break
            else: match = 1
        except: pass
    return match


def urlRewrite(url):
    # 'https://vkprime.com/embed-7pws6soif1cn.html'
    url_dics = [{'host': 'vkprime.php', 'url': 'http://vkprime.com/embed-%s.html'},
                {'host': 'vkspeed.php', 'url': 'http://vkspeed.com/embed-%s.html'},
                {'host': 'speed.php', 'url': 'http://vkspeed.com/embed-%s-600x380.html'}]
    try:
        videoID = getVideoID(url)
        for i in url_dics:
            try:
                if re.compile(i['host']).findall(url)[0]: return i['url'] % videoID
            except: pass
        return url
    except: return url


def findvid_url(text: str):
    """
    :type text: str
    """
    _regexs = [r'(?:iframe|source).+?(?:src)=(?:\"|\')(.+?)(?:\"|\')',
               r'(?:data-video|data-src|data-href)=(?:\"|\')(.+?)(?:\"|\')',
               r'(?:file|source|src)(?:\:)\s*(?:\"|\')(.+?)(?:\"|\')',
               r'''<iframe.+?src=['"]([^'"]+)''',
               r'"(?:file|src)"\s*:\s*"([^"]+m3u8)']
    links = []
    if not text: return
    for _regex in _regexs:
        try:
            if items := re.compile(_regex, flags=re.DOTALL | re.I).findall(text):
                for link in items:
                    link = link if link.startswith('http') else f'https:{link}'
                    if link in links: continue
                    if all(x not in link for x in remove_ads_js_urls):
                        links.append(link)
        except: log(f'Error: {print_exc()}')
    return links

def convert(data):
    """
    useges:
    response_params = Utils.convert(dict(urllib.parse.parse_qsl(response_text)))
    """
    if isinstance(data, bytes): return data.decode('ascii')
    if isinstance(data, dict): return dict(map(convert, data.items()))
    return map(convert, data) if isinstance(data, tuple) else data


def get_form_action(url, html, headers):
    try:
        # r = re.findall(r'''<form.+?action="([^"]+).+?name='([^']+)'\s*value='([^']+)''', html, re.DOTALL)
        r = re.findall(r'''<form.+?action="([^"]+)''', html, re.DOTALL)
        headers.update({'Referer': url, 'Origin': urljoin(url, '/')[:-1]})
        if r:
            try:
                purl = r[0]
                # log(f'get_form_action >>> purl: {purl}')
                if r := re.findall(r"type='hidden'\s*name='([^']+)'\s*value='([^']+)", html):
                    pd = dict(r)
                else: pd = ' '
                html = request(purl, post=pd, headers=headers)
            except: log(f'Error in get_form_action: {print_exc()}')
            # html = request(purl, post={name: value}, headers=headers)
        # else:
            # r2 = re.findall(r'''<form.+?action="([^"]+).+?''', html, re.DOTALL)
            # if r2:
                # log(f'get_form_action >>> r2: {r2}  headers: {headers}')
                # purl = r2[0]
                # html = request(purl, post=' ', headers=headers)
        return str(html)
    except Exception as e: log(f'Error {e}: in get_form_action: {print_exc()}')
