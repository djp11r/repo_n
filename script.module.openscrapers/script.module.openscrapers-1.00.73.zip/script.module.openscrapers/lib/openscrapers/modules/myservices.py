import requests, time
from threading import Thread, Timer

from urllib.parse import quote
from openscrapers.windows.base import Progress
# from modules import cache_utils

from openscrapers.modules.control import setting, setSetting, sleep, notification, inputdialog, yesnoDialog, okDialog, make_listitem, selectDialog, addonIcon, addonPath
from openscrapers.modules.log_utils import error, log
from openscrapers.modules.cleandate import utc_to_datetime
# clear_cache = cache_utils.clear_cache
user_agent = 'SALTS/%s' % '6.04.04'
qr_str = 'https://api.qrserver.com/v1/create-qr-code/?size=256x256&qzone=1%s'
meta_keys = 'title year poster fanart clearlogo'
code_str, nav2_str, await_str = 'PIN CODE: [B]%s[/B]', 'LOCATION: [B]%s[/B]', 'REMAINING: [B]%02d:%02d[/B]'
auth_str, noauth_str = 'Authorized: Select to Remove', 'Unauthorized: Select to Add'
timeout = 10.05
img_url = 'https://i.imgur.com/%s.png'


def watch_indicators(function):
	def wrapper(instance, *args, **kwargs):
		if function(instance, *args, **kwargs): okDialog(message=(
			'At successful activation, watched status and resume progress will be set to [B]%s[/B]. '
			'To change settings after activation, use the addon settings category:[CR]'
			'[B]Features/Watched Indicators/Watched Status Provider[/B]'
		) % instance.__class__.__name__)
	return wrapper

def _make_progress_dialog(**kwargs):
	log(f'kwargs: {repr(kwargs)}')
	if icon is None: icon = addonIcon()
	window = Progress('progress.xml', addonPath(), heading=heading, icon=icon, qr=qr, artwork=artwork)
	Thread(target=window.run).start()
	return window

def authorize():
	def _builder():
		for api in services:
			item = make_listitem()
			item.setLabel('[B]%s[/B]' % api.__name__.upper())
			item.setLabel2(auth_str if api().token else noauth_str)
			item.setArt({'icon': api.icon if api.icon.startswith('Default') else '%s%s' % (img_url, api.icon)})
			yield item
	services = (Trakt, MDBList, TMDbList)
	service = selectDialog('My Services', list(_builder()), useDetails=True)
	if service < 0: return
	try: success = services[service]().set()
	except Exception as e: log(f'myservices error: {str(e)}')
	else: return success
	return notification('Error in authorize')

class RepeatTimer(Timer):
	def run(self):
		while not self.finished.wait(self.interval):
			self.function(*self.args, **self.kwargs)


class Trakt:
	icon = 'sGq3ifV'
	def __init__(self):
		self.token = setting('trakt.token')
		self.client_id = setting('trakt.client')
		self.secret = setting('trakt.secret')

	def base_url(self, path):
		return f'https://auth.trakt.tv/{path}'

	def poll_auth(self, data):
		response = requests.post(self.base_url('oauth/device/token'), json=data, timeout=timeout)
		if not response.ok: return
		data.update(response.json())
		self.token = data['access_token']

	@watch_indicators
	def set(self):
		if self.token:
			if not yesnoDialog(): return
			data = {'token': self.token, 'client_id': self.client_id, 'client_secret': self.secret}
			response = requests.post(self.base_url('oauth/revoke'), json=data, timeout=timeout)
			setSetting('trakt.user', '')
			setSetting('trakt.token', '')
			setSetting('trakt.refresh', '')
			setSetting('trakt.expires', '')
			setSetting('trakt_indicators_active', 'false')
			setSetting('watched_indicators', '0')
			sleep(500)
			# clear_cache('trakt', silent=True)
			return notification(f'Removed {self.__class__.__name__} Authorization')

		data = {'client_id': self.client_id, 'client_secret': self.secret, 'code': ''}
		response = requests.post(self.base_url('oauth/device/code'), json=data, timeout=timeout)
		result = response.json()
		data['code'] = result['device_code']
		expires_in, expires_at = result['expires_in'], result['expires_in'] + time.monotonic()
		try: qr_icon = qr_str % '&color=f00&data=%s' % quote('%s/%s' % (result['verification_url'], result['user_code']))
		except: qr_icon = ''
		meta = {**dict.fromkeys(meta_keys.split(), ''), 'poster': qr_icon}
		detail = code_str % result['user_code'], nav2_str % result['verification_url']
		progress_dialog = _make_progress_dialog(meta=meta)
		timer = RepeatTimer(result['interval'], self.poll_auth, args=(data,))
		timer.start()
		for i in range(1, expires_in + 1):
			if self.token or progress_dialog.iscanceled(): break
			lines = await_str % divmod(expires_at - time.monotonic(), 60), *detail
			progress = 100 - int(100 * i / expires_in)
			progress_dialog.update('[CR]'.join(lines), progress)
			sleep(1000)
		timer.cancel()
		progress_dialog.close()
		if progress_dialog.iscanceled(): return False
		if not self.token: return notification(f'Error {self.__class__.__name__}.set()')
		sleep(500)
		headers = {'trakt-api-key': self.client_id, 'trakt-api-version': '2', 'Content-Type': 'application/json'}
		headers.update({'Authorization': f'Bearer {self.token}'})
		response = requests.get('https://api.trakt.tv/users/me', headers=headers, timeout=timeout)
		username = response.json()['username']
		expires = int(data['created_at']) + int(data['expires_in'])
		refresh, token = data['refresh_token'], data['access_token']
		setSetting('trakt.user', str(username))
		setSetting('trakt.token', token)
		setSetting('trakt.refresh', refresh)
		setSetting('trakt.expires', str(expires))
		setSetting('trakt_indicators_active', 'true')
		setSetting('watched_indicators', '1')
		expires_in = utc_to_datetime(float(expires))
		setSetting('trakt_renual', expires_in)
		notification(f'Set {self.__class__.__name__} Authorization')
		sleep(500)
		# clear_cache('trakt', silent=True)
		return True

class MDBList:
	icon = 'mdblist.png'
	def __init__(self):
		self.grant_type = 'urn:ietf:params:oauth:grant-type:device_code'
		self.client_id = get_setting('mdblist.client_id')
		self.token = get_setting('mdblist.token')
		self.created_at = time.time()

	def base_url(self, path):
		return f'https://api.mdblist.com/{path}'

	def poll_auth(self, data):
		response = requests.post(self.base_url('oauth/token/'), data=data, timeout=timeout)
		if not response.ok: return
		data.update(response.json())
		self.token = data['access_token']

	@watch_indicators
	def set(self):
		if self.token:
			if not yesnoDialog(): return
			setSetting('mdblist_user', '')
			set_setting('mdblist_user', '')
			set_setting('mdblist.token', '')
			set_setting('mdblist.refresh', '')
			set_setting('mdblist.expires', '')
			set_setting('mdbl_indicators_active', 'false')
			setSetting('watched_indicators', '0')
			sleep(500)
			# clear_cache('mdblist', silent=True)
			return notification(f'Removed {self.__class__.__name__} Authorization')

		data = {'client_id': self.client_id, 'scope': 'write'}
		response = requests.post(self.base_url('oauth/device-authorization/'), data=data, timeout=timeout)
		result = response.json()
		data = {'device_code': result['device_code'], 'client_id': self.client_id, 'grant_type': self.grant_type}
		expires_in, expires_at = result['expires_in'], result['expires_in'] + time.monotonic()
		try: qr_icon = qr_str % '&data=%s' % quote(result['verification_uri'])
		except: qr_icon = ''
		meta = {**dict.fromkeys(meta_keys.split(), ''), 'poster': qr_icon}
		detail = code_str % result['user_code'], nav2_str % result['verification_uri']
		progress_dialog = _make_progress_dialog(meta=meta)
		timer = RepeatTimer(result['interval'], self.poll_auth, args=(data,))
		timer.start()
		for i in range(1, expires_in + 1):
			if self.token or progress_dialog.iscanceled(): break
			lines = await_str % divmod(expires_at - time.monotonic(), 60), *detail
			progress = 100 - int(100 * i / expires_in)
			progress_dialog.update('[CR]'.join(lines), progress)
			sleep(1000)
		timer.cancel()
		progress_dialog.close()
		if progress_dialog.iscanceled(): return False
		if not self.token: return kodi_utils.notify_error()
		headers = {'Authorization': 'Bearer %s' % self.token}
		response = requests.get(self.base_url('user'), headers=headers, timeout=timeout)
		result = response.json()
		user_id, username = result['user_id'], result['username']
		expires = int(self.created_at) + int(data['expires_in'])
		refresh, token = data['refresh_token'], data['access_token']
		setSetting('mdblist_user', str(username))
		#setSetting('mdblist_api', api_key)
		set_setting('mdblist.token', token)
		set_setting('mdblist.refresh', refresh)
		set_setting('mdblist.expires', str(expires))
		setSetting('mdbl_indicators_active', 'true')
		setSetting('watched_indicators', '2')
		notification(f'Set {self.__class__.__name__} Authorization')
		sleep(500)
		# clear_cache('mdblist', silent=True)
		return True

class TMDbList:
	icon = 'VYCWHvl'
	def __init__(self):
		self.read = setting('tmdb.tmdb_read_token')
		self.token = setting('tmdb.token')
		self.session_id = get_setting('tmdb.session_id')
		self.headers = {'Authorization': f'Bearer {self.read}'}

	def base_url(self, path):
		return f'https://api.themoviedb.org/{path}'

	def poll_auth(self, data):
		response = requests.post(self.base_url('4/auth/access_token'), json=data, headers=self.headers, timeout=timeout)
		if not response.ok: return
		data.update(response.json())
		self.token = data['access_token']

	def set(self):
		if self.token:
			if not yesnoDialog(): return
			data = {'access_token': self.token}
			response = requests.delete(self.base_url('4/auth/access_token'), json=data, headers=self.headers, timeout=timeout)
			result = response.json()
			if not result['success']: return notification(f'Error: {self.__class__.__name__}.set()')
			setSetting('tmdb.account_id', '')
			setSetting('tmdb.token', '')
			# clear_cache('tmdblist', silent=True)
			session_id = setting('tmdb.session_id')
			data = {'session_id': session_id}
			response = requests.delete(self.base_url('3/authentication/session'), json=data, headers=self.headers, timeout=timeout)
			result = response.json()
			if not result['success']: return
			setSetting('tmdb.session_account_id', '')
			setSetting('tmdb.session_id', '')
			setSetting('tmdb.user', '')
			return notification(f'Removed {self.__class__.__name__} Authorization')

		response = requests.post(self.base_url('4/auth/request_token'), headers=self.headers, timeout=timeout)
		result = response.json()
		if not result['success']: return
		data = {'request_token': result['request_token']}
		expires_in, expires_at = 600, 600 + time.monotonic()
		url = f'https://www.themoviedb.org/auth/access?request_token={result["request_token"]}'
		tiny_url = 'http://tinyurl.com/api-create.php'
		try: tiny_url = requests.get(tiny_url, params={'url': url}, timeout=timeout).text
		except: tiny_url = url
		qr_icon = qr_str % '&data=%s' % quote(tiny_url)
		log(f'tmdblist: {tiny_url}\n{url}')
		meta = {**dict.fromkeys(meta_keys.split(), ''), 'poster': qr_icon}
		detail = nav2_str % tiny_url, ''
		progress_dialog = _make_progress_dialog(meta=meta)
		timer = RepeatTimer(5, self.poll_auth, args=(data,))
		timer.start()
		for i in range(1, expires_in + 1):
			if self.token or progress_dialog.iscanceled(): break
			lines = await_str % divmod(expires_at - time.monotonic(), 60), *detail
			progress = 100 - int(100 * i / expires_in)
			progress_dialog.update('[CR]'.join(lines), progress)
			sleep(1000)
		timer.cancel()
		progress_dialog.close()
		if progress_dialog.iscanceled(): return False
		if not self.token: return notification(f'Error: {self.__class__.__name__}.set()')
		account_id, access_token = str(data['account_id']), str(data['access_token'])
		setSetting('tmdb.account_id', account_id)
		setSetting('tmdb.token', access_token)
		notification(f'Set {self.__class__.__name__} Authorization')
		sleep(500)
		if not self.token and not setting('tmdb.token'): return
		access_token = self.token or setting('tmdb.token')
		data = {'access_token': access_token}
		response = requests.post(self.base_url('3/authentication/session/convert/4'), json=data, headers=self.headers, timeout=timeout)
		result = response.json()
		if not result['success']: return
		session_id = result['session_id']
		params = {'session_id': session_id}
		response = requests.get(self.base_url('3/account'), params=params, headers=self.headers, timeout=timeout)
		result = response.json()
		if 'id' not in result: return
		username, session_account_id = str(result['username']), str(result['id'])
		setSetting('tmdb.user', username)
		setSetting('tmdb.session_id', session_id)
		setSetting('tmdb.session_account_id', session_account_id)
		return True

