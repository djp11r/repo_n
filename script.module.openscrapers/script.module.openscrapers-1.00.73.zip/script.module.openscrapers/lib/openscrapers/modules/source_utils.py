# -*- coding: utf-8 -*-
"""
"""

import re
from string import printable
from traceback import print_exc, print_stack
from difflib import SequenceMatcher

try:
    from openscrapers import quote_plus, urlparse, unquote_plus, unquote
    from openscrapers.modules.log_utils import log, error
    from openscrapers.modules.control import setting as getSetting
    from openscrapers.modules.py_tools import ensure_str, ensure_text
    from openscrapers.modules.cleantitle import get
    from openscrapers.modules import client
    from openscrapers.modules.client_utils import replaceHTMLCodes
except:
    testing=True
    Setting = {'host.limit': 'true', 'host.count': 3}
    getSetting = Setting.get

host_limit = 'true'

RES_4K = ('.4k', 'hd4k', '4khd', '.uhd', 'ultrahd', 'ultra.hd', 'hd2160', '2160hd', '2160', '2160p', '216o', '216op')
RES_1080 = ('1080', '1080p', '1080i', 'hd1080', '1080hd', 'hd1080p', 'm1080p', 'fullhd', 'full.hd', '1o8o', '1o8op', '108o', '108op', '1o80', '1o80p')
RES_720 = ('720', '720p', '720i', 'hd720', '720hd', 'hd720p', '72o', '72op')
RES_SD = ('576p', '576i', 'sd576', '576sd', '480p', '480i', 'sd480', '480sd', '360p', '360i', 'sd360', '360sd', '240p', '240i', 'sd240', '240sd', 'sd')
RES_SCR = ('dvdscr', 'screener', 'scr')
RES_CAM = ('camrip', 'cam rip', 'tsrip', 'ts rip', 'hdcam', 'hd cam', 'hdts', 'hd ts', 'dvdcam', 'dvd cam', 'dvdts', 'dvd ts', 'cam', 'telesync', 'tele sync', 'ts')
VIDEO_3D = ('.3d.', '.sbs.', '.hsbs', 'sidebyside', 'side.by.side', 'stereoscopic', '.tab.', '.htab.', 'topandbottom', 'top.and.bottom')
DOLBY_VISION = ('dolby.vision', 'dolbyvision', '.dovi.', '.dv.')
HDR = ('2160p.bluray.hevc.truehd', '2160p.bluray.hevc.dts', '2160p.bluray.hevc.lpcm', '2160p.blu.ray.hevc.truehd', '2160p.blu.ray.hevc.dts', '2160p.uhd.bluray',
        '2160p.uhd.blu.ray', '2160p.us.bluray.hevc.truehd', '2160p.us.bluray.hevc.dts', '.hdr.', 'hdr10', 'hdr.10', 'uhd.bluray.2160p', 'uhd.blu.ray.2160p')
HDR_TRUE = ('.hdr.', '.hdr10.', 'hdr.10')
ENHANCED_UPSCALED = ('.enhanced.', '.upscaled.', '.enhance.', '.upscale.')
CODEC_H264 = ('avc', 'h264', 'h.264', 'x264', 'x.264')
CODEC_H265 = ('h265', 'h.265', 'hevc', 'x265', 'x.265')
CODEC_XVID = ('xvid', '.x.vid')
CODEC_DIVX = ('divx', 'div2', 'div3', 'div4')
CODEC_MPEG = ('.mpg', '.mp2', '.mpeg', '.mpe', '.mpv', '.mp4', '.m4p', '.m4v', 'msmpeg', 'mpegurl')
CODEC_MP4 = ('mp4')
CODEC_M3U = ('m3u8', 'm3u')
CODEC_AVI = ('avi')
CODEC_MKV = ('mkv', 'matroska')
REMUX = ('remux', 'bdremux')
BLURAY = ('bluray', 'blu.ray', 'bdrip', 'bd.rip', '.brrip.', 'br.rip')
DVD = ('dvdrip', 'dvd.rip')
WEB = ('.web.', 'webdl', 'web.dl', 'web-dl', 'webrip', 'web.rip')
HDRIP = ('.hdrip', '.hd.rip')
DOLBY_TRUEHD = ('true.hd', 'truehd')
DOLBY_DIGITALPLUS = ('dolby.digital.plus', 'dolbydigital.plus', 'dolbydigitalplus', 'dd.plus.', 'ddplus', '.ddp.', 'ddp2', 'ddp5', 'ddp7', 'eac3', '.e.ac3')
DOLBY_DIGITALEX = ('.dd.ex.', 'ddex', 'dolby.ex.', 'dolby.digital.ex.', 'dolbydigital.ex.')
DOLBYDIGITAL = ('dd2.', 'dd5', 'dd7', 'dolbyd.', 'dolby.digital', 'dolbydigital', '.ac3', '.ac.3.', '.dd.')
DTSX = ('dts.x.', 'dtsx')
DTS_HDMA = ('hd.ma', 'hdma')
DTS_HD = ('dts.hd.', 'dtshd')
AUDIO_8CH = ('ch8', '8ch', 'ch7', '7ch', '7 1', 'ch7 1', '7 1ch')
AUDIO_7CH = ('ch7.', '7ch.', '6.1ch', '6.1.')
AUDIO_6CH = ('ch6', '6ch', 'ch6', '6ch', '6 1', 'ch6 1', '6 1ch', '5 1', 'ch5 1', '5 1ch')
AUDIO_2CH = ('ch2', '2ch', 'stereo', 'dualaudio', 'dual', '2 0', 'ch2 0', '2 0ch')
AUDIO_1CH = ('ch1', '1ch', 'mono', 'monoaudio', 'ch1 0', '1 0ch')
SUBS = ('subita', 'subfrench', 'subspanish', 'subtitula', 'swesub', 'nl.subs', 'subbed')
ADS = ('1xbet', 'betwin')
MULTI_LANG = ('hindi.eng', 'ara.eng', 'ces.eng', 'chi.eng', 'cze.eng', 'dan.eng', 'dut.eng', 'ell.eng', 'esl.eng', 'esp.eng', 'fin.eng', 'fra.eng', 'fre.eng',
'frn.eng', 'gai.eng', 'ger.eng', 'gle.eng', 'gre.eng', 'gtm.eng', 'heb.eng', 'hin.eng', 'hun.eng', 'ind.eng', 'iri.eng', 'ita.eng', 'jap.eng', 'jpn.eng',
'kor.eng', 'lat.eng', 'lebb.eng', 'lit.eng', 'nor.eng', 'pol.eng', 'por.eng', 'rus.eng', 'som.eng', 'spa.eng', 'sve.eng', 'swe.eng', 'tha.eng', 'tur.eng',
'uae.eng', 'ukr.eng', 'vie.eng', 'zho.eng', 'dual.audio', 'multi')
EXTRAS = ('sample', 'extra', 'extras', 'deleted', 'unused', 'footage', 'inside', 'blooper', 'bloopers', 'making.of', 'feature', 'featurette', 'behind.the.scenes', 'trailer')
LANG = ('hindi', 'arabic', 'bengali', 'bgaudio', 'castellano', 'chinese', 'dutch', 'finnish', 'french', 'german', 'greek', 'indonesian', 'hebrew', 'italian', 'korean', 'latino', 'polish',
                'portuguese', 'russian', 'swedish', 'spanish', 'tamil', 'telugu', 'truefrench', 'truespanish', 'turkish')
ABV_LANG = ('.ara.', '.ces.', '.chi.', '.chs.', '.cze.', '.dan.', '.de.', '.deu.', '.dut.', '.ell.', '.es.', '.esl.', '.esp.', '.fi.', '.fin.', '.fr.', '.fra.', '.fre.', '.frn.', '.gai.', '.ger.', '.gle.', '.gre.',
                        '.gtm.', '.he.', '.heb.', '.hi.', '.hin.', '.hun.', '.hindi.', '.ind.', '.iri.', '.it.', '.ita.', '.ja.', '.jap.', '.jpn.', '.ko.', '.kor.', '.lat.', '.nl.', '.lit.', '.nld.', '.nor.', '.pl.', '.pol.',
                        '.pt.', '.por.', '.ru.', '.rus.', '.som.', '.spa.', '.sv.', '.sve.', '.swe.', '.tha.', '.tr.', '.tur.', '.uae.', '.uk.', '.ukr.', '.vi.', '.vie.', '.zh.', '.zho.')
DUBBED = ('bengali.dub', 'dublado', 'dubbed', 'pldub')
SUBS = ('subita', 'subfrench', 'subspanish', 'subtitula', 'swesub', 'nl.subs')

ENG_CHECK = ('.eng.', '.en.', 'english', 'multi')
SRT_CHECK = ('with.srt', '.avi', '.mkv', '.mp4')

UNDESIRABLES = ['uptobox', '400p.octopus', '720p.octopus', '1080p.octopus', 'alexfilm', 'amedia', 'audiobook', 'baibako', 'bigsinema', 'bonus.disc', 'casstudio.tv', 'courage.bambey',
                '.cbr', '.cbz', 'coldfilm', 'dilnix', 'dutchreleaseteam', 'e.book.collection', 'empire.minutemen', 'eniahd', '.exe', 'exkinoray', 'extras.only',
                'gears.media', 'gearsmedia', 'good.people', 'gostfilm', 'hamsterstudio', 'hdrezka', 'hdtvrip', 'hurtom', 'idea.film', 'ideafilm', 'jaskier', 'kapatejl6', 'kb.1080p',
                'kb.720p', 'kb.400p', 'kerob', 'kinokopilka', 'kravec', 'kuraj.bambey', 'lakefilm', 'lostfilm', 'megapeer', 'minutemen.empire', 'newstudio',
                'omskbird', '.ost.', 'paravozik', 'profix.media', 'rifftrax', 'sample', 'soundtrack', 'subtitle.only', 'sunshinestudio', 'teaser', 'trailer', 'tumbler.studio',
                'tvshows', 'ultradox', 'viruseproject', 'vostfr', 'vo.stfr', 'web.dlrip', 'webdlrip', 'wish666', 'pa.web.dl', '.p.web.dl', '.d.web.dl', '.dt.web.dl']
# viruseproject has lots of uploads on glotorrents and site fixes the "&dn=???" portion in html title to reflect the true range the pack covers vs. assclowns incomplete pack file name used

season_list = ('one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eigh', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen',
            'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen', 'twenty', 'twenty-one', 'twenty-two', 'twenty-three',
            'twenty-four', 'twenty-five')
season_ordinal_list = ('first', 'second', 'third', 'fourth', 'fifth', 'sixth', 'seventh', 'eighth', 'ninth', 'tenth', 'eleventh', 'twelfth',
            'thirteenth', 'fourteenth', 'fifteenth', 'sixteenth', 'seventeenth', 'eighteenth', 'nineteenth', 'twentieth', 'twenty-first',
            'twenty-second', 'twenty-third', 'twenty-fourth', 'twenty-fifth')
season_ordinal2_list = ('1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th', '9th', '10th', '11th', '12th', '13th', '14th', '15th', '16th',
            '17th', '18th', '19th', '20th', '21st', '22nd', '23rd', '24th', '25th')

season_dict = {'1': 'one', '2': 'two', '3': 'three', '4': 'four', '5': 'five', '6': 'six', '7': 'seven', '8': 'eigh', '9': 'nine', '10': 'ten',
            '11': 'eleven', '12': 'twelve', '13': 'thirteen', '14': 'fourteen', '15': 'fifteen', '16': 'sixteen', '17': 'seventeen',
            '18': 'eighteen', '19': 'nineteen', '20': 'twenty', '21': 'twenty-one', '22': 'twenty-two', '23': 'twenty-three',
            '24': 'twenty-four', '25': 'twenty-five'}
season_ordinal_dict = {'1': 'first', '2': 'second', '3': 'third', '4': 'fourth', '5': 'fifth', '6': 'sixth', '7': 'seventh', '8': 'eighth', '9': 'ninth',
            '10': 'tenth', '11': 'eleventh', '12': 'twelfth', '13': 'thirteenth', '14': 'fourteenth', '15': 'fifteenth', '16': 'sixteenth',
            '17': 'seventeenth', '18': 'eighteenth', '19': 'nineteenth', '20': 'twentieth', '21': 'twenty-first', '22': 'twenty-second',
            '23': 'twenty-third', '24': 'twenty-fourth', '25': 'twenty-fifth'}
season_ordinal2_dict = {'1': '1st', '2': '2nd', '3': '3rd', '4': '4th', '5': '5th', '6': '6th', '7': '7th', '8': '8th', '9': '9th', '10': '10th',
            '11': '11th', '12': '12th', '13': '13th', '14': '14th', '15': '15th', '16': '16th', '17': '17th', '18': '18th', '19': '19th',
            '20': '20th', '21': '21st', '22': '22nd', '23': '23rd', '24': '24th', '25': '25th'}

unwanted_tags = ('tamilrockers.com', 'www.tamilrockers.com', 'www.tamilrockers.ws', 'www.tamilrockers.pl',
            'www-tamilrockers-cl', 'www.tamilrockers.cl', 'www.tamilrockers.li', 'www-tamilrockers-tw',
            'www.tamilrockerrs.pl',
            'www.tamilmv.bid', 'www.tamilmv.biz', 'www.1tamilmv.org',
            'gktorrent-bz', 'gktorrent-com',
            'www.torrenting.com', 'www.torrenting.org', 'www-torrenting-com', 'www-torrenting-org',
            'katmoviehd.pw', 'katmoviehd-pw',
            'www.torrent9.nz', 'www-torrent9-uno', 'torrent9-cz', 'torrent9.cz', 'torrent9-red', 'torrent9-bz',
            'agusiq-torrents-pl',
            'oxtorrent-bz', 'oxtorrent-com', 'oxtorrent.com', 'oxtorrent-sh', 'oxtorrent-vc',
            'www.movcr.tv', 'movcr-com', 'www.movcr.to',
            '(imax)', 'imax',
            'xtorrenty.org', 'nastoletni.wilkoak', 'www.scenetime.com', 'kst-vn',
            'www.movierulz.vc', 'www-movierulz-ht', 'www.2movierulz.ac', 'www.2movierulz.ms',
            'www.3movierulz.com', 'www.3movierulz.tv', 'www.3movierulz.ws', 'www.3movierulz.ms',
            'www.7movierulz.pw', 'www.8movierulz.ws',
            'mkvcinemas.live', 'torrentcounter-to',
            'www.bludv.tv', 'ramin.djawadi', 'extramovies.casa', 'extramovies.wiki',
            '13+', '18+', 'taht.oyunlar', 'crazy4tv.com', 'karibu', '989pa.com',
            'best-torrents-net', '1-3-3-8.com', 'ssrmovies.club',
            'va:', 'zgxybbs-fdns-uk', 'www.tamilblasters.mx',
            'www.1tamilmv.work', 'www.xbay.me',
            'crazy4tv-com', '(es)')


host_limit = getSetting('host.limit') or 'true'
host_limit_count = getSetting('host.count') or '3'

def check_host_limit(item, items): # lazy way to use less code and limit the sources a bit. could likely be coded better but oh well.
    try:
        if host_limit == 'true':
            items = [i['source'] for i in items if 'source' in i] or [i for i in items]
            if items.count(item) == host_limit_count:
                return True
            else:
                return False
        else:
            return False
    except:
        return False

def aliases_to_array(aliases, filter=None):
    try:
        if all(isinstance(x, str) for x in aliases): return aliases
        if not filter: filter = []
        if isinstance(filter, str): filter = [filter]
        return [x.get('title') for x in aliases if not filter or x.get('country') in filter]
    except:
        error()
        return []

def get_codec(txt):
    if any(value in txt for value in CODEC_H265):
        _codec = "HEVC | "
    elif any(value in txt for value in CODEC_H264):
        _codec = "AVC | "
    elif any(value in txt for value in CODEC_MKV):
        _codec = "MKV | "
    elif any(value in txt for value in CODEC_DIVX):
        _codec = "DIVX | "
    elif any(value in txt for value in CODEC_MPEG):
        _codec = "MPEG | "
    elif any(value in txt for value in CODEC_MP4):
        _codec = "MP4 | "
    elif any(value in txt for value in CODEC_M3U):
        _codec = "M3U | "
    elif any(value in txt for value in CODEC_XVID):
        _codec = "XVID | "
    elif any(value in txt for value in CODEC_AVI):
        _codec = "AVI | "
    else:
        _codec = '0'
    return _codec


def get_audio(txt):
    if any(value in txt for value in AUDIO_8CH):
        _audio = "7.1 | "
    elif any(value in txt for value in AUDIO_6CH):
        _audio = "5.1 | "
    elif any(value in txt for value in AUDIO_2CH):
        _audio = "2.0 | "
    elif any(value in txt for value in AUDIO_1CH):
        _audio = "Mono | "
    else:
        _audio = '0'
    return _audio


def get_size(txt):
    try:
        _size = re.findall(r'(\d+(?:\.|/,|)?\d+(?:\s+|)(?:gb|GiB|mb|MiB|GB|MB))', txt)
        _size = _size[0].encode('utf-8')
        _size = _size + " | "
    except:
        _size = '0'
    return _size


def get_3D(txt):
    if any(value in txt for value in VIDEO_3D):
        _3D = "3D | "
    else:
        _3D = '0'
    return _3D


def get_quality(txt1, txt2=None):
    if not txt2:
        txt = txt1
    else:
        txt = txt1
        txt += txt2
    if any(value in txt for value in RES_4K):
        _quality = "4K"
    elif any(value in txt for value in RES_1080):
        _quality = "1080p"
    elif any(value in txt for value in RES_720):
        _quality = "720p"
    elif any(value in txt for value in RES_SD):
        _quality = "SD"
    elif any(value in txt for value in RES_SCR):
        _quality = "SCR"
    elif any(value in txt for value in RES_CAM):
        _quality = "CAM"
    else:
        _quality = "SD"
    return _quality


def get_info(txt1, txt2=None):
    if not txt2:
        txt = txt1
    else:
        txt = txt1
        txt += txt2
    _codec = get_codec(txt)
    if not _codec or _codec == '0':
        _codec = ''
    _audio = get_audio(txt)
    if not _audio or _audio == '0':
        _audio = ''
    _size = get_size(txt)
    if not _size or _size == '0':
        _size = ''
    _3D = get_3D(txt)
    if not _3D or _3D == '0':
        _3D = ''
    _info = _codec + _audio + _size + _3D
    return _info


def cleanup(txt):
    try:
        _txt = strip_domain(txt)
        _txt = unquote(_txt)
        _txt = _txt.lower()
        _txt = re.sub(r'[^a-z0-9 ]+', ' ', _txt)
    except:
        _txt = str(txt.lower())
    return _txt


def cleanupALT(txt):
    try:
        _txt = strip_domain(txt)
        _txt = _txt.upper()
        _txt = re.sub(r'(.+)(\.|\(|\[|\s)(\d{4}|S\d*E\d*|S\d*)(\.|\)|\]|\s)', '', _txt)
        _txt = re.split(r'\.|\(|\)|\[|\]|\s|-', _txt)
        _txt = [i.lower() for i in _txt]
    except:
        _txt = str(txt.lower())
    return _txt


def get_release_quality(release_name, release_link=None):
    try:
        if not release_name:
            return 'SD', []
        try:
            release_name = cleanup(release_name)
            if release_link:
                release_link = cleanup(release_link)
        except:
            release_name = cleanupALT(release_name)
            if release_link:
                release_link = cleanupALT(release_link)
        if release_link and release_link == release_name:
            release_link = None
        quality = get_quality(release_name, release_link)
        info = get_info(release_name, release_link)
        return quality, info
    except:
        return 'SD', []


def url_strip(url):
    try:
        url = unquote_plus(url)
        if 'magnet:' in url: url = url.split('&dn=')[1]
        url = url.lower().replace("'", "").lstrip('.').rstrip('.')
        fmt = re.sub(r'[^a-z0-9]+', '.', url)
        fmt = f'.{fmt}.'
        fmt = re.sub(r'(.+)((?:19|20)[0-9]{2}|season.\d+|s[0-3]{1}[0-9]{1}|e\d+|complete)(.complete\.|.episode\.\d+\.|.episodes\.\d+\.\d+\.|.series|.extras|.ep\.\d+\.|.\d{1,2}\.|-|\.|\s)', '', fmt) # new for pack files
        if '.http' in fmt: fmt = None
        return None if fmt == '' else f'.{fmt}'
    except:
        error()
        return None


def check_url(url):
    try:
        url = url.lower()
        try: url = url.encode('utf-8')
        except: pass
        return get_qual(url) or 'SD'
    except:
        error()
        return 'SD'


def get_qual(term):
    if any(i in term for i in RES_SCR): return '720p'
    elif any(i in term for i in RES_CAM): return 'SD'
    elif any(i in term for i in RES_720): return '720p'
    elif any(i in term for i in RES_1080): return '1080p'
    elif any(i in term for i in RES_4K): return '4K'
    elif '.hd.' in term: return '720p'
    else: return 'SD'

def info_from_name(release_title, title, year, hdlr=None, episode_title=None, season=None, pack=None):
    try:
        release_title = release_title.lower().replace('&', 'and').replace("'", "")
        release_title = re.sub(r'[^a-z0-9]+', '.', release_title)
        title = title.lower().replace('&', 'and').replace("'", "")
        title = re.sub(r'[^a-z0-9]+', '.', title)
        name_info = release_title.replace(title, '').replace(year, '')
        if hdlr: name_info = name_info.replace(hdlr.lower(), '')
        if episode_title:
            episode_title = episode_title.lower().replace('&', 'and').replace("'", "")
            episode_title = re.sub(r'[^a-z0-9]+', '.', episode_title)
            name_info = name_info.replace(episode_title, '')
        if pack:
            if pack == 'season':
                season_fill = season.zfill(2)
                str1_replace = ('.s%s' % season, '.s%s' % season_fill, '.season.%s' % season, '.season%s' % season, '.season.%s' % season_fill, '.season%s' % season_fill, 'complete')
                for i in str1_replace: name_info = name_info.replace(i, '')
            elif pack == 'show':
                str2_replace = ('.all.seasons', 'seasons', 'season', 'the.complete', 'complete', 'all.torrent', 'total.series', 'tv.series', 'series', 'edited', 's1', 's01')
                for i in str2_replace: name_info = name_info.replace(i, '')
        name_info = name_info.lstrip('.').rstrip('.')
        name_info = '.%s.' % name_info
        return name_info
    except:
        error()
        return release_title


def get_query(data, title, full_name=None):
    if not full_name:
        hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']
        query = f'{title} {hdlr}'
    else:
        hdlr = (
            f"S{int(data['season'])}E{int(data['episode'])}"
            if 'tvshowtitle' in data
            else ''
        )
        query = f'{title} {hdlr}' if hdlr != '' else f'{title}'
    query = quote_plus(re.sub(r'[^A-Za-z0-9\s\.-]+', '', query))
    return query, hdlr


def check_title(title, aliases, release_title, hdlr, year, years=None): # non pack file title check, single eps and movies
    if years: # for movies only, scraper to pass None for episodes
        if all(value not in release_title for value in years): return False
    elif not re.search(fr'{hdlr}', release_title, re.I): return False
    aliases = aliases_to_array(aliases)
    title_list = []
    title_list_append = title_list.append
    if aliases:
        for item in aliases:
            try:
                alias = item.replace('&', 'and').replace(year, '')
                if years: # for movies only, scraper to pass None for episodes
                    for i in years: alias = alias.replace(i, '')
                if alias in title_list: continue
                title_list_append(alias)
            except:
                error()
    try:
        title = title.replace('&', 'and').replace(year, '') # year only in meta title if an addon custom query added it
        if title not in title_list: title_list_append(title)

        release_title = re.sub(r'([(])(?=((19|20)[0-9]{2})).*?([)])', '\\2', release_title) #remove parenthesis only if surrounding a 4 digit date
        t = re.split(f'{hdlr}', release_title, 1, re.I)[0].replace(year, '').replace('&', 'and')
        if years:
            for i in years: t = t.split(i)[0]
        t = re.split(r'2160p|216op|4k|1080p|1o8op|108op|1o80p|720p|72op|480p|48op', t, 1, re.I)[0]
        cleantitle_t = get(t)
        if all(get(i) != cleantitle_t for i in title_list): return False

# filter to remove episode ranges that should be picked up in "filter_season_pack()" ex. "s01e01-08"
        if hdlr != year: # equal for movies but not for shows
            range_regex = (
                    r's\d{1,3}e\d{1,3}[-.]e\d{1,3}',
                    r's\d{1,3}e\d{1,3}[-.]\d{1,3}(?!p|bit|gb)(?!\d{1,3})',
                    r's\d{1,3}[-.]e\d{1,3}[-.]e\d{1,3}',
                    r'season[.-]?\d{1,3}[.-]?ep[.-]?\d{1,3}[-.]ep[.-]?\d{1,3}',
                    r'season[.-]?\d{1,3}[.-]?episode[.-]?\d{1,3}[-.]episode[.-]?\d{1,3}') # may need to add "to", "thru"
            for regex in range_regex:
                if bool(re.search(regex, release_title, re.I)): return False
        return True
    except:
        error()
        return False


def normalize(title):
    import unicodedata
    try:
        title = ''.join(c for c in unicodedata.normalize('NFKD', title) if unicodedata.category(c) != 'Mn')
        return title.strip()
    except: return title


def get_undesirables():
    try:
        if getSetting('filter.undesirables') != 'true': return []
    except: return []
    from openscrapers.modules.undesirables import Undesirables
    try: undesirables = Undesirables().get_enabled()
    except: undesirables = UNDESIRABLES
    return undesirables


def check_foreign_audio():
    try: return getSetting('filter.foreign.single.audio') == 'true'
    except: return 'false'


def copy2clip(txt):
    from sys import platform as sys_platform
    platform = sys_platform
    if platform == "win32":
        try:
            from subprocess import check_call
            # cmd = "echo " + txt.strip() + "|clip"
            cmd = "echo " + txt.replace('&', '^&').strip() + "|clip" # "&" is a command seperator
            return check_call(cmd, shell=True)
        except:
            error('Windows: Failure to copy to clipboard')
    elif platform == "darwin":
        try:
            from subprocess import check_call
            cmd = f'echo {txt.strip()}|pbcopy'
            return check_call(cmd, shell=True)
        except:
            error('Mac: Failure to copy to clipboard')
    elif platform == "linux":
        try:
            from subprocess import Popen, PIPE
            p = Popen(["xsel", "-pi"], stdin=PIPE)
            p.communicate(input=txt)
        except:
            error('Linux: Failure to copy to clipboard')


def is_match(name, title, hdlr=None, aliases=None):
    try:
        name = name.lower()
        t = re.sub(r'(\+|\.|\(|\[|\s)(\d{4}|s\d+e\d+|s\d+|3d)(\.|\)|\]|\s|)(.+|)', '', name)
        t = get(t)
        titles = [get(title)]

        if aliases:
            if not isinstance(aliases, list):
                from ast import literal_eval
                aliases = literal_eval(aliases)
            try: titles.extend([get(i['title']) for i in aliases])
            except: pass

        return t in titles and hdlr.lower() in name if hdlr else t in titles
    except:
        error('is_match exc: ')
        return True


def remove_lang(release_info, check_foreign_audio):
    if not release_info: return False
    try:
        if any(value in release_info for value in DUBBED): return True
        if any(value in release_info for value in SUBS): return True
        if check_foreign_audio:
            if any(value in release_info for value in LANG) and all(value not in release_info for value in ENG_CHECK): return True
            if any(value in release_info for value in ABV_LANG) and all(value not in release_info for value in ENG_CHECK): return True
        return bool(release_info.endswith('.srt.') and all(value not in release_info for value in SRT_CHECK))
    except:
        # error()
        return False


def remove_undesirables(release_info, undesirables):
    if any(value in release_info for value in undesirables): return True


def release_title_format(release_title):
    try:
        release_title = release_title.lower().replace("'", "").lstrip('.').rstrip('.')
        fmt = '.%s.' % re.sub(r'[^a-z0-9-~]+', '.', release_title).replace('.-.', '-').replace('-.', '-').replace('.-', '-').replace('--', '-')
        return fmt
    except:
        error()
        return release_title

UNWANTED_REGEX_CACHE = {}
RE_BRACKETS_JP = re.compile(r'【.*?】', re.I)
RE_BRACKETS_SQ = re.compile(r'^\[.*?]', re.I)

def clean_name(release_title):
    try:
        release_title = RE_BRACKETS_JP.sub('', release_title)
        release_title = strip_non_ascii_and_unprintable(release_title).lstrip('+.-:/ ').replace(' ', '.')
        releasetitle_startswith = release_title.lower().startswith
        if releasetitle_startswith('rifftrax'): return release_title # removed by "undesirables" anyway so exit
        for i in unwanted_tags:
            if releasetitle_startswith(i):
                #release_title = re.sub(r'^%s' % i.replace('+', '\+'), '', release_title, 1, re.I)
                release_title = re.sub(r'^%s' % re.escape(i), '', release_title, 1, re.I)
        release_title = release_title.lstrip('+.-:/ ')
        release_title = RE_BRACKETS_SQ.sub('', release_title, 1).lstrip('.-[](){}:/')
        return release_title
    except:
        error()
        return release_title

def strip_non_ascii_and_unprintable(text):
    try:
        result = ''.join(char for char in text if char in printable)
        return result.encode('ascii', errors='ignore').decode('ascii', errors='ignore')
    except:
        error()
        return text

def _size(siz):
    try:
        if siz in ('0', 0, '', None): return 0, ''
        div = 1 if siz.lower().endswith(('gb', 'gib')) else 1024
        # if ',' in siz and siz.lower().endswith(('mb', 'mib')): siz = size.replace(',', '')
        # elif ',' in siz and siz.lower().endswith(('gb', 'gib')): siz = size.replace(',', '.')
        dec_count = len(re.findall(r'[.]', siz))
        if dec_count == 2: siz = siz.replace('.', ',', 1) # torrentproject2 likes to randomly use 2 decimals vs. a comma then a decimal
        float_size = round(float(re.sub(r'[^0-9|/.|/,]', '', siz.replace(',', ''))) / div, 2) #comma issue where 2,750 MB or 2,75 GB (sometimes replace with "." and sometimes not)
        str_size = '%.2f GB' % float_size
        return float_size, str_size
    except:
        error('failed on siz=%s' % siz)
        return 0, ''

POWERS = {
    'YB': 1208925819614629174706176,
    'ZB': 1180591620717411303424,
    'EB': 1152921504606846976,
    'TB': 1099511627776,
    'GB': 1073741824,
    'MB': 1048576,
    'KB': 1024,
    'B': 1
}

def convert_size(size_bytes, to='GB'):
    try:
        if size_bytes == 0: return 0, ''
        p = POWERS[to]
        float_size = round(size_bytes / p, 2)
        # if to == 'B' or to  == 'KB': return 0, ''
        str_size = '%s %s' % (float_size, to)
        return float_size, str_size
    except:
        error()
        return 0, ''

def base32_to_hex(hash, caller):
    from base64 import b32decode
    hex = b32decode(hash).hex()
    log(f'{caller}: base32 hash "{hash}"  converted to hex 40  "{hex}" ', __name__, 0)
    return hex

def scraper_error(provider, testing=False):
    import traceback
    failure = traceback.format_exc()
    msg = f'{provider.upper()} - Exception: \n{failure}'
    if testing: print(msg)
    else:
        log(msg, caller='scraper_error', level=1)


# removes multi epsiode ranges returned from single epsiode query (ex. S01E01-E17 is also returned in S01E01 query)
def filter_single_episodes(hdlr, release_title):
    try:
        fmt = release_title_format(release_title)
        se = hdlr.lower()
        for item in [(se + r'(?:\.|-)e\d{1,2}(?:$|\.|-)'), (se + r'(?:\.|-)s[0-3]{1}[0-9]{1}e\d{1,2}(?:$|\.|-)'), (se + r'-\d{2}(?:$|\.|-)')]:
            if bool(re.search(item, fmt)):
                return False
        return True
    except:
        error()
        return True

websites = set()
def check_dupes(url):
    parsed = urlparse(url)
    website = parsed.hostname + parsed.path
    if website in websites:
        return False
    websites.add(website)
    return True


def append_headers(headers):
    return f'|{"&".join([f"{key}={quote_plus(value)}" for key, value in iter(headers.items())])}'


def supported_video_extensions():
    return ['.m4v', '.3g2', '.3gp', '.nsv', '.tp', '.ts', '.ty', '.strm', '.pls', '.rm', '.rmvb', '.mpd', '.m3u', '.m3u8', '.mov', '.qt', '.divx', '.xvid', '.bivx', '.vob', '.iso', '.udf', '.pva', '.wmv', '.asf', '.m2v', '.avi', '.mpg', '.mpeg', '.mp4', '.mkv', '.mk3d', '.avc', '.vp3', '.svq3', '.nuv', '.viv', '.dv', '.fli', '.flv', '.001', '.wpl', '.xspf', '.vdr', '.dvr-ms', '.xsp', '.mts', '.m2t', '.m2ts', '.evo', '.ogv', '.sdp', '.avs', '.rec', '.url', '.pxml', '.vc1', '.h264', '.rcv', '.mpls', '.mpl', '.webm', '.bdmv', '.bdm', '.wtv', '.trp', '.f4v', '.pvr']


def get_supported_formats():
    return supported_video_extensions()


def strip_domain(url):
    try:
        if url.lower().startswith('http') or url.startswith('/'):
            url = re.findall(r'(?://.+?|)(/.+)', url)[0]
        url = replaceHTMLCodes(url)
        try: url = url.encode('utf-8')
        except: pass
        return url
    except:
        error()
        return url

def is_host_valid(url, domains):
    try:
        if not url: return False, ''
        if any(x in url.lower() for x in ('.rar.', '.zip.', '.part.', '.sample.')) or any(url.lower().endswith(x) for x in ('.bmp', '.gif', '.jpg', '.nfo', '.part', '.png', '.rar', '.sample.', '.srt', '.txt', '.zip')):
            return False, ''
        host = __top_domain(url)
        hosts = [domain.lower() for domain in domains if host and host in domain.lower()]
        if hosts and '.' not in host: host = hosts[0]
        if hosts and any(h for h in ('google', 'picasa', 'blogspot') if h in host): host = 'gvideo'
        if hosts and any(h for h in ('akamaized', 'ocloud') if h in host): host = 'CDN'
        return any(hosts), host
    except:
        error(f'is_host_valid Error host: {host} url: {url} domains: {domains}\n: {print_stack(limit=15)}')
        return False, host


def __top_domain(url):
    try:
        url = url.replace(r'\/', '/').replace('///', '//')
        if not (url.startswith('//') or url.startswith('http://') or url.startswith('https://')):
            url = f'//{url}'
        elements = urlparse(url)
        domain = elements.netloc or elements.path
        domain = domain.split('@')[-1].split(':')[0]
        regex = r"(?:www\.)?([\w\-]*\.[\w\-]{2,3}(?:\.[\w\-]{2,3})?)$"
        if res := re.search(regex, domain): domain = res[1]
        domain = domain.lower()
    except:
        error(f'__top_domain Error url: {url} : {print_exc()}')
        elements = urlparse(url)
        host = elements.netloc
        domain = host.replace('www.', '')
    return domain


def get_host(url):# same as __top_domain(url)
    try:
        url = url.replace(r'\/', '/').replace('///', '//')
        elements = urlparse(url)
        domain = elements.netloc or elements.path
        domain = domain.split('@')[-1].split(':')[0]
        if res := re.search(r"(?:www\.)?([\w\-]*\.[\w\-]{2,3}(?:\.[\w\-]{2,3})?)$", domain):
            domain = res[1]
        domain = domain.lower()
    except:
        elements = urlparse(url)
        host = elements.netloc
        domain = host.replace('www.', '')
    return domain


def checkHost(url, hostList):# same as is_host_valid(url, domains)
    host = get_host(url)
    validHost = False
    for i in hostList:
        if i.lower() in url.lower():
            host = i
            validHost = True
            return validHost, host
    return validHost, host


def single_checkPack(release_title, query):
    range_pattern = '%s%s' % (query.lower(), r'[-]\d{2}([-,.[({]|$)')
    if bool(re.search(range_pattern, release_title.lower())): return True
    else: return False


def release_title_strip(release_title):
    try:
        try: release_title = release_title.encode('utf-8')
        except: pass
        release_title = release_title.lower().replace("'", "").lstrip('.').rstrip('.')
        fmt = re.sub(r'[^a-z0-9]+', '.', release_title)
        fmt = f'.{fmt}.'
        fmt = re.sub(r'(.+)((?:19|20)[0-9]{2}|season.\d+|s[0-3]{1}[0-9]{1}|e\d+|complete)(.complete\.|.episode\.\d+\.|.episodes\.\d+\.\d+\.|.series|.extras|.ep\.\d+\.|.\d{1,2}\.|-|\.|\s)', '', fmt) # new for pack files

        # Fails for these cases
        # release_title = Game.of.Thrones.S01.1080p.BluRay.10bit.HEVC-MkvCage.Season.1.One (ENCODED)
        # fmt = .one.
        # .yelowstone.season.03.hamsterstudio.2019.
        # fmt = ''
        # may be best to pass "tvshowtitle" and "ep_title" and strip that off, as well as strip seaon/s01 type info off

        return None if fmt == '' else f'.{fmt}'
    except:
        error()
        return None


def check_directstreams(url, hoster='', quality='SD'):
    urls = []
    host = hoster
    from openscrapers.modules import directstream
    if 'google' in url or any(x in url for x in ['youtube.', 'docid=']):
        urls = directstream.google(url)
        if not urls:
            if tag := directstream.googletag(url):
                urls = [{'quality': tag[0]['quality'], 'url': url}]
        if urls: host = 'gvideo'
    elif 'ok.ru' in url:
        urls = directstream.odnoklassniki(url)
        if urls: host = 'vk'
    elif 'vk.com' in url:
        urls = directstream.vk(url)
        if urls: host = 'vk'
    elif any(x in url for x in ['akamaized', 'blogspot', 'ocloud.stream']):
        urls = [{'url': url}]
        if urls: host = 'CDN'
    direct = bool(urls)
    if not urls: urls = [{'quality': quality, 'url': url}]
    return urls, host, direct


def evp_decode(cipher_text, passphrase, salt=None):
    from base64 import b64decode
    from openscrapers.modules import pyaes
    cipher_text = ensure_text(b64decode(cipher_text))
    if not salt:
        salt = cipher_text[8:16]
        cipher_text = cipher_text[16:]
    data = evpKDF(passphrase, salt)
    decrypter = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(data['key'], data['iv']))
    plain_text = decrypter.feed(cipher_text)
    plain_text += decrypter.feed()
    return plain_text


def evpKDF(passwd, salt, key_size=8, iv_size=4, iterations=1, hash_algorithm="md5"):
    import hashlib
    target_key_size = key_size + iv_size
    derived_bytes = ""
    number_of_derived_words = 0
    block = None
    hasher = hashlib.new(hash_algorithm)
    while number_of_derived_words < target_key_size:
        if block is not None:
            hasher.update(block)
        hasher.update(passwd)
        hasher.update(salt)
        block = hasher.digest()
        hasher = hashlib.new(hash_algorithm)
        for _i in list(range(1, iterations)):
            hasher.update(block)
            block = hasher.digest()
            hasher = hashlib.new(hash_algorithm)
        derived_bytes += block[: min(len(block), (target_key_size - number_of_derived_words) * 4)]
        number_of_derived_words += len(block) / 4
    return {"key": derived_bytes[: key_size * 4], "iv": derived_bytes[key_size * 4:]}


def match_name_strlist(pFileName, result, season=None, episode=None):
    # pFileName = unquote(os.path.basename(vidPath))
    # pFileName = os.path.splitext(pFileName)[0]
    matches = []
    for j in result:
        if season:
            if seas_ep_filter(season, episode, j['fileName']):
                seq = SequenceMatcher(None, pFileName.lower(), j['fileName'].lower())
                matches.append({'fileName': j['fileName'], 'fileID': j['fileID'], 'ratio': seq.ratio()})
        else:
            seq = SequenceMatcher(None, pFileName.lower(), j['fileName'].lower())
            matches.append({'fileName': j['fileName'], 'fileID': j['fileID'], 'ratio': seq.ratio()})
    matches.sort(key=lambda i: i['ratio'], reverse=True)
    log(f'matches: {matches}')


def seas_ep_filter(season, episode, release_title, split=False):
    try:
        release_title = re.sub(r'[^A-Za-z0-9-]+', '.', unquote(release_title).replace('\'', '')).replace('&', 'and').replace('%', '.percent').lower()
        season = str(season)
        season_fill = season.zfill(2)
        episode = str(episode)
        episode_fill = episode.zfill(2)
        int_episode = int(episode)

        string1 = r'(s<<S>>[.-]?e[p]?[.-]?<<E>>[.-])'
        string2 = r'(season[.-]?<<S>>[.-]?episode[.-]?<<E>>[.-])|' \
                  r'([s]?<<S>>[x.]<<E>>[.-])'
        string3 = r'(s<<S>>e<<E1>>[.-]?e?<<E2>>[.-])'
        string4 = r'([.-]<<S>>[.-]?<<E>>[.-])'
        string5 = r'(episode[.-]?<<E>>[.-])'
        string6 = r'([.-]e[p]?[.-]?<<E>>[.-])'
        string7 = r'(^(?=.*[.-]e?0*<<E>>[.-])(?:(?!((?:s|season)[.-]?\d+[.-x]?(?:ep?|episode)[.-]?\d+)|\d+x\d+).)*$)'
        string_list = []
        append = string_list.append
        append(string1.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
        append(string1.replace('<<S>>', season).replace('<<E>>', episode_fill))
        append(string1.replace('<<S>>', season_fill).replace('<<E>>', episode))
        append(string1.replace('<<S>>', season).replace('<<E>>', episode))
        append(string2.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
        append(string2.replace('<<S>>', season).replace('<<E>>', episode_fill))
        append(string2.replace('<<S>>', season_fill).replace('<<E>>', episode))
        append(string2.replace('<<S>>', season).replace('<<E>>', episode))
        append(string3.replace('<<S>>', season_fill).replace('<<E1>>', str(int_episode - 1).zfill(2)).replace('<<E2>>', episode_fill))
        append(string3.replace('<<S>>', season_fill).replace('<<E1>>', episode_fill).replace('<<E2>>', str(int_episode + 1).zfill(2)))
        append(string4.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
        append(string4.replace('<<S>>', season).replace('<<E>>', episode_fill))
        append(string5.replace('<<E>>', episode_fill))
        append(string5.replace('<<E>>', episode))
        append(string6.replace('<<E>>', episode_fill))
        append(string7.replace('<<E>>', episode_fill))
        final_string = '|'.join(string_list)
        reg_pattern = re.compile(final_string)
        if split: return release_title.split(re.search(reg_pattern, release_title).group(), 1)[1]
        else: return bool(re.search(reg_pattern, release_title))
    except:
        error()
        return None