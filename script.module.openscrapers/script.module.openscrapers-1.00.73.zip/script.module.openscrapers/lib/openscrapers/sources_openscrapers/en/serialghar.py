# -*- coding: UTF-8 -*-

import re

from openscrapers.modules.client import agent, request
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.hindi_utils import get_query, get_source_dict, query_cleaner, resolve_gen
from openscrapers.modules.log_utils import error, log
from openscrapers.modules.control import setting
from openscrapers.modules.source_utils import get_host
from openscrapers import custom_base_link
custom_base = custom_base_link(__name__)


class source:

    def __init__(self):
        self.name = 'serialghar'
        self.base_link = custom_base or 'https://serialmaza.info'
        self.domains = list(get_host(self.base_link)) # ['serialmaza.info']
        self.search_link = '/?s='
        self.headers = {'User-Agent': agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f'From: {__name__}.tvshow\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year}')
        try:
            return f'{tvshowtitle}'
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f'From: {__name__}.episode url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}')
        try:
            # if type(tvdb) == int: return
            # if '|' not in tvdb: return
            if 'episode' in title.lower(): return
            query = get_query(url, season)
            # channel_name = self.get_channel_name(str(tvdb))
            # log(f'query {query} title: {title}')
            # if re.search(r'the-kapil-sharma-show', query, re.I): query = 'the-kapil-sharma-show'
            # elif re.search(r'indias-best-dancer', query, re.I): query = 'indias-best-dancer-3'
            if re.search(r'india-got-talent', query, re.I): query = 'indias-got-talent'
            # elif re.search(r'crime-patrol', query, re.I): query = 'crime-patrol-48-hours'
            # elif re.search(r'kaun-banega-crorepati', query, re.I): query = 'kaun-banega-crorepati-16'
            elif re.search(r'jhalak-dikhhla-jaa', query, re.I): query = 'jhalak-dikhhla-jaa'
            # else: query = f'{query}'
            # qepisode = title.replace('Episode ', '')
            query_title = query_cleaner(query)
            episode_title = query_cleaner(title)
            search_url = f'{self.base_link}{self.search_link}{url}'
            # log(f'tvdb: {tvdb} query: {query} search_url: {search_url}')
            result = request(search_url, headers=self.headers)
            results = parseDOM(result, 'article', attrs={'class': 'item-list'})
            # log(f'From: {__name__} total: {len(results)} result1 {results}')
            # results = parseDOM(result.text, 'div', attrs={'class': 'blog-posts posts-medium posts-container'})
            # log(f'From: {__name__} total: {len(results)} result2 {results}')
            for item in results:
                # log(f'{__name__} episode item: {item}')
                urls = parseDOM(item, "a", ret="href")
                for url in urls:
                    # log(f'{__name__} query_title: {query_title} episode_title: {episode_title} url: {url}')
                    if query_title in str(url) and episode_title in str(url):
                        # log(f'@@@@@ {__name__} episode item: {item}')
                        return url
        except:
            error(f'{__name__}_ episode: ')
        return

    def sources(self, url, hostDict):
        # log(f'From: {__name__} url {url}')
        sources = []
        try:
            if not url: return sources
            result = request(url, headers=self.headers)
            if not result: return sources
            # log(f'From: {__name__} total: {len(result)} result {result}')
            results = parseDOM(result, 'div', attrs={'class': 'entry'})
            # log(f'From: {__name__} total: {len(results)} results {results}')
            items = parseDOM(results, 'p')
            for item in items:
                urls = parseDOM(item, 'a', attrs={'target': '_blank'}, ret='href')
                #log(f'total: {len(urls)} urls: {urls}')
                for iurl in urls:
                    sources = get_source_dict(iurl, sources)
                # iurls = []
                # if iurls := [iurl for iurl in urls if 'vkspeed.php?id=' in iurl or 'vkprime.php?id=' in iurl and iurl not in iurls]:
                    # sources = get_source_dict(iurls, sources)
            if not sources: log(f'From: {__name__} no sources on url {url}')
            return sources
        except:
            error(f'{__name__}_ sources url: {url} ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return resolve_gen(url)
