# -*- coding: UTF-8 -*-
import json
import re

from openscrapers.modules.client import agent, parseDOM, request
from openscrapers.modules.hindi_utils import get_source_dict, resolve_gen
from openscrapers.modules.log_utils import error, log
from openscrapers.modules.control import setting
from openscrapers.modules.source_utils import get_host
from openscrapers import custom_base_link
custom_base = custom_base_link(__name__)

class source:

    def __init__(self):
        self.name = 'movierulz'
        self.base_link = custom_base or 'https://www.5movierulz.online'
        self.domains = list(get_host(self.base_link)) # ['5movierulz.online']
        self.search_link = '/?s='
        self.headers = {'User-Agent': agent(), }

    def movie(self, imdb, title, localtitle, aliases, year):
        # log(f'From: {__name__}\nimdb: {imdb}\ntitle: {title}\nlocaltitle: {localtitle}\naliases: {aliases}\nyear: {year}')
        try:
            # log(f'title: {repr(title)} year: {repr(year)}')
            scrape = title.lower().replace(' ', '-')
            iurl = f'{self.base_link}{self.search_link}{scrape}'
            result = request(iurl, headers=self.headers)
            if not result: return
            result = parseDOM(result, 'div', attrs={'class': 'cont_display'})
            # log(f'total: {len(result)} result: {result}')
            for item in result:
                if re.search(scrape, item, re.I) and 'Full Movie' in str(item):
                    # log(f'item: {item}')
                    if url := parseDOM(item, 'a', ret="href")[0]:
                        return url
            return
        except:
            error(f'{__name__}_ movie: ')
            return

    # def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
    #     # log(f'From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year}')
    #     try:
    #         return f'{tvshowtitle}'
    #     except:
    #         error(f'{__name__}_ tvshow: ')
    #         return
    #
    # def episode(self, url, imdb, tvdb, title, premiered, season, episode):
    #     # log(f'From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}')
    #     try:
    #         if type(tvdb) == int: return
    #         if '|' not in tvdb: return
    #         url = url.lower().replace(f' season {season}', '').replace(' ', '-').replace('.', '')
    #         if 'episode' in title.lower():
    #             # log(f'episode url:  {url}\nseason: {season} episode: {episode}')
    #             query = f'episode/{url}-s{season}e{episode}'
    #             return f'{self.base_link}/{query}/'
    #     except:
    #         error(f'{__name__}_ episode: ')
    #         return

    def sources(self, url, hostDict):
        log(f'From: {__name__} url {url}')
        sources = []
        try:
            if not url: return sources
            result = request(url, headers=self.headers)
            if not result: return sources
            items = parseDOM(result, 'div', attrs={'class': 'entry-content'})
            # log(f'1total: {len(items)} items: {repr(items)}')
            result = parseDOM(items, 'a', attrs={'target': '_blank'}, ret="href")
            # log(f'total: {len(result)} result: {repr(result)}')
            for item in result:
                if not item.startswith('https://t.me'):
                    # print(f'item: {item}')
                    sources = get_source_dict([str(item)], sources)
            r = re.search(r'var\s*locations\s*=\s*([^;]+)', result)
            if r:
                links = json.loads(r.group(1))
                for link in links:
                    if 'vcdnlare' in link or 'uperbox' in link:
                        sources = get_source_dict([str(link)], sources)
            return sources
        except:
            error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return resolve_gen(url)
