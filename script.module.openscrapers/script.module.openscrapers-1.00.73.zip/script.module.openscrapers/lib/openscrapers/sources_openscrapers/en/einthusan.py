# -*- coding: UTF-8 -*-
import base64
import json
import random
import re
import time

from openscrapers import quote, urljoin
from openscrapers.modules import cache
# from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.client import request
from openscrapers.modules.hindi_utils import get_source_dict, replaceHTMLCodes, resolve_gen
from openscrapers.modules.log_utils import error, log
from openscrapers.modules.control import setting
from openscrapers.modules.source_utils import get_host
from openscrapers import custom_base_link
custom_base = custom_base_link(__name__)

class source:

    def __init__(self):
        self.name = 'einthusan'
        self.base_link = custom_base or 'https://einthusan.tv'
        self.domains = list(get_host(self.base_link)) #  ['einthusan.tv']
        self.headers = {'Referer': f'{self.base_link}/', 'Origin': self.base_link,}

    def movie(self, imdb, title, localtitle, aliases, year):
        # log(f'From: {__name__}\nimdb: {imdb}\ntitle: {title}\nlocaltitle: {localtitle}\naliases: {aliases}\nyear: {year}')
        try:
            link = f'https://einthusan.tv/movie/results/?lang=hindi&query={title}'
            # log(f'link: {link}')
            movies_page = request(link)
            if not movies_page: return None
            # movies_page = requests.get(link, headers=self.headers).text
            # read_write_file(file_n='www.desirulez.cc.html')
            items = re.findall(r'data-disabled="false"\s*href="([^"]+)">\s*<img\s*src="([^"]+).+?>([^<]+)</h3.+?info">(.+?)</div', movies_page)
            items += re.findall(r'data-disabled="false"\s*href="([^"]+)"><img\s*src="([^"]+).+?h3>([^<]+).+?info">(.+?)</div', movies_page)
            # log(f'total: {len(items)} items: {items}')
            url = self.filter_relevent(items, title, year)
            if not url: url = self.filter_relevent(items, title, year, check_year=False)
            return url
        except:
            error(f'{__name__}_ movie: ')
            return None

    def filter_relevent(self, items, title, year, check_year=True):
        for url, thumb, gtitle, info in items:
            # log(f'url: {url} thumb: {thumb} gtitle: {gtitle} info: {info}')
            if title.lower() == gtitle.lower() and year in info and check_year:
                url = (url if url.startswith(self.base_link) else urljoin(self.base_link, quote(url)))
                return url
            if title.lower() == gtitle.lower() and not check_year:
                url = (url if url.startswith(self.base_link) else urljoin(self.base_link, quote(url)))
                return url
        return 

    def decrypt(self, e):
        t = 10
        i = e[:t] + e[-1] + e[t + 2:-1]
        i = base64.b64decode(i).decode('utf-8')
        return json.loads(i)

    def encrypt(self, t):
        e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        n = 10
        a = json.dumps(t).encode('utf-8')
        a = base64.b64encode(a).decode('utf-8')
        a = a[:n] + random.choice(e) + random.choice(e) + a[n + 1:] + a[n]
        return a

    def get_sort_cdn(self, slist):
        ejo = []
        for server in slist:
            params = {'_': int(time.time() * 1000)}
            response = request(server, params=params, output='elapsed')
            ejo.append((response, server))
            #response = requests.get(server, headers=self.headers, params=params)
            #ejo.append((response.elapsed, server))
        return self.encrypt([x for _, x in sorted(ejo)])

    def sources(self, url, hostDict):
        # log(f'From: {__name__}\nurl {url}')
        sources = []
        try:
            if not url: return sources
            result = request(url, headers=self.headers, output='extended')
            # result = requests.get(url, headers=self.headers)
            if not result: return sources
            token = replaceHTMLCodes(re.findall(r'data-pageid="([^"]+)', result[0])[0])
            #log(f'token: {token}')
            ej = re.findall(r'data-ejpingables="([^"]+)', result[0])[0]
            ej = self.decrypt(ej)
            xj = {"EJOutcomes": cache.get(self.get_sort_cdn, 24, ej), "NativeHLS": False}
            pdata = {'xEvent': 'UIVideoPlayer.PingOutcome', 'xJson': json.dumps(xj).replace(' ', ''), 'gorilla.csrf.Token': token}
            self.headers.update({'X-Requested-With': 'XMLHttpRequest'})
            aurl = url.replace('/movie', '/ajax/movie')
            r2 = request(aurl, post=pdata, headers=self.headers, cookies=result[3])
            # r2 = requests.post(aurl, data=pdata, headers=self.headers, cookies=result.cookies)
            stream_url = self.decrypt(r2.json()['Data']['EJLinks'])['MP4Link']
            # log(f'stream_url: {repr(stream_url)}')
            if stream_url is not None: sources = get_source_dict(stream_url, sources)
            return sources
        except:
            error(f'{__name__}_ sources:')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return resolve_gen(url)
