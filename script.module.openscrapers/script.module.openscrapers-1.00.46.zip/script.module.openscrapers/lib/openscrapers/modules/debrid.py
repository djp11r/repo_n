# -*- coding: utf-8 -*-
"""
	OpenScrapers Module
"""


# from openscrapers.modules import control
from openscrapers.modules import log_utils

try:
	import resolveurl

	debrid_resolvers = [resolver() for resolver in resolveurl.relevant_resolvers(order_matters=True) if
						resolver.isUniversal()]
	if not debrid_resolvers:
		debrid_resolvers = [resolver() for resolver in
							resolveurl.relevant_resolvers(order_matters=True, include_universal=False) if
							'rapidgator.net' in resolver.domains]
except:
	debrid_resolvers = []


def status():
	return debrid_resolvers != []


def resolver(url, debrid):
	try:
		debrid_resolver = [resolver for resolver in debrid_resolvers if resolver.name == debrid][0]
		debrid_resolver.login()
		_host, _media_id = debrid_resolver.get_host_and_id(url)
		return debrid_resolver.get_media_url(_host, _media_id)
	except Exception as e:
		log_utils.log(f'{debrid} Resolve Failure: {e}', log_utils.LOGWARNING)
		return None
