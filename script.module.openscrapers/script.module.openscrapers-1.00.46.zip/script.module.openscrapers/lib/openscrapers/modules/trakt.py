# -*- coding: utf-8 -*-
"""
    OpenScrapers Module
"""

import json
import re
from urllib.parse import quote_plus

import requests
# import re
# import threading
# import time
from openscrapers import urljoin

from openscrapers.modules import cleandate
from openscrapers.modules import client
from openscrapers.modules import client_utils
from openscrapers.modules import log_utils
from openscrapers.modules import utils
from openscrapers.modules import control

BASE_URL = 'https://api.trakt.tv'
V2_API_KEY = '42740047aba33b1f04c1ba3893ce805a9ecfebd05de544a30fe0c99fabec972e'
CLIENT_SECRET = 'c7a3e7fdf5c3863872c8f45e1d3f33797b492ed574a00a01a3fadcb3d270f926'
REDIRECT_URI = 'urn:ietf:wg:oauth:2.0:oob'


def getTraktCredentialsInfo():
    user = control.setting('trakt.user').strip()
    token = control.setting('trakt.token')
    refresh = control.setting('trakt.refresh')
    return user != '' and token != '' and refresh != ''


def __getTraktALT(url, post=None):
    try:
        url = url if url.startswith(BASE_URL) else urljoin(BASE_URL, url)
        post = json.dumps(post) if post else None
        headers = {'Content-Type': 'application/json', 'trakt-api-key': V2_API_KEY, 'trakt-api-version': '2'}
        if getTraktCredentialsInfo():
            headers['Authorization'] = f'Bearer {control.setting("trakt.token")}'
        result = client.request(url, post=post, headers=headers, output='extended', error=True)
        result = utils.byteify(result)
        resp_code = result[1]
        resp_header = result[2]
        result = result[0]
        if resp_code in ['423', '500', '502', '503', '504', '520', '521', '522', '524']:
            log_utils.log(f'Temporary Trakt Error: {resp_code}', log_utils.LOGWARNING)
            return
        elif resp_code in ['429']:
            log_utils.log(f'Trakt Rate Limit Reached: {resp_code}', log_utils.LOGWARNING)
            return
        elif resp_code in ['404']:
            log_utils.log(f'Trakt Object Not Found: {resp_code}', log_utils.LOGWARNING)
            return
        if resp_code not in ['401', '405']:
            return result, resp_header
        oauth = urljoin(BASE_URL, '/oauth/token')
        opost = {'client_id': V2_API_KEY, 'client_secret': CLIENT_SECRET, 'redirect_uri': REDIRECT_URI, 'grant_type': 'refresh_token', 'refresh_token': control.setting('trakt.refresh')}
        result = client.request(oauth, post=json.dumps(opost), headers=headers)
        result = client_utils.json_loads_as_str(result)
        token, refresh = result['access_token'], result['refresh_token']
        control.setSetting(id='trakt.token', value=token)
        control.setSetting(id='trakt.refresh', value=refresh)
        headers['Authorization'] = f'Bearer {token}'
        result = client.request(url, post=post, headers=headers, output='extended', error=True)
        result = client_utils.byteify(result)
        return result[0], result[2]
    except Exception as e:
        log_utils.log(f'Unknown Trakt Error: {e}', log_utils.LOGWARNING)


def __getTrakt(url, post=None):
    try:
        url = url if url.startswith(BASE_URL) else urljoin(BASE_URL, url)
        post = json.dumps(post) if post else None
        headers = {'Content-Type': 'application/json', 'trakt-api-key': V2_API_KEY, 'trakt-api-version': '2'}
        if getTraktCredentialsInfo():
            headers['Authorization'] = f'Bearer {control.setting("trakt.token")}'
        if not post:
            r = requests.get(url, headers=headers, timeout=30)
        else:
            r = requests.post(url, data=post, headers=headers, timeout=30)
        r.encoding = 'utf-8'
        resp_code = str(r.status_code)
        resp_header = r.headers
        result = r.text
        if resp_code in ['423', '500', '502', '503', '504', '520', '521', '522', '524',]:
            log_utils.log(f'Trakt Error: {resp_code}')
            return
        elif resp_code in {'429'}:
            log_utils.log(f'Trakt Rate Limit Reached: {resp_code}')
            return
        elif resp_code in {'404'}:
            log_utils.log(f'Trakt Object Not Found : {resp_code}')
            return
        if resp_code not in ['401', '405', '403']:
            return result, resp_header
        oauth = urljoin(BASE_URL, '/oauth/token')
        opost = {'client_id': V2_API_KEY, 'client_secret': CLIENT_SECRET, 'redirect_uri': REDIRECT_URI, 'grant_type': 'refresh_token', 'refresh_token': control.setting('trakt.refresh')}
        result = requests.post(oauth, data=json.dumps(opost), headers=headers, timeout=30).json()
        token, refresh = result['access_token'], result['refresh_token']
        control.setSetting(id='trakt.token', value=token)
        control.setSetting(id='trakt.refresh', value=refresh)
        headers['Authorization'] = f'Bearer {token}'
        if not post:
            r = requests.get(url, headers=headers, timeout=30)
        else:
            r = requests.post(url, data=post, headers=headers, timeout=30)
        r.encoding = 'utf-8'
        return r.text, r.headers
    except:
        pass


def _released_key(item):
    if 'released' in item:
        return item['released'] or '0'
    elif 'first_aired' in item:
        return item['first_aired'] or '0'
    else:
        return '0'


def sort_list(sort_key, sort_direction, list_data):
    reverse = sort_direction != 'asc'
    if sort_key == 'rank':
        return sorted(list_data, key=lambda x: x['rank'], reverse=reverse)
    elif sort_key == 'added':
        return sorted(list_data, key=lambda x: x['listed_at'], reverse=reverse)
    elif sort_key == 'title':
        return sorted(list_data, key=lambda x: x[x['type']].get('title'), reverse=reverse)
    elif sort_key == 'released':
        return sorted(list_data, key=lambda x: _released_key(x[x['type']]), reverse=reverse)
    elif sort_key == 'runtime':
        return sorted(list_data, key=lambda x: x[x['type']].get('runtime', 0), reverse=reverse)
    elif sort_key == 'popularity':
        return sorted(list_data, key=lambda x: x[x['type']].get('votes', 0), reverse=reverse)
    elif sort_key == 'percentage':
        return sorted(list_data, key=lambda x: x[x['type']].get('rating', 0), reverse=reverse)
    elif sort_key == 'votes':
        return sorted(list_data, key=lambda x: x[x['type']].get('votes', 0), reverse=reverse)
    else:
        return list_data


def getTraktAsJson(url, post=None):
    try:
        r, res_headers = __getTrakt(url, post)
        r = client_utils.json_loads_as_str(r)
        if 'X-Sort-By' in res_headers and 'X-Sort-How' in res_headers:
            r = sort_list(res_headers['X-Sort-By'], res_headers['X-Sort-How'], r)
        return r
    except:
        pass


def getTraktIndicatorsInfo():
    indicators = control.setting('indicators') if getTraktCredentialsInfo() == False else control.setting('indicators.alt')
    indicators = indicators == '1'
    return indicators


def getTraktAddonMovieInfo():
    try:
        scrobble = control.addon('script.trakt').getSetting('scrobble_movie')
    except:
        scrobble = ''
    try:
        ExcludeHTTP = control.addon('script.trakt').getSetting('ExcludeHTTP')
    except:
        ExcludeHTTP = ''
    try:
        authorization = control.addon('script.trakt').getSetting('authorization')
    except:
        authorization = ''
    return scrobble == 'true' and ExcludeHTTP == 'false' and not not authorization


def getTraktAddonEpisodeInfo():
    try:
        scrobble = control.addon('script.trakt').getSetting('scrobble_episode')
    except:
        scrobble = ''
    try:
        ExcludeHTTP = control.addon('script.trakt').getSetting('ExcludeHTTP')
    except:
        ExcludeHTTP = ''
    try:
        authorization = control.addon('script.trakt').getSetting('authorization')
    except:
        authorization = ''
    return scrobble == 'true' and ExcludeHTTP == 'false' and not not authorization


def slug(name):
    name = name.strip()
    name = name.lower()
    name = re.sub('[^a-z0-9_]', '-', name)
    name = re.sub('--+', '-', name)
    if name.endswith('-'):
        name = name.rstrip('-')
    return name


def manager(name, imdb, tmdb, content):
    try:
        post = {"movies": [{"ids": {"imdb": imdb}}]} if content == 'movie' else {"shows": [{"ids": {"tmdb": tmdb}}]}
        items = [('Add to [B]Collection[/B]', '/sync/collection')]
        items += [('Remove from [B]Collection[/B]', '/sync/collection/remove')]
        items += [('Add to [B]Watchlist[/B]', '/sync/watchlist')]
        items += [('Remove from [B]Watchlist[/B]', '/sync/watchlist/remove')]
        items += [('Add to [B]new List[/B]', '/users/me/lists/%s/items')]
        result = getTraktAsJson('/users/me/lists')
        lists = [(i['name'], i['ids']['slug']) for i in result]
        lists = [lists[i//2] for i in range(len(lists)*2)]
        for i in range(0, len(lists), 2):
            lists[i] = (str(f'Add to [B]{lists[i][0]}[/B]'), f'/users/me/lists/{lists[i][1]}/items',)
        for i in range(1, len(lists), 2):
            lists[i] = (str(f'Remove from [B]{lists[i][0]}[/B]'), f'/users/me/lists/{lists[i][1]}/items/remove',)
        items += lists
        select = control.selectDialog([i[0] for i in items], 'Trakt Manager')
        if select == -1:
            return
        elif select == 4:
            t = 'Add to [B]new List[/B]'
            k = control.keyboard('', t)
            k.doModal()
            new = k.getText() if k.isConfirmed() else None
            if new is None or new == '':
                return
            result = __getTrakt('/users/me/lists', post={"name": new, "privacy": "private"})[0]
            try:
                slug = client_utils.json_loads_as_str(result)['ids']['slug']
            except:
                return control.infoDialog('Trakt Manager', heading=str(name), sound=True, icon='ERROR')
            result = __getTrakt(items[select][1] % slug, post=post)[0]
        else:
            result = __getTrakt(items[select][1], post=post)[0]
        icon = control.infoLabel('ListItem.Icon') if result is not None else 'ERROR'
    except:
        return


def getActivity():
    try:
        i = getTraktAsJson('/sync/last_activities')
        activity = [
            i['movies']['collected_at'],
            i['episodes']['collected_at'],
            i['movies']['watchlisted_at'],
            i['shows']['watchlisted_at'],
            i['seasons']['watchlisted_at'],
            i['episodes']['watchlisted_at'],
            i['lists']['updated_at'],
            i['lists']['liked_at'],
        ]
        activity = [int(cleandate.iso_2_utc(i)) for i in activity]
        activity = sorted(activity, key=int)[-1]
        return activity
    except:
        pass


def getWatchedActivity():
    try:
        i = getTraktAsJson('/sync/last_activities')
        activity = [i['movies']['watched_at'], i['episodes']['watched_at']]
        activity = [int(cleandate.iso_2_utc(i)) for i in activity]
        activity = sorted(activity, key=int)[-1]
        return activity
    except:
        pass


def syncMovies(user):
    try:
        if not getTraktCredentialsInfo():
            return
        indicators = getTraktAsJson('/users/me/watched/movies')
        indicators = [i['movie']['ids'] for i in indicators]
        return [str(i['imdb']) for i in indicators if 'imdb' in i]
    except:
        pass


def cachesyncMovies(timeout=0):
    return cache.get(syncMovies, timeout, control.setting('trakt.user').strip())


def timeoutsyncMovies():
    timeout = cache.timeout(syncMovies, control.setting('trakt.user').strip())
    return timeout


def syncTVShows(user):
    try:
        if not getTraktCredentialsInfo():
            return
        indicators = getTraktAsJson('/users/me/watched/shows?extended=full')
        indicators = [(i['show']['ids']['tmdb'], i['show']['aired_episodes'], sum(([(s['number'], e['number']) for e in s['episodes']] for s in i['seasons']), [],),) for i in indicators]
        return [(str(i[0]), int(i[1]), i[2]) for i in indicators]
    except:
        pass


def cachesyncTVShows(timeout=0):
    return cache.get(syncTVShows, timeout, control.setting('trakt.user').strip())


def timeoutsyncTVShows():
    timeout = cache.timeout(syncTVShows, control.setting('trakt.user').strip()) or 0
    return timeout


def syncSeason(imdb):
    try:
        if not getTraktCredentialsInfo():
            return
        indicators = getTraktAsJson(f'/shows/{imdb}/progress/watched?specials=false&hidden=false')
        indicators = indicators['seasons']
        indicators = [(i['number'], [x['completed'] for x in i['episodes']]) for i in indicators]
        return ['%01d' % int(i[0]) for i in indicators if False not in i[1]]
    except:
        pass


def markMovieAsWatched(imdb):
    if not imdb.startswith('tt'):
        imdb = f'tt{imdb}'
    return __getTrakt('/sync/history', {"movies": [{"ids": {"imdb": imdb}}]})[0]


def markMovieAsNotWatched(imdb):
    if not imdb.startswith('tt'):
        imdb = f'tt{imdb}'
    return __getTrakt('/sync/history/remove', {"movies": [{"ids": {"imdb": imdb}}]})[0]


def markTVShowAsWatched(imdb):
    return __getTrakt('/sync/history', {"shows": [{"ids": {"imdb": imdb}}]})[0]


def markTVShowAsNotWatched(imdb):
    return __getTrakt('/sync/history/remove', {"shows": [{"ids": {"imdb": imdb}}]})[0]


def markEpisodeAsWatched(imdb, season, episode):
    season, episode = int('%01d' % int(season)), int('%01d' % int(episode))
    return __getTrakt('/sync/history', {"shows": [{"seasons": [{"episodes": [{"number": episode}], "number": season}], "ids": {"imdb": imdb}}]})[0]


def markEpisodeAsNotWatched(imdb, season, episode):
    season, episode = int('%01d' % int(season)), int('%01d' % int(episode))
    return __getTrakt('/sync/history/remove', {"shows": [{"seasons": [{"episodes": [{"number": episode}], "number": season}], "ids": {"imdb": imdb}}]})[0]


def getMovieTranslation(id, lang, full=False):
    url = f'/movies/{id}/translations/{lang}'
    try:
        item = getTraktAsJson(url)[0]
        return item if full else item.get('title')
    except:
        pass


def getTVShowTranslation(id, lang, season='', episode='', full=False):
    if season and episode:
        url = f'/shows/{id}/seasons/{season}/episodes/{episode}/translations/{lang}'
    else:
        url = f'/shows/{id}/translations/{lang}'
    try:
        item = getTraktAsJson(url)[0]
        return item if full else item.get('title')
    except:
        pass


def getMovieAliases(id):
    try:
        return getTraktAsJson(f'/movies/{id}/aliases')
    except:
        return []


def getTVShowAliases(id):
    try:
        return getTraktAsJson(f'/shows/{id}/aliases')
    except:
        return []


def getMovieSummary(id, full=False):
    try:
        url = f'/movies/{id}'
        if full:
            url += '?extended=full'
        return getTraktAsJson(url)
    except:
        return


def getTVShowSummary(id, full=False):
    try:
        url = f'/shows/{id}'
        if full:
            url += '?extended=full'
        return getTraktAsJson(url)
    except:
        return


def getSeasonsSummary(id, full=False, episodes=False):  #Uses imdb_id, full or episodes but not both.
    try:
        url = f'/shows/{id}/seasons'
        if full:
            url += '?extended=full'
        if episodes:
            url += '?extended=episodes'
        return getTraktAsJson(url)
    except:
        return


def getEpisodeSummary(id, season, episode='', full=False):
    try:
        if not episode:
            url = f'/shows/{id}/seasons/{season}'
            #url += '?translations=en'
        else:
            url = f'/shows/{id}/seasons/{season}/episodes/{episode}'
        if full:
            url += '?extended=full'
        return getTraktAsJson(url)
    except:
        return


#/shows/game-of-thrones/seasons/1/people
#/shows/game-of-thrones/seasons/1/people?extended=guest_stars

#/shows/game-of-thrones/seasons/1/episodes/1/people
#/shows/game-of-thrones/seasons/1/episodes/1/people?extended=guest_stars


def getPeople(id, content_type, full=False): #Uses imdb_id
    try:
        url = f'/{content_type}/{id}/people'
        if full:
            url += '?extended=full'
        return getTraktAsJson(url)
    except:
        return


def getStudio(id, content_type): #Uses imdb_id
    try:
        url = f'/{content_type}/{id}/studios'
        return getTraktAsJson(url)
    except:
        return


def getGenre(content, type, type_id):
    try:
        r = getTraktAsJson(f'/search/{type}/{type_id}?type={content}&extended=full')
        return r[0].get(content, {}).get('genres', [])
    except:
        log_utils.error()
        return []


def SearchMovie(title, year='', full=False):
    try:
        url = f'/search/movie?query={quote_plus(title)}'
        if year:
            url += f'&year={year}'
        if full:
            url += '&extended=full'
        return getTraktAsJson(url)
    except:
        return


def SearchTVShow(title, year='', full=False):
    try:
        url = f'/search/show?query={quote_plus(title)}'
        if year:
            url += f'&year={year}'
        if full:
            url += '&extended=full'
        return getTraktAsJson(url)
    except:
        return


def SearchEpisode(title, season, episode, full=False):
    try:
        url = f'/search/{title}/seasons/{season}/episodes/{episode}'
        if full:
            url += '&extended=full'
        return getTraktAsJson(url)
    except:
        return


def SearchAll(title, year='', full=False):
    try:
        return SearchMovie(title, year, full) + SearchTVShow(title, year, full)
    except:
        return


