# -*- coding: utf-8 -*-
"""
"""

import re
import base64
import traceback

try:
    from urlparse import parse_qs, urljoin
    from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, parse_qs, quote_plus, urljoin

from openscrapers import cfScraper
#from openscrapers.modules import cfscrape
from openscrapers.modules import client
from openscrapers.modules import source_utils
from openscrapers.modules import log_utils
# from openscrapers.modules import directstream
#from openscrapers.modules.hindi_sources import read_write_file

class source:
    def __init__(self):
        """
        For Movie: https://vidsrc.me/embed/ IMDB_ID /
        ex: https://vidsrc.me/embed/tt1300854/
        For TV Show https://vidsrc.me/embed/ IMDB_ID / SE - EP /
        ex: https://vidsrc.me/embed/tt0944947/2-3/
        For Latest Added Movies JSON: https://vidsrc.me/movies/latest/page-1.json
        For Latest Added Episodes JSON: https://vidsrc.me/episodes/latest/page-1.json
        """
        self.priority = 1
        self.language = ['en']
        self.domains = ['vidsrc.me', 'v2.vidsrc.me']
        self.base_link = 'https://v2.vidsrc.me'
        self.movie_link = '/embed/%s'
        self.tv_link = '/embed/%s/%s-%s'
        self.headers = {'User-Agent': client.agent(), 'Referer': self.base_link}

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url is None: return sources
            hostDict = hostprDict + hostDict

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            if not data['imdb'] or data['imdb'] == '0':
                return sources

            if 'tvshowtitle' in data:
                query = self.tv_link % (data['imdb'], data['season'], data['episode'])
            else:
                query = self.movie_link % data['imdb']

            url = urljoin(self.base_link, query)
            r = client.r_request(url)
            #log_utils.log('VIDSRC r: ' + r)
            items = client.parse_dom(r, 'div', req='data-hash')
            for item in items:
                url = 'https://v2.vidsrc.me/src/%s' % item.attrs['data-hash']
                #log_utils.log('VIDSRC url: ' + repr(url))
                host = client.parseDOM(item.content, 'div')[0]
                #log_utils.log('VIDSRC host: ' + repr(host))
                host = host.lower().replace('vidsrc', '').strip()
                if host == 'pro': # other sources are javascripted
                    host = 'direct'
                    sources.append({'source': host, 'quality': '720p', 'language': 'en', 'url': url, 'direct': True, 'debridonly': False})
            # read_write_file(file_n='test_apimdb.html', read=False, result=posts)
            # posts = read_write_file(file_n='test_apimdb.html')
            #urls = re.findall(r'<div class="server" data-src="(.+?)">', posts)
            # urls = client.parseDOM(r, 'div', attrs={'class': '.*?source'}, ret='data-hash')
            # # log_utils.log('r: ' + repr(urls))
            # # urls = [urljoin(self.base_link, url) if url.startswith('/') else url for url in urls]
            # # log_utils.log('_all: len(urls): %s urls: %s' % (len(urls), urls))
            # for url in urls:
            #     try:
            #         headers = {'User-Agent': client.agent(), 'Referer': 'https://v2.vidsrc.me'}
            #         r = 'https://v2.vidsrc.me/src/%s' % url
            #         r2 = cfScraper.get(r, headers=headers).text
            #         # read_write_file(file_n='test_apividsrc.html', read=False, result=posts)
            #         # posts = read_write_file(file_n='test_apividsrc.html')
            #         links = re.findall("'player' src='(.+?)'", r2)
            #         for url in links:
            #             url = url if url.startswith('http') else 'https:{0}'.format(url)
            #             valid, host = source_utils.is_host_valid(url, hostDict)
            #             url = "%s%s" % (url, source_utils.append_headers(headers))
            #             if valid:
            #                 sources.append({'source': host, 'quality': '720p', 'language': 'en', 'info': '', 'url': url, 'direct': False, 'debridonly': False})
            #             else:
            #                 sources.append({'source': 'vidsrc', 'quality': '720p', 'language': 'en', 'info': '', 'url': url, 'direct': True, 'debridonly': False})
            #     except:
            #         source_utils.scraper_error('%s_sources:' % __name__)
            return sources
        except:
            source_utils.scraper_error('%s_sources:' % __name__)
            return sources

    def resolve(self, url):
        data = client.r_request(url)
        #log_utils.log('VIDSRC data: ' + data)
        link = re.findall("'player' src='(.+?)'", data)[0]
        link = link + '|Referer=https://vidsrc.me'
        url = link if link.startswith('http') else 'https:{0}'.format(link)
        #log_utils.log('VIDSRCurl: ' + repr(url))
        return url
