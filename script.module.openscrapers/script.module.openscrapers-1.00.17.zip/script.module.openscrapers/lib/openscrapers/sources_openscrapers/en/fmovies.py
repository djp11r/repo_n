# -*- coding: utf-8 -*-

import re

from openscrapers import urlencode, parse_qs, quote_plus, urljoin
from openscrapers.modules import log_utils
from openscrapers.modules import client
from openscrapers.modules import cfscrape
from openscrapers.modules import scrape_source, cleantitle

class source:
    def __init__(self):
        self.priority = 40
        self.language = ['en']
        self.domains = ['fmovies.vision', 'gostream.cool']
        self.base_link = 'https://fmovies.vision'
        self.search_link = '/index.php?do=search&filter=true'
        self.cookie = client.request(self.base_link, output='cookie', timeout='5')
        self.headers = {'User-Agent': client.agent()}

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            movie_title = cleantitle.get_plus(title)
            check_title = cleantitle.get(title)
            search_url = self.base_link + self.search_link
            post = ('do=search&subaction=search&search_start=0&full_search=0&result_from=1&story=%s' % movie_title)
            html = client.request(search_url, post=post, cookie=self.cookie).replace('\n', '')
            r = client.parseDOM(html, 'div', attrs={'class': 'item'})
            r = [(client.parseDOM(i, 'a', attrs={'class': 'poster'}, ret='href'), client.parseDOM(i, 'img', ret='alt'), re.findall('<div class="meta">(\d{4}) <i class="dot">', i)) for i in r]
            r = [(i[0][0], i[1][0], i[2][0]) for i in r if len(i[0]) > 0 and len(i[1]) > 0 and len(i[2]) > 0]
            url = [i[0] for i in r if check_title == cleantitle.get(i[1]) and year == i[2]][0]
            return url
        except Exception:
            #log_utils.log('movie', 1)
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url is None:
                return sources

            hostDict = hostprDict + hostDict

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            query = '%s-%sx%s' % (data['tvshowtitle'], int(data['season']), int(data['episode']))
            query = re.sub(r'(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            # query = self.search_link % quote_plus(query).lower().replace('+', '-').replace('sg-1', 'sg1').replace('--', '-')
            html = client.request(url, cookie=self.cookie)
            try:
                links = client.parseDOM(html, 'div', ret='data-link')
                for link in links:
                    for source in scrape_source.getMore(link, hostDict):
                        sources.append(source)
            except:
                #log_utils.log('sources', 1)
                pass
            try:
                result = re.compile('<script src="https://simplemovie.xyz/(.+?)" type').findall(html)[0]
                result_url = 'https://simplemovie.xyz/' + result
                result_html = client.request(result_url, cookie=self.cookie).replace("\\", "")
                links = re.compile('''<tr onclick="window\.open\( \\'(.+?)\\' \)">''').findall(result_html)
                for link in links:
                    for source in scrape_source.getMore(link, hostDict):
                        sources.append(source)
            except:
                #log_utils.log('sources', 1)
                pass
            return sources
        except Exception:
            log_utils.error(f'{__name__}_ sources: ')
            return []

    def fmovies_to(self, link, hostDict):
        sources = []
        try:
            # r = client.r_request(link).text
            r = self.cfscraper.get(link, headers=self.headers).text
            # print(f'resp: {r}')
            # links = re.findall(r'''(?:src|file)[:=]\s*['"]([^"']+)''', r)
            # links = client.parseDOM(r, 'ul', ret='data-video')
            # links = client.parseDOM(r, 'ul', attrs={'class': r'list-server-items.*?'})
            links = client.parseDOM(r, 'iframe', ret='src')
            # log_utils.log("fmovies_to links: {}".format(links))
            for url in links:
                # url = "%s|%s" % (url, source_utils.append_headers(self.headers))
                sources.append({'source': 'fmovies', 'quality': '720p', 'language': 'en', 'info': '', 'url': url, 'direct': True, 'debridonly': False})
            return sources
        except:
            log_utils.error(f'{__name__}_ fmovies_to: {link}')
            return []

    def resolve(self, url):
        try:
            url = client.request(url)
            url = re.findall(r'sources: \[\{file:"*(.+?)"\}\]', url)[0]
            url = url.replace('https://', 'http://')
            return url
        except:
            return url
