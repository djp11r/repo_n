# -*- coding: utf-8 -*-

"""
    OpenScrapers Project
"""

import re

try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, quote_plus
try: from urlparse import parse_qs, urljoin
except ImportError: from urllib.parse import parse_qs, urljoin
    
# from openscrapers.sources_openscrapers import cfScraper
from openscrapers.modules import client
from openscrapers.modules import cleantitle
from openscrapers.modules import source_utils
from openscrapers.modules import more_sources


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['projecfreetv.co']
        self.base_link = 'https://www1.projecfreetv.co'
        self.search_link = '/episode/%s/'
        self.headers = {'User-Agent': client.agent()}

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return

            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            source_utils.scraper_error('projecfreetv')
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url is None:
                return sources

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']

            hdlr = 's%02de%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']

            query = '%s-s%02de%02d' % (data['tvshowtitle'], int(data['season']), int(data['episode']))
            query = re.sub(r'(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            url = self.search_link % quote_plus(query)
            url = urljoin(self.base_link, url).lower().replace('+', '-').replace(' ', '-')
            source_utils.scraper_error('projecfreetv \n%s' % url)

            r = client.request(url, headers=self.headers)
            try:
                data = re.compile('<a href="(.+?)" target="_blank" rel="nofollow" title.+?').findall(r)
                for url in data:
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    if valid:
                        sources.append(
                            {'source': host, 'quality': 'SD', 'language': 'en', 'url': url, 'direct': False,
                             'debridonly': False})
                    # if 'gomostream' in url or 'vidnode' in url or 'vidlink' in url:
                    if any(re.findall(r'gomostream|vidnode|vidlink', url, re.IGNORECASE)):
                        for source in more_sources.getMore(url, hostDict):
                            sources.append(source)
                        
            except:
                pass
            return sources
        except Exception:
            source_utils.scraper_error('projecfreetv')
            return

    def resolve(self, url):
        return url
