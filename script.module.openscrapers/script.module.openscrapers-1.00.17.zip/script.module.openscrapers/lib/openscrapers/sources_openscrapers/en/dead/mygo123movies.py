# -*- coding: utf-8 -*-

import re
# import requests
# from six import ensure_text
from openscrapers import urlparse, quote_plus

from openscrapers.modules import client
from openscrapers.modules import cleantitle
from openscrapers.modules import source_utils
from openscrapers.modules import log_utils


class source:
    def __init__(self):
        self.priority = 40
        self.language = ['en']
        self.domains = ['my.go123movies.io']
        self.base_link = 'https://my.go123movies.io'
        self.search_link = '/?s=%s'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            link = self.base_link + self.search_link % quote_plus(title)
            check = cleantitle.get(title)
            r = client.r_request(link)
            r = client.parseDOM(r, 'div', attrs={'class': 'ml-item'})
            r = [(client.parseDOM(i, 'a', ret='href'), client.parseDOM(i, 'a', ret='oldtitle'), re.findall('(\d{4})', i)) for i in r]
            r = [(i[0][0], i[1][0], i[2][0]) for i in r if len(i[0]) > 0 and len(i[1]) > 0 and len(i[2]) > 0]
            url = [i[0] for i in r if check == cleantitle.get(i[1]) and year == i[2]][0]
            return url
        except Exception:
            log_utils.error(f'{__name__}_ movie: ')
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            # tvshowtitle='South Park'
            link = self.base_link + self.search_link % quote_plus(tvshowtitle)
            check = cleantitle.comper_title(tvshowtitle)
            # check = 'orange-is-the-new-black'
            # year= '2013'
            r = client.r_request(link)
            # from openscrapers.modules.hindi_sources import read_write_file
            # r=read_write_file(file_n='my.go123movies.io.html')
            r = client.parseDOM(r, 'div', attrs={'class': 'ml-item'})
            r = [(client.parseDOM(i, 'a', ret='href'), client.parseDOM(i, 'a', ret='oldtitle'), re.findall(r'(\d{4})', i)) for i in r]
            # log_utils.log('check: %s year: %s' % (check, year))
            # log_utils.log('r: %s' % r)
            r = [(i[0][0], i[1][0], i[2][0]) for i in r if len(i[0]) > 0 and len(i[1]) > 0 and len(i[2]) > 0]
            # log_utils.log('r: %s' % r)
            # url = [i[0] for i in r if check == cleantitle.comper_title(i[1]) and year == i[2]][0]
            for i in r:
                # print('i1: %s i2: %s' % (repr(i[1]), repr(i[2])))
                # print('type i1: %s i2: %s check: %s' % (type(cleantitle.comper_title(i[1])), type(i[2]), type(check)))
                # print('i1: %s i2: %s' % (repr(cleantitle.comper_title(i[1])), repr(i[2])))
                if str(check) == cleantitle.comper_title(i[1]) and str(year) == i[2]:
                    # print('i: %s' % str(i))
                    return i[0]
            return #url
        except Exception:
            log_utils.error(f'{__name__}_ tvshow: ')
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return
            url = url[:-1]
            url = url.replace('/series/', '/episode/')
            url = '%s-season-%s-episode-%s/' % (url, season, episode)
            return url
        except Exception:
            log_utils.error(f'{__name__}_ episode: ')
            return


# Need to scrape multiple shows and movies to log source results.
# then write or find the proper bit to scrape the links further.


    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            hostDict = hostprDict + hostDict
            if url == None: return sources
            log_utils.log('Addon Testing starting url: \n' + repr(url))
            html = client.r_request(url).text
            links = client.parseDOM(html, 'iframe', ret='src')
            for link in links:
                link = "https:" + link if not link.startswith('http') else link
                # log_utils.log('Addon Testing link: \n' + repr(link))
                valid, host = source_utils.is_host_valid(link, hostDict)
                qual, info = source_utils.get_release_quality(link, link)
                sources.append({'source': host, 'quality': qual, 'language': 'en', 'url': link, 'info': info, 'direct': False, 'debridonly': False})
            return sources
        except Exception:
            log_utils.error(f'{__name__}_ sources: ')
            return sources


    def resolve(self, url):
        return url


