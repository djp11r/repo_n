# -*- coding: UTF-8 -*-
import re

from openscrapers import parse_qs, urlencode
from openscrapers.modules import cleantitle
from openscrapers.modules.client import agent, request, scrapePage
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.hindi_utils import get_query, get_source_dict, query_cleaner, resolve_gen, get_ch_name
from openscrapers.modules.log_utils import log, error


class source:

    def __init__(self):
        self.name = "desirulez"
        self.domains = ['desirulez.net']
        self.base_link = 'https://desirulez.net'
        self.base_link_3 = f'{self.base_link}/watch-online'
        self.headers = {'User-Agent': agent(), }

    # def movie(self, imdb, title, localtitle, aliases, year):
    #     # log(f'From: {__name__}\nimdb: {imdb}\ntitle: {title}\nlocaltitle: {localtitle}\naliases: {aliases}\nyear: {year}')
    #     try:
    #         link = f'{self.base_link}/forumdisplay.php?f=20'
    #         movies_page = scrapePage(link, headers=self.headers).text # read_write_file(file_n='www.desirulez.cc.html')#
    #         result = parseDOM(movies_page, "h3", attrs={"class": "threadtitle"})
    #         for item in result:
    #             if title in item:
    #                 url = parseDOM(item, "a", ret="href")[0]
    #                 url = (
    #                     url
    #                     if url.startswith(self.base_link_3)
    #                     else urljoin(self.base_link_3, quote(url))
    #                 )
    #                 # log(f'url: {url}')
    #                 url = {'imdb': imdb, 'title': title, 'year': year, 'aliases': aliases, 'url': url}
    #                 url = urlencode(url)
    #                 return url
    #     except:
    #         error(f'{__name__}_ movie: ')
    #         return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f'From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year}')
        try:
            try:
                url = aliases[0]['url']
                # log(f'show url: {url}')
                if 'desirulez' in url: return url
            except: pass
            return f'{tvshowtitle}'
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f'From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}')
        try:
            if type(tvdb) == int: return
            if '|' not in tvdb: return
            ch_name = get_ch_name(str(tvdb))
            query = get_query(url)
            if re.search(r'kaun-banega-crorepati', query, re.I): query = 'kaun-banega-crorepati-15'
            fquery = f'{query}-{title}-video-episode-update-online/'
            fquery = query_cleaner(fquery)
            url = {'imdb': imdb, 'title': title, 'url': f'{self.base_link}/{fquery}', 'referer': f'{self.base_link}/watch-online/{ch_name}/{query}/'}
            url = urlencode(url)
            return url
        except:
            error(f'{__name__}_ episode: ')
            return

    def searchShow(self, title, season, episode, aliases):
        # aliases = [{'title': title}]
        try:
            url = f'{self.base_link}/tv-show/{cleantitle.geturl(title)}/season/{int(season):01d}/episode/{int(episode):01d}'
            # url = '%s/show/%s/season/%01d/episode/%01d' % (self.base_link, cleantitle.geturl(alias['title']), int(season), int(episode))
            url = request(url, headers=self.headers, output='geturl', timeout='10')
            if self.base_link in url:
                return url
        except:
            error(f'{__name__}_ searchShow: ')
            return

    def sources(self, url, hostDict):
        # log(f'From: {__name__} url {url}')
        sources = []
        try:
            if not url: return sources
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            url = data['url']
            # log(f'url to get: {url}')
            self.headers['referer'] = data['referer']
            result = scrapePage(url, headers=self.headers).text
            # log(f'result to get: {result}')
            if not result: return sources
            # result = result.replace('\n', '')
            links = parseDOM(result, 'div', attrs={'class': 'entry-content entry clearfix'})
            # links = parseDOM(result, 'blockquote', attrs={'class': r'.*?postcontent.*?'})
            # log(f'total: {len(links)} links: {links}')
            # pattern = re.compile(r'(?<=font color)(.+?)(((?=font color)|##)+)', re.S)  # all a in after font color
            pattern = re.compile(r'(?<=<b>)(.+?)((?=<b>)|##)', re.S)  # find all a after <b> and before <b>
            ndata = re.findall(pattern, f'{links[0]}##')
            for item in ndata:
                # urls = parseDOM(item, 'a', attrs={'target': '_blank'}, ret='href')
                urls = re.findall(r'href=[\'"]?([^\'" >]+)', item[0])
                # log(f'total: {len(urls)} links: {urls}')
                final_url = []
                for iurl in urls:
                    if 'imdb.com' in iurl or 'desirulez' in iurl: continue
                    if iurl not in final_url: final_url.append(iurl)
                if final_url: sources = get_source_dict(final_url, sources)
            # log(f'total: {len(sources)} sources: {sources}')
            if not sources: log(f'From: {__name__} no sources on url {url}')
            return sources
        except:
            error(f'{__name__}_ sources: url: {url}')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return resolve_gen(url)
