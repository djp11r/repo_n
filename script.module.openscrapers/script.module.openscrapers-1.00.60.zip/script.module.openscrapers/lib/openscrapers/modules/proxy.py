# -*- coding: utf-8 -*-
"""
    OpenScrapers Module
"""

import random
import re
from openscrapers import parse_qs, urlparse, urlencode, quote_plus
from openscrapers.modules.client import request
from openscrapers.modules.utils import byteify
from openscrapers.modules.log_utils import log
from openscrapers.modules.client_utils import replaceHTMLCodes


def proxy_request(url, check, close=True, redirect=True, error=False, proxy=None, post=None, headers=None, mobile=False, XHR=False, limit=None, referer=None, cookie=None, compression=True, output='', timeout='30'):
    try:
        if proxy_url := get_proxy_url(url):
            if post is not None and isinstance(post, dict):
                post = byteify(post)
                post = urlencode(post)
            r = request(proxy_url, post=post, close=close, redirect=redirect, error=error, proxy=proxy, headers=headers, mobile=mobile, XHR=XHR, limit=limit, referer=referer, cookie=cookie, compression=compression, output=output, timeout=timeout)
            if check in str(r) or str(r): return r
    except:
        pass


def get_proxy_url(url, url_try=3):
    try:
        proxies = sorted(get_p_list(), key=lambda x: random.random())
        proxies = proxies[:url_try]
        for p in proxies:
            p += quote_plus(url)
            r = request(p, output='geturl')
            if r is not None: return p #parse(r)
            else: log(f'proxy url not working: {p} r: {r}')
    except:
        pass


def check_proxy_url():
        url = 'https%3A%2F%2Fbstsrs.one%2Fshow%2Fthe-fear-index-s01e02%2Fseason%2F1%2Fepisode%2F2'
        proxies = get_p_list()
        _work = not_work = []
        for p in proxies:
            new_url = p + quote_plus(url)
            r = request(new_url, output='geturl')
            print(f'r: {repr(r)}')
            if r: _work.append(p)
            elif not r: not_work.append(p)
        print(f'proxy _work total: {len(_work)}: {_work}')
        print(f'proxy not_work total: {len(not_work)}: {not_work}')


def get_p_list():
    return [
        'https://api.allorigins.win/raw?url=',
        'http://dontfilter.us/browse.php?b=20&u=',
        'http://www.onlineipchanger.com/browse.php?b=20&u=',
        'http://www.unblockmyweb.com/browse.php?b=20&u=',
        'http://mlproxy.science/surf.php?b=20&u=',
        'http://fproxy.net/browse.php?b=20&u=',
        ]
    # return [
    #     'http://proxycloud.net/browse.php?b=20&u=',
    #     'http://buka.link/browse.php?b=20&u=',
    #     'http://buka.link/browse.php?&b=2u=',
    #     'https://corsproxy.io/?',
    #     'http://proxite.net/browse.php?b=20&u=',
    #     'http://webtunnel.org/browse.php?b=20&u=',
    #     'http://proxydash.com/browse.php?b=20&u=',
    #     'http://www.mybriefonline.xyz/browse.php?b=20&u='
    #     'http://free-proxyserver.com/browse.php?b=20&u=',
    #     'http://webproxy.stealthy.co/browse.php?b=20&u=',
    #     'https://www.prontoproxy.com/browse.php?b=20&u=',
    #     'http://sslpro.eu/browse.php?b=20&u=',
    #     'http://www.xxlproxy.com/index.php?hl=3e4&q=']


def parse(url):
    try: url = replaceHTMLCodes(url)
    except: pass
    try: url = parse_qs(urlparse(url).query)['u'][0]
    except: pass
    try: url = parse_qs(urlparse(url).query)['q'][0]
    except: pass
    return url