# -*- coding: utf-8 -*-
"""
	OpenScrapers Module
"""

import xbmc

from traceback import print_exc
from openscrapers.modules import control
from openscrapers.modules import log_utils
window = control.homeWindow
LOGINFO = 1


class CheckSettingsFile:
	def run(self):
		try:
			# log_utils.log('[ script.module.openscrapers ]  CheckSettingsFile Service Starting...', LOGINFO)
			window.clearProperty('openscrapers_settings')
			profile_dir = control.dataPath
			if not control.existsPath(profile_dir):
				success = control.makeDirs(profile_dir)
			settings_xml = control.joinPath(profile_dir, 'settings.xml')
			if not control.existsPath(settings_xml):
				control.setSetting('module.provider', 'openscrapers')
			return
		except:
			log_utils.log(f'[ script.module.openscrapers ] Error:  {print_exc()}', LOGINFO)


class SettingsMonitor(control.monitor_class):
	def __init__ (self):
		control.monitor_class.__init__(self)
		window.setProperty('openscrapers.debug.reversed', control.setting('debug.reversed'))
		# log_utils.log('[ script.module.openscrapers ]  Settings Monitor Service Starting...', LOGINFO)

	def onSettingsChanged(self): # Kodi callback when the addon settings are changed
		window.clearProperty('openscrapers_settings')
		control.sleep(50)
		refreshed = control.make_settings_dict()
		control.refresh_debugReversed()

class AddonCheckUpdate:
	def run(self):
		# log_utils.log('[ script.module.openscrapers ]  Addon checking available updates', LOGINFO)
		try:
			import re
			import requests
			repo_xml = requests.get('https://raw.githubusercontent.com/djp11r/repo_n/mayb/script.module.openscrapers/addon.xml')
			if repo_xml.status_code != 200:
				return xbmc.log(f'[ script.module.openscrapers ]  Could not connect to remote repo XML: status code = {repo_xml.status_code}', LOGINFO)
			repo_version = re.search(r'<addon id=\"script.module.openscrapers\".*version=\"(\d*.\d*.\d*)\"', repo_xml.text, re.I).group(1)
			local_version = control.addonVersion()[:7] # 5 char max so pre-releases do try to compare more chars than github version
			def check_version_numbers(current, new): # Compares version numbers and return True if github version is newer
				current = current.split('.')
				new = new.split('.')
				step = 0
				for i in current:
					if int(new[step]) > int(i): return True
					if int(i) > int(new[step]): return False
					if int(i) == int(new[step]):
						step += 1
						continue
				return False
			if check_version_numbers(local_version, repo_version):
				while control.condVisibility('Library.IsScanningVideo'):
					control.sleep(10000)
				msg = f'[ script.module.openscrapers ] A newer version is available. Installed Version: v{local_version}, Repo Version: v{repo_version}'
				log_utils.log(msg, LOGINFO)
				control.notification(message=msg, time=5000)
			return # xbmc.log('[ script.module.openscrapers ]  Addon update check complete', LOGINFO)
		except:
			log_utils.log(f'[ script.module.openscrapers ] Error:  {print_exc()}', LOGINFO)


class SyncMyAccounts:
	def run(self):
		# xbmc.log('[ script.module.openscrapers ]  Sync "My Accounts" Service Starting...', LOGINFO)
		control.syncMyAccounts(silent=True)
		return # xbmc.log('[ script.module.openscrapers ]  Finished Sync "My Accounts" Service', LOGINFO)

class CheckUndesirablesDatabase:
	def run(self):
		xbmc.log('[ script.module.openscrapers ]  "CheckUndesirablesDatabase" Service Starting...', LOGINFO)
		from openscrapers.modules import undesirables
		try:
			if old_database := undesirables.Undesirables().check_database():
				undesirables.add_new_default_keywords()
		except: xbmc.log(f'Error: {print_exc()}')
		return xbmc.log('[ script.module.openscrapers ]  Finished "CheckUndesirablesDatabase" Service', LOGINFO)

def main():
	while not control.monitor.abortRequested():
		# xbmc.log('[ script.module.openscrapers ]  Service Started', LOGINFO)
		CheckSettingsFile().run()
		CheckUndesirablesDatabase().run()
		SyncMyAccounts().run()
		if control.setting('checkAddonUpdates') == 'true':
			AddonCheckUpdate().run()
			# log_utils.log('[ script.module.opencrapers ]  Addon update check complete', LOGINFO)
		if control.isVersionUpdate():
			control.clean_settings()
			log_utils.log('[ script.module.openscrapers ]  Settings file cleaned complete', LOGINFO)
		break
	SettingsMonitor().waitForAbort()
	# xbmc.log('[ script.module.openscrapers ]  Service Stopped', LOGINFO)

main()
