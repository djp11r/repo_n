# -*- coding: utf-8 -*-

import re, json
import requests

from openscrapers import parse_qs, urlencode

from openscrapers.modules.client import request, parseDOM, scrapePage, agent, UserAgent
from openscrapers.modules import jsunpack
from openscrapers.modules.source_utils import get_release_quality, is_host_valid, check_url, checkHost
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.py_tools import six_decode, ensure_str, ensure_text


"""Example...

from openscrapers.modules import scrape_sources
for source in scrape_sources.process(url, hostDict):
    sources.append(source)

scrape_sources.rescrape(url)

scrape_sources.prepare_link(url)

"""


def unpacked(html):
    unpacked = ''
    if jsunpack.detect(html):
        unpacked = jsunpack.unpack(html)
    return unpacked


def prepare_link(url):
    if not url:
        return
    url = six_decode(url)
    url = "https:" + url if url.startswith('//') else url
    if '2embed.ru' in url:
        url = url.replace('2embed.ru', '2embed.to')
    if 'cloudvid.co' in url:
        url = url.replace('cloudvid.co', 'cloudvideo.tv')
    if 'dood.pm' in url:
        url = url.replace('dood.pm', 'doodstream.com')
    if 'dood.cx' in url:
        url = url.replace('dood.cx', 'doodstream.com')
    if 'dood.to' in url:
        url = url.replace('dood.to', 'doodstream.com')
    if 'dood.so' in url:
        url = url.replace('dood.so', 'doodstream.com')
    if 'eplayvid.com' in url:
        url = url.replace('eplayvid.com', 'eplayvid.net')
    if 'gomostream.com' in url:
        url = url.replace('gomostream.com', 'gomo.to')
    if 'sendit.cloud' in url:
        url = url.replace('sendit.cloud', 'send.cm')
    if 'vidcloud.icu' in url:
        url = url.replace('vidcloud.icu', 'vidembed.io')
    if 'vidcloud9.com' in url:
        url = url.replace('vidcloud9.com', 'vidembed.io')
    if 'vidembed.cc' in url:
        url = url.replace('vidembed.cc', 'vidembed.io')
    if 'vidembed.io' in url:
        url = url.replace('vidembed.io', 'membed.net')
    if 'vidnext.net' in url:
        url = url.replace('vidnext.net', 'vidembed.me')
    if 'vidembed.me' in url:
        url = url.replace('vidembed.me', 'membed.net')
    if 'vidoza.net' in url:
        url = url.replace('vidoza.net', 'vidoza.co')
    #log('scrape_sources - prepare_link link: ' + str(url))
    return url


def process(hostDict, link, host=None, info=None):
    sources = []
    try:
        if link is None: return sources
        link = six_decode(link)
        if link.startswith('//'): link = 'https:%s' % link
        if ' ' in link: link = link.replace(' ', '+')
        # print("getMore url In: {}".format(link))
        link = prepare_link(link)
        host = link if host is None else host
        info = link if info is None else info
        if 'linkbin.me' in host:
            for source in linkbin(link, hostDict, info=info):
                sources.append(source)
        elif any(i in host for i in ['gomo.to', 'gomostream.com', 'gomoplayer.com']):
            for source in gomo(link, hostDict, info=info):
                sources.append(source)
        elif any(i in host for i in ['database.gdriveplayer.us', 'databasegdriveplayer.co', 'series.databasegdriveplayer.co']):
            for source in gdriveplayer(link, hostDict, info=info):
                sources.append(source)
        elif 'vidlink.org' in host:
            for source in vidlink(link, hostDict, info=info):
                sources.append(source)
        elif any(i in host for i in ['goload.pro', 'goload.io', 'membed.net', 'vidembed.me', 'vidembed.io', 'vidembed.cc', 'vidcloud9.com']):
            for source in vidembed(link, hostDict, info=info):
                sources.append(source)
        elif 'voxzer.org' in host:
            for source in voxzer(link, hostDict, info=info):
                sources.append(source)
        elif 'ronemo.com' in host:
            for source in ronemo(link, hostDict, info=info):
                sources.append(source)
        elif any(i in host for i in ['2embed.ru', '2embed.to']):
            for source in twoembed(link, hostDict, info=info):
                sources.append(source)
        elif "cloudvideo.tv" in link:
            for source in cloudvideo(link, hostDict):
                sources.append(source)
        elif "abcvideo.cc" in link:
            for source in abcvideo(link, hostDict):
                sources.append(source)
        elif "vidoza.net" in link:
            for source in vidoza(link, hostDict):
                sources.append(source)
        elif "upstream.to" in link:
            for source in upstream(link, hostDict):
                sources.append(source)
        elif "mixdrop.co" in link:
            for source in mixdrop(link, hostDict):
                sources.append(source)
        elif "mediashore.org" in link:
            for source in mediashore(link, hostDict):
                sources.append(source)
        elif "movcloud" in link:
            for source in movcloud(link, hostDict):
                sources.append(source)
        elif "vidcloud.pro" in link:
            for source in vidcloud_pro(link, hostDict):
                sources.append(source)
        elif 'vidcloud9' in link:
            for source in vidcloud9(link, hostDict):
                sources.append(source)
        elif 'vidsrc' in link:
            for source in vidsrc(link, hostDict):
                sources.append(source)
        elif 'vidsrc.me' in link:
            for source in vidsrc_me(link, hostDict):
                sources.append(source)
        elif 'vidnext.net' in link:
            for source in vidnext_net(link, hostDict):
                sources.append(source)
        elif 'vidoo' in link:
            for source in vidoo(link, hostDict):
                sources.append(source)
        elif 'hls3x.vidcloud9.com' in link:
            for source in hls3x(link, hostDict):
                sources.append(source)
        elif 'fmovies' in link:
            for source in fmovies_to(link, hostDict):
                sources.append(source)
        else:
            valid, host = is_host_valid(host, hostDict)
            if valid:
                quality, info = get_release_quality(link, info)
                if link.startswith('http'):
                    sources.append({'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False})
        return sources
    except Exception:
        #log_utils.log('process', 1)
        return sources


def linkbin(link, hostDict, info=None):
    sources = []
    try:
        html = scrapePage(link).text
        urls = re.findall('<li class="signle-link"><a href="(.+?)" target="_blank">', html)
        for url in urls:
            url = prepare_link(url)
            valid, host = is_host_valid(url, hostDict)
            if valid:
                quality, info = get_release_quality(url, info)
                sources.append({'source': host, 'quality': quality, 'info': info, 'url': url, 'direct': False})
        return sources
    except Exception:
        #log('linkbin', 1)
        return sources


def gomo(link, hostDict, info=None):
    sources = []
    try:
        # domain = re.findall('(?://|\.)(gomo\.to|gomostream\.com|gomoplayer\.com)/', link)[0]
        domain = re.findall(r'(?://|\.)(gomo(?:stream|player|)\.(?:com|to))', html, re.MULTILINE)[0]
        gomo_link = 'https://%s/decoding_v3.php' % domain
        result = request(link, timeout='5')
        tc = re.compile('tc = \'(.+?)\';').findall(result)[0]
        if (tc):
            token = re.compile('"_token": "(.+?)",').findall(result)[0]
            post = {'tokenCode': tc, '_token': token}
            def tsd(tokenCode):
                _13x48X = tokenCode
                # print(_13x48X[6:19]) # get 6 to 19 char
                # print(_13x48X[6:19][::-1]) # revers the srting
                _71Wxx199 = _13x48X[6:19][::-1]
                return _71Wxx199 + "19" + "666979"
            headers = {'Host': domain, 'Referer': link, 'User-Agent': UserAgent, 'x-token': tsd(tc)}
            urls = request(gomo_link, XHR=True, post=post, headers=headers, output='json', timeout='5')
            for url in urls:
                if not url:
                    continue
                url = prepare_link(url)
                headers = {'User-Agent': UserAgent, 'Referer': url}
                if 'gomo.to' in url:
                    url = request(url, headers=headers, output='geturl', timeout='5')
                    if not url:
                        continue
                    if 'gomoplayer.com' in url:
                        html = request(url, headers=headers, timeout='5')
                        unpacked = unpacked(html)
                        links = re.compile('file:"(.+?)"').findall(unpacked)
                        for link in links:
                            if '/srt/' in link:
                                continue
                            quality, info = get_release_quality(link, info)
                            link += '|%s' % urlencode({'Referer': url})
                            sources.append({'source': 'gomoplayer', 'quality': quality, 'info': info, 'url': link, 'direct': True})
                    elif any(i in url for i in ['database.gdriveplayer.us', 'databasegdriveplayer.co', 'series.databasegdriveplayer.co']):
                        for source in gdriveplayer(url, hostDict):
                            sources.append(source)
                    else:
                        valid, host = checkHost(url, hostDict)
                        quality, info = get_release_quality(url, info)
                        sources.append({'source': host, 'quality': quality, 'url': url, 'info': info, 'direct': False})
                        #sources.append({'source': 'gomo', 'quality': 'SD', 'url': url, 'direct': True})
                else:
                    valid, host = checkHost(url, hostDict)
                    if valid:
                        quality, info = get_release_quality(url, info)
                        sources.append({'source': host, 'quality': quality, 'url': url, 'info': info, 'direct': False})
        return sources
    except Exception:
        #log('gomo', 1)
        return sources


def gdriveplayer(link, hostDict, info=None):
    sources = []
    try:
        html = scrapePage(link).text
        servers = parseDOM(html, 'ul', attrs={'class': 'list-server-items'})[0]
        urls = parseDOM(servers, 'a', ret='href')
        for url in urls:
            if not url or url.startswith('/player.php'):
                continue
            url = prepare_link(url)
            valid, host = is_host_valid(url, hostDict)
            if valid:
                quality, info = get_release_quality(url, info)
                sources.append({'source': host, 'quality': quality, 'info': info, 'url': url, 'direct': False})
        return sources
    except:
        return []


def vidembed(link, hostDict, info=None):
    sources = []
    try:
        try:
            html = scrapePage(link).text
            urls = parseDOM(html, 'li', ret='data-video')
            if urls:
                for url in urls:
                    url = prepare_link(url)
                    valid, host = is_host_valid(url, hostDict)
                    if valid:
                        quality, info = get_release_quality(url, info)
                        sources.append({'source': host, 'quality': quality, 'info': info, 'url': url, 'direct': False})
        except:
            pass
        valid, host = is_host_valid(link, hostDict)
        if valid:
            quality, info = get_release_quality(link, info)
            sources.append({'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False})
        return sources
    except Exception:
        #log('vidembed', 1)
        return sources


def vidlink(link, hostDict, info=None):
    sources = []
    try:
        return sources # site for update_views bit needs cfscrape so the links are trash.
        # return sources is added to cock block the urls from being seen lol.
        postID = link.split('/embed/')[1]
        post_link = 'https://vidlink.org/embed/update_views'
        headers = {'User-Agent': UserAgent, 'Referer': link}
        ihtml = request(post_link, post={'postID': postID}, headers=headers, XHR=True)
        if ihtml:
            linkcode = unpacked(ihtml)
            linkcode = linkcode.replace('\\', '')
            links = re.findall(r'var file1="(.+?)"', linkcode)[0]
            stream_link = links.split('/pl/')[0]
            headers = {'Referer': 'https://vidlink.org/', 'User-Agent': UserAgent}
            response = request(links, headers=headers)
            urls = re.findall(r'[A-Z]{10}=\d+x(\d+)\W[A-Z]+=\"\w+\"\s+\/(.+?)\.', response)
            if urls:
                for qual, url in urls:
                    url = stream_link + '/' + url + '.m3u8'
                    qual = qual + ' ' + info if not info == None else qual
                    #log('scrape_sources - process vidlink link: ' + str(url))
                    valid, host = is_host_valid(url, hostDict)
                    if valid:
                        quality, info = get_release_quality(qual, url)
                        sources.append({'source': host, 'quality': quality, 'info': info, 'url': url, 'direct': False})
        return sources
    except Exception:
        #log('vidlink', 1)
        return sources


def get_recaptcha():
    response = requests.get(
        "https://recaptcha.harp.workers.dev/?anchor=https%3A%2F%2Fwww.google.com%2Frecaptcha%2Fapi2%2Fanchor%3Far%3D1%26k%3D6Lf2aYsgAAAAAFvU3-ybajmezOYy87U4fcEpWS4C%26co%3DaHR0cHM6Ly93d3cuMmVtYmVkLnRvOjQ0Mw..%26hl%3Den%26v%3DPRMRaAwB3KlylGQR57Dyk-pF%26size%3Dinvisible%26cb%3D7rsdercrealf&reload=https%3A%2F%2Fwww.google.com%2Frecaptcha%2Fapi2%2Freload%3Fk%3D6Lf2aYsgAAAAAFvU3-ybajmezOYy87U4fcEpWS4C"
    )
    return response.json()["rresp"]


def twoembed(link, hostDict, info=None):
    sources = []
    try:
        token = get_recaptcha()
        headers = {'User-Agent': UserAgent, 'Referer': 'https://www.2embed.to/'}
        r = requests.get(link, headers=headers).text
        items = parseDOM(r, 'a', ret='data-id')
        for item in items:
            try:
                stream = requests.get("https://www.2embed.to/ajax/embed/play", params={"id": item, "_token": token}, headers=headers).json()
                url = stream['link']
                if 'vidcloud.pro' in url:
                    r = request(url, headers={'User-Agent': UserAgent, 'Referer': url})
                    r = re.findall('sources = \[{"file":"(.+?)","type"', r)[0]
                    url = r.replace('\\', '')
                url = prepare_link(url)
                valid, host = is_host_valid(url, hostDict)
                #if valid:
                quality, info = get_release_quality(url, info)
                if url.startswith('http'):
                    sources.append({'source': host, 'quality': quality, 'info': info, 'url': url, 'direct': False})
            except: pass
        return sources
    except:
        # error('twoembed: %s' % link)
        return []


def ronemo(link, hostDict, info=None):
    sources = []
    try:
        html = scrapePage(link).text
        url = re.findall('"link":"(.+?)",', html)[0]
        valid, host = is_host_valid(url, hostDict)
        quality, info = get_release_quality(url, info)
        url += '|%s' % urlencode({'Referer': link})
        sources.append({'source': host, 'quality': quality, 'info': info, 'url': url, 'direct': True})
        return sources
    except Exception:
        #log('ronemo', 1)
        return sources


def voxzer(link, hostDict, info=None):
    sources = []
    try:
        link = link.replace('/view/', '/list/')
        html = scrapePage(link).json()
        url = html['link']
        valid, host = is_host_valid(url, hostDict)
        quality, info = get_release_quality(url, info)
        url += '|%s' % urlencode({'Referer': link})
        sources.append({'source': host, 'quality': quality, 'info': info, 'url': url, 'direct': True})
        return sources
    except Exception:
        #log('voxzer', 1)
        return sources


def rescrape(url): # unused old code saved.
    try:
        html = client.scrapePage(url).text
        link = re.findall(r'(?:file|source)(?:\:)\s*(?:\"|\')(.+?)(?:\"|\')', html)[0]
        return link
    except:
        #log_utils.log('rescrape', 1)
        return url


def movcloud(link, hostDict):
    sources = []
    try:
        url = link.replace('https://movcloud.net/embed/', 'https://api.movcloud.net/stream/')
        url = request(url, headers={'User-Agent': agent(), 'Referer': 'https://movcloud.net'})
        resp = ensure_str(url, errors='replace')
        url = json.loads(resp)
        url = url['data']
        url = url['sources']
        for url in url:
            label = url['label']
            url = url['file']
            quality, info = get_release_quality(label, label)
            if url.startswith('http'):
                sources.append(
                    {'source': 'movcloud', 'quality': quality, 'info': info, 'url': url, 'direct': False,
                     'debridonly': False})
        return sources
    except:
        error('movcloud: %s' % link)
        return []


def vidcloud9(link, hostDict):
    sources = []
    try:
        # print("link:%s" % link)
        if not link.endswith('.m3u8'):
            url = request(link, headers={'User-Agent': agent(), 'Referer': link})
            resp = ensure_str(url, errors='replace')
            # print("resp:%s" % resp)
            url = re.compile('data-video="(.+?)">.+?</li>').findall(resp)
            for url in url:
                if url.startswith('//'):
                    url = 'https:' + url
                if 'vidnext.net' in url:
                    if '&typesub' in url:
                        url = request(link, headers={'User-Agent': agent(), 'Referer': link})
                        resp = ensure_str(url, errors='ignore')
                        url = re.findall("file: '(.+?)'", resp)[0]
                        if url.startswith('http'):
                            sources.append(
                                {'source': 'HLS', 'quality': 'SD', 'info': '', 'url': url,
                                 'direct': False})
                    else:
                        url = request(url, headers={'User-Agent': agent(), 'Referer': link})
                        resp = ensure_str(url, errors='ignore')
                        url = re.findall('data-video="(.+?)">', resp)
                        for url in url:
                            if url.startswith('//'):
                                url = 'https:' + url
                            if 'vidnext.net' in url:
                                url = request(url, headers={'User-Agent': agent(), 'Referer': url})
                                resp = ensure_str(url, errors='ignore')
                                r = re.findall('(ep.+?.m3u8)', resp)
                                for r in r:
                                    url = url.split('ep')[0]
                                    url = url + r
                                    if '.720.m3u8' in url:
                                        quality = '720p'
                                    else:
                                        quality = 'SD'
                                    if url.startswith('http'):
                                        sources.append(
                                            {'source': 'HLS3X', 'quality': quality, 'info': '', 'url': url,
                                             'direct': False})
                            else:
                                valid, host = is_host_valid(url, hostDict)
                                if valid:
                                    quality, info = get_release_quality(url, url)
                                    if url.startswith('http'):
                                        sources.append(
                                            {'source': host, 'quality': quality, 'info': info, 'url': url,
                                             'direct': False})

                elif 'movcloud' in url:
                    url = url.replace('https://movcloud.net/embed/', 'https://api.movcloud.net/stream/')
                    url = request(url, headers={'User-Agent': agent(), 'Referer': 'https://movcloud.net'})
                    url = json.loads(url)
                    url = url['data']
                    url = url['sources']
                    for url in url:
                        label = url['label']
                        url = url['file']
                        quality, info = get_release_quality(label, label)
                        if url.startswith('http'):
                            sources.append(
                                {'source': 'movcloud', 'quality': quality, 'info': info, 'url': url,
                                 'direct': False})
                else:
                    valid, host = is_host_valid(url, hostDict)
                    if valid:
                        quality, info = get_release_quality(url, url)
                        if url.startswith('http'):
                            sources.append(
                                {'source': host, 'quality': quality, 'info': info, 'url': url,
                                 'direct': False})
        # else:
        #     valid, host = is_host_valid(link, hostDict)
        #     sources.append({'source': host, 'quality': '720p', 'info': '', 'url': link, 'direct': True})
        return sources
    except:
        error('vidcloud9: %s' % link)
        return []


def vidcloud_pro(link, hostDict):
    sources = []
    try:
        url = request(link, headers={'User-Agent': agent(), 'Referer': link})
        resp = ensure_str(url, errors='ignore')
        url = re.findall(r'sources = \[{"file":"(.+?)","type"', resp)[0]
        url = url.replace('\\', '')
        valid, host = is_host_valid(link, hostDict)
        if valid:
            quality, info = get_release_quality(url, url)
            if url.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': url,
                     'direct': False})
        return sources
    except:
        error('vidcloud_pro: %s' % link)
        return []


def vidsrc(link, hostDict):
    sources = []
    try:
        # r = cfscraper.get(link, headers={'User-Agent': agent(), 'Referer': 'https://v2.vidsrc.me'}).content
        # r = ensure_text(r, errors='replace')
        r = scrapePage(link).text
        r = re.findall('data-hash="(.+?)"', r)[0]
        r = 'https://v2.vidsrc.me/src/%s' % r
        # r2 = cfscraper.get(r, headers={'User-Agent': agent(), 'Referer': 'https://v2.vidsrc.me'}).content
        # r2 = ensure_text(r2, errors='replace')
        r2 = scrapePage(link).text
        links = re.findall("'player' src='(.+?)'", r2)
        links = [link + '|Referer=https://vidsrc.me' for link in links]
        for url in links:
            url = url if url.startswith('http') else 'https:{0}'.format(url)
            sources.append({'source': 'CDN', 'quality': '720p', 'info': '', 'url': url, 'direct': True})
        return sources
    except:
        error('vidsrc: %s' % link)
        return []


def vidsrc_me(link, hostDict):
    sources = []
    try:
        r = request(link, headers={'User-Agent': agent(), 'Referer': 'https://v2.vidsrc.me'})
        resp = ensure_str(r, errors='ignore')
        r = re.findall('data-hash="(.+?)"', resp)[0]
        r = 'https://v2.vidsrc.me/src/%s' % r
        url = request(r, headers={'User-Agent': agent(), 'Referer': 'https://v2.vidsrc.me'})
        resp = ensure_str(url, errors='ignore')
        url = re.findall("'player' src='(.+?)'", resp)[0]
        url = url + '|Referer=https://vidsrc.me'
        quality, info = get_release_quality(url, url)
        if url.startswith('http'):
            sources.append(
                {'source': 'CDN', 'quality': quality, 'info': info, 'url': url, 'direct': True,
                 'debridonly': False})
        return sources
    except:
        error('vidsrc_me: %s' % link)
        return []


def vidnext_net(link, hostDict):
    sources = []
    try:
        if 'vidnext.net' in link:
            if '&typesub' in link:
                url = request(link, headers={'User-Agent': agent(), 'Referer': link})
                resp = ensure_str(url, errors='ignore')
                url = re.findall("file: '(.+?)'", resp)[0]
                if url.startswith('http'):
                    sources.append(
                        {'source': 'HLS', 'quality': 'SD', 'info': '', 'url': url,
                         'direct': False})
            else:
                url = request(link, headers={'User-Agent': agent(), 'Referer': link})
                resp = ensure_str(url, errors='ignore')
                url = re.findall('data-video="(.+?)">', resp)
                for url in url:
                    if url.startswith('//'):
                        url = 'https:' + url
                    if 'vidnext.net' in url:
                        url = request(url, headers={'User-Agent': agent(), 'Referer': url})
                        resp = ensure_str(url, errors='ignore')
                        r = re.findall('(ep.+?.m3u8)', resp)
                        for r in r:
                            url = url.split('ep')[0]
                            url = url + r
                            if '.720.m3u8' in url:
                                quality = '720p'
                            else:
                                quality = 'SD'
                            if url.startswith('http'):
                                sources.append(
                                    {'source': 'HLS3X', 'quality': quality, 'info': '', 'url': url, 'direct': False,
                                     'debridonly': False})

        else:
            valid, host = is_host_valid(link, hostDict)
            if valid:
                quality, info = get_release_quality(link, link)
                if link.startswith('http'):
                    sources.append(
                        {'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False,
                         'debridonly': False})

        return sources
    except:
        error('vidnext_net: %s' % link)
        return []


def hls3x(link, hostDict):
    sources = []
    try:
        url = request(link, headers={'User-Agent': agent(), 'Referer': link})
        resp = ensure_str(url, errors='ignore')
        r = re.findall('(ep.+?.m3u8)', resp)
        for r in r:
            url = url.split('ep')[0]
            url = url + r
            if '.720.m3u8' in url:
                quality = '720p'
            else:
                quality = 'SD'
            info = get_release_quality(url)
            if url.startswith('http'):
                sources.append(
                    {'source': 'HLS3X', 'quality': quality, 'info': info, 'url': url, 'direct': False,
                     'debridonly': False})
        return sources
    except:
        error('hls3x: %s' % link)
        return []


def vidoo(link, hostDict):
    sources = []
    try:
        url = request(link, headers={'User-Agent': agent(), 'Referer': link})
        resp = ensure_str(url, errors='ignore')
        r = re.findall(r'file:"(.+?)"\},\{file:".+?",label:"(.+?)"', resp)
        for r in r:
            quality, info = get_release_quality(r[1], r[0])
            r = request(r[0], headers={'User-Agent': agent(), 'Referer': link})
            resp = ensure_str(r, errors='ignore')
            r = re.findall('(https://.+?m3u8)', resp)[0]
            if r.startswith('http'):
                sources.append(
                    {'source': 'VIDOO', 'quality': quality, 'info': info, 'url': r, 'direct': False,
                     'debridonly': False})
        return sources
    except:
        error('vidoo: %s' % link)
        return []


def mediashore(link, hostDict):
    sources = []
    try:
        try:
            url = request(link, headers={'User-Agent': agent(), 'Referer': link})
            resp = ensure_str(url, errors='ignore')
            r = re.findall('<title>(.+?)</title>', resp)[0]
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(r, r)
            if r.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': r, 'direct': False,
                     'debridonly': False})
        except:
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(link, link)
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False,
                     'debridonly': False})
        return sources
    except:
        error('mediashore: %s' % link)
        return []


def abcvideo(link, hostDict):
    sources = []
    try:
        try:
            if 'html' in link:
                url = request(link, headers={'User-Agent': agent(), 'Referer': link})
                resp = ensure_str(url, errors='ignore')
                r = re.findall('jwplayer.qualityLabel\', \'(.+?)\'', resp)[0]
                valid, host = is_host_valid(link, hostDict)
                quality, info = get_release_quality(r, r)
                if r.startswith('http'):
                    sources.append(
                        {'source': host, 'quality': quality, 'info': info, 'url': r, 'direct': False,
                         'debridonly': False})
            else:
                url = request(link, headers={'User-Agent': agent(), 'Referer': link})
                resp = ensure_str(url, errors='ignore')
                r = re.findall('<title>(.+?)</title>', resp)[0]
                valid, host = is_host_valid(link, hostDict)
                quality, info = get_release_quality(r, r)
                if r.startswith('http'):
                    sources.append(
                        {'source': host, 'quality': quality, 'info': info, 'url': r, 'direct': False,
                         'debridonly': False})
        except:
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(link, link)
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False,
                     'debridonly': False})
        return sources
    except:
        error('abcvideo: %s' % link)
        return []


def cloudvideo(link, hostDict):
    sources = []
    try:
        try:
            url = request(link, headers={'User-Agent': agent(), 'Referer': link})
            resp = ensure_str(url, errors='ignore')
            r = re.findall('<title>(.+?)</title>', resp)[0]
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(r, r)
            if r.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': r, 'direct': False,
                     'debridonly': False})
        except:
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(link, link)
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False,
                     'debridonly': False})
        return sources
    except:
        error('cloudvideo: %s' % link)
        return []


def mixdrop(link, hostDict):
    sources = []
    try:
        try:
            if '?' in link: link = link.split('?')[0]
            try: url = request(link, headers={'User-Agent': agent(), 'Referer': link})
            except: url = request(link, verifySsl=False, headers={'User-Agent': agent(), 'Referer': link})
            resp = ensure_str(url, errors='ignore')
            r = re.findall('target="_blank">(.+?)</a>', resp)[0]
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(r, r)
            if r.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': r, 'direct': False,
                     'debridonly': False})
        except:
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(link, link)
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False,
                     'debridonly': False})
        return sources
    except:
        error('mixdrop: %s' % link)
        return []


def upstream(link, hostDict):
    sources = []
    try:
        try:
            url = request(link, headers={'User-Agent': agent(), 'Referer': link})
            resp = ensure_str(url, errors='ignore')
            r = re.findall('</i>(.+?)</span>', resp)[0]
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(r, r)
            if r.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': r, 'direct': False,
                     'debridonly': False})
        except:
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(link, link)
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False,
                     'debridonly': False})
        return sources
    except:
        error('upstream: %s' % link)
        return []


def vidoza(link, hostDict):
    sources = []
    try:
        try:
            url = request(link, headers={'User-Agent': agent(), 'Referer': link})
            resp = ensure_str(url, errors='ignore')
            r = re.findall('CONTENT="(.+?)">', resp)[0]
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(r, r)
            if r.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': r, 'direct': False,
                     'debridonly': False})
        except:
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(link, link)
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False,
                     'debridonly': False})
        return sources
    except:
        error('vidoza: %s' % link)
        return []


def fmovies_to(link, hostDict):
    sources = []
    try:
        r = scrapePage(link).text
        # links = re.findall(r'''(?:src|file)[:=]\s*['"]([^"']+)''', r)
        # links = parseDOM(r, 'ul', ret='data-video')
        # links = parseDOM(r, 'ul', attrs={'class': r'list-server-items.*?'})
        links = parseDOM(r, 'iframe', ret='src')
        # log("fmovies_to links: {}".format(links))
        for url in links:
            # url = "%s|%s" % (url, append_headers(self.headers))
            sources.append({'source': 'fmovies', 'quality': '720p', 'info': '', 'url': url, 'direct': True})
        return sources
    except:
        error('fmovies_to: %s' % link)
        return []


def gamovideo(link, hostDict):
    sources = []
    try:
        try:
            # url = request(link, headers={'User-Agent': agent(), 'Referer': link})
            url = scrapePage(link, headers={'User-Agent': agent(), 'Referer': link}).text
            # url = read_write_file(file_n='gomostream.com.html')
            r = re.findall('<Title>(.+?)</Title>', url)
            # print(f'r: {r}')
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(r[0], r[0])
            if r[0].startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': r, 'direct': False,
                     'debridonly': False})
        except:
            valid, host = is_host_valid(link, hostDict)
            quality, info = get_release_quality(link, link)
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False,
                     'debridonly': False})
        return sources
    except:
        error('gamovideo: %s' % link)
        return []


def sgoogle(link, hostDict):
    sources = []
    try:
        if link.startswith('http'):
            sources.append({'source': 'gvideo', 'quality': 'SD', 'info': '', 'url': link,
                            'direct': True})
        return sources
    except:
        return []


def more_rapidvideo(link, hostDict, lang, info):
    if "rapidvideo.com" in link:
        sources = []
        try:
            headers = {
                'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3555.0 Safari/537.36"}
            response = scrapePage(link, headers=headers).text
            test = re.findall(r"""(https:\/\/www.rapidvideo.com\/e\/.*)">""", response)
            numGroups = len(test)
            for i in range(1, numGroups):
                url = test[i]
                valid, host = is_host_valid(url, hostDict)
                q = check_url(url)
                sources.append({'source': host, 'quality': q, 'url': url, 'info': info, 'direct': False})
            return sources
        except:
            return sources
    else:
        return []


def more_cdapl(link, hostDict, lang, info):
    if "cda.pl" in link:
        sources = []
        try:
            headers = {
                'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3555.0 Safari/537.36"}
            response = scrapePage(link, headers=headers).text
            test = parseDOM(response, 'div', attrs={'class': 'wrapqualitybtn'})
            urls = parseDOM(test, 'a', ret='href')
            if urls:
                for url in urls:
                    valid, host = is_host_valid(url, hostDict)
                    q = check_url(url)
                    direct = re.findall("""file":"(.*)","file_cast""", scrapePage(url, headers=headers).text)[
                        0].replace("\\/", "/")
                    sources.append({'source': 'CDA', 'quality': q, 'url': direct, 'info': info, 'direct': True})
            return sources
        except:
            return sources
    else:
        return []


def more_vidnode(link, hostDict):
    sources = []  # By Shellc0de
    try:
        headers = {'Host': 'vidnode.net', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 'Upgrade-Insecure-Requests': '1', 'Accept-Language': 'en-US,en;q=0.9'}
        response = request(link, headers=headers, timeout=5)
        urls = re.findall(r'''\{file:\s*['"]([^'"]+).*?label:\s*['"](\d+\s*P)['"]''', response, re.DOTALL | re.I)
        if urls:
            for url, qual in urls:
                quality, info = get_release_quality(qual, url)
                host = url.split('//')[1].replace('www.', '')
                host = host.split('/')[0].lower()  # 'CDN'
                sources.append({'source': host, 'quality': quality, 'url': url, 'info': info, 'direct': True})
        return sources
    except:
        return sources
