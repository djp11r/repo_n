# -*- coding: UTF-8 -*-

import re

from openscrapers.modules.hindi_sources import scrapePage, get_source_dict, resolve_gen, get_query, query_cleaner
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.client import agent


class source:

    def __init__(self):
        self.name = "desiserials"
        self.domains = ['desiserials.org']
        self.base_link = 'https://www.desi-serials.cc'
        self.headers = {'User-Agent': agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f'From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year}')
        try:
            try:
                url = aliases[0]['url']
                # log(f'show url: {url}')
                if 'desi-serials' in url: return url
            except: pass
            return f'{tvshowtitle}'
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f'From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}')
        try:
            if type(tvdb) == int: return
            if 'episode' in title.lower(): return
            if 'watch-online' in url: return url
            if '|' in tvdb:
                query = get_query(url)
                if re.search(r'crime-patrol', query, re.I): query = f'{query}-episode-best-of-{title}-watch-online'
                elif re.search(r'masterchef-india', query, re.I): query = f'{query}-{title}-watch-online'
                else: query = f'{query}-episode-{title}-watch-online'
                query = query_cleaner(query)
                return f'{self.base_link}/{query}/'
        except:
            error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict):
        # log(f'From: {__name__} url {url}')
        sources = []
        try:
            if not url: return sources
            result = scrapePage(url, headers=self.headers).text
            if not result: return sources
            # read_write_file(read=False, result=result)
            result = parseDOM(result, 'div', attrs={'class': 'post-content'})
            items = parseDOM(result, 'p')
            for item in items:
                urls = parseDOM(item, 'a', attrs={'target': '_blank'}, ret='href')
                # log(f'total: {len(urls)} urls: {urls}')
                final_url = []
                for iurl in urls:
                    if iurl not in final_url: final_url.append(iurl)
                if final_url: sources = get_source_dict(final_url, sources)
            if not sources: log(f'From: {__name__} no sources on url {url}')
            return sources
        except:
            error(f'{__name__}_ sources url: {url} ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return resolve_gen(url)
