# -*- coding: utf-8 -*-
# --[getSum v1.4]--|--[From JewBMX]--
# Lazy Module to make life a little easier.

import re
from html import unescape

from openscrapers.modules.utils import byteify
from openscrapers.modules import log_utils

headers = {'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3555.0 Safari/537.36"}


class GetSum(object):
	_frame_regex = r'(?:iframe|source).+?(?:src)=(?:\"|\')(.+?)(?:\"|\')'
	_datavideo_regex = r'(?:data-video|data-src|data-href)=(?:\"|\')(.+?)(?:\"|\')'
	_filesource_regex = r'(?:file|source)(?:\:)\s*(?:\"|\')(.+?)(?:\"|\')'
	_magnet_regex = r'''(magnet:\?[^"']+)'''
	_timeout = 10

	def findSum(self, text, type=None):
		try:
			self.links = set()
			if not text:
				return
			if re.search(self._frame_regex, text, re.IGNORECASE) or type == 'iframe':
				if links := re.compile(self._frame_regex).findall(text):
					for link in links:
						link = link if link.startswith('http') else f'https:{link}'
						if link in self.links:
							continue
						self.links.add(link)
			if re.search(self._datavideo_regex, text, re.IGNORECASE) or type == 'datavideo':
				if links := re.compile(self._datavideo_regex).findall(text):
					for link in links:
						link = link if link.startswith('http') else f'https:{link}'
						if link in self.links:
							continue
						self.links.add(link)
			if re.search(self._filesource_regex, text, re.IGNORECASE) or type == 'filesource':
				if links := re.compile(self._filesource_regex).findall(text):
					for link in links:
						link = link if link.startswith('http') else f'https:{link}'
						if link in self.links:
							continue
						self.links.add(link)
			if re.search(self._magnet_regex, text, re.IGNORECASE) or type == 'magnet':
				if links := re.compile(self._magnet_regex).findall(text):
					for link in links:
						link = str(byteify(replaceHTMLCodes(link)).split('&tr')[0])
						link = link if link.startswith('magnet') else f'magnet:{link}'
						if link in self.links:
							continue
						self.links.add(link)
			return self.links
		except Exception:
			return self.links


########################################################
########################################################


def logSum(matches):
	number = 0
	for match in matches:
		log_utils.log(f'getSum - logSum:  {number:d}  -  {match}')
		number = number + 1


# Normal = getSum.get(url)
# CFscrape = getSum.get(url, Type='cfscrape')
def get(url, headers=None, Type=None):
	if not headers:
		headers = headers
	if not url:
		return
	if Type == 'client' or Type is None:
		from openscrapers.modules import client
		content = client.request(url, headers=headers)
	if Type == 'cfscrape':
		from openscrapers.modules import cfscrape
		cfscraper = cfscrape.create_scraper()
		content = cfscraper.get(url, headers=headers).content
	if Type == 'redirect':
		import requests
		content = requests.get(url, headers=headers).url
	if content is None:
		log_utils.log(f'getSum - Get ERROR:  No Content Got for:  {str(url)}')
		raise Exception()
	return content


# results = getSum.findSum(text)
# for result in results:
def findSum(text, type=None, timeout=10):
	if not text: return
	getSum = GetSum()
	return results if (results := getSum.findSum(text, type=type)) else []


# results = getSum.findEm(text, '(?:iframe|source).+?(?:src)=(?:\"|\')(.+?)(?:\"|\')')
# for result in results:
def findEm(text, regex):
	if results := re.findall(regex, text, flags=re.DOTALL | re.IGNORECASE):
		return results
	else:
		return []


# results = getSum.findThat(text, 'hhhhh')
# for result in results:
def findThat(text, regex):
	p_reg = re.compile(regex, flags=re.DOTALL | re.IGNORECASE)
	return results if (results := p_reg.findall(text)) else []


def find_match(regex, text, index=0):
	results = re.findall(text, regex, flags=re.DOTALL | re.IGNORECASE)
	return results[index]


def findall(text, regex):
	p_reg = re.compile(regex, re.DOTALL + re.MULTILINE + re.UNICODE)
	return p_reg.findall(text)


def findallIgnoreCase(text, regex):
	p_reg = re.compile(regex, re.DOTALL + re.MULTILINE + re.UNICODE + re.IGNORECASE)
	return p_reg.findall(text)


def regex_get_all(text, start_with, end_with):
	return re.findall(f"(?i)({start_with}" + r"[\S\s]+?" + end_with + ")", text)


def get_sources(text):
	return re.compile(r'sources\s*:\s*\[(.+?)\]').findall(text)


def get_sources_content(text):
	return re.compile(r'\{(.+?)\}').findall(text)


def get_files(text):
	return re.compile(r'''['"]?file['"]?\s*:\s*['"]([^'"]*)''').findall(text)


def get_files2(text):
	return re.findall(r'''['"]file['"]\s*:\s*['"]([^'"]+)''', text)


def get_video(text):
	pattern = r'file(?:\'|\")?\s*(?:\:)\s*(?:\"|\')(.+?)(?:\"|\')'
	match = re.compile(pattern).findall(text)
	return [byteify(url) for url in match]


def replaceHTMLCodes(text):
	text = re.sub(r"(&#[0-9]+)([^;^0-9]+)", "\\1;\\2", text)
	text = unescape(text)
	text = text.replace("&quot;", "\"")
	text = text.replace("&amp;", "&")
	text = text.replace("%2B", "+")
	text = text.replace(r"\/", "/")
	text = text.replace("\\", "")
	text = text.strip()
	return text


def unpacked(url):
	try:
		from openscrapers.modules import client
		from openscrapers.modules import jsunpack
		from openscrapers.modules import log_utils
		unpacked = ''
		html = client.request(url)
		if jsunpack.detect(html):
			unpacked = jsunpack.unpack(html)
			# log_utils.log('WatchWrestling - unpacked: \n' + str(unpacked))
		else:
			log_utils.log('getSum - unpacked - Failed.')
		return unpacked
	except:
		return


def TEST_RUN():
	from openscrapers.modules import jsunpack
	from openscrapers.modules import log_utils
	log_utils.log('#####################################')
	url = 'https://site.com'
	data = get(url, Type='cfscrape')
	packed = find_match(data, r"text/javascript'>(eval.*?)\s*</script>")
	unpacked = jsunpack.unpack(packed)
	log_utils.log(f'---getSum TEST_RUN - unpacked: \n{str(unpacked)}')
	log_utils.log('#####################################')
	return unpacked
