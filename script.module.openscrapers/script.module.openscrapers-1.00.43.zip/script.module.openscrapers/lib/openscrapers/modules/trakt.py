# -*- coding: utf-8 -*-
"""
    OpenScrapers Module
"""

import json
from urllib.parse import quote_plus

# import re
# import threading
# import time
from openscrapers import urljoin

from openscrapers.modules import client
from openscrapers.modules import client_utils
from openscrapers.modules import log_utils
from openscrapers.modules import utils

BASE_URL = 'https://api.trakt.tv'
V2_API_KEY = '42740047aba33b1f04c1ba3893ce805a9ecfebd05de544a30fe0c99fabec972e'
CLIENT_SECRET = 'c7a3e7fdf5c3863872c8f45e1d3f33797b492ed574a00a01a3fadcb3d270f926'
REDIRECT_URI = 'urn:ietf:wg:oauth:2.0:oob'


def __getTrakt(url, post=None):
    try:
        url = url if url.startswith(BASE_URL) else urljoin(BASE_URL, url)
        post = json.dumps(post) if post else None
        headers = {'Content-Type': 'application/json', 'trakt-api-key': V2_API_KEY, 'trakt-api-version': 2}
        result = client.request(url, post=post, headers=headers, output='extended', error=True)
        result = utils.byteify(result)

        resp_code = result[1]
        resp_header = result[2]
        result = result[0]
        if resp_code in ['423', '500', '502', '503', '504', '520', '521', '522', '524']:
            log_utils.log(f'Temporary Trakt Error: {resp_code}', log_utils.LOGWARNING)
            return
        elif resp_code in ['429']:
            log_utils.log(f'Trakt Rate Limit Reached: {resp_code}', log_utils.LOGWARNING)
            return
        elif resp_code in ['404']:
            log_utils.log(f'Object Not Found: {resp_code}', log_utils.LOGWARNING)
            return
        if resp_code not in ['401', '405']:
            return result
    except Exception as e:
        log_utils.log(f'Unknown Trakt Error: {e}', log_utils.LOGWARNING)


def getTraktAsJson(url, post=None):
    try:
        r, res_headers = __getTrakt(url, post)
        r = client_utils.json_loads_as_str(r)
        if 'X-Sort-By' in res_headers and 'X-Sort-How' in res_headers:
            r = sort_list(res_headers['X-Sort-By'], res_headers['X-Sort-How'], r)
        return r
    except:
        pass


def getMovieTranslation(id, lang, full=False):
    try:
        url = f'/movies/{id}/translations/{lang}'
        item = getTraktAsJson(url)[0]
        result = item if full else item.get('title')
        return None if result == 'none' else result
    except:
        log_utils.error()


def getTVShowTranslation(id, lang, season=None, episode=None, full=False):
    try:
        if season and episode: url = f'/shows/{id}/seasons/{season}/episodes/{episode}/translations/{lang}'
        else: url = f'/shows/{id}/translations/{lang}'
        item = getTraktAsJson(url)[0]
        result = item if full else item.get('title')
        return None if result == 'none' else result
    except:
        log_utils.error()


def getMovieAliases(id):
    try:
        return getTraktAsJson(f'/movies/{id}/aliases')
    except:
        return []


def getTVShowAliases(id):
    try:
        return getTraktAsJson(f'/shows/{id}/aliases')
    except:
        return []


def _released_key(item):
    if 'released' in item:
        return item['released'] or '0'
    elif 'first_aired' in item:
        return item['first_aired'] or '0'
    else:
        return '0'

def sort_list(sort_key, sort_direction, list_data):
    reverse = sort_direction != 'asc'
    if sort_key == 'rank':
        return sorted(list_data, key=lambda x: x['rank'], reverse=reverse)
    elif sort_key == 'added':
        return sorted(list_data, key=lambda x: x['listed_at'], reverse=reverse)
    elif sort_key == 'title':
        return sorted(list_data, key=lambda x: x[x['type']].get('title'), reverse=reverse)
    elif sort_key == 'released':
        return sorted(list_data, key=lambda x: _released_key(x[x['type']]), reverse=reverse)
    elif sort_key == 'runtime':
        return sorted(list_data, key=lambda x: x[x['type']].get('runtime', 0), reverse=reverse)
    elif sort_key == 'popularity':
        return sorted(list_data, key=lambda x: x[x['type']].get('votes', 0), reverse=reverse)
    elif sort_key == 'percentage':
        return sorted(list_data, key=lambda x: x[x['type']].get('rating', 0), reverse=reverse)
    elif sort_key == 'votes':
        return sorted(list_data, key=lambda x: x[x['type']].get('votes', 0), reverse=reverse)
    else:
        return list_data


def getGenre(content, type, type_id):
    try:
        r = getTraktAsJson(f'/search/{type}/{type_id}?type={content}&extended=full')
        return r[0].get(content, {}).get('genres', [])
    except:
        log_utils.error()
        return []


def SearchMovie(title, year='', full=False):
    try:
        url = '/search/movie?query=%s' % quote_plus(title)
        if year:
            url += '&year=%s' % year
        if full:
            url += '&extended=full'
        return getTraktAsJson(url)
    except:
        return


def SearchTVShow(title, year='', full=False):
    try:
        url = '/search/show?query=%s' % quote_plus(title)
        if year:
            url += '&year=%s' % year
        if full:
            url += '&extended=full'
        return getTraktAsJson(url)
    except:
        return


def SearchEpisode(title, season, episode, full=False):
    try:
        url = '/search/%s/seasons/%s/episodes/%s' % (title, season, episode)
        if full:
            url += '&extended=full'
        return getTraktAsJson(url)
    except:
        return


def SearchAll(title, year='', full=False):
    try:
        return SearchMovie(title, year, full) + SearchTVShow(title, year, full)
    except:
        return


def getEpisodeRating(imdb, season, episode):
    try:
        if not imdb.startswith('tt'): imdb = f'tt{imdb}'
        url = f'/shows/{imdb}/seasons/{season}/episodes/{episode}/ratings'
        r = getTraktAsJson(url)
        r1 = r.get('rating', '0')
        r2 = r.get('votes', '0')
        return str(r1), str(r2)
    except:
        return
