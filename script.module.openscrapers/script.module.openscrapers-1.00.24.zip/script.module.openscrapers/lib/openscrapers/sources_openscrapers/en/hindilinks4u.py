# -*- coding: UTF-8 -*-

# import json
import re

# from openscrapers import urlencode, quote_plus

import requests
from openscrapers.modules import client, log_utils
from openscrapers.modules.hindi_sources import scraper_debug, get_source_dict, resolve_gen, host


class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "hindilinks4u"
        self.domains = ['hindilinks4u.to']
        self.base_link = 'https://www.hindilinks4u.to'
        self.search_link = '/feed/?s=%s&submit=Search'
        self.headers = {'User-Agent': client.agent(), }

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            # scraper_debug("title: {} localtitle: {}".format(title, localtitle))
            scrape = title.lower().replace(' ', '-')
            start_url = "%s/%s-%s/" % (self.base_link, scrape, year)
            # print('movie url: {}'.format(start_url))
            return start_url
        except:
            log_utils.error(f'{__name__}_ movie: ')
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # scraper_debug("From: {} \nimdb {} \ntvdb {}\n tvshowtitle {}, localtvshowtitle {}, aliases {}, year {} ".format(self.name, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))
        try:
            query = '%s' % (tvshowtitle)
            url = query
            # scraper_debug('>>> #### 0AAAA - hindilinks4u EP url : %s' % ( url))
            return url
        except:
            log_utils.error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # scraper_debug("From: {} \ntvdb: {}, title: {}\nurl: {} , season: {}, episode: {}".format(self.name, tvdb, title, url, season, episode))
        try:
            if type(tvdb) == int: return
            if '|' in tvdb:
                # scraper_debug("type hindilinks4u tvdb %s" % type(tvdb))
                # tvdb = tvdb.split('|')
                # ch_name = tvdb[0]
                url = url.lower().replace(' season %s' % season, '').replace(' ', '-').replace('.', '')
                if 'episode' in title.lower():
                    # title = title.lower().replace(' ', '').replace('episode', '')
                    query = "episode/%s-s%se%s" % (url, season, episode)
                    url = '%s/%s/' % (self.base_link, query)
                    # scraper_debug('\nout episode url :  %s \nepisode: %s' % (url, episode))
                    return url
            else: return
        except:
            log_utils.error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict, hostprDict):
        # scraper_debug("From: {} \nurl {}".format(self.name, url))
        sources = []
        try:
            if not url: return sources
            # scraper_debug("url: {}".format(url))
            result = requests.get(url, headers=self.headers).text
            if not result: return sources
            items = re.findall('data-href=."(.*?)."', result)
            # result = client.parseDOM(result, 'div', attrs = {'class': 'entry-content rich-content'})
            # result += client.parseDOM(result, 'div', attrs = {'id': 'player2'})
            # scraper_debug(result)
            # items += client.parseDOM(result, 'p')
            # scraper_debug(items)
            for item in items:
                # scraper_debug(item)
                # try: urls = client.parseDOM(item, 'a', ret = 'href')
                # except: urls = list(item)
                # scraper_debug('item: %s type : %s' % (item, type(item)))
                # urls = [item]
                # scraper_debug('item: %s type : %s' % (urls, type(urls)))
                # furls = []
                # vidhost = None
                # for j in range(0, len(urls)):
                #     scraper_debug('....\n%s' % urls[j])
                #     furls.append(urls[j])

                if item:
                    sources = get_source_dict([item], sources)
            return sources
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # scraper_debug('In type of url {} url: {}'.format(type(url), url))
        url = resolve_gen(url)
        return url
