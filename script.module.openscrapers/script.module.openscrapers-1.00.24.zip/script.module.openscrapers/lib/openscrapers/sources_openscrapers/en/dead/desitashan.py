# -*- coding: UTF-8 -*-

import re
import traceback

try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import quote_plus

from openscrapers.modules import client, log_utils, genericresolver, source_utils


class source:

    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.name = "desitashan"
        self.domains = ['desitashan.plus']
        self.base_link = 'http://www.desitashan.plus'
        self.search_link = '/?s=%s+Video+Watch+Online&submit=Search'

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log_utils.log("!!!!!!! yodesi \n{} ... \n{} .. \n{}\n {} {} {}  ".format(imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))
        try:
            query = '%s' % (tvshowtitle)
            url = query
            # log_utils.log('>>> #### 0AAAA - yodesi EP url : %s' % ( url))
            return url
        except:
            log_utils.log('yodesi tvshow Exception : %s' % (traceback.format_exc()))
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            title = title.replace('(SET)', '')
            query = '%s %s' % (title, episode)
            #log_utils.debug('query @@ [%s]' % query, __name__)
            query = self.search_link % (quote_plus(query))
            log_utils.debug('url query @@ [%s]' % query, __name__)
            result = client.request(self.base_link + query)

            #log_utils.debug('result @@ [%s]' % result, __name__)
            result = result.decode('iso-8859-1').encode('utf-8')

            #log_utils.debug('result 28 @@ [%s]' % result, __name__)
            result = result.replace('\n', '').replace('\t', '')

            #log_utils.debug('result 31 @@ [%s]' % result, __name__)
            items = client.parseDOM(result, 'item')

            log_utils.debug('items @@ [%s]' % items, __name__)
            cleanedTitle = cleantitle.get('%s %s' % (title, episode))

            for item in items:
                linkTitle = client.parseDOM(item, 'title')[0]
                linkTitle = cleantitle.get(linkTitle).replace('videowatchonline', '')
                if cleanedTitle == linkTitle:
                    self.srcs.extend(self.source(item))
            return self.srcs
        except:
            log_utils.log('yodesi sources Exception : %s' % (traceback.format_exc()))
            return sources

    def source(self, item):
        try:
            srcs = []

            links = client.parseDOM(item, 'p', attrs={'style':'text-align: center;'})

            for link in links:
                quality = 'SD'
                if 'span' in link:
                    if 'HD' in link:
                        quality = 'HD'
                    continue

                urls = client.parseDOM(link, 'a', ret='href')

                if len(urls) > 0:

                    for i in range(0, len(urls)):
                        urls[i] = client.urlRewrite(urls[i])

                    host = client.host(urls[0])
                    url = "##".join(urls)

                    srcs.append({'source': host, 'parts': str(len(urls)), 'quality': quality, 'scraper': self.name, 'url': url, 'direct': False})
                    urls = []
            log_utils.debug('SOURCES [%s]' % srcs, __name__)
            return srcs
        except:
            log_utils.log('yodesi getunpackurl Exception : %s' % (traceback.format_exc()))
            return


    def resolve(self, url):
        # url = genericresolver.resolve(url)
        return url
