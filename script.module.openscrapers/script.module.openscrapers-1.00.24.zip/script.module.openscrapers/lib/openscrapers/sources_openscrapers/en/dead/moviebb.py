# -*- coding: UTF-8 -*-

import re
import base64

from six import ensure_text
from openscrapers import parse_qs, urljoin, urlparse, urlencode, quote_plus, unquote

from openscrapers.modules import client
from openscrapers.modules import cleantitle
from openscrapers.modules import source_utils
from openscrapers.modules import log_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['moviebb.net']
        self.base_link = 'https://moviebb.net'
        self.search_link = '/search-movies/%s.html'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            log_utils.error(f'{__name__}_ movie: ')
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            log_utils.error(f'{__name__}_ tvshow: ')
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None:
                return
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            log_utils.error(f'{__name__}_ episode: ')
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            hostDict = hostprDict + hostDict
            sources = []
            if url is None:
                return sources
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            year = data['premiered'].split('-')[0] if 'tvshowtitle' in data else data['year']
            query = '%s season %s' % (title, data['season']) if 'tvshowtitle' in data else title
            check_title = cleantitle.get(query)
            url = self.base_link + self.search_link % cleantitle.get_utf8(query)
            html = client.scrapePage(url).text
            #log_utils.log('moviebb html: ' + html)
            results = client.parseDOM(html, 'div', attrs={'class': 'itemInfo'})
            results = [(client.parseDOM(i, 'a', ret='href'), client.parseDOM(i, 'a'), re.findall('(\d{4})', i)) for i in results]
            results = [(i[0][0], i[1][0], i[2][0]) for i in results if len(i[0]) > 0 and len(i[1]) > 0 and len(i[2]) > 0]
            url = [i[0] for i in results if check_title == cleantitle.get(i[1]) and year == i[2]][0]
            if 'tvshowtitle' in data:
                # log_utils.log(f'moviebb url: {url} ')
                sepi = 'season-%1d/episode-%1d.html' % (int(data['season']), int(data['episode']))
                data = client.scrapePage(url).text
                link = client.parseDOM(data, 'a', ret='href')
                url = [i for i in link if sepi in i][0]
            r = client.scrapePage(url).text
            try:
                v = re.findall(r'document.write\(Base64.decode\("(.+?)"\)', r)[0]
                b64 = base64.b64decode(v)
                b64 = ensure_text(b64, errors='ignore')
                link = client.parseDOM(b64, 'iframe', ret='src')[0]
                link = link.replace('\/', '/')
                host = re.findall('([\w]+[.][\w]+)$', urlparse(link.strip().lower()).netloc)[0]
                host = client.replaceHTMLCodes(host)
                valid, hoster = source_utils.is_host_valid(host, hostDict)
                if valid:
                    sources.append({'source': hoster, 'quality': 'SD', 'language': 'en', 'url': link, 'direct': False, 'debridonly': False})
            except:
                log_utils.error(f'{__name__}_ sources: ')
                pass
            try:
                r = client.parseDOM(r, 'div', {'class': 'server_line'})
                r = [(client.parseDOM(i, 'a', ret='href')[0], client.parseDOM(i, 'p', attrs={'class': 'server_servername'})[0]) for i in r]
                if r:
                    for i in r:
                        host = re.sub('Server|Link\s*\d+', '', i[1]).lower()
                        host = client.replaceHTMLCodes(host)
                        if 'other' in host: continue
                        if host in str(sources):
                            continue
                        link = i[0].replace('\/', '/')
                        valid, hoster = source_utils.is_host_valid(host, hostDict)
                        if valid:
                            sources.append({'source': hoster, 'quality': 'SD', 'language': 'en', 'url': link, 'direct': False, 'debridonly': False})
            except:
                log_utils.error(f'{__name__}_ sources: ')
                pass
            return sources
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return sources


    def resolve(self, url):
        if any(x in url for x in self.domains):
            try:
                r = client.scrapePage(url).text
                try:
                    v = re.findall(r'document.write\(Base64.decode\("(.+?)"\)', r)[0]
                    b64 = base64.b64decode(v)
                    b64 = ensure_text(b64, errors='ignore')
                    try:
                        url = client.parseDOM(b64, 'iframe', ret='src')[0]
                    except:
                        url = client.parseDOM(b64, 'a', ret='href')[0]
                    url = url.replace('///', '//')
                except:
                    u = client.parseDOM(r, 'div', attrs={'class': 'player'})
                    url = client.parseDOM(u, 'a', ret='href')[0]
            except:
                log_utils.error(f'{__name__}_ resolve: ')
            return url
        else:
            return url


