# -*- coding: utf-8 -*-
"""
	OpenScrapers Module
"""
from openscrapers.modules.control import monitor, setting, isVersionUpdate, clean_settings
from openscrapers.modules.log_utils import log

def main():
	from openscrapers.modules.service_functions import SettingsMonitor, CheckSettingsFile, CheckUndesirablesDatabase, SyncMyAccounts
	while not monitor.abortRequested():
		# log('[ script.module.openscrapers ]  Service Started', LOGINFO)
		CheckSettingsFile().run()
		CheckUndesirablesDatabase().run()
		SyncMyAccounts().run()
		if setting('checkAddonUpdates') == 'true':
			from openscrapers.modules.service_functions import AddonCheckUpdate
			AddonCheckUpdate().run()
			# log('[ script.module.opencrapers ]  Addon update check complete', LOGINFO)
		if isVersionUpdate():
			clean_settings()
			log('[ script.module.openscrapers ]  Settings file cleaned complete', LOGINFO)
		break
	SettingsMonitor().waitForAbort()
	# log('[ script.module.openscrapers ]  Service Stopped', LOGINFO)

main()
