# -*- coding: UTF-8 -*-

from openscrapers.modules import client
from openscrapers.modules import cleantitle
from openscrapers.modules import log_utils
from openscrapers.modules import scrape_source
from openscrapers import urljoin


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['watchseriess.net']
        self.base_link = 'https://watchseriess.net'
        self.tvshow_link = '/series/%s-season-%s-episode-%s'
        self.headers = {'User-Agent': client.randomagent(), 'Referer': self.base_link}


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            movie_title = cleantitle.geturl(title)
            url = self.base_link + '/series/%s-episode-0' % movie_title
            return url
        except Exception:
            #log_utils.log('movie', 1)
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = cleantitle.geturl(tvshowtitle)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return
            url = urljoin(self.base_link, self.tvshow_link % (url, season, episode))
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url is None:
                return sources
            hostDict = hostprDict + hostDict
            html = client.scrapePage(url).text
            links = client.parseDOM(html, 'div', attrs={'class': 'anime_muti_link'})[0]
            links = client.parseDOM(links, 'a', ret='data-video')
            for link in links:
                for source in scrape_source.getMore(link, hostDict):
                    sources.append(source)
            return sources
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return sources


    def resolve(self, url):
        return url


