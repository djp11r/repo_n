# -*- coding: UTF-8 -*-

# import json
import re

# try: from urllib import quote_plus
# except ImportError: from urllib.parse import quote_plus
import requests
from openscrapers.modules import client, log_utils
from openscrapers.modules.hindi_sources import scraper_debug, get_source_dict, urlRewrite, resolve_gen, host


class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "desitelly"
        self.domains = ['desitellybox.me']
        self.base_link = 'https://www.desitellybox.me'
        self.headers = {'User-Agent': client.agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # scraper_debug("From: {} \nimdb {} \ntvdb {}\n tvshowtitle {}, localtvshowtitle {}, aliases {}, year {} ".format(self.name, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))
        try:
            # query = '%s' % tvshowtitle
            # url = query
            # scraper_debug('>>> #### 0AAAA - desitelly EP url : %s' % ( url))
            return '%s' % tvshowtitle
        except:
            log_utils.error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # scraper_debug("From: {} url {} ... \nimdb {} .. tvdb {}\n title {}, premiered {}, season {}, episode {} ".format(self.name, url, imdb, tvdb, title, premiered, season, episode))
        try:
            if type(tvdb) == int:
                return
            if '|' in tvdb:
                # scraper_debug("type desitelly tvdb %s" % type(tvdb))
                # tvdb = tvdb.split('|')
                # ch_name = tvdb[0]
                # title = tvdb[1].lower().replace(' ', '-')
                title = title.lower().replace(' ', '-').replace('.', '')
                furl = '%s-%s-episode-watch-online/' % (url, title)
                if 'episode' in title.lower():
                    furl = '%s-watch-online-%s/' % (url, title)
                url = furl.lower().replace(' ', '-').replace('.', '').replace('---', '-')
                url = "%s/%s" % (self.base_link, url)
                # print('url: {}'.format(url))
                return url
            else: return
        except:
            log_utils.error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict, hostprDict):
        # scraper_debug("From: {} \nurl {}".format(self.name, url))
        sources = []
        try:
            if not url: return sources
            # result = requests.get(url, headers=self.headers).text
            result = client.r_request(url).text
            if not result:
                return sources
            result = client.parseDOM(result, 'div', attrs={'class': 'entry_content'})
            # scraper_debug(result)
            items = client.parseDOM(result, 'p')
            # scraper_debug(items)
            for item in items:
                # scraper_debug(item)
                urls = client.parseDOM(item, 'a', ret='href')
                # scraper_debug('....\n%s' % urls)
                furls = []
                vidhost = None
                for j in range(0, len(urls)):
                    # scraper_debug('....\n%s' % urls[j])
                    try:
                        headers = {'Referer': urls[j]}
                        self.headers.update(headers)
                        result = requests.get(urls[j], headers=self.headers).text
                        if result:
                            links = client.parseDOM(result, 'iframe', ret='src')
                            for link in links:
                                if 'vkprime' in link or 'speed' in link or 'watchvideo.us' in link:
                                    vidhost = host(link)
                                    furls.append(link)
                                elif 'flow.' in link:
                                    # vidhost = 'CDN'
                                    furls.append(urls[j])
                    except:
                        log_utils.error('%s_ sources: ' % __name__)
                if len(furls) > 0:
                    sources = get_source_dict(furls, sources, vidhost)
            # dumper = dumper
            # scraper_debug('SOURCES \n\n%s' % json.dumps(sources, default = dumper, indent = 2))
            return sources
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # scraper_debug('In type of url {} url: {}'.format(type(url), url))
        url = resolve_gen(url)
        return url
