# -*- coding: UTF-8 -*-

import re

from openscrapers.modules.client import agent, parseDOM, request
from openscrapers.modules.hindi_utils import get_source_dict, resolve_gen
from openscrapers.modules.log_utils import error


class source:

    def __init__(self):
        self.name = "hindilinks4u"
        self.domains = ['hindilinks4u.hair']
        self.base_link = 'https://hindilinks4u.hair'
        self.search_link = '/?s=%s'
        self.headers = {'User-Agent': agent(), }

    def movie(self, imdb, title, localtitle, aliases, year):
        # log(f'From: {__name__}\nimdb: {imdb}\ntitle: {title}\nlocaltitle: {localtitle}\naliases: {aliases}\nyear: {year}')
        try:
            # log(f'title: {repr(title)} year: {repr(year)}')
            scrape = title.lower().replace(' ', '-')
            return f'{self.base_link}/{scrape}-{year}/'
        except:
            error(f'{__name__}_ movie: ')
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f'From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year}')
        try:
            return f'{tvshowtitle}'
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f'From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}')
        try:
            # if type(tvdb) == int: return
            # if '|' not in tvdb: return
            url = url.lower().replace(f' season {season}', '').replace(' ', '-').replace('.', '')
            if 'episode' in title.lower():
                # log(f'episode url:  {url}\nseason: {season} episode: {episode}')
                query = f'episode/{url}-s{season}e{episode}'
                return f'{self.base_link}/{query}/'
        except:
            error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict):
        # log(f'From: {__name__} url {url}')
        sources = []
        try:
            if not url: return sources
            result = request(url, headers=self.headers)
            if not result: return sources
            # items = re.findall('data-href=."(.*?)."', str(result))
            # result = parseDOM(result, 'div', attrs = {'class': 'entry-content rich-content'})
            items = parseDOM(result, 'ul', attrs={'id': 'video_tabs'})
            # log(f'1total: {len(items)} items: {repr(items)}')
            items += parseDOM(result, 'div', attrs={'id': 'player2'})
            # log(f'2total: {len(items)} result: {repr(items)}')
            items += parseDOM(result, 'div', attrs={'itemprop': 'description'})
            # log(f'3total: {len(items)} items: {repr(items)}')
            for item in items:
                if urls := re.findall(r'href=[\'"]?([^\'" >]+)', str(item), re.I):
                    for url in urls:
                        # print(f'url: {url}')
                        url = f'{url}|Referer={self.base_link}'
                        if final_url := [str(url)]:
                            sources = get_source_dict(final_url, sources)
                if urls := re.findall('src="(.*?)"', str(item), re.I):
                    for url in urls:
                        url = f'{url}|Referer={self.base_link}'
                        if final_url := [str(url)]:
                            sources = get_source_dict(final_url, sources)
            return sources
        except:
            error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return resolve_gen(url)
