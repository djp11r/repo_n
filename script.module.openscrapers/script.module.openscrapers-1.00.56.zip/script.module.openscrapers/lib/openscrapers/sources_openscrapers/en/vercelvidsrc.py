# -*- coding: utf-8 -*-
"""
    **Created by Tempest**
    **If you see this in a addon other than Tempest and says it was
    created by someone other than Tempest they stole it from me**
"""
import random
import re
# import traceback
from openscrapers import parse_qs, urljoin, urlencode
from openscrapers.modules import client
from openscrapers.modules import dom_parser
from openscrapers.modules import source_utils
from openscrapers.modules import log_utils

# from openscrapers import custom_base_link
# custom_base = custom_base_link(__name__)


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['vercel.app']
        baselink = ['https://api-movie-source.vercel.app', 'https://vidsrc-api-sooty.vercel.app', 'https://vidsrc-api-chi.vercel.app', 'https://vidsrc-api-mu.vercel.app', 'https://vidsrc-api-eight.vercel.app', 'https://vidsrc-api-rosy.vercel.app']
        blink = random.choice(baselink)
        # blink = 'https://vidsrc-api-rosy.vercel.app'
        self.base_link = f'{blink}/vidsrc/%s'
        '''example url (movie) : f'{blink}/streams/ttXXXXXX'
            example url (series) : f'{blink}/streams/ttXXXXXX?s=1&e=2'''
        self.headers = {'User-Agent': client.agent(), 'Referer': self.base_link}

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict):
        sources = []
        try:
            if url is None: return sources
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            if not data['imdb'] or data['imdb'] == '0': return sources
            if 'tvshowtitle' in data: query = '%s?s=%s&e=%s' % (data['imdb'], data['season'], data['episode'])
            else: query = data['imdb']

            url = urljoin(self.base_link, query)
            # log_utils.log('VIDSRC url: ' + repr(url))
            items = client.scrapePage(url, self.headers).json
            # log_utils.log('VIDSRC r: ' + r)
            for item in items.get('sources'):
                sour_item = item.get('data')
                # log_utils.log('VIDSRC sour_item: ' + repr(sour_item))
                host = item.get('name')
                url = sour_item.get('stream')
                if url:
                    # log_utils.log('VIDSRC url: ' + repr(url))
                    furl = f'{url}|{urlencode(self.headers)}'
                    sources.append({'source': host, 'url': furl, 'direct': True, 'info': '', 'quality': '720p'})
            return sources
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        data = client.scrapePage(url, self.headers).text
        #log_utils.log('VIDSRC data: ' + data)
        try: link = re.findall('"file": "(.+?)"', data)[0]
        except: link = re.findall("'player' src='(.+?)'", data)[0]
        #link = link + '|Referer=https://v2.vidsrc.me'
        url = link if link.startswith('http') else f'https:{link}'
        #log_utils.log('VIDSRCurl: ' + repr(url))
        return url