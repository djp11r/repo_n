# -*- coding: UTF-8 -*-

import os
from traceback import print_exc
from pkgutil import walk_packages
from urllib.parse import parse_qs, urljoin, urlparse, urlencode, quote, unquote, quote_plus, unquote_plus, parse_qsl

try:
	from openscrapers.modules.control import setting as getSetting, joinPath
	from openscrapers.modules.log_utils import log, error
	from openscrapers.modules import cfscrape

	cfScraper = cfscrape.create_scraper()
	debug = getSetting('debug.enabled') == 'true'
	provider = getSetting('module.provider').lower()
	testing = False
except:
	from .modules.log_utils import log, error
	LOGWARNING = 'LOGWARNING'
	__addon__ = None
	debug = True
	testing = True
	provider = 'sources_openscrapers'
	joinPath = os.path.join
	HostedMediaFile = []
# print(f'testing : {testing} provider: {provider}')
hindi_providers = ('desirulez', 'desicinemas', 'serialghar', 'watchapne', 'desiserials', 'desitelly', 'yodesi', 'playdesi')
sourceFolder = 'sources_openscrapers'
# testing = True

def sources(ret_all=False, media_type=None, vid_type=None):
	try:
		# log(f'ret_all: {ret_all} media_type: {media_type} vid_type: {vid_type}')
		sourceDict = []
		sourceDict_append = sourceDict.append
		sourceFolderLocation = joinPath(os.path.dirname(__file__), sourceFolder)
		# sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
		not_usefull = []
		not_usefull_append = not_usefull.append
		for loader, module_name, is_pkg in walk_packages([joinPath(sourceFolderLocation, 'en')]):
			# if testing:
			try:
				module = loader.find_module(module_name).load_module(module_name)
				module = module.source()
				# log(f'module: {module}')
			except: log(f'Error: Loading module: "{module_name}": {print_exc()}')
			if is_pkg: continue
			if not ret_all and not enabledCheck(module_name): continue
			if vid_type and media_type == 'episode' and module_name not in hindi_providers: continue
			elif not vid_type and module_name in hindi_providers: continue
			# if ret_all or enabledCheck(module_name):
			try:
				module = loader.find_module(module_name).load_module(module_name)
				# log(f'media_type: {media_type} module_name: {module_name} is_pkg: {is_pkg} loader: {loader} ')
				if media_type == 'episode':
					try:
						if getattr(module.source(), 'tvshow'):
							sourceDict_append((module_name, module.source))
					except: not_usefull_append(module_name)
				elif media_type == 'movie':
					try:
						if getattr(module.source(), 'movie'):
							sourceDict_append((module_name, module.source))
					except: not_usefull_append(module_name)
				else:
					sourceDict_append((module_name, module.source))
				# sourceDict_append((module_name, module.source()))
			except Exception as e:
				log(f'Error: Loading module: "{module_name}": {print_exc()}')
		if debug: log(f'for media_type: {media_type} usefull Providers: {len(sourceDict)} not usefull Providers: {len(not_usefull)}')
		return sourceDict
	except:
		log(f'Error: sources: "{print_exc()}"')
		return []

def enabledCheck(module_name):
	try:
		return getSetting(f'provider.{module_name}') == 'true'
	except:
		# error()
		return True


def pack_sources(sourceSubFolder='torrents'):
	return []

def getScraperFolder():
	try:
		sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
		sourceSubFolders = [x for x in sourceSubFolders if x not in ['__pycache__', 'help', 'modules', 'cfscrape', 'pyaes']]
		return [i for i in sourceSubFolders if 'openscrapers' in i.lower()][0]
	except:
		error('getScraperFolder: ')
		return 'sources_openscrapers'

def providerSources():
	sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
	return getModuleName(sourceSubFolders)


def providerNames():
	providerList = []
	append = providerList.append
	# provider = getSetting('module.provider')
	sourceFolder = getScraperFolder()
	sourceFolderLocation = joinPath(os.path.dirname(__file__), sourceFolder)
	sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
	for i in sourceSubFolders:
		for loader, module_name, is_pkg in walk_packages([joinPath(sourceFolderLocation, i)]):
			if is_pkg: continue
			correctName = module_name.split('_')[0]
			append(correctName)
	return providerList


def getAllHosters():
	def _sources(sourceFolder, append):
		sourceFolderLocation = os.path.join(os.path.dirname(__file__), sourceFolder)
		sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
		for i in sourceSubFolders:
			for loader, module_name, is_pkg in walk_packages([os.path.join(sourceFolderLocation, i)]):
				if is_pkg: continue
				try: mn = str(module_name).split('_')[0]
				except: mn = str(module_name)
				append(mn)
	sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
	appendList = []
	append = appendList.append
	for item in sourceSubFolders:
		if item not in ['__pycache__', 'modules', 'cfscrape', 'pyaes']:
			_sources(item, append)
	return list(set(appendList))


def getModuleName(scraper_folders):
	nameList = []
	append = nameList.append
	for s in scraper_folders:
		if s not in ['__pycache__', 'modules', 'cfscrape', 'pyaes']:
			try: append(s.split('_')[1].lower().title())
			except: pass
	return nameList


def custom_base_link(scraper):
	try:
		url = getSetting(f'url.{scraper}')
		url = url[:-1] if url and url.startswith('http') else None
	except:
		url = None
	return url



def getapi_keys():
	from random import choice
	api_keys = {'api_keys': {}}
	api_keys['api_keys']['trakt.client'] = getSetting('trakt.client') or '1038ef327e86e7f6d39d80d2eb5479bff66dd8394e813c5e0e387af0f84d89fb'
	api_keys['api_keys']['trakt.secret']= getSetting('trakt.secret') or '8d27a92e1d17334dae4a0590083a4f26401cb8f721f477a79fd3f218f8534fd1'
	api_keys['api_keys']['fanart']= getSetting('fanart') or 'cf3429b06e1bbccc9d1e1b86b32fc51a'
	api_keys['api_keys']['tmdb']= getSetting('tmdb') or '05a454b451f2f9003fbca293744e4a85'
	api_keys['api_keys']['tmdb.user'] = getSetting('tmdb.user') or 'aaaas'
	api_keys['api_keys']['tmdb.pw'] = getSetting('tmdb.pw') or '6666'
	api_keys['api_keys']['opensubs.user'] = getSetting('opensubs.user') or 'aaaajjjj0'
	api_keys['api_keys']['opensubs.pw'] = getSetting('opensubs.pw') or '6666Mill_'
	api_keys['api_keys']['imdbuser'] = getSetting('imdbuser') or '56044779'
	api_keys['api_keys']['mdblist'] = getSetting('mdblist') or 'osscknixflg2dogpr271ujz18'
	api_keys['api_keys']['simkltoken'] = getSetting('simkltoken') or '110460fa96e0cb8c6a4768de14983374376090247ba4a55fb55ac66c26e3b732'
	# api_keys['api_keys']['filepursuittoken'] = getSetting('filepursuit.api') or 'e1235ccc65msh9c6da42a2ff1797p199cefjsnaa4033afc078'
	# api_keys['api_keys']['gdrivetoken'] = getSetting('gdrive.cloudflare_url') or choice(['https://gd.djp97s.workers.dev', 'https://wandering-river-0edc.rrosajp4.workers.dev'])
	api_keys['api_keys']['tvdb'] = getSetting('tvdb') or choice(['06cff30690f9b9622957044f2159ffae', '1D62F2F90030C444', '7R8SZZX90UA9YMBU'])
	return api_keys


def get_creden():
	trakt = {'trakt': {}}
	trakt['trakt']['token'] = getSetting('trakt.token')
	trakt['trakt']['user'] = getSetting('trakt.user')
	trakt['trakt']['refresh'] = getSetting('trakt.refresh')
	trakt['trakt']['expires'] = getSetting('trakt.expires')
	return dict(trakt, **getapi_keys())