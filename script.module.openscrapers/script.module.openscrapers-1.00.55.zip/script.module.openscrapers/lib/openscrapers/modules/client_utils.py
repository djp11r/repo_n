# -*- coding: utf-8 -*-


from html import unescape
import re
import json
try:
    from openscrapers.modules.py_tools import ensure_str
    from openscrapers.modules.dom_parser import parseDOM
    from openscrapers.modules import jsunpack
    from openscrapers.modules import unjuice
    from openscrapers.modules.utils import byteify
    from openscrapers.modules.log_utils import error, log
except:
    from .modules.py_tools import ensure_str
    from .modules.dom_parser import parseDOM
    from .modules import jsunpack
    from .modules import unjuice
    from .modules.utils import byteify
    from .modules.log_utils import error, log


regex_pattern1 = r'(?:iframe|source).+?(?:src)=(?:\"|\')(.+?)(?:\"|\')'
regex_pattern2 = r'(?:data-video|data-src|data-href)=(?:\"|\')(.+?)(?:\"|\')'
regex_pattern3 = r'(?:file|source)(?:\:)\s*(?:\"|\')(.+?)(?:\"|\')'
regex_pattern4 = r'''(magnet:\?[^"']+)'''
regex_pattern5 = r'<[iI][fF][rR][aA][mM][eE].+?[sS][rR][cC]="(.+?)"'
regex_pattern6 = r'''['"]file['"]\s*:\s*['"]([^'"]+)'''
regex_pattern7 = r'''['"]?file['"]?\s*:\s*['"]([^'"]*)'''
regex_pattern8 = r'file(?:\'|\")?\s*(?:\:)\s*(?:\"|\')(.+?)(?:\"|\')'
regex_pattern9 = r'sources\s*:\s*\[(.+?)\]'
regex_pattern10 = r'\{(.+?)\}'


def re_findall(html, regex):
    return re.findall(regex, html)


def re_compile(html, regex):
    return re.compile(regex).findall(html)


def unpacked(html):
    return jsunpack.get_2packed_data(html) if jsunpack.detect(html) else ''


def unpacked2(html):
    packed_data = ''
    if jsunpack.detect(html):
        for match in re.finditer(r'''(eval\s*\(function\(p,a,c,k,e,.*?)</script>''', html, re.DOTALL | re.I):
            r = match.group(1)
            t = re.findall(r'(eval\s*\(function\(p,a,c,k,e,)', r, re.DOTALL | re.IGNORECASE)
            if len(t) == 1:
                if jsunpack.detect(r):
                    packed_data += jsunpack.unpack(r)
            else:
                t = r.split('eval')
                t = [f'eval{x}' for x in t if x]
                for r in t:
                    if jsunpack.detect(r):
                        packed_data += jsunpack.unpack(r)
    return packed_data


def unjuiced2(html):
    unjuiced = ''
    if unjuice.test(html):
        for match in re.finditer(r'(_juicycodes\(.+?[;\n<])|(JuicyCodes.Run\([^\)]+)', html, re.DOTALL | re.I):
            unjuiced += unjuice.run(match.group(1))
    return unjuiced


def remove_tags(text):
    TAG_RE = re.compile(r'<[^>]+>')
    return TAG_RE.sub('', text)


def remove_codes(string):
    remove = re.compile('<.+?>')
    string = re.sub(remove, '', string)
    return string


def replace_html_entities(string):
    items = (('â\x80\x99', '\''), ('\\/', '/'), ('///', '//'), ('&nbsp;', ''), ('&#8230;', '...'), ('&#8217;', "\'"), ('%2B', '+'), ('&#8211;', '-'), ('&lt;', '<'), ('&#60;', '<'), ('&gt;', '>'), ('&#62;', '>'), ('&amp;', '&'), ('&#38;', '&'), ('&#038;', '&'), ('&quot;', '"'), ('&#34;', '"'), ('&apos;', "'"), ('&#39;', "'"))
    for item in items:
        string = string.replace(item[0], item[1])
    return string


def replaceHTMLCodes(txt):
    # Some HTML entities are encoded twice. Decode double.
    return _replaceHTMLCodes(_replaceHTMLCodes(txt))


def _replaceHTMLCodes(txt):
    try:
        if not txt: return ''
        txt = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', txt) # fix html codes with missing semicolon
        txt = unescape(txt)
        txt = replace_html_entities(txt)
        # txt = re.sub(r'\\[nrt]', '', txt)
        txt = txt.strip()
        return ensure_str(txt)
    except:
        error('_replaceHTMLCodes Error: ')
        return txt


def cleanHTML(txt):
    txt = re.sub(r'<.+?>|</.+?>|\n', '', txt)
    return replaceHTMLCodes(txt)

def clean_html(txt):
    txt = txt.replace('&quot;', '\"')
    txt = txt.replace('&amp;', '&')
    txt = txt.replace('\\n','')
    txt = txt.replace('\\t', '')
    txt = txt.replace('\\', '')
    txt = ' '.join(txt.split())
    return ensure_str(txt)


def removeNonAscii(s):
    return ''.join(i for i in s if ord(i) < 128)


def json_loads_as_str(json_text):
    return byteify(json.loads(json_text, object_hook=byteify), ignore_dicts=True)


