import functools
import os
import random
import re
import shutil
from gzip import GzipFile
from ssl import OPENSSL_VERSION
from io import BytesIO
from time import sleep
from json import loads
from socket import AF_INET, AF_INET6, AF_UNSPEC, getaddrinfo
from urllib.parse import urlparse

import requests
import urllib3
from requests.adapters import HTTPAdapter
from _socket import gaierror

from .log_utils import log, error

try: from openscrapers.modules import cache
except: from . import cache
try: translatePath = xbmc.translatePath
except: translatePath = object()

SSL_OPTIONS = urllib3.util.ssl_.OP_NO_SSLv2 | urllib3.util.ssl_.OP_NO_SSLv3 | urllib3.util.ssl_.OP_NO_COMPRESSION | urllib3.util.ssl_.OP_NO_TICKET
_c_suite = ['ECDHE-ECDSA-AES128-GCM-SHA256', 'ECDHE-ECDSA-AES256-GCM-SHA384', 'ECDHE-ECDSA-CHACHA20-POLY1305', 'ECDHE-RSA-AES128-GCM-SHA256', 'ECDHE-RSA-AES256-GCM-SHA384', 'ECDHE-RSA-CHACHA20-POLY1305', 'ECDHE-ECDSA-AES128-SHA', 'ECDHE-ECDSA-AES256-SHA', 'ECDHE-RSA-AES128-SHA', 'ECDHE-RSA-AES256-SHA', 'ECDHE-ECDSA-AES256-SHA384', 'ECDHE-RSA-AES256-SHA384', 'ECDHE-ECDSA-AES128-SHA256', 'ECDHE-RSA-AES128-SHA256', 'TLS_AES_128_GCM_SHA256', 'TLS_AES_256_GCM_SHA384', 'TLS_CHACHA20_POLY1305_SHA256', 'DHE-RSA-AES256-GCM-SHA384', 'DHE-RSA-CHACHA20-POLY1305', 'DHE-RSA-AES128-GCM-SHA256', 'DHE-RSA-AES256-SHA256', 'DHE-RSA-AES128-SHA256', 'DHE-RSA-AES256-SHA', 'DHE-RSA-AES128-SHA', 'AES256-GCM-SHA384', 'AES128-GCM-SHA256', 'AES256-SHA256', 'AES128-SHA256', 'AES256-SHA', 'AES128-SHA']
random.shuffle(_c_suite)
cipher_suite = ':'.join(_c_suite)
chrome_browser = {'cipher_suite': cipher_suite, 'headers': {'sec-ch-ua-mobile': '?0', 'sec-ch-ua-platform': '"Windows"', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', 'Sec-Fetch-Site': 'none', 'Upgrade-Insecure-Requests': '1', 'Sec-Fetch-Mode': 'navigate', 'Sec-Fetch-User': '?1', 'Sec-Fetch-Dest': 'document', 'Accept-Encoding': 'gzip, deflate', 'Accept-Language': 'en-US,en;q=0.9', }}
firef_browser = {'cipher_suite': cipher_suite, 'headers': {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8', 'Accept-Language': 'en-US,en;q=0.5', 'Accept-Encoding': 'gzip, deflate', 'Upgrade-Insecure-Requests': '1', 'Sec-Fetch-Dest': 'document', 'Sec-Fetch-Mode': 'navigate', 'Sec-Fetch-Site': 'none', 'Sec-Fetch-User': '?1', 'TE': 'Trailers', }}
random_browser = random.choice((chrome_browser, firef_browser))
common_settings = {'verify_ssl': True, 'http_timeout': 20}
CHUNK_SIZE = 64 * 1024
OPEN_SESSIONS = []
DNS_OVERRIDE_DOMAINS = ['slyguy.uk', 'i.mjh.nz', 'dai.google.com']
DNS_OVERRIDE_SERVER = '1.1.1.1' # format('1.1.1.1' if KODI_VERSION >= 19 else 'cloudflare-dns.com')
try:
    from openscrapers.modules.control import getKodiVersion, dataPath, addonId, setting
    KODI_VERSION = getKodiVersion()
    ADDON_PROFILE, ADDON_ID = dataPath, addonId
    http_retries, cache_resp, proxy_server = int(setting('http_retries')), setting('cache_resp') == 'true', 'kodi'
except:
    KODI_VERSION, ADDON_PROFILE, ADDON_ID = 21, '', ''
    http_retries, proxy_server, cache_resp = 2, 'kodi', True
COMMON_ADDON = {'id': '', 'profile': ''}
userdata = {}
# log(f'http_retries:: {repr(http_retries)} proxy_server:: {repr(proxy_server)} cache_resp:: {repr(cache_resp)}')


def get_kodi_proxy():
    usehttpproxy = {'network.usehttpproxy': False, 'network.httpproxytype': 'https', 'network.httpproxyserver': '', 'network.httpproxyport': '', 'network.httpproxyusername': '', 'network.httpproxypassword': ''}
    # usehttpproxy = usehttpproxy.get('network.usehttpproxy')
    if usehttpproxy.get('network.usehttpproxy') is not True: return None
    try: httpproxytype = int(usehttpproxy.get('network.httpproxytype'))
    except ValueError: httpproxytype = 0
    proxy_types = ['http', 'socks4', 'socks4a', 'socks5', 'socks5h']
    proxy = dict(scheme=proxy_types[httpproxytype] if 0 <= httpproxytype < 5 else 'http', server=usehttpproxy.get('network.httpproxyserver'), port=usehttpproxy.get('network.httpproxyport'), username=usehttpproxy.get('network.httpproxyusername'), password=usehttpproxy.get('network.httpproxypassword'), )
    if proxy.get('username') and proxy.get('password') and proxy.get('server') and proxy.get('port'): proxy_address = '{scheme}://{username}:{password}@{server}:{port}'.format(**proxy)
    elif proxy.get('username') and proxy.get('server') and proxy.get('port'): proxy_address = '{scheme}://{username}@{server}:{port}'.format(**proxy)
    elif proxy.get('server') and proxy.get('port'): proxy_address = '{scheme}://{server}:{port}'.format(**proxy)
    elif proxy.get('server'): proxy_address = '{scheme}://{server}'.format(**proxy)
    else: return None
    return proxy_address


def _get_url(url):
    # log(f'Request DNS URL: {url}')
    data = cache.get(requests.get, 24, url)
    return data


def _load_rewrites(directory):
    rewrites = []
    file_names = ['urls.txt', 'dns_rewrites.txt', ]
    found = False
    for name in file_names:
        try: file_path = os.path.join(translatePath(directory), name)
        except: file_path = f'D:/GitHub/repo_testing/voot_testing/script.module.openscrapers/{name}'
        if os.path.exists(file_path):
            found = True
            break
    if not found: return rewrites

    try:
        def _process_lines(lines):
            for line in lines:
                entry = line.strip()
                if not entry or entry.startswith('#'): continue
                entries = [x.strip() for x in entry.split() if x.strip()]
                if len(entries) == 1 and entries[0].lower().startswith('http'):
                    text = _get_url(entry)
                    _process_lines(text.split('\n'))
                    continue
                if len(entries) < 2: continue
                rewrites.append(entries)
        with open(file_path, 'r') as f:
            text = f.read()
        _process_lines(text.split('\n'))
    except Exception as e: log(f'Error: {e} DNS Rewrites Failed: {file_path}')
    return rewrites


def get_dns_rewrites(dns_rewrites=None):
    rewrites = _load_rewrites(ADDON_PROFILE)

    if COMMON_ADDON.get('id') != ADDON_ID:
        rewrites.extend(_load_rewrites(COMMON_ADDON.get('profile')))
    if dns_rewrites: rewrites.extend(dns_rewrites)

    # add some defaults that are often blocked by networkwide dns
    # rewrites.extend([['r:https://cloudflare-dns.com/dns-query', 'dai.google.com'],])
    # if rewrites: log(f'Rewrites Loaded: {len(rewrites)}')
    for domain in DNS_OVERRIDE_DOMAINS:
        rewrites.append(['r:{}'.format(DNS_OVERRIDE_SERVER), domain])
    return rewrites


def close_sessions():
    for session in OPEN_SESSIONS:
        session.close()


class Error(Exception):
    def __init__(self, message='', heading=None):
        self.message = message
        self.heading = heading or 'Infinite'
        super(Error, self).__init__(message)


class SessionError(Error):
    pass


class DOHResolver(object):
    def __init__(self, adapter, nameservers=None):
        self._adapter = adapter
        self.nameservers = nameservers or []
        self._session = RawSession()

    def query(self, host, source=None):
        #TODO: use source ip address
        class DNSResultWrapper(object):
            def __init__(self, answer):
                self.answer = answer

            def to_text(self):
                return self.answer

        for server in self.nameservers:
            key = (server, host)
            ips = cache.get(key, 24)
            if not ips:
                headers = {'accept': 'application/dns-json'}
                server_host = urlparse(server).netloc.lower()
                info = self._adapter.getaddrinfo(server_host, 443 if server.lower().startswith('https') else 80)
                families = [x[0] for x in info]
                params = {'name': host}
                # prefer IPV4
                if AF_INET in families or AF_INET6 not in families: params['type'] = 'A'
                else: params['type'] = 'AAAA'
                try:
                    data = self._session.get(server, params=params, headers=headers).json()
                except Exception as e:
                    log(f'DOHResolver error: {e} DOH Request: {server} for {host} type {params["type"]}')
                    continue
                suitable = [x for x in data['Answer'] if x['type'] in (1, 28)]  #ipv4 or ipv6
                ttl = min([x['TTL'] for x in suitable])
                ips = [x['data'] for x in suitable]
                cache.cache_insert(key, ips, expires=ttl)
            if ips: return [DNSResultWrapper(ip) for ip in ips]
        raise SessionError(f'Unable to resolve host: {host} with nameservers: {self.nameservers}')


class SessionAdapter(HTTPAdapter):
    def __init__(self):
        self.session_data = {}
        self._context_cache = {}
        super(SessionAdapter, self).__init__()

    def init_poolmanager(self, *args, **kwargs):
        super(SessionAdapter, self).init_poolmanager(*args, **kwargs)
        self.poolmanager.connection_from_pool_key = functools.partial(self.connection_from_pool_key, self.poolmanager.connection_from_pool_key)

    def proxy_manager_for(self, *args, **kwargs):
        manager = super(SessionAdapter, self).proxy_manager_for(*args, **kwargs)
        manager.connection_from_pool_key = functools.partial(self.connection_from_pool_key, manager.connection_from_pool_key)
        return manager

    def connection_from_pool_key(self, func, pool_key, request_context):
        if self.session_data['ssl_ciphers'] or self.session_data['ssl_options']:
            # log(f'ssl_ciphers ::: {self.session_data.get("ssl_ciphers")}\nssl_options ::: {self.session_data.get("ssl_options")}\nheaders     ::: {self.session_data.get("headers")}')
            context_key = (self.session_data['ssl_ciphers'], self.session_data['ssl_options'])
            request_context['ssl_context'] = self._context_cache[context_key] = self._context_cache.get(context_key, requests.packages.urllib3.util.ssl_.create_urllib3_context(ciphers=self.session_data['ssl_ciphers'], options=self.session_data['ssl_options']))
            pool_key = pool_key._replace(key_ssl_context=context_key)

        if self.session_data['interface_ip']:
            request_context['source_address'] = (self.session_data['interface_ip'], 0)
            pool_key = pool_key._replace(key_source_address=request_context['source_address'])

        # ensure we get a unique pool (socket) for same domain on different rewrite ips
        if self.session_data['rewrite'] and self.session_data['rewrite'][0] == request_context['host']:
            pool_key = pool_key._replace(key_server_hostname=self.session_data['rewrite'][1])
        # ensure we get a unique pool (socket) for same domain on different resolvers
        elif self.session_data['resolver'] and self.session_data['resolver'][0] == request_context['host']:
            pool_key = pool_key._replace(key_server_hostname=self.session_data['resolver'][1].nameservers[0])

        pool = func(pool_key, request_context)
        pool._new_conn = functools.partial(self._new_pool_conn, pool._new_conn)
        return pool

    def _new_pool_conn(self, func, *args, **kwargs):
        conn = func(*args, **kwargs)
        conn.connect = functools.partial(self.connect, conn.connect, conn)
        conn.getaddrinfo = self.getaddrinfo
        return conn

    def connect(self, func, conn, *args, **kwargs):
        retval = func(*args, **kwargs)
        # if hasattr(conn.sock, 'server_hostname'): log(f'SSL Cipher: {conn.sock.server_hostname} - {conn.sock.cipher()}')
        return retval

    def getaddrinfo(self, host, port, family=0, _type=0):
        orig_host = host

        if self.session_data['rewrite'] and self.session_data['rewrite'][0] == host:
            host = self.session_data['rewrite'][1]
            log(f'DNS Rewrite: {orig_host} -> {host}')

        elif self.session_data['resolver'] and self.session_data['resolver'][0] == host:
            try:
                host = self.session_data['resolver'][1].query(host, source=self.session_data['interface_ip'])[0].to_text()
                log(f'DNS Resolver: {orig_host} -> {self.session_data["resolver"][1].nameservers[0]} -> {host}')
            except Exception as e:
                log(f'Failed to resolve. Falling back to dns lookup: {e}')
                host = orig_host

        if ':' in host: first, second = (family, None)
        else:
            first = AF_INET
            second = AF_INET6 if family == AF_UNSPEC else None

        try: addresses = getaddrinfo(host, port, first, _type)
        except gaierror:
            if second: addresses = getaddrinfo(host, port, second, _type)
            else: raise

        if addresses[0][4][0] != host: log(f'DNS Resolver: {host} -> {addresses[0][4][0]}')
        return addresses


class RawSession(requests.Session):
    def __init__(self, verify=None, timeout=None, auto_close=True, ssl_ciphers=None, ssl_options=SSL_OPTIONS, proxy=None):
        super(RawSession, self).__init__()
        self._verify = verify
        self._timeout = timeout
        self._rewrites = []
        self._session_cache = {}
        self._proxy = proxy
        self._cert = None
        _browser = random_browser
        # log(f'using::: {_browser}')
        if not ssl_ciphers: ssl_ciphers = _browser.get('cipher_suite')
        self.headers = _browser.get('headers')
        self._ssl_ciphers = ssl_ciphers
        self._ssl_options = ssl_options

        if auto_close:
            OPEN_SESSIONS.append(self)

        self._adapter = SessionAdapter()
        for prefix in ('http://', 'https://'):
            self.mount(prefix, self._adapter)

    def set_dns_rewrites(self, rewrites):
        for entries in rewrites:
            pattern = entries.pop()
            pattern = re.escape(pattern).replace('\*', '.*')
            pattern = re.compile(pattern, flags=re.IGNORECASE)

            new_entries = []
            for entry in entries:
                _type = 'skip'
                if entry.startswith('p:'):
                    _type = 'proxy'
                    entry = entry[2:]
                elif entry.startswith('r:'):
                    _type = 'resolver'
                    entry = entry[2:]
                elif entry.startswith('i:'):
                    _type = 'interface_ip'
                    entry = entry[2:]
                elif entry[0].isdigit(): _type = 'dns'
                else: _type = 'url_sub'
                new_entries.append([_type, entry])
            # Make sure dns is done last
            self._rewrites.append([pattern, sorted(new_entries, key=lambda x: x[0] == 'dns')])

    def set_cert(self, cert):
        self._cert = cert
        if cert: log(f'SSL CERT SET TO: {cert}')

    def _get_cert(self):
        if not self._cert: return None

        if self._cert.lower().startswith('http'):
            url = self._cert
            self._cert = None
            log(f'Downloading cert: {url}')
            resp = self.request('get', url, stream=True)
            self._cert = translatePath('special://temp/temp.pem')
            with open(self._cert, 'wb') as f:
                shutil.copyfileobj(resp.raw, f)
        return translatePath(self._cert)

    def set_proxy(self, proxy):
        self._proxy = proxy

    def _get_proxy(self):
        if self._proxy and self._proxy.lower().strip() == 'kodi': self._proxy = get_kodi_proxy()
        return self._proxy

    def close(self):
        super(RawSession, self).close()
        if self in OPEN_SESSIONS:
            OPEN_SESSIONS.remove(self)

    def __del__(self):
        self.close()

    def request(self, method, url, **kwargs):
        req = requests.Request(method, url, params=kwargs.pop('params', None))
        url = req.prepare().url

        session_data = {
            'ssl_ciphers': self._ssl_ciphers,
            'ssl_options': self._ssl_options,
            'proxy': None,
            'interface_ip': None,
            'rewrite': None,
            'resolver': None,
            'url': url,
        }

        if url in self._session_cache:
            session_data = self._session_cache[url]
        elif self._rewrites:
            for row in self._rewrites:
                if not row[0].search(url): continue
                for entry in row[1]:
                    if entry[0] == 'skip': continue
                    if entry[0] == 'url_sub': session_data['url'] = re.sub(row[0], entry[1], url, count=1)
                    elif entry[0] == 'proxy': session_data['proxy'] = entry[1]
                    elif entry[0] == 'interface_ip':
                        session_data['interface_ip'] = entry[1]
                    elif entry[0] == 'dns': session_data['rewrite'] = [urlparse(session_data['url']).netloc.lower(), entry[1]]
                    elif entry[0] == 'resolver' and entry[1]:
                        resolver = DOHResolver(self._adapter)
                        resolver.nameservers = [entry[1], ]
                        session_data['resolver'] = [urlparse(session_data['url']).netloc.lower(), resolver]
                break

            self._session_cache[url] = session_data

        if session_data['interface_ip']:
            if not session_data['resolver']:
                log('DNS leak! DNS requests will be going via the default interface. Specify a DNS server in smart urls to fix')
            elif isinstance(session_data['resolver'][1], DOHResolver):
                log('DNS leak! The DOH DNS & request only will be made using the default interface (support coming soon). All other requests will use the specified interface.')

        if session_data['url'] != url:
            error("URL Changed: {}".format(session_data['url']))

        if session_data['proxy'] is None:
            session_data['proxy'] = self._get_proxy()

        if session_data['proxy']:
            # remove username, password from proxy for logging
            parsed = urlparse(session_data['proxy'])
            replaced = parsed._replace(netloc=f'{"username"}:{"password"}@{parsed.hostname}' if parsed.username else parsed.hostname)
            log(f'Proxy: {replaced.geturl()}:{parsed.port}')
            kwargs['proxies'] = {'http': session_data['proxy'], 'https': session_data['proxy'], }
        if self._cert:
            session_data['ssl_ciphers'] += '@SECLEVEL=0'
            kwargs['verify'] = False
            kwargs['cert'] = self._get_cert()

        self._adapter.session_data = session_data

        if 'verify' not in kwargs: kwargs['verify'] = self._verify
        if 'timeout' not in kwargs: kwargs['timeout'] = self._timeout

        # Do request
        try: result = super(RawSession, self).request(method, session_data['url'], **kwargs)
        except requests.exceptions.ConnectionError as e:
            raise SessionError(f'error: {e} Failed to connect to host: {urlparse(session_data["url"]).netloc.lower()}')
        return result


class Cresponse():
    """ Adding Attribute to cache response return"""
    pass


class Session(RawSession):
    def __init__(self, headers=None, cookies_key=None, base_url='{}', timeout=None, attempts=None, verify=None, dns_rewrites=None, auto_close=True, return_json=False, **kwargs):
        super(Session, self).__init__(verify=common_settings.get('verify_ssl', True) if verify is None else verify, timeout=common_settings.get('http_timeout', 30) if timeout is None else timeout, auto_close=auto_close, **kwargs)

        self._headers = headers or {}
        self._cookies_key = cookies_key
        self._base_url = base_url
        self._attempts = http_retries if attempts is None else attempts
        self._return_json = return_json
        self.before_request = None
        self.after_request = None
        self.cache_resp = cache_resp
        self.set_dns_rewrites(get_dns_rewrites() if dns_rewrites is None else dns_rewrites)
        self.set_proxy(proxy_server or None)
        self.headers.update(self._headers)
        # log(f'self.headers: {self.headers}')
        if self._cookies_key: self.cookies.update(userdata.get(self._cookies_key, {}))

    def gz_json(self, *args, **kwargs):
        kwargs['return_json'] = False
        # log(f'gz_json args: {args}  kwargs: {kwargs}')
        resp = self.get(*args, **kwargs)
        json_text = GzipFile(fileobj=BytesIO(resp.content)).read()
        return loads(json_text)

    def request(self, method, url, timeout=None, attempts=None, verify=None, error_msg=None, retry_not_ok=False, retry_delay=30, log_url=None, return_json=None, **kwargs):
        method = method.upper()

        if not url.startswith('http'): url = self._base_url.format(url)
        if self.cache_resp:
            data = cache.cache_get(url)
            # log(f' type: {type(data)} response.__dict__: {repr(data)}')
            if data:
                fdata = eval(data["value"])
                # log(f'type: {type(fdata)} response.__dict__: {repr(fdata)}')
                response = Cresponse()
                response.text = fdata.get('text')
                response.status_code = fdata.get('status_code')
                response.headers = fdata.get('headers')
                response.url = fdata.get('url')
                return response

        attempts = max(self._attempts if attempts is None else attempts, 1)

        if timeout is not None: kwargs['timeout'] = timeout
        if verify is not None: kwargs['verify'] = verify

        for i in range(1, attempts + 1):
            attempt = f'Attempt {i}/{attempts}: '
            if i > 1 and retry_delay: sleep(retry_delay)
            if self.before_request: self.before_request()
            try: resp = super(Session, self).request(method, url, **kwargs)
            except SessionError:
                log(f'attempt:{attempt} method:{method} url: {log_url or url}\nkwargs: {kwargs}')
                resp = None
                if i == attempts: raise
                else: continue
            except Exception as err:
                error(f'err: {err} attempt:{attempt} method:{method} url: {log_url or url}', __name__)
                resp = None
            if resp is None: raise SessionError(f'URL returned no response from url: {url}\nerror_msg {error_msg}')
            if retry_not_ok and not resp.ok: continue
            if i == attempts or resp.ok: break

        if self.cache_resp:
            cache_resp = {'text': resp.text, 'status_code': resp.status_code, 'headers': resp.headers, 'url': resp.url}
            cache.cache_insert(url, repr(cache_resp))
        return resp

    def save_cookies(self):
        if not self._cookies_key: raise Exception('A cookies key needs to be set to save cookies')
        userdata.set(self._cookies_key, self.cookies.get_dict())

    def clear_cookies(self):
        if self._cookies_key: userdata.delete(self._cookies_key)
        self.cookies.clear()

    def chunked_dl(self, url, dst_path, method='GET', **kwargs):
        kwargs['stream'] = True
        kwargs['return_json'] = False
        resp = self.request(method, url, **kwargs)
        resp.raise_for_status()

        with open(dst_path, 'wb') as f:
            for chunk in resp.iter_content(CHUNK_SIZE):
                f.write(chunk)
        return resp