# -*- coding: utf-8 -*-
"""
    OpenScrapers Module
"""

import re
from ast import literal_eval
from json import loads, dumps
from gzip import GzipFile
from html import unescape
from http import cookiejar
from io import BytesIO
from random import choice, randrange
from time import sleep, time
from sys import version_info
from traceback import print_exc
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, quote_plus, unquote_plus, urlencode, urljoin, urlparse
from urllib.request import HTTPCookieProcessor, HTTPHandler, HTTPRedirectHandler, HTTPSHandler, ProxyHandler, Request, build_opener, install_opener, urlopen
from urllib.response import addinfourl

import requests
from requests import Timeout, Session
from requests.exceptions import SSLError, RequestException
from requests.adapters import HTTPAdapter, Retry
from openscrapers.modules import cache, client_utils
from openscrapers.modules.log_utils import log, error as lerror
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.utils import get_headers_parse_url, byteify
from openscrapers.modules import pyaes
from openscrapers.modules import cfscrape
from openscrapers.modules.control import translate_path, dataPath, existsPath, setting, get_useragent

# from openscrapers.modules.client_session import Session
# session = Session()

try: cache_resp = setting('cache_resp') == 'true'
except: cache_resp = True
_COOKIE_HEADER = "Cookie"
_HEADER_RE = re.compile(r"^([\w\d-]+?)=(.*?)$")
try: random_us = setting('random_us') == 'true'
except: random_us = False
try: 
    if random_us: UserAgent = cache.get(agent, 2)
    else: UserAgent = cache.get(get_useragent, 200) #get_useragent()
except: UserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/114.0'
OldUserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:97.0) Gecko/20100101 Firefox/97.0'
MobileUserAgent = 'Mozilla/5.0 (Android 10; Mobile; rv:83.0) Gecko/83.0 Firefox/83.0'

dnt_headers = {
    'user-agent': UserAgent,
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-encoding': 'gzip, deflate',
    'accept-language': 'en,en-US;q=0.9',
    'connection': 'keep-alive',
    'pragma': 'no-cache',
    'SEC-FETCH-DEST': 'document',
    'cache-control': 'no-cache',
    'dnt': '1',
}
#     'content-type': 'application/x-www-form-urlencoded',


fheaders = {
    'Accept-Language': 'en,en-US;q=0.9',
    'Accept-Encoding': 'gzip, deflate',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'Connection': 'keep-alive',
    'DNT': '1',
    'Upgrade-Insecure-Requests': '1',
    'x-requested-with': 'XMLHttpRequest', }
# 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
# 'sec-fetch-dest': 'document',
# 'sec-fetch-mode': 'navigate',
# 'sec-fetch-site': 'cross-site',
# }
# 'Pragma': 'no-cache',
# 'Cache-Control': 'no-cache',


def make_session(url='https://'):
    # log(f'requests.certs.where(): {requests.certs.where()}')
    session = requests.Session()
    retry = Retry(total=2, status=1, backoff_factor=0.5, status_forcelist=(429, 502, 503, 504))
    adapter = HTTPAdapter(max_retries=retry, pool_maxsize=100)
    session.mount('http://', adapter)
    session.mount(url, adapter)
    return session

def _strip_url(url):
    return get_headers_parse_url(url)


def _url_with_headers(url, headers):
    if not len(headers.keys()): return url
    return f'{url}|{urlencode(headers)}'


def strip_cookie_url(url):
    url, headers = _strip_url(url)
    if _COOKIE_HEADER in headers.keys():
        del headers[_COOKIE_HEADER]
    return _url_with_headers(url, headers)


def get_referer(url):
    parsed_url = urlparse(url)
    return f'{parsed_url.scheme}://{(parsed_url.netloc or parsed_url.path)}/'


def _add_request_header(_request, headers=None):
    if headers is None: headers = {}
    try:
        host = _request.host
        referer = headers.get('Referer') or get_referer(_request.get_full_url())
        _request.add_unredirected_header('Host', host)
        _request.add_unredirected_header('Referer', referer)
        for key in headers:
            if isinstance(headers[key], dict): continue
            # log(f'type headers[key]: {type(headers[key])} headers[key]: {headers[key]}')
            _request.add_header(key, headers[key])
        if 'User-Agent' not in headers: _request.add_header('User-Agent', agent())
    except: lerror(f'Error from: {__name__}: ')
    return _request


def brutforce_decode(response, encoding='utf-8', errors='replace'):
    try: return response.decode(encoding, errors=errors)
    except:
        try: return response.decode('latin-1', errors=errors)
        except:
            try: return response.decode('iso-8859-1', errors=errors)
            except: return response


def _get_result(response, limit=None, ret_code=None):
    try:
        if not response: return
        if ret_code: return response.status
        try: result = response.read(int(limit) * 1024) if limit else response.read(5242880)
        except AttributeError: result = response.text
        # log(f'type result: {type(result)} : {result}')
        encoding = None
        # text_content = False
        # log(f'response.headers: {dict(response.headers)}')
        if isinstance(result, bytes) and response.headers.get('content-encoding', '').lower() == 'gzip':
            result = GzipFile(fileobj=BytesIO(result)).read()
        if isinstance(result, bytes):
            content_type = response.headers.get('content-type', '').lower()
            # text_content = any(x in content_type for x in ['text', 'json', 'xml', 'mpegurl'])
            if 'charset=' in content_type: encoding = content_type.split('charset=')[-1]
            if encoding is None:
                epatterns = [r'<meta\s+http-equiv="Content-Type"\s+content="(?:.+?);\s+charset=(.+?)"', r'xml\s*version.+encoding="([^"]+)']
                for epattern in epatterns:
                    epattern = epattern.encode('utf8')
                    r = re.search(epattern, result, re.IGNORECASE)
                    if r:
                        encoding = brutforce_decode(r.group(1), 'utf8', errors='ignore')
                        break
            if encoding is None:
                r = re.search(b'^#EXT', result, re.IGNORECASE)
                if r: encoding = 'utf8'
            if encoding is not None:
                return brutforce_decode(result, encoding, errors='ignore')
            else: log('Unknown Page Encoding')
        return brutforce_decode(result, errors='ignore')
    except: lerror(f'Error from: {__name__}: ')


def _basic_request(url, headers=None, post=None, timeout=60, jpost=False, limit=None):
    try:
        _headers = headers if headers else {}
        if '|' in url:
            url, oheaders = get_headers_parse_url(url)
            _headers.update(oheaders)
        request = Request(url)
        if post is not None:
            if jpost:
                post = dumps(post)
                post = post.encode('utf8')
                request = Request(url, post)
                request.add_header('Content-Type', 'application/json')
            else:
                if isinstance(post, dict): post = bytes(urlencode(post), encoding='utf-8')
                if len(post) > 0: request = Request(url, data=post.encode('utf8'))
                else:
                    request.get_method = lambda: 'POST'
                    request.has_header = lambda header_name: (header_name == 'Content-type' or Request.has_header(request, header_name))
        request = _add_request_header(request, _headers)
        response = urlopen(request, timeout=int(timeout))
        return _get_result(response, limit)
    except:
        lerror(f'Error from: {__name__}: for url {url} ')
        return


def request(url, close=True, redirect=True, error=False, verify=True, post=None, headers=None, mobile=False, XHR=False,
            limit=None, referer=None, cookie=None, compression=False, output='', timeout='10', jpost=False, cfflare=False):
    if not url: return None
    if url.startswith('//'): url = f'https:{url}'
    if post:
        if isinstance(post, dict): post = bytes(urlencode(post), encoding='utf-8')
        elif isinstance(post, str): post = bytes(post, encoding='utf-8')
    _headers = headers if headers else {}
    try:
        if cache_resp and (data := cache.cache_get(url)):
            try: fdata = literal_eval(data['value'])
            except: fdata = eval(data['value'])
            # log(f'cache_resp from url: {repr(url)}')
            return fdata.get('text')

        if '|' in url:
            url, oheaders = get_headers_parse_url(url)
            _headers.update(oheaders)
        if _headers.get('verifypeer', '') == 'false':
            verify = False
            _headers.pop('verifypeer')

        handlers = []
        cookies = cookiejar.LWPCookieJar()
        if output == 'cookie' or output == 'extended' or not close or redirect:
            handlers += [HTTPHandler(), HTTPSHandler(), HTTPCookieProcessor(cookies)]
        if output == 'elapsed': start_time = time() * 1000
        opener = _get_unverified_context(verify, handlers)
        install_opener(opener)

        if 'User-Agent' in _headers:
            pass
        elif mobile:
            _headers['User-Agent'] = cache.get(mobileagent, 2)
        else:
            if random_us: _headers['User-Agent'] = cache.get(agent, 2)
            else: _headers['User-Agent'] = cache.get(get_useragent, 2)
        if 'Referer' in _headers:
            pass
        elif referer is None:
            _headers['Referer'] = get_referer(url)
        else:
            _headers['Referer'] = referer
        if 'Accept-Language' not in _headers:
            _headers['Accept-Language'] = 'en-US,en'
        if 'Accept' not in _headers:
            _headers['Accept'] = '*/*'
        if 'X-Requested-With' in _headers:
            pass
        elif XHR:
            _headers['X-Requested-With'] = 'XMLHttpRequest'
        if 'Cookie' in _headers:
            pass
        if cookie is not None:
            if isinstance(cookie, dict):
                cookie = '; '.join(['{0}={1}'.format(x, y) for x, y in iter(cookie.items())])
            _headers['Cookie'] = cookie
        else:
            cpath = urlparse(url).netloc
            ccookie = retrieve(cpath + '.txt')
            if ccookie: _headers['Cookie'] = ccookie
            else:
                ccookie = retrieve(cpath + '.json')
                if ccookie:
                    cfhdrs = loads(ccookie)
                    _headers.update(cfhdrs)

        if 'Accept-Encoding' in _headers:
            pass
        elif compression and limit is None:
            _headers['Accept-Encoding'] = 'gzip'
        if redirect is False:
            class NoRedirectHandler(HTTPRedirectHandler):
                def http_error_302(self, req, fp, code, msg, _headers):
                    infourl = addinfourl(fp, _headers, req.get_full_url())
                    try:
                        if version_info < (3, 9, 0):
                            infourl.code = code
                            infourl.status = code
                    except: pass
                    return infourl

                http_error_300 = http_error_302
                http_error_301 = http_error_302
                http_error_303 = http_error_302
                http_error_307 = http_error_302
                http_error_308 = http_error_302

            opener = build_opener(NoRedirectHandler())
            install_opener(opener)
            try: del _headers['Referer']
            except BaseException: pass

        url = quote_plus(url, safe="%/:=&?~#+!$,;'@()*[]|")
        # url = client_utils.byteify(url.replace(' ', '%20'))
        req = Request(url)
        if post:
            if jpost:
                post = dumps(post)
                req = Request(url, post)
                req.add_header('Content-Type', 'application/json')
            else:
                if len(post) > 0: req = Request(url, data=post)
                else:
                    req.get_method = lambda: 'POST'
                    req.has_header = lambda header_name: (header_name == 'Content-type' or Request.has_header(req, header_name))

        if limit == '0': req.get_method = lambda: 'HEAD'
        req = _add_request_header(req, _headers)
        # log(f'sent headers: {req.headers}')
        try:
            response = urlopen(req, timeout=int(timeout))
        except HTTPError as e:
            result = e.read()
            if error is True: response = e
            if e.info().get('Content-Encoding', '').lower() == 'gzip':
                result = GzipFile(fileobj=BytesIO(result)).read()
            result = brutforce_decode(result, errors='ignore')
            server = e.info().get('Server')
            ecode = e.status or e.code
            if 'cf-browser-verification' in result:
                from modules import cfscrape
                _cf_lim = 0
                while 'cf-browser-verification' in result and _cf_lim <= 1:
                    _cf_lim += 1
                    netloc = get_referer(url)
                    ua = _headers['User-Agent']
                    try: cf = cache.get(cfscrape.get_cookie_string, 1, netloc, ua)[0]
                    except BaseException:
                        try: cf = cfscrape.get_cookie_string(url, (ua))[0]
                        except BaseException: cf = None
                    finally: _headers['Cookie'] = cf

                    request = Request(url, data=post)
                    _add_request_header(request, _headers)
                    try:
                        response = urlopen(request, timeout=int(timeout))
                    except HTTPError as response:
                        cache.remove(cfscrape.get_cookie_string, netloc, ua)
            if 'cloudflare' in server.lower():
                if ecode == 403 and not e.info().get('cf-mitigated', False):
                    opener = _get_unverified_context(verify, handlers)
                    # install_opener(opener)
                    try:
                        response = opener.open(req, timeout=20)
                    except HTTPError as e:
                        if e.code == 403:
                            opener = _get_unverified_context(verify, handlers)
                            try:
                                response = opener.open(req, timeout=15)
                            except HTTPError as e:
                                return e  # Give up
                elif any(x == ecode for x in [403, 429, 503]) and any(x in result for x in ['__cf_chl_f_tk', '__cf_chl_jschl_tk__=', '/cdn-cgi/challenge-platform/']):
                    if response := cf_responce(url, headers=_headers, post=post, timeout='30'):
                        log(f'scrapePage: using cf_responce: {url}')
                    # cookies, cf_ua = cfcookie().get(url, timeout)
                    # if cookies is None:
                    #     log(f'This site has an unsolvable Cloudflare challenge. url: {url}')
                    #     if not error: return ''
                    # _headers['Cookie'] = cookies
                    # _headers['User-Agent'] = cf_ua
                    # req = Request(url, data=post)
                    # _add_request_header(req, _headers)
                    # response = urlopen(req, timeout=int(timeout))
                else:
                    if not error: return log(f'url: {url} Error: {print_exc()}', __name__)
        except URLError as err:
            return lerror(f'URLError from: {__name__}: Error: {err}\nurl: {url}\n_headers: {_headers}')

        if not cookies:
            try: cookies = response.getheader('set-cookie')
            except:
                try: cookies = response.info().get_all('Set-Cookie')
                except: cookies = ''
        if output == 'cookie':
            # log(f'cookie: {cookie} type: {type(cookies)} cookies: {cookies}\nurl: {url}\n{repr(cookies)}')
            result = ''
            # if not cookies: return result
            if isinstance(cookies, str): result = cookies
            elif isinstance(cookies, dict): result = '; '.join([f'{x}={y}' for x, y in iter(cookies.items())])
            elif isinstance(cookies, list): result = '; '.join([f'{i.name}={i.value}' for i in cookies])
            # elif isinstance(cookies, 'http.cookiejar.LWPCookieJar'): result = '; '.join([f'{x}={y}' for x, y in iter(cookies.items())])
            return result
        elif output == 'elapsed':
            result = (time() * 1000) - start_time
            if close: response.close()
            return int(result)
        elif output == 'geturl':
            try: result = response.url
            except: result = response.geturl()
            if close: response.close()
            return result
        elif output == 'headers':
            result = dict(response.headers)
            if close: response.close()
            return result
        elif output == 'response':
            if close: response.close()
            return _get_result(response, limit)
        elif output == 'chunk':
            try: content = int(response.headers['Content-Length'])
            except BaseException: content = (2049 * 1024)
            if content < (2048 * 1024): return
            try: result = response.read(16 * 1024)
            except: result = response  # testing
            return result
        elif output == 'file_size':
            try: content = int(response.headers['Content-Length'])
            except BaseException: content = '0'
            response.close()
            return content
        result = _get_result(response, limit)

        if 'sucuri_cloudproxy_js' in str(result):  # who da fuck?
            su = sucuri().get(result)
            _headers['Cookie'] = su
            req = Request(url, data=post)
            req = _add_request_header(req, _headers)
            response = urlopen(req, timeout=int(timeout))
            result = _get_result(response, limit)
        if 'Blazingfast.io' in str(result) and 'xhr.open' in str(result):  # who da fuck?
            netloc = get_referer(url)
            ua = _headers['User-Agent']
            _headers['Cookie'] = cache.get(bfcookie().get, 168, netloc, ua, timeout)
            result = _basic_request(url, headers=_headers, post=post, timeout=timeout, limit=limit)
        if output == 'extended':
            try: response_headers = dict([(item[0].title(), item[1]) for item in list(response.info().items())])  # behaves differently 18 to 19. 18 I had 3 "Set-Cookie:" it combined all 3 values into 1 key. In 19 only the last keys value was present.
            except BaseException: response_headers = dict(response.headers)
            try: response_url = response.geturl()
            except: response_url = response.url
            # try: response_code = str(response.status)
            # except: response_code = str(response.status_code)  # object from CFScrape Requests object.
            if isinstance(cookies, str): cookies = cookies
            elif isinstance(cookies, dict): cookies = '; '.join([f'{x}={y}' for x, y in iter(cookies.items())])
            elif isinstance(cookies, list): cookies = '; '.join([f'{i.name}={i.value}' for i in cookies])
            if close: response.close()
            return result, _headers, response_headers, cookies, response_url
        elif output == 'json':
            result = loads(result)
            response.close()
            return result
        if close: response.close()
        if cache_resp: cache.cache_insert(url, repr({'text': result}))
        return result
    except Exception as err:
        lerror(f'Error from: {__name__}: Error: {err}\nurl: {url}\n_headers: {_headers}\npost: {repr(post)}')
        return None




class Cresponse():
    """ Adding Attribute to cache response return"""
    pass


def scrapePage(url, referer=None, headers=None, post=None, cookie=None, timeout=10, verify=True, output='', mobile=False, XHR=False):
    try:
        if not url: return
        _headers = headers if headers else {}
        response = None
        if post:
            if isinstance(post, dict): post = bytes(urlencode(post), encoding='utf-8')
            elif isinstance(post, str): post = bytes(post, encoding='utf-8')
        url = f'https:{url}' if url.startswith('//') else url
        _headers = headers if headers else {}
        if '|' in url:
            url, oheaders = get_headers_parse_url(url)
            _headers.update(oheaders)
        if _headers.get('verifypeer', '') == 'false':
            verify = False
            _headers.pop('verifypeer')
        if 'User-Agent' in _headers: pass
        elif mobile: _headers['User-Agent'] = cache.get(mobileagent, 2)
        else:
            if random_us: _headers['User-Agent'] = cache.get(agent, 2)
            else: _headers['User-Agent'] = UserAgent
        if 'Referer' in _headers: pass
        elif referer is None: _headers['Referer'] = get_referer(url)
        else: _headers['Referer'] = referer
        if 'Accept-Language' not in _headers: _headers['Accept-Language'] = 'en-US,en'
        if 'Accept' not in _headers: _headers['Accept'] = '*/*'
        if 'X-Requested-With' in _headers: pass
        elif XHR: _headers['X-Requested-With'] = 'XMLHttpRequest'
        if 'Accept-Encoding' in _headers: pass

        url = quote_plus(url, safe="%/:=&?~#+!$,;'@()*[]|")
        if cache_resp:
            data = cache.cache_get(url)
            # log(f'cache.cache_get data type: {type(data)} response.__dict__: {repr(data)}')
            if data:
                try: fdata = literal_eval(data['value'])
                except: fdata = eval(data['value'])
                # log(f'from cache type: {type(fdata)} response.__dict__: {repr(fdata)}')
                response = Cresponse()
                # content = fdata.get('_content')
                response.text = fdata.get('text')# content.decode(fdata.get('encoding') or 'UTF-8', errors='ignore')
                response.status_code = fdata.get('status_code')
                response.headers = fdata.get('headers')
                response.cookies = fdata.get('cookies')
                response.url = fdata.get('url')
                return response
        session = make_session(url)
        with session:
            session.headers.update(_headers)
            if referer and 'Referer' not in session.headers: session.headers.update({'Referer': referer})
            else:
                referer = get_referer(url)
                session.headers.update({'Referer': referer})
            if cookie and 'Cookie' not in session.headers: session.headers.update({'Cookie': cookie}) # not tested yet, just placed as a idea reminder.
            if 'python-requests' in str(session.headers) or 'User-Agent' not in session.headers: session.headers.update({'User-Agent': agent()})
            try:
                if post: response = session.post(url, data=post, timeout=int(timeout), verify=verify)
                else: response = session.get(url, timeout=int(timeout), verify=verify)
                """ ghetto fix for blockage that could probably be coded better."""
                # log(f'type: {type(response)} response.__dict__: {repr(response.__dict__)}')
                # log(f'type: {type(response)} response.__dict__: {repr(response)}')
                if isinstance(response, dict): return response
                resp_code = str(response.status_code)
                resp_header = response.headers
                resp_server = resp_header.get('Server', '')
                if resp_code in {'403', '503'} and resp_server == 'cloudflare':
                    iurl = get_referer(url)[:-1]
                    response = session.get(iurl, timeout=int(timeout), verify=verify)
                    cookies_dictionary = session.cookies.get_dict()
                    csrf = re.findall(r'csrf\-token"\s*content\s*=\s*"([^"]+)"', response.text, re.DOTALL)
                    if cookies_dictionary and csrf:
                        _headers['X-CSRF-TOKEN'] = csrf[0]
                        _headers.update(cookies_dictionary)
                    #log(f'scrapePage - url with cloudflare: {repr(url)} \niurl: {iurl}  cookies_dictionary: {cookies_dictionary}\nsession.headers: {session.headers}')
                    if response := cf_responce(url, headers=_headers, post=post, timeout='30'):
                        log(f'scrapePage: using cf_responce: {url}')
                    else:
                        from openscrapers.modules.proxy import get_proxy_url
                        if iurl := get_proxy_url(url):
                            log(f'scrapePage: using get_proxy_url: {iurl}')
                            if post: response = session.post(iurl, data=post, timeout=int(timeout))
                            else: response = session.get(iurl, timeout=int(timeout))
                            url = iurl
                response.encoding = 'utf-8'
                # response.raise_for_status()  # Commented out to make trakt progress option work properly again lol
            except SSLError as err:
                log(f'scrapePage SSLError as err: {err} url: {url}')
                if int(timeout) < 40: scrapePage(url, headers=_headers, post=post, timeout=int(timeout) + 10, verify=False)
            except Timeout as err:
                log(f'scrapePage Timeout as err: {err} url: {url}')
                if int(timeout) < 40: scrapePage(url, headers=_headers, post=post, timeout=int(timeout) + 10, verify=verify)
            except ConnectionError as err: log(f'scrapePage ConnectionError as err: {err} url: {url} session.headers:{session.headers}')
            except HTTPError as err: log(f'scrapePage HTTPError as err: {err} url: {url} session.headers:{session.headers}')
            except RequestException as err: log(f'scrapePage RequestException as err: {err} url: {url} session.headers:{session.headers}')
            except Exception as e: log(f'scrapePage except Exception as e: {e} url: {url}')
        # cookies_dictionary = session.cookies.get_dict()
        # log(f'cookies_dictionary: {cookies_dictionary}')
        # log(f'session_headers send: {session.headers}')
        # log(f'response.headers recived: {response.headers}')
        if not response: return log(f'scrapePage No response from url: {url} {response}')
        if cache_resp:
            cache_r = {'text': response.text, 'status_code': response.status_code, 'headers': response.headers, 'url': response.url, 'cookies': response.cookies.get_dict()}
            # log(f'cache.cache_get data type: {type(cache_r)} response.__dict__: {repr(cache_r)}')
            cache.cache_insert(url, repr(cache_r))
        if output == 'extended':
            try: response_headers = dict(response.headers)
            except BaseException: response_headers = dict([(item[0].title(), item[1]) for item in list(response.info().items())])  # behaves differently 18 to 19. 18 I had 3 "Set-Cookie:" it combined all 3 values into 1 key. In 19 only the last keys value was present.
            response_url = response.url
            # try: response_code = str(response.status)
            # except: response_code = str(response.status_code)  # object from CFScrape Requests object.
            cookies = session.cookies.get_dict()
            if isinstance(cookies, dict): cookies = '; '.join([f'{x}={y}' for x, y in iter(cookies.items())])
            elif isinstance(cookies, list): cookies = '; '.join([f'{i.name}={i.value}' for i in cookies])
            return response.text, _headers, response_headers, cookies, response_url
        elif output == 'cookie':
            result = ''
            cookies = session.cookies.get_dict()
            if isinstance(cookies, dict): result = '; '.join([f'{x}={y}' for x, y in iter(cookies.items())])
            elif isinstance(cookies, list): result = '; '.join([f'{i.name}={i.value}' for i in cookies])
            return result
        elif output == 'geturl': return response.url
        elif output == 'chunk':
            return response.text
        elif output == 'headers': return dict(response.headers)
        elif output == 'response': return response.text
        return response
    except Exception:
        lerror(f'Error from: {__name__}: url: {url} ')
        return


def url_ok(url): #  Old Code Saved.
    r = requests.get(url, headers=dnt_headers)
    return r.status_code in [200, 301]


_agents = ['Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 Edg/116.0.1938.62',
           'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0',
           'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
           'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.8464.47 Safari/537.36 OPR/117.0.8464.47',
           'Mozilla/5.0 (X11; Linux x86_64; rv:91.0) Gecko/20100101 Thunderbird/91.7.0',
           'Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Thunderbird/128.5.0',
           'Mozilla/5.0 (Macintosh; Apple macOS 15_1_1) AppleWebKit/537.36.0 (KHTML, like Gecko) Chrome/130.0.6723.118 Safari/537.36.0',
           'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.2 Safari/605.1.15 AlohaBrowser/6.3.2']


def randomagent():
    return choice(_agents)


def mobileagent(mobile='android'):
    _mobagents = [
        'Mozilla/5.0 (Linux; Android 13; T771K Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/130.0.6723.107 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/479.0.0.48.89;]',
        'Mozilla/5.0 (Linux; Android 14; V2339 Build/UP1A.231005.007; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/131.0.6778.39 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/491.0.0.58.78;IABMV/1;]',
        'Mozilla/5.0 (Linux; Android 14; RMX3708 Build/UP1A.231005.007; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/130.0.6723.83 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/488.0.0.78.79;IABMV/1;] FBNV/5',
        'Mozilla/5.0 (Linux; Android 14; 2409BRN2CA Build/UP1A.231005.007; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/130.0.6723.108 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/486.0.0.66.70;IABMV/1;]',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 17_7_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.7.2 Mobile/15E148 Safari/605.1.15 NewsSapphire/29.8.421122001',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 17_7_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.7.1 Mobile/15E148 Safari/605.1.15 BingSapphire/1.0.420822001',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 18_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1.1 Mobile/15E148 Safari/605.1.15 BingSapphire/29.6.421107001']

    if mobile == 'android': return choice(_mobagents[:4])
    else: return choice(_mobagents[5:7])


def agent():
    return choice(_agents)

def store(ftext, fname):
    try:
        fpath = translate_path(dataPath) + fname
        with open(fpath, 'w', encoding='utf-8') as f:
            f.write(ftext)
    except: pass


def retrieve(fname):
    try:
        fpath = translate_path(dataPath) + fname
        if existsPath(fpath):
            with open(fpath, encoding='utf-8') as f:
                ftext = f.readlines()
            return '\n'.join(ftext)
        else: return None
    except: return None


class cfcookie:
    def __init__(self):
        self.cookie = None
        self.ua = None

    def get(self, netloc, timeout):
        try:
            self.netloc = netloc
            self.timeout = timeout
            self._get_cookie(netloc, timeout)
            if self.cookie:
                cfdata = dumps({'Cookie': self.cookie, 'User-Agent': self.ua})
                store(cfdata, urlparse(netloc).netloc + '.json')
                log(f'{netloc} returned cookie. collect tokens.')
            return (self.cookie, self.ua)
        except:
            lerror(f'Error from: {__name__}: netloc: {netloc} ')
            return (self.cookie, self.ua)

    def _get_cookie(self, netloc, timeout):
        if setting('fs_enable') == 'true':
            bypass_url = setting('fs_url')
            fs_timeout = int(setting('fs_timeout'))
            if not bypass_url.startswith('http'):
                log('Sorry, malformed flaresolverr url', 'error')
                return
            post = {'cmd': 'request.get', 'url': netloc, 'returnOnlyCookies': True, 'maxTimeout': fs_timeout * 1000}
        else:
            bypass_url = urljoin(setting('cs_url'), '/cf-clearance-scraper')
            if not bypass_url.startswith('http'):
                log('Sorry, malformed cf-clearance-scraper url', 'error')
                return
            post = {'url': netloc, 'mode': 'waf-session'}

        resp = _basic_request(bypass_url, post=post, jpost=True)
        if resp:
            resp = loads(resp)
            if setting('fs_enable') == 'true':
                soln = resp.get('solution')
                if soln.get('status') < 300:
                    cookie = '; '.join(['%s=%s' % (i.get('name'), i.get('value')) for i in soln.get('cookies')])
                    if 'cf_clearance' in cookie:
                        self.cookie = cookie
                        self.ua = soln.get('userAgent')
                    else:
                        log('%s returned an error. Could not collect tokens.' % netloc)
            else:
                if resp.get('code') < 300:
                    rheaders = resp.get('headers')
                    cookies = resp.get('cookies')
                    cookies = {x.get('name'): x.get('value') for x in cookies}
                    if 'cf_clearance' in cookies.keys():
                        self.cookie = "; ".join([x + "=" + y for x, y in cookies.items()])
                        self.ua = rheaders.get('user-agent')
                    else:
                        log('%s returned an error. Could not collect tokens.' % netloc, 'error')
        else:
            try:
                headers = {}
                req = Request(netloc)
                req = _add_request_header(req, headers)

                try: response = urlopen(req, timeout=int(timeout))
                except HTTPError as response: log(f'Error: {response}')

                result = _get_result(response)
                jschl = re.findall(r'name\s*=\s*["\']jschl_vc["\']\s*value\s*=\s*["\'](.+?)["\']/>', result, re.I)
                if not jschl: return
                jschl = jschl[0]
                init = re.findall(r'setTimeout\(function\(\){\s*.*?.*:(.*?)};', result, re.I)[-1]
                builder = re.findall(r"challenge-form\'\);\s*(.*)a.v", result, re.I)[0]
                decryptVal = self.parseJSString(init)
                lines = builder.split(';')

                for line in lines:
                    if len(line) > 0 and '=' in line:
                        sections = line.split('=')
                        line_val = self.parseJSString(sections[1])
                        decryptVal = int(eval(str(decryptVal) + sections[0][-1] + str(line_val)))

                answer = decryptVal + len(urlparse(netloc).netloc)
                query = f'{netloc}/cdn-cgi/l/chk_jschl?jschl_vc={jschl}&jschl_answer={answer}'

                if 'type="hidden" name="pass"' in result:
                    passval = re.findall(r'name\s*=\s*["\']pass["\']\s*value\s*=\s*["\'](.*?)["\']', result, re.I)[0]
                    query = f'{netloc}/cdn-cgi/l/chk_jschl?pass={quote_plus(passval)}&jschl_vc={jschl}&jschl_answer={answer}'
                    sleep(6)
                cookies = cookiejar.LWPCookieJar()
                handlers = [HTTPHandler(), HTTPSHandler(), HTTPCookieProcessor(cookies)]
                opener = build_opener(*handlers)
                install_opener(opener)
                try:
                    req = Request(query)
                    req = _add_request_header(req, headers)
                    response = urlopen(req, timeout=int(timeout))
                    self.ua = response.info().get('User-Agent', '')
                except: pass

                cookie = '; '.join([f'{i.name}={i.value}' for i in cookies])
                if cookie: self.cookie = cookie
            except: lerror(f'get_cookie-Error: ({print_exc()}) ')

    def parseJSString(self, s):
        try:
            offset = 1 if s[0] == '+' else 0
            return int(eval(s.replace('!+[]', '1').replace('!![]', '1').replace('[]', '0').replace('(', 'str(')[offset:]))
        except: lerror(f'parseJSString-Error: ({print_exc()}) ')

class bfcookie:
    def __init__(self):
        self.COOKIE_NAME = 'BLAZINGFAST-WEB-PROTECT'

    def get(self, netloc, ua, timeout):
        try:
            headers = {'User-Agent': ua, 'Referer': netloc}
            result = _basic_request(netloc, headers=headers, timeout=timeout)
            match = re.findall(r'xhr\.open\("GET","([^,]+),', result, re.I)
            if not match: return False
            url_Parts = match[0].split('"')
            url_Parts[1] = '1680'
            url = urljoin(netloc, ''.join(url_Parts))
            match = re.findall(r'rid\s*?=\s*?([0-9a-zA-Z]+)', url_Parts[0])
            if not match: return False
            headers['Cookie'] = f'rcksid={match[0]}'
            result = _basic_request(url, headers=headers, timeout=timeout)
            return self.getCookieString(result, headers['Cookie'])
        except: lerror(f'Error from: {__name__}:  netloc: {netloc}')

    # not very robust but lazieness...
    def getCookieString(self, content, rcksid):
        vars = re.findall(r'toNumbers\("([^"]+)"', content)
        value = self._decrypt(vars[2], vars[0], vars[1])
        return f'{self.COOKIE_NAME}={value};{rcksid}'

    def _decrypt(self, msg, key, iv):
        from binascii import hexlify, unhexlify
        msg = unhexlify(msg)
        key = unhexlify(key)
        iv = unhexlify(iv)
        if len(iv) != 16: return False
        decrypter = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(key, iv))
        plain_text = decrypter.feed(msg)
        plain_text += decrypter.feed()
        return hexlify(plain_text)


class sucuri:
    def __init__(self):
        self.cookie = None

    def get(self, result):
        from base64 import b64decode
        try:
            s = re.compile(r"S\s*=\s*'([^']+)").findall(result)[0]
            s = b64decode(s)
            s = s.replace(' ', '')
            s = re.sub(r'String\.fromCharCode\(([^)]+)\)', r'chr(\1)', s)
            s = re.sub(r'\.slice\((\d+),(\d+)\)', r'[\1:\2]', s)
            s = re.sub(r'\.charAt\(([^)]+)\)', r'[\1]', s)
            s = re.sub(r'\.substr\((\d+),(\d+)\)', r'[\1:\1+\2]', s)
            s = re.sub(r';location.reload\(\);', '', s)
            s = re.sub(r'\n', '', s)
            s = re.sub(r'document\.cookie', 'cookie', s)
            cookie = ''
            exec(s)
            self.cookie = re.compile(r'([^=]+)=(.*)').findall(cookie)[0]
            self.cookie = f'{self.cookie[0]}={self.cookie[1]}'
            return self.cookie
        except: lerror(f'Error from: {__name__}: ')


def get_fheaders(url=None, headers=None):
    _headers = headers if headers else {'User-Agent': agent(), }
    if url and 'Referer' not in _headers:
        _headers['Referer'] = get_referer(url)
    if 'User-Agent' not in _headers: _headers['User-Agent'] = agent()
    return dict(_headers, **fheaders)


def cf_responce(url, headers=None, post=None, timeout='30'):
    try:
        # url = quote(url, safe=':/')
        _headers = get_fheaders(url, headers)
        if post: _headers.update({'Content-Type': 'application/json'})
        else: _headers.update({'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'})
        data = None
        if post:
            if isinstance(post, dict): data = post
            else:
                try: data = parse_qs(post)
                except: pass
        scraper = cfscrape.CloudScraper()
        response = scraper.request(method='GET' if post is None else 'POST', url=url, headers=_headers, data=data, timeout=int(timeout))
        if response.status_code == 403: response = scraper.request(method='GET' if post is None else 'POST', url=url, data=data, timeout=int(timeout))
        return response
    except: lerror(f'Error from: {__name__}: url: {url} ')


def direct_request(url):
    hea = {'Referer': '', 'User-Agent': 'okhttp/4.9.3', 'Accept-Encoding': 'gzip, deflate', 'Accept': '*/*', 'Connection': 'keep-alive'}
    resp = requests.get(url, headers=hea)
    # resp = _get_result(resp)
    json_text = GzipFile(fileobj=BytesIO(resp.content)).read()
    # logger(f'json_text: {repr(json_text)}')
    return loads(json_text)


def _get_encoding(response):
    try:
        try: return response.info().getheader('Content-Encoding')
        except: return response.headers['Content-Encoding']
    except: lerror(f'Error from: {__name__}: ')
    return None


def _get_unverified_context(verifySsl, handlers, TLSv1_3=True):
    import ssl
    ctx = None
    # log(f'get_default_verify_paths: {repr(ssl.get_default_verify_paths())}')
    if verifySsl:
        try:
            from openscrapers.modules.control import get_kodi_certi_file
            ctx = ssl.create_default_context(cafile=get_kodi_certi_file())
            ctx.set_alpn_protocols(['http/1.0', 'http/1.1'])
        except: pass
    if not verifySsl or ctx is None:
        # ctx = ssl._create_unverified_context()
        # ssl._create_default_https_context = ssl._create_unverified_context
        ctx = ssl.create_default_context()
        TLSV = ssl.TLSVersion.TLSv1_2
        if TLSv1_3: TLSV = ssl.TLSVersion.TLSv1_3
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        ctx.maximum_version = TLSV
        ctx.set_alpn_protocols(['http/1.0', 'http/1.1'])
    if ctx: handlers += [HTTPSHandler(context=ctx, debuglevel=1)]
    return build_opener(*handlers)


def get_content(response, encoding=None):
    try:
        content_type = response.headers.get('content-type', '').lower()
        text_content = any(x in content_type for x in ['text', 'json', 'xml', 'mpegurl'])
        if 'charset=' in content_type: encoding = content_type.split('charset=')[-1]
        if encoding is None:
            epatterns = [r'<meta\s+http-equiv="Content-Type"\s+content="(?:.+?);\s+charset=(.+?)"', r'xml\s*version.+encoding="([^"]+)']
            for epattern in epatterns:
                epattern = epattern.encode('utf8')
                if r := re.search(epattern, response.content, re.IGNORECASE):
                    encoding = brutforce_decode(r[1])
                    break
        if encoding is None:
            if r := re.search(b'^#EXT', response.content, re.IGNORECASE):
                encoding = 'utf8'
        if encoding is not None: return brutforce_decode(response.content, encoding, errors='ignore')
        elif text_content: return brutforce_decode(response.content)
        else: log('Unknown Page Encoding')
    except: lerror(f'Error from: {__name__}: ')
    return


def refresh_redirect(url, headers=None):
    _headers = get_fheaders(url, headers)
    refresh = True
    html = ''
    while refresh:
        # log(f'refresh_redirect url: {url} _headers: {_headers}')
        if result := request(url, headers=_headers, output='extended'):
            html = result[0]
            response_headers = result[2]
            # log(f'result {type(result[0])}, response_code {type(result[1])}, response_headers {type(result[2])}, _headers {type(result[3])}, cookie {type(result[4])}, response_url {type(result[5])}')
            if response_headers.get('Refresh'): url = response_headers.get('Refresh').split(' ')[-1]
            elif 'http-equiv="refresh"' in html: url = unescape(re.findall(r'http-equiv="refresh".+?url=([^"]+)', html)[0])
            else: refresh = False
        else: refresh = False
    return html


def list_request(doms, query='', scheme='https://'):
    if isinstance(doms, list):
        for i in range(len(doms)):
            dom = choice(doms)
            try:
                base_link = dom if dom.startswith('http') else scheme + dom
                url = urljoin(base_link, query)
                # log(f'list_request i: {i} url: {url}')
                r = requests.get(url, headers={'User-Agent': agent(), 'Referer': base_link}, timeout=7)
                if r.ok:
                    #log('list_request chosen base: ' + base_link)
                    return r.text, base_link
                raise Exception()
            except Exception:
                doms = [d for d in doms if d != dom]
                lerror(f'list_request failed dom: {repr(i)} - {dom}')
    else:
        base_link = doms if doms.startswith('http') else scheme + doms
        url = urljoin(base_link, query)
        # log(f'list_request url: {url}')
        r = requests.get(url, headers={'User-Agent': agent(), 'Referer': base_link}, timeout=10)
        if r.ok:
            #log('list_request chosen base: ' + base_link)
            return r.text, base_link
        raise Exception()


def get_page_server(url, selector='', end_point='getp', timeout='30'):
    url_api = f'https://v-resol.vercel.app/api/{end_point}'
    ft = {'id': f'{url}/', 'selector': selector}
    return request(url_api, post=ft, timeout=timeout, verify=False)
