# -*- coding: UTF-8 -*-

import os
from traceback import print_exc, print_stack
from pkgutil import walk_packages
from urllib.parse import parse_qs, urljoin, urlparse, urlencode, quote, unquote, quote_plus, unquote_plus, parse_qsl

try:
	from openscrapers.modules.control import setting, joinPath
	from openscrapers.modules.log_utils import log, error
	from openscrapers.modules import cfscrape
	from openscrapers.modules.cache import get, get_all_data, _execute, _executemany
	from openscrapers.modules.utils import make_thread_list
	cfScraper = cfscrape.create_scraper()
	debug = setting('debug.enabled') == 'true'
	provider = setting('module.provider').lower()
	testing = False
except:
	from .modules.log_utils import log, error
	__addon__ = None
	debug = True
	testing = True
	provider = 'sources_openscrapers'
	joinPath = os.path.join
	HostedMediaFile = []
# log(f'testing : {testing} provider: {provider}')
hindi_providers = ('desirulez', 'desicinemas', 'serialghar', 'watchapne', 'desiserials', 'desitelly', 'yodesi', 'playdesi')
sourceFolder = 'sources_openscrapers'


def sources(ret_all=False, media_type=None, vid_type=None, retry=0):
	try:
		# log(f'ret_all= {ret_all} media_type= {media_type} vid_type= {vid_type}')
		retry += 1
		sourceDict = []
		sourceDict_append = sourceDict.append
		sourceFolderLocation = joinPath(os.path.dirname(__file__), sourceFolder, 'en')
		# log(f'sourceFolderLocation: {sourceFolderLocation}')
		# sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
		usefull_scrapers = get(external_scrapers_fail_stats)
		# if debug and usefull_scrapers: log(f'total: {len(usefull_scrapers)} >> usefull_scrapers: {usefull_scrapers}')
		not_usefull = []
		not_usefull_append = not_usefull.append
		for loader, module_name, is_pkg in walk_packages([sourceFolderLocation]):
			if is_pkg: continue
			if not ret_all and not enabledCheck(module_name): continue
			if vid_type and media_type == 'episode' and module_name not in hindi_providers: continue
			elif not vid_type and module_name in hindi_providers: continue
			if not ret_all and usefull_scrapers and module_name not in usefull_scrapers: not_usefull_append(module_name); continue
			# log(f'media_type: {media_type} module_name: {module_name} is_pkg: {is_pkg} loader: {loader} ')
			try: module = loader.find_spec(module_name).loader.load_module(module_name) #may be using in future
			except:
				log(f'Error: loader.find_spec: "{module_name}": {print_stack(limit=15)}')
				try: module = loader.find_module(module_name).load_module(module_name)
				except: log(f'Error: loader.find_module: "{module_name}": {print_stack(limit=15)}'); not_usefull_append(module_name) ; continue
			module_source = module.source()
			try:
				if media_type == 'episode' and getattr(module_source, 'tvshow'): sourceDict_append((module_name, module_source))
				elif media_type == 'movie' and getattr(module_source, 'movie'): sourceDict_append((module_name, module_source))
				else: sourceDict_append((module_name, module_source))
			except: not_usefull_append(module_name)
		if debug and sourceDict and usefull_scrapers: log(f'retry: {retry} using Providers: {len(sourceDict)}|{len(usefull_scrapers)} for media_type: {media_type}')# not usefull Providers: {len(not_usefull)}')
		#log(f'not_usefull: {not_usefull}')
		if retry > 1: return sourceDict
		elif not sourceDict: sources(True, media_type, vid_type, retry)
		return sourceDict
	except Exception as e:
		log(f'Error: sources: {e} {print_stack(limit=15)}')
		return []

def enabledCheck(module_name):
	try: return setting(f'provider.{module_name}') == 'true'
	except: return True


def pack_sources(sourceSubFolder='torrents'):
	return []

def getScraperFolder():
	try:
		sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
		sourceSubFolders = [x for x in sourceSubFolders if x not in ['__pycache__', 'help', 'modules', 'cfscrape', 'pyaes']]
		return [i for i in sourceSubFolders if 'openscrapers' in i.lower()][0]
	except:
		error('getScraperFolder: ')
		return 'sources_openscrapers'

def providerSources():
	sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
	return getModuleName(sourceSubFolders)


def providerNames():
	providerList = []
	append = providerList.append
	# provider = setting('module.provider')
	sourceFolder = getScraperFolder()
	sourceFolderLocation = joinPath(os.path.dirname(__file__), sourceFolder)
	sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
	for i in sourceSubFolders:
		for loader, module_name, is_pkg in walk_packages([joinPath(sourceFolderLocation, i)]):
			if is_pkg: continue
			correctName = module_name.split('_')[0]
			append(correctName)
	return providerList


def getAllHosters():
	def _sources(sourceFolder, append):
		sourceFolderLocation = os.path.join(os.path.dirname(__file__), sourceFolder)
		sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
		for i in sourceSubFolders:
			for loader, module_name, is_pkg in walk_packages([os.path.join(sourceFolderLocation, i)]):
				if is_pkg: continue
				try: mn = str(module_name).split('_')[0]
				except: mn = str(module_name)
				append(mn)
	sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
	appendList = []
	append = appendList.append
	for item in sourceSubFolders:
		if item not in ['__pycache__', 'modules', 'cfscrape', 'pyaes']:
			_sources(item, append)
	return list(set(appendList))


def getModuleName(scraper_folders):
	nameList = []
	append = nameList.append
	for s in scraper_folders:
		if s not in ['__pycache__', 'modules', 'cfscrape', 'pyaes']:
			try: append(s.split('_')[1].lower().title())
			except: pass
	return nameList


def custom_base_link(scraper):
	try:
		url = setting(f'url.{scraper}')
		if not url: return None
		url = url if url.startswith('http') else f'https://{url}'
	except: url = None
	return url



def getapi_keys():
	from random import choice
	api_keys = {'api_keys': {}}
	api_keys['api_keys']['trakt.client'] = setting('trakt.client') or '1038ef327e86e7f6d39d80d2eb5479bff66dd8394e813c5e0e387af0f84d89fb' #'e3a8d1c673dfecb7f669b23ecbf77c75fcfd24d3e8c3dbc7f79ed995262fa1db' #'63c53edc299b7a05cc6ea2272e8a84e13aade067c18a794362ab9a4a84eafb16'
	api_keys['api_keys']['trakt.secret'] = setting('trakt.secret') or '8d27a92e1d17334dae4a0590083a4f26401cb8f721f477a79fd3f218f8534fd1' # '73bee6aeee29cb75db4d8771458a440017f7cfe842e85f457ed9d81f7910b349' #'9163ebda9d33acd06c74d017e861404b7212ee34675e09e73365d7536b84eab6'
	api_keys['api_keys']['fanart'] = setting('fanart') or 'cf3429b06e1bbccc9d1e1b86b32fc51a'
	api_keys['api_keys']['tmdb'] = setting('tmdb') or 'd848316a33e79095beb945a2bd2d53b1' #'05a454b451f2f9003fbca293744e4a85'
	api_keys['api_keys']['tmdb.user'] = setting('tmdb.user') or 'aaaas'
	api_keys['api_keys']['tmdb.pw'] = setting('tmdb.pw') or '6666'
	api_keys['api_keys']['tmdb.token'] = setting('tmdb.token') or ''
	api_keys['api_keys']['tmdb.account_id'] = setting('tmdb.account_id') or ''
	# api_keys['api_keys']['tmdb.tmdb_read_token'] = setting('tmdb.tmdb_read_token') or 'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJkODQ4MzE2YTMzZTc5MDk1YmViOTQ1YTJiZDJkNTNiMSIsIm5iZiI6MTcxMTQ3Mzg1NC45MzQsInN1YiI6IjY2MDMwNGJlYjAyZjVlMDE3ZDIxNDAzZSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ._uRCLIwLIE2gOlH8q04gcM3ywIXpxuZ-uyel-UMRRg4'
	api_keys['api_keys']['opensubs.user'] = setting('opensubs.user') or 'aaaajjjj0'
	api_keys['api_keys']['opensubs.pw'] = setting('opensubs.pw') or '6666Mill_'
	api_keys['api_keys']['opensubstoken'] = setting('opensubstoken') or 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIwa3RuNE92SnNTWWk0cFczeTRtOGdINWFFaXFPWjEwaiIsImV4cCI6MTczNzIwNDM4N30.IPHkjK5KtQ5S3_o78FpbDed7ql2Ds_tiYuvm6YJ_n94'
	api_keys['api_keys']['imdbuser'] = setting('imdbuser') or '56044779'
	api_keys['api_keys']['mdblist'] = setting('mdblist') or 'osscknixflg2dogpr271ujz18'
	api_keys['api_keys']['simkltoken'] = setting('simkltoken') or '110460fa96e0cb8c6a4768de14983374376090247ba4a55fb55ac66c26e3b732'
	api_keys['api_keys']['tvdb'] = setting('tvdb') or '06cff30690f9b9622957044f2159ffae'
	# api_keys['api_keys']['filepursuittoken'] = setting('filepursuit.api') or 'e1235ccc65msh9c6da42a2ff1797p199cefjsnaa4033afc078'
	api_keys['api_keys']['gemini_api'] = setting('gemini_api') or 'AIzaSyA1aLFES7CEbZzpnc8dSo61fGuiQ-eHEhY'
	api_keys['api_keys']['groq_api'] = setting('groq_api') or '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'
	api_keys['api_keys']['tvdb'] = setting('tvdb') or choice(['06cff30690f9b9622957044f2159ffae', '1D62F2F90030C444', '7R8SZZX90UA9YMBU'])
	return api_keys


def get_urls():
	urls = {'urls': {}}
	urls['urls']['desicinemas'] = setting('url.desicinemas')
	urls['urls']['desirulez'] = setting('url.desirulez')
	urls['urls']['desiserials'] = setting('url.desiserials')
	urls['urls']['playdesi'] = setting('url.playdesi')
	urls['urls']['yodesi'] = setting('url.yodesi')
	urls['urls']['ddlive'] = setting('ddlive')
	return urls #dict(urls, **getapi_keys())

def get_creden(info='', expires=''):
	from openscrapers.modules.trakt import trakt_user_active, refresh_token, getTraktAsJson
	# from openscrapers.modules.cleandate import utc_to_datetime
	# refresh_at = utc_to_datetime(float(setting("trakt.expires")))
	# log(f'{info} trakt.refresh at: {refresh_at}')
	if trakt_user_active():
		if setting('only_infinite_trakt'): token = refresh_token(info)
		else: token = refresh_token(info)
		activities = getTraktAsJson('/sync/last_activities')
		# log(f'>>>>>>>>>>> activities: {activities}')
	trakt = {'trakt': {}}
	# if activities:
	trakt['trakt']['token'] = setting('trakt.token')
	trakt['trakt']['user'] = setting('trakt.user')
	trakt['trakt']['refresh'] = setting('trakt.refresh')
	trakt['trakt']['expires'] = setting('trakt.expires')
	return dict(trakt, **getapi_keys(), **get_urls())


## from infinite


def check_hosted_media(vid_url):
	from resolveurl import HostedMediaFile
	hmf = HostedMediaFile(url=vid_url, include_disabled=True, include_universal=False)
	if hmf.valid_url() is True:
		if rpart := hmf.resolve(): return rpart
	return


def get_hosts():
	def make_hostlist():
		from functools import reduce
		try:
			from resolveurl import relevant_resolvers
			pr_list = relevant_resolvers(order_matters=True)
			pr_list = [i.domains for i in pr_list if '*' not in i.domains]
			pr_list = [i.lower() for i in reduce(lambda x, y: x+y, pr_list)]
			pr_list = [x for y, x in enumerate(pr_list) if x not in pr_list[:y]]
		except: pr_list = []
		# log(f'make_hostlist pr_list {len(pr_list)} {pr_list}')
		return list(set(pr_list))
	return get(make_hostlist)


try: hosts_list = get_hosts()
except: hosts_list = []

def get_provider():
	try:
		scraper_stats = get_all_data('prov_perf')
		scraper_stats.sort(key=lambda a: a[1], reverse=True)
		return [str(i[0]) for i in scraper_stats if i[1] >= 2]
	except: return ['gdrive', 'filemoon', 'streamtape', 'trade', 'bestarticles', 'tellygossips', 'filelions', 'furher', 'youtube', 'eplayvid', 'cdn4', 'doodstream', 'streamwish', 'tvarticles', 'Folder 2']


def external_scrapers_fail_stats():
	threshold = int(setting('failing_scrapers.threshold', 0))
	data = get_all_data()
	# log(f'data: {repr(data)}')
	# results = sorted([(str(i[0]), i[1], i[2]) for i in results], key=lambda k: k[2] - k[1], reverse=False)
	# results = sorted([(str(i.get('source')), i.get('success'), i.get('failure')) for i in data], key=lambda k: k[2] - k[1], reverse=False)
	# results = sorted([(str(i.get('source')), i.get('success'), i.get('failure')) for i in data if i.get('success') >= threshold], key=lambda k: k[2] - k[1], reverse=False)
	try: results = [i[0] for i in data if i[1] >= threshold or i[1] >= 1]
	except: results = [i[0] for i in data]
	return results


def sourcesstats(sourcedict, sources):
	try:
		insert_list = []
		all_sources = [i[0] for i in sourcedict if all(x not in i[0] for x in ('season', 'show'))]
		working_scrapers = sorted(list({i['provider_site'] for i in sources}))
		non_working_scrapers = sorted([i for i in all_sources if i not in working_scrapers])
		scraper_stats = get_all_data()
		if scraper_stats:
			for i in scraper_stats:
				try:
					scraper, success, fail = str(i[0]), i[1], i[2]
					if scraper in working_scrapers:
						insert_list.append((scraper, success + 1, fail))
						working_scrapers.remove(scraper)
					else:
						insert_list.append((scraper, success, fail + 1))
						non_working_scrapers.remove(scraper)
				except: pass
		if len(working_scrapers) > 0: insert_list.extend((scraper, 1, 0) for scraper in working_scrapers)
		if len(non_working_scrapers) > 0: insert_list.extend((scraper, 0, 1) for scraper in non_working_scrapers)
		# log(f'sourcesstats insert_list: {insert_list}')
		if insert_list: _executemany("INSERT OR REPLACE INTO scr_perf VALUES (?, ?, ?)", insert_list)
	except: error(f'sourcesstats Error: {print_exc()}')


def external_scrapers_reset_stats():
	try:
		def reset_data(scraper_stats, _from):
			insert_list = []
			for i in scraper_stats:
				i1 = i2 = 1
				try:
					half_value = i[1] // 2
					if i[1] > 20: i1 = 1 if half_value < 2 else half_value
					else: i1 = i[1]
					#if i[2] > 1: i2 = 1 if half_value < 2 else i[2] - half_value
				except: pass
				insert_list.append((i[0], i1, i2))
			log(f'{_from} insert_list: {insert_list}')
			return insert_list
		_execute("DELETE FROM scr_perf WHERE success IS NULL OR success = '0'", ())
		if scraper_stats := get_all_data():
			insert_list = reset_data(scraper_stats, 'scr_perf')
			if insert_list: _executemany("INSERT OR REPLACE INTO scr_perf VALUES (?, ?, ?)", insert_list)
		if scraper_stats := get_all_data('prov_perf'):
			insert_list = reset_data(scraper_stats, 'prov_perf')
			if insert_list: _executemany("INSERT OR REPLACE INTO prov_perf VALUES (?, ?, ?)", insert_list)
		return True
	except:
		error(f'external_scrapers_reset_stats Error: {print_exc()}')
		return False


def providerstats(info):
	try:
		insert_list = []
		working_source = str(info).split('.')[0]
		if working_source in ('www', 'Folder'): return
		c_data = _execute("SELECT success FROM prov_perf WHERE source = ?", (working_source,)).fetchone()
		if c_data: insert_list.append((working_source, c_data[0] + 1, 1))
		else: insert_list.append((working_source, 1, 1))
		# log(f'{info} insert_list: {insert_list}')
		if insert_list: _executemany("INSERT OR REPLACE INTO prov_perf VALUES (?, ?, ?)", insert_list)
	except: error(f'providerstats Error: {print_exc()}')

def test_progress():
	try:
		import requests, ssl
		ctx = None
		log(f'ssl.OPENSSL_VERSION: {ssl.OPENSSL_VERSION}\nrequests.certs.where(): {requests.certs.where()}\nget_default_verify_paths: {repr(ssl.get_default_verify_paths())}')
		import time
		from openscrapers.modules.utils import make_qrcode
		from openscrapers.windows.base import getProgressWindow
		from openscrapers.modules.control import sleep
		device_codes = {'expires_in': 80, 'interval': 1, 'verification_url': 'https://trakt.tv/activate?code={str(device_codes["user_code"])', 'user_code': 'ADBFDRF'}
		start = time.time()
		expires_in = device_codes['expires_in'] + start
		progres_msg = f'Please Scan the QR Code[CR][CR] Or open this link in a browser: [B]https://trakt.tv/activate[/B][CR]When prompted enter : [COLOR FF6CB201]{str(device_codes["user_code"])}[/COLOR]'
		token_url = f'https://trakt.tv/activate?code={str(device_codes["user_code"])}'
		qr_code = ''#make_qrcode(token_url, 'trakt') or ''
		progressD = getProgressWindow('TMDb Account Authorization', qr_code, 1)
		progressD.set_controls()
		log(f'progres_msg: {repr(progres_msg)}\n {repr(expires_in)}\n {repr(divmod(expires_in - time.monotonic(), 60))}')
		progressD.update(0, progres_msg)
		try:
			progress = 0
			while not progressD.iscanceled() and progress < expires_in:
				progres_ = '%02d:%02d' % divmod(expires_in - time.time(), 60)
				if progres_ == '00:00' or progressD.iscanceled(): break
				log(f'progress: {progress} progres_msg: {repr(progres_)}')
				progressD.update(progress, f'Remaining Time: [B]{progres_}[/B][CR]{progres_msg}')
				sleep(max(device_codes['interval'], 1)*1000)
				progress = max((time.time() - start), 0)
		except: error(f'error: ')
		finally:
			progressD.close()
	except: return error(f'device_codes: {device_codes}')

def test_trakt():
	try:
		from openscrapers.modules.trakt import trakt_user_active, refresh_token, getTraktAsJson
		# authTrakt()
		# if trakt_user_active():
		from datetime import datetime
		from openscrapers.modules import cleandate
		from openscrapers.modules.control import setSetting
		# refresh_token()
		expires = setting('trakt.expires')
		log(f'>>>>>>>>>>> refresh_token: {expires}')
		expires_in = datetime.fromtimestamp(float(expires))
		# log(f'>>>>>>>>>>> refresh_token: {expires_in}')
		expires_in = cleandate.utc_to_datetime(float(expires))
		log(f'>>>>>>>>>>> refresh_token: {expires_in[0:10]}')
		setSetting('trakt_renual', expires_in[0:10])
		# if not trakt_user_active(): log('>>>>>>>>>>> not refresh_token:')
	except: error(f'test_trakt Error: {print_exc()}'); return

def ssl_get_info():
	import itertools
	import certifi
	import socket
	import os, sys, ssl, urllib3, requests
	from platform import platform, python_version
	from openscrapers.modules.control import get_kodi_certi_file
	log(f'OS platform()        : {platform()}')
	# log(f'certifi.where(): {repr(certifi.where())}')
	lcafile = get_kodi_certi_file()
	# lcafile = certifi.where()
	log(f'get_kodi_certi_file(): {repr(lcafile)}')
	log(f'Python platform()    : \n{python_version()}\n{sys.version}')
	log(f'ssl.OPENSSL_VERSION  : {ssl.OPENSSL_VERSION}\nssl.OPENSSL_VERSION_NUMBER: {ssl.OPENSSL_VERSION_NUMBER}\nssl.OPENSSL_VERSION_INFO: {ssl.OPENSSL_VERSION_INFO}')
	log(f'urllib3.__version__  : {urllib3.__version__}')
	log(f'requests.__version__ : {requests.__version__}')
	# log(f'requests.help        : {requests.help}')
	log(f'ssl.get_default_verify_paths() {ssl.get_default_verify_paths()}')
	# which is used to create an SSLSocket
	# Create an SSLContext instance by specifying the highest TLS protocol
	# that both the client and the server supports
	sslSettings = ssl.SSLContext(ssl.PROTOCOL_TLS)
	sslSettings.verify_mode = ssl.CERT_REQUIRED
	# Load the CA certificates used for validating the peer's certificate
	sslSettings.load_verify_locations(cafile=lcafile, capath=None, cadata=None)
	# Create a connection oriented socket
	con_socket = socket.socket()
	# Make SSLSocket from the connection oriented socket
	sslSocket  = sslSettings.wrap_socket(con_socket)
	con_socket.close()
	# Connect to a server using TLS
	sslSocket.connect(("python.org", 443))
	log(f'SSLContext object                        : {repr(sslSettings)}')
	# Get the context from SSLSocket and print
	context = sslSocket.context
	log(f'SSLContext object obtained from SSLSocket: {repr(context)}')
	log(f'The type of the secure socket created    : {repr(context.sslsocket_class)}')
	log(f'Maximum version of the TLS               : {repr(context.maximum_version)}')
	log(f'Minimum version of the TLS               : {repr(context.minimum_version)}')
	log(f'SSL options enabled in the context object: {repr(context.options)}')
	log(f'Protocol set in the context              : {repr(context.protocol)}')
	log(f'Verify flags for certificates            : {repr(context.verify_flags)}')
	# sslSettings.verify_flags &= ~ssl.VERIFY_X509_STRICT
	# sslSettings.verify_flags += ssl.VERIFY_X509_PARTIAL_CHAIN
	# Added in version py 3.4
	context.verify_flags = context.verify_flags & ~ssl.VERIFY_X509_STRICT
	# Added in version py 3.10.
	context.verify_flags = context.verify_flags & ~ssl.VERIFY_X509_PARTIAL_CHAIN
	log(f'cVerify flags for certificates           : {repr(context.verify_flags)}')
	log(f'Verification mode(how to validate peer\'s certificate and handle failures if any):{repr(sslSocket.context.verify_mode)}')
	# Do SSL shutdown handshake
	sslSocket.unwrap()
	# Close the SSLSocket instance
	sslSocket.close()
	return

def test_request():
	from openscrapers.modules.client import make_session, request
	# from openscrapers.modules.client_session import Session
	# session = Session()
	url = 'https://dlhd.dad/24-7-channels.php'
	data = request(url, verify=False)
	# session = make_session()
	# data = session.get(url, verify=False)
	log(f'data: {repr(data)}')


def action_test_func():
	try:
		test_trakt()
		# test_request()
		return
		import json, time
		from openscrapers.modules.opensubs import Opensubs
		from openscrapers.modules.control import temppath, selectDialog
		choices = ['Step 1: Use the QR Code to approve access at TMDB\n            Navigate to: line2 ok', ('Step 2: Access approved at TMDB'), ('Cancel')]
		# choice = selectDialog([i for i in choices], 'TMDBList')
		# log(f'choice: {repr(choice)}')
		imdb_id = 'tt6470478'
		query = 'The Good Doctor'
		language = 'en'
		season = 6
		episode = 10
		# from openscrapers.modules.trakt import __getTrakt
		# activities = __getTrakt('/sync/last_activities')
		activities = test_progress()
		log(f'activities: {repr(activities)}')
		# data = Opensubs().getSubs(query, imdb_id, season, episode)
		# if data: log(f'total: {len(data)} data: {data}')
		# insert_list = [('desiserials', 7, 1), ('serialghar', 2, 1), ('yodesi', 13, 1), ('desirulez', 7, 1), ('123moviestv_me', 13, 1), ('cinebox_cc', 13, 1), ('databasegdriveplayer_co', 7, 1), ('gowatchseries_ch', 2, 1), ('vumoo_to', 1, 1), ('dopebox_to', 13, 1), ('gdriveplayer_us', 5, 1), ('goku_to', 1, 1), ('myflixer_it', 11, 1), ('watchserieshd_stream', 7, 1), ('winnoise_com', 10, 1), ('couchtuner_show', 5, 1), ('0123movies_ch', 1, 1), ('123movies_skin', 1, 1), ('bstsrs_one', 8, 1), ('desitelly', 7, 1), ('hindilinks4u', 1, 1), ('tvseries_video', 6, 1), ('yomovies_bio', 1, 1), ('ytube', 1, 1), ('gdrive', 8, 1), ('c1ne_co', 1, 1), ('filepursuit', 10, 1), ('putlocker_to', 1, 1), ('soap2day_fan', 1, 1), ('f123movies_com', 1, 1), ('cinecalidad_vet', 1, 1), ('noxx_to', 3, 1), ('1movies_la', 5, 1), ('himovies_top', 12, 1), ('primewire_mx', 2, 1), ('desicinemas', 2, 1), ('upmovies_to', 1, 1), ('series9movies_com', 1, 1), ('movies2watch_tv', 12, 1), ('watchapne', 2, 1), ('lordhd_one', 1, 1), ('iwaatch_com', 1, 1), ('anymovies_co', 2, 1), ('filmxy_pw', 1, 1), ('doomovies_ga', 1, 1), ('movierulz', 1, 1), ('gomovies_sx', 10, 1), ('upmovies_net', 1, 1), ('vumoo_mx', 1, 1), ('levidia_ch', 4, 1), ('flixhq_to', 1, 1), ('projectfreetv_lol', 1, 1), ('tinyzonetv_to', 1, 1)]
		# if insert_list: _executemany("INSERT OR REPLACE INTO scr_perf VALUES (?, ?, ?)", insert_list)
		# insert_list = [('embedwish', 1, 1), ('wishfast', 1, 1), ('ds2play', 1, 1), ('vidoza', 1, 1), ('vidmoly', 1, 1), ('streamvid', 1, 1), ('mdbekjwqa', 1, 1), ('obeywish', 1, 1), ('server4', 1, 1), ('mwish', 1, 1), ('doods', 1, 1), ('2embed', 1, 1), ('vtube', 1, 1), ('youdbox', 1, 1), ('tvpost', 1, 1), ('meomeo', 1, 1), ('upstream', 1, 1), ('bollyfunmaza', 1, 1), ('cdnwish', 1, 1), ('mlions', 1, 1), ('d0000d', 1, 1), ('dood', 1, 1), ('movie', 1, 1), ('tellygossips', 2, 1), ('exandnext', 1, 1), ('vidhidepre', 1, 1), ('filelions', 2, 1), ('insurancehubportal', 1, 1), ('furher', 2, 1), ('youtube', 2, 1), ('eplayvid', 2, 1), ('cdn4', 2, 1), ('doodstream', 2, 1), ('streamtape', 3, 1), ('streamwish', 2, 1), ('vidhidevip', 1, 1), ('filemoon', 4, 1), ('credits', 1, 1), ('tvarticles', 2, 1), ('gdrive', 5, 1), ('trade', 3, 1), ('Folder 2', 2, 1), ('bestarticles', 6, 1)]
		# if insert_list: _executemany("INSERT OR REPLACE INTO prov_perf VALUES (?, ?, ?)", insert_list)
		return True
	except:
		error(f'action_test_func Error: {print_exc()}')
		return False
