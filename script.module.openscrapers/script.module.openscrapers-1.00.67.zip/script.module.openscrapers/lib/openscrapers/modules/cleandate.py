# -*- coding: utf-8 -*-

import time
import datetime
from datetime import datetime, timezone

def utc_to_datetime(date, date_format='%Y-%m-%d %H:%M:%S'):
    return time.strftime(date_format, time.gmtime(date))

def iso_2_utc(iso_ts='2025-01-01T05:53:48.000Z'): # to 1733655228.0
    if not iso_ts or iso_ts is None:
        return 0
    delim = -1
    if not iso_ts.endswith('Z'):
        delim = iso_ts.rfind('+')
        if delim == -1:
            delim = iso_ts.rfind('-')
    if delim > -1:
        ts = iso_ts[:delim]
        sign = iso_ts[delim]
        tz = iso_ts[delim + 1:]
    else:
        ts = iso_ts
        tz = None
    if ts.find('.') > -1:
        ts = ts[:ts.find('.')]
    try:
        d = datetime.datetime.strptime(ts, '%Y-%m-%dT%H:%M:%S')
    except TypeError:
        d = datetime.datetime(*(time.strptime(ts, '%Y-%m-%dT%H:%M:%S')[:6]))
    dif = datetime.timedelta()
    if tz:
        hours, minutes = tz.split(':')
        hours = int(hours)
        minutes = int(minutes)
        if sign == '-':
            hours = -hours
            minutes = -minutes
        dif = datetime.timedelta(minutes=minutes, hours=hours)
    utc_dt = d - dif
    epoch = datetime.datetime.utcfromtimestamp(0)
    delta = utc_dt - epoch
    try:
        seconds = delta.total_seconds()  # works only on 2.7
    except:
        seconds = delta.seconds + delta.days * 24 * 3600  # close enough
    return seconds


def get_datetime(hours=0):
    dt = datetime.datetime.now().replace(microsecond=0).isoformat() + datetime.timedelta(hours)
    d = datetime.datetime(dt.year, 4, 1)
    dston = d - datetime.timedelta(days=d.weekday() + 1)
    d = datetime.datetime(dt.year, 11, 1)
    dstoff = d - datetime.timedelta(days=d.weekday() + 1)
    return dt if dston > dt or dt >= dstoff else dt + datetime.timedelta(hours=1)


def datetime_from_string(string_date, format="%Y-%m-%d", date_only=True): # date or datetime object from string
    if not string_date: return None
    try:
        try:
            if date_only: result = datetime.datetime.strptime(string_date, format).date()
            else: result = datetime.datetime.strptime(string_date, format)
        except:
            if date_only: result = datetime.datetime(*(time.strptime(string_date, format)[0:6])).date()
            else: result = datetime.datetime(*(time.strptime(string_date, format)[0:6]))
        return result
    except:
        from openscrapers.modules.log_utils import error
        error()

def timestamp_from_string(string_date, format="%Y-%m-%d"):
    if not string_date: return None
    try:
        try: element = datetime.datetime.strptime(string_date, format)
        except: element = datetime.datetime(*(time.strptime(string_date, format)[0:6]))
        timestamp = datetime.datetime.timestamp(element)
        return timestamp
    except:
        from openscrapers.modules.log_utils import error
        error()



def local_datetime_to_utc_timestamp(dt_string, fmt='%Y-%m-%d %H:%M:%S'):
    local_tz = datetime.now().astimezone().tzinfo
    dt_local = datetime.strptime(dt_string, fmt)
    dt_local = dt_local.replace(tzinfo=local_tz)
    dt_utc = dt_local.astimezone(timezone.utc)
    return dt_utc.timestamp()

def utc_timestamp_to_local_string(ts, fmt='%Y-%m-%d %H:%M:%S'):
    local_tz = datetime.now().astimezone().tzinfo
    dt_local = datetime.fromtimestamp(float(ts), tz=local_tz)
    return dt_local.strftime(fmt)


def datetime_to_utc(string_date: str, date_format: str = '%Y-%m-%d %H:%M:%S'):
    """
    Convert a formatted datetime string or numeric timestamp string to a UTC timestamp (float).
    """
    if not string_date:
        return None

    try:
        # Case 1: numeric timestamp (e.g., "1771837100")
        if isinstance(string_date, (int, float)) or (isinstance(string_date, str) and string_date.isdigit()):
            return float(string_date)

        # Case 2: formatted datetime string
        try:
            element = datetime.strptime(string_date, date_format)
        except ValueError:
            # Fallback for looser parsing
            element = datetime(*time.strptime(string_date, date_format)[0:6])

        # Assume naive datetime is UTC
        # element = element.replace(tzinfo=timezone.utc)
        local_tz = datetime.now().astimezone().tzinfo
        element = element.replace(tzinfo=local_tz)
        return element.timestamp()

    except Exception as err:
        log(f'Error to revesr: {err}')
        return None


def utc_to_datetime_string(value, date_format: str = '%Y-%m-%d %H:%M:%S'):
    """
    Convert a UNIX timestamp (int/float/string) to a formatted UTC datetime string.
    """
    if value is None:
        return None

    try:
        # Normalize input
        if isinstance(value, str):
            if not value.replace('.', '', 1).isdigit():
                raise ValueError(f"Not a numeric timestamp: {value}")
            value = float(value)

        # Convert timestamp → datetime
        local_tz = datetime.now().astimezone().tzinfo
        dt = datetime.fromtimestamp(float(value), tz=local_tz)

        # Format output
        return dt.strftime(date_format)

    except Exception as err:
        log(f'Error to revesr: {err}')
        return None


