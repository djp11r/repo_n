# -*- coding: utf-8 -*-
"""
	OpenScrapers Module
"""

import threading
from concurrent.futures import ThreadPoolExecutor, wait
from typing import Callable, Iterable, Any, Tuple, Optional

class Thread(threading.Thread):
    def __init__(
        self,
        target: Callable[..., Any],
        *args: Any,
        name: str | None = None
    ) -> None:
        super().__init__(target=target, args=args, name=name)
        self._target = target
        self._args = args



class ExecutorWrapper:
    def __init__(self, max_workers: int = 10) -> None:
        self._max_workers = max_workers
        self._executor: ThreadPoolExecutor | None = None

    def __enter__(self) -> ThreadPoolExecutor:
        self._executor = ThreadPoolExecutor(max_workers=self._max_workers)
        return self._executor

    def __exit__(self, exc_type, exc, tb) -> None:
        if self._executor:
            self._executor.shutdown(wait=True)


# Global wrapper
tp_wrapper = ExecutorWrapper(max_workers=10)

#Init global thread pool
# tp = ThreadPoolExecutor(max_workers=10)



def run_and_wait(func: Callable[[Any], Any], iterable: Iterable[Any]) -> None:
    with tp_wrapper as tp:
        futures: list[Future] = [tp.submit(func, item) for item in iterable]
        wait(futures)


def run_and_wait_multi(
    func: Callable[..., Any],
    iterable: Iterable[Tuple[Any, ...]]
) -> Iterable[Any]:
    with tp_wrapper as tp:
        return tp.map(lambda args: func(*args), iterable)


def shutdown_executor():
    tp_wrapper.shutdown(wait=True)