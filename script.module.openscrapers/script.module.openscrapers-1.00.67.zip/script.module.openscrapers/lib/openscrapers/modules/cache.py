# -*- coding: utf-8 -*-
"""
	OpenScrapers Module
"""

from ast import literal_eval
from hashlib import md5
from json import dumps
from re import sub as re_sub
from sqlite3 import dbapi2 as db
from time import time
from traceback import print_exc, print_stack
from openscrapers.modules.control import homeWindow, existsPath, dataPath, makeFile, cacheFile, undesirablescacheFile, setting
from openscrapers.modules.log_utils import log, error
cachetime = int(setting('cacheduration')) or 10
cache_file = cacheFile if cacheFile else 'cache.db'

# log(f'>>>>>>>>>>> cache_file: {repr(cache_file)} cachetime: {repr(cachetime)}')
database_timeout = 20
table_creators = {
'external_db': (
'CREATE TABLE IF NOT EXISTS cache (key text, value text, date integer, unique(key));',
'CREATE TABLE IF NOT EXISTS scr_perf (source text not null, success integer, failure integer, unique(source))',
'CREATE TABLE IF NOT EXISTS prov_perf (source text not null, success integer, provider text, unique(source))',),
}



def get(function, duration=cachetime, *args, **kwargs):
	"""
	:param function: Function to be executed
	:param duration: Duration of validity of cache in hours
	:param args: Optional arguments for the provided function
	"""
	try:
		key = _hash_function(function, *args, **kwargs)
		cache_result = cache_get(key, duration)
		if cache_result: return cache_result

		fresh_result = repr(function(*args)) # may need a try-except block for server timeouts

		if cache_result and len(cache_result) == 1 and fresh_result == '[]': # fix for syncSeason mark unwatched season when it's the last item remaining
			if cache_result[0].isdigit():
				remove(function, *args)
				return []

		invalid = False
		try: # Sometimes None is returned as a string instead of None type for "fresh_result"
			if not fresh_result or fresh_result in {'None', '', '[]', '{}'}: invalid = True
		except: pass

		if invalid: # If the cache is old, but we didn't get "fresh_result", return the old cache # do not cache_insert() None type, sometimes servers just down momentarily
			return cache_result if cache_result else None
		cache_insert(key, fresh_result, duration)
		return literal_eval(fresh_result)
	except:
		error(f'cache.get: {print_exc()}')
		return None

def _is_cache_valid(cached_time, cache_timeout):
	now = int(time())
	diff = now - cached_time
	# log(f'diff: {diff}  return {int(cache_timeout * 3600) > diff} now: {now} cached_time: {repr(cached_time)} cache_timeout: {repr(cache_timeout)}')
	return (cache_timeout * 3600) > diff


def timeout(function, *args):
	try:
		key = _hash_function(function, args)
		result = cache_get(key)
		return int(result['date']) if result else 0
	except:
		error()
		return 0


def cache_existing(function, *args):
	try:
		if cache_result := cache_get(_hash_function(function, args)):
			return cache_result
	except:
		error()
	return None


def cache_get(key, duration=cachetime, table='cache'):
	dbcur = connect_db_file()
	results = dbcur.execute(f'''SELECT * FROM {table} WHERE key=?''', (key,)).fetchone()
	try: dbcur.close()
	except: pass
	# log(f'results: {results}')
	if not results: return
	if _is_cache_valid(results['date'], duration):
		try: return literal_eval(results['value'])
		except: return eval(results['value'])
	else: return

def get_timestamp(offset=None):
	if offset is None: offset = int(time()) + cachetime*3600 # HOURS multiply by 3600 to get seconds
	else: offset = offset*3600 + int(time())
	# Offset is in HOURS multiply by 3600 to get seconds
	return offset


def cache_insert(key, value, expires=6, table='cache'):
	try:
		_timestamp = get_timestamp(expires)
		dbcur = connect_db_file()
		# dbcur = get_connection_cursor(dbcon)
		dbcur.execute(f'''CREATE TABLE IF NOT EXISTS {table} (key TEXT, value TEXT, date INTEGER, UNIQUE(key));''')
		dbcur.execute(f'''INSERT OR REPLACE INTO {table} Values (?, ?, ?)''', (key, repr(value), _timestamp))
		dbcur.commit()
	except:
		error()
	finally:
		try: dbcur.close()# ; dbcon.close()
		except: pass
	return

def remove(function, *args):
	try:
		key = _hash_function(function, args)
		if key_exists := cache_get(key):
			dbcur = connect_db_file()
			# dbcur = get_connection_cursor(dbcon)
			dbcur.execute('''DELETE FROM cache WHERE key=?''', (key,))
			dbcur.commit()
	except:
		error()
	try: dbcur.close()# ; dbcon.close()
	except: pass
	return

def _hash_function(function_instance, *args, **kwargs):
	return _get_function_name(function_instance) + _generate_md5(*args, **kwargs)

def _get_function_name(function_instance):
	return re_sub(r'.+\smethod\s|.+function\s|\sat\s.+|\sof\s.+', '', repr(function_instance))

def _generate_md5(*args, **kwargs):
	md5_hash = md5()
	[md5_hash.update(str(arg).encode()) for arg in args]
	md5_hash.update(dumps(kwargs).encode())
	return md5_hash.hexdigest()

def cache_clear(flush_only=True):
	try:
		dbcur = connect_db_file()
		# dbcur = get_connection_cursor(dbcon)
		for table in ['cache']:#, 'scr_perf', 'prov_perf']:
			try:
				if flush_only:
					dbcur.execute(f'DELETE from {table} WHERE CAST(date AS INT) <= ?', (get_timestamp(),))
					#dbcur.execute(f'''DELETE FROM {table}''')
				else: dbcur.execute(f'DROP TABLE IF EXISTS {table}')
			except: error()
		dbcur.commit()
		dbcur.execute("VACUUM")
	except:
		error()
	finally:
		try: dbcur.close()# ; dbcon.close()
		except: pass
	return


def connect_db_file(db_file=cache_file, dict_=True):
	dbcon = db.connect(db_file, timeout=database_timeout, isolation_level=None, check_same_thread=False)
	#dbcon.execute('''CREATE TABLE IF NOT EXISTS cache (key TEXT, value TEXT, date INTEGER, UNIQUE(key));''')
	# dbcon.execute('''PRAGMA page_size = 32768''')
	dbcon.execute('''PRAGMA journal_mode = OFF''')
	dbcon.execute('''PRAGMA synchronous = OFF''')
	# dbcon.execute('''PRAGMA temp_store = memory''')
	# dbcon.execute('''PRAGMA mmap_size = 30000000000''')
	if dict_: dbcon.row_factory = _dict_factory
	return dbcon


# def get_connection_cursor(dbcon):
# 	dbcur = dbcon.cursor()
# 	dbcur.execute('''PRAGMA synchronous = OFF''')
# 	dbcur.execute('''PRAGMA journal_mode = OFF''')
# 	return dbcur


def _dict_factory(cursor, row):
	return {col[0]: row[idx] for idx, col in enumerate(cursor.description)}


def make_database(database_name='external_db'):
	if existsPath(cache_file): return
	if not existsPath(dataPath): makeFile(dataPath)
	dbcon = connect_db_file()
	for command in table_creators[database_name]: dbcon.execute(command)
	# dbcon.commit()
	dbcon.execute('VACUUM')
	dbcon.close()
	return

def get_all_data(table='scr_perf'):
	try:
		dbcon = connect_db_file(dict_=False)
		if cache_data := dbcon.execute(f'SELECT * FROM {table}').fetchall():
			# log(f'ExternalCache get_all_data cache_data: {cache_data}')
			return cache_data
	except Exception as e:
		error(f'ExternalCache get_all_data Error: {print_exc()} e: {e}')
	finally:
		dbcon.close()
	return []

def _execute(command, params):
	dbcon = connect_db_file(dict_=False)
	return dbcon.execute(command, params)

def _executemany(command, insert_list):
	dbcon = connect_db_file(dict_=False)
	return dbcon.executemany(command, insert_list)

class Undesirables():
	def __init__(self):
		self.make_database_objects()

	def get_enabled(self):
		results = self.dbcur.execute('SELECT keyword FROM undesirables WHERE enabled = ?', (True,))
		return self.process_keywords(results)

	def get_default(self):
		results = self.dbcur.execute('SELECT keyword FROM undesirables WHERE user_defined = ?', (False,))
		return self.process_keywords(results)

	def get_user_defined(self):
		results = self.dbcur.execute('SELECT keyword FROM undesirables WHERE user_defined = ?', (True,))
		return self.process_keywords(results)

	def get_all(self):
		results = self.dbcur.execute('SELECT keyword FROM undesirables')
		return self.process_keywords(results)

	def set_many(self, undesirables):
		self.dbcur.executemany('INSERT OR REPLACE INTO undesirables VALUES (?, ?, ?)', undesirables)
		self.dbcon.commit()

	def make_connection(self):
		self.dbcon = db.connect(undesirablescacheFile, timeout=60)

	def make_cursor(self):
		self.dbcur = self.dbcon.cursor()
		self.dbcur.execute('''PRAGMA synchronous = OFF''')
		self.dbcur.execute('''PRAGMA journal_mode = OFF''')

	def make_database_objects(self):
		if not existsPath(dataPath): makeFile(dataPath)
		self.make_connection()
		self.make_cursor()
		self.dbcur.execute('CREATE TABLE IF NOT EXISTS undesirables (keyword TEXT NOT NULL, user_defined BOOL NOT NULL, enabled BOOL NOT NULL, UNIQUE(keyword))')

	def set_defaults(self, keywords):
		self.set_many([(i, False, True) for i in keywords])

	def process_keywords(self, results):
		keywords = [i[0] for i in results.fetchall()]
		if not keywords:
			from openscrapers.modules.source_utils import UNDESIRABLES
			keywords = UNDESIRABLES
			self.set_defaults(keywords)
		return keywords


try: undesirables_cache = [] #Undesirables()
except: undesirables_cache = []


class BaseCache(object):
	def __init__(self, dbfile, table):
		self.media_prop = 'open_scrap.%s'
		self.table = table
		self.dbfile = dbfile

	def get(self, string):
		result = None
		try:
			current_time = get_timestamp()
			result = self.get_memory_cache(string, current_time)
			if result is None:
				dbcon = connect_db_file(self.dbfile)
				if cache_data := dbcon.execute('SELECT expires, data FROM %s WHERE id = ?' % self.table, (string,)).fetchone():
					if cache_data[0] > current_time:
						result = eval(cache_data[1])
						self.set_memory_cache(result, string, cache_data[0])
					else: self.delete(string)
		except: pass
		return result

	def set(self, string, data, expiration=720):
		try:
			dbcon = connect_db_file(self.dbfile)
			expires = get_timestamp(expiration)
			dbcon.execute('INSERT OR REPLACE INTO %s(id, data, expires) VALUES (?, ?, ?)' % self.table, (string, repr(data), int(expires)))
			self.set_memory_cache(data, string, int(expires))
		except: return None

	def get_memory_cache(self, string, current_time):
		result = None
		try:
			if cachedata := homeWindow.get_property(self.media_prop % string):
				cachedata = eval(cachedata)
				if cachedata[0] > current_time: result = cachedata[1]
		except: pass
		return result

	def set_memory_cache(self, data, string, expires):
		try:
			cachedata = (expires, data)
			cachedata_repr = repr(cachedata)
			homeWindow.set_property(self.media_prop % string, cachedata_repr)
		except: pass

	def delete(self, string):
		try:
			dbcon = connect_db_file(self.dbfile)
			dbcon.execute('DELETE FROM %s WHERE id = ?' % self.table, (string,))
			self.delete_memory_cache(string)
		except: pass

	def delete_memory_cache(self, string):
		homeWindow.clear_property(self.media_prop % string)

	def manual_connect(self, dbfile):
		return connect_db_file(dbfile)

	def _execute(self, command, params):
		dbcon = connect_db_file(dict_=False)
		return dbcon.execute(command, params)

	def _executemany(self, command, insert_list):
		dbcon = connect_db_file(dict_=False)
		return dbcon.executemany(command, insert_list)

	def delete_all_lists(self, dbfile, table):
		try:
			dbcon = self.manual_connect(dbfile)
			dbcon.execute(f'DELETE FROM {table}')
			dbcon.execute('VACUUM')
			return True
		except: return False

	def clean_database(self, dbfile, table):
		try:
			dbcon = self.manual_connect(dbfile)
			dbcon.execute(f'DELETE from {table} WHERE CAST(expires AS INT) <= ?', (get_timestamp(),))
			dbcon.execute('VACUUM')
			return True
		except: return False
