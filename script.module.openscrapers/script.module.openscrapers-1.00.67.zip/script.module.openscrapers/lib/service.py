# -*- coding: utf-8 -*-
"""
	OpenScrapers Module
"""

from traceback import print_exc
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.control import monitor, isVersionUpdate, clean_settings, addonVersion, condVisibility, notification, sleep, make_settings_dict, refresh_debugReversed, monitor_class, setting, setSetting, joinPath, makeDirs, homeWindow, dataPath, existsPath
from openscrapers.modules.workers import shutdown_executor
window = homeWindow


class CheckSettingsFile:
	def run(self):
		try:
			# log('[script.module.openscrapers]  CheckSettingsFile Service Starting...', 1)
			window.clearProperty('openscrapers_settings')
			from openscrapers.modules.cache import cache_clear
			cache_clear()
			if not existsPath(dataPath):
				success = makeDirs(dataPath)
			settings_xml = joinPath(dataPath, 'settings.xml')
			if not existsPath(settings_xml):
				setSetting('module.provider', 'openscrapers')
			return
		except: error(f'Error: {print_exc()}', __name__)


class SettingsMonitor(monitor_class):
	def __init__ (self):
		monitor_class.__init__(self)
		window.setProperty('openscrapers.debug.reversed', setting('debug.reversed'))
		# log('Settings Monitor Service Starting...')

	def onSettingsChanged(self): # Kodi callback when the addon settings are changed
		window.clearProperty('openscrapers_settings')
		sleep(50)
		refreshed = make_settings_dict()
		refresh_debugReversed()

class AddonCheckUpdate:
	def run(self):
		# log('Addon checking available updates')
		try:
			import re
			import requests
			repo_xml = requests.get('https://raw.githubusercontent.com/djp11r/repo_n/mayb/script.module.openscrapers/addon.xml')
			if repo_xml.status_code != 200:
				return log(f'Could not connect to remote repo XML: status code = {repo_xml.status_code}')
			repo_version = re.search(r'<addon id=\"script.module.openscrapers\".*version=\"(\d*.\d*.\d*)\"', repo_xml.text, re.I).group(1)
			local_version = addonVersion()[:7] # 5 char max so pre-releases do try to compare more chars than github version
			def check_version_numbers(current, new): # Compares version numbers and return True if github version is newer
				current = current.split('.')
				new = new.split('.')
				step = 0
				for i in current:
					if int(new[step]) > int(i): return True
					if int(i) > int(new[step]): return False
					if int(i) == int(new[step]):
						step += 1
						continue
				return False
			if check_version_numbers(local_version, repo_version):
				while condVisibility('Library.IsScanningVideo'):
					sleep(10000)
				msg = f'[script.module.openscrapers] A newer version is available. Installed Version: v{local_version}, Repo Version: v{repo_version}'
				log(msg)
				notification(message=msg, time=5000)
			return # log('Addon update check complete')
		except: error(f'Error: {print_exc()}', __name__)


class CheckUndesirablesDatabase:
	def run(self):
		log('"CheckUndesirablesDatabase" Service Starting...')
		from openscrapers.modules import undesirables
		try:
			if old_database := undesirables.Undesirables().check_database():
				undesirables.add_new_default_keywords()
		except: error(f'Error: {print_exc()}', __name__)
		return log('Finished "CheckUndesirablesDatabase" Service')


def main():
	while not monitor.abortRequested():
		log('[script.module.openscrapers] Main Monitor Service Started')
		CheckSettingsFile().run()
		# CheckUndesirablesDatabase().run()
		if setting('checkAddonUpdates') == 'true':
			# from openscrapers.modules.service_functions import AddonCheckUpdate
			AddonCheckUpdate().run()
			# log('[script.module.opencrapers] Addon update check complete')
		if isVersionUpdate():
			clean_settings()
			log('[script.module.openscrapers] Settings file cleaned complete')
		break
	SettingsMonitor().waitForAbort()
	# shutdown_executor()
	log('[script.module.openscrapers] Main Monitor Service Finished')

main()
