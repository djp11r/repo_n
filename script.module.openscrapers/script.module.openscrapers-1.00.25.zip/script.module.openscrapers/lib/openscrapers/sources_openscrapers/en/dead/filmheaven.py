# -*- coding: utf-8 -*-
"""
    **Created by Tempest**
    **If you see this in a addon other than Tempest and says it was
    created by someone other than Tempest they stole it from me**
"""

import re
import requests
import traceback
from openscrapers import urlencode, parse_qs, quote_plus, urljoin
from openscrapers.modules import log_utils
from openscrapers.modules import client
from openscrapers.modules import source_utils


class source:
    def __init__(self):
        self.priority = 40
        self.language = ['en']
        self.domains = ['filmheaven.com']
        self.base_link = 'https://filmheaven.com'
        self.search_link = '/?s=%s'
        self.headers={'User-Agent': client.agent(), 'Referer': self.base_link}

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            items = []

            if url is None:
                return sources

            hostDict = hostprDict + hostDict

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            hdlr = '%s (%s)' % (data['title'], int(data['year']))
            query = '%s+%s' % (data['title'], int(data['year']))

            url = self.search_link % quote_plus(query)
            url = urljoin(self.base_link, url)
            try:
                posts = requests.get(url, headers=self.headers).text
                r = [i for i in re.findall(r'<a href="(.+?)">(.+?)</a>', posts) if hdlr in i[1]]
                items += r
            except:
                pass

            for item in items:
                r = requests.get(item[0], headers=self.headers).text
                url = re.findall(r'src=\'(.+?)\'', r)
                for url in url:
                    if url.endswith('.xyz'): continue
                    if 'url=' in url:
                        url = url.split('url=')[1]
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    if valid:
                        sources.append(
                            {'source': host, 'quality': '720p', 'language': 'en', 'info': '', 'url': url,
                             'direct': False, 'debridonly': False})

            return sources
        except Exception:
            log_utils.error(f'{__name__}_ sources: ')
            return []

    def resolve(self, url):
        return url
