# -*- coding: utf-8 -*-

"""
    OpenScrapers Project
"""

import re

try: from urlparse import urljoin
except ImportError: from urllib.parse import urljoin
try: from urllib import quote_plus
except ImportError: from urllib.parse import quote_plus

from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import directstream
from openscrapers.modules import dom_parser
from openscrapers.modules import source_utils
from openscrapers.modules import cfscrape


class source:
    def __init__(self):
        self.priority = 31
        self.language = ['en']
        self.domains = ['watchseries.movie', 'watchseries.fm']
        self.base_link = 'https://www10.watchseries.movie'
        self.search_link = '/search.html?keyword=%s'
        self.headers = {'User-Agent': client.agent()}
        self.scraper = cfscrape.create_scraper()

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = urljoin(self.base_link, self.search_link % quote_plus(cleantitle.query(tvshowtitle)))
            url = url + '$$$' + tvshowtitle
            return url
        except:
            source_utils.scraper_error('WATCHSERIES')
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url == None:
                return
            tvshowtitle = url.split('$$$')[1]
            url = url.split('$$$')[0]
            result = self.scraper.get(url, headers=self.headers).content
            express = r'''<a\s*href="([^"]+)"\s*class="videoHname\s*title"\s*title="%s - Season %s''' % (tvshowtitle, season)
            get_season = re.findall(express, result, flags=re.I)[0]
            url = urljoin(self.base_link, get_season + '/season')
            result = self.scraper.get(url, headers=self.headers).content
            express = '''<div class="vid_info"><span><a href="([^"]+)" title="([^"]+)" class="videoHname">'''
            get_ep = re.findall(express, result, flags=re.I)
            epi = [i[0] for i in get_ep if title.lower() in i[1].lower()]
            get_ep = urljoin(self.base_link, epi[0])
            url = get_ep.encode('utf-8')
            return url
        except:
            source_utils.scraper_error('WATCHSERIES')
            return


    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if not url: return sources

            hostDict += ['akamaized.net', 'google.com', 'picasa.com', 'blogspot.com']
            result = client.request(url, headers=self.headers, timeout=10)
            dom = dom_parser.parse_dom(result, 'a', req='data-video')
            urls = [i.attrs['data-video'] if i.attrs['data-video'].startswith('http') else 'https:' + i.attrs['data-video'] for i in dom]

            for url in urls:
                dom = []
                if 'ocloud.stream' in url:
                    result = client.request(url, headers=self.headers, timeout=10)
                    base = re.findall('<base href="([^"]+)">', result)[0]
                    hostDict += [base]
                    dom = dom_parser.parse_dom(result, 'a', req=['href', 'id'])
                    dom = [(i.attrs['href'].replace('./embed', base + 'embed'), i.attrs['id']) for i in dom if i]
                    dom = [(re.findall(r"var\s*ifleID\s*=\s*'([^']+)", client.request(i[0]))[0], i[1]) for i in dom if i]
                if dom:
                    try:
                        for r in dom:
                            valid, hoster = source_utils.is_host_valid(r[0], hostDict)
                            if not valid:
                                continue
                            quality = source_utils.label_to_quality(r[1])
                            urls, host, direct = source_utils.check_directstreams(r[0], hoster)
                            for x in urls:
                                if direct:
                                    size = source_utils.get_size(x['url'])
                                if size:
                                    sources.append(
                                        {'source': host, 'quality': quality, 'language': 'en', 'url': x['url'],
                                         'direct': direct, 'debridonly': False, 'info': size})
                                else:
                                    sources.append(
                                        {'source': host, 'quality': quality, 'language': 'en', 'url': x['url'],
                                         'direct': direct, 'debridonly': False})
                    except:
                        pass
                else:
                    if 'load.php' not in url:
                        valid, hoster = source_utils.is_host_valid(url, hostDict)
                        if valid:
                            try:
                                url.decode('utf-8')
                                if 'vidnode.net' in url:
                                    url = url.replace('vidnode.net', 'vidcloud9.com')
                                    hoster = 'vidcloud9'
                                sources.append(
                                    {'source': hoster, 'quality': 'SD', 'language': 'en', 'url': url, 'direct': False,
                                     'debridonly': False})
                            except:
                                pass
            return sources
        except:
            source_utils.scraper_error('WATCHSERIES')
            return sources


    def resolve(self, url):
        if "google" in url:
            return directstream.googlepass(url)
        else:
            return url
