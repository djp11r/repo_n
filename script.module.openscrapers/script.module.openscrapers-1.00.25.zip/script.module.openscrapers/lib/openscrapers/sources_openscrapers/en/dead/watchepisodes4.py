# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 04-14-2020 by Tempest.

import re
import traceback

from openscrapers.modules import client
from openscrapers.modules import log_utils
from openscrapers.modules import cleantitle
from openscrapers.modules import scrape_source
from openscrapers.modules import source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['watchepisodes4.com']
        self.base_link = 'https://www.watchepisodes4.com/'
        self.headers = {'User-Agent': client.agent()}

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            clean_title = cleantitle.geturl(tvshowtitle)
            url = self.base_link + clean_title
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return
            response = client.request(url)
            r = re.compile('<a title=".+? Season %s Episode %s .+?" href="(.+?)">' % (season, episode)).findall(response)
            for url in r:
                return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if not url: return sources
            # hostDict += hostprDict
            r = client.request(url)
            r = re.compile('class="watch-button" data-actuallink="(.+?)"').findall(r)
            for url in r:
                if url in str(sources):
                    continue
                valid, host = source_utils.is_host_valid(url, hostDict)
                if valid:
                    sources.append({'source': host, 'quality': 'SD', 'language': 'en', 'info': '', 'url': url, 'direct': False, 'debridonly': False})
            return sources
        except Exception:
            log_utils.log('---WATCHEPSODES4 Testing - Exception: \n' + str(traceback.format_exc()))
            return []

    def resolve(self, url):
        return url
