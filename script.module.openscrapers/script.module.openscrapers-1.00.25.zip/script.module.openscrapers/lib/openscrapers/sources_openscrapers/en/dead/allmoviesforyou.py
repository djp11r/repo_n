# -*- coding: utf-8 -*-
# Add tvshows later(only a few on site)
"""
    **Created by Tempest**
    **If you see this in a addon other than Tempest and says it was
    created by someone other than Tempest they stole it from me**
"""

import re
from openscrapers import parse_qs, urljoin, urlencode
from openscrapers.modules import log_utils
from openscrapers.modules import client
from openscrapers.modules import source_utils


class source:
    def __init__(self):
        self.priority = 40
        self.language = ['en']
        self.domains = ['allmoviesforyou.net']
        self.base_link = 'https://allmoviesforyou.net'
        self.search_link = '/?s=%s'
        self.search_link2 = '/embed/tmdb/tv?id=%s&s=%s&e=%s'
        self.headers = {'User-Agent': client.agent(), 'Referer': self.base_link}

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        items = []
        if url is None: return sources
        try:
            hostDict += hostprDict
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            if 'tvshowtitle' in data:
                query = '/episode/%s-%sx%s/' % (data['tvshowtitle'], int(data['season']), int(data['episode']))
            else:
                query = '/movies/%s/' % data['title']
            query = query.replace(' ', '-')
            url = urljoin(self.base_link, query).lower()
            try:
                # log_utils.log(f'url: {url}')
                r = client.request(url, headers=self.headers)
                # r = client.parseDOM(r, 'article', attrs={'class': 'TPost B'})
                # r = [re.findall(
                #     r'<a href="(.+?)">.+?<span class="Qlty">(.+?)</span>.+?<span class="Qlty Yr">(.+?)</span>.+?<h2 class="Title">(.+?)</h2>',
                #     i, re.DOTALL)[0] for i in r]
                # items += r
                url = re.findall('<iframe src="(.+?)"', str(r))[0]
                url = url.replace('#038;', '')
                url = client.request(url, headers={'User-Agent': client.agent(), 'Referer': url})
                url = re.findall('src="(.+?)"', str(url))

                for url in url:
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    sources.append({'source': host, 'quality': 'SD', 'language': 'en', 'info': '', 'url': url, 'direct': False, 'debridonly': False})
            except:
                log_utils.error(f'{__name__}_ sources: ')
                return

            # for item in items:
            #     try:
            #         if data['title'] in item[3] and data['year'] in item[2]:
            #             print(f'url: {item[0]}')
            #             url = client.request(item[0], headers=self.headers)
            #             url = re.findall('<iframe src="(.+?)"', url)[0]
            #             url = url.replace('#038;', '')
            #             url = client.request(url, headers={'User-Agent': client.agent(), 'Referer': url})
            #             url = re.findall('src="(.+?)"', url)
            #
            #             for url in url:
            #                 valid, host = source_utils.is_host_valid(url, hostDict)
            #                 sources.append(
            #                     {'source': host, 'quality': 'SD', 'language': 'en', 'info': '', 'url': url,
            #                      'direct': False, 'debridonly': False})
            #     except:
            #         pass

            return sources
        except Exception:
            log_utils.error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        return url
