# -*- coding: utf-8 -*-

"""

"""

import base64
import re

from openscrapers import urlparse, parse_qs, urljoin, urlencode, quote_plus

from openscrapers.modules import client
from openscrapers.modules import cleantitle
from openscrapers import cfScraper
from openscrapers.modules import source_utils
from openscrapers.modules import py_tools
from openscrapers.modules import log_utils

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['kat.mn', 'www2.putlockers.gs', 'putlockerfree.net', 'www8.putlockers.fm', 'putlocker.unblckd.pw']
        self.base_link = 'https://kat.mn/'
        self.search_link = 'search-movies/%s.html'
        # self.s = cfscrape.create_scraper()


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year, 'aliases': aliases}
            url = urlencode(url)
            return url
        except:
            log_utils.error(f'{__name__}_ movie: ')
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            log_utils.error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            log_utils.error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if not url: return sources
            hostDict += hostprDict
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            # title = cleantitle.get_query(title)
            hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']
            query = '%s season %d' % (title, int(data['season'])) if 'tvshowtitle' in data else title
            query = query.replace(' ', '%20').replace('.', '').replace(':', '').replace('\'', '').lower() # re.sub(r'(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)
            query = quote_plus(query)
            url = urljoin(self.base_link, self.search_link % query)
            self.ua = {'User-Agent': client.agent()}
            r = cfScraper.get(url, headers=self.ua).text
            # _posts = client.parseDOM(r, 'div', attrs={'class': 'item'})
            _posts = client.parseDOM(r, 'li', attrs={'class': 'item'})
            posts = []
            # print('_posts: %s' % _posts)
            for p in _posts:
                try:
                    post = (client.parseDOM(p, 'a', ret='href')[1],
                        re.findall(r'<b>(.+?)</b>', p, re.I|re.S)[0], # client.parseDOM(p, 'a')[1], # for putlockers.gs-like domains
                        re.findall(r'year">\s*?(\d{4})</', p, re.I|re.S)[0] # re.findall(r'Release:\s*?(\d{4})</', p, re.I|re.S)[1] # for putlockers.gs-like domains
                    )
                    posts.append(post)
                except:
                    pass
            if not posts: return
            # print('posts: %s' % posts)
            posts = [(i[0], i[1], i[2]) for i in posts if i]
            if 'tvshowtitle' in data:
                sep = 'season %d' % int(data['season'])
                sepi = 'season-%1d/episode-%1d.html' % (int(data['season']), int(data['episode']))
                post = [i[0] for i in posts if sep in i[1].lower()][0]
                data = cfScraper.get(post, headers=self.ua).text
                link = client.parseDOM(data, 'a', ret='href')
                link = [i for i in link if sepi in i][0]
            else:
                link = [i[0] for i in posts if cleantitle.get_simple(title) in cleantitle.get_simple(i[1]) and hdlr == i[2]][0]
            self.ua = {'Referer': link}
            r = cfScraper.get(link, headers=self.ua).text
            try:
                v = re.findall(r'document.write\(Base64.decode\("(.+?)"\)', r)[0]
                #v = v.encode('utf-8')
                b64 = base64.b64decode(v)
                b64 = py_tools.ensure_text(b64, errors='ignore')
                url = client.parseDOM(b64, 'iframe', ret='src')[0]
                try:
                    host = re.findall(r'([\w]+[.][\w]+)$', urlparse(url.strip().lower()).netloc)[0]
                    host = client.replaceHTMLCodes(host)
                    host = py_tools.ensure_str(host)
                    valid, hoster = source_utils.is_host_valid(host, hostDict)
                    if valid:
                        sources.append({
                            'source': hoster,
                            'quality': 'SD',
                            'language': 'en',
                            'info': '',
                            'url': url.replace(r'\/', '/'),
                            'direct': False,
                            'debridonly': False
                        })
                except:
                    log_utils.error(f'{__name__}_ sources: ')
                    pass
            except:
                log_utils.error(f'{__name__}_ sources: ')
                pass
            r = client.parseDOM(r, 'div', {'class': 'server_line'})
            r = [(client.parseDOM(i, 'a', ret='href')[0],
                  client.parseDOM(i, 'p', attrs={'class': 'server_servername'})[0]) for i in r]
            if r:
                for i in r:
                    try:
                        host = re.sub(r'Server|Link\s*\d+', '', i[1]).lower()
                        url = i[0].replace(r'\/', '/')
                        host = client.replaceHTMLCodes(host)
                        host = py_tools.ensure_str(host)
                        if 'other' in host: continue
                        valid, hoster = source_utils.is_host_valid(host, hostDict)
                        if valid:
                            sources.append({
                                'source': hoster,
                                'quality': 'SD',
                                'language': 'en',
                                'info': '',
                                'url': url,
                                'direct': False,
                                'debridonly': False})
                    except:
                        log_utils.error(f'{__name__}_ sources: ')
            return sources
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        if any(x in url for x in self.domains):
            try:
                r = cfScraper.get(url).text
                try:
                    v = re.findall(r'document.write\(Base64.decode\("(.+?)"\)', r)[0]
                    #v = v.encode('utf-8')
                    b64 = base64.b64decode(v)
                    b64 = py_tools.ensure_text(b64, errors='ignore')
                    try:
                        url = client.parseDOM(b64, 'iframe', ret='src')[0]
                    except:
                        url = client.parseDOM(b64, 'a', ret='href')[0]
                except:
                    # u = client.parseDOM(r, 'div', attrs={'class': 'player'})
                    # url = client.parseDOM(u, 'a', ret='href')[0]
                    pass
                url = url.replace('///', '//')
            except:
                log_utils.error(f'{__name__}_ resolve: ')
            return url
        else:
            return url
