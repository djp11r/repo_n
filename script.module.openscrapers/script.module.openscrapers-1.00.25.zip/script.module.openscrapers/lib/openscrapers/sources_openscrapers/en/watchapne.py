# -*- coding: UTF-8 -*-

import re
from openscrapers import urlencode

import requests
from openscrapers.modules import client, log_utils
from openscrapers.modules.hindi_sources import get_source_dict, link_extractor, host, append_headers, get_headersfrom_url
# from openscrapers.modules.hindi_sources import read_write_file


class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "watchapne"
        self.domains = ['watchapne.co']
        self.base_link = 'https://watchapne.co'
        self.referer = self.base_link
        self.headers = {'User-Agent': client.agent(),}
        self.apneembed = ['newstalks.co', 'newstrendz.co', 'newscurrent.co', 'newsdeskroom.co',
                     'newsapne.co', 'newshook.co', 'newsbaba.co', 'articlesnewz.com',
                     'articlesnew.com', 'webnewsarticles.com']
    
    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            query = title.replace(' ', '-').replace(':', '')
            start_url = f"https://watchapne.co/movie/{query}"
            # log_utils.log(f'movie url: {start_url}')
            return start_url
        except:
            log_utils.error(f'{__name__}_ movie: ')
            return
    
    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log_utils.log(f"From: {self.name} \nimdb {imdb} \ntvdb {tvdb}\n tvshowtitle {tvshowtitle}, localtvshowtitle {localtvshowtitle}, aliases {aliases}, year {year} ")
        try:
            query = tvshowtitle.replace(' ', '-')
            url = query
            # log_utils.log(f'>>> #### 0AAAA - watchapne EP url : {url}')
            return url
        except:
            log_utils.error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log_utils.log(f"From: {self.name} url {url} ... \nimdb {imdb} .. tvdb {tvdb}\n title {title}, premiered {premiered}, season {season}, episode {episode} ")
        try:
            if type(tvdb) == int: return
            if '|' in tvdb:
                # log_utils.log(f"type watchapne tvdb: {tvdb} Type {type(tvdb)}")
                # query = '{}/{}'.format(url, title).replace(' ', '-')
                query = '{}'.format(url).replace(' ', '-')
                # title = '{}'.format(title).replace(' ', '-')
                # log_utils.log(f"query {query} title: {title} ")
                if 'episode' in title.lower():
                    url = f'https://watchapne.co/web-series/{query}'
                    # self.referer = 'https://watchapne.co/web-series/'
                    release_title = title.strip()
                else:
                    url = f'https://apnetv.to/Hindi-Serial/{query}'
                    # self.referer = 'https://apnetv.co/Hindi-Serials'
                    release_title = re.sub(r'\d{4}', '', title).strip()  # remove year from title
                # log_utils.log(f"show url {url}")
                result = client.r_request(url, headers=self.headers).text
                # result = read_write_file(file_n='JSTesting/apnetv.me.html')
                # log_utils.log(f"watchapne release_title: {release_title}")
                try:
                    if 'web-series' in url:
                        results = client.parseDOM(result, 'div', attrs={'class': 's-epidode clearfix'})
                        results += client.parseDOM(result, 'div', attrs={'class': 'web-series-grid'})
                    else:
                        results = client.parseDOM(result, 'ul', attrs={'class': 'ul'})
                        results = client.parseDOM(results, 'li')
                    for result in results:
                        # log_utils.log(f"watchapne episode result: {result}")
                        if release_title in result:
                            url = client.parseDOM(result, "a", ret="href")[0]
                            return url
                except:
                    log_utils.error(f'{__name__}_ episode: ')
            return
        except:
            log_utils.error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict, hostprDict):
        # log_utils.log(f"From: {self.name} url: {url} ")
        sources = []
        try:
            if not url:	return sources
            result = requests.get(url, headers=self.headers).text
            if not result: return
            result = client.parseDOM(result, 'div', attrs={'class': 'bottom_episode_list'})
            items = client.parseDOM(result, 'li')
            for item in items:
                urls = client.parseDOM(item, 'a', ret='href')
                # log_utils.log(f'urls: {urls}')
                furls = []
                vidhost = None
                for j in range(0, len(urls)):
                    try:
                        vhdr = {'Referer': self.referer}
                        link = f'{urls[j]}{append_headers(vhdr)}'
                        furls.append(link)
                    except:
                        log_utils.error(f'{__name__}_ sources: ')
                if len(furls) > 0:
                    sources = get_source_dict(furls, sources, vidhost)
            return sources
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return sources
    
    def apne_twostop(self, url, headers):
        # headers.update(self.headers)
        # url = url.replace('www.hindistoponline.com', 'hindigostop.com')
        # log_utils.log(f'headers >>> : {headers}')
        html = requests.get(url, headers=headers).text
        try:
            urltopost = re.search(r'''<form.*action=["'](.+?)["']''', html)
            urltopost = urltopost.group(1)
            inputNameValue = re.compile('''input.*?name=["'](.+?)["'].+?value=["'](.+?)["']''', re.M)
            formFields = inputNameValue.findall(html)
            # log_utils.log(f'0 formFields {formFields}')
            postFields = {}
            for field in formFields:
                # log_utils.log(f'0 field {field}')
                postFields[field[0].encode("ascii")] = field[1].encode("ascii")
            # log_utils.log(f'0 postFields {postFields}')
            html = requests.post(urltopost, headers=headers, data=postFields).text
            # log_utils.log(f'html >>> : {html}')
            return html
        except Exception as e:
            log_utils.error(f'{__name__}_ apne_twostop: ')
    
    def resolve(self, url):
        # log_utils.log(f'In type of url {type(url)} url: {url}')
        try:
            if not any(re.findall(r'dailymotion|vup|streamtape|vidoza|mixdrop|mystream|doodstream|watchvideo|vkprime|vkspeed', url, re.IGNORECASE)):
                if ' , ' in url: iurl = url.split(' , ')
                else: iurl = [url]
                # log_utils.log(f'In len of iurl {len(iurl)} iurl: {iurl}')
                furl = links = []
                headers = get_headersfrom_url(url)
                headers.update({'User-Agent': client.agent()})
                # log_utils.log(f'In type of headers {type(headers)} headers: {headers}')
                for url in range(0, len(iurl)):
                    url=iurl[url]
                    # log_utils.log(f'watchapne type of url {type(url)} url: {url}')
                    if any([x in url for x in self.apneembed]):
                        refresh = True
                        while refresh:
                            url = url.replace('/go.', '/')
                            if '/?' not in url:
                                url = url.replace('?', '/?')
                            r = client.request(url, headers=headers, output='extended')
                            if r[2].get('Refresh'):
                                url = r[2].get('Refresh').split(' ')[-1]
                            else:
                                html = r[0]
                                refresh = False
                        r = re.findall(r'''<form.+?action="([^"]+).+?name='([^']+)'\s*value='([^']+)''', html, re.DOTALL)
                        if r:
                            purl, name, value = r[0]
                            html = client.request(purl, post={name: value}, headers=headers)
                            s = re.findall(r"<iframe.+?src='([^']+)", html)
                            if s:
                                strurl = s[0]
                                # log_utils.log(f'watchapne type of strurl {type(strurl)} strurl: {strurl}')
                                if 'url=' in strurl:
                                    strurl = strurl.split('url=')[-1]
                                if 'hls' in strurl and 'videoapne' in strurl:
                                    strurl = strurl.replace('hls/,', '')
                                    strurl = strurl.replace(',.urlset/master.m3u8', '/v.mp4')
                                # if strurl.endswith('.m3u8'): headers.update({'Range': 'bytes=0-'})
                                # strurl = '{0}|{1}'.format(strurl, urlencode(headers))
                                if strurl not in furl:
                                    furl.append(strurl)
                # log_utils.log(f'watchapne len furl: {len(furl)} type furl {type(furl)} furl: {furl}')
                if len(furl) > 0: url = ' , '.join(furl)
                else: url = furl[0]
                # log_utils.log(f'watchapne type of url {type(url)} url: {url}')
                return url
        except Exception as e:
            log_utils.error(f'{__name__}_ url: {url} resolve: {e}')
            return
