# -*- coding: UTF-8 -*-

# import json
import re

# try: from urllib import quote_plus
# except ImportError: from urllib.parse import quote_plus
import requests
from openscrapers.modules import client, log_utils
from openscrapers.modules.hindi_sources import get_source_dict, urlRewrite, resolve_gen, host


class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "desitelly"
        self.domains = ['desitellybox.me']
        self.base_link = 'https://www.desitellybox.me'
        self.headers = {'User-Agent': client.agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log_utils.log("From: {} \nimdb {} \ntvdb {}\n tvshowtitle {}, localtvshowtitle {}, aliases {}, year {} ".format(self.name, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))
        try:
            # query = '%s' % tvshowtitle
            # url = query
            # log_utils.log('>>> #### 0AAAA - desitelly EP url : %s' % ( url))
            return '%s' % tvshowtitle
        except:
            log_utils.error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log_utils.log("From: {} url {} ... \nimdb {} .. tvdb {}\n title {}, premiered {}, season {}, episode {} ".format(self.name, url, imdb, tvdb, title, premiered, season, episode))
        try:
            if type(tvdb) == int:
                return
            if '|' in tvdb:
                # log_utils.log("type desitelly tvdb %s" % type(tvdb))
                # tvdb = tvdb.split('|')
                # ch_name = tvdb[0]
                # title = tvdb[1].lower().replace(' ', '-')
                title = title.lower()
                furl = '%s-%s-episode-watch-online/' % (url, title)
                if 'episode' in title.lower():
                    furl = '%s-watch-online-%s/' % (url, title)
                url = furl.lower().replace(' ', '-').replace('.', '').replace('---', '-').replace("’", '')
                url = "%s/%s" % (self.base_link, url)
                # print('url: {}'.format(url))
                return url
            else: return
        except:
            log_utils.error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict, hostprDict):
        # log_utils.log(f"From sources: {self.name} url: {url} ")
        sources = []
        try:
            if not url: return sources
            # result = requests.get(url, headers=self.headers).text
            result = client.r_request(url).text
            if not result:
                return sources
            result = client.parseDOM(result, 'div', attrs={'class': 'entry_content'})
            # log_utils.log(result)
            items = client.parseDOM(result, 'p')
            # log_utils.log(items)
            for item in items:
                # log_utils.log(item)
                urls = client.parseDOM(item, 'a', ret='href')
                # log_utils.log('....\n%s' % urls)
                furls = []
                vidhost = None
                for j in range(0, len(urls)):
                    # log_utils.log('....\n%s' % urls[j])
                    try:
                        headers = {'Referer': urls[j]}
                        self.headers.update(headers)
                        result = requests.get(urls[j], headers=self.headers).text
                        if result:
                            links = client.parseDOM(result, 'iframe', ret='src')
                            for link in links:
                                if 'vkprime' in link or 'speed' in link or 'watchvideo.us' in link:
                                    vidhost = host(link)
                                    furls.append(link)
                                elif 'flow.' in link:
                                    # vidhost = 'CDN'
                                    furls.append(urls[j])
                    except:
                        log_utils.error('%s_ sources: ' % __name__)
                if len(furls) > 0:
                    sources = get_source_dict(furls, sources, vidhost)
            # dumper = dumper
            # log_utils.log('SOURCES \n\n%s' % json.dumps(sources, default = dumper, indent = 2))
            return sources
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # log_utils.log('In type of url {} url: {}'.format(type(url), url))
        url = resolve_gen(url)
        return url
