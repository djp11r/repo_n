# -*- coding: utf-8 -*-

import inspect
from datetime import datetime
from traceback import format_stack, print_exc

try:
	import xbmc
	from openscrapers.modules.control import getKodiVersion, translate_path, setting as getSetting, lang, joinPath, existsPath, addonInfo
	LOGPATH = translate_path('special://logpath/')
	addonName = addonInfo('name')
	debug_enabled = getSetting('debug.enabled') == 'true'
	debug_location = getSetting('debug.location')
	reverse_log = getSetting('debug.reversed') == 'true'
	logger = xbmc.log
except:
	print(f'Error: {print_exc()}')
	addonName = False
if not addonName:
	from os.path import join as joinPath
	from os.path import exists as existsPath
	logger = print
	addonName = "OPENSCRAPERS"
	debug_enabled = True
	debug_location = '0'
	reverse_log = ''
	LOGPATH = ''
#print(f'LOGPATH: {LOGPATH}\naddonName: {addonName}\ndebug_enabled: {debug_enabled}\ndebug_location: {debug_location}\nreverse_log: {reverse_log}')
LOGDEBUG = 0
LOGINFO = 1
LOGWARNING = 2
LOGERROR = 3
LOGFATAL = 4
LOGNONE = 5 # not used

debug_list = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'FATAL']
DEBUGPREFIX = '[ OPENSCRAPERS %s ]'


def log(msg, caller=None, level=LOGINFO, stack=False):

	if not debug_enabled: return
	if isinstance(msg, int): msg = lang(msg) # for strings.po translations
	try:
		if not msg.isprintable(): # ex. "\n" is not a printable character so returns False on those cases
			msg = f'{normalize(msg)} (NORMALIZED by log_utils.log())'
		if isinstance(msg, bytes):
			msg = f'{msg.decode("utf-8", errors="replace")} (ENCODED by log_utils.log())'

		if caller is not None and level != LOGERROR:
			func = inspect.currentframe().f_back.f_code
			line_number = inspect.currentframe().f_back.f_lineno
			caller = f'{caller}.{func.co_name}()'
			msg = f'From func name: {caller} Line # :{line_number}\n                       msg : {msg}'
		elif caller is not None:
			msg = f'From func name: {caller[0]}.{caller[1]}() Line # :{caller[2]}\n                       msg : {msg}'
		if stack:
			# try: _stack = format_stack()[-3:-2][0]
			# except: _stack = format_stack()
			try: msg = f'{msg}\ntraceback for func: {format_stack()[-3:-2][0].split("script.module.openscrapers")[1:]}'
			except: msg = f'{msg} traceback Found: {format_stack()}'
		if debug_location == '1':
			log_file = joinPath(LOGPATH, 'openscrapers.log')
			if not existsPath(log_file):
				f = open(log_file, 'w')
				f.close()
			datestr = str(datetime.now().date())[5:]
			timestr = str(datetime.now().time())[:5]
			if not reverse_log:
				with open(log_file, 'a', encoding='utf-8') as f: # "with" auto cleans up and closes
					line = f'[{datestr} {timestr}] {DEBUGPREFIX % debug_list[level]}: {msg}'
					f.write(line.rstrip('\r\n') + '\n')
					# f.writelines([line1, line2]) ## maybe an option for the 2 lines without using "\n"
			else:
				with open(log_file, 'r+', encoding='utf-8') as f:
					line = f'[{datestr} {timestr}] {DEBUGPREFIX % debug_list[level]}: {msg}'
					log_file = f.read()
					f.seek(0, 0)
					f.write(line.rstrip('\r\n') + '\n' + log_file)
		else:
			logger(f'OPEN>>>>:: {msg} level: {debug_list[level]}', level)
	except Exception as e:
		logger(f'Logging Failure: {e} {msg} \ntraceback:{print_exc()}', LOGERROR)


def error(message=None, exception=True):
	try:
		import sys
		if exception:
			type, value, traceback = sys.exc_info()
			addon = 'script.module.openscrapers'
			filename = traceback.tb_frame.f_code.co_filename
			if addon in filename:
				filename = filename.split(addon)[1]
			name = traceback.tb_frame.f_code.co_name
			linenumber = traceback.tb_lineno
			errortype = type.__name__
			errormessage = value or value.message
			# if not str(errormessage): return
			if message: message += ' -> '
			else: message = ''
			message += f'{str(errortype)} -> {str(errormessage)}'
			caller = [filename, name, linenumber]
			del (type, value, traceback)  # So we don't leave our local labels/objects dangling
		else:
			caller = None
		log(msg=message, caller=caller, level=LOGERROR)
	except Exception as e:
		logger(f'Logging Failure: {e}', LOGERROR)

def clear_logFile():
	cleared = False
	try:
		from openscrapers.modules.control import yesnoDialog
		if not yesnoDialog(lang(32060), '', ''): return 'canceled'
		log_file = joinPath(LOGPATH, 'openscrapers.log')
		if not existsPath(log_file):
			f = open(log_file, 'w')
			return f.close()
		with open(log_file, 'r+') as f:
			f.truncate(0) # need '0' when using r
		cleared = True
	except Exception as e:
		logger(f'[ script.module.openscrapers ] log_utils.clear_logFile() Failure: {e}', LOGERROR)
	return cleared

def view_LogFile():
	try:
		from openscrapers.windows.textviewer import TextViewerXML
		from openscrapers.modules.control import addonPath, notification
		name = 'kodi'
		log_file = joinPath(LOGPATH, 'kodi.log')
		if not existsPath(log_file):
			return notification(message='Log File not found, likely logging is not enabled.')

		with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
			text = f.read()
		heading = f'[B]{name} -  LogFile[/B]'
		windows = TextViewerXML('textviewer.xml', addonPath(), heading=heading, text=text)
		windows.run()
		del windows
	except:
		error()

def upload_LogFile():
	from openscrapers.modules.control import notification,  addonVersion, selectDialog
	import re
	url = 'https://paste.kodi.tv/'
	log_file = joinPath(LOGPATH, 'openscrapers.log')
	if not existsPath(log_file):
		return notification(message='Log File not found, likely logging is not enabled.')
	try:
		import requests
		with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
			text = f.read()
		regex = re.compile(r"Users\\(?<!\w)(.+?)[\\|\/]", re.IGNORECASE)
		text = regex.sub(r'special://', text)
		UserAgent = f'openscrapers {addonVersion()}'
		response = requests.post(f'{url}documents', data=text.encode('utf-8', errors='ignore'), headers={'User-Agent': UserAgent})
		# log(f'log_response={response}')
		if 'key' in response.json():
			result = url + response.json()['key']
			log(f'openscrapers log file uploaded to: {result}')
			from sys import platform as sys_platform
			supported_platform = any(value in sys_platform for value in ('win32', 'linux2'))
			highlight_color = 'gold'
			list = [(f'[COLOR {highlight_color}]url:[/COLOR]  {str(result)}', str(result))]
			if supported_platform: list += [(f'[COLOR {highlight_color}]  -- Copy url To Clipboard[/COLOR]', ' ')]
			select = selectDialog([i[0] for i in list], lang(32059))
			if 'Copy url To Clipboard' in list[select][0]:
				from openscrapers.modules.source_utils import copy2clip
				copy2clip(list[select - 1][1])
		elif 'message' in response.json():
			notification(message=f'openscrapers Log upload failed: {str(response.json()["message"])}')
			log(f'openscrapers Log upload failed: {str(response.json()["message"])}', level=LOGERROR)
		else:
			notification(message='openscrapers Log upload failed')
			log(f'openscrapers Log upload failed: {response.text}', level=LOGERROR)
	except:
		error('openscrapers log upload failed')
		notification(message='pastebin post failed: See log for more info')

def normalize(msg):
	try:
		import unicodedata
		msg = ''.join(c for c in unicodedata.normalize('NFKD', msg) if unicodedata.category(c) != 'Mn')
		return str(msg)
	except:
		error()
		return msg
