# -*- coding: utf-8 -*-
"""
	Umbrella Addon
"""
import json
import re
import shutil
import zipfile
from urllib.parse import quote

import requests

try:
    from openscrapers.modules.control import get_addon_version, setting, setSetting, okDialog, openSettings, getLangString, homeWindow, delete_file, renameFile, sleep, notification
    from openscrapers.modules.log_utils import log, error
    from openscrapers.modules.cache import cache_get, cache_insert
    import xbmc
except:
    from .log_utils import log, error

base_url = 'https://api.opensubtitles.com/api/v1'
api_key = 'cQBWQwPugvGVDrpdU9MDRlvdfcu4WNTx'
version = get_addon_version()


class Opensubs():
    def __init__(self):
        self.username = setting('opensubs.user', 'GKobu')
        self.password = setting('opensubs.pw', 'GKoBu2017')
        self.jwt_token = setting('opensubstoken')
        self.headers = {'Api-Key': api_key, 'User-Agent': 'Umbrella v' + version, 'Content-Type': 'application/json', }
        self.headers1 = {'User-Agent': 'infinite v0.1'}
        self.highlight_color = setting('highlight.color')
        self.data = {"username": self.username, "password": self.password, }

    def get_jwt_token(self):
        url = base_url + '/login'
        response = requests.post(url, headers=self.headers, json=self.data)
        if response.status_code == 200:
            response = response.json()
            setSetting('opensubstoken', response.get('token'))
            return response
        else: return False

    def auth(self):
        if not self.username or not self.password: return False
        if self.jwt_token:
            url = base_url + '/infos/user'
            headers2 = dict(self.headers, **{'Authorization': self.jwt_token, })
            response = requests.get(url, headers=headers2)
            if response.status_code == 200: return True
            else: return self.get_jwt_token()
        else: self.get_jwt_token()

    def getSubs(self, title, imdb, year, season=None, episode=None):
        try:
            language = xbmc.convertLanguage(setting('subtitles.lang.1'), xbmc.ISO_639_1)
            if season:
                url = base_url + f'/subtitles?imdb_id={imdb}&season_number={season}&episode_number={episode}&languages={language}'
            else:
                url = base_url + f'/subtitles?imdb_id={imdb}&year={year}&languages={language}'
            headers = dict(self.headers, **{'Authorization': self.jwt_token, })
            response = requests.get(url, headers=headers)
            response = response.json()
            response = response['data']
            results = []
            log(f'OpenSubs Searching: Imdb:{imdb} Season: {season} Episode: {episode} Language: {language}.', level=1)
            for count, x in enumerate(response):
                try:
                    fileName = response[count]['attributes'].get('files')[0].get('file_name')
                    fileID = response[count]['attributes'].get('files')[0].get('file_id')
                    results.append({'fileName': fileName, 'fileID': fileID})
                except: error()
            return results
        except:
            results = []
            return results

    def downloadSubs(self, fileID, fileName):
        try:
            if not self.jwt_token: self.jwt_token = (self.get_jwt_token()).get('token')#'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIyelJlVmthcFI0QWtFdU0wbnhEblowWnU0emxCNWRPWSIsImV4cCI6MTcyNTgxOTg3MH0.Ugk-_YnnNNluonHRCO12OIOcylueq5iNVmLvWNO77eY'
            url = base_url + '/download'
            headers = dict(self.headers, **{'Authorization': self.jwt_token, })
            data = {"file_id": fileID, }
            response = requests.post(url, headers=headers, json=data)
            response = response.json()
            link = response.get('link')
            log(f'OpenSubs Download Link: {link} Filename: {fileName}.', level=1)
            return link, fileName
        except:
            error()
            return None

    def getAccountStatus(self):
        try:
            if not self.username or not self.password: return okDialog(title=40503, message='Please enter username and password.')
            response = self.get_jwt_token()
            responseUser = response.get('user')
            responseToken = response.get('token')
            username = self.username
            a_downloads = responseUser.get('allowed_downloads')
            setSetting('opensubstoken', responseToken)
            openSettings('0.0')
            return okDialog(title=40503, message=f'Logged in Username: {username} [CR] Allowed Downloads: {a_downloads}')
        except:
            error()
            return okDialog(title=40503, message='Error checking opensubs. Please check use your username and not your email to authenticate and password. Press Ok to save and try checking again.')

    def revokeAccess(self):
        try:
            homeWindow.setProperty('infinity.updateSettings', 'false')
            setSetting('opensubs.user', '')
            setSetting('opensubs.pw', '')
            setSetting('opensubstoken', '')
            homeWindow.setProperty('infinity.updateSettings', 'true')
            self.jwt_token = ''
            openSettings('0.0')
        except:
            error()

    def search(self, query, imdb_id, language, season=None, episode=None):
        # ('Britannia', '5932548', 'eng', 1, 4)
        cache_name = f'opensubtitles_{imdb_id}_{language}'
        if season: cache_name += f'_{season}_{episode}'
        if cache := cache_get(cache_name): return cache
        url = f'https://rest.opensubtitles.org/search/imdbid-{imdb_id}/query-{quote(query)}{f"/season-{season}/episode-{episode}" if season else ""}/sublanguageid-{language}'
        response = self._get(url, retry=True)
        if not response:
            log(f'Error OpenSubtitlesAPI search url: {url}')
            url = f'https://subs.wyzie.ru/search?id={imdb_id}{f"&season={season}&episode={episode}" if season else ""}&language={language}&type=srt'
            response = self._get(url, retry=True)
            if not response: return log(f'Error subs.wyzie search url: {url}')
        response = json.loads(response.text)
        cache_insert(cache_name, response, expires=48)
        return response

    def download(self, url, filepath, temp_zip, temp_path, final_path):
        # ('https://dl.opensubtitles.org/en/download/src-api/vrf-f5590bb8/subad/7258810', 'C:\\Users\\JP\\AppData\\Roaming\\Kodi\\cache\\', 'C:\\Users\\JP\\AppData\\Roaming\\Kodi\\cache\\temp.zip', 'C:\\Users\\JP\\AppData\\Roaming\\Kodi\\cache\\Britannia.S01E04.WEBRip.x264-ION10.srt', 'C:\\Users\\JP\\AppData\\Roaming\\Kodi\\cache\\infiniteSubs_5932548_1_4_eng.srt')
        if 'subencoding-utf8/' in url: url = url.replace('subencoding-utf8/', '')
        result = self._get(url, stream=True, retry=True)
        with open(temp_zip, 'wb') as f: shutil.copyfileobj(result.raw, f)
        with zipfile.ZipFile(temp_zip, 'r') as zip_file: zip_file.extractall(filepath)
        delete_file(temp_zip)
        renameFile(temp_path, final_path)
        with open(final_path, 'r', encoding='utf-8', errors='ignore') as sub_contents:
            file = sub_contents.read()
        ifile = self.cleanup_subtitles(file)
        if ifile:
            with open(final_path, mode='w', encoding='utf-8', errors='ignore') as f:
                f.write(ifile)
        return final_path

    def _get(self, url, stream=False, retry=False):
        response = requests.get(url, headers=self.headers1, stream=stream)
        if '200' in str(response): return response
        elif '429' in str(response) and retry:
            notification('OpenSubtitles Rate Limited. Retrying in 10 secs..', 3500)
            sleep(10000)
            return self._get(url, stream)
        else: return

    def cleanup_subtitles(self, sub_contents):
        __url_regex = r'[a-z0-9][a-z0-9-]{0,5}[a-z0-9]\.[a-z0-9]{2,20}\.[a-z]{2,5}'
        fist_last_regex = '(Support us and become|to remove all ads|Watch any video online|Free Browser extension)'
        __credit_part_regex = r'(sync|synced|fix|fixed|corrected|corrections)'
        __credit_regex = __credit_part_regex + r' ?&? ?' + __credit_part_regex + r'? by'
        all_lines = sub_contents.split('\n')
        cleaned_lines = []
        buffer = []
        garbage = False

        if all_lines[0].strip() != '': all_lines.insert(0, '')
        if all_lines[-1].strip() != '': all_lines.append('')

        for line in all_lines:
            line = line.strip()
            if garbage and line != '': continue
            garbage = False
            line_contains_ad = (re.search(fist_last_regex, line, re.IGNORECASE) or re.search(__url_regex, line, re.IGNORECASE) or re.search(__credit_regex, line, re.IGNORECASE))

            if line_contains_ad:
                if not re.match(r'^\{\d+\}\{\d+\}', line):
                    log(f'(detected ad) {line.encode("ascii", errors="ignore")}')
                    garbage = True
                    buffer = []
                continue

            if line == '':
                if len(buffer) > 0:
                    buffer.insert(0, '')
                    cleaned_lines.extend(buffer)
                    buffer = []
                continue
            buffer.append(line)
        return '\n'.join(cleaned_lines)