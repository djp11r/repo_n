# -*- coding: utf-8 -*-
"""
    Umbrella Addon
"""
import json
import os
import re
import requests
from urllib.parse import quote
from urllib.request import urlopen, Request
from traceback import print_exc
from difflib import SequenceMatcher
import shutil
from zipfile import ZipFile
try:
    from openscrapers.modules.control import get_addon_version, setting, setSetting, okDialog, openSettings, getLangString, homeWindow, delete_file, renameFile, sleep, notification, temppath, existsPath, xbmc_player, jsonrpc, listDir, joinPath, get_sub_settings
    from openscrapers.modules.log_utils import log, error
    from openscrapers.modules.cache import cache_get, cache_insert
    from openscrapers.modules.source_utils import seas_ep_filter
    from openscrapers.modules.cleantitle import get_simple
except:
    from .log_utils import log, error
    temppath = ''

base_url = 'https://api.opensubtitles.com/api/v1'
api_key = 'cQBWQwPugvGVDrpdU9MDRlvdfcu4WNTx'
version = get_addon_version()
usefull_lang = ('en', 'eng', 'hi')


class Opensubs():
    def __init__(self):
        self.username = setting('opensubs.user', 'GKobu')
        self.password = setting('opensubs.pw', 'GKoBu2017')
        self.jwt_token = setting('opensubstoken')
        self.headers = {'Api-Key': api_key, 'User-Agent': 'Umbrella v' + version, 'Content-Type': 'application/json', }
        self.headers1 = {'User-Agent': 'infinite v0.1'}
        self.highlight_color = setting('highlight.color')
        self.data = {"username": self.username, "password": self.password, }

    def get_jwt_token(self):
        url = base_url + '/login'
        response = requests.post(url, headers=self.headers, json=self.data)
        log(f'get_jwt_token headers: {self.headers} self.data: {self.data} response.json(): {response}')
        if response.status_code == 200:
            response = response.json()
            log(f'get_jwt_token response: {repr(response)}')
            setSetting('opensubstoken', response.get('token'))
            return response
        else: return False

    def auth(self):
        if not self.username or not self.password: return False
        if self.jwt_token:
            url = base_url + '/infos/user'
            headers2 = dict(self.headers, **{'Authorization': self.jwt_token, })
            response = requests.get(url, headers=headers2)
            if response.status_code == 200: return True
            else: return self.get_jwt_token()
        else: self.get_jwt_token()

    def getAccountStatus(self):
        try:
            if not self.username or not self.password: return okDialog(title=40503, message='Please enter username and password.')
            response = self.get_jwt_token()
            responseUser = response.get('user')
            responseToken = response.get('token')
            username = self.username
            a_downloads = responseUser.get('allowed_downloads')
            setSetting('opensubstoken', responseToken)
            openSettings('0.0')
            return okDialog(title=40503, message=f'Logged in Username: {username} [CR] Allowed Downloads: {a_downloads}')
        except:
            error(f'{__name__} Error: {print_exc()}')
            return okDialog(title=40503, message='Error checking opensubs. Please check use your username and not your email to authenticate and password. Press Ok to save and try checking again.')

    def revokeAccess(self):
        try:
            homeWindow.setProperty('infinity.updateSettings', 'false')
            setSetting('opensubs.user', '')
            setSetting('opensubs.pw', '')
            setSetting('opensubstoken', '')
            homeWindow.setProperty('infinity.updateSettings', 'true')
            self.jwt_token = ''
            openSettings('0.0')
        except:
            error(f'{__name__} Error: {print_exc()}')

    def getSubs(self, title, imdb, season=None, episode=None, year=None):
        try:
            # if not self.jwt_token: self.jwt_token = (self.get_jwt_token()).get('token') #'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIyelJlVmthcFI0QWtFdU0wbnhEblowWnU0emxCNWRPWSIsImV4cCI6MTcyNTgxOTg3MH0.Ugk-_YnnNNluonHRCO12OIOcylueq5iNVmLvWNO77eY'
            language = setting('subtitles.lang_primary') or 'en'
            if season: url = base_url + f'/subtitles?imdb_id={imdb}&season_number={season}&episode_number={episode}&languages={language}'
            else: url = base_url + f'/subtitles?imdb_id={imdb}&year={year}&languages={language}'
            sub_file_name = f'{title} S{season} E{episode}' if season else f'{title}'
            srtFile = os.path.join(temppath, f'{get_simple(sub_file_name)}.srt')
            # if existsPath(srtFile): return srtFile
            headers = dict(self.headers, **{'Authorization': self.jwt_token, })
            # log(f'getSubs headers: {headers}')
            response = requests.get(url, headers=headers)
            jresponse = response.json()
            dresponse = jresponse['data']
            if not dresponse:
                log(f'getSubs imdb: {imdb} dresponse: {dresponse}')
                subfilter = []
                result = self.search(title, imdb, season, episode, language)
                if not result: return
                if season:
                    try:
                        try: subfilter = [{'fileName': i.get('MovieReleaseName'), 'fileID': i.get('ZipDownloadLink'), 'ratio': SequenceMatcher(None, title.lower(), i.get('MovieReleaseName').lower()).ratio()} for i in result if title.lower() in i['MovieReleaseName'].lower() and str(season) == i.get('SeriesSeason') and str(episode) == i.get('SeriesEpisode') and i['SubLanguageID'] in usefull_lang and i['SubSumCD'] == '1'][0]
                        except: subfilter = [{'fileName': i.get('MovieReleaseName'), 'fileID': i.get('ZipDownloadLink'), 'ratio': SequenceMatcher(None, title.lower(), i.get('MovieName').lower()).ratio()} for i in result if title.lower() in i['MovieName'].lower() and str(season) == i.get('SeriesSeason') and str(episode) == i.get('SeriesEpisode') and i['SubLanguageID'] in usefull_lang and i['SubSumCD'] == '1'][0]
                    except: log(f'result: {result}')
                if not subfilter:
                    try: subfilter = [{'fileName': i.get('MovieReleaseName'), 'fileID': i.get('ZipDownloadLink'), 'ratio': SequenceMatcher(None, title.lower(), i.get('MovieReleaseName').lower()).ratio()} for i in result if title.lower() in i['MovieReleaseName'].lower() and i['SubLanguageID'] in usefull_lang and i['SubSumCD'] == '1'][0]
                    except: subfilter = [{'fileName': i.get('MovieReleaseName'), 'fileID': i.get('ZipDownloadLink'), 'ratio': SequenceMatcher(None, title.lower(), i.get('MovieName').lower()).ratio()} for i in result if title.lower() in i['MovieName'].lower() and i['SubLanguageID'] in usefull_lang and i['SubSumCD'] == '1'][0]
                    # log(f'2subfilter: {subfilter}')
                chosen_sub = subfilter if subfilter else result[0]
                # log(f'chosen_sub: {chosen_sub}')
                if not chosen_sub: return
                DownloadLink = chosen_sub.get('fileID') or chosen_sub.get('ZipDownloadLink')
                # log(f'DownloadLink: {DownloadLink}')
                return self.downloadSubs(DownloadLink, srtFile)
                # return
            results = []
            # log(f'OpenSubs Searching: Imdb:{imdb} Season: {season} Episode: {episode} Language: {language} jresponse: {jresponse}', level=1)
            for count, x in enumerate(dresponse):
                try:
                    seq = None
                    sub_lang = dresponse[count]['attributes'].get('language')
                    if sub_lang not in usefull_lang: continue
                    fileName = dresponse[count]['attributes'].get('files')[0].get('file_name')
                    fileID = dresponse[count]['attributes'].get('files')[0].get('file_id')
                    if season and seas_ep_filter(season, episode, fileName):
                        seq = SequenceMatcher(None, title.lower(), fileName.lower())
                    else: seq = SequenceMatcher(None, title.lower(), fileName.lower())
                    # log(f'seq: {seq} title.lower(): {title.lower()} fileName.lower(): {fileName.lower()}')
                    if seq: results.append({'fileName': fileName, 'fileID': fileID, 'ratio': seq.ratio()})
                except: error(f'{__name__} dresponse: {dresponse}')
            results.sort(key=lambda i: i['ratio'], reverse=True)
            return self.downloadSubs(results[0]['fileID'], srtFile)
        except:
            error(f'{__name__} title: {title}\nimdb: {imdb} srtFile: {srtFile} jresponse: {jresponse} Error: {print_exc()}')
            return None

    def downloadSubs(self, fileID, srtFile):
        try:
            url = base_url + '/download'
            headers = dict(self.headers, **{'Authorization': self.jwt_token, })
            # log(f'downloadSubs headers: {headers}')
            data = {"file_id": fileID, }
            response = requests.post(url, headers=headers, json=data)
            response = response.json()
            link = response.get('link')
            # log(f'OpenSubs Download Link: {link} response: {response}', level=1)
            # response = requests.get(link, headers={'User-Agent': "Magic Browser"}, stream=True)
            # log(f'from link: {link} response: {response.text}', level=1)
            # with open(srtFile, 'w', encoding='utf-8', errors='ignore') as f:
                # f.write(response.text)
            reqqqq = Request(link, headers={'User-Agent': "Magic Browser"})
            http_response = urlopen(reqqqq)
            response = http_response.read()
            response = response.decode('utf-8')
            # log(f'from link: {link} response: {response}', level=1)
            with open(srtFile, 'w', encoding="utf-8") as f:
                f.write(response)
            # log(f'opened file {srtFile}', level=1)
            return srtFile
        except:
            error(f'{__name__} downloadURL: {link or url}\nsrtFile: {srtFile} Error: {print_exc()}')
            return None

    def search(self, title, imdb_id, season=None, episode=None, language=None):
        # ('Britannia', '5932548', 'eng', 1, 4)
        cache_name = f'opensubtitles_{imdb_id}_{language}'
        if season: cache_name += f'_{season}_{episode}'
        if cache := cache_get(cache_name): return cache
        url = f'https://rest.opensubtitles.org/search/imdbid-{imdb_id}/query-{quote(title)}{f"/season-{season}/episode-{episode}" if season else ""}/sublanguageid-{language}'
        response = self._get(url, retry=True)
        if not response:
            log(f'Error OpenSubtitlesAPI search url: {url}')
            url = f'https://subs.wyzie.ru/search?id={imdb_id}{f"&season={season}&episode={episode}" if season else ""}&language={language}&type=srt'
            response = self._get(url, retry=True)
            if not response: return log(f'Error subs.wyzie search url: {url}')
        response = json.loads(response.text)
        cache_insert(cache_name, response, expires=48)
        return response

    def download(self, url, final_path):
        # ('https://dl.opensubtitles.org/en/download/src-api/vrf-f5590bb8/subad/7258810', 'C:\\Users\\JP\\AppData\\Roaming\\Kodi\\cache\\Britannia.S01E04.WEBRip.x264-ION10.srt',)
        if 'subencoding-utf8/' in url: url = url.replace('subencoding-utf8/', '')
        temp_zip = os.path.join(temppath, 'temp.zip')
        result = self._get(url, stream=True, retry=True)
        with open(temp_zip, 'wb') as f: shutil.copyfileobj(result.raw, f)
        with ZipFile(temp_zip, 'r') as zip_file: zip_file.extractall(temppath)
        delete_file(temp_zip)
        # renameFile(temp_path, final_path)
        with open(final_path, 'r', encoding='utf-8', errors='ignore') as sub_contents:
            file = sub_contents.read()
        ifile = self.cleanup_subtitles(file)
        if ifile:
            with open(final_path, mode='w', encoding='utf-8', errors='ignore') as f:
                f.write(ifile)
        return final_path

    def _get(self, url, stream=False, retry=False):
        response = requests.get(url, headers=self.headers1, stream=stream)
        if '200' in str(response): return response
        elif '429' in str(response) and retry:
            notification('OpenSubtitles Rate Limited. Retrying in 10 secs..', 3500)
            sleep(10000)
            return self._get(url, stream)
        else: return

    def cleanup_subtitles(self, sub_contents):
        __url_regex = r'[a-z0-9][a-z0-9-]{0,5}[a-z0-9]\.[a-z0-9]{2,20}\.[a-z]{2,5}'
        fist_last_regex = r'(Support us and become|to remove all ads|Watch any video online|Free Browser extension)'
        __credit_part_regex = r'(sync|synced|fix|fixed|corrected|corrections)'
        __credit_regex = __credit_part_regex + r' ?&? ?' + __credit_part_regex + r'? by'
        all_lines = sub_contents.split('\n')
        cleaned_lines = []
        buffer = []
        garbage = False

        if all_lines[0].strip() != '': all_lines.insert(0, '')
        if all_lines[-1].strip() != '': all_lines.append('')

        for line in all_lines:
            line = line.strip()
            if garbage and line != '': continue
            garbage = False
            line_contains_ad = (re.search(fist_last_regex, line, re.IGNORECASE) or re.search(__url_regex, line, re.IGNORECASE) or re.search(__credit_regex, line, re.IGNORECASE))

            if line_contains_ad:
                if not re.match(r'^\{\d+\}\{\d+\}', line):
                    log(f'(detected ad) {line.encode("ascii", errors="ignore")}')
                    garbage = True
                    buffer = []
                continue

            if line == '':
                if len(buffer) > 0:
                    buffer.insert(0, '')
                    cleaned_lines.extend(buffer)
                    buffer = []
                continue
            buffer.append(line)
        return '\n'.join(cleaned_lines)



class Subtitles(xbmc_player):
    def __init__(self):
        xbmc_player.__init__(self)
        self.os_api = Opensubs()
        sub_settings = get_sub_settings()
        self.auto_enable = sub_settings['auto_enable']
        self.language = sub_settings['language']
        self.quality = ['bluray', 'hdrip', 'brrip', 'bdrip', 'dvdrip', 'webdl', 'webrip', 'webcap', 'web', 'hdtv', 'hdrip']
        self.audio_preference = sub_settings['audio_preference']
        self.secondary_language = sub_settings['secondary_language']

    def get(self, query, imdb_id, season, episode, sub_url=None, secondary_search=False):
        def _notification(line, _time=3500):
            return notification(line, _time)

        def _video_file_subs():
            try: available_sub_language = self.getSubtitles()
            except: available_sub_language = ''
            if available_sub_language in usefull_lang:
                if self.auto_enable == 'true': self.showSubtitles(True)
                _notification('Local Subtitles Found')
                return True
            return False

        def _downloaded_subs():
            files = listDir(subtitle_path)[1]
            if len(files) > 0:
                match_lang1 = None
                match_lang2 = None
                files = [i for i in files if i.endswith('.srt')]
                for item in files:
                    if item == search_filename:
                        match_lang1 = item
                        break
                final_match = match_lang1 or match_lang2 or None
                if final_match:
                    subtitle = joinPath(subtitle_path, final_match)
                    _notification('Downloaded Subtitles Found')
                    return subtitle
            return False

        def _searched_subs():
            subtitle = self.os_api.getSubs(query, imdb_id, season, episode)
            if not subtitle or len(subtitle) == 0: _notification('No Subtitles Found in searched'); return False
            sleep(100)
            return subtitle

        if self.audio_preference: self.setAudioPrefs()
        if self.auto_enable == 'true': self.showSubtitles(True)
        if imdb_id is None: return _notification('No Subtitles Found')
        imdb_id = re.sub(r'[^0-9]', '', str(imdb_id))
        subtitle_path = temppath
        sub_filename = f'{query} S{season} E{episode}' if season else f'{query}'
        search_filename = f'{get_simple(sub_filename)}.srt'
        subtitle = _video_file_subs()
        # log(f'_video_file_subs: {subtitle}')
        if subtitle: return
        subtitle = _downloaded_subs()
        # log(f'_downloaded_subs: {subtitle}')
        if subtitle: return self.setSubtitles(subtitle)
        # log(f'sub_url: {subtitle}')
        if sub_url and '.srt' in sub_url: return self.setSubtitles(sub_url)
        if self.auto_enable == 'false': return
        # subtitle = _searched_subs()
        # log(f'_searched_subs: {subtitle}')
        # if subtitle: return self.setSubtitles(subtitle)
        if secondary_search: return _notification('No Subtitles Found')
        if self.secondary_language in (self.language, None, 'None', ''): return _notification('No Subtitles Found')
        self.language = self.secondary_language
        self.get(query, imdb_id, season, episode, secondary_search=True)

    def setAudioPrefs(self):
        try:
            activePlayers = '{"jsonrpc": "2.0", "method": "Player.GetActivePlayers", "id": 1}'
            json_query = jsonrpc(activePlayers)
            json_response = json.loads(json_query)
            activePlayerID = json_response['result'][0]['playerid']
            details_query_dict = {"jsonrpc": "2.0", "method": "Player.GetProperties", "params": {"properties": ["currentaudiostream", "audiostreams", "subtitleenabled", "currentsubtitle", "subtitles"], "playerid": activePlayerID}, "id": 1}
            details_query_string = json.dumps(details_query_dict)
            json_query = jsonrpc(details_query_string)
            json_response = json.loads(json_query)

            if 'result' in json_response and json_response['result'] is not None:
                self.current_audio_stream = json_response['result']['currentaudiostream']
                self.audiostreams = json_response['result']['audiostreams']
                self.evalPrefs()
            # log(f'json_response: {json_response}\nlen(self.audiostreams): {len(self.audiostreams)} self.audiostreams: {self.audiostreams}')
        except: log(f'{__name__} Error: {print_exc()}')

    def evalPrefs(self):
        try:
            audio_changed = False
            audio = self.evalFilenamePrefs()
            if (audio >= 0) and audio < len(self.audiostreams):
                self.setAudioStream(audio)
                audio_changed = True
            if not audio_changed:
                trackIndex = self.evalAudioPrefs(self.language)
                if trackIndex == -2: audio_changed = True
                elif trackIndex >= 0:
                    log(f'Audio:: Match found for audio track {trackIndex} languages: {self.language}')
                    self.setAudioStream(trackIndex)
                    audio_changed = True
        except: log(f'{__name__} Error: {print_exc()}')

    def evalFilenamePrefs(self):
        try:
            audio = -1
            filename = self.getPlayingFile()
            log(f'evalFilenamePrefs filename: {filename}')
            reg = re.compile(r'audiostream[_|.|-]*\d+|subtitle[_|.|-]*\d+', re.I)
            split = re.compile(r'[_|.|-]*', re.I)
            matches = reg.findall(filename)
            fileprefs = []
            for m in matches:
                sp = split.split(m)
                fileprefs.append(sp)

            for pref in fileprefs:
                if len(pref) == 2 and pref[0].lower() == 'audiostream':
                    audio = int(pref[1])
                    log(f'audio track extracted from filename: {audio}')
                    return audio
            return audio
        except: log(f'{__name__} Error: {print_exc()}')

    def evalAudioPrefs(self, audio_prefs):
        try:
            if audio_prefs is None: return -2
            if (self.current_audio_stream and 'language' in self.current_audio_stream) and audio_prefs == self.current_audio_stream['language']:
                return -2
            for stream in self.audiostreams:
                if stream['language'] in ('en', 'eng') or self.secondary_language == stream['language']:
                    log(f'Audio language of stream index {stream["index"]} language: {stream["language"]}')
                    return stream['index']
            return -2
        except: log(f'{__name__} Error: {print_exc()}')
