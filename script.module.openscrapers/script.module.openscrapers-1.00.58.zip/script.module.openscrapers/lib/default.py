# -*- coding: utf-8 -*-

from sys import argv
from six.moves.urllib_parse import parse_qsl
from openscrapers import sources_openscrapers
from openscrapers.modules.control import openSettings, setProviderDefaults, setSetting, execute, sleep, condVisibility, homeWindow, clean_settings, notification, okDialog

params = dict(parse_qsl(argv[2].replace('?', '')))
action = params.get('action')
mode = params.get('mode')
query = params.get('query')
name = params.get('name')

if action is None:
	openSettings('0.0', 'script.module.openscrapers')
elif action == 'openscraperssettings':
	openSettings('0.0', 'script.module.openscrapers')
elif action == 'ShowChangelog':
	from openscrapers.modules import changelog
	changelog.get()
elif action == 'ShowHelp':
	from openscrapers.help import help
	help.get(name)
elif action == 'Defaults':
	sourceList = []
	sourceList = sources_openscrapers.all_providers
	setProviderDefaults()
	# for i in sourceList:
		# source_setting = f'provider.{i}'
		# value = getSettingDefault(source_setting)
		# setSetting(source_setting, value)
elif action == 'toggleAll':
	sourceList = []
	sourceList = sources_openscrapers.all_providers
	homeWindow.setProperty('openscrapers_settings', 'false')
	for i in sourceList:
		source_setting = f'provider.{i}'
		setSetting(source_setting, params['setting'])
	homeWindow.setProperty('openscrapers_settings', 'true')
elif action == 'toggleAllHosters':
	sourceList = []
	sourceList = sources_openscrapers.hoster_providers
	homeWindow.setProperty('openscrapers_settings', 'false')
	for i in sourceList:
		source_setting = f'provider.{i}'
		setSetting(source_setting, params['setting'])
	homeWindow.setProperty('openscrapers_settings', 'true')

elif action == 'toggleAllTorrent':
	sourceList = []
	sourceList = sources_openscrapers.torrent_providers
	for i in sourceList:
		source_setting = f'provider.{i}'
		setSetting(source_setting, params['setting'])
elif action == 'toggleAllPackTorrent':
	execute('RunPlugin(plugin://script.module.openscrapers/?action=toggleAllTorrent&amp;setting=false)')
	sleep(500)
	sourceList = []
	from openscrapers import pack_sources
	sourceList = pack_sources()
	for i in sourceList:
		source_setting = f'provider.{i}'
		setSetting(source_setting, params['setting'])

elif action == 'cleanSettings':
	clean_settings()
elif action == 'reset_stats':
	from openscrapers import external_scrapers_reset_stats
	external_scrapers_reset_stats()

elif action == 'undesirablesSelect':
	from openscrapers.modules.undesirables import undesirablesSelect
	undesirablesSelect()
elif action == 'undesirablesInput':
	from openscrapers.modules.undesirables import undesirablesInput
	undesirablesInput()
elif action == 'undesirablesUserRemove':
	from openscrapers.modules.undesirables import undesirablesUserRemove
	undesirablesUserRemove()
elif action == 'undesirablesUserRemoveAll':
	from openscrapers.modules.undesirables import undesirablesUserRemoveAll
	undesirablesUserRemoveAll()

elif action == 'tools_clearLogFile':
	from openscrapers.modules import log_utils
	cleared = log_utils.clear_logFile()
	if cleared == 'canceled': pass
	elif cleared: notification(message='openscrapers Log File Successfully Cleared')
	else: notification(message='Error clearing openscrapers Log File, see kodi.log for more info')
elif action == 'tools_viewLogFile':
	from openscrapers.modules import log_utils
	log_utils.view_LogFile()
elif action == 'tools_uploadLogFile':
	from openscrapers.modules import log_utils
	log_utils.upload_LogFile()

elif action == 'toggleAllPaid':
	sourceList = []
	sourceList = sources_openscrapers.all_paid_providers
	for i in sourceList:
		source_setting = f'provider.{i}'
		setSetting(source_setting, params['setting'])
	# xbmc.log('All Paid providers = %s' % sourceList,2)
	sleep(200)
	openSettings(query, "script.module.openscrapers")
elif action == 'toggleAllDebrid':
	sourceList = []
	sourceList = sources_openscrapers.debrid_providers
	for i in sourceList:
		source_setting = f'provider.{i}'
		setSetting(source_setting, params['setting'])
elif action == 'plexAuth':
	from openscrapers.modules import plex
	plex.Plex().auth()
elif action == 'plexRevoke':
	from openscrapers.modules import plex
	plex.Plex().revoke()
elif action == 'plexSelectShare':
	from openscrapers.modules import plex
	plex.Plex().get_plexshare_resource()

elif action == 'ShowOKDialog':
	okDialog(params.get('title', 'default'), int(params.get('message', '')))


elif action == 'traktAcct':
	from openscrapers.modules import trakt
	trakt.Trakt().account_info_to_dialog()
elif action == 'traktAuth':
	from openscrapers.modules import trakt
	trakt.Trakt().auth()
elif action == 'traktRevoke':
	from openscrapers.modules import trakt
	trakt.Trakt().revoke()

elif action == 'action_test_func':
	from openscrapers import action_test_func
	action_test_func()