# -*- coding: utf-8 -*-
"""
	OpenScrapers Module
"""

def main():
	from openscrapers.modules.control import monitor, setting, isVersionUpdate, clean_settings
	from openscrapers.modules.log_utils import log
	from openscrapers.modules.service_functions import SettingsMonitor, CheckSettingsFile
	while not monitor.abortRequested():
		log('[script.module.openscrapers] Main Monitor Service Started')
		CheckSettingsFile().run()
		# CheckUndesirablesDatabase().run()
		if setting('checkAddonUpdates') == 'true':
			from openscrapers.modules.service_functions import AddonCheckUpdate
			AddonCheckUpdate().run()
			# log('[script.module.opencrapers] Addon update check complete')
		if isVersionUpdate():
			clean_settings()
			log('[script.module.openscrapers] Settings file cleaned complete')
		break
	SettingsMonitor().waitForAbort()
	log('[script.module.openscrapers] Main Monitor Service Finished')

main()
