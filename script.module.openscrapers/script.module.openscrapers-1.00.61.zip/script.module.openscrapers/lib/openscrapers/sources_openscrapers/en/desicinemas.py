# -*- coding: UTF-8 -*-

from openscrapers.modules.client import agent, request
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.hindi_utils import get_source_dict, resolve_gen
from openscrapers.modules.log_utils import error, log
from openscrapers.modules.control import setting


class source:

    def __init__(self):
        self.name = 'desicinemas'
        base_link = setting(self.name)
        self.domains = list(base_link) # ['desicinemas.tv']
        self.base_link = f'https://{base_link}' # 'https://desicinemas.tv'
        self.search_link = '/?s=%s'
        self.headers = {'User-Agent': agent(), }
        # self.scraper = cfscrape.create_scraper()

    def movie(self, imdb, title, localtitle, aliases, year):
        # log(f'From: {__name__}\nimdb: {imdb}\ntitle: {title}\nlocaltitle: {localtitle}\naliases: {aliases}\nyear: {year}')
        try:
            try:
                if 'desicinemas' in aliases:
                    return aliases[0]['url']
            except: pass
            scrape = title.lower().replace(' ', '+').replace(':', '')
            url = self.base_link + self.search_link % scrape
            result = request(url, headers=self.headers)
            if not result: return
            # log(f'result: {result}')
            items = parseDOM(result, 'li', attrs={'class': r'TPostMv.*?'})
            for item in items:
                if title in item:
                    url = parseDOM(item, "a", ret="href")[0]
                    # print(f'url: {url}')
                    return url
        except:
            error(f'{__name__}_ movie: ')
        return

    def sources(self, url, hostDict):
        sources = []
        # log(f'From: {__name__} url {url}')
        try:
            if not url: return sources
            result = request(url, headers=self.headers)
            if not result: return sources
            # result = parseDOM(result, 'div', attrs={'class': 'TPMvCn'})
            items = parseDOM(result, 'div', attrs={'class': r'OptionBx on'})
            # log(f'items: {items}')
            # items = parseDOM(result, 'ul', attrs={'class': 'MovieList Rows BX B06 C20 D03 E20'})
            # log(f'items: {items}')
            final_url = []
            for item in items:
                urls = parseDOM(item, 'a', ret='href')
                # log(f'urls: {urls}')
                iurls = []
                if iurls := [iurl for iurl in urls if iurl not in iurls]: sources = get_source_dict(iurls, sources)
            return sources
        except:
            error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return resolve_gen(url)
