# -*- coding: UTF-8 -*-

import re

from openscrapers.modules.client import agent, scrapePage
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.hindi_utils import get_query, get_source_dict, resolve_gen
from openscrapers.modules.log_utils import error, log
from openscrapers.modules.control import get_domin_setting


class source:

    def __init__(self):
        self.name = 'watchapne'
        base_link = get_domin_setting(self.name)
        self.domains = base_link.split('|')
        self.base_link = f'https://{self.domains[0]}'
        self.base_link1 = f'https://{self.domains[1]}'
        self.base_link2 = f'https://{self.domains[2]}'
        
        # self.base_link = 'https://watchapne.to'
        self.referer = ''
        self.headers = {'User-Agent': agent(), }

    def movie(self, imdb, title, localtitle, aliases, year):
        # log(f'From: {__name__}\nimdb: {imdb}\ntitle: {title}\nlocaltitle: {localtitle}\naliases: {aliases}\nyear: {year}')
        try:
            query = title.replace(' ', '-').replace(':', '')
            self.headers.update({'Referer': f'{self.base_link2}/', 'Origin': self.base_link2})
            return f'{self.base_link2}/movie/{query}'
        except:
            error(f'{__name__}_ movie: ')
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f'From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year}')
        try:
            return f'{tvshowtitle}'
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f'From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}')
        try:
            # if type(tvdb) == int: return
            # if '|' not in tvdb: return
            query = get_query(url)
            # log(f'query {query} title: {title}')
            if re.search(r'indian-idol', query, re.I): query = 'Indian-Idol-Season-15'
            elif re.search(r'india-got-talent', query, re.I): query = 'Indias-Got-Talent-Season-11'
            elif re.search(r'indias-best-dancer', query, re.I): query = 'Indias-Best-Dancer-4'
            elif re.search(r'jhalak-dikhhla-jaa', query, re.I): query = 'Jhalak-Dikhhla-Jaa-Season-12'
            # elif re.search(r'masterchef-india', query, re.I): query = 'Masterchef-India-Season-7'
            if re.search(r'episode', title, re.I):
                # self.base_link = 'https://watchapne.to'
                url = f'{self.base_link}/web-series/{query}'
                self.headers.update({'Referer': f'{self.base_link}/', 'Origin': self.base_link})
                if season == 1: query = query.replace('Season-1', '').replace('season-1', '')  # re.sub(r'[Ss]eason-1', '', str(query)).strip() #
                release_title = title.strip()
            else:
                # self.base_link = 'https://apnetv.co'
                self.headers.update({'Referer': f'{self.base_link1}/', 'Origin': self.base_link1})
                url = f'{self.base_link1}/Hindi-Serial/{query}'
                release_title = re.sub(r'\d{4}', '', title).strip()  # remove year from title
            # log(f'From: {__name__} show release_title: {release_title} url {url}')
            # log(f'{__name__} episode url: {url}')
            result = scrapePage(url, headers=self.headers).text
            # log(f'{__name__} url: {url}\nself.headers: {self.headers}\nepisode result: {result}')
            if next_result := parseDOM(result, 'div', attrs={'class': 'pagination_btns'}):
                if nurl := parseDOM(next_result, "a", attrs={'class': 'prev_next_btns'}, ret="href", )[0]:
                    result += scrapePage(nurl, headers=self.headers).text
            if 'web-series' in url:
                results = parseDOM(result, 'div', attrs={'class': 's-epidode clearfix'})
                results += parseDOM(result, 'div', attrs={'class': 'web-series-grid'})
                results += parseDOM(result, 'div', attrs={'class': 'col-md-3 col-xs-6'})
            else:
                results = parseDOM(result, 'ul', attrs={'class': 'ul'})
                results = parseDOM(results, 'li')
            for item in results:
                # log(f'{__name__} episode item: {item}')
                if release_title in item:
                    # log(f'{__name__} episode item: {item}')
                    url = parseDOM(item, "a", ret="href")[0]
                    return url
        except:
            error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict):
        # log(f'From: {__name__} url {url}')
        sources = []
        try:
            if not url: return sources
            result = scrapePage(url, headers=self.headers).text
            # log(f'{__name__} sources result: {result}')
            if not result: return
            result = parseDOM(result, 'div', attrs={'class': 'bottom_episode_list'})
            items = parseDOM(result, 'li')
            # log(f'sources result: {result}\nitems: {items}')
            for item in items:
                urls = parseDOM(item, 'a', attrs={'target': '_blank'}, ret='href')
                # log(f'sources urls: {urls} item: {item}')
                final_url = []
                for iurl in urls:
                    iurl = iurl.replace('\t', '').replace(' ', '')
                    link = f'{iurl}|Referer={self.base_link}/'
                    if link not in final_url: final_url.append(link)
                if final_url: sources = get_source_dict(final_url, sources)
            if not sources: log(f'From: {__name__} no sources on url {url}')
            return sources
        except:
            error(f'{__name__}_ sources url: {url} ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return resolve_gen(url, self.headers)
