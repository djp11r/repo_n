# -*- coding: UTF-8 -*-

import os
from traceback import print_exc, print_stack
from pkgutil import walk_packages
from urllib.parse import parse_qs, urljoin, urlparse, urlencode, quote, unquote, quote_plus, unquote_plus, parse_qsl

try:
	from openscrapers.modules.control import setting, joinPath
	from openscrapers.modules.log_utils import log, error
	from openscrapers.modules import cfscrape
	from openscrapers.modules.cache import get, get_all_data, _execute, _executemany
	from openscrapers.modules.utils import make_thread_list
	cfScraper = cfscrape.create_scraper()
	debug = setting('debug.enabled') == 'true'
	provider = setting('module.provider').lower()
	testing = False
except:
	from .modules.log_utils import log, error
	__addon__ = None
	debug = True
	testing = True
	provider = 'sources_openscrapers'
	joinPath = os.path.join
	HostedMediaFile = []
# print(f'testing : {testing} provider: {provider}')
hindi_providers = ('desirulez', 'desicinemas', 'serialghar', 'watchapne', 'desiserials', 'desitelly', 'yodesi', 'playdesi')
sourceFolder = 'sources_openscrapers'


def sources(ret_all=False, media_type=None, vid_type=None, retry=0):
	try:
		# log(f'ret_all= {ret_all} media_type= {media_type} vid_type= {vid_type}')
		retry += 1
		sourceDict = []
		sourceDict_append = sourceDict.append
		sourceFolderLocation = joinPath(os.path.dirname(__file__), sourceFolder, 'en')
		# log(f'sourceFolderLocation: {sourceFolderLocation}')
		# sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
		usefull_scrapers = get(external_scrapers_fail_stats)
		# if debug and usefull_scrapers: log(f'total: {len(usefull_scrapers)} >> usefull_scrapers: {usefull_scrapers}')
		not_usefull = []
		not_usefull_append = not_usefull.append
		for loader, module_name, is_pkg in walk_packages([sourceFolderLocation]):
			if is_pkg: continue
			if not ret_all and not enabledCheck(module_name): continue
			if vid_type and media_type == 'episode' and module_name not in hindi_providers: continue
			elif not vid_type and module_name in hindi_providers: continue
			if not ret_all and usefull_scrapers and module_name not in usefull_scrapers: not_usefull_append(module_name); continue
			# log(f'media_type: {media_type} module_name: {module_name} is_pkg: {is_pkg} loader: {loader} ')
			try: module = loader.find_spec(module_name).loader.load_module(module_name) #may be using in future
			except:
				log(f'Error: loader.find_spec: "{module_name}": {print_stack(limit=15)}')
				try: module = loader.find_module(module_name).load_module(module_name)
				except: log(f'Error: loader.find_module: "{module_name}": {print_stack(limit=15)}'); not_usefull_append(module_name) ; continue
			module_source = module.source()
			try:
				if media_type == 'episode' and getattr(module_source, 'tvshow'): sourceDict_append((module_name, module_source))
				elif media_type == 'movie' and getattr(module_source, 'movie'): sourceDict_append((module_name, module_source))
				else: sourceDict_append((module_name, module_source))
			except: not_usefull_append(module_name)
		if debug and sourceDict and usefull_scrapers: log(f'retry: {retry} using Providers: {len(sourceDict)}|{len(usefull_scrapers)} for media_type: {media_type}')# not usefull Providers: {len(not_usefull)}')
		#log(f'not_usefull: {not_usefull}')
		if retry > 1: return sourceDict
		elif not sourceDict: sources(True, media_type, vid_type, retry)
		return sourceDict
	except Exception as e:
		log(f'Error: sources: {e} {print_stack(limit=15)}')
		return []

def enabledCheck(module_name):
	try: return setting(f'provider.{module_name}') == 'true'
	except: return True


def pack_sources(sourceSubFolder='torrents'):
	return []

def getScraperFolder():
	try:
		sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
		sourceSubFolders = [x for x in sourceSubFolders if x not in ['__pycache__', 'help', 'modules', 'cfscrape', 'pyaes']]
		return [i for i in sourceSubFolders if 'openscrapers' in i.lower()][0]
	except:
		error('getScraperFolder: ')
		return 'sources_openscrapers'

def providerSources():
	sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
	return getModuleName(sourceSubFolders)


def providerNames():
	providerList = []
	append = providerList.append
	# provider = setting('module.provider')
	sourceFolder = getScraperFolder()
	sourceFolderLocation = joinPath(os.path.dirname(__file__), sourceFolder)
	sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
	for i in sourceSubFolders:
		for loader, module_name, is_pkg in walk_packages([joinPath(sourceFolderLocation, i)]):
			if is_pkg: continue
			correctName = module_name.split('_')[0]
			append(correctName)
	return providerList


def getAllHosters():
	def _sources(sourceFolder, append):
		sourceFolderLocation = os.path.join(os.path.dirname(__file__), sourceFolder)
		sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
		for i in sourceSubFolders:
			for loader, module_name, is_pkg in walk_packages([os.path.join(sourceFolderLocation, i)]):
				if is_pkg: continue
				try: mn = str(module_name).split('_')[0]
				except: mn = str(module_name)
				append(mn)
	sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
	appendList = []
	append = appendList.append
	for item in sourceSubFolders:
		if item not in ['__pycache__', 'modules', 'cfscrape', 'pyaes']:
			_sources(item, append)
	return list(set(appendList))


def getModuleName(scraper_folders):
	nameList = []
	append = nameList.append
	for s in scraper_folders:
		if s not in ['__pycache__', 'modules', 'cfscrape', 'pyaes']:
			try: append(s.split('_')[1].lower().title())
			except: pass
	return nameList


def custom_base_link(scraper):
	try:
		url = setting(f'url.{scraper}')
		url = url[:-1] if url and url.startswith('http') else None
	except:
		url = None
	return url



def getapi_keys():
	from random import choice
	api_keys = {'api_keys': {}}
	api_keys['api_keys']['trakt.client'] = setting('trakt.client') or '1038ef327e86e7f6d39d80d2eb5479bff66dd8394e813c5e0e387af0f84d89fb'
	api_keys['api_keys']['trakt.secret'] = setting('trakt.secret') or '8d27a92e1d17334dae4a0590083a4f26401cb8f721f477a79fd3f218f8534fd1'
	api_keys['api_keys']['fanart'] = setting('fanart') or 'cf3429b06e1bbccc9d1e1b86b32fc51a'
	api_keys['api_keys']['tmdb'] = setting('tmdb') or '05a454b451f2f9003fbca293744e4a85'
	api_keys['api_keys']['tmdb.user'] = setting('tmdb.user') or 'aaaas'
	api_keys['api_keys']['tmdb.pw'] = setting('tmdb.pw') or '6666'
	api_keys['api_keys']['opensubs.user'] = setting('opensubs.user') or 'aaaajjjj0'
	api_keys['api_keys']['opensubs.pw'] = setting('opensubs.pw') or '6666Mill_'
	api_keys['api_keys']['imdbuser'] = setting('imdbuser') or '56044779'
	api_keys['api_keys']['mdblist'] = setting('mdblist') or 'osscknixflg2dogpr271ujz18'
	api_keys['api_keys']['simkltoken'] = setting('simkltoken') or '110460fa96e0cb8c6a4768de14983374376090247ba4a55fb55ac66c26e3b732'
	# api_keys['api_keys']['filepursuittoken'] = setting('filepursuit.api') or 'e1235ccc65msh9c6da42a2ff1797p199cefjsnaa4033afc078'
	# api_keys['api_keys']['gdrivetoken'] = setting('gdrive.cloudflare_url') or choice(['https://gd.djp97s.workers.dev', 'https://wandering-river-0edc.rrosajp4.workers.dev'])
	api_keys['api_keys']['tvdb'] = setting('tvdb') or choice(['06cff30690f9b9622957044f2159ffae', '1D62F2F90030C444', '7R8SZZX90UA9YMBU'])
	return api_keys


def get_h_urls():
	h_urls = {'h_urls': {}}
	h_urls['h_urls']['desicinemas'] = setting('desicinemas')
	h_urls['h_urls']['desirulez'] = setting('desirulez')
	h_urls['h_urls']['desiserials'] = setting('desiserials')
	h_urls['h_urls']['playdesi'] = setting('playdesi')
	h_urls['h_urls']['yodesi'] = setting('yodesi')
	return h_urls #dict(h_urls, **getapi_keys())

def get_creden():
	trakt = {'trakt': {}}
	trakt['trakt']['token'] = setting('trakt.token')
	trakt['trakt']['user'] = setting('trakt.user')
	trakt['trakt']['refresh'] = setting('trakt.refresh')
	trakt['trakt']['expires'] = setting('trakt.expires')
	return dict(trakt, **getapi_keys(), **get_h_urls())


## from infinite


def check_hosted_media(vid_url):
	from resolveurl import HostedMediaFile
	hmf = HostedMediaFile(url=vid_url, include_disabled=True, include_universal=False)
	if hmf.valid_url() is True:
		if rpart := hmf.resolve(): return rpart
	return


def get_hosts():
	def make_hostlist():
		from functools import reduce
		try:
			from resolveurl import relevant_resolvers
			pr_list = relevant_resolvers(order_matters=True)
			pr_list = [i.domains for i in pr_list if '*' not in i.domains]
			pr_list = [i.lower() for i in reduce(lambda x, y: x+y, pr_list)]
			pr_list = [x for y, x in enumerate(pr_list) if x not in pr_list[:y]]
		except: pr_list = []
		# log(f'make_hostlist pr_list {len(pr_list)} {pr_list}')
		return list(set(pr_list))
	return get(make_hostlist)


try: hosts_list = get_hosts()
except: hosts_list = []

def get_provider():
	try:
		scraper_stats = get_all_data('prov_perf')
		scraper_stats.sort(key=lambda a: a[1], reverse=True)
		return [str(i[0]) for i in scraper_stats if i[1] >= 2]
	except: return ['gdrive', 'filemoon', 'streamtape', 'trade', 'bestarticles', 'tellygossips', 'filelions', 'furher', 'youtube', 'eplayvid', 'cdn4', 'doodstream', 'streamwish', 'tvarticles', 'Folder 2']


def external_scrapers_fail_stats():
	threshold = int(setting('failing_scrapers.threshold', 0))
	data = get_all_data()
	# log(f'data: {repr(data)}')
	# results = sorted([(str(i[0]), i[1], i[2]) for i in results], key=lambda k: k[2] - k[1], reverse=False)
	# results = sorted([(str(i.get('source')), i.get('success'), i.get('failure')) for i in data], key=lambda k: k[2] - k[1], reverse=False)
	# results = sorted([(str(i.get('source')), i.get('success'), i.get('failure')) for i in data if i.get('success') >= threshold], key=lambda k: k[2] - k[1], reverse=False)
	try: results = [i[0] for i in data if i[1] >= threshold or i[1] >= 1]
	except: results = [i[0] for i in data]
	return results


def sourcesstats(sourcedict, sources):
	try:
		insert_list = []
		all_sources = [i[0] for i in sourcedict if all(x not in i[0] for x in ('season', 'show'))]
		working_scrapers = sorted(list({i['provider_site'] for i in sources}))
		non_working_scrapers = sorted([i for i in all_sources if i not in working_scrapers])
		scraper_stats = get_all_data()
		if scraper_stats:
			for i in scraper_stats:
				try:
					scraper, success, fail = str(i[0]), i[1], i[2]
					if scraper in working_scrapers:
						insert_list.append((scraper, success + 1, fail))
						working_scrapers.remove(scraper)
					else:
						insert_list.append((scraper, success, fail + 1))
						non_working_scrapers.remove(scraper)
				except: pass
		if len(working_scrapers) > 0: insert_list.extend((scraper, 1, 0) for scraper in working_scrapers)
		if len(non_working_scrapers) > 0: insert_list.extend((scraper, 0, 1) for scraper in non_working_scrapers)
		# log(f'sourcesstats insert_list: {insert_list}')
		if insert_list: _executemany("INSERT OR REPLACE INTO scr_perf VALUES (?, ?, ?)", insert_list)
	except: error(f'sourcesstats Error: {print_exc()}')


def external_scrapers_reset_stats():
	try:
		def reset_data(scraper_stats, _from):
			insert_list = []
			for i in scraper_stats:
				i1 = i2 = 1
				try:
					half_value = i[1] // 2
					if i[1] > 1: i1 = 1 if half_value < 2 else half_value
					#if i[2] > 1: i2 = 1 if half_value < 2 else i[2] - half_value
				except: pass
				insert_list.append((i[0], i1, i2))
			log(f'{_from} insert_list: {insert_list}')
			return insert_list
		_execute("DELETE FROM scr_perf WHERE success IS NULL OR success = '0'", ())
		if scraper_stats := get_all_data():
			insert_list = reset_data(scraper_stats, 'scr_perf')
			if insert_list: _executemany("INSERT OR REPLACE INTO scr_perf VALUES (?, ?, ?)", insert_list)
		if scraper_stats := get_all_data('prov_perf'):
			insert_list = reset_data(scraper_stats, 'prov_perf')
			if insert_list: _executemany("INSERT OR REPLACE INTO prov_perf VALUES (?, ?, ?)", insert_list)
		return True
	except:
		error(f'external_scrapers_reset_stats Error: {print_exc()}')
		return False


def providerstats(info):
	try:
		insert_list = []
		working_source = str(info).split('.')[0]
		if working_source in ('www', 'Folder'): return
		c_data = _execute("SELECT success FROM prov_perf WHERE source = ?", (working_source,)).fetchone()
		if c_data: insert_list.append((working_source, c_data[0] + 1, 1))
		else: insert_list.append((working_source, 1, 1))
		# log(f'{info} insert_list: {insert_list}')
		if insert_list: _executemany("INSERT OR REPLACE INTO prov_perf VALUES (?, ?, ?)", insert_list)
	except: error(f'providerstats Error: {print_exc()}')



def action_test_func():
	try:
		from openscrapers.modules.opensubs import Opensubs
		from openscrapers.modules.control import temppath
		imdb_id = 'tt6470478'
		query = 'The Good Doctor'
		language = 'en'
		season = 6
		episode = 10
		data = Opensubs().getSubs(query, imdb_id, season, episode)
		if data: log(f'total: {len(data)} data: {data}')
		# insert_list = [('desiserials', 7, 1), ('serialghar', 2, 1), ('yodesi', 13, 1), ('desirulez', 7, 1), ('123moviestv_me', 13, 1), ('cinebox_cc', 13, 1), ('databasegdriveplayer_co', 7, 1), ('gowatchseries_ch', 2, 1), ('vumoo_to', 1, 1), ('dopebox_to', 13, 1), ('gdriveplayer_us', 5, 1), ('goku_to', 1, 1), ('myflixer_it', 11, 1), ('watchserieshd_stream', 7, 1), ('winnoise_com', 10, 1), ('couchtuner_show', 5, 1), ('0123movies_ch', 1, 1), ('123movies_skin', 1, 1), ('bstsrs_one', 8, 1), ('desitelly', 7, 1), ('hindilinks4u', 1, 1), ('tvseries_video', 6, 1), ('yomovies_bio', 1, 1), ('ytube', 1, 1), ('gdrive', 8, 1), ('c1ne_co', 1, 1), ('filepursuit', 10, 1), ('putlocker_to', 1, 1), ('soap2day_fan', 1, 1), ('f123movies_com', 1, 1), ('cinecalidad_vet', 1, 1), ('noxx_to', 3, 1), ('1movies_la', 5, 1), ('himovies_top', 12, 1), ('primewire_mx', 2, 1), ('desicinemas', 2, 1), ('upmovies_to', 1, 1), ('series9movies_com', 1, 1), ('movies2watch_tv', 12, 1), ('watchapne', 2, 1), ('lordhd_one', 1, 1), ('iwaatch_com', 1, 1), ('anymovies_co', 2, 1), ('filmxy_pw', 1, 1), ('doomovies_ga', 1, 1), ('movierulz', 1, 1), ('gomovies_sx', 10, 1), ('upmovies_net', 1, 1), ('vumoo_mx', 1, 1), ('levidia_ch', 4, 1), ('flixhq_to', 1, 1), ('projectfreetv_lol', 1, 1), ('tinyzonetv_to', 1, 1)]
		# if insert_list: _executemany("INSERT OR REPLACE INTO scr_perf VALUES (?, ?, ?)", insert_list)
		# insert_list = [('embedwish', 1, 1), ('wishfast', 1, 1), ('ds2play', 1, 1), ('vidoza', 1, 1), ('vidmoly', 1, 1), ('streamvid', 1, 1), ('mdbekjwqa', 1, 1), ('obeywish', 1, 1), ('server4', 1, 1), ('mwish', 1, 1), ('doods', 1, 1), ('2embed', 1, 1), ('vtube', 1, 1), ('youdbox', 1, 1), ('tvpost', 1, 1), ('meomeo', 1, 1), ('upstream', 1, 1), ('bollyfunmaza', 1, 1), ('cdnwish', 1, 1), ('mlions', 1, 1), ('d0000d', 1, 1), ('dood', 1, 1), ('movie', 1, 1), ('tellygossips', 2, 1), ('exandnext', 1, 1), ('vidhidepre', 1, 1), ('filelions', 2, 1), ('insurancehubportal', 1, 1), ('furher', 2, 1), ('youtube', 2, 1), ('eplayvid', 2, 1), ('cdn4', 2, 1), ('doodstream', 2, 1), ('streamtape', 3, 1), ('streamwish', 2, 1), ('vidhidevip', 1, 1), ('filemoon', 4, 1), ('credits', 1, 1), ('tvarticles', 2, 1), ('gdrive', 5, 1), ('trade', 3, 1), ('Folder 2', 2, 1), ('bestarticles', 6, 1)]
		# if insert_list: _executemany("INSERT OR REPLACE INTO prov_perf VALUES (?, ?, ?)", insert_list)
		return True
	except:
		error(f'action_test_func Error: {print_exc()}')
		return False
