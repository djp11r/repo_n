# -*- coding: utf-8 -*-

from random import choice

import requests
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.utils import get_datetime
API_URL = 'https://api.themoviedb.org/3/'
ART_URL = 'https://image.tmdb.org/t/p/original'
HEADERS = {'Content-Type': 'application/json;charset=utf-8'}
API_KEY = 'c8b7db701bac0b26edfcc93b39858972'
empty_value_check, trailers_check = ('', 'None', None), ('Trailer', 'Teaser')
youtube_url = 'plugin://plugin.video.youtube/play/?video_id=%s'


def find_movie_by_external_source(imdb):
    try:
        url = f'{API_URL}find/{imdb}?api_key={API_KEY}&language=en-US&external_source=imdb_id'
        result = requests.get(url, headers=HEADERS).json()
        return result['movie_results'][0]
    except Exception as err:
        error(f'find_movie_by_external_source: {err}')
        return


def find_tvshow_by_external_source(imdb=None, tvdb=None):
    try:
        if imdb: url = f'{API_URL}find/{imdb}?api_key={API_KEY}&language=en-US&external_source=imdb_id'
        elif tvdb: url = f'{API_URL}find/{tvdb}?api_key={API_KEY}&language=en-US&external_source=tvdb_id'
        result = requests.get(url, headers=HEADERS).json()
        return result['tv_results'][0]
    except Exception as err:
        error(f'find_tvshow_by_external_source: {err}')
        return


def clean_title_to_comparisons(string):
    """
        Method that takes a string and returns it cleaned of any special characters in order to do proper string comparisons
    """
    try: return ''.join(e for e in string.lower() if e.isalnum())
    except: return string


def clean_title_to_search(title):
    ftitle = ''
    for word in title.split(' '):
        if word.isalnum() is False:
            w = ""
            for i in range(len(word)):
                if word[i].isalnum():
                    w += word[i]
            word = w
        ftitle += ' ' + word
    return ftitle.strip()


def get_query(title):
    title = title.lower()
    if 'superstar singer' in title: return 'superstar singer'
    elif 'dance deewane' in title: return 'dance deewane'
    elif 'india got talent' in title: return 'india got talent'
    elif 'jhalak dikhhla jaa' in title: return 'jhalak dikhhla jaa'
    elif 'crime patrol' in title: return 'crime patrol'
    elif 'indias best dancer' in title: return 'indias best dancer'
    elif 'kaun banega crorepati' in title: return 'kaun banega crorepati'
    elif 'bigg boss ott' in title: return 'bigg boss ott'
    elif 'bigg boss' in title: return 'bigg boss'
    elif 'indian idol' in title: return 'indian idol'
    elif 'the kapil sharma show' in title: return 'the kapil sharma show'
    return title


def _do_tmdb_request(values, method='search/multi', lang='en'):
    api_key = choice(['8877595a1e6647d272148c99133df1fb', 'bc96b19479c7db6c8ae805744d0bdfe2', 'b370b60447737762ca38457bd77579b3', 'edde6b5e41246ab79a2697cd125e1781', 'c8b7db701bac0b26edfcc93b39858972', 'af3a53eb387d57fc935e9128468b1899']) # 6a5be4999abf74eba1f9a8311294c267
    url = f'http://api.themoviedb.org/3/{method}?language={lang}&api_key={api_key}&{values}'
    try: response = requests.get(url, headers=HEADERS, timeout=20)
    except: response = None
    data = response.json()
    # log(f'from method: {method} values: {values} url: {url}\ndata: {data}')
    return data


def tmdb_search(query, season=1, only_tmbdid=True):
    """
    :param query:
    :return: dict for meta
    """

    query_part = query.split('|')
    if query_part[1].isdigit(): title, year, media_type, runtime = query_part[0], query_part[1], 'movie', 120
    else: title, year, media_type, runtime = query_part[1], None, 'tvshow', 30
    name = get_query(title)
    tmdb_id = None
    if year: name = name + '&year=' + year
    else: name, year = name, str(get_datetime().year)
    # log(f'name: {name} title: {title} year: {year}')
    meta = _do_tmdb_request('query=' + name, 'search/multi')
    data_get = meta.get
    if meta and data_get('total_results') == 1 and data_get('results'):
        tmdb_id = data_get('results')[0].get('id')
        media_type = data_get('results')[0].get('media_type')
    elif meta and data_get('total_results') > 1 and data_get('results'):
        results = [r for r in data_get('results') if (r.get('title') and clean_title_to_comparisons(r.get('title').lower()) in clean_title_to_comparisons(name.lower())) and r.get('release_date', '0000')[:4] == year]
        if not results: results = [r for r in data_get('results') if (r.get('name') and clean_title_to_comparisons(r.get('name').lower()) in clean_title_to_comparisons(name.lower()))]
        if len(results) > 1:
            fresults = [r for r in results if r.get('original_language') != 'en']
            if len(fresults) > 0:
                tmdb_id = fresults[0].get('id')
                media_type = fresults[0].get('media_type')
            else:
                tmdb_id = results[0].get('id')
                media_type = results[0].get('media_type')
        elif len(results) == 1:
            tmdb_id = results[0].get('id')
            media_type = results[0].get('media_type')
    # log(f'{repr(tmdb_id)}, {repr(media_type)}, {repr(title)}, {repr(query)}, {repr(year)}, {repr(season)}, {repr(runtime)}')
    if only_tmbdid: return tmdb_id
    else: return get_meta_tmbd(tmdb_id, media_type, title, query, year, season, runtime)


def get_meta_tmbd(tmdb_id, media_type, title, query, year, season, runtime):
    md = None
    if tmdb_id:
        tmdb_image_url = 'https://image.tmdb.org/t/p/'
        # Attempt to grab all info in one request
        extra_append = 'append_to_response=casts,trailers,external_ids,videos,credits,content_ratings,release_dates,alternative_titles,translations,images'
        meta = _do_tmdb_request(extra_append, f'{media_type}/{tmdb_id}')
        # log(f'meta: {meta}')
        if meta is not None: # Parse out extra info from request
            data_get = meta.get
            cast, writer, director, studio, trailer, all_trailers, country, country_codes, alternative_titles = [], [], [], [], [], [], [], [], []
            mpaa, spoken_language = 'NR', ''
            title = title.title()
            # if not data_get('title'): title = title.title()
            # else: title = data_get('title')
            if production_countries := data_get('production_countries'):
                country = [i['name'] for i in production_countries]
                country_codes = [i['iso_3166_1'] for i in production_countries]
            if spoken_languages := data_get('spoken_languages'):
                try: spoken_language = spoken_languages[0]['english_name']
                except: pass
            if companies := data_get('networks') or data_get('production_companies'):
                if len(companies) == 1: studio = ([i['name'] for i in companies][0],)
                else:
                    try: studio = (next(i['name'] for i in companies if i['logo_path'] not in empty_value_check) or next(i['name'] for i in companies),)
                    except: pass
            if alternative_titles := data_get('alternative_titles'):
                alternatives = alternative_titles.get('titles') or alternative_titles.get('results') or []
                alternative_titles = [i['title'] for i in alternatives if i['iso_3166_1'] in ('US', 'GB', 'UK', 'IN', '')] if alternatives else []

            premiered = data_get('release_date') or data_get('first_air_date')
            media_type = 'tvshow' if media_type != 'movie' else 'movie'
            md = {'tmdb_id': str(data_get('id')), 'tvdb_id': query,
                'title': title, 'tagline': data_get('tagline'), 'mediatype': media_type,
                'plot': data_get('overview'), 'country': country,
                'studio': studio, 'mpaa': mpaa, 'rating': data_get('vote_average'),
                'votes': data_get('vote_count'), 'premiered': premiered,
                'duration': runtime * 60, 'year': year, 'alternative_titles': alternative_titles, 'country_codes': country_codes, 'spoken_language': spoken_language,
                'genre': [], 'cast': [], 'director': [], 'writer': [], 'trailer': [], 'all_trailers': []}

            iddata = data_get('external_ids')
            imdb_id = iddata.get('imdb_id') if iddata else query
            md.update({'imdb_id': imdb_id, 'imdbnumber': imdb_id, })
            if premiered: md.update({'year': str(premiered[:4])})
            if data_get('runtime'): md.update({'duration': data_get('runtime') * 60})
            if data_get('episode_run_time'): md.update({'duration': data_get('episode_run_time')[0] * 60})

            if casts := data_get('casts') or data_get('credits'):
                if casts.get('cast'):
                    cast = [{'name': x.get('name') or 'none', 'role': x.get('character'), 'thumbnail': f'{tmdb_image_url}w138_and_h175_face{x.get("profile_path")}'} for x in casts['cast']]
                    md.update({'cast': cast[:10]})
                if crew := casts.get('crew'):
                    try: writer = [i['name'] for i in crew if i['job'] in ('Author', 'Writer', 'Screenplay', 'Characters')]
                    except: pass
                    try: director = [i['name'] for i in crew if i['job'] == 'Director']
                    except: pass
                    md.update({'director': director, 'writer': writer})

            if genres := data_get('genres'):
                genre = [x.get('name') for x in genres]
                md.update({'genre': genre})

            if trailers := data_get('videos') or data_get('trailers'):
                all_trailers = trailers.get('results') or trailers.get('youtube') or []
                try: trailer = [youtube_url % i['key'] for i in all_trailers if i['site'] == 'YouTube' and i['type'] in trailers_check][0]
                except: pass
                md.update({'trailer': trailer, 'all_trailers': all_trailers})

            if poster_path := data_get('poster_path'): md.update({'poster': f'{tmdb_image_url}w500{poster_path}'})
            if backdrop_path := data_get('backdrop_path'): md.update({'fanart': f'{tmdb_image_url}w1280{backdrop_path}'})
            if media_type == 'movie': md['extra_info'] = {'status': data_get('status'), 'budget': data_get('budget') or '$0', 'revenue': data_get('revenue') or '$0', 'homepage': data_get('homepage'), 'collection_name': data_get('collection_name'), 'collection_id': data_get('collection_id')}
            else:
                season_n = data_get('number_of_seasons') or data_get('seasons')
                # log(f'season_n: {season_n}')
                if not season_n: season_n = 1
                if isinstance(season_n, list): season_n = len(season_n)
                if season_n > season: season = season_n
                created_by = data_get('created_by', None)
                try: ei_created_by = ', '.join([i['name'] for i in created_by])
                except: ei_created_by = 'N/A'
                extra_info = {'status': data_get('status'), 'homepage': data_get('homepage'), 'created_by': ei_created_by, 'type': data_get('type'), 'last_episode_to_air': data_get('last_episode_to_air'), 'next_episode_to_air': data_get('next_episode_to_air')}
                md.update({'tvshowtitle': title, 'seasons': season_n, 'season': season, 'extra_info': extra_info, 'season_data': data_get('seasons') or [], 'total_aired_eps': data_get('number_of_episodes') or 1})
        # log(f'md: {md}')
    return md