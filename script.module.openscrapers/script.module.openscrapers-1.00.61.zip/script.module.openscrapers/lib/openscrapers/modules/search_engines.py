# -*- coding: utf-8 -*-

import re
import requests

from openscrapers.modules import client
from openscrapers.modules import client_utils
from openscrapers.modules import cleantitle
from openscrapers.modules import log_utils

DOM = client_utils.parseDOM
CLEAN = client_utils.remove_codes


def bing(search_query, parse=False):
    try:
        if not search_query:
            return
        search_headers = {'User-Agent': client.UserAgent, 'Referer': 'https://www.bing.com'}
        search_url = f'https://www.bing.com/search?q={search_query}'
        #log_utils.log('bing search_url: \n' + repr(search_url))
        search_html = client.request(search_url, headers=search_headers)
        #log_utils.log('bing search_html: \n' + repr(search_html))
        if parse:
            results = DOM(search_html, 'li', attrs={'class': 'b_algo'})
            results = [(DOM(i, 'cite'), DOM(i, 'h2')) for i in results]
            results = [(i[0][0], i[1][0]) for i in results if len(i[0]) > 0 and len(i[1]) > 0]
            # log_utils.log(f'bing results: {repr(results)}')
            return [(CLEAN(i[0]), CLEAN(i[1]),) for i in results if len(i[0]) > 0 and len(i[1]) > 0]
        return search_html
    except Exception as e:
        log_utils.error(f'bing: {e}', 1)
        return


def duckduckgo(search_query):
    try:
        if not search_query:
            return
        search_data = {'q': search_query}
        search_headers = {'User-Agent': client.UserAgent, 'Referer': 'https://duckduckgo.com'}
        #https://lite.duckduckgo.com/lite
        search_url = 'https://html.duckduckgo.com/html/'
        return requests.post(search_url, headers=search_headers, data=search_data, verify=False).content
    except:
        log_utils.error('duckduckgo', 1)
        return


def ecosia(search_query, parse=False):
    try:
        if not search_query:
            return
        search_headers = {'User-Agent': client.UserAgent, 'Referer': 'https://www.ecosia.org'}
        search_url = 'https://www.ecosia.org/search?q=%s' % search_query
        #log_utils.log('ecosia search_url: \n' + repr(search_url))
        search_html = client.scrapePage(search_url, headers=search_headers).text
        #log_utils.log('ecosia search_html: \n' + repr(search_html))
        if parse:
            results = DOM(search_html, 'div', attrs={'class': 'result__title'})
            results = [(DOM(i, 'a', ret='href'), DOM(i, 'h2', attrs={'class': 'result-title__heading'})) for i in results]
            results = [(i[0][0], i[1][0]) for i in results if len(i[0]) > 0 and len(i[1]) > 0]
            results = [(CLEAN(i[0]), CLEAN(i[1])) for i in results]
            #log_utils.log('ecosia results: \n' + repr(results))
            return results
        return search_html
    except:
        log_utils.log('ecosia', 1)
        return


def google(search_query):
    try:
        if not search_query:
            return
        search_headers = {'User-Agent': client.UserAgent, 'Referer': 'https://www.google.com'}
        search_url = f'https://www.google.com/search?q={search_query}'
        return client.scrapePage(search_url, headers=search_headers).text
    except:
        log_utils.error('google', 1)
        return


def startpage(search_query):
    try:
        if not search_query:
            return
        search_headers = {'User-Agent': client.UserAgent, 'Referer': 'https://www.startpage.com'}
        #https://www.startpage.com/sp/search
        search_url = f'https://www.startpage.com/do/search?q={search_query}'
        return client.scrapePage(search_url, headers=search_headers).text
    except:
        log_utils.error('startpage', 1)
        return


def swisscows(search_query):
    try:
        if not search_query:
            return
        search_headers = {'User-Agent': client.UserAgent, 'Referer': 'https://swisscows.com'}
        search_url = f'https://swisscows.com/en/web?query={search_query}'
        return client.scrapePage(search_url, headers=search_headers).text
    except:
        log_utils.error('swisscows', 1)
        return


def yahoo(search_query):
    try:
        if not search_query:
            return
        search_headers = {'User-Agent': client.UserAgent, 'Referer': 'https://search.yahoo.com'}
        search_url = f'https://search.yahoo.com/search?p={search_query}'
        return client.scrapePage(search_url, headers=search_headers).text
    except:
        log_utils.error('yahoo', 1)
        return


def yandex(search_query):
    try:
        if not search_query:
            return
        search_headers = {'User-Agent': client.UserAgent, 'Referer': 'https://yandex.com'}
        search_url = 'https://yandex.com/search/?text=%s' % search_query
        #log_utils.log('yandex search_url: \n' + repr(search_url))
        search_html = client.scrapePage(search_url, headers=search_headers).text
        #log_utils.log('yandex search_html: \n' + repr(search_html))
        return search_html
    except:
        log_utils.log('yandex', 1)
        return

def make_search_query(domain, title, imdb=None, year=None, season=None, episode=None, domainprefix='&sites='):
    try:
        if not domain:
            return
        search_title = imdb if imdb is not None else cleantitle.get_plus(title)
        search_term = f'{search_title}+{year}' if year is not None else search_title
        if (season and episode) is not None:
            season = f'{int(season):02d}'
            episode = f'{int(episode):02d}'
            return f'{search_term}+s{season}e{episode}+{domainprefix}{domain}'
        elif season is not None:
            season = f'{int(season):02d}'
            return f'{search_term}+Season+{season}+{domainprefix}{domain}'
        else:
            return f'{search_term}+{domainprefix}{domain}'
    except:
        log_utils.error('make_search_query', 1)
        return


