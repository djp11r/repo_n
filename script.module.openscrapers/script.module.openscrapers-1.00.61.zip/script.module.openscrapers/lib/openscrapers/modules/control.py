# -*- coding: utf-8 -*-
"""
	OpenScrapers Module
"""
import sys
from traceback import print_exc
from json import dumps as jsdumps, loads as jsloads
import os.path

from sys import argv

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
from xml.dom.minidom import parse as mdParse
#import xml.etree.ElementTree as ET #python 3.11 bug screws element tree. everything changed was left commented out.

def getKodiVersion():
	return int(xbmc.getInfoLabel("System.BuildVersion")[:2])

addon = xbmcaddon.Addon
addonObject = addon('script.module.openscrapers')
addonInfo = addonObject.getAddonInfo
getLangString = addonObject.getLocalizedString
condVisibility = xbmc.getCondVisibility
infoLabel = xbmc.getInfoLabel
execute = xbmc.executebuiltin
jsonrpc = xbmc.executeJSONRPC
keyboard = xbmc.Keyboard
log = xbmc.log
monitor_class = xbmc.Monitor
monitor = xbmc.Monitor()
xbmc_player = xbmc.Player

isfilePath = os.path.isfile
# dialog = xbmcgui.Dialog()
homeWindow = xbmcgui.Window(10000)
progressDialog = xbmcgui.DialogProgress()
progress_line = '%s[CR]%s[CR]%s'
deleteDir = xbmcvfs.rmdir
deleteFile = xbmcvfs.delete
existsPath = xbmcvfs.exists
legalFilename = xbmcvfs.makeLegalFilename
listDir = xbmcvfs.listdir
makeFile = xbmcvfs.mkdir
makeDirs = xbmcvfs.mkdirs
openFile = xbmcvfs.File
renameFile = xbmcvfs.rename
translate_path = xbmcvfs.translatePath
joinPath = os.path.join
isfilePath = os.path.isfile
absPath = os.path.abspath

addon_settings = translate_path(joinPath(addonInfo('path'), 'resources', 'settings.xml'))
dataPath = translate_path(addonInfo('profile'))
cacheFile = translate_path(joinPath(dataPath, 'cache.db'))
undesirablescacheFile = joinPath(dataPath, 'undesirables.db')
user_settings = joinPath(dataPath, 'settings.xml')
temppath = translate_path('special://temp')
plexSharesFile = ''

def kodi_dialog():
	return xbmcgui.Dialog()

def get_addon_version():
	return addonInfo('version')

def setting(id, fallback=None):
	try: settings_dict = jsloads(homeWindow.getProperty('openscrapers_settings'))
	except: settings_dict = make_settings_dict()
	if settings_dict is None: settings_dict = settings_fallback(id)
	value = settings_dict.get(id, '')
	if fallback is None: return value
	if value == '': return fallback
	return value

def settings_fallback(id):
	return {id: addonObject.getSetting(id)}

def setSetting(id, value):
	return addonObject.setSetting(id, value)

def make_settings_dict(): # service runs upon a setting change
	try:
		#root = ET.parse(user_settings).getroot()
		root = mdParse(user_settings) #minidom instead of element tree
		curSettings = root.getElementsByTagName("setting") #minidom instead of element tree
		settings_dict = {}
		for item in curSettings:
			dict_item = {}
			#setting_id = item.get('id')
			setting_id = item.getAttribute('id') #minidom instead of element tree
			#setting_value = item.text
			try:
				setting_value = item.firstChild.data #minidom instead of element tree
			except:
				setting_value = None
			if setting_value is None: setting_value = ''
			dict_item = {setting_id: setting_value}
			settings_dict.update(dict_item)
		homeWindow.setProperty('openscrapers_settings', jsdumps(settings_dict))
		return settings_dict
	except:
		print(f'error: {print_exc()}')
		return None

def refresh_debugReversed(): # called from service "onSettingsChanged" to clear openscrapers.log if setting to reverse has been changed
	if homeWindow.getProperty('openscrapers.debug.reversed') != setting('debug.reversed'):
		homeWindow.setProperty('openscrapers.debug.reversed', setting('debug.reversed'))
		execute('RunPlugin(plugin://script.module.openscrapers/?action=tools_clearLogFile)')

def lang(language_id):
	return getLangString(language_id)

def sleep(time):  # Modified `sleep`(in milli secs) command that honors a user exit request
	while time > 0 and not monitor.abortRequested():
		xbmc.sleep(min(100, time))
		time -= 100

def isVersionUpdate():
	versionFile = joinPath(dataPath, 'installed.version')
	try:
		if not xbmcvfs.exists(versionFile):
			f = open(versionFile, 'w')
			f.close()
	except:
		log('OpenScrapers Addon Data Path Does not Exist. Creating Folder....', 1)
		addon_folder = translate_path('special://profile/addon_data/script.module.openscrapers')
		if not existsPath(addon_folder): makeDirs(addon_folder)
	try:
		with open(versionFile, 'r') as fh: oldVersion = fh.read()
	except: oldVersion = '0'
	try:
		curVersion = addonInfo('version')
		if oldVersion != curVersion:
			with open(versionFile, 'w') as fh: fh.write(curVersion)
			return True
		else: return False
	except Exception as e:
		log(f'{e}', 1)
		return False

def clean_settings():
	def _make_content(dict_object):
		content = '<settings version="2">'
		new_line = '\n    '
		for item in dict_object:
			_id = item['id']
			if _id in active_settings:
				if 'default' in item and 'value' in item: content += f'{new_line}<setting id="{_id}" default="{item["default"]}">{item["value"]}</setting>'
				elif 'default' in item: content += f'{new_line}<setting id="{_id}" default="{item["default"]}"></setting>'
				elif 'value' in item: content += f'{new_line}<setting id="{_id}">{item["value"]}</setting>'
				else: content += f'{new_line}<setting id="{_id}"></setting>'
				content = content.replace('></setting>', ' />')
			else: removed_settings_append(item)
		content += '\n</settings>'
		return content
	try:
		active_settings, current_user_settings, removed_settings = [], [], []
		active_append, current_append, removed_settings_append = active_settings.append, current_user_settings.append, removed_settings.append
		for i in mdParse(addon_settings).getElementsByTagName('setting'):
			setting_id = i.getAttribute('id')
			if setting_id: active_append(setting_id)
		for item in mdParse(user_settings).getElementsByTagName('setting'):
			dict_item = {}
			setting_id = item.getAttribute('id')
			setting_default = item.getAttribute('default')
			try: setting_value = item.firstChild.data
			except: setting_value = None
			dict_item['id'] = setting_id
			if setting_value: dict_item['value'] = setting_value
			if setting_default: dict_item['default'] = setting_default
			current_append(dict_item)
		new_content = _make_content(current_user_settings)
		with openFile(user_settings, 'w') as f: f.write(new_content)
		sleep(200)
		from openscrapers.modules.cache import cache_clear
		cache_clear()
		notification(title='script.module.openscrapers', message=lang(32036).format(str(len(removed_settings))))
	except Exception as e:
		log(f'error: {e}', 1)
		notification(title='script.module.openscrapers', message=32037)

def addonId():
	return addonInfo('id')

def addonName():
	return addonInfo('name')

def addonVersion():
	return addonInfo('version')

def addonIcon():
	return addonInfo('icon')

def addonPath():
	return translate_path(addonInfo('path'))

def addonEnabled(addon_id):
	return condVisibility(f'System.AddonIsEnabled({addon_id})')

def addonInstalled(addon_id):
	return condVisibility(f'System.HasAddon({addon_id})')

def openSettings(query=None, id=None):
	try:
		hide()
		if not id: id = addonInfo('id')
		log(f'openSettings query: {query} id: {id}', 1)
		execute(f'Addon.OpenSettings({id})')
		sleep(100)
		# while condVisibility('Window.IsVisible(addonsettings)'): sleep(100)
		# sleep(100)
		if 'resolveurl' in id:
			execute('RunPlugin(plugin://script.module.resolveurl/?mode=reset_cache)')
			sleep(100)
			notification(message='resolveurl reset cache', time=2000)
		if not query: return
		c, f = query.split('.')
		execute(f'SetFocus({int(c) - 100:d})')
		execute(f'SetFocus({int(f) - 80:d})')
	except:
		log(f'error: {print_exc()}', 1)
	return

def getProviderDefaults():
	provider_defaults = {}
	try:
		for item in mdParse(addon_settings).getElementsByTagName("setting"): #holy shit look at that.
			setting_id = item.getAttribute('id') #minidom instead of element tree
			if not setting_id.startswith('provider.'): continue
			try: defaulttext = item.getElementsByTagName('default')[0].firstChild.data #minidom instead of element tree
			except: defaulttext = 'false'
			provider_defaults[setting_id] = defaulttext or 'false'
	except: pass
	return provider_defaults

def setProviderDefaults(provider_defaults=None):
	try:
		if provider_defaults is None: provider_defaults = getProviderDefaults()
		homeWindow.setProperty('openscrapers_settings', 'false')
		for k, v in provider_defaults.items(): setSetting(k, v)
		homeWindow.setProperty('openscrapers_settings', 'true')
	except: return

def hide():
	execute('Dialog.Close(busydialog)')
	return execute('Dialog.Close(busydialognocancel)')

def notification(title=None, message=None, icon=None, time=3000, sound=False):
	if title == 'default' or title is None: title = addonName()
	if isinstance(title, int): heading = lang(title)
	else: heading = str(title)
	if isinstance(message, int): body = lang(message)
	else: body = str(message)
	if not icon or icon == 'default': icon = addonIcon()
	elif icon == 'INFO': icon = xbmcgui.NOTIFICATION_INFO
	elif icon == 'WARNING': icon = xbmcgui.NOTIFICATION_WARNING
	elif icon == 'ERROR': icon = xbmcgui.NOTIFICATION_ERROR
	return kodi_dialog().notification(heading, body, icon, time, sound=sound)

def yesnoDialog(line, heading=addonInfo('name'), nolabel='', yeslabel=''):
	return kodi_dialog().yesno(heading, line, nolabel, yeslabel)

def selectDialog(list, heading=addonInfo('name')):
	return kodi_dialog().select(heading, list)

def multiselectDialog(list, preselect=[], heading=addonInfo('name')):
	return kodi_dialog().multiselect(heading, list, preselect=preselect)


def contextmenuDialog(items=None, labels=None):
	if items:
		labels = [i[0] for i in items]
		choice = kodi_dialog().contextmenu(labels)
		if choice >= 0: return items[choice][1]()
		else: return False
	else: return kodi_dialog().contextmenu(labels)

def multiselectDialog_(title=None, items=None, preselect=None):
	if items:
		labels = [i for i in items]
		if preselect == None:
			return kodi_dialog().multiselect(title, labels)
		else:
			return kodi_dialog().multiselect(title, labels, preselect=preselect)
	else: return

def okDialog(title=None, message=None):
	if title == 'default' or title is None: title = addonName()
	if isinstance(title, int): heading = lang(title)
	else: heading = str(title)
	if isinstance(message, int): body = lang(message)
	else: body = str(message)
	return kodi_dialog().ok(heading, body)



def getSettingDefault(id):
	import re
	try:
		settings = open(addon_settings, 'r')
		value = ' '.join(settings.readlines())
		value.strip('\n')
		settings.close()
		value = re.findall(fr'id=\"{id}\".*?default=\"(.*?)\"', value)[0]
		return value
	except:
		return None



def check_version_numbers(current, new):
	# Compares version numbers and return True if new version is newer
	current = current.split('.')
	new = new.split('.')
	step = 0
	for i in current:
		if int(new[step]) > int(i):
			return True
		if int(i) == int(new[step]):
			step += 1
			continue
	return False


def set_reuselanguageinvoker():
	# if getKodiVersion() < 18:
		# notification(message=32116)
		# return
	try:
		addon_xml = joinPath(addonInfo('path'), 'addon.xml')
		try:
			tree = mdParse(addon_xml)
			reuse = tree.getElementsByTagName("reuselanguageinvoker")[0]
			current_value = reuse.firstChild.data
		except: return log('[script.module.openscrapers] ReuseLanguageInvokerCheck failed to get settings.xml value', 1)
		#tree = mdParse(addon_xml)
		#root = tree.getroot()
		#for item in root.iter('reuselanguageinvoker'):
		#	current_value = str(item.text)
		if current_value:
			new_value = 'true' if current_value == 'false' else 'false'
			if not yesnoDialog(lang(33018) % (current_value, new_value), '', ''):
				return openSettings(query='12.6')
			if new_value == 'true' and not yesnoDialog(lang(33019), '', ''): return
			# item.text = new_value
			hash_start = gen_file_hash(addon_xml)
			newxml = str(tree.toxml())[22:] #for some reason to xml adds this so we remove it."<?xml version="1.0" ?>"
			with open(addon_xml, "w") as f:
				f.write(newxml)
			hash_end = gen_file_hash(addon_xml)
			if hash_start != hash_end:
				homeWindow.setProperty('openscrapers_settings', 'false')
				setSetting('reuse.languageinvoker', new_value)
				homeWindow.setProperty('openscrapers_settings', 'true')
				okDialog(message=f'{lang(33017) % new_value}\n{lang(33020)}')
			else:
				return okDialog(message=33021)
			current_profile = infoLabel('system.profilename')
			execute(f'LoadProfile({current_profile})')
	except Exception as e: log(f'set_reuselanguageinvoker error: {repr(e)}', 1)


def display_string(object):
	try:
		if type(object) is str:
			return deaccentString(object)
	except NameError:
		pass
	if type(object) is int:
		return f'{object}'
	if type(object) is bytes:
		object = ''.join(chr(x) for x in object)
		return object


def deaccentString(text):
	import unicodedata
	try:
		if isinstance(text, bytes):
			text = text.decode('utf-8')
	except UnicodeDecodeError:
		text = f'{text}'
	text = ''.join(c for c in unicodedata.normalize('NFD', text) if unicodedata.category(c) != 'Mn')
	return text


def strip_non_ascii_and_unprintable(text):
	try:
		from string import printable
		result = ''.join(char for char in text if char in printable)
		return result.encode('ascii', errors='ignore').decode('ascii', errors='ignore')
	except Exception as e:
		log(f'strip_non_ascii_and_unprintable error: {repr(e)}', 1)
		return text


def gen_file_hash(file):
	try:
		from hashlib import md5
		md5_hash = md5()
		with open(file, 'rb') as afile:
			buf = afile.read()
			md5_hash.update(buf)
			return md5_hash.hexdigest()
	except Exception as e: log(f'gen_file_hash error: {repr(e)}', 1)


def getModuleName():
	scraper_folders = os.path.join(addonInfo('path'), 'lib', 'openscrapers', 'sources_openscrapers', 'en')
	# print(f'scraper_folders : {scraper_folders}')
	nameList = []
	nameListappend = nameList.append
	for file in os.listdir(scraper_folders):
		if file not in ['__pycache__', 'dead', 'undertest', 'hindi', '__init__.py']:
			# print(f's: {file}')
			try: nameListappend(file.split('.')[0].lower())
			except: pass
	return nameList


def platform():
	if xbmc.getCondVisibility('system.platform.android'):
		return 'android'
	elif xbmc.getCondVisibility('system.platform.linux'):
		return 'linux'
	elif xbmc.getCondVisibility('system.platform.windows'):
		return 'windows'
	elif xbmc.getCondVisibility('system.platform.osx'):
		return 'osx'
	elif xbmc.getCondVisibility('system.platform.atv2'):
		return 'atv2'
	elif xbmc.getCondVisibility('system.platform.ios'):
		return 'ios'


def get_useragent():
	get_platform = platform()
	# log(f'get_platform: {get_platform}', 1)
	if get_platform == 'windows': return 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
	elif get_platform == 'linux': return  'Mozilla/5.0 (Linux; Android 9; AFTSSS) AppleWebKit/537.36 (KHTML, like Gecko) Silk/130.1.71 like Chrome/130.0.6723.86 Safari/537.36'
	elif get_platform == 'android': return 'Mozilla/5.0 (Linux; Android 13; T771K Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/130.0.6723.107 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/479.0.0.48.89;]'
	elif get_platform == 'ios': return  'Mozilla/5.0 (iPhone; CPU iPhone OS 17_7_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.7.2 Mobile/15E148 Safari/605.1.15 NewsSapphire/29.8.421122001'
	else: return 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'


def openBrowser(link):
	myplatform = platform()
	if myplatform == 'android':
		mycommand = 'StartAndroidActivity(,android.intent.action.VIEW,,%s)'
		return xbmc.executebuiltin(mycommand % link)
	else:
		import webbrowser
		return webbrowser.open(link)


def copy2clip(txt):
	platform = sys.platform
	if platform == 'win32':
		try:
			import subprocess
			cmd = 'echo %s|clip' % txt.strip()
			return subprocess.check_call(cmd, shell=True)
		except:
			pass
	elif platform == 'linux':
		try:
			from subprocess import PIPE, Popen
			p = Popen(['xsel', '-pi'], stdin=PIPE)
			p.communicate(input=txt)
		except:
			pass

def _update_settings_xml():
	"""
	This function writes a new ``resources/settings.xml`` file which contains
	all settings for this addon and its plugins.
	"""
	from openscrapers.modules.py_tools import ensure_text
	from openscrapers.modules.log_utils import log
	# addon_settings = 'settings.xml'
	provider_url = {'123movies': 'https://www11.123movie.movie',
				'2embed': 'https://www.2embed.ru',
				'apimdb': 'https://player.apimdb.net',
				'bnwmovies': 'https://bnwmovies.com',
				'filmxy': 'https://www.filmxy.tv',
				'fsapi': 'https://fsapi.xyz',
				'gowatchseries': 'https://www5.gowatchseries.bz',
				'hdmovie8': 'https://hdmovie8.com',
				'imdbbox': 'https://imdbbox.com',
				'iwaatch': 'https://iwaatch.com',
				'myvideolink': 'https://see.home.kg',
				'plockers': 'https://putlocker.unblockit.uno',
				'projectfree': 'https://projecfreetv.co',
				'putlockersnet': 'https://wwv.putlockers.net',
				'streamlord': 'http://www.streamlord.com',
				'telepisodes': 'https://www1.telepisodes.org',
				'tunemovie': 'multi',
				'vidsrc': 'https://v2.vidsrc.me',
				'watchseriess': 'https://www4.watchseriess.co'}

	new_xml = ['<?xml version="1.0" encoding="utf-8" standalone="yes" ?>',
			   '<settings>',
			   '\t<!-- General-0 -->',
			   '\t<category label="32050">',
			   '\t\t<setting id="module.provider" label="32005" type="action" enable="false" visible="false" action="RunPlugin(plugin://script.module.openscrapers/?action=ScraperChoice)" default="OpenScrapers"/>',
			   '\t\t<setting label="32006" type="action" action="RunPlugin(plugin://script.module.openscrapers/?action=Defaults&amp;setting=true)"/>',
			   '\t\t<setting label="32007" type="action" action="RunPlugin(plugin://script.module.openscrapers/?action=toggleAll&amp;setting=false)"/>',
			   '\t\t<setting label="32008" type="action" action="RunPlugin(plugin://script.module.openscrapers/?action=toggleAll&amp;setting=true)"/>',
			   '\t\t<setting type="sep"/>',
			   '\t\t<setting label="32041" type="action" action="RunPlugin(plugin://script.module.openscrapers/?action=cleanSettings)"/>',
			   '\t\t<setting label="32009" type="action" action="RunPlugin(plugin://script.module.openscrapers/?action=ShowChangelog)"/>',
			   '\t\t<setting id="checkAddonUpdates" type="bool" label="32010" default="false"/>',
			   '\t\t<setting label="32001" type="action" action="RunPlugin(plugin://script.module.openscrapers/?action=ShowHelp&amp;name=updates)"/>',
			   '\t\t<!-- <setting id="undesirables.choice" type="text" default="" visible="true"/> -->',
			   '\t\t<setting id="filter.undesirables" type="bool" label="32016" default="true"/>',
			   '\t\t<setting id="undesirables.settings1" type="action" label="32046" default="" action="RunPlugin(plugin://script.module.openscrapers/?action=undesirablesSelect)" subsetting="true" enable="eq(-1,true)"/>',
			   '\t\t<setting id="undesirables.settings2" type="action" label="32048" default="" action="RunPlugin(plugin://script.module.openscrapers/?action=undesirablesInput)" subsetting="true" enable="eq(-2,true)"/>',
			   '\t\t<setting id="undesirables.settings3" type="action" label="32049" default="" action="RunPlugin(plugin://script.module.openscrapers/?action=undesirablesUserRemove)" subsetting="true" enable="eq(-3,true)"/>',
			   '\t\t<setting id="undesirables.settings4" type="action" label="32140" default="" action="RunPlugin(plugin://script.module.openscrapers/?action=undesirablesUserRemoveAll)" subsetting="true" enable="eq(-4,true)"/>',
			   '\t\t<setting label="32003" type="action" action="RunPlugin(plugin://script.module.openscrapers/?action=ShowHelp&amp;name=undesirablesFilter)"/>',
			   '\t\t<setting id="filter.foreign.single.audio" type="bool" label="32017" default="true"/>',
			   '\t\t<!-- Hidden -->',
			   '\t\t<!-- <setting id="folder5.tv_shows_directory" type="text" default="None" visible="false" /> -->',
			   '\t</category>',
			   '\t<!-- Providers/Hosters-1 -->',
			   '\t<category label="32051">',
			   '\t\t<setting label="32011" type="action" action="RunPlugin(plugin://script.module.openscrapers/?action=toggleAllHosters&amp;setting=false)"/>',
			   '\t\t<setting label="32012" type="action" action="RunPlugin(plugin://script.module.openscrapers/?action=toggleAllHosters&amp;setting=true)"/>',
			   '\t\t<setting type="sep"/>',]

	hosters = getModuleName()
	hosters = sorted(hosters, key=lambda x: x)
	for hoster in hosters:
		label = provider_url.get(hoster)
		if label:
			new_xml.append(f'\t\t<setting id="provider.{hoster}" type="bool" label="{hoster.upper()} {label}" default="true"/>')
			new_xml.append(f'\t\t<setting id="url.{hoster}" type="text" label="Custom Domain:" default="" visible="eq(-1,true)" subsetting="true"/>')
		else: new_xml.append(f'\t\t<setting id="provider.{hoster}" type="bool" label="{hoster.upper()}" default="true"/>')

	# new_xml.append('\t</category>')
	new_xml1 = ['\t</category>',
				'\t<!-- Accounts-2 -->',
				'\t<category label="32053">',
				'\t\t<setting label="32018" type="lsep"/>',
				'\t\t<setting type="action" label="32004" action="RunPlugin(plugin://script.module.openscrapers/?action=ShowHelp&amp;name=myAccountsSync&amp;query=6.2)"/>',
				'\t\t<setting type="action" label="32019" option="close" action="RunPlugin(plugin://script.module.openscrapers/?action=openMyAccount&amp;opensettings=true&amp;query=6.1)"/>',
				'\t\t<setting type="action" label="32020" option="close" action="RunPlugin(plugin://script.module.openscrapers/?action=syncMyAccount&amp;opensettings=true&amp;query=6.2)"/>',
				'\t\t<setting id="trakt.user" type="string" help=""/>',
				'\t\t<setting id="trakt.expires" type="string" help=""/>',
				'\t\t<setting id="trakt.refresh" type="string" help=""/>',
				'\t\t<setting id="trakt.token" type="string" help=""/>',
				'\t\t<setting type="lsep" label="32023"/>',
				'\t\t<setting id="furk.user_name" type="text" label="32024" default="" enable="true"/>',
				'\t\t<setting id="furk.user_pass" type="text" label="32025" option="hidden" default="" enable="true"/>',
				'\t\t<setting id="furk.api" type="text" label="32026" default="" enable="true"/>',
				'\t\t<setting type="lsep" label="32027"/>',
				'\t\t<setting id="easynews.user" type="text" label="32028" default="" enable="true"/>',
				'\t\t<setting id="easynews.password" type="text" label="32029" default="" enable="true"/>',
				'\t\t<setting type="lsep" label="32030"/>',
				'\t\t<setting id="ororo.user" type="text" label="32031" default="" enable="true"/>',
				'\t\t<setting id="ororo.pass" type="text" label="32032" default="" enable="true"/>',
				'\t\t<setting type="lsep" label="32081"/>',
				'\t\t<setting id="gdrive.cloudflare_url" type="text" label="32039" default="" enable="true"/>',
				'\t\t<setting id="gdrive.title.chk" type="bool" label="32083" default="true"/>',
				'\t\t<setting label="32001" type="action" action="RunPlugin(plugin://script.module.openscrapers/?action=ShowHelp&amp;name=gdrive_titleCheck)"/>',
				'\t\t<setting type="lsep" label="32021"/>',
				'\t\t<setting id="filepursuit.api" type="text" label="32022" default="" enable="true"/>',
				'\t</category>',
				'\t<!-- Debugging - 3 -->',
				'\t<category label="32054">',
				'\t\t<setting id="unblockit" type="text" label="unblockit Domain:" default="https://unblockit.bz"/>',
				'\t\t<setting id="debug.enabled" type="bool" label="32033" default="false"/>',
				'\t\t<setting id="debug.location" type="enum" label="32034" lvalues="32035|32036" default="1" enable="eq(-1,true)"/>',
				'\t\t<setting id="debug.reversed" type="bool" label="32055" default="false"/>',
				'\t\t<setting type="action" label="32056" action="RunPlugin(plugin://script.module.openscrapers/?action=tools_clearLogFile)" visible="eq(-3,true) + eq(-2,1)"/>',
				'\t\t<setting type="action" label="32057" action="RunPlugin(plugin://script.module.openscrapers/?action=tools_viewLogFile&amp;name=openscrapers)" visible="eq(-4,true) + eq(-3,1)"/>',
				'\t\t<setting type="action" label="32058" action="RunPlugin(plugin://script.module.openscrapers/?action=tools_uploadLogFile)" visible="eq(-5,true) + eq(-4,1)"/>',
				'\t</category>',
				'</settings>'
				]
	new_xml1 = '\n'.join(new_xml1)
	new_xml.append(new_xml1)
	# print(new_xml1)

	try:
		with open(addon_settings, 'r', encoding='utf-8') as f:
			old_xml = f.read()
	except:
		old_xml = u''
	old_xml = ensure_text(old_xml)

	new_xml = ensure_text('\n'.join(new_xml))
	if old_xml != new_xml:
		log('Updating Settings XML')
		try:
			with open(addon_settings, 'w', encoding='utf-8') as f:
				f.write(new_xml)
		except: raise
	else: log('No Settings Update Needed')

def get_kodi_certi_file():
	return translate_path('special://xbmc/system/certs/cacert.pem')

def supported_video_extensions():
	supported_video_extensions = xbmc.getSupportedMedia('video').split('|')
	unsupported = ['', '.url', '.bin', '.zip', '.rar', '.001', '.disc', '.7z', '.tar.gz', '.tar.bz2', '.tar.xz', '.tgz', '.tbz2', '.gz', '.bz2', '.xz', '.tar']
	return [i for i in supported_video_extensions if i not in unsupported]

def moderator():
	from urllib.parse import urlparse
	netloc = [urlparse(argv[0]).netloc, '', 'plugin.video.metalliq', 'script.extendedinfo', 'plugin.program.super.favourites', 'plugin.video.themoviedb.helper']
	if not infoLabel('Container.PluginName') in netloc: pass
	#sys.exit()


def jsondate_to_datetime(jsondate_object, resformat, remove_time=False):
	import _strptime  # fix bug in python import
	from datetime import datetime
	import time
	if remove_time:
		try: datetime_object = datetime.strptime(jsondate_object, resformat).date()
		except TypeError: datetime_object = datetime(*(time.strptime(jsondate_object, resformat)[:6])).date()
	else:
		try: datetime_object = datetime.strptime(jsondate_object, resformat)
		except TypeError: datetime_object = datetime(*(time.strptime(jsondate_object, resformat)[:6]))
	return datetime_object

def set_active_monitor():
	homeWindow.setProperty('openscraper.active', 'true')

def release_active_monitor():
	homeWindow.clearProperty('openscraper.active')

def function_monitor(func, query='0.0'):
	func()
	sleep(10)
	openSettings(query)
	while not condVisibility('Window.IsVisible(addonsettings)'):
		sleep(50)
	sleep(10)
	release_active_monitor()

def delete_file(_file):
	try: deleteFile(_file)
	except Exception as e:
		# log(f'delete_file error: {repr(e)}')
		from os import unlink, remove
		try:
			unlink(_file)
			remove(_file)
		except Exception as e: pass#log(f'2 delete_file error: {repr(e)}')


def getlan_choice():
	return {'None':'None','Afrikaans':'afr','Albanian':'alb','Arabic':'ara',
	'Armenian':'arm','Basque':'baq','Bengali':'ben','Bosnian':'bos',
	'Breton':'bre','Bulgarian':'bul','Burmese':'bur','Catalan':'cat',
	'Chinese':'chi','Croatian':'hrv','Czech':'cze','Danish':'dan',
	'Dutch':'dut','English':'eng','Esperanto':'epo','Estonian':'est',
	'Finnish':'fin','French':'fre','Galician':'glg','Georgian':'geo',
	'German':'ger','Greek':'ell','Hebrew':'heb','Hindi':'hin',
	'Hungarian':'hun','Icelandic':'ice','Indonesian':'ind','Italian':'ita',
	'Japanese':'jpn','Kazakh':'kaz','Khmer':'khm','Korean':'kor',
	'Latvian':'lav','Lithuanian':'lit','Luxembourgish':'ltz','Macedonian':'mac',
	'Malay':'may','Malayalam':'mal','Manipuri':'mni','Mongolian':'mon',
	'Montenegrin':'mne','Norwegian':'nor','Occitan':'oci','Persian':'per',
	'Polish':'pol','Portuguese':'por','Portuguese(Brazil)':'pob','Romanian':'rum',
	'Russian':'rus','Serbian':'scc','Sinhalese':'sin','Slovak':'slo',
	'Slovenian':'slv','Spanish':'spa','Swahili':'swa','Swedish':'swe',
	'Syriac':'syr','Tagalog':'tgl','Tamil':'tam','Telugu':'tel',
	'Thai':'tha','Turkish':'tur','Ukrainian':'ukr','Urdu':'urd','Vietnamese':'vie'}

def get_sub_settings():
	auto_enable = setting('subtitles.auto_enable', True)
	lang = setting('subtitles.lang_primary', 'en')
	audio_preference = setting('audio.preference', 'true') == 'true'
	secondary_lang = setting('subtitles.lang_secondary', 'hin')
	return {'auto_enable': auto_enable, 'language': lang, 'audio_preference': audio_preference, 'secondary_language': secondary_lang}

def get_domin_setting(s_id):
	return setting(s_id)

