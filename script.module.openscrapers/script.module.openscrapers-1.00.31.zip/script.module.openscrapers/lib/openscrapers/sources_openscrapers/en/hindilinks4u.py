# -*- coding: UTF-8 -*-

# import json
import re

# from openscrapers import urlencode, quote_plus

import requests

from openscrapers.modules.hindi_sources import get_source_dict, resolve_gen
from openscrapers.modules.log_utils import log, error
# from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.client import agent, request

class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "hindilinks4u"
        self.domains = ['hindilinks4u.to']
        self.base_link = 'https://www.hindilinks4u.to'
        self.search_link = '/feed/?s=%s&submit=Search'
        self.headers = {'User-Agent': agent(), }

    def movie(self, imdb, title, localtitle, aliases, year):
        # log(f"From: {__name__}\nimdb: {imdb}\ntitle: {title}\nlocaltitle: {localtitle}\naliases: {aliases}\nyear: {year}")
        try:
            scrape = title.lower().replace(' ', '-')
            start_url = f"{self.base_link}/{scrape}-{year}/"
            return start_url
        except:
            error(f'{__name__}_ movie: ')
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f"From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year} ")
        try:
            url = f'{tvshowtitle}'
            return url
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f"From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}")
        try:
            if type(tvdb) == int: return
            if '|' in tvdb:
                url = url.lower().replace(f' season %s' % season, '').replace(' ', '-').replace('.', '')
                if 'episode' in title.lower():
                    # log(f'episode url:  {url}\nseason: {season} episode: {episode}')
                    query = f"episode/{url}-s{season}e{episode}"
                    url = f'{self.base_link}/{query}/'
                    return url
            else: return
        except:
            error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict):
        # log(f"From: {__name__}\nurl {url}")
        sources = []
        try:
            if not url: return sources
            result = request(url, headers=self.headers)
            if not result: return sources
            items = re.findall('data-href=."(.*?)."', result)
            # result = parseDOM(result, 'div', attrs = {'class': 'entry-content rich-content'})
            # result += parseDOM(result, 'div', attrs = {'id': 'player2'})
            # log(result)
            # items += parseDOM(result, 'p')
            # log(items)
            for item in items:
                if item:
                    sources = get_source_dict(item, sources)
            return sources
        except:
            error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return resolve_gen(url)
