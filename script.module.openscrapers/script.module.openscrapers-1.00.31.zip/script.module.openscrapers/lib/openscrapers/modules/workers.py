# -*- coding: utf-8 -*-
"""
	OpenScrapers Module
"""

from threading import Thread as thread

class Thread(thread):
	def __init__(self, target, *args, name=None):
		self._target = target
		self._args = args
		self._name = name
		thread.__init__(self, target=self._target, args=self._args, name=self._name)

# class Thread(threading.Thread):
	# def __init__(self, target, *args):
		# self._target = target
		# self._args = args
		# threading.Thread.__init__(self)

	# def run(self):
		# self._target(*self._args)
