# -*- coding: utf-8 -*-
# (updated 12-14-2021)
'''
	Fenomscrapers Project
'''
import random
import re
import requests
from openscrapers import parse_qs, urlencode, unquote, quote_plus

try: from openscrapers.modules.control import setting as getSetting
except: pass
from openscrapers.modules.source_utils import check_foreign_audio, get_query, check_title, info_from_name, get_release_quality, _size
from openscrapers.modules.log_utils import log, error

def getResults(searchTerm):
	cloudflare_worker_url = random.choice(['https://wandering-river-0edc.rrosajp4.workers.dev', 'https://gd.djp97s.workers.dev'])
	url = f'{cloudflare_worker_url}/searchjson/{searchTerm}'
	# if not url.startswith("https://"): url = "https://" + url
	# log('query url = %s' % url)
	results = requests.get(url).json()
	return results

class source:
	pack_capable = False
	hasMovies = True
	hasEpisodes = True

	def __init__(self):
		try: 
			self.title_chk = (getSetting('gdrive.title.chk') == 'true')
			self.check_foreign_audio = check_foreign_audio()
		except: 
			self.title_chk = 'true'
			self.check_foreign_audio = False
		self.base_link = 'https://gd.djp97s.workers.dev'

	def movie(self, imdb, title, localtitle, aliases, year):
		try:
			url = {'imdb': imdb, 'title': title, 'aliases': aliases, 'year': year}
			url = urlencode(url)
			return url
		except:
			error(f'{__name__}_ movie: ')
			return

	def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
		try:
			url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'aliases': aliases, 'year': year}
			url = urlencode(url)
			return url
		except:
			error(f'{__name__}_ tvshow: ')
			return

	def episode(self, url, imdb, tvdb, title, premiered, season, episode):
		try:
			if not url: return
			url = parse_qs(url)
			url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
			url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
			url = urlencode(url)
			return url
		except:
			error(f'{__name__}_ episode: ')
			return

	def sources(self, url, hostDict):
		sources = []
		if not url: return sources
		append = sources.append
		try:
			data = parse_qs(url)
			data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

			title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$','s')
			aliases = data['aliases']
			episode_title = data['title'] if 'tvshowtitle' in data else None
			year = data['year']
			# hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else year
			# query = '%s %s' % (title, hdlr)
			# query = quote_plus(re.sub(r'[^A-Za-z0-9\s\.-]+', '', query))
			query, hdlr = get_query(data, title)
			# log(f'{__name__} query1: {query}')
			results = getResults(query)
			if not results:
				query, hdlr = get_query(data, title, 'nofull_name')
				# log(f'{__name__} nofull_name {query}_ sources: ')
				results = getResults(query)
				if not results: return sources
		except:
			error(f'{__name__}_ sources: ')
			return sources

		for result in results:
			try:
				#log(f'GD result: {result}')
				link = result["link"]
				name = unquote(link.rsplit("/")[-1])
				if self.title_chk:
					if not check_title(title, aliases, name, hdlr, year): continue
				name_info = info_from_name(name, title, year, hdlr, episode_title)

				quality, info = get_release_quality(name_info, link)
				try:
					size = str(result["size_gb"]) + ' GB'
					dsize, isize = _size(size)
					# if isize: info.insert(0, isize)
				except:
					error(f'{__name__}_ sources: ')
					dsize = 0
				info = ' | '.join(info)

				append({'source': 'gdrive', 'provider': 'gdrive', 'name': name, 'name_info': name_info,
								'quality': quality, 'url': link, 'info': info,  'direct': True, 'size': dsize})
			except:
				error(f'{__name__}_ sources: ')
		return sources

	def resolve(self, url):
		return url
