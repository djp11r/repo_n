# -*- coding: utf-8 -*-
"""
	OpenScrapers Module
"""

import json
# import re
# import threading
# import time
from openscrapers import urljoin

from openscrapers.modules import client
from openscrapers.modules import log_utils
from openscrapers.modules import utils

BASE_URL = 'https://api.trakt.tv'
V2_API_KEY = '42740047aba33b1f04c1ba3893ce805a9ecfebd05de544a30fe0c99fabec972e'
CLIENT_SECRET = 'c7a3e7fdf5c3863872c8f45e1d3f33797b492ed574a00a01a3fadcb3d270f926'
REDIRECT_URI = 'urn:ietf:wg:oauth:2.0:oob'


def __getTrakt(url, post=None):
	try:
		url = urljoin(BASE_URL, url) if not url.startswith(BASE_URL) else url
		post = json.dumps(post) if post else None
		headers = {'Content-Type': 'application/json', 'trakt-api-key': V2_API_KEY, 'trakt-api-version': 2}
		result = client.request(url, post=post, headers=headers, output='extended', error=True)
		result = utils.byteify(result)

		resp_code = result[1]
		resp_header = result[2]
		result = result[0]
		if resp_code in ['423', '500', '502', '503', '504', '520', '521', '522', '524']:
			log_utils.log('Temporary Trakt Error: %s' % resp_code, log_utils.LOGWARNING)
			return
		elif resp_code in ['429']:
			log_utils.log('Trakt Rate Limit Reached: %s' % resp_code, log_utils.LOGWARNING)
			return
		elif resp_code in ['404']:
			log_utils.log('Object Not Found: %s' % resp_code, log_utils.LOGWARNING)
			return
		if resp_code not in ['401', '405']:
			return result
	except Exception as e:
		log_utils.log('Unknown Trakt Error: %s' % e, log_utils.LOGWARNING)
		pass


def getTraktAsJson(url, post=None, authentication=None):
	try:
		res_headers = {}
		r = getTrakt(url=url, post=post, extended=True, authentication=authentication)
		if isinstance(r, tuple) and len(r) == 2:
			r , res_headers = r[0], r[1]
		if not r or any(val in str(r) for val in ["Bad Gateway", "We're sorry, but something went wrong (500)"]):
			log_utils.log('Trakt Service Unavailable', __name__, log_utils.LOGNOTICE)
			return
		# log_utils.log('r = %s' % r, __name__, log_utils.LOGDEBUG)
		r = utils.json_loads_as_str(r)
		res_headers = dict((k.lower(), v) for k, v in res_headers.iteritems())
		if 'x-sort-by' in res_headers and 'x-sort-how' in res_headers:
			r = sort_list(res_headers['x-sort-by'], res_headers['x-sort-how'], r)
		return r
	except:
		log_utils.error()


def getMovieTranslation(id, lang, full=False):
	try:
		url = '/movies/%s/translations/%s' % (id, lang)
		item = getTraktAsJson(url)[0]
		result = item if full else item.get('title')
		return None if result == 'none' else result
	except:
		log_utils.error()
		pass


def getTVShowTranslation(id, lang, season=None, episode=None, full=False):
	try:
		if season and episode: url = '/shows/%s/seasons/%s/episodes/%s/translations/%s' % (id, season, episode, lang)
		else: url = '/shows/%s/translations/%s' % (id, lang)
		item = getTraktAsJson(url)[0]
		result = item if full else item.get('title')
		return None if result == 'none' else result
	except:
		log_utils.error()
		pass


def getMovieAliases(id):
	try:
		return getTraktAsJson('/movies/%s/aliases' % id)
	except:
		return []


def getTVShowAliases(id):
	try:
		return getTraktAsJson('/shows/%s/aliases' % id)
	except:
		return []


def getGenre(content, type, type_id):
	try:
		r = '/search/%s/%s?type=%s&extended=full' % (type, type_id, content)
		r = getTraktAsJson(r)
		r = r[0].get(content, {}).get('genres', [])
		return r
	except:
		log_utils.error()
		return []

def getEpisodeRating(imdb, season, episode):
	try:
		if not imdb.startswith('tt'): imdb = 'tt' + imdb
		url = '/shows/%s/seasons/%s/episodes/%s/ratings' % (imdb, season, episode)
		r = getTraktAsJson(url)
		r1 = r.get('rating', '0')
		r2 = r.get('votes', '0')
		return str(r1), str(r2)
	except:
		return
