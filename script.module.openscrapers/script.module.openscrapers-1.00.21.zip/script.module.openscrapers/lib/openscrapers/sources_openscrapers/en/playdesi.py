# -*- coding: UTF-8 -*-

# import json
# import re
import re


import requests
from openscrapers.modules import client, log_utils
from openscrapers.modules.hindi_sources import scraper_debug, get_source_dict, resolve_gen, host, keepclean_title


class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "playdesi"
        self.domains = ['playdesi.org']
        self.base_link = 'https://playdesi.tv'
        self.headers = {'User-Agent': client.agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # scraper_debug("From: {} \nimdb {} \ntvdb {}\n tvshowtitle {}, localtvshowtitle {}, aliases {}, year {} ".format(self.name, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))
        try:
            try:
                url = aliases[0]['url']
                # log_utils.log(f'show url: {url}')
                if 'playdesi' in url: return url
            except: pass #log_utils.error(f'{__name__}_ tvshow: ')
            query = '%s' % (tvshowtitle)
            url = query
            # scraper_debug('>>> #### 0AAAA - yodesi EP url : %s' % ( url))
            return url
        except:
            log_utils.error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # scraper_debug("From: {} url: {} imdb: {} tvdb: {}\n title: {}, premiered: {}, season: {}, episode: {} ".format(self.name, url, imdb, tvdb, title, premiered, season, episode))
        # log_utils.log(f'episode url: {url}')
        try:
            if type(tvdb) == int: return
            if 'episode' not in title.lower(): return
            if 'watch-online' in url: return url
            if '|' in tvdb:
                # scraper_debug("type playdesi tvdb %s" % type(tvdb))
                tvdb = tvdb.split('|')
                # ch_name = tvdb[0]
                title = keepclean_title(tvdb[1]).lower().replace(' ', '-')#.replace('.', '').replace('season', '')
                # episode = episode.lower().replace('.', '').replace('episode', '').strip()
                urls = []
                urls.append('{}/{}-season-{}-{}-watch-online'.format(self.base_link, title, season, episode))
                urls.append('{}/{}-{}-watch-online'.format(self.base_link, title, episode))
                for url in urls:
                    url = url.replace(' ', '-')
                    result = requests.get(url, headers=self.headers)
                    # print('status_code: {} url: {}'.format(result.status_code, url))
                    if result.status_code == 200:
                        return url
            # else: return
        except:
            log_utils.error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict, hostprDict):
        # scraper_debug("From: {} \nurl: {} ... \n{} .. \n{}".format(self.name, url, hostDict, hostprDict))
        # log_utils.log(f'url: {url}')
        sources = []
        try:
            if not url:	return sources
            # scraper_debug('url: %s' % url)
            result = requests.get(url, headers=self.headers).text
            if not result:
                return
            result = client.parseDOM(result, 'div', attrs={'class': 'entry-content'})
            # scraper_debug('result: %s' % result)
            items = client.parseDOM(result, 'p')
            for item in items:
                urls = client.parseDOM(item, 'a', ret='href')
                # log_utils.log(f'url: {urls}')
                furls = []
                vidhost = None
                for j in range(0, len(urls)):
                    try:
                        headers = {'Referer': urls[j]}
                        self.headers.update(headers)
                        result = requests.get(urls[j], headers = self.headers).text
                        if result:
                            links = client.parseDOM(result, 'iframe', ret = 'src')
                            for link in links:
                                # print('link: {}'.format(link))
                                if 'vkprime' in link or 'speed' in link or 'watchvideo.us' in link:
                                    vidhost = host(link)
                                    furls.append(link)
                                elif any(re.findall(r'index.php|embed|plyr20a|nflix20', link, re.IGNORECASE)):
                                    # vidhost = 'CDN'
                                    furls.append(urls[j])
                    except:
                        pass
                if len(furls) > 0:
                    sources = get_source_dict(furls, sources, vidhost)
            # dumper = dumper
            # scraper_debug('SOURCES \n\n%s' % json.dumps(sources, default = dumper, indent = 2))
            return sources
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # scraper_debug('In type of url {} url: {}'.format(type(url), url))
        url = resolve_gen(url)
        return url
