# -*- coding: utf-8 -*-
# -Cleaned and Checked on 04-30-2020 by Tempest.

import re
import traceback

try: from urlparse import parse_qs, urljoin, urlparse
except ImportError: from urllib.parse import parse_qs, urljoin, urlparse
try: from urllib import urlencode, quote_plus, unquote_plus
except ImportError: from urllib.parse import urlencode, quote_plus, unquote_plus


from openscrapers.modules import client
from openscrapers.modules import log_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['www1.watch-series.la', 'dwatchseries.to', 'swatchseries.to']
        self.base_link = 'https://www1.watch-series.la'

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except Exception:
            log_utils.log('SwatchSeries - Exception: \n' + str(traceback.format_exc()))
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None:
                return
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            title = url['tvshowtitle'].replace(' ', '_').replace(':', '').replace('.-.', '.').replace('\'', '').replace(",", '').replace("'", '').replace('�', '-').replace('!', '')
            # tit = cleantitle.get_query_(url['tvshowtitle'])
            tit = re.sub('[^A-Za-z0-9]+', '_', title)
            url = '%s/episode/%s_s%s_e%s.html' % (self.base_link, tit, season, episode)
            return url
        except Exception:
            log_utils.log('SwatchSeries - Exception: \n' + str(traceback.format_exc()))
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if not url: return sources
            hostDict += hostprDict
            r = client.request(url)
            links = re.compile(r'''onclick="if \(confirm\('Delete link (.+?)'\)\)''', re.DOTALL).findall(str(r))
            links = [x for y, x in enumerate(links) if x not in links[:y]]
            for i in links:
                try:
                    url = i
                    url = client.replaceHTMLCodes(url)
                    url = url.encode('utf-8')
                    host = re.findall(r'([\w]+[.][\w]+)$', urlparse(url.strip().lower()).netloc)[0]
                    if host not in hostDict:
                        raise Exception()
                    host = host.encode('utf-8')
                    if 'vev' not in url:
                        sources.append({'source': host, 'quality': 'SD', 'language': 'en', 'info': '', 'url': url, 'direct': False, 'debridonly': False})
                except Exception:
                    pass

            return sources
        except Exception:
            log_utils.log('SwatchSeries - Exception: \n' + str(traceback.format_exc()))
            return sources

    def resolve(self, url):
        return url
