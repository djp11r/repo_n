# -*- coding: utf-8 -*-
# -Cleaned and Checked on 04-14-2020 by Tempest.
# -Converted to py3/2 for TheOath


import re
try: import simplejson as json
except: import json
import base64
import time
import traceback

try: from urlparse import parse_qs, urljoin
except ImportError: from urllib.parse import parse_qs, urljoin
try: from urllib import urlencode, unquote_plus, quote
except ImportError: from urllib.parse import urlencode, unquote_plus, quote


from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import directstream
from openscrapers.modules import source_utils
from openscrapers.modules import scrape_source
from openscrapers.modules import log_utils
from openscrapers.modules import py_tools


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['cartoonhd.care']
        self.base_link = 'https://cartoonhd.app'
        self.headers = {'User-Agent': client.agent()}
        # self.session = requests.Session()

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            # aliases = json.loads(aliases)
            # aliases.append({'country': 'us', 'title': title})
            url = {'imdb': imdb, 'title': title, 'year': year, 'aliases': aliases}
            url = urlencode(url)
            return url
        except:
            log_utils.log('cartoonhd - Exception: \n' + str(traceback.format_exc()))
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            # aliases = json.loads(aliases)
            # aliases.append({'country': 'us', 'title': tvshowtitle})
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year, 'aliases': aliases}
            url = urlencode(url)
            return url
        except:
            log_utils.log('cartoonhd - Exception: \n' + str(traceback.format_exc()))
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url: return
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            log_utils.log('cartoonhd - Exception: \n' + str(traceback.format_exc()))
            return


    def searchShow(self, title, season, episode, aliases, headers):
        aliases = [{'title': title}]
        try:
            for alias in aliases:
                url = '%s/tv-show/%s/season/%01d/episode/%01d' % (self.base_link, cleantitle.geturl(title), int(season), int(episode))
                # url = '%s/show/%s/season/%01d/episode/%01d' % (self.base_link, cleantitle.geturl(alias['title']), int(season), int(episode))
                url = client.request(url, headers=headers, output='geturl', timeout='10')
                if url and url != self.base_link:
                    break
            return url
        except:
            log_utils.log('cartoonhd - Exception: \n' + str(traceback.format_exc()))
            return


    def searchMovie(self, title, year, aliases, headers):
        if not aliases:
            aliases = [{'title': title}]
        try:
            for alias in aliases:
                url = '%s/full-movie/%s' % (self.base_link, cleantitle.geturl(alias['title']))
                url = client.request(url, headers=headers, output='geturl', timeout='10')
                if url and url != self.base_link:
                    break
            if not url:
                for alias in aliases:
                    url = '%s/full-movie/%s-%s' % (self.base_link, cleantitle.geturl(alias['title']), year)
                    url = client.request(url, headers=headers, output='geturl', timeout='10')
                    if url and url != self.base_link:
                        break
            return url
        except:
            log_utils.log('cartoonhd - Exception: \n' + str(traceback.format_exc()))
            return


    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if not url: return sources
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            imdb = data['imdb']
            aliases = eval(data['aliases'])
            headers = {'User-Agent': client.agent()}
            if 'tvshowtitle' in data:
                url = self.searchShow(title, int(data['season']), int(data['episode']), aliases, headers)
            else:
                url = self.searchMovie(title, data['year'], aliases, headers)
            print("url to get: %s" % url)
            r = client.request(url, headers=headers, output='extended', timeout='10')
            # print("r: %s" % r[0])
            if r is None:
                return sources
            # if imdb not in r[0]:
            #     return sources
            try:
                cookie = r[4]
                headers = r[3]
            except:
                cookie = r[3]
                headers = r[2]
            result = r[0]
            try:
                resp = py_tools.ensure_text(result, errors='ignore')
                r = re.findall(r'(https:.*?redirector.*?)[\'\"]', resp)
                for i in r:
                    try:
                        sources.append({'source': 'gvideo', 'quality': directstream.googletag(i)[0]['quality'], 'language': 'en', 'info': '', 'url': i, 'direct': True, 'debridonly': False})
                    except: pass
            except: source_utils.scraper_error('CARTOONHD')

            try: auth = re.findall(r'__utmx=(.+)', cookie)[0].split(';')[0]
            except: auth = 'false'
            auth = 'Bearer %s' % unquote_plus(auth)
            headers['Authorization'] = auth
            headers['Referer'] = url
            u = '/ajax/vsozrflxcw.php'
            self.base_link = client.request(self.base_link, headers=headers, output='geturl')
            u = urljoin(self.base_link, u)
            action = 'getEpisodeEmb' if '/episode/' in url else 'getMovieEmb'
            tim = str(int(time.time())) if py_tools.isPY2 else py_tools.ensure_binary(str(int(time.time())))
            elid = quote(base64.b64encode(tim)).strip()
            token = re.findall(r"var\s+tok\s*=\s*'([^']+)", result)[0]
            idEl = re.findall(r'elid\s*=\s*"([^"]+)', result)[0]
            post = {'action': action, 'idEl': idEl, 'token': token, 'nopop': '', 'elid': elid}
            post = urlencode(post)
            if cookie: cookie += ';%s=%s' % (idEl, elid)
            else: cookie = '%s=%s' % (idEl, elid)
            headers['Cookie'] = cookie
            r = client.request(u, post=post, headers=headers, cookie=cookie, XHR=True)
            resp = py_tools.ensure_text(r, errors='ignore')
            r = str(json.loads(resp))
            r = re.findall(r'\'(http.+?)\'', r) + re.findall(r'\"(http.+?)\"', r)
            for i in r:
                # print("iL %s" % i)
                if 'Season' in i:
                    i = i.split(' - Season')[0]
                if 'vidnode.net' in i:
                    i = i.replace('vidnode.net', 'vidcloud9.com')
                for source in scrape_source.getMore(i, hostDict):
                    sources.append(source)
            return sources
        except Exception:
            log_utils.log('cartoonhd - Exception: \n' + str(traceback.format_exc()))
            return sources

    def resolve(self, url):
        if 'google' in url and 'googleapis' not in url:
            return directstream.googlepass(url)
        else:
            return url
