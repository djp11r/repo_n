# -*- coding: UTF-8 -*-

import re
import traceback

try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import quote_plus

from bs4 import BeautifulSoup, SoupStrainer
from openscrapers.modules import client, cleantitle, log_utils, genericresolver, source_utils


class source:

    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.name = "desiserials"
        self.domains = ['desiserials.org']
        self.base_link = 'http://www.desi-serials.org'
        self.search_link = '/feed/?s=%s&submit=Search'

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log_utils.log("!!!!!!! yodesi \n{} ... \n{} .. \n{}\n {} {} {}  ".format(imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))
        try:
            query = '%s' % (tvshowtitle)
            url = query
            # log_utils.log('>>> #### 0AAAA - yodesi EP url : %s' % ( url))
            return url
        except:
            log_utils.log('yodesi tvshow Exception : %s' % (traceback.format_exc()))
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log_utils.log("!!!!!!! yodesi \n{} ... \n{} .. \n{}\n {} {} {} {} ".format(url, imdb, tvdb, title, premiered, season, episode))
        try:
            query = '%s %s' % (title, episode)
            query = self.search_link % (quote_plus(query))

            result = client.request(self.base_link + query)

            result = result.decode('iso-8859-1').encode('utf-8')

            result = result.replace('\n', '').replace('\t', '')

            items = client.parseDOM(result, 'item')

            cleanedTitle = cleantitle.get('%s %s' % (title, episode))

            for item in items:
                linkTitle = client.parseDOM(item, 'title')[0]
                linkTitle = cleantitle.get(linkTitle).replace('watchonlineepisodehd', '')
                if cleanedTitle == linkTitle:
                    url = client.parseDOM(item, "link")[0]
                    url = client.replaceHTMLCodes(url)
                    break

            return url
        except:
            log_utils.log('yodesi episode Exception : %s' % (traceback.format_exc()))
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        # log_utils.log("!!!!!!! yodesi \n{} ... \n{} .. \n{}".format(url, hostDict, hostprDict))
        try:
            quality = ''
            if url is None: return sources

            result = client.request(url)

            result = result.decode('iso-8859-1').encode('utf-8')

            result = result.replace('\n', '')

            result = client.parseDOM(result, "div", attrs={"class": "post-content bottom"})[0]

            items = client.parseDOM(result, "p")

            hosts = client.parseDOM(result, "span", attrs={"style":"color: red;"})

            links = []

            for item in items:
                if 'a href' in item:
                    #log_utils.debug('##>>## item %s' % item, __name__)
                    links.append(item)
            items = zip(hosts, links)

            for item in items:
                self.srcs.extend(self.source(item))

            log_utils.debug('SOURCES [%s]' % sources, __name__)
            return sources
        except Exception as e:
            log_utils.error(e)
            return self.srcs

    def source(self, item):

        title = item[0]
        links = item[1]
        urls = []
        if '720p' in title:
            quality = 'HD'
        else:
            quality = 'SD'

        parts = client.parseDOM(links, "a", ret="href")
        #log_utils.debug('##>>## parts %s' % parts, __name__)
        srcs = []

        for part in parts:
            #log_utils.debug('##>>## part %s' % part, __name__)
            try:
                part = client.request(part)
                part = part.decode('iso-8859-1').encode('utf-8')
                part = client.parseDOM(part, "td", attrs={"style": "vertical-align:middle;text-align:center;"})[0]
                #log_utils.debug('##>>## part %s' % part, __name__)
                tUrl = re.compile('(SRC|src|data-config)=[\'|\"](.+?)[\'|\"]').findall(part)[0][1]
                host = client.host(tUrl)
                urls.append(tUrl)

            except Exception as e:
                log_utils.error(e)
                pass

        url = "##".join(urls)
        srcs.append({'source': host, 'parts': len(urls), 'quality': quality, 'scraper': self.name, 'url': url, 'direct': False})

        return srcs
        
    def getVideoID(self, url):
        try:
            return re.compile('(id|url|v|si|sim|data-config)=(.+?)/').findall(url + '/')[0][1]
        except:
            log_utils.log('yodesi getunpackurl Exception : %s' % (traceback.format_exc()))
            return


    def resolve(self, url):
        # url = genericresolver.resolve(url)
        return url
