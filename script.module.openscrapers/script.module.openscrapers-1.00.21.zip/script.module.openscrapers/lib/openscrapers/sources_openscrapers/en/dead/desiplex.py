# -*- coding: UTF-8 -*-

import re
import traceback

try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import quote_plus

from bs4 import BeautifulSoup, SoupStrainer
from openscrapers.modules import client, log_utils, genericresolver, source_utils


class source:
    domains = ['desiplex.me']
    name = "desiplex"

    def __init__(self):
        self.priority = 3
        self.language = ['en']
        self.name = "desiplex"
        self.domains = ['desiplex.me']
        self.base_link = 'http://www.desiplex.me'
        self.search_link = '/feed/?s=%s&submit=Search'
        self.info_link = '%s/watch/?id=%s'

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log_utils.log("!!!!!!! yodesi \n{} ... \n{} .. \n{}\n {} {} {}  ".format(imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))
        try:
            query = '%s' % (tvshowtitle)
            url = query
            # log_utils.log('>>> #### 0AAAA - yodesi EP url : %s' % ( url))
            return url
        except:
            log_utils.log('yodesi tvshow Exception : %s' % (traceback.format_exc()))
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log_utils.log("!!!!!!! yodesi \n{} ... \n{} .. \n{}\n {} {} {} {} ".format(url, imdb, tvdb, title, premiered, season, episode))
        try:
            query = '%s %s' % (url, episode)
            url = self.base_link + self.search_link % (quote_plus(query))
            return url
        except:
            log_utils.log('yodesi episode Exception : %s' % (traceback.format_exc()))
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        # log_utils.log("!!!!!!! yodesi \n{} ... \n{} .. \n{}".format(url, hostDict, hostprDict))
        try:
            query = '%s %s' % (title, episode)
            query = self.search_link % (quote_plus(query))

            result = client.request(self.base_link + query)
            result = result.decode('iso-8859-1').encode('utf-8')
            result = result.replace('\n', '').replace('\t', '')
            items = client.parseDOM(result, 'content:encoded')[0]
            items = re.compile('class=\"single-heading\">(.+?)<span').findall(items)

            for i in range(0, len(items)):
                try:
                    quality = source_utils.get_qual(str(items[i]))

                    urls = client.parseDOM(items[i], "a", ret="href")
                    for j in range(0, len(urls)):

                        result = client.request(urls[j])
                        item = BeautifulSoup(result, "html.parser", parse_only=SoupStrainer("iframe"))

                        if len(item) == 0:
                            item = re.compile('data-config="(.+?)"').findall(result)[0]
                            item = [{"src":item}]

                        for links in item:
                            rUrl = links["src"]

                            if rUrl.startswith('//'):
                                rUrl = 'http:%s' % rUrl

                            urls[j] = rUrl
                            host = client.host(urls[0])
                    url = 'stack://' + ' , '.join(urls)
                    sources.append({'source': host, 'quality': quality, 'language': 'en', 'info': 'All parts', 'url': url, 'direct': False, 'debridonly': False})
                    urls = []
                except:
                    pass
            return sources
        except:
            return sources


    def resolve(self, url):
        # url = genericresolver.resolve(url)
        return url
