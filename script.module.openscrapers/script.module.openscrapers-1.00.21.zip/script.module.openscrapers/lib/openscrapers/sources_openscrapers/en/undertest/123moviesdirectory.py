# -*- coding: UTF-8 -*-


from openscrapers.modules import client
from openscrapers.modules import cleantitle
from openscrapers.modules import source_utils
from openscrapers.modules import log_utils
from openscrapers.modules.hindi_sources import read_write_file



class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['123movies.directory']
        self.base_link = 'https://123movies.directory'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            movieTitle = cleantitle.geturl(title)
            url = self.base_link + '/%s-%s/' % (movieTitle, year)
            return url
        except Exception:
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = cleantitle.geturl(tvshowtitle)
            return url
        except Exception:
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None:
                return
            # tvshowTitle = url
            link = '%s/episode/%s-season-%s-episode-%s/' % (self.base_link, url, season, episode)
            return link
        except Exception:
            return


    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            hostDict = hostprDict + hostDict
            if url is None: return sources
            # log_utils.log('Addon Testing starting url: ' + repr(url))
            html = client.r_request(url)
            # read_write_file(file_n='test_html.html', read=False, result=html)
            # html = read_write_file(file_n='test_html.html')
            links = client.parseDOM(html, 'iframe', ret='src')
            for link in links:
                link = "https:" + link if not link.startswith('http') else link
                log_utils.log('Addon Testing link: ' + repr(link))
                valid, host = source_utils.is_host_valid(link, hostDict)
                log_utils.log('Addon Testing valid: %s host: %s' % (valid, host))
                if valid:
                    qual, info = source_utils.get_release_quality(link, link)
                    log_utils.log('Addon Testing qual: %s info: %s' % (qual, info))
                    sources.append({'source': host, 'quality': qual, 'language': 'en', 'url': link, 'info': info, 'direct': False, 'debridonly': False})
            return sources
        except Exception:
            log_utils.error('123movies.directory sources exception')
            return sources

    def resolve(self, url):
        return url


