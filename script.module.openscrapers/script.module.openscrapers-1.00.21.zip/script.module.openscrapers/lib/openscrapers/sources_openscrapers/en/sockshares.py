# -*- coding: utf-8 -*-
"""
    **Created by Tempest**
    **If you see this in a addon other than Tempest and says it was
    created by someone other than Tempest they stole it from me**
"""

import re, base64
import traceback
from openscrapers import urlencode, parse_qs, quote_plus, urljoin

from openscrapers.modules import log_utils
from openscrapers.modules import client
from openscrapers.modules import scrape_sources
# from openscrapers.modules import source_utils
from openscrapers.modules.py_tools import ensure_str


class source:
    def __init__(self):
        self.priority = 40
        self.language = ['en']
        self.domains = ['sockshares.tv']
        self.base_link = 'https://sockshares.tv'
        self.search_link = '/search-movies/%s.html'
        self.headers = {'User-Agent': client.agent(), 'Referer': self.base_link}

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None:
                return

            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url is None:
                return sources

            hostDict = hostprDict + hostDict

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            hdlr = '%s Season %s' % (title, data['season']) if 'tvshowtitle' in data else data['year']
            url = self.search_link % quote_plus(title)

            url = urljoin(self.base_link, url)
            r = client.request(url, headers=self.headers)
            # print(r)
            resp = client.parseDOM(r, 'div', attrs={'class': 'thumb'})
            # r = [re.findall(r'<a class="img" href="(.+?)".+?<b>(.+?)</b>.+?\s*.+?\b*\s*</a>\s*.+?<div class="status status-year">(.+?)</div>', i, re.DOTALL)[0] for i in resp]
            items = re.findall(r'<a class="img" href="(.+?)".*?<div class="status">(.+?)</div>.*?<div class="status status-year">(.+?)</div>', str(resp), re.DOTALL)

            for item in items:
                try:
                    if 'tvshowtitle' in data:
                        hdlr = "Season %s" % data['season']
                        if hdlr == item[1]:
                            url = client.request(item[0], headers=self.headers)
                            url = re.findall('href="(.+?)">(.+?)</a>', url)
                            for url in url:
                                if data['episode'] == url[1]:
                                    # print(data['episode'], url)
                                    url = client.request(url[0], headers=self.headers)
                                    url = re.findall('<img src=".+?" width="16" height="16" /> <a href="(.+?)">Version ', url)
                                    i = 0
                                    for r in url:
                                        if i == 15: break
                                        r = client.request(r, headers=self.headers)
                                        r = re.compile(r'Base64\.decode\("(.+?)"').findall(r)
                                        # print("r decode: %s" % r)
                                        for iframe in r:
                                            iframe = base64.b64decode(iframe)
                                            # print("iframe decode: %s" % iframe)
                                            iframe = ensure_str(iframe, errors='replace')
                                            if '<img src' in iframe:
                                                r = re.compile(r'href="(.+?)"').findall(iframe)
                                                for link in r:
                                                    for source in scrape_sources.process(hostDict, link):
                                                        sources.append(source)
                                                    i += 1
                                            else:
                                                r = re.compile(r'src="(.+?)"').findall(iframe)
                                                for link in r:
                                                    for esource in scrape_sources.process(hostDict, link):
                                                        sources.append(esource)
                                                    i += 1
                    else:
                        if title == item[1] and data['year'] in item[2]:
                            url = client.request(item[0], headers=self.headers)
                            url = re.findall('<img src=".+?" width="16" height="16" /> <a href="(.+?)">Version ', url)
                            i = 0
                            for r in url:
                                if i == 20: break
                                r = client.request(r, headers=self.headers)
                                r = re.compile(r'Base64\.decode\("(.+?)"').findall(r)
                                for iframe in r:
                                    iframe = base64.b64decode(iframe)
                                    iframe = ensure_str(iframe, errors='replace')
                                    if '<img src' in iframe:
                                        r = re.compile('href="(.+?)"').findall(iframe)
                                        for link in r:
                                            for source in scrape_sources.process(hostDict, link):
                                                sources.append(source)
                                            i += 1
                                    else:
                                        r = re.compile('src="(.+?)"').findall(iframe)
                                        for link in r:
                                            for esource in scrape_sources.process(hostDict, link):
                                                sources.append(esource)
                                            i += 1
                except:
                    pass

            return sources
        except Exception:
            log_utils.error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        return url

