# -*- coding: utf-8 -*-

import re
import base64

from openscrapers.modules.py_tools import ensure_text
from openscrapers import parse_qs, urljoin, urlencode
from openscrapers.modules import client
from openscrapers.modules import log_utils
from openscrapers.modules import source_utils
from openscrapers.modules import scrape_sources


class source:
    def __init__(self):
        self.priority = 40
        self.results = []
        self.language = ['en']
        self.domains = ['fsapi.xyz']
        self.base_link = 'https://fsapi.xyz'
        self.search_link = '/movie/%s'
        self.search_link2 = '/tv-imdb/%s-%s-%s'
        self.headers = {'User-Agent': client.agent(), 'Referer': self.base_link}

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            if url is None: return self.results
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            if not data['imdb'] or data['imdb'] == '0':
                return self.results
            if 'tvshowtitle' in data:
                url = self.base_link + '/tv-imdb/%s-%s-%s' % (data['imdb'], data['season'], data['episode'])
            else:
                url = self.base_link + '/movie/%s' % data['imdb']
            cookie = client.request(self.base_link, output='cookie', timeout='5')
            html = client.request(url, cookie=cookie)
            matchs = re.findall('''&url=(.+?)" target=''', html)
            for match in matchs:
                match = base64.b64decode(match)
                link = ensure_text(match, errors='ignore')
                if any(i in link for i in ['api.123movie.cc', 'vidsrc.me']):
                    continue
                for source in scrape_sources.process(hostDict, link):
                    self.results.append(source)
            return self.results
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return self.results

    def resolve(self, url):
        # if 'gdriveplayer' in url:
            # url = directstream.googlepass(url)
        return url
