# -*- coding: utf-8 -*-

import atexit
import os
import inspect
import time
from datetime import datetime
from functools import wraps
from traceback import format_stack, print_exc, format_exc

try:
	import xbmc
	from openscrapers.modules.control import getKodiVersion, translate_path, setting as getSetting, lang, joinPath, existsPath, addonInfo
	LOGPATH = translate_path('special://logpath/')
	addonName = addonInfo('name')
	debug_enabled = getSetting('debug.enabled') == 'true'
	debug_level = getSetting('debug.level')
	debug_location = getSetting('debug.location')
	reverse_log = getSetting('debug.reversed') == 'true'
	logger = xbmc.log
except:
	print(f'Error: {print_exc()}')
	addonName = False
if not addonName:
	from os.path import join as joinPath
	from os.path import exists as existsPath
	logger = print
	addonName = "OPENSCRAPERS"
	debug_enabled = True
	debug_location = '0'
	debug_level = '1'
	reverse_log = ''
	LOGPATH = ''
#print(f'LOGPATH: {LOGPATH}\naddonName: {addonName}\ndebug_enabled: {debug_enabled}\ndebug_location: {debug_location}\nreverse_log: {reverse_log}')
LOGDEBUG = 0
LOGINFO = 1
LOGWARNING = 2
LOGERROR = 3
LOGFATAL = 4
LOGNONE = 5  # not used

debug_list = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'FATAL']
prefix = '~~~openscrapers~~~:'

def log(msg, caller=None, level=LOGINFO):

	if not debug_enabled: return
	if isinstance(msg, int): msg = lang(msg) # for strings.po translations
	try:
		# if not msg.isprintable(): # ex. "\n" is not a printable character so returns False on those cases
		# 	msg = f'{normalize(msg)} (NORMALIZED by log_utils.log())'
		if isinstance(msg, bytes):
			msg = f'{msg.decode("utf-8", errors="replace")} (ENCODED by log_utils.log())'
		if caller is not None:
			# fcaller = f'{caller[0]}.{caller[1]}() Line # :{caller[2]}'
			msg = f'From func name: {caller}\n           msg : {msg}'
			if level == LOGERROR: msg = f'{msg}\n\tStack trace (most recent call last):\n{"".join(format_stack())}'
		if level == '0':
			# try: _stack = format_stack()[-3:-2][0]
			# except: _stack = format_stack()
			try: msg_format_stack = format_stack()[-3:-2][0].split("script.module.openscrapers")[1:]
			except: msg_format_stack = format_stack()
			tb = format_exc()
			msg = f'{msg} msg_format_stack: {msg_format_stack}' if tb.startswith("NoneType: None") else f'tb >>> : {tb}\nmsg_format_stack: {msg_format_stack} \n{msg}'
		if debug_location == '1':
			log_file = joinPath(LOGPATH, 'openscrapers.log')
			if not existsPath(log_file):
				f = open(log_file, 'w')
				f.close()
			datestr = str(datetime.now().date())[5:]
			timestr = str(datetime.now().time())[:5]
			if not reverse_log:
				with open(log_file, 'a', encoding='utf-8') as f: # "with" auto cleans up and closes
					line = f'[{datestr} {timestr}] {prefix} {msg}'
					f.write(line.rstrip('\r\n') + '\n')
					# f.writelines([line1, line2]) ## maybe an option for the 2 lines without using "\n"
			else:
				with open(log_file, 'r+', encoding='utf-8') as f:
					line = f'[{datestr} {timestr}] {prefix} {msg}'
					log_file = f.read()
					f.seek(0, 0)
					f.write(line.rstrip('\r\n') + '\n' + log_file)
		else:
			logger(f'{prefix} {msg} level: {debug_list[level]}', level)
	except Exception as e:
		logger(f'Logging Failure: {e} {msg} \ntraceback:{print_exc()}', LOGERROR)


def error(message=None, exception=True):
	try:
		import sys
		if exception:
			type, value, traceback = sys.exc_info()
			addon = 'script.module.openscrapers'
			filename = traceback.tb_frame.f_code.co_filename
			if addon in filename: filename = filename.split(addon)[1]
			name = traceback.tb_frame.f_code.co_name
			linenumber = traceback.tb_lineno
			errortype = type.__name__
			errormessage = value or value.message
			# if not str(errormessage): return
			if message: message += ' -> '
			else: message = ''
			message += f'{str(errortype)} -> {str(errormessage)}'
			caller = [filename, name, linenumber]
			del (type, value, traceback)  # So we don't leave our local labels/objects dangling
		else:
			caller = None
			currentframe = inspect.currentframe()
			func = currentframe.f_back.f_code
			line_number = currentframe.f_back.f_lineno
			message = f'message: {message}\nfrom: {func} line no: {line_number}'
			message = f'error: {message}\n\tStack trace (most recent call last):\n{"".join(format_stack())}'
		log(msg=message, caller=caller, level=LOGERROR)
	except Exception as e:
		log(f'Logging Failure: {e}', level=LOGERROR)

def clear_logFile():
	cleared = False
	try:
		from openscrapers.modules.control import yesnoDialog
		if not yesnoDialog(lang(32060), '', ''): return 'canceled'
		log_file = joinPath(LOGPATH, 'openscrapers.log')
		if not existsPath(log_file):
			f = open(log_file, 'w')
			return f.close()
		with open(log_file, 'r+') as f:
			f.truncate(0) # need '0' when using r
		cleared = True
	except Exception as e:
		logger(f'clear_logFile() Failure: {e}', LOGERROR)
	return cleared

def view_LogFile():
	try:
		from openscrapers.windows.textviewer import TextViewerXML
		from openscrapers.modules.control import addonPath, notification
		name = 'kodi'
		log_file = joinPath(LOGPATH, 'kodi.log')
		if not existsPath(log_file):
			return notification(message='Log File not found, likely logging is not enabled.')
		with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
			text = f.read()
		heading = f'[B]{name} -  LogFile[/B]'
		windows = TextViewerXML('textviewer.xml', addonPath(), heading=heading, text=text)
		windows.run()
		del windows
	except: error()

def upload_LogFile():
	from openscrapers.modules.control import notification,  addonVersion, selectDialog
	import re
	url = 'https://paste.kodi.tv/'
	log_file = joinPath(LOGPATH, 'openscrapers.log')
	if not existsPath(log_file):
		return notification(message='Log File not found, likely logging is not enabled.')
	try:
		import requests
		with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
			text = f.read()
		regex = re.compile(r"Users\\(?<!\w)(.+?)[\\|\/]", re.IGNORECASE)
		text = regex.sub(r'special://', text)
		UserAgent = f'openscrapers {addonVersion()}'
		response = requests.post(f'{url}documents', data=text.encode('utf-8', errors='ignore'), headers={'User-Agent': UserAgent})
		# log(f'log_response={response}')
		if 'key' in response.json():
			result = url + response.json()['key']
			log(f'openscrapers log file uploaded to: {result}')
			from sys import platform as sys_platform
			supported_platform = any(value in sys_platform for value in ('win32', 'linux2'))
			highlight_color = 'gold'
			list = [(f'[COLOR {highlight_color}]url:[/COLOR]  {str(result)}', str(result))]
			if supported_platform: list += [(f'[COLOR {highlight_color}]  -- Copy url To Clipboard[/COLOR]', ' ')]
			select = selectDialog([i[0] for i in list], lang(32059))
			if 'Copy url To Clipboard' in list[select][0]:
				from openscrapers.modules.source_utils import copy2clip
				copy2clip(list[select - 1][1])
		elif 'message' in response.json():
			notification(message=f'openscrapers Log upload failed: {str(response.json()["message"])}')
			log(f'openscrapers Log upload failed: {str(response.json()["message"])}', level=LOGERROR)
		else:
			notification(message='openscrapers Log upload failed')
			log(f'openscrapers Log upload failed: {response.text}', level=LOGERROR)
	except:
		error('openscrapers log upload failed')
		notification(message='pastebin post failed: See log for more info')

def normalize(msg):
	try:
		import unicodedata
		msg = ''.join(c for c in unicodedata.normalize('NFKD', msg) if unicodedata.category(c) != 'Mn')
		return str(msg)
	except:
		error()
		return msg


def debug(func):
	"""
	usage:
	@debug
	def add_numbers(x, y):
		return x + y
	add_numbers(7, y=5,)  # Output: Calling add_numbers with args: (7) kwargs: {'y': 5} \n add_numbers returned: 12
	:param func:
	:type func:
	:return:
	:rtype:
	"""

	@wraps(func)
	def wrapper(*args, **kwargs):
		start = time.time()
		result = None
		log(f'[DEBUG] Calling {func.__name__} with Positional argument {args} and keyword arguments: {kwargs}')
		try: result = func(*args, **kwargs)
		except Exception as e: error(f'Error: {func.__name__} An exception occurred: {e}\n\tStack trace (most recent call last):\n{"".join(format_stack())}')
		log(f'Finished in {time.time() - start:.3f} secs Result: {result} ')
		return result
	return wrapper


class Profiler(object):
	"""Class used to profile a block of code
	useges:
	import Profiler
	_profiler = Profiler(enabled=False, print_callees=False, num_lines=20)
	if debug: profiler.enable(flush=True)
	if debug: profiler.print_stats()
	"""

	__slots__ = ('__weakref__', '_enabled', '_num_lines', '_print_callees', '_profiler', '_reuse', '_timer', 'name',)

	from cProfile import Profile as _Profile
	from pstats import Stats as _Stats

	from io import StringIO as _StringIO
	from functools import wraps as _wraps

	_wraps = staticmethod(_wraps)
	from weakref import ref as _ref

	class Proxy(_ref):
		def __call__(self, *args, **kwargs):
			return super(Profiler.Proxy, self).__call__().__call__(*args, **kwargs)

		def __enter__(self, *args, **kwargs):
			return super(Profiler.Proxy, self).__call__().__enter__(*args, **kwargs)

		def __exit__(self, *args, **kwargs):
			return super(Profiler.Proxy, self).__call__().__exit__(*args, **kwargs)

		def disable(self, *args, **kwargs):
			return super(Profiler.Proxy, self).__call__().disable(*args, **kwargs)

		def enable(self, *args, **kwargs):
			return super(Profiler.Proxy, self).__call__().enable(*args, **kwargs)

		def get_stats(self, *args, **kwargs):
			return super(Profiler.Proxy, self).__call__().get_stats(*args, **kwargs)

		def print_stats(self, *args, **kwargs):
			return super(Profiler.Proxy, self).__call__().print_stats(*args, **kwargs)

		def tear_down(self, *args, **kwargs):
			return super(Profiler.Proxy, self).__call__().tear_down(*args, **kwargs)

	_instances = set()

	def __new__(cls, *args, **kwargs):
		self = super(Profiler, cls).__new__(cls)
		cls._instances.add(self)
		if not kwargs.get('enabled') or kwargs.get('lazy'):
			self.__init__(*args, **kwargs)
			return cls.Proxy(self)
		return self

	def __init__(self, enabled=True, lazy=True, name=__name__, num_lines=20, print_callees=False, reuse=False, timer=None):
		self._enabled = enabled
		self._num_lines = num_lines
		self._print_callees = print_callees
		self._profiler = None
		self._reuse = reuse
		self._timer = timer
		self.name = name

		if enabled and not lazy:
			self._create_profiler()

		atexit.register(self.tear_down)

	def __enter__(self):
		if not self._enabled:
			return

		if not self._profiler:
			self._create_profiler()

	def __exit__(self, exc_type=None, exc_val=None, exc_tb=None):
		if not self._enabled:
			return

		log(f'Profiling stats: {self.get_stats(num_lines=self._num_lines, print_callees=self._print_callees, reuse=self._reuse, )}')
		if not self._reuse:
			self.tear_down()

	def __call__(self, func=None, name=__name__, reuse=False):
		"""Decorator used to profile function calls"""

		if not func:
			self._reuse = reuse
			self.name = name
			return self

		@self.__class__._wraps(func)  # pylint: disable=protected-access
		def wrapper(*args, **kwargs):
			"""Wrapper to:
			   1) create a new Profiler instance;
			   2) run the function being profiled;
			   3) print out profiler result to the log; and
			   4) return result of function call"""

			name = getattr(func, '__qualname__', None)
			if name:
				# If __qualname__ is available (Python 3.3+) then use it
				pass

			elif args and getattr(args[0], func.__name__, None):
				if isinstance(args[0], type):
					class_name = args[0].__name__
				else:
					class_name = args[0].__class__.__name__
				name = '.'.join((class_name, func.__name__,))

			elif func.__class__ and not isinstance(func.__class__, type) and func.__class__.__name__ != 'function':
				name = '.'.join((func.__class__.__name__, func.__name__,))

			elif func.__module__:
				name = '.'.join((func.__module__, func.__name__,))

			else:
				name = func.__name__

			self.name = name
			with self:
				result = func(*args, **kwargs)

			return result

		if not self._enabled:
			self.tear_down()
			return func
		return wrapper

	def _create_profiler(self):
		if self._timer:
			self._profiler = self._Profile(timer=self._timer)
		else:
			self._profiler = self._Profile()
		self._profiler.enable()

	@classmethod
	def wait_timer(cls):
		times = os.times()
		return times.elapsed - (times.system + times.user)

	def disable(self):
		if self._profiler:
			self._profiler.disable()

	def enable(self, flush=False):
		self._enabled = True
		if flush or not self._profiler:
			self._create_profiler()
		else:
			self._profiler.enable()

	def get_stats(self, flush=True, num_lines=20, print_callees=False, reuse=False):
		if not (self._enabled and self._profiler):
			return None

		self.disable()

		output_stream = self._StringIO()
		try:
			stats = self._Stats(self._profiler, stream=output_stream)
			stats.strip_dirs().sort_stats('cumulative', 'time')
			if print_callees:
				stats.print_callees(num_lines)
			else:
				stats.print_stats(num_lines)
			output = output_stream.getvalue()
		# Occurs when no stats were able to be generated from profiler
		except TypeError:
			output = 'Profiler: unable to generate stats'
		finally:
			output_stream.close()

		if reuse:
			# If stats are accumulating then enable existing/new profiler
			self.enable(flush)

		return output

	def print_stats(self):
		log(f'Profiling stats: {self.get_stats(num_lines=self._num_lines, print_callees=self._print_callees, reuse=self._reuse, )}')

	def tear_down(self):
		self.__class__._instances.discard(self)