"""
js_decoder.py

Unified JavaScript decoding utility:
- Dean Edwards P.A.C.K.E.R. unpacking
- JS unescape() decoding
- Recursive percent-string decoding inside JS strings
- Safer normalization and structured logging
- Optional multi-pass decoding

Usage:
    from js_decoder import decode_js

    result = decode_js(obfuscated_js, debug=True, max_passes=3)
"""

from __future__ import annotations

import binascii
import re
import urllib.parse
from typing import Iterable
from openscrapers.modules.log_utils import log

#  JS UNESCAPE DECODER + NORMALIZATION

# Match %xx or %uXXXX
PERCENT_RE = re.compile(r'%(?:[0-9A-Fa-f]{2}|u[0-9A-Fa-f]{4})')

# Match quoted strings that contain percent-escapes
STRING_PERCENT_RE = re.compile(
    r"(['\"])(%[0-9A-Fa-fuU]{2,6}(?:%[0-9A-Fa-fuU]{2,6})*)\1"
)


def _normalize_js_escapes(s: str) -> str:
    """
    Normalize JS escape patterns:
    - Convert %uXXXX → \\uXXXX (Python-compatible)
    - Leave %xx as-is for urllib.parse.unquote
    """
    def repl(match: re.Match) -> str:
        token = match.group(0)
        if token.startswith('%u') or token.startswith('%U'):
            return '\\u' + token[2:]
        return token
    return PERCENT_RE.sub(repl, s)


def _decode_unicode_escapes(s: str, errors: str) -> str:
    """
    Decode Python-style \\uXXXX sequences.
    """
    try:
        return s.encode('utf-8').decode('unicode_escape', errors=errors)
    except Exception as e:
        log(f'unicode_escape decode failed: {e}')
        return s


def js_unescape(payload: str | bytes, *, errors: str = "replace", extra_fallbacks: Iterable[str] = (), debug: bool = False) -> str:
    """
    Decode JavaScript-style unescape() payloads with:
    - %xx decoding
    - %uXXXX decoding
    - Normalization passes
    - Fallback chains
    """
    if isinstance(payload, bytes):
        payload = payload.decode("latin-1", errors="ignore")

    if debug: log(f'js_unescape: start {len(payload)}', )

    normalized = _normalize_js_escapes(payload)
    if debug and normalized != payload:
        log(f'js_unescape: normalized from {payload} to {normalized}')

    try:
        decoded = urllib.parse.unquote(normalized)
    except Exception as e:
        log(f'js_unescape: urllib.parse.unquote failed: {e}')
        decoded = normalized

    decoded2 = _decode_unicode_escapes(decoded, errors=errors)
    if debug and decoded2 != decoded:
        log(f'js_unescape: unicode_escape changed {decoded} to {decoded2}')

    for enc in extra_fallbacks:
        try:
            alt = decoded2.encode("latin-1").decode(enc, errors=errors)
            if debug and alt != decoded2:
                log(f'js_unescape: fallback {enc} changed {decoded2} to {alt}')
            return alt
        except Exception as e: log(f'js_unescape: fallback {enc} failed: {e}')

    return decoded2


def decode_percent_strings(source: str, *, debug: bool = False) -> str:
    """
    Recursively decode any quoted string that contains percent-escapes.
    Example: "A('%41%42%43')" → "A('ABC')"
    """

    def repl(match: re.Match) -> str:
        quote, encoded = match.groups()
        decoded = js_unescape(encoded, debug=debug)
        if debug and decoded != encoded:
            log(f'decode_percent_strings: {encoded} -> {decoded}')
        return f"{quote}{decoded}{quote}"

    return STRING_PERCENT_RE.sub(repl, source)


#  P.A.C.K.E.R. DETECTION + UNPACKING

# Improved detection: tolerate whitespace, comments, and minor variations
PACKER_DETECT_RE = re.compile(
    r"eval\s*\(\s*function\s*\(\s*p\s*,\s*a\s*,\s*c\s*,\s*k\s*,\s*e\s*,\s*d?\s*\)",
    re.I
)


def detect(source: str) -> bool:
    """
    Detect whether `source` looks like Dean Edwards' P.A.C.K.E.R.
    """
    return PACKER_DETECT_RE.search(source) is not None


def _filterargs(source: str):
    """
    Extract the four args needed by the P.A.C.K.E.R. decoder.
    Handles typical patterns like:
        }('payload', radix, count, 'symtab'.split('|'))
    """
    argsregex = r"}\s*\('(.*)',\s*(.*?),\s*(\d+),\s*'(.*?)'\.split\('\|'\)"
    match = re.search(argsregex, source, re.DOTALL)
    if not match:
        raise UnpackingError("Unable to extract P.A.C.K.E.R. arguments.")
    payload, radix, count, symtab = match.groups()
    radix = 36 if not radix.isdigit() else int(radix)
    return payload, symtab.split('|'), radix, int(count)


def _replacestrings(source: str) -> str:
    """
    Strip string lookup table (list) and replace values in source.
    """
    match = re.search(r'var *(_\w+)= \["(.*?)"\] ;', source, re.DOTALL)
    if not match: return source

    varname, strings = match.groups()
    startpoint = len(match.group(0))
    lookup = strings.split('","')
    variable = f"{varname}[%d]"

    for index, value in enumerate(lookup):
        if '\\x' in value:
            raw = value.replace('\\x', '')
            try:
                value = binascii.unhexlify(raw).decode('ascii', errors='replace')
            except Exception: pass
        source = source.replace(variable % index, f'"{value}"')

    return source[startpoint:]


def _replacejsstrings(source: str) -> str:
    """
    Strip JS string encodings like \\xNN and replace values in source.
    """
    matches = set(re.findall(r'\\x([0-7][0-9A-F])', source))
    for value in matches:
        try:
            decoded = binascii.unhexlify(value).decode('ascii', errors='replace')
            source = source.replace(f'\\x{value}', decoded)
        except Exception: continue
    return source


class Unbaser:
    """
    Functor for a given base. Converts strings to integers.
    """
    ALPHABET = {
        62: '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
        95: r' !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ' r'[\] ^_`abcdefghijklmnopqrstuvwxyz{|}~'
    }

    def __init__(self, base: int):
        self.base = base

        if 2 <= base <= 36:
            self.unbase = lambda s: int(s, base)
            return

        if base < 62:
            self.ALPHABET[base] = self.ALPHABET[62][:base]
        elif 62 < base < 95:
            self.ALPHABET[base] = self.ALPHABET[95][:base]

        try:
            self.dictionary = {c: i for i, c in enumerate(self.ALPHABET[base])}
        except KeyError: raise TypeError('Unsupported base encoding.')

        self.unbase = self._dictunbaser

    def _dictunbaser(self, string: str) -> int:
        return sum(
            (self.base ** idx) * self.dictionary[c]
            for idx, c in enumerate(string[::-1])
        )

    def __call__(self, string: str) -> int:
        return self.unbase(string)


class UnpackingError(Exception):
    """Badly packed source or general error."""
    pass


def unpack_packer(source: str, *, debug: bool = False) -> str:
    """
    Unpack P.A.C.K.E.R.-packed JS code.
    """
    payload, symtab, radix, count = _filterargs(source)

    if count != len(symtab):
        raise UnpackingError("Malformed P.A.C.K.E.R. symtab.")

    try:
        unbase = Unbaser(radix)
    except TypeError as e:
        raise UnpackingError(f"Unknown P.A.C.K.E.R. encoding: {e}") from e

    def lookup(match: re.Match) -> str:
        word = match.group(0)
        try:
            if radix == 1:
                idx = int(word)
            else:
                idx = unbase(word)
            return symtab[idx] or word
        except Exception:
            return word

    payload = payload.replace("\\\\", "\\").replace("\\'", "'")

    # Detect newer variant using String.fromCharCode
    p = re.search(r'String\.fromCharCode\(([^)]+)', source)
    if p:
        # Heuristic: if it uses 161 offset, use getstring
        parts = re.findall(r'String\.fromCharCode\(([^)]+)', source)
        uses_161 = any('+161' in part or '161+' in part for part in parts)

        if uses_161:
            if debug: log('unpack_packer: using getstring variant')

            def getstring(c: int, a: int = radix) -> str:
                ch = chr(c % a + 161)
                return ch if c < a else getstring(c // a, a) + ch

            for i in range(count - 1, -1, -1):
                try:
                    payload = payload.replace(getstring(i), symtab[i])
                except Exception:
                    continue

            return _replacejsstrings(_replacestrings(payload))

    # Classic variant
    if debug: log('unpack_packer: using classic lookup variant')

    replaced = re.sub(r"\b\w+\b", lookup, payload, flags=re.ASCII)
    return _replacestrings(replaced)


#  UNIFIED MULTI-PASS DECODER

def unpack(source: str, *, debug: bool = False, max_passes: int = 3) -> str:
    """
    Unified decoding pipeline with optional multi-pass behavior.
    Pass (repeated up to max_passes):
      1. If P.A.C.K.E.R. detected, try to unpack.
      2. Decode percent-encoded strings inside quotes.
      3. Run js_unescape on the whole source.
    Stops early if a pass makes no changes.
    """
    if debug: log(f'decode_js: start, max_passes={max_passes}', )

    prev = None
    current = source

    for i in range(max_passes):
        if debug: log(f'decode_js: pass {i + 1}')

        changed = False

        # 1. P.A.C.K.E.R. unpacking
        if detect(current):
            if debug: log(f'decode_js: P.A.C.K.E.R. detected on pass {i + 1}')
            try:
                unpacked = unpack_packer(current, debug=debug)
                if unpacked != current:
                    if debug: log('decode_js: unpack_packer changed content')
                    current = unpacked
                    changed = True
            except Exception as e: log(f'decode_js: unpack_packer failed on pass {i + 1}: {e}')

        # 2. Recursive percent-string decoding
        new_current = decode_percent_strings(current, debug=debug)
        if new_current != current:
            if debug: log('decode_js: decode_percent_strings changed content')
            current = new_current
            changed = True

        # 3. Whole-source js_unescape
        new_current = js_unescape(current, debug=debug)
        if new_current != current:
            if debug: log('decode_js: js_unescape changed content')
            current = new_current
            changed = True

        if not changed:
            if debug: log(f'decode_js: no changes on pass {i + 1}, stopping')
            break

        if prev is not None and current == prev:
            if debug: log('decode_js: stabilized between passes, stopping')
            break

        prev = current

    return current


# if __name__ == "__main__":
#     test = '''eval(function(p,a,c,k,e,d){while(c--)if(k[c])p=p.replace(new RegExp('\\b'+c.toString(a)+'\\b','g'),k[c]);return p}('4(\'30\').2z({2y:\'5://a.8.7/i/z/y/w.2x\',2w:{b:\'2v\',19:\'<p><u><2 d="20" c="#17">2u 19.</2></u><16/><u><2 d="18" c="#15">2t 2s 2r 2q.</2></u></p>\',2p:\'<p><u><2 d="20" c="#17">2o 2n b.</2></u><16/><u><2 d="18" c="#15">2m 2l 2k 2j.</2></u></p>\',},2i:\'2h\',2g:[{14:"11",b:"5://a.8.7/2f/13.12"},{14:"2e",b:"5://a.8.7/2d/13.12"},],2c:"11",2b:[{10:\'2a\',29:\'5://v.8.7/t-m/m.28\'},{10:\'27\'}],26:{\'25-3\':{\'24\':{\'23\':22,\'21\':\'5://a.8.7/i/z/y/\',\'1z\':\'w\',\'1y\':\'1x\'}}},s:\'5://v.8.7/t-m/s/1w.1v\',1u:"1t",1s:"1r",1q:\'1p\',1o:"1n",1m:"1l",1k:\'5\',1j:\'o\',});l e;l k=0;l 6=0;4().1i(9(x){f(6>0)k+=x.r-6;6=x.r;f(q!=0&&k>=q){6=-1;4().1h();4().1g(o);$(\'#1f\').j();$(\'h.g\').j()}});4().1e(9(x){6=-1});4().1d(9(x){n(x)});4().1c(9(){$(\'h.g\').j()});9 n(x){$(\'h.g\').1b();f(e)1a;e=1;}',36,109,'||font||jwplayer|http|p0102895|me|vidto|function|edge3|file|color|size|vvplay|if|video_ad|div||show|tt102895|var|player|doPlay|false||21600|position|skin|test||static|1y7okrqkv4ji||00020|01|type|360p|mp4|video|label|FFFFFF|br|FF0000||deleted|return|hide|onComplete|onPlay|onSeek|play_limit_box|setFullscreen|stop|onTime|dock|provider|391|height|650|width|over|controlbar|5110|duration|uniform|stretching|zip|stormtrooper|213|frequency|prefix||path|true|enabled|preview|timeslidertooltipplugin|plugins|html5|swf|src|flash|modes|hd_default|3bjhohfxpiqwws4phvqtsnolxocychumk274dsnkblz6sfgq6uz6zt77gxia|240p|3bjhohfxpiqwws4phvqtsnolxocychumk274dsnkba36sfgq6uzy3tv2oidq|hd|original|ratio|broken|is|link|Your|such|No|nofile|more|any|availabe|Not|File|OK|previw|jpg|image|setup|flvplayer'.split('|')))'''
    # test = '''eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('y.x(A(\'%0%f%b%9%1%d%8%8%o%e%B%c%0%e%d%0%f%w%1%7%3%2%p%d%1%n%2%1%c%0%t%0%f%7%8%8%d%5%6%1%7%e%b%l%7%1%2%e%9%q%c%0%6%1%z%2%0%f%b%1%9%c%0%s%6%6%l%G%4%4%5%5%5%k%b%7%5%8%o%i%2%k%6%i%4%2%3%p%2%n%4%5%7%6%9%s%4%j%q%a%h%a%3%a%E%a%3%D%H%9%K%C%I%m%r%g%h%L%v%g%u%F%r%g%3%J%3%j%3%m%h%4\'));',48,48,'22|72|65|6d|2f|77|74|61|6c|63|4e|73|3d|6f|6e|20|4d|32|76|59|2e|70|51|64|69|62|79|31|68|30|7a|34|66|write|document|75|unescape|67|4f|5a|57|55|3a|44|47|4a|78|49'.split('|'),0,{}))'''
    # test = '''eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('x.w(z(\'%1%f%9%b%0%d%7%7%m%e%A%c%1%e%d%1%f%v%0%3%i%2%o%d%0%s%2%0%c%1%q%1%f%3%7%7%d%6%5%0%3%e%9%l%3%0%2%e%b%g%c%1%5%0%y%2%1%f%9%0%b%c%1%r%5%5%l%E%4%4%6%6%6%n%9%3%6%7%m%k%2%n%5%k%4%2%i%o%2%s%4%6%3%5%b%r%4%8%D%h%C%a%F%8%H%B%I%h%i%a%g%8%u%a%q%j%t%j%g%8%t%h%p%j%p%a%G%4\'));',45,45,'72|22|65|61|2f|74|77|6c|5a|73|55|63|3d|6f|6e|20|79|59|6d|4d|76|70|69|2e|62|7a|30|68|64|44|54|66|write|document|75|unescape|67|51|32|6a|3a|35|5f|47|34'.split('|'),0,{}))'''
    # test = '''eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('q.r(s(\'%h%t%a%p%u%6%c%n%0%5%l%4%2%4%7%j%0%8%1%o%b%3%7%m%1%8%a%7%b%3%d%6%1%f%0%v%1%5%D%9%0%5%c%g%0%4%A%9%0%f%k%z%2%8%1%C%2%i%d%6%2%3%k%j%2%3%y%e%x%w%g%B%E%F%i%h%e\'));',42,42,'5a|4d|4f|54|6a|44|33|6b|57|7a|56|4e|68|55|3e|47|69|65|6d|32|45|46|31|6f|30|75|document|write|unescape|6e|62|6c|2f|3c|22|79|63|66|78|59|72|61'.split('|'),0,{}))'''
    # test = r"y.x(A('%22%20%73%63%72%6f%6c%6c%69%6e%67%3d%22%6e%6f%22'))"
    # print(unpack(test, debug=True))
