import time
import socket
import ssl
from random import shuffle, uniform
from typing import Any, Dict, Optional, Protocol

import requests
from requests.adapters import HTTPAdapter
from urllib3 import PoolManager
from urllib3.connection import HTTPSConnection, HTTPConnection
from urllib3.connectionpool import HTTPSConnectionPool, HTTPConnectionPool
from urllib3.util import Retry
from urllib3.exceptions import ProtocolError

from openscrapers.modules.log_utils import error as lerror, log


class SmartRetry(Retry):
    """
    Retry policy with:
    - custom backoff
    - DNS failure exclusion
    - deterministic behavior
    """

    def is_dns_failure(self, error):
        return (
            isinstance(error, ProtocolError)
            and isinstance(error.__cause__, socket.gaierror)
        )

    def increment(self, method=None, url=None, response=None, error=None, _pool=None, _stacktrace=None):
        # Skip retries for DNS resolution failures
        if error and self.is_dns_failure(error):
            raise error

        return super().increment(method=method, url=url, response=response, error=error, _pool=_pool, _stacktrace=_stacktrace,)

    def get_backoff_time(self):
        """
        Custom exponential backoff with jitter.
        """
        # Standard exponential backoff
        base = super().get_backoff_time()
        # Add jitter (0–100ms)
        jitter = uniform(0, 0.1)
        return base + jitter


# SSL CONTEXT HELPERS

def get_ciphers():
    SSL_CIPHERS = ['TLS_AES_256_GCM_SHA384', 'TLS_CHACHA20_POLY1305_SHA256', 'TLS_AES_128_GCM_SHA256', 'ECDHE-ECDSA-AES256-SHA384', 'ECDHE-RSA-AES256-SHA384', 'ECDHE-ECDSA-AES128-SHA256', 'ECDHE-RSA-AES128-SHA256', 'DHE-RSA-AES256-GCM-SHA384', 'DHE-RSA-AES128-GCM-SHA256', 'DHE-RSA-AES256-SHA256', 'DHE-RSA-AES128-SHA256', 'ECDHE-ECDSA-AES128-GCM-SHA256', 'ECDHE-ECDSA-AES256-GCM-SHA384', 'ECDHE-ECDSA-CHACHA20-POLY1305', 'ECDHE-RSA-AES128-GCM-SHA256', 'ECDHE-RSA-AES256-GCM-SHA384', 'ECDHE-RSA-CHACHA20-POLY1305', 'ECDHE-ECDSA-AES128-SHA', 'ECDHE-ECDSA-AES256-SHA', 'ECDHE-RSA-AES128-SHA', 'ECDHE-RSA-AES256-SHA', 'AES128-GCM-SHA256', 'AES256-GCM-SHA384', 'AES128-SHA', 'AES256-SHA', '!eNULL', '!MD5', '!aNULL']
    shuffle(SSL_CIPHERS)
    SSL_CIPHERS = ':'.join(SSL_CIPHERS)
    SSL_CIPHERS = SSL_CIPHERS + '@SECLEVEL=0'
    return SSL_CIPHERS

SSL_CIPHERS = get_ciphers()


def create_relaxed_context(cafile: Optional[str] = None) -> ssl.SSLContext:
    ctx = ssl.create_default_context(cafile=cafile)

    for flag in ("VERIFY_X509_STRICT", "VERIFY_X509_PARTIAL_CHAIN"):
        if hasattr(ssl, flag):
            ctx.verify_flags &= ~getattr(ssl, flag)

    ctx.set_ciphers(SSL_CIPHERS)
    return ctx


def conext_http(verify: bool = True) -> ssl.SSLContext:
    try:
        from openscrapers.modules.control import get_kodi_certi_file
        cafile = get_kodi_certi_file()
    except:
        import certifi
        # cafile = r'F:\py_charm_proj\py_proj\.venv\Lib\site-packages\certifi\cacert.pem'
        cafile = certifi.where()

    if verify:
        ctx = create_relaxed_context(cafile=cafile)
        ctx.check_hostname = True
        ctx.verify_mode = ssl.CERT_REQUIRED
    else:
        ctx = ssl._create_unverified_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

    if hasattr(ssl, "OP_NO_RENEGOTIATION"):
        ctx.options |= ssl.OP_NO_RENEGOTIATION
    if hasattr(ssl, "OP_ENABLE_MIDDLEBOX_COMPAT"):
        ctx.options |= ssl.OP_ENABLE_MIDDLEBOX_COMPAT

    try: ctx.set_alpn_protocols(["http/1.1"])
    except NotImplementedError: pass

    # log(f'SSLContext created: verify={verify} cafile={cafile}')
    return ctx


# TIMING MIXIN

class _HasWrapSocket(Protocol):
    def _wrap_socket(self, sock, **kwargs) -> Any: ...


class TimingMixin:
    _timings: Dict[str, float]

    def _wrap_socket(self: _HasWrapSocket, sock, **kwargs) -> Any:
        start = time.perf_counter()
        wrapped = super()._wrap_socket(sock, **kwargs)  # type: ignore[misc]
        tls_time = time.perf_counter() - start
        self._timings["tls"] = tls_time
        log(f'TLS handshake: {tls_time:.4f} sec ({self.host}:{self.port})')  # type: ignore[attr-defined]
        return wrapped

    def connect(self) -> None:
        self._timings = {}

        dns_start = time.perf_counter()
        socket.getaddrinfo(self.host, self.port)  # type: ignore[attr-defined]
        dns_time = time.perf_counter() - dns_start
        self._timings["dns"] = dns_time
        # log(f'DNS lookup: {dns_time:.4f} sec ({self.host})')  # type: ignore[attr-defined]

        tcp_start = time.perf_counter()
        super().connect()  # type: ignore[misc]
        tcp_time = time.perf_counter() - tcp_start
        self._timings["tcp"] = tcp_time
        # log(f'TCP connect: {tcp_time:.4f} sec ({self.host}:{self.port})')  # type: ignore[attr-defined]


class TimingHTTPConnection(TimingMixin, HTTPConnection):
    pass


class TimingHTTPSConnection(TimingMixin, HTTPSConnection):
    pass


# MERGED SSL + TIMING + DEBUG + PER‑REQUEST OVERRIDE

class SSLContextAdapter(HTTPAdapter):
    """
    HTTPS adapter with:
      - SSLContext injection
      - DNS/TCP/TLS timing
      - Structured debug logging
      - Per‑request debug override (request.debug)
    """

    def __init__(
        self,
        ssl_context: Optional[ssl.SSLContext] = None,
        debug: bool = False,
        **kwargs: Any,
    ) -> None:
        self.ssl_context = ssl_context
        self.debug = debug
        super().__init__(**kwargs)

    # --- Pool Manager -------------------------------------------------------

    def init_poolmanager(self, connections: int, maxsize: int, block: bool = False, **pool_kwargs: Any) -> None:
        pool_kwargs["ssl_context"] = self.ssl_context

        self.poolmanager = PoolManager(num_pools=connections, maxsize=maxsize, block=block, **pool_kwargs,)

        if self.debug:
            log(f'PoolManager initialized: pools={connections} maxsize={maxsize}')

    def proxy_manager_for(self, proxy: str, **proxy_kwargs: Any) -> PoolManager:
        proxy_kwargs["ssl_context"] = self.ssl_context
        return super().proxy_manager_for(proxy, **proxy_kwargs)

    # --- Connection Selection -----------------------------------------------

    def get_connection(self, url: str, proxies: Optional[Dict[str, str]] = None) -> HTTPConnectionPool:
        conn = super().get_connection(url, proxies)

        if isinstance(conn, HTTPSConnectionPool):
            conn.ConnectionCls = TimingHTTPSConnection
        else:
            conn.ConnectionCls = TimingHTTPConnection

        return conn

    # --- Timing + Per‑Request Debug ----------------------------------------

    def send(self, request, **kwargs: Any) -> requests.Response:  # type: ignore[override]
        # Per‑request override:
        #   session.debug = False
        #   request.debug = True  → logs enabled for this request only
        req_debug = getattr(request, "debug", None)
        effective_debug = req_debug if req_debug is not None else self.debug

        if effective_debug: log(f'Sending request: {request.method} {request.url}\nRequest headers: {request.headers}')

        start = time.perf_counter()
        response: requests.Response = super().send(request, **kwargs)
        end = time.perf_counter()

        conn = getattr(response.raw, "_connection", None)
        timings: Dict[str, float] = getattr(conn, "_timings", {}) if conn else {}

        first_byte = float(response.raw.tell()) if hasattr(response.raw, "tell") else 0.0
        timings["first_byte"] = first_byte
        timings["total"] = end - start

        setattr(response, "_timings", timings)

        if effective_debug:
            log(f'Timing breakdown for {request.url}:')
            for k, v in timings.items():
                log(f'  {k:<12} {v:.4f}')

        return response


# SESSION BUILDER

def build_session(url: str = "https://", verify: bool = True, debug: bool = False,) -> requests.Session:
    session = requests.Session()

    ctx = conext_http(verify)

    retry = SmartRetry(
        total=2,
        connect=3,
        read=3,
        status=3,
        backoff_factor=0.5,
        status_forcelist=(429, 502, 503, 504),
        # allowed_methods=False,  # retry all methods
        raise_on_status=False,
        respect_retry_after_header=True,
    )

    adapter = SSLContextAdapter(ssl_context=ctx, max_retries=retry, pool_maxsize=40, debug=debug,)

    session.mount("http://", adapter)
    session.mount("https://", adapter)
    session.max_redirects = 10

    # log(f'Session built for base URL: {url} (verify={verify}, debug={debug})')
    return session
