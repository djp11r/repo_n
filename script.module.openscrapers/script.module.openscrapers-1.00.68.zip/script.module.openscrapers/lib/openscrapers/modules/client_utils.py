# -*- coding: utf-8 -*-
import re
import json
from base64 import b64decode
from html import unescape
try:
    from openscrapers.modules.py_tools import ensure_str
    from openscrapers.modules.dom_parser import parseDOM
    from openscrapers.modules import jsunpack
    from openscrapers.modules import unjuice
    from openscrapers.modules.jsunhunt import unhunt
    from openscrapers.modules.utils import byteify
    from openscrapers.modules.log_utils import error, log
except:
    from modules.py_tools import ensure_str
    from modules.dom_parser import parseDOM
    from modules import jsunpack
    from modules import unjuice
    from modules.jsunhunt import unhunt
    from modules.utils import byteify
    from modules.log_utils import error, log


regex_pattern1 = r'(?:iframe|source).+?(?:src)["\']?\s*[:=]?\s*["\']([^"\']+)'
regex_pattern2 = r'(?:data-video|data-src|data-href)=(?:\"|\')(.+?)(?:\"|\')'
regex_pattern3 = r'''(?:source|file)['"]*\s*[:=]?\s*["']([^"']+)'''
regex_pattern4 = r'''(magnet:\?[^"']+)'''
regex_pattern5 = r'<[iI][fF][rR][aA][mM][eE].+?[sS][rR][cC]="(.+?)"'
regex_pattern6 = r'''(?:file|src)['"]*\s*[:=]?\s*["']([^"']+)'''
regex_pattern7 = r'''(?:file|src)['"]*\s*[:=]?\s*["']([^"']+)'''
regex_pattern8 = r'''(?:file|src)['"]*\s*[:=]?\s*["']([^"']+)'''
regex_pattern9 = r'''(?:source)['"]*\s*[:=]?\s*["']([^"']+)'''
regex_pattern10 = r'\{(.+?)\}'
regex_pattern11 = re.compile(r'''(?:source|src|file)['"]*\s*[:=]?\s*["']([^"']+)''', flags=re.DOTALL+re.I)
regex_pattern12 = re.compile(r'''(?s)script>\s*var.*?"([^"]*)''', flags=re.DOTALL+re.I)
regex_pattern13 = re.compile(r'''(var .*?\s*=\s*["'].+?['"];)''', re.DOTALL)


def regexExtract(data, expression, group=1, all=False, flags=re.I):
    try:
        if all:
            match = re.findall(expression, data, flags=flags)
            if group is None: return match
            else: return match[group]
        else:
            match = re.search(expression, data, flags=flags)
            if group is None: return match.groups()
            else: return match.group(group)
    except: return None


def re_findall(html, regex):
    return re.findall(regex, html)


def re_compile(html, regex):
    return re.compile(regex).findall(html)


def unpacked(html):
    return jsunpack.get_2packed_data(html) if jsunpack.detect(html) else ''


def unpacked2(html):
    packed_data = ''
    if jsunpack.detect(html):
        for match in re.finditer(r'''(eval\s*\(function\(p,a,c,k,e,.*?)</script>''', html, re.DOTALL | re.I):
            r = match.group(1)
            t = re.findall(r'(eval\s*\(function\(p,a,c,k,e,)', r, re.DOTALL | re.IGNORECASE)
            if len(t) == 1:
                if jsunpack.detect(r):
                    packed_data += jsunpack.unpack(r)
            else:
                t = r.split('eval')
                t = [f'eval{x}' for x in t if x]
                for r in t:
                    if jsunpack.detect(r):
                        packed_data += jsunpack.unpack(r)
    return packed_data


def unjuiced2(html):
    unjuiced = ''
    if unjuice.test(html):
        for match in re.finditer(r'(_juicycodes\(.+?[;\n<])|(JuicyCodes.Run\([^\)]+)', html, re.DOTALL | re.I):
            unjuiced += unjuice.run(match.group(1))
    return unjuiced


def remove_tags(text):
    TAG_RE = re.compile(r'<[^>]+>')
    return TAG_RE.sub('', text)


def remove_codes(string):
    remove = re.compile(r'<.+?>')
    string = re.sub(remove, '', string)
    return string


def replace_html_entities(string):
    items = (('â\x80\x99', '\''), ('\\/', '/'), ('///', '//'), ('&nbsp;', ''), ('&#8230;', '...'), ('&#8217;', "\'"), ('%2B', '+'), ('&#8211;', '-'), ('&lt;', '<'), ('&#60;', '<'), ('&gt;', '>'), ('&#62;', '>'), ('&amp;', '&'), ('&#38;', '&'), ('&#038;', '&'), ('&quot;', '"'), ('&#34;', '"'), ('&apos;', "'"), ('&#39;', "'"))
    for item in items:
        string = string.replace(item[0], item[1])
    return string


def replaceHTMLCodes(txt):
    # Some HTML entities are encoded twice. Decode double.
    return _replaceHTMLCodes(_replaceHTMLCodes(txt))


def _replaceHTMLCodes(txt):
    try:
        if not txt: return ''
        txt = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', txt) # fix html codes with missing semicolon
        txt = re.sub(r'[^\x00-\x7f]',r'', txt) # remove all non-ASCII
        txt = unescape(txt)
        txt = replace_html_entities(txt)
        # txt = re.sub(r'\\[nrt]', '', txt)
        txt = txt.strip()
        return ensure_str(txt)
    except:
        error('_replaceHTMLCodes Error: ')
        return txt


def cleanHTML(txt):
    txt = re.sub(r'<.+?>|</.+?>|\n', '', txt)
    return replaceHTMLCodes(txt)

def clean_html(txt):
    txt = txt.replace('&quot;', '\"')
    txt = txt.replace('&amp;', '&')
    txt = txt.replace('\\n','')
    txt = txt.replace('\\t', '')
    txt = txt.replace('\\', '')
    txt = ' '.join(txt.split())
    return ensure_str(txt)


def removeNonAscii(s):
    return ''.join(i for i in s if ord(i) < 128)


def json_loads_as_str(json_text):
    return byteify(json.loads(json_text, object_hook=byteify), ignore_dicts=True)


def get_jsunpack_unjuice(shtml):
    if unjuice.test(shtml): shtml += unjuice.run(shtml)
    if jsunpack.detect(shtml): shtml += jsunpack.get_2packed_data(shtml)
    return shtml


def scan_html(html):
    patterns = {
        'source src file': r'''(?:source|src|file)['"]?\s*[:=]?\s*['"](.+?\.m3u8)(?:"|')''',
        'var script': r'''(?s)script>\s*var.*?"([^"]*)''',
        'source object': r'''source\s*:\s+?(?:"|'|`)(.+?)(?:"|'|`)''',
        'var source': r'''var source.?=.?(?:\"|'|`)(.+?)(?:\"|'|`)",''',
        'quoted URL': r'''(?:"|')(http.*?\.m3u8.*?)(?:"|')''',
        'base64 URL': r'''atob\((?:"|')((?:aHR|Ly).+?)(?:"|')''',
        'packed JS': r'''(eval\(function\(p,a,c,k,e,d\).+?{}\)\)'''
    }

    res = None

    for pattern_name, pattern in patterns.items():
        matches = re.findall(pattern, html)
        if matches:
            for match in matches:
                if pattern_name == 'var script' or pattern_name == 'base64 URL':
                    match = b64decode(match).decode("ascii")
                if pattern_name == 'packed JS':
                    for packed in matches:
                        unpacked = jsunpack.unpack(packed)
                        res = scan_html(unpacked)
                        if res: break
                if '.m3u8' in match:
                    res = match
                    break
                if any(ext in match for ext in [".css", ".js", "load-playlist"]):
                    match = match.replace('.css', '.m3u8').replace('.js', '.m3u8')
                    res = match
                    break
        if res: break

    if isinstance(res, str) and res.startswith("//"): res = f'https:{res}'
    return res


def scan_htmlo(html):
    patterns = {
        'source src file': r'''(?:source|src|file)['"]?\s*[:=]?\s*['"](.+?\.m3u8)(?:"|')''',
        'var script': r'''(?s)script>\s*var.*?"([^"]*)''',
        'source object': r'''source\s*:\s+?(?:"|'|`)(.+?)(?:"|'|`)''',
        'var source': r'''var source.?=.?(?:\"|'|`)(.+?)(?:\"|'|`)",''',
        'quoted URL': r'''(?:"|')(http.*?\.m3u8.*?)(?:"|')'''}
    res = None
    for pattern_name, pattern in patterns.items():
        matches = re.findall(pattern, html)
        if matches:
            for match in matches:
                if pattern_name == 'var script':
                    match = b64decode(match).decode("ascii")
                if '.m3u8' in match:
                    res = match
                    break
                if ".css" in match or ".js" in match or "load-playlist" in match:
                        if ".css" in match: match = match.replace('.css', '.m3u8')
                        elif ".js" in match: match = match.replace('.js', '.m3u8')
                        res = match
                        break
    if not res:
        patterns2 = {'base64 URL': r'''atob\((?:"|')((?:aHR|Ly).+?)(?:"|')''',
                     'packed JS': r'''(eval\(function\(p,a,c,k,e,d\).+?{}\)\)'''}
        for pattern_name, pattern in patterns2.items():
            matches = re.findall(pattern, html)
            if matches:
                if pattern_name in ['base64 URL']:
                    for match in matches:
                        b64 = b64decode(match).decode("ascii")
                        # Some sites like to hide the m3u8 in a .js or .css file
                        if '.m3u8' in match:
                            res = match
                            break
                        if ".css" in match or ".js" in match or "load-playlist" in match:
                                if ".css" in match: match = match.replace('.css', '.m3u8')
                                elif ".js" in match: match = match.replace('.js', '.m3u8')
                                res = match
                                break
                if pattern_name == 'packed JS':
                    packed = unpacked(html)#jsunpack.unpack(re_packed[0])
                    res = scan_html(packed)
                if res: break
    if type(res) == str and res.startswith("//"): res = f'https:{res}'
    return res


def get_link(resp):
    patterns = [
        r'''(https?:\/\/\S+\.m3u8)''',
        r'''(?:file)["']?\s*[:=]?\s*["']([^"']+)''',
        r'''(?s)script>\s*var.*?"([^"]*)''',
        r'''"(aHR0.+?)"''',
        r'''encryptedSource\s*=\s*"(.+?)"''',
        r"source:\s*'(.+?)'"
    ]

    link = None
    for pattern in patterns:
        match = re.search(pattern, resp)
        if match:
            link = match.group(1)
            # log(f'get_link pattern: {pattern}\nlink: {link}')
            if link and '.m3u8' not in link:
                try:
                    elink = b64decode(link).decode('utf-8', errors='ignore')  # Decode base64-encoded link (if applicable)
                    if elink.startswith('://'): link = f'https{elink[1]}'
                except Exception as err: error(f'get_link link: {link} err: {err}')
            if '.m3u8' in link: break
    if not link: log(f'get_link resp: {resp}')
    return link or None


def get_ltv_link(resp):
    links = regex_pattern11.findall(resp)
    # log(f'play provider links: {links}\nresp: {resp}')
    links = [x for x in links if '.m3u8' in x]
    if not links:
        links = regex_pattern12.findall(resp)
        # log(f'play provider links3: {links}')
        links = [b64decode(links[0]).decode('utf-8')]
    # log(f'play provider links4: {links}')
    links = [x for x in links if '.m3u8' in x]
    if not links:
        link = b64decode(unhunt(resp))
        iurl = link.decode('utf-8', errors='ignore')
        iurl = str(iurl).split('https')
        # log(f'play provider iurl: {iurl}') # ['ޝ\x1dyԨ\x1e', '://webhdrunns.mizhls.ru/lb/premium347/index.m3u8']
        links = [f'https{iurl[1]}']
        # log(f'play provider links: {repr(links)}') # 'https://webhdrunns.mizhls.ru/lb/premium347/index.m3u8'
    if not links: links = re.findall(r'(https?:\/\/\S+\.m3u8)', resp)
    if not links: return
    links = list({x for x in links if '.m3u8' in x})
    # links = [x for x in links if '.m3u8' in x]
    # links = list(set(links))
    # if len(links) > 1:
    #     list_items = [{'line1': f'url:  {i}'} for i in links]
    #     kwargs = {'items': dumps(list_items), 'heading': 'Select source to play.', 'narrow_window': 'true'}
    #     return select_dialog(links, **kwargs)
    if len(links) > 0: return links[0]