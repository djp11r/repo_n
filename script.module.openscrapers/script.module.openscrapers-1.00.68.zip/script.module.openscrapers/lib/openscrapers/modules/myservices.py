import requests, time
from threading import Thread, Timer

from urllib.parse import quote
from openscrapers.windows.base import Progress
# from modules import cache_utils

from openscrapers.modules.control import setting, setSetting, sleep, notification, yesnoDialog, okDialog, make_listitem, dialog, addonIcon, addonPath
from openscrapers.modules.log_utils import error, log
from openscrapers.modules.cleandate import utc_to_datetime
# clear_cache = cache_utils.clear_cache
user_agent = 'SALTS/%s' % '6.04.04'
qr_str = 'https://api.qrserver.com/v1/create-qr-code/?size=256x256&qzone=1%s'
meta_keys = 'title year poster fanart clearlogo'
code_str, nav2_str, await_str = 'PIN CODE: [B]%s[/B]', 'LOCATION: [B]%s[/B]', 'REMAINING: [B]%02d:%02d[/B]'
auth_str, noauth_str = 'Authorized: Select to Remove', 'Unauthorized: Select to Add'
timeout = 10.05
img_url = 'https://i.imgur.com/%s.png'


def watch_indicators(function):
	def wrapper(instance, *args, **kwargs):
		if function(instance, *args, **kwargs): okDialog(message=(
			'At successful activation, watched status and resume progress will be set to [B]%s[/B]. '
			'To change settings after activation, use the addon settings category:[CR]'
			'[B]Features/Watched Indicators/Watched Status Provider[/B]'
		) % instance.__class__.__name__)
	return wrapper

# def _make_progress_dialog(**kwargs):
	# progress_dialog = create_window(('windows.progress', 'ProgressMedia'), 'progress_media.xml', **kwargs)
	# Thread(target=progress_dialog.run).start()
	# return progress_dialog

# def _make_progress_dialog(heading='Openscraper', icon=None, qr=0, artwork=0):
def _make_progress_dialog(**kwargs):
	log(f'kwargs: {repr(kwargs)}')
	if icon is None: icon = addonIcon()
	window = Progress('progress.xml', addonPath(), heading=heading, icon=icon, qr=qr, artwork=artwork)
	Thread(target=window.run).start()
	return window

def authorize():
	def _builder():
		for name, api in services:
			item = make_listitem()
			item.setLabel('[B]%s[/B]' % name.upper())
			item.setLabel2(auth_str if api().token else noauth_str)
			item.setArt({
				'icon': api.icon
				if api.icon.startswith('Default') else
				'%s%s' % (img_url, api.icon)
			})
			yield(item)
	services = (('trakt', Trakt), ('mdblist', MDBList), ('tmdb', TMDBList), ('flicklist', FlickList),
	)
	service = dialog.select('My Services', list(_builder()), useDetails=True)
	if service < 0: return
	try: success = services[service][1]().set()
	except Exception as e: log(f'myservices error: {str(e)}')
	else: return success
	return notification('Error in authorize')

class RepeatTimer(Timer):
	def run(self):
		while not self.finished.wait(self.interval):
			self.function(*self.args, **self.kwargs)


class Trakt:
	icon = 'sGq3ifV'
	def __init__(self):
		self.token = setting('trakt.token')
		self.client_id = setting('trakt.client')
		self.secret = setting('trakt.secret')

	def base_url(self, path):
		return f'https://api.trakt.tv/{path}'

	def poll_auth(self, data):
		response = requests.post(self.base_url('oauth/device/token'), json=data, timeout=timeout)
		if not response.ok: return
		data.update(response.json())
		self.token = data['access_token']

	@watch_indicators
	def set(self):
		cls_name = self.__class__.__name__
		if self.token:
			if not yesnoDialog(): return
			data = {'token': self.token, 'client_id': self.client_id, 'client_secret': self.secret}
			response = requests.post(self.base_url('oauth/revoke'), json=data, timeout=timeout)
			setSetting('trakt.user', '')
			setSetting('trakt.token', '')
			setSetting('trakt.refresh', '')
			setSetting('trakt.expires', '')
			setSetting('trakt_indicators_active', 'false')
			setSetting('watched_indicators', '0')
			sleep(500)
			# clear_cache('trakt', silent=True)
			return notification(f'Removed {cls_name} Authorization')

		data = {'client_id': self.client_id, 'client_secret': self.secret, 'code': ''}
		response = requests.post(self.base_url('oauth/device/code'), json=data, timeout=timeout)
		result = response.json()
		data['code'] = result['device_code']
		expires_in, expires_at = result['expires_in'], result['expires_in'] + time.monotonic()
		try: qr_icon = qr_str % '&color=f00&data=%s' % quote('%s/%s' % (result['verification_url'], result['user_code']))
		except: qr_icon = ''
		meta = {**dict.fromkeys(meta_keys.split(), ''), 'poster': qr_icon}
		detail = code_str % result['user_code'], nav2_str % result['verification_url']
		progress_dialog = _make_progress_dialog(meta=meta)
		timer = RepeatTimer(result['interval'], self.poll_auth, args=(data,))
		timer.start()
		for i in range(1, expires_in + 1):
			if self.token or progress_dialog.iscanceled(): break
			lines = await_str % divmod(expires_at - time.monotonic(), 60), *detail
			progress = 100 - int(100 * i / expires_in)
			progress_dialog.update('[CR]'.join(lines), progress)
			sleep(1000)
		timer.cancel()
		progress_dialog.close()
		if progress_dialog.iscanceled(): return False
		if not self.token: return notification(f'Error {cls_name}.set()')
		sleep(500)
		headers = {'trakt-api-key': self.client_id, 'trakt-api-version': '2', 'Content-Type': 'application/json'}
		headers.update({'Authorization': f'Bearer {self.token}'})
		response = requests.get(self.base_url('users/me'), headers=headers, timeout=timeout)
		username = response.json()['username']
		expires = int(data['created_at']) + int(data['expires_in'])
		refresh, token = data['refresh_token'], data['access_token']
		setSetting('trakt.user', str(username))
		setSetting('trakt.token', token)
		setSetting('trakt.refresh', refresh)
		setSetting('trakt.expires', str(expires))
		setSetting('trakt_indicators_active', 'true')
		setSetting('watched_indicators', '1')
		expires_in = utc_to_datetime(float(expires))
		setSetting('trakt_renual', expires_in)
		notification(f'Set {cls_name} Authorization')
		sleep(500)
		# clear_cache('trakt', silent=True)
		return True

class MDBList:
	icon = 'mdblist.png'
	def __init__(self):
		self.token = setting('mdblist_api')

	def base_url(self, path):
		return f'https://api.mdblist.com/{path}'

	@watch_indicators
	def set(self):
		cls_name = self.__class__.__name__
		if self.token:
			if not yesnoDialog(): return
			setSetting('mdblist_user', '')
			# setSetting('mdblist_api', '')
			setSetting('mdbl_indicators_active', 'false')
			setSetting('watched_indicators', '0')
			sleep(500)
			# clear_cache('mdblist', silent=True)
			return notification(f'Removed {cls_name} Authorization')

		api_key = dialog.input('MDBList API Key:')
		if not api_key: return
		params = {'apikey': api_key}
		response = requests.get(self.base_url('user'), params=params, timeout=timeout)
		result = response.json()
		user_id, username = result['user_id'], result['username']
		setSetting('mdblist_user', str(username))
		#setSetting('mdblist_api', api_key)
		setSetting('mdbl_indicators_active', 'true')
		setSetting('watched_indicators', '2')
		notification(f'Set {cls_name} Authorization')
		sleep(500)
		# clear_cache('mdblist', silent=True)
		return True

class TMDBList:
	icon = 'VYCWHvl'
	def __init__(self):
		self.read = setting('tmdb.tmdb_read_token')
		self.token = setting('tmdb.token')
		self.headers = {'Authorization': f'Bearer {self.read}'}

	def base_url(self, path):
		return f'https://api.themoviedb.org/{path}'

	def poll_auth(self, data):
		response = requests.post(self.base_url('4/auth/access_token'), json=data, headers=self.headers, timeout=timeout)
		if not response.ok: return
		data.update(response.json())
		self.token = data['access_token']

	def set(self):
		cls_name = self.__class__.__name__
		if self.token:
			if not yesnoDialog(): return
			data = {'access_token': self.token}
			response = requests.delete(self.base_url('4/auth/access_token'), json=data, headers=self.headers, timeout=timeout)
			result = response.json()
			if not result['success']: return notification(f'Error: {cls_name}.set()')
			setSetting('tmdb.account_id', '')
			setSetting('tmdb.token', '')
			# clear_cache('tmdblist', silent=True)
			notification(f'Removed {cls_name} Authorization')
			session_id = setting('tmdb.session_id')
			data = {'session_id': session_id}
			response = requests.delete(self.base_url('3/authentication/session'), json=data, headers=self.headers, timeout=timeout)
			result = response.json()
			if not result['success']: return
			setSetting('tmdb.session_account_id', '')
			setSetting('tmdb.session_id', '')
			setSetting('tmdb.user', '')
			return

		response = requests.post(self.base_url('4/auth/request_token'), headers=self.headers, timeout=timeout)
		result = response.json()
		if not result['success']: return
		data = {'request_token': result['request_token']}
		expires_in, expires_at = 600, 600 + time.monotonic()
		url = f'https://www.themoviedb.org/auth/access?request_token={result["request_token"]}'
		tiny_url = 'http://tinyurl.com/api-create.php'
		try: tiny_url = requests.get(tiny_url, params={'url': url}, timeout=timeout).text
		except: tiny_url = url
		qr_icon = qr_str % '&data=%s' % quote(tiny_url)
		log(f'tmdblist: {tiny_url}\n{url}')
		meta = {**dict.fromkeys(meta_keys.split(), ''), 'poster': qr_icon}
		detail = nav2_str % tiny_url, ''
		progress_dialog = _make_progress_dialog(meta=meta)
		timer = RepeatTimer(5, self.poll_auth, args=(data,))
		timer.start()
		for i in range(1, expires_in + 1):
			if self.token or progress_dialog.iscanceled(): break
			lines = await_str % divmod(expires_at - time.monotonic(), 60), *detail
			progress = 100 - int(100 * i / expires_in)
			progress_dialog.update('[CR]'.join(lines), progress)
			sleep(1000)
		timer.cancel()
		progress_dialog.close()
		if progress_dialog.iscanceled(): return False
		if not self.token: return notification(f'Error: {cls_name}.set()')
		account_id, access_token = str(data['account_id']), str(data['access_token'])
		setSetting('tmdb.account_id', account_id)
		setSetting('tmdb.token', access_token)
		notification(f'Set {cls_name} Authorization')
		sleep(500)
		if not self.token and not setting('tmdb.token'): return
		access_token = self.token or setting('tmdb.token')
		data = {'access_token': access_token}
		response = requests.post(self.base_url('3/authentication/session/convert/4'), json=data, headers=self.headers, timeout=timeout)
		result = response.json()
		if not result['success']: return
		session_id = result['session_id']
		params = {'session_id': session_id}
		response = requests.get(self.base_url('3/account'), params=params, headers=self.headers, timeout=timeout)
		result = response.json()
		if not 'id' in result: return
		username, session_account_id = str(result['username']), str(result['id'])
		setSetting('tmdb.user', username)
		setSetting('tmdb.session_id', session_id)
		setSetting('tmdb.session_account_id', session_account_id)
		return True

class FlickList:
	icon = 'DefaultPlaylist.png'
	def __init__(self):
		self.token = setting('flicklist.token')
		self.client_id = setting('flicklist.client_id') or 'econolo'

	def base_url(self, path):
		return f'https://flicklist.tv/api/{path}'

	def poll_auth(self, data):
		response = requests.post(self.base_url('auth/device/token'), json=data, timeout=timeout)
		if not 'access_token' in response.text: return
		data.update(response.json())
		self.token = data['access_token']

	@watch_indicators
	def set(self):
		cls_name = self.__class__.__name__
		if self.token:
			if not yesnoDialog(): return
			setSetting('flicklist_user', '')
			setSetting('flicklist.token', '')
			setSetting('flicklist.expires', '')
			setSetting('flicklist.client_id', '')
			setSetting('flicklist_indicators_active', 'false')
			setSetting('watched_indicators', '0')
			sleep(500)
			# clear_cache('flicklist', silent=True)
			return notification(f'Removed {cls_name} Authorization')

		from datetime import datetime
		data = {'client_id': self.client_id}
		response = requests.post(self.base_url('auth/device/code'), json=data, timeout=timeout)
		result = response.json()
		log(f'result: {repr(result)}')
		data['device_code'] = result['device_code']
		expires_in, expires_at = result['expires_in'], result['expires_in'] + time.monotonic()
		try: qr_icon = qr_str % '&data=%s' % quote('%s' % result['verification_uri'])
		except: qr_icon = ''
		meta = {**dict.fromkeys(meta_keys.split(), ''), 'poster': qr_icon}
		detail = code_str % result['user_code'], nav2_str % result['verification_uri']
		progress_dialog = _make_progress_dialog(meta=meta)
		timer = RepeatTimer(result['interval'], self.poll_auth, args=(data,))
		timer.start()
		for i in range(1, expires_in + 1):
			if self.token or progress_dialog.iscanceled(): break
			lines = await_str % divmod(expires_at - time.monotonic(), 60), *detail
			progress = 100 - int(100 * i / expires_in)
			progress_dialog.update('[CR]'.join(lines), progress)
			sleep(1000)
		timer.cancel()
		progress_dialog.close()
		if progress_dialog.iscanceled(): return False
		if not self.token: return notification(f'Error: {cls_name}.set()')
		dt = datetime.strptime(data['expires_at'], '%Y-%m-%dT%H:%M:%S.%fZ')
		expires = str(int(dt.timestamp()))
		username = data['user']['username']
		setSetting('flicklist_user', str(username))
		setSetting('flicklist.token', self.token)
		setSetting('flicklist.expires', expires)
		setSetting('flicklist.client_id', self.client_id)
		setSetting('flicklist_indicators_active', 'true')
		setSetting('watched_indicators', '3')
		notification(f'Set {cls_name} Authorization')
		sleep(500)
		# clear_cache('flicklist', silent=True)
		return True

def refer_link(service):
	url = {'realdebrid': 'https://tinyurl.com/2db65q28', 'torbox': 'https://tinyurl.com/2d2ra6jq'}[service]
	expires_in, expires_at = 20, 20 + time.monotonic()
	try: qr_icon = qr_str % '&data=%s' % quote(url)
	except: qr_icon = media_path('%s.png' % service)
	meta = {**dict.fromkeys(meta_keys.split(), ''), 'poster': qr_icon}
	detail = nav2_str % url, ''
	progress_dialog = _make_progress_dialog(meta=meta)
	for i in range(1, expires_in + 1):
		if progress_dialog.iscanceled(): break
		lines = await_str % divmod(expires_at - time.monotonic(), 60), *detail
		progress = 100 - int(100 * i / expires_in)
		progress_dialog.update('[CR]'.join(lines), progress)
		sleep(1000)
	progress_dialog.close()

