# -*- coding: utf-8 -*-

import time
import datetime
from datetime import datetime, timezone

def utc_to_datetime(date, date_format='%Y-%m-%d %H:%M:%S'):
    return time.strftime(date_format, time.gmtime(date))

def iso_2_utc(iso_ts='2025-01-01T05:53:48.000Z'): # to 1733655228.0
    if not iso_ts or iso_ts is None:
        return 0
    delim = -1
    if not iso_ts.endswith('Z'):
        delim = iso_ts.rfind('+')
        if delim == -1:
            delim = iso_ts.rfind('-')
    if delim > -1:
        ts = iso_ts[:delim]
        sign = iso_ts[delim]
        tz = iso_ts[delim + 1:]
    else:
        ts = iso_ts
        tz = None
    if ts.find('.') > -1:
        ts = ts[:ts.find('.')]
    try:
        d = datetime.datetime.strptime(ts, '%Y-%m-%dT%H:%M:%S')
    except TypeError:
        d = datetime.datetime(*(time.strptime(ts, '%Y-%m-%dT%H:%M:%S')[:6]))
    dif = datetime.timedelta()
    if tz:
        hours, minutes = tz.split(':')
        hours = int(hours)
        minutes = int(minutes)
        if sign == '-':
            hours = -hours
            minutes = -minutes
        dif = datetime.timedelta(minutes=minutes, hours=hours)
    utc_dt = d - dif
    epoch = datetime.datetime.utcfromtimestamp(0)
    delta = utc_dt - epoch
    try:
        seconds = delta.total_seconds()  # works only on 2.7
    except:
        seconds = delta.seconds + delta.days * 24 * 3600  # close enough
    return seconds


def get_datetime(hours=0):
    dt = datetime.datetime.now().replace(microsecond=0).isoformat() + datetime.timedelta(hours)
    d = datetime.datetime(dt.year, 4, 1)
    dston = d - datetime.timedelta(days=d.weekday() + 1)
    d = datetime.datetime(dt.year, 11, 1)
    dstoff = d - datetime.timedelta(days=d.weekday() + 1)
    return dt if dston > dt or dt >= dstoff else dt + datetime.timedelta(hours=1)


def datetime_from_string(string_date, format="%Y-%m-%d", date_only=True): # date or datetime object from string
    if not string_date: return None
    try:
        try:
            if date_only: result = datetime.datetime.strptime(string_date, format).date()
            else: result = datetime.datetime.strptime(string_date, format)
        except:
            if date_only: result = datetime.datetime(*(time.strptime(string_date, format)[0:6])).date()
            else: result = datetime.datetime(*(time.strptime(string_date, format)[0:6]))
        return result
    except:
        from openscrapers.modules.log_utils import error
        error()

def timestamp_from_string(string_date, format="%Y-%m-%d"):
    if not string_date: return None
    try:
        try: element = datetime.datetime.strptime(string_date, format)
        except: element = datetime.datetime(*(time.strptime(string_date, format)[0:6]))
        timestamp = datetime.datetime.timestamp(element)
        return timestamp
    except:
        from openscrapers.modules.log_utils import error
        error()



def local_datetime_to_utc_timestamp(dt_string, fmt='%Y-%m-%d %H:%M:%S'):
    local_tz = datetime.now().astimezone().tzinfo
    dt_local = datetime.strptime(dt_string, fmt)
    dt_local = dt_local.replace(tzinfo=local_tz)
    dt_utc = dt_local.astimezone(timezone.utc)
    return dt_utc.timestamp()

def utc_timestamp_to_local_string(ts, fmt='%Y-%m-%d %H:%M:%S'):
    local_tz = datetime.now().astimezone().tzinfo
    dt_local = datetime.fromtimestamp(float(ts), tz=local_tz)
    return dt_local.strftime(fmt)


def datetime_to_utc(string_date: str | time.struct_time, date_format: str = '%Y-%m-%d %H:%M:%S') -> str | None:
    """Convert a formatted datetime string, numeric timestamp string, or struct_time to UTC datetime string."""
    if not string_date:
        return None

    try:
        # Case 1: time.struct_time
        if isinstance(string_date, time.struct_time):
            timestamp = time.mktime(string_date)
            return time.strftime(date_format, time.localtime(timestamp))

        # Case 2: numeric timestamp (e.g., "1771837100")
        if isinstance(string_date, (int, float)) or (isinstance(string_date, str) and string_date.isdigit()):
            return time.strftime(date_format, time.localtime(float(string_date)))

        # Case 3: formatted datetime string
        try:
            element = datetime.strptime(string_date, date_format)
        except ValueError:
            # Fallback for looser parsing
            element = datetime(*time.strptime(string_date, date_format)[0:6])

        # Assume naive datetime is UTC
        element = element.replace(tzinfo=timezone.utc)
        return element.strftime(date_format)

    except Exception as err:
        log(f'Error converting datetime: {err}')
        return None


def utc_to_datetime_new(date: float | str, reversedt: bool = False, date_format: str = '%Y-%m-%d %H:%M:%S') -> str | None:
    """Convert UTC timestamp to datetime string, or reverse to UTC datetime string."""
    if isinstance(date, str):
        dt = datetime.strptime(date, '%Y-%m-%d %H:%M:%S')
        date = dt.timestamp()
        # reversedt = True

    if reversedt:
        return datetime_to_utc(time.localtime(date), date_format)
    
    # Use localtime() instead of gmtime() to get your local timezone
    return time.strftime(date_format, time.localtime(date))

def comper_time_with_current(date: str):
    try:
        dt = datetime.strptime(date, '%Y-%m-%d %H:%M:%S')
        old_time = dt.timestamp()
        return old_time < int(time.time())
    except ValueError: return True

def get_timestamp(offset: int | None = None, humanread: bool = False) -> str | int:
    """Get current timestamp with optional hour offset.
    
    Args:
        offset: Hour offset from current time (None for current time)
        humanread: Return human-readable datetime string if True
        
    Returns:
        Unix timestamp (int) or datetime string (str)
    """
    current_time = int(time.time())
    timestamp = current_time if offset is None else current_time + offset * 3600

    return datetime_to_utc(timestamp) if humanread else timestamp


