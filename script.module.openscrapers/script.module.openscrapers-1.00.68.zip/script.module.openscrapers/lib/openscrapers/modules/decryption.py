# -*- coding: utf-8 -*-
import base64
from urllib.parse import quote, unquote
from typing import Optional, Tuple, Dict, List, Union

ALPHABET = {
    '47ab07f9': 'A', '47ab07fa': 'B', '47ab07fb': 'C', '47ab07fc': 'D', '47ab07fd': 'E',
    '47ab07fe': 'F', '47ab07ff': 'G', '47ab0800': 'H', '47ab0801': 'I', '47ab0802': 'J',
    '47ab0803': 'K', '47ab0804': 'L', '47ab0805': 'M', '47ab0806': 'N', '47ab0807': 'O',
    '47ab0808': 'P', '47ab0809': 'Q', '47ab080a': 'R', '47ab080b': 'S', '47ab080c': 'T',
    '47ab080d': 'U', '47ab080e': 'V', '47ab080f': 'W', '47ab0810': 'X', '47ab0811': 'Y',
    '47ab0812': 'Z',
    '47ab0819': 'a', '47ab081a': 'b', '47ab081b': 'c', '47ab081c': 'd', '47ab081d': 'e',
    '47ab081e': 'f', '47ab081f': 'g', '47ab0820': 'h', '47ab0821': 'i', '47ab0822': 'j',
    '47ab0823': 'k', '47ab0824': 'l', '47ab0825': 'm', '47ab0826': 'n', '47ab0827': 'o',
    '47ab0828': 'p', '47ab0829': 'q', '47ab082a': 'r', '47ab082b': 's', '47ab082c': 't',
    '47ab082d': 'u', '47ab082e': 'v', '47ab082f': 'w', '47ab0830': 'x', '47ab0831': 'y',
    '47ab0832': 'z',
    '47ab07e8': '0', '47ab07e9': '1', '47ab07ea': '2', '47ab07eb': '3', '47ab07ec': '4',
    '47ab07ed': '5', '47ab07ee': '6', '47ab07ef': '7', '47ab07f0': '8', '47ab07f1': '9',
    '47ab07f2': ':', '47ab07e7': '/', '47ab07e6': '.', '47ab0817': '_', '47ab07e5': '-'
}

CHARACTER_MAP = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"


def decode(uri):
    for key in ALPHABET.keys():
        uri = uri.replace(key, ALPHABET[key])
    #Added a ghetto dash replace to retain any dash thats meant to be there.(doesnt matter tho from my tests.)
    return uri.replace('---', '-$DASH$-').replace('-', '').replace('$DASH$', '-')


def decipher(encrypted_url: str):
    s1, s2 = encrypted_url[:9], encrypted_url[9:].strip('=')
    crypto = 0
    decrypted = ""
    for index, character in enumerate(s2, 1):
        crypto <<= 6
        if character in CHARACTER_MAP: crypto |= CHARACTER_MAP.index(character)
        if index and not (index % 4): decrypted, crypto = decrypted + chr((0xff0000 & crypto) >> 16) + chr((0xff00 & crypto) >> 8) + chr(0xff & crypto), 0
    if index % 4 and not (index % 2):
        crypto >>= 4
        decrypted += chr(crypto)
    if index % 4 and not (index % 3): decrypted += chr((65280 & crypto) >> 8) + chr(255 & crypto)
    decrypted = unquote(decrypted)
    mapper = {byte_index: byte_index for byte_index in range(0x100)}
    xcrypto = 0
    for byte_index in range(0x100):
        xcrypto = (xcrypto + mapper.get(byte_index) + ord(s1[byte_index % len(s1)])) % 0x100
        mapper[byte_index], mapper[xcrypto] = mapper[xcrypto], mapper[byte_index]
    xcryptoz, xcryptoy = 0, 0
    cipher = ""
    for character in decrypted:
        xcryptoy = (xcryptoy + 1) % 0x100
        xcryptoz = (xcryptoz + mapper.get(xcryptoy)) % 0x100
        mapper[xcryptoy], mapper[xcryptoz] = mapper[xcryptoz], mapper[xcryptoy]
        cipher += chr(ord(character) ^ mapper[(mapper[xcryptoy] + mapper[xcryptoz]) % 0x100])
    return cipher


class DecryptionMethods:
    """
    USEGES:
    from openscrapers.modules.decryotion import DecryptionMethods

    decoded_url = DecryptionMethods.decode_src(encoded, seed)
    unpacked = DecryptionMethods.hunter(*processed_values)
    vrf = DecryptionMethods.rc4_decode(VRF.DEFAULT_ENCRYPTION_KEY, data)
    """
    @staticmethod
    def rc4_decode(key: str, data: Union[bytearray, str]) -> bytearray:
        key_bytes = bytes(key, 'utf-8')
        s = bytearray(range(256))
        j = 0

        for i in range(256):
            j = (j + s[i] + key_bytes[i % len(key_bytes)]) & 0xff
            s[i], s[j] = s[j], s[i]

        decoded = bytearray(len(data))
        i = 0
        k = 0

        for index in range(len(data)):
            i = (i + 1) & 0xff
            k = (k + s[i]) & 0xff
            s[i], s[k] = s[k], s[i]
            t = (s[i] + s[k]) & 0xff
            if isinstance(data[index], str): decoded[index] = ord(data[index]) ^ s[t]
            elif isinstance(data[index], int): decoded[index] = data[index] ^ s[t]
            else: raise ValueError("Unsupported data type in the input")
        return decoded

    @staticmethod
    def int_2_base(x: int, base: int) -> str:

        if x < 0: sign = -1
        elif x == 0: return 0
        else: sign = 1
        x *= sign
        digits = []
        while x:
            digits.append(CHARACTER_MAP[int(x % base)])
            x = int(x / base)

        if sign < 0: digits.append('-')
        digits.reverse()
        return ''.join(digits)

    @staticmethod
    def decode_base64_url_safe(s: str) -> bytearray:
        standardized_input = s.replace('_', '/').replace('-', '+')
        binary_data = base64.b64decode(standardized_input)
        return bytearray(binary_data)

    def hunter_def(self, d, e, f) -> int:
        """Used by self.hunter"""
        g = list(CHARACTER_MAP)
        h = g[0:e]
        i = g[0:f]
        d = list(d)[::-1]
        j = 0
        for c, b in enumerate(d):
            if b in h: j = j + h.index(b) * e ** c
        k = ""
        while j > 0:
            k = i[j % f] + k
            j = (j - (j % f)) // f
        return int(k) or 0

    @staticmethod
    def hunter(self, h, u, n, t, e, r) -> str:
        """Decodes the common h,u,n,t,e,r packer"""
        r = ""
        i = 0
        while i < len(h):
            j = 0
            s = ""
            while h[i] is not n[e]:
                s = ''.join([s, h[i]])
                i += 1
            while j < len(n):
                s = s.replace(n[j], str(j))
                j += 1
            r = ''.join([r, ''.join(map(chr, [self.hunter_def(s, e, 10) - t]))])
            i += 1
        return r

    @staticmethod
    def decode_src(encoded, seed) -> str:
        """decodes hash found @ vidsrc.me embed page"""
        encoded_buffer = bytes.fromhex(encoded)
        decoded = ""
        for i in range(len(encoded_buffer)):
            decoded += chr(encoded_buffer[i] ^ ord(seed[i % len(seed)]))
        return decoded


class VRF:
    DEFAULT_ENCRYPTION_KEY = b"FWsfu0KQd9vxYGNB"
    VIDPLAY_ENCRYPTION_KEY = b"8z5Ag5wgagfsOuhz"

    @staticmethod
    def encrypt(data: str) -> str:
        def rot13(vrf):
            vrf = bytearray(vrf)
            for i in range(len(vrf)):
                byte = vrf[i]
                if 65 <= byte <= 90: vrf[i] = ((byte - 65 + 13) % 26 + 65)
                elif 97 <= byte <= 122: vrf[i] = ((byte - 97 + 13) % 26 + 97)
            return vrf

        def vrf_shift(vrf):
            vrf = bytearray(vrf)
            shifts = [-4, -2, -6, 5, -2]
            for i in range(len(vrf)):
                shift = shifts[i % 5]
                vrf[i] = (vrf[i] + shift) & 0xFF
            return vrf

        vrf = DecryptionMethods.rc4_decode(VRF.DEFAULT_ENCRYPTION_KEY, data)
        vrf = base64.urlsafe_b64encode(vrf)
        vrf = rot13(vrf)
        vrf = base64.urlsafe_b64encode(vrf)
        vrf = vrf_shift(vrf)
        return quote(vrf.decode("utf-8"))


def encrypt64(data):
    """

    :param data: bytes:
    :return: bytes
    """
    if isinstance(data, str): data = data.encode('utf-8', errors='ignore') # str to bytes use .encode('utf-8')
    return base64.b64encode(data)


def decrypt64(data):
    """

    :param data: bytes:
    :return: str
    """
    # if isinstance(data, bytes): data = data.decode('utf-8') # from bytes to str use .decode('utf-8')
    if isinstance(data, str): data = data.encode('utf-8') # str to bytes use .encode('utf-8')
    return base64.b64decode(data).decode('utf-8', errors='ignore')


# if __name__ == "__main__":
#     data = {'Superembed': 'MGFiZTI1MzFhMjhkY2Q0NzcxYmZjYWFlZTY4YjdlYjU6YW1aT2NsZEZhWFZHUXpsMlUxZ3pOVkpCUWpOVUsyTnFhbTFtT0hsRVZIaEhOalo0VTA1c2VWbDVTbTFvTVhob1pGcExlQ3RoUTNKbWN6aExhblpFU2xOd05HcHpkVms0V21KM1IweGpTRWhMZEhKdmVrRTlQUT09'}
#     for item in data.values():
#         print(f'item: {item}')
#         encoded = DecryptionMethods.decode_base64_url_safe(item)
#         decoded = DecryptionMethods.rc4_decode("https://vidsrc.to", encoded)
#         decoded_text = decoded.decode('utf-8')
#         print(decoded)