# -*- coding: utf-8 -*-
"""
	openscrapers Module
"""

from sys import version_info
# import types

isPY2 = version_info[0] == 2
isPY3 = version_info[0] == 3

if isPY2:
	class _C:
		def _m(self): pass
	ClassType = type(_C)
	range = xrange
	string_types = basestring,
	integer_types = (int, long)
	# class_types = (type, types.ClassType)
	class_types = (type, ClassType)
	text_type = unicode
	binary_type = str
	def iteritems(d, **kw):
		return d.iteritems(**kw)

elif isPY3:
	string_types = str,
	integer_types = int,
	class_types = type,
	text_type = str
	binary_type = bytes
	def iteritems(d, **kw):
		return iter(d.items(**kw))


def ensure_text(s, encoding='utf-8', errors='strict'):
	try:
		if isinstance(s, binary_type): return s.decode(encoding, errors)
		elif isinstance(s, text_type): return s
	except: return s


def ensure_str(s, encoding='utf-8', errors='strict'):
	try:
		if not isinstance(s, (text_type, binary_type)):
			from openscrapers.modules.log_utils import log
			return log(f'not expecting type: {type(s)}', __name__)
		try: s = s.encode('ascii', errors='ignore').decode('ascii', errors='ignore') # added for ascii characters, check if this is correct for both 18 and 19
		except: pass
		if isPY2 and isinstance(s, text_type): s = s.encode(encoding, errors)
		elif isPY3 and isinstance(s, binary_type): s = s.decode(encoding, errors)
		return s
	except: return s


def ensure_binary(s, encoding='utf-8', errors='strict'):
	"""Coerce **s** to six.binary_type.

	For Python 2:
	- `unicode` -> encoded to `str`
	- `str` -> `str`

	For Python 3:
	- `str` -> encoded to `bytes`
	- `bytes` -> `bytes`
	"""
	if isinstance(s, text_type): return s.encode(encoding, errors)
	elif isinstance(s, binary_type): return s
	else: raise TypeError(f'not expecting type" {type(s)}')


def six_encode(txt, char='utf-8', errors='replace'):
	try:
		if isPY2 and isinstance(txt, text_type): txt = txt.encode(char, errors=errors)
		return txt
	except: return txt


def six_decode(txt, char='utf-8', errors='replace'):
	try:
		if isPY3 and isinstance(txt, binary_type): txt = txt.decode(char, errors=errors)
		return txt
	except: return txt
