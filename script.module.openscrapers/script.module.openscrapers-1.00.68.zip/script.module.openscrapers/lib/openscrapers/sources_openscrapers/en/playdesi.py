# -*- coding: UTF-8 -*-

import re

from openscrapers.modules.client import agent, scrapePage, refresh_redirect
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.hindi_utils import get_source_dict, get_vid_url, keepclean_title, query_cleaner
from openscrapers.modules.log_utils import error, log
from openscrapers.modules.control import setting
from openscrapers.modules.source_utils import get_host
from openscrapers import custom_base_link
custom_base = custom_base_link(__name__)

class source:

    def __init__(self):
        self.name = 'playdesi'
        self.base_link = custom_base or 'https://playdesi.net'
        self.domains = list(get_host(self.base_link)) # ['playdesi.net']
        self.headers = {'User-Agent': agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f'From: {__name__}\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year}')
        try:
            try:
                url = aliases[0]['url']
                if 'playdesi' in url: return url
            except: pass
            return f'{tvshowtitle}'
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f'From: {__name__} url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}')
        try:
            # if type(tvdb) == int: return
            # if '|' not in tvdb: return
            if 'episode' not in title.lower(): return
            if 'watch-online' in url: return url
            # tvdb = tvdb.split('|')
            # episode = episode.replace('Episode', '')
            # show_name = tvdb[1]
            # chanel_name = keepclean_title(tvdb[0])
            # log(f'From: {__name__} show_name {show_name}')
            show_name = query_cleaner(url, season)
            season_data = re.compile(r'[sS]eason.+?(\d{1,2})|[sS]eason(\d{1,2})|[sS](\d{1,2})', flags=re.I)
            show_name = re.sub(season_data, '', show_name)
            # show_url = f'https://playdesi.net/watch-online/{chanel_name}/{show_name}/'
            # if season > 1: show_url = f'{show_url}-season-{season
            qepisode = title.replace('Episode ', '')
            # show_url = show_url.lower().replace(' ', '-').replace('  ', '-')
            # log(f'From: {__name__} show_url {show_url}')
            url = f'https://playdesi.net/{show_name}-episode-{qepisode}-watch-online/'
            if season > 1: url = f'https://playdesi.net/{show_name}-season-{season}-episode-{qepisode}-watch-online/'
            url = url.lower().replace(' ', '-').replace('  ', '-')
            # if result := scrapePage.srp_page(show_url, headers=self.headers):
                # qepisode = title.replace('Episode ', '')
                # release_title = f'season-{season}-episode-{qepisode}'
                # results = parseDOM(result.text, 'div', attrs={'class': 'post-content'})
                # log(f'From: {__name__} total: {len(results)} result1 {results}')
                # results = parseDOM(result.text, 'div', attrs={'class': 'blog-posts posts-medium posts-container'})
                # log(f'From: {__name__} total: {len(results)} result2 {results}')
                # for item in results:
                    # log(f'{__name__} episode item: {item}')
                    # urls = parseDOM(item, "a", ret="href")
                    # log(f'{__name__} release_title: {release_title} url: {urls}')
                    # for url in urls:
                        # if release_title in url:
                            # log(f'@@@@@ {__name__} episode item: {item}')
                            # break
            return url
        except:
            error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict):
        # log(f'From: {__name__} url {url}')
        sources = []
        try:
            if not url: return sources
            result = scrapePage.srp_page(url, headers=self.headers).text
            if not result: return
            result = parseDOM(result, 'div', attrs={'class': 'entry-content'})
            # log(f'result: {result}')
            items = parseDOM(result, 'p')
            for item in items:
                # log(f'sources url: {urls}')
                try:
                    urls = parseDOM(item, 'a', attrs={'target': '_blank'}, ret='href')[0]
                    sources = get_source_dict([urls], sources)
                except: pass
            if not sources: log(f'From: {__name__} no sources on url {url}')
            return sources
        except:
            error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        # url = resolve_gen(url)
        try:
            if result := refresh_redirect(url, headers=self.headers):
                self.headers.update({'Referer': self.base_link})
                vidhost, strurl = get_vid_url(result, self.headers)
                return f'{strurl}|Referer={self.base_link}'
        except:
            pass
        return
