# -*- coding: UTF-8 -*-

import os
try: from . import en
except: from . import en

scraper_source = os.path.dirname(__file__)
__all__ = [x[1] for x in os.walk(scraper_source)][0]

##--hosters--##
hoster_source = en.sourcePath
hoster_providers = en.__all__

##--All Providers--##
total_providers = {'en': hoster_providers}
all_providers = []
try:
	for value in total_providers.values():
		all_providers += value
except:
	pass
