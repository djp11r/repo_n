# -*- coding: utf-8 -*-
"""
	OpenScrapers Module
"""

from openscrapers.modules.control import addonPath, addonVersion, joinPath
from openscrapers.windows.textviewer import TextViewerXML


def get(file):
	scrapers_path = addonPath()
	scrapers_version = addonVersion()
	helpFile = joinPath(scrapers_path, 'lib', 'openscrapers', 'help', f'{file}.txt')
	with open(helpFile, mode='r', encoding='utf-8', errors='ignore') as f:
		text = f.read()
	heading = f'[B]OpenScrapers -  v{scrapers_version} - {file}[/B]'
	windows = TextViewerXML('textviewer.xml', scrapers_path, heading=heading, text=text)
	windows.run()
	del windows
