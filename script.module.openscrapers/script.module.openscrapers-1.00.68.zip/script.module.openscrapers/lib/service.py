
from openscrapers.modules.log_utils import log
from openscrapers.modules.service import OMain


if __name__ == '__main__':
	log('Settings & Main Monitor Service Starting')

	with OMain() as omain:
		omain.startUpServices()
		omain.waitForAbort()

	log('Settings & Main Monitor Service Stopped')
