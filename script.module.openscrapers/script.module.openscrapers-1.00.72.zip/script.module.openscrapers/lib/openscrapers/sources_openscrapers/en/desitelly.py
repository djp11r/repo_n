# -*- coding: UTF-8 -*-

import re

from openscrapers.modules.client import agent, request
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.hindi_utils import get_query, get_source_dict, query_cleaner, resolve_gen, get_ch_name
from openscrapers.modules.log_utils import error, log
from openscrapers.modules.control import setting
from openscrapers.modules.source_utils import get_host
from openscrapers import custom_base_link
custom_base = custom_base_link(__name__)

class source:

    def __init__(self):
        self.name = 'desitelly'
        self.base_link = custom_base or 'https://www.desitellybox.net'
        self.domains = list(get_host(self.base_link)) #  ['desitellybox.net']
        self.headers = {'User-Agent': agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log(f'From: {__name__}.tvshow\nimdb {imdb}\ntvdb {tvdb}\ntvshowtitle {tvshowtitle}\nlocaltvshowtitle {localtvshowtitle}\naliases {aliases}\nyear {year}')
        try:
            return f'{tvshowtitle}'
        except:
            error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # log(f'From: {__name__}.episode url {url}\nimdb {imdb}\ntvdb {tvdb}\ntitle {title}\npremiered {premiered}\nseason {season}\nepisode {episode}')
        try:
            if type(tvdb) == int: return
            if '|' not in tvdb: return
            ch_name = get_ch_name(str(tvdb))
            query = get_query(url, season)
            # log(f'query {query} title: {title}')
            # elif re.search(r'masterchef-india', query, re.I): query = f'masterchef-india-season-7-{title}-watch-online'
            if re.search(r'madness-machayenge', query, re.I): query = 'madness-machayenge'
            # else: query = f'{query}'
            if 'amazon' in ch_name: ch_name = 'amazon-web-series'
            # else: ch_name = query_cleaner(f'{ch_name}-web-series')
            # query = query_cleaner(query)
            query_title = f'{query}-{title}'
            query_title = query_cleaner(query_title)
            search_url = f'{self.base_link}/category/{ch_name}/{query}/'
            # log(f'tvdb: {tvdb} query: {query}\nquery_title: {query_title} search_url: {search_url}')
            if result := request(search_url, headers=self.headers):
                results = parseDOM(result, 'div', attrs={'class': 'item_content'})
                # log(f'From: {__name__} total: {len(results)} result1 {results}')
                for item in results:
                    if query_title in str(item):
                        # log(f'item: {item}')
                        url = parseDOM(item, "a", ret="href")[0]
                        return url
        except:
            error(f'{__name__}_ episode: ')
        return

    def sources(self, url, hostDict):
        # log(f'From: {__name__} url {url}')
        sources = []
        try:
            if not url: return sources
            result = request(url)
            if not result: return sources
            result = parseDOM(result, 'div', attrs={'class': 'entry_content'})
            items = parseDOM(result, 'p')
            for item in items:
                urls = parseDOM(item, 'a', attrs={'target': '_blank'}, ret='href')
                # log(f'total: {len(urls)} urls: {urls}')
                iurls = []
                if iurls := [iurl for iurl in urls if iurl not in iurls]: sources = get_source_dict(iurls, sources)
            if not sources: log(f'From: {__name__} no sources on url {url}')
            return sources
        except:
            error(f'{__name__}_ sources url: {url} ')
            return sources

    def resolve(self, url):
        # log(f'In resolve of url {type(url)} url: {url}')
        return resolve_gen(url)
