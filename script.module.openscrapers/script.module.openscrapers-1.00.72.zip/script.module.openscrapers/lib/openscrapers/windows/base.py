# -*- coding: utf-8 -*-
"""
	Fenomscrapers Module
"""
from threading import Thread

from xbmc import executebuiltin
from xbmcgui import WindowXMLDialog, ListItem, ControlProgress
from openscrapers.modules.control import addonPath, notification, addonIcon
from openscrapers.modules.log_utils import log


class BaseDialog(WindowXMLDialog):
	def __init__(self, *args):
		WindowXMLDialog.__init__(self, args)
		self.left_action = 1
		self.right_action = 2
		self.up_action = 3
		self.down_action = 4
		self.closing_actions = [9, 10, 13, 92]
		self.selection_actions = [7, 100]
		self.context_actions = [101, 117]
		self.info_actions = [11,]
		self.heading = 'Openscraper'

	def make_listitem(self):
		return ListItem(offscreen=True)

	def set_image(self, _control, _image):
		self.getControl(_control).setImage(_image)

	def set_label(self, _control, _label):
		self.getControl(_control).setLabel(_label)

	def set_text(self, _control, _text):
		self.getControl(_control).setText(_text)

	def set_percent(self, _control, _percent):
		self.getControl(_control).setPercent(_percent)

	def reset_window(self, _control):
		self.getControl(_control).reset()

	def execute_code(self, command):
		return executebuiltin(command)

	def get_position(self, window_id):
		return self.getControl(window_id).getSelectedPosition()

	def getControlProgress(self, control_id):
		control = self.getControl(control_id)
		if not isinstance(control, ControlProgress):
			raise AttributeError(f'Control with Id {control_id} should be of type ControlProgress')
		return control


class Progress(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.closed = False
		self.heading = kwargs.get('heading', 'Openscraper')
		self.qr = kwargs.get('qr')
		self.artwork = kwargs.get('artwork')
		self.icon = kwargs.get('icon') or ''
		self.text = kwargs.get('text', '')
		self.is_canceled = False
		self.selected = None
		self.enable_buttons = kwargs.get('enable_buttons', False)
		self.true_button = kwargs.get('true_button', '')
		self.false_button = kwargs.get('false_button', '')
		self.focus_button = kwargs.get('focus_button', 10)
		self.percent = float(kwargs.get('percent', 0))
		self.set_properties()

	def run(self):
		self.doModal()
		# self.clearProperties()
		return self.selected

	def iscanceled(self):
		if self.enable_buttons: return self.selected
		else: return self.is_canceled

	def onAction(self, action):
		if action in self.closing_actions or action in self.selection_actions:
			self.is_canceled = True
			self.close()

	def onClick(self, controlID):
		self.selected = controlID == 10
		self.close()

	def doClose(self):
		self.closed = True
		self.close()
		del self

	def set_properties(self):
		if self.qr: self.setProperty('openscr.qr','1')
		else: self.setProperty('openscr.qr','0')
		if self.artwork: self.setProperty('openscr.artwork', '1')
		else: self.setProperty('openscr.artwork', '0')
		self.setProperty('openscr.heading', self.heading)
		self.setProperty('openscr.icon', self.icon)

	def update(self, percent=0, content=''):
		try:
			self.setProperty('openscr.label', self.heading)
			self.setProperty('percent', str(percent))
			self.getControl(2001).setText(content)
			self.getControl(5000).setPercent(percent)
		except: pass


def getProgressWindow(heading='Openscraper', icon=None, qr=0, artwork=0):
	if icon is None: icon = addonIcon()
	window = Progress('progress.xml', addonPath(), heading=heading, icon=icon, qr=qr, artwork=artwork)
	Thread(target=window.run).start()
	return window
