# -*- coding: utf-8 -*-
import re
import json
from base64 import b64decode
from html import unescape
try:
    from openscrapers.modules.py_tools import ensure_str
    from openscrapers.modules.dom_parser import parseDOM
    from openscrapers.modules import jsunpack
    from openscrapers.modules import unjuice
    from openscrapers.modules.jsunhunt import unhunt
    from openscrapers.modules.utils import byteify
    from openscrapers.modules.log_utils import error, log
except:
    from modules.py_tools import ensure_str
    from modules.dom_parser import parseDOM
    from modules import jsunpack
    from modules import unjuice
    from modules.jsunhunt import unhunt
    from modules.utils import byteify
    from modules.log_utils import error, log


regex_pattern1 = r'(?:iframe|source).+?(?:src)["\']?\s*[:=]?\s*["\']([^"\']+)'
regex_pattern2 = r'(?:data-video|data-src|data-href)=(?:\"|\')(.+?)(?:\"|\')'
regex_pattern3 = r'''(?:source|file)['"]*\s*[:=]?\s*["']([^"']+)'''
regex_pattern4 = r'''(magnet:\?[^"']+)'''
regex_pattern5 = r'<[iI][fF][rR][aA][mM][eE].+?[sS][rR][cC]="(.+?)"'
regex_pattern6 = r'''(?:file|src)['"]*\s*[:=]?\s*["']([^"']+)'''
regex_pattern7 = r'''(?:file|src)['"]*\s*[:=]?\s*["']([^"']+)'''
regex_pattern8 = r'''(?:file|src)['"]*\s*[:=]?\s*["']([^"']+)'''
regex_pattern9 = r'''(?:source)['"]*\s*[:=]?\s*["']([^"']+)'''
regex_pattern10 = r'\{(.+?)\}'
regex_pattern11 = re.compile(r'''(?:source|src|file)['"]*\s*[:=]?\s*["']([^"']+)''', flags=re.DOTALL+re.I)
regex_pattern12 = re.compile(r'''(?s)script>\s*var.*?"([^"]*)''', flags=re.DOTALL+re.I)
regex_pattern13 = re.compile(r'''(var .*?\s*=\s*["'].+?['"];)''', re.DOTALL)


def regexExtract(data, expression, group=1, all=False, flags=re.I):
    try:
        if all:
            match = re.findall(expression, data, flags=flags)
            if group is None: return match
            else: return match[group]
        else:
            match = re.search(expression, data, flags=flags)
            if group is None: return match.groups()
            else: return match.group(group)
    except: return None


def re_findall(html, regex):
    return re.findall(regex, html)


def re_compile(html, regex):
    return re.compile(regex).findall(html)


def unpacked(html):
    return jsunpack.unpack(html) if jsunpack.detect(html) else ''


def unpacked2(html):
    packed_data = ''
    if jsunpack.detect(html):
        for match in re.finditer(r'''(eval\s*\(function\(p,a,c,k,e,.*?)</script>''', html, re.DOTALL | re.I):
            r = match.group(1)
            t = re.findall(r'(eval\s*\(function\(p,a,c,k,e,)', r, re.DOTALL | re.IGNORECASE)
            if len(t) == 1:
                if jsunpack.detect(r):
                    packed_data += jsunpack.unpack(r)
            else:
                t = r.split('eval')
                t = [f'eval{x}' for x in t if x]
                for r in t:
                    if jsunpack.detect(r):
                        packed_data += jsunpack.unpack(r)
    return packed_data


def unjuiced2(html):
    unjuiced = ''
    if unjuice.test(html):
        for match in re.finditer(r'(_juicycodes\(.+?[;\n<])|(JuicyCodes.Run\([^\)]+)', html, re.DOTALL | re.I):
            unjuiced += unjuice.run(match.group(1))
    return unjuiced


def remove_tags(text):
    TAG_RE = re.compile(r'<[^>]+>')
    return TAG_RE.sub('', text)


def remove_codes(string):
    remove = re.compile(r'<.+?>')
    string = re.sub(remove, '', string)
    return string


# Pre-compile the regex patterns outside the function for maximum speed
MISSING_SEMICOLON_PATTERN = re.compile(r'(&#[0-9]+)([^;0-9]+)')
MULTI_SPACE_PATTERN = re.compile(r'\s+')
# Combine all unique custom replacements into a single mapping dictionary
CUSTOM_REPLACEMENTS = {# Smart Quotes (Normalized to straight single quotes)
    "“": "'", "”": "'", "‘": "'", "’": "'", "â\x80\x99": "'", "\u02bb": "",
    # Dashes, Ellipses, and Math symbols
    "—": "",  # Em-dash removed
    "–": "-",  # En-dash replaced with hyphen
    "…": "...",  # Ellipsis normalized to three dots
    "%2B": "+",  # URL encoded plus sign
    # Path / Slash fixes
    "\\/": "/", "///": "//",
    # Strip tags, layout controls, and specific symbols
    "&nbsp;": "", "\u2009": "",  # Thin space
    "»": "", "&raquo;": "", "&Amp;": "&",
    # Raw Byte / Hex Escape Artifacts
    "\x80\x9c": "'", "\x80\x9d": "'", "\x80\x98": "'", "\x80\x99": "'", "\x80\x89": "", "\x80\x93": "-", "\x89": "", "\x8e": "", "\\xa": "a"}
# Single-pass regex pattern for custom replacements
CUSTOM_REPLACE_PATTERN = re.compile("|".join(re.escape(k) for k in CUSTOM_REPLACEMENTS.keys()))
# Detects JS-style escaped sequences cheaply
JS_ESCAPE_DETECT = re.compile(r'(\\x[0-9A-Fa-f]{2}|\\u[0-9A-Fa-f]{4}|\[0-7]{1,3}|\\n|\\t|\\r)')

def replaceHTMLCodes(txt: str) -> str:
    """High-performance HTML decoding pipeline optimized for Python 3.14."""
    if not txt: return ''
    # 1. Quick pre-check: Only run the double-decode loop if an entity actually exists
    # This skips heavy processing entirely for normal, clean strings
    for _ in range(2):
        if '&' not in txt and '\\' not in txt and '%' not in txt and '<' not in txt:
            break
        # 1. Fix missing semicolons on numeric entities
        if "&#" in txt:
            txt = MISSING_SEMICOLON_PATTERN.sub(r"\1;\2", txt)
        # 2. HTML unescape (C‑level, extremely fast)
        txt = unescape(txt)
        # 3. Decode raw backslash escape sequences first  This check is extremely cheap and avoids slow decoding
        if "\\" in txt and JS_ESCAPE_DETECT.search(txt):
            try: txt = txt.encode("utf-8").decode("unicode_escape")
            except Exception: pass
        # 4. Fast, single-pass custom character replacements
        txt = CUSTOM_REPLACE_PATTERN.sub(lambda m: CUSTOM_REPLACEMENTS[m.group(0)], txt)
    # 6. Global structural cleanup (HTML tags, spacing, layout control)
    # txt = txt.replace('<span class="st">', '').replace('</span>', '')
    #txt = txt.replace('\n', ' ').replace('\r', '').replace('\t', '')
    txt = MULTI_SPACE_PATTERN.sub(' ', txt)
    # 7. Final pass: Drop remaining non-ASCII characters
    return txt.encode('ascii', 'ignore').decode('ascii').strip()


def replace_html_entities(string):
    txt = replaceHTMLCodes(string)
    return txt


def _replaceHTMLCodes(txt):
    if not txt: return ''
    txt = replaceHTMLCodes(txt)
    return txt


def cleanHTML(txt):
    return replaceHTMLCodes(txt)

def clean_html(txt):
    txt = replaceHTMLCodes(txt)
    txt = txt.replace('\n', ' ').replace('\r', '').replace('\t', '')
    txt = MULTI_SPACE_PATTERN.sub(' ', txt)
    return txt.encode('ascii', 'ignore').decode('ascii').strip()


def removeNonAscii(s):
    return ''.join(i for i in s if ord(i) < 128)


def json_loads_as_str(json_text):
    return byteify(json.loads(json_text, object_hook=byteify), ignore_dicts=True)


def get_jsunpack_unjuice(shtml):
    if unjuice.test(shtml): shtml += unjuice.run(shtml)
    if jsunpack.detect(shtml): shtml += jsunpack.unpack(shtml)
    return shtml


def scan_html(html):
    patterns = {
        'source src file': r'''(?:source|src|file)['"]?\s*[:=]?\s*['"](.+?\.m3u8)(?:"|')''',
        'var script': r'''(?s)script>\s*var.*?"([^"]*)''',
        'source object': r'''source\s*:\s+?(?:"|'|`)(.+?)(?:"|'|`)''',
        'var source': r'''var source.?=.?(?:\"|'|`)(.+?)(?:\"|'|`)",''',
        'quoted URL': r'''(?:"|')(http.*?\.m3u8.*?)(?:"|')''',
        'base64 URL': r'''atob\((?:"|')((?:aHR|Ly).+?)(?:"|')''',
        'packed JS': r'''(eval\(function\(p,a,c,k,e,d\).+?{}\)\)'''
    }

    res = None

    for pattern_name, pattern in patterns.items():
        matches = re.findall(pattern, html)
        if matches:
            for match in matches:
                if pattern_name == 'var script' or pattern_name == 'base64 URL':
                    match = b64decode(match).decode("ascii")
                if pattern_name == 'packed JS':
                    for packed in matches:
                        unpacked = jsunpack.unpack(packed)
                        res = scan_html(unpacked)
                        if res: break
                if '.m3u8' in match:
                    res = match
                    break
                if any(ext in match for ext in [".css", ".js", "load-playlist"]):
                    match = match.replace('.css', '.m3u8').replace('.js', '.m3u8')
                    res = match
                    break
        if res: break

    if isinstance(res, str) and res.startswith("//"): res = f'https:{res}'
    return res


def scan_htmlo(html):
    patterns = {
        'source src file': r'''(?:source|src|file)['"]?\s*[:=]?\s*['"](.+?\.m3u8)(?:"|')''',
        'var script': r'''(?s)script>\s*var.*?"([^"]*)''',
        'source object': r'''source\s*:\s+?(?:"|'|`)(.+?)(?:"|'|`)''',
        'var source': r'''var source.?=.?(?:\"|'|`)(.+?)(?:\"|'|`)",''',
        'quoted URL': r'''(?:"|')(http.*?\.m3u8.*?)(?:"|')'''}
    res = None
    for pattern_name, pattern in patterns.items():
        matches = re.findall(pattern, html)
        if matches:
            for match in matches:
                if pattern_name == 'var script':
                    match = b64decode(match).decode("ascii")
                if '.m3u8' in match:
                    res = match
                    break
                if ".css" in match or ".js" in match or "load-playlist" in match:
                        if ".css" in match: match = match.replace('.css', '.m3u8')
                        elif ".js" in match: match = match.replace('.js', '.m3u8')
                        res = match
                        break
    if not res:
        patterns2 = {'base64 URL': r'''atob\((?:"|')((?:aHR|Ly).+?)(?:"|')''',
                     'packed JS': r'''(eval\(function\(p,a,c,k,e,d\).+?{}\)\)'''}
        for pattern_name, pattern in patterns2.items():
            matches = re.findall(pattern, html)
            if matches:
                if pattern_name in ['base64 URL']:
                    for match in matches:
                        b64 = b64decode(match).decode("ascii")
                        # Some sites like to hide the m3u8 in a .js or .css file
                        if '.m3u8' in match:
                            res = match
                            break
                        if ".css" in match or ".js" in match or "load-playlist" in match:
                                if ".css" in match: match = match.replace('.css', '.m3u8')
                                elif ".js" in match: match = match.replace('.js', '.m3u8')
                                res = match
                                break
                if pattern_name == 'packed JS':
                    packed = unpacked(html)#jsunpack.unpack(re_packed[0])
                    res = scan_html(packed)
                if res: break
    if type(res) == str and res.startswith("//"): res = f'https:{res}'
    return res


def get_link(resp):
    patterns = [
        r'''(https?:\/\/\S+\.m3u8)''',
        r'''(?:file)["']?\s*[:=]?\s*["']([^"']+)''',
        r'''(?s)script>\s*var.*?"([^"]*)''',
        r'''"(aHR0.+?)"''',
        r'''encryptedSource\s*=\s*"(.+?)"''',
        r"source:\s*'(.+?)'"
    ]

    link = None
    for pattern in patterns:
        match = re.search(pattern, resp)
        if match:
            link = match.group(1)
            # log(f'get_link pattern: {pattern}\nlink: {link}')
            if link and '.m3u8' not in link:
                try:
                    elink = b64decode(link).decode('utf-8', errors='ignore')  # Decode base64-encoded link (if applicable)
                    if elink.startswith('://'): link = f'https{elink[1]}'
                except Exception as err: error(f'get_link link: {link} err: {err}')
            if '.m3u8' in link: break
    if not link: log(f'get_link resp: {resp}')
    return link or None


def get_ltv_link(resp):
    links = regex_pattern11.findall(resp)
    # log(f'play provider links: {links}\nresp: {resp}')
    links = [x for x in links if '.m3u8' in x]
    if not links:
        links = regex_pattern12.findall(resp)
        # log(f'play provider links3: {links}')
        links = [b64decode(links[0]).decode('utf-8')]
    # log(f'play provider links4: {links}')
    links = [x for x in links if '.m3u8' in x]
    if not links:
        link = b64decode(unhunt(resp))
        iurl = link.decode('utf-8', errors='ignore')
        iurl = str(iurl).split('https')
        # log(f'play provider iurl: {iurl}') # ['ޝ\x1dyԨ\x1e', '://webhdrunns.mizhls.ru/lb/premium347/index.m3u8']
        links = [f'https{iurl[1]}']
        # log(f'play provider links: {repr(links)}') # 'https://webhdrunns.mizhls.ru/lb/premium347/index.m3u8'
    if not links: links = re.findall(r'(https?:\/\/\S+\.m3u8)', resp)
    if not links: return
    links = list({x for x in links if '.m3u8' in x})
    # links = [x for x in links if '.m3u8' in x]
    # links = list(set(links))
    # if len(links) > 1:
    #     list_items = [{'line1': f'url:  {i}'} for i in links]
    #     kwargs = {'items': dumps(list_items), 'heading': 'Select source to play.', 'narrow_window': 'true'}
    #     return select_dialog(links, **kwargs)
    if len(links) > 0: return links[0]