# -*- coding: utf-8 -*-

"""Example...
from resources.lib.modules import scrape_sources
for source in scrape_sources.process(hostDict, link, host=None, info=None):
    sources.append(source)
scrape_sources.rescrape(url, regex=None)
scrape_sources.prepare_link(url)
if not link: continue
"""

import base64
import re, json
import requests
from traceback import print_exc
from openscrapers import parse_qs, urlencode, hosts_list

from openscrapers.modules.client import request, parseDOM, UserAgent, dnt_headers, scrapePage
from openscrapers.modules import client_utils
from openscrapers.modules import jsunpack
from openscrapers.modules.source_utils import get_release_quality, is_host_valid, check_url, checkHost, supported_video_extensions, append_headers
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.py_tools import six_decode, ensure_text
host_limit = 'true'
# Using these gdriveplayer_domains in prepare_link to be lazy. Some are just fake-makes that i tossed in incase they ever show up lol.
gdriveplayer_domains = ['database.gdriveplayer.co', 'database.gdriveplayer.io', 'database.gdriveplayer.me', 'database.gdriveplayer.us', 'database.gdriveplayer.xyz',
    'database,gdriveplayer.co', 'database,gdriveplayer.io', 'database,gdriveplayer.me', 'database,gdriveplayer.us', 'database,gdriveplayer.xyz', # This lines just ghetto made alts incase the api links are fuckered.
    'databasegdriveplayer.co', 'databasegdriveplayer.io', 'databasegdriveplayer.me', 'databasegdriveplayer.us', 'databasegdriveplayer.xyz',
    'series.databasegdriveplayer.co', 'series.databasegdriveplayer.io', 'series.databasegdriveplayer.me', 'series.databasegdriveplayer.us', 'series.databasegdriveplayer.xyz' # Lazy line beisdes the first one lol.
]
gomo_domains = ['playerhost.net', 'gomo.to', 'gomostream.com', 'gomoplayer.com']
truepoweroflove_domains = ['truepoweroflove.com']
furher_domains = ['furher.in']
hlspanel_domains = ['hlspanel.xyz']
linkbin_domains = ['linkbin.me']
ronemo_domains = ['ronemo.com']
source_stream_domains = [] # Saved for ramdom odd ones found later lol.
superembed_domains = ['streamembed.net']
vidstreams_domains = ['vidstreams.net']
twoembed_domains = ['2embed.me', '2embed.ru', '2embed.to', '2embed.cc', '2embed.skin', 'hdville.online', 'moviekhhd.net', 'superstream.monster', 'dmmitltd.com', 'asia1.com.ge'] #https://2embedstatus.xyz
vidembed_domains = ['goload.io', 'goload.pro', 'membed1.com', 'membed.co', 'membed.net', 'movembed.cc',
    'vidcloud9.com', 'vidembed.cc', 'vidembed.io', 'vidembed.me', 'vidembed.net', 'vidnext.net', 'vidnode.net',
    'anihdplay.com', 'gotaku1.com', 'playtaku.net', 'playtaku.online', 'movstreamhd.pro'
]
vidlink_domains = ['vidlink.org']
vidsrc_domains = ['v2.vidsrc.me', 'vidsrc.me', 'vidsrc.to']
voxzer_domains = ['voxzer.org']
######################################################
############ Used for prepare_link.
######################################################
# these redirect to a new domain: clicknupload.click
clicknupload_redir_domains = ['clicknupload.click', 'clicknupload.com', 'clicknupload.link', 'clicknupload.me', 'clicknupload.to']
clicknupload_working_domains = ['clicknupload.cc', 'clicknupload.club', 'clicknupload.co', 'clicknupload.org', 'clicknupload.red']
######################################################
# Spare Alt  doodstream.co | dood.cx fails and all others redirect to doodstream.com
doodstream_redir_domains = ['dood.to', 'dood.so', 'dood.cx', 'dood.pm', 'ds2play.com', 'doods.pro', 'dood.la', 'dood.re', 'dood.sh', 'dood.watch', 'dood.wf', 'dood.ws', 'dood.yt', 'dooood.com']
######################################################
entervideo_failing_domains = ['entervideo.net', 'eplayvid.com']
######################################################
# Spare Alt  gotaku1.com, playtaku.net, playtaku.online
goload_failing_domains = ['gogohd.pro', 'goload.io', 'streamani.net', 'vidstreaming.io', 'anihdplay.com']
goload_redir_domains = ['gembedhd.com', 'gogo-play.net', 'gogohd.net', 'goload.pro', 'playgo1.cc']
goload_failing_domains += goload_redir_domains
######################################################
gomoplayer_failing_domains = ['gomoplayer.com', 'tunestream.net']
######################################################
streamsb_failing_domains = ['p1ayerjavseen.com', 'sbplay1.com', 'sbplay2.xyz', 'sbplay.org', 'sbface.com']
streamsb_working_domains = ['aintahalu.sbs', 'arslanrocky.xyz', 'cloudemb.com', 'embedsb.com', 'embedtv.fun',
    'gomovizplay.com', 'japopav.tv', 'javplaya.com', 'javside.com', 'lvturbo.com', 'playersb.com', 'sbanh.com',
    'sbani.pro', 'sbasian.pro', 'sbbrisk.com', 'sbchill.com', 'sbembed1.com', 'sbembed.com', 'sbface.com',
    'sbfast.com', 'sbfull.com', 'sbhight.com', 'sblanh.com', 'sblongvu.com', 'sbnet.one', 'sbone.pro',
    'sbplay2.com', 'sbplay.one', 'sbrapid.com', 'sbrity.com', 'sbspeed.com', 'sbthe.com', 'sbvideo.net',
    'ssbstream.net', 'streamovies.xyz', 'streamsb.net', 'streamsss.net', 'tubesb.com', 'tvmshow.com',
    'vidmovie.xyz', 'vidmoviesb.xyz', 'viewsb.com', 'watchsb.com'
]
######################################################
# These redirect to ahvsh.com but swapped to streamhide.com for dupe checks.
streamhide_redir_domains = ['ahvsh.com', 'guccihide.com', 'louishide.com']
streamhide_working_domains = ['streamhide.com', 'streamhide.to', 'movhide.pro', 'moviesm4u.com', 'bikurathulw.sbs', 'javb1.com']
######################################################
streamwish_failing_domains = ['abkrzkz.sbs', 'ajmidyad.sbs', 'atabkhha.sbs', 'atabknha.sbs', 'atabknhk.sbs', 'atabknhs.sbs', 'embedwish.com', 'hayaatieadhab.sbs',
    'khadhnayad.sbs', 'kharabnahs.sbs', 'mwish.pro', 'wishfast.top', 'yadmalik.sbs'
]
streamwish_working_domains = ['abkrzkr.sbs', 'ankrzkz.sbs', 'awish.pro', 'cilootv.store', 'doodporn.xyz', 'dwish.pro', 'streamwish.com', 'streamwish.site',
    'streamwish.to', 'strmwis.xyz', 'tuktukcinema.store', 'vidmoviesb.xyz', 'volvovideo.top', 'wishembed.pro'
]
######################################################
# Spare Alt  movembed.cc | The redirects goto membed1.com i think but done now to be lazy and for dupe checks.
vidcloud9_failing_domains = ['membed.co', 'vidembed.io', 'vidembed.me', 'vidembed.net', 'vidcloud.icu']
vidcloud9_redir_domains = ['membed.net', 'vidcloud9.com', 'vidembed.cc', 'vidnext.net', 'vidnode.net']
vidcloud9_failing_domains += vidcloud9_redir_domains
######################################################
vidcloud_failing_domains = ['vidcloud.pro', 'vidcloud.is']
######################################################
twoembed_failing_domains = ['2embed.ru', '2embed.to']
######################################################
video_extensions = ['.m4v', '.3g2', '.3gp', '.nsv', '.tp', '.ts', '.ty', '.strm', '.pls', '.rm', '.rmvb', '.mpd', '.m3u', '.m3u8', '.mov', '.qt', '.divx', '.xvid', '.bivx', '.vob', '.udf', '.pva', '.wmv', '.asf', '.m2v', '.avi', '.mpg', '.mpeg', '.mp4', '.mkv', '.mk3d', '.avc', '.vp3', '.svq3', '.nuv', '.viv', '.dv', '.fli', '.flv', '.001', '.wpl', '.xspf', '.vdr', '.dvr-ms', '.xsp', '.mts', '.m2t', '.m2ts', '.evo', '.ogv', '.sdp', '.avs', '.rec', '.url', '.pxml', '.vc1', '.h264', '.rcv', '.mpls', '.mpl', '.webm', '.bdmv', '.bdm', '.wtv', '.trp', '.f4v', '.pvr']
######################################################
mod_domains = 'true' #control.setting('mod.domains') or 'true'
######################################################


# written by mbebe on GitHub: https://github.com/mbebe/blomqvist
# License: https://github.com/mbebe/blomqvist/blob/master/LICENSE
def GetPlayLink(base_link, server_id, url, host, headers):
    # url_api = base64.b64decode(''.join(chr(int(c)) for c in '118O0O107O0O71O0O99O0O104O0O57O0O67O0O99O0O119O0O70O0O109O0O76O0O115O0O86O0O50O0O89O0O121O0O86O0O109O0O100O0O117O0O119O0O87O0O89O0O108O0O82O0O88O0O76O0O121O0O86O0O71O0O90O0O117O0O86O0O72O0O97O0O48O0O82O0O88O0O97O0O105O0O74O0O87O0O89O0O121O0O57O0O121O0O76O0O54O0O77O0O72O0O99O0O48O0O82O0O72O0O97'.split('O0O'))[::-1]).decode('utf-8')
    url_api = 'https://v-resol.vercel.app/api/' #'https://rabbitthunder-teal.vercel.app/api/'
    # id = server_id
    ref = url
    ref = base_link + ref if ref.startswith('/') else ref
    headers.update({'Referer': ref})
    get_url = base_link + '/ajax/sources/' + server_id

    # log(f'get_url ={repr(get_url)}')
    response = requests.get(get_url, headers=headers, verify=None)
    json_data = None
    try:
        json_data = json.loads(response.text)
    except Exception as e:
        error(f'not json_data: {e}')

    if json_data:
        link = json_data['link']
    else:
        html = response.content
        html = html.decode(encoding='utf-8', errors='strict')
        link = re.findall(r'"link"\s*\:\s*"([^"]+)"', html, re.DOTALL)[0]

    nturl = link
    urlapi = url_api
    if 'vidcloud' in host:
        urlapi = url_api + 'vidcloud'
    elif 'upcloud' in host:
        urlapi = url_api + 'upcloud'

    if 'rabbitstream' in link:
        if '?z=' in nturl:
            nturl = nturl.split('?z=')[0]
        idx = nturl.split('/')[-1]  #
        ft = {'id': idx}
        response = requests.post(urlapi, data=ft, verify=None)
        html = response.content
        html = html.decode(encoding='utf-8', errors='strict')
        jsdata = json.loads(html)
        stream_url = jsdata['source']
    else:
        try:
            stream_url = link
        except:
            return link

    if stream_url:
        # log('stream_url =' + repr(stream_url), 1)
        return stream_url


def prepare_link(url):
    if not url:
        return
    url = url.replace(r"\/", "/")
    url = url.replace("\\", "")
    url = url.replace('///', '//')
    url = f'https:{url}' if url.startswith('//') else url
    if not url.startswith('http'):
        url = re.sub(r'\s+', '', url)
    if not url.startswith('http'):
        #log('scrape_sources - prepare_link NOT-link: ' + str(url))
        return
    u = url.replace('//www.', '//')
    if mod_domains == 'true':
        try:
            old_domain = re.findall(r'//(.+?)/', u)[0]
        except:
            error(f'scrape_sources - prepare_link - old_domain failed-url: {u}')
            return
        if old_domain in doodstream_redir_domains:
            url = url.replace(old_domain, 'doodstream.com')
        elif old_domain in entervideo_failing_domains:
            url = url.replace(old_domain, 'eplayvid.net')
        elif old_domain in gdriveplayer_domains:
            url = url.replace(old_domain, 'databasegdriveplayer.co')
        elif old_domain in goload_failing_domains:
            url = url.replace(old_domain, 'gotaku1.com')
        elif old_domain in gomoplayer_failing_domains:
            url = url.replace(old_domain, 'xvideosharing.com')
        elif old_domain in streamhide_redir_domains:
            url = url.replace(old_domain, 'streamhide.com')
        elif old_domain in streamwish_failing_domains:
            url = url.replace(old_domain, 'streamwish.to')
        elif old_domain in vidcloud9_failing_domains:
            url = url.replace(old_domain, 'movstreamhd.pro')
        elif old_domain in vidcloud_failing_domains:
            url = url.replace(old_domain, 'vidcloud.co')
        elif old_domain in twoembed_failing_domains:
            url = url.replace(old_domain, '2embed.me')
        elif old_domain == 'aparat.cam':
            url = url.replace(old_domain, 'wolfstream.tv')
        elif old_domain == 'clipwatching.com':
            url = url.replace(old_domain, 'highstream.tv')
        elif old_domain == 'cloudvid.co':
            url = url.replace(old_domain, 'cloudvideo.tv')
        elif old_domain == 'fastclick.to':
            url = url.replace(old_domain, 'drop.download')
        elif old_domain == 'gomostream.com':
            url = url.replace(old_domain, 'gomo.to')
        elif old_domain == 'sendit.cloud':
            url = url.replace(old_domain, 'send.cm')
        elif old_domain == 'streamvid.co':
            url = url.replace(old_domain, 'streamvid.cc')
        elif old_domain in clicknupload_redir_domains:
            url = url.replace(old_domain, 'clicknupload.download')
        elif old_domain in streamsb_failing_domains:
            url = url.replace(old_domain, 'embedsb.com') #auto redirects ya to streamwish.com lately. need to check some sources.
    if '//vidcloud.co/embed/' in u:
        url = url.replace('/embed/', '/v/')  # Ghetto fix to get the resolver pattern to notice the url
    #log('scrape_sources - prepare_link link: ' + str(url))
    # this log line should log atleast 90% of the source links when used. altho its gonna have dupes and links from before and after various process steps.
    return url


def check_host_limit(item, items): # lazy way to not import source_utils if i dont gotta and a little less code use sorta.
    return host_limit == 'true' and item in str(items)


def check_direct(hostDict, url, host=None): # unused code saved. now works like is_host_valid but as direct lol.
    try:
        url = prepare_link(url)
        if not url:
            raise Exception()
        host = host or url
        direct_check = tuple(supported_video_extensions())
        valid, host = is_host_valid(host, hostDict)
        if valid:
            return False, url
        elif '/hls/' in url or url.endswith(direct_check):
            return True, url
        return False, url
    except:
        error(f'Error from: {__name__}: url: {url} ')
        return False, url


def make_direct_item(hostDict, link, host=None, info=None, referer=None, prep=False):
    item = {}
    try:
        if prep:
            link = prepare_link(link)
        if not link:
            return item
        host = link if host is None else host
        info = link if info is None else info
        valid, host = is_host_valid(host, hostDict)
        quality, info = get_release_quality(link, info)
        #direct = any((x in link.lower() for x in video_extensions))
        if referer:
            link += append_headers({'Referer': referer})
        return {'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': True}
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return item


def make_item(hostDict, link, host=None, info=None, prep=False):
    item = {}
    try:
        if prep:
            link = prepare_link(link)
        if not link:
            return item
        host = link if host is None else host
        info = link if info is None else info
        valid, host = is_host_valid(host, hostDict)
        if valid:
            quality, info = get_release_quality(link, info)
            item = {'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False}
        #else: log('scrape_sources - make_item - non-valid link: ' + str(link))
        #log('scrape_sources - make_item item: ' + str(item))
        return item
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return item


def process(hostDict, link, host=None, info=None):
    sources = []
    try:
        if not hostDict: hostDict = hosts_list
        link = prepare_link(link)
        if link is None: return sources
        # log(f'getMore url In: {link}')
        host = link if host is None else host
        info = link if info is None else info
        if any(i in host for i in gdriveplayer_domains):
            #log('scrape_sources - process - gdriveplayer link: '+repr(link))
            for source in gdriveplayer(link, hostDict, info=info):
                sources.append(source)
        elif any(i in host for i in gomo_domains):
            #log('scrape_sources - process - gomo link: '+repr(link))
            for source in gomo(link, hostDict, info=info):
                sources.append(source)
        elif any(i in host for i in furher_domains):
            #log('scrape_sources - process - furher link: '+repr(link))
            for source in furher(link, hostDict, info=info):
                sources.append(source)
        elif any(i in host for i in hlspanel_domains):
            #log('scrape_sources - process - hlspanel link: '+repr(link))
            for source in hlspanel(link, hostDict, info=info):
                sources.append(source)
        elif any(i in host for i in linkbin_domains):
            #log('scrape_sources - process - linkbin link: '+repr(link))
            for source in linkbin(link, hostDict, info=info):
                sources.append(source)
        elif any(i in host for i in ronemo_domains):
            #log('scrape_sources - process - ronemo link: '+repr(link))
            for source in ronemo(link, hostDict, info=info):
                sources.append(source)
        elif any(i in host for i in source_stream_domains):
            #log('scrape_sources - process - source_stream link: '+repr(link))
            for source in source_stream(link, hostDict, info=info):
                sources.append(source)
        elif any(i in host for i in superembed_domains):
            #log('scrape_sources - process - superembed link: '+repr(link))
            for source in superembed(link, hostDict, info=info):
                sources.append(source)
        elif any(i in host for i in truepoweroflove_domains):
            #log('scrape_sources - process - truepoweroflove link: '+repr(link))
            for source in truepoweroflove(link, hostDict, info=info):
                sources.append(source)
        elif any(i in host for i in twoembed_domains):
            #log('scrape_sources - process - twoembed link: '+repr(link))
            for source in twoembed(link, hostDict, info=info):
                sources.append(source)
        elif any(i in host for i in vidembed_domains):
            #log('scrape_sources - process - vidembed link: '+repr(link))
            for source in vidembed(link, hostDict, info=info):
                sources.append(source)
        elif any(i in host for i in vidlink_domains):
            #log('scrape_sources - process - vidlink link: '+repr(link))
            for source in vidlink(link, hostDict, info=info):
                sources.append(source)
        # elif any(i in host for i in vidsrc_domains):
            #log('scrape_sources - process - vidsrc link: '+repr(link))
            # for source in vidsrc(link, hostDict, info=info):
                # sources.append(source)
        elif any(i in host for i in voxzer_domains):
            #log('scrape_sources - process - voxzer link: '+repr(link))
            for source in voxzer(link, hostDict, info=info):
                sources.append(source)
            # sources.extend(iter(voxzer(link, hostDict, info=info)))
        # elif 'cloudvideo.tv' in link:
            # sources.extend(iter(cloudvideo(link, hostDict)))
        # elif 'abcvideo.cc' in link:
            # sources.extend(iter(abcvideo(link, hostDict)))
        # elif 'vidoza.net' in link:
            # sources.extend(iter(vidoza(link, hostDict)))
        # elif 'upstream.to' in link:
            # sources.extend(iter(upstream(link, hostDict)))
        # elif 'mixdrop.co' in link:
            # sources.extend(iter(mixdrop(link, hostDict)))
        # elif 'mediashore.org' in link:
            # sources.extend(iter(mediashore(link, hostDict)))
        # elif 'movcloud' in link:
            # sources.extend(iter(movcloud(link, hostDict)))
        # douplicate in list domain
        # elif 'vidcloud.pro' in link:
            # sources.extend(iter(vidcloud_pro(link, hostDict)))
        # elif 'vidcloud9' in link:
            # sources.extend(iter(vidcloud9(link, hostDict)))
        # elif 'vidsrc.me' in link:
            # sources.extend(iter(vidsrc_me(link, hostDict)))
        # elif 'vidnext.net' in link:
            # sources.extend(iter(vidnext_net(link, hostDict)))
        # elif 'vidoo' in link:
            # sources.extend(iter(vidoo(link, hostDict)))
        # elif 'hls3x.vidcloud9.com' in link:
            # sources.extend(iter(hls3x(link, hostDict)))
        # elif 'fmovies' in link:
            # sources.extend(iter(fmovies_to(link, hostDict)))
        # elif any(i in host for i in ['vidcloud', 'upcloud', 'rabbitstream']):
            # log('scrape_sources - process - voxzer link: '+repr(link))
            # for source in rebit_st(link, hostDict, info=info):
                # sources.append(source)
        else:
            try:
                if item := make_item(hostDict, link, host=host, info=info):
                    sources.append(item)
            except:
                pass
        # log(f'{len(sources)} {sources}')
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return sources


def rescrape(url, regex=None): # unused old code saved.
    try:
        link = prepare_link(url)
        html = scrapePage.srp_page(link, headers={'User-Agent': UserAgent, 'Referer': link}).text
        if regex:
            link = re.findall(regex, html)[0]
        else:
            link = re.findall(r'(?:file|source)\s*[:=,]?\s*["\']([^"\']+)', html)[0]
        return link
    except:
        error(f'Error from: {__name__}: url: {url} ')
        return url


def rebit_st(link, hostDict, info=None):
    sources = []
    url_api = 'https://rabbitthunder-teal.vercel.app/api/'
    nturl = link
    urlapi = url_api

    if 'vidcloud' in link: urlapi = url_api + 'vidcloud'
    elif 'upcloud' in link: urlapi = url_api + 'upcloud'
    if 'rabbitstream' in link:
        if '?z=' in nturl: nturl = nturl.split('?z=')[0]
        idx = nturl.split('/')[-1]  #
        ft = {'id': idx}
        response = requests.post(urlapi, data=ft, verify=None)
        html = response.content
        html = html.decode(encoding='utf-8', errors='strict')
        jsdata = json.loads(html)
        stream_url = jsdata['source']
    else: stream_url = link
    if item := make_item(hostDict, stream_url, info=info):
        sources.append(item)
    return sources


def linkbin(link, hostDict, info=None):
    sources = [] # Last Tested/Checked: 6-28-2023  Status: Working.
    try:
        html = scrapePage.srp_page(link, headers={'User-Agent': UserAgent, 'Referer': link}).text
        results = parseDOM(html, 'li', attrs={'class': 'signle-link'})
        results = [(parseDOM(i, 'a', ret='href'), parseDOM(i, 'a')) for i in results]
        results = [(i[0][0], i[1][0]) for i in results if len(i[0]) > 0 and len(i[1]) > 0]
        for result in results:
            try:
                url = prepare_link(result[0])
                if not url:
                    continue
                if info:
                    info += f' {result[1]}'
                else:
                    info = result[1]
                if item := make_item(hostDict, url, info=info):
                    sources.append(item)
            except:
                #error('linkbin')
                pass
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return sources


def gomo(link, hostDict, info=None):
    sources = [] # Last Tested/Checked: 6-28-2023  Status: Working.
    try:
        # domain = re.findall(r'(?://|\.)(playerhost\.net|gomo\.to|gomostream\.com|gomoplayer\.com)/', link)[0]
        domain = re.findall(r'(?://|\.)((?:playerhost|gomo|gomostream|gomoplayer|)\.(?:com|to|net))', link, re.MULTILINE)[0]
        # log(f'domain: {repr(domain)}')
        gomo_link = f'https://{domain}/decoding_v3.php'
        result = scrapePage.srp_page(link, headers={'User-Agent': UserAgent, 'Referer': link}).text
        tc = re.compile(r'tc = \'(.+?)\';').findall(result)[0]
        if tc:
            token = re.compile(r'"_token": "(.+?)",').findall(result)[0]
            post = {'tokenCode': tc, '_token': token}

            def _tsd_tsd_ds(result, tokenCode):
                tmp_lst = re.compile(r'''(?<=_tsd_tsd_ds)(.*?)(?=\})''', re.M | re.S).findall(result)
                for item in tmp_lst:
                    if '.slice(' in item:
                        item = item.split('.slice')[1]
                        item = item.strip()
                        return_add = item[-8:-2]
                        # log(f'return_add: {repr(return_add)}')
                        usefull_item = re.compile(r'\((\d+),(\d+)\)', re.M | re.S).findall(item)[0]
                        # log(f'usefull_item: {repr(usefull_item)}')
                        start_point = int(usefull_item[0])
                        end_point = int(usefull_item[1])
                        _13x48X = tokenCode
                        # log(f'_13x48X: {repr(_13x48X)}')
                        _71Wxx199 = _13x48X[start_point:end_point][::-1]
                        # log(f'_71Wxx199: {repr(_71Wxx199)}')
                        return _71Wxx199 + usefull_item[1] + return_add
                return ''

            def tsd(tokenCode):
                _13x48X = tokenCode
                # log(_13x48X[6:19]) # get 6 to 19 char ## slice
                # log(_13x48X[6:19][::-1]) # revers the srting
                _71Wxx199 = _13x48X[4:18][::-1]
                return _71Wxx199 + "18" + "432782"
                # _71Wxx199 = _13x48X[4:30][::-1]
                # return _71Wxx199 + "30" + "487395"
            token_code = _tsd_tsd_ds(result, tc)
            # log(f'token_code: {repr(token_code)}')
            headers = {'Host': domain, 'Referer': link, 'User-Agent': UserAgent, 'x-token': token_code}
            urls = request(gomo_link, XHR=True, post=post, headers=headers, output='json', timeout='5')
            for url in urls:
                try:
                    url = prepare_link(url)
                    if not url:
                        continue
                    if 'gomo.to' in url or 'playerhost.net' in url:
                        headers = {'User-Agent': UserAgent, 'Referer': url}
                        url = request(url, headers=headers, output='geturl', timeout='5')
                        url = prepare_link(url)
                        if not url:
                            continue
                        if url == 'http://ww1.gomoplayer.com/':
                            continue
                        if any(i in url for i in gdriveplayer_domains):
                            for source in gdriveplayer(url, hostDict):
                                sources.append(source)
                        else:
                            if item := make_item(hostDict, url, info=info):
                                sources.append(item)
                    else:
                        if item := make_item(hostDict, url, info=info):
                            sources.append(item)
                except:
                    error(f'Error from: {__name__}: url: {url} ')
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return sources


def gdriveplayer(link, hostDict, info=None):
    sources = [] # Last Tested/Checked: 6-28-2023  Status: Working.
    try:
        html = scrapePage.srp_page(link, headers={'User-Agent': UserAgent, 'Referer': link}).text
        servers = parseDOM(html, 'ul', attrs={'class': 'list-server-items'})[0]
        urls = parseDOM(servers, 'a', ret='href')
        for url in urls:
            try:
                if not url or url.startswith('/player.php'):
                    continue
                url = prepare_link(url)
                if not url:
                    continue
                if item := make_item(hostDict, url, info=info):
                    sources.append(item)
            except:
                error(f'Error from: {__name__}: link: {link} ')
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return []

def vidembed(link, hostDict, info=None):
    sources = [] # Last Tested/Checked: 6-28-2023  Status: Working.
    try:
        try:
            html = scrapePage.srp_page(link, headers={'User-Agent': UserAgent, 'Referer': link}).text
            urls = []
            urls += parseDOM(html, 'li', ret='data-video')
            urls += parseDOM(html, 'iframe', ret='src')
            if urls:
                for url in urls:
                    try:
                        url = prepare_link(url)
                        if not url:
                            continue
                        if item := make_item(hostDict, url, info=info):
                            sources.append(item)
                    except:
                        error(f'Error from: {__name__}: url: {url} ')
        except: error(f'Error from: {__name__}: link: {link} ')
        try:
            if item := make_item(hostDict, link, info=info):
                sources.append(item)
            else: log(f'scrape_sources - vidembed - non-item link2: {link}')
        except:
            error(f'Error from: {__name__}: link: {link} ')
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return sources


def vidlink(link, hostDict, info=None):
    sources = [] # Last Tested/Checked: 6-28-2023  Status: Blocked.(update_views page)
    try:
        try:
            postID = link.split('/embed/')[1]
            post_link = 'https://vidlink.org/embed/update_views'
            headers = {'User-Agent': UserAgent, 'Referer': link}
            if ihtml := request(post_link, post={'postID': postID}, headers=headers, XHR=True):
                linkcode = client_utils.unpacked(ihtml)
                linkcode = linkcode.replace('\\', '')
                links = re.findall(r'var file1="(.+?)"', linkcode)[0]
                stream_link = links.split('/pl/')[0]
                headers = {'Referer': 'https://vidlink.org/', 'User-Agent': UserAgent}
                response = scrapePage.srp_page(links, headers=headers).text
                if urls := re.findall(r'[A-Z]{10}=\d+x(\d+)\W[A-Z]+=\"\w+\"\s+\/(.+?)\.', response):
                    for qual, url in urls:
                        url = f'{stream_link}/{url}.m3u8'
                        # qual = qual if info is None else f'{qual} {info}'
                        if item := make_item(hostDict, url, info=info):
                            sources.append(item)
                            #else: log('scrape_sources - vidlink - non-item link: ' + str(url))
        except:
            headers = {'User-Agent': UserAgent, 'Referer': link}
            html = scrapePage.srp_page(link, headers=headers).text
            iframe = parseDOM(html, 'iframe', ret='src')
            for i in iframe:
                for source in process(hostDict, i):
                    sources.append(source)
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return sources


def vidsrc(link, hostDict, info=None):
    sources = [] # Last Tested/Checked: 6-28-2023  Status: Working.
    try: # https://vidsrc.to/embed/tv/72710/1/1
        domain = re.findall(r'(?://|\.)(v2\.vidsrc\.me|vidsrc\.me|vidsrc\.to)/', link)[0]
        headers = {'User-Agent': UserAgent, 'Referer': 'https://%s/' % domain}
        html = request(link, headers=headers)
        items = parseDOM(html, 'div', ret='data-hash')
        for item in items:
            try:
                item_base = 'https://source.%s/source/' % domain
                item_url = item_base + item
                item_html = request(item_url, headers=headers)
                if not item_html:
                    continue
                item_html = item_html.replace("\'", '"')
                item_src = re.findall(r'(?:src|file|source)\s*[:=,]?\s*["\']([^"\']+)', item_html, re.DOTALL)[0]
                item_src = f'https:{item_src}' if item_src.startswith('//') else item_src
                item_link = request(item_src, headers=headers, output='geturl')
                url = prepare_link(item_link)
                if not url:
                    continue
                if item := make_item(hostDict, url, info=info):
                    sources.append(item)
            except:
                error(f'Error from: {__name__}: item: {item} ')
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return sources


def clean_embed(link):
    link = link.replace('/embed/imdb/tv?id=', '/embed/')
    link = link.replace('/embed/imdb/movie?id=', '/embed/')
    link = link.replace('/embed/tmdb/tv?id=', '/embed/')
    link = link.replace('/embed/tmdb/movie?id=', '/embed/')
    #link = link.replace('/embedtv/', '/tv/')
    return link


def twoembed(link, hostDict, info=None):
    sources = [] # Last Tested/Checked: 6-28-2023  Status: Working.
    try:
        link = clean_embed(link)
        link = prepare_link(link)
        if not link: return
        headers = {'User-Agent': UserAgent, 'Referer': link}
        html = scrapePage.srp_page(link, headers=headers).text
        iframe = parseDOM(html, 'iframe', ret='src')[0]
        if iframe == 'about:blank': return
        iframe = clean_embed(iframe)
        #log(f'twoembed iframe: {iframe}')
        iframe_html = scrapePage.srp_page(iframe, headers=headers).text
        # log(f'twoembed iframe_html: {iframe_html}')
        try: iframe_unpacked = client_utils.unpacked(iframe_html)
        except: iframe_unpacked = ''
        if not iframe_unpacked: iframe_unpacked = iframe_html
        iframe_sources = re.findall(r'sources:\[(.+?)\]', iframe_unpacked, re.S)[0]
        #source_link = re.findall(r'(?:file|src)\s*[:=,]?\s*["\']([^"\']+)', iframe_sources)[0]
        source_link = re.findall(r'(?:file|src)\s*(?:\:)\s*(?:\"|\')(.+?)(?:\"|\')', iframe_sources)[0]
        #log(f'twoembed source_link: {source_link}')
        if item := make_direct_item(hostDict, source_link, host='2embed.me', info=info, referer=link):
            sources.append(item)
        #else: log('scrape_sources - twoembed - non-item link: ' + str(url))
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return sources


def furher(link, hostDict, info=None):
    sources = [] # Last Tested/Checked: 8-12-2023  Status: Working.
    try: #https://furher.in/e/g5pjexss0zhm
        embed_html = scrapePage.srp_page(link, headers={'User-Agent': UserAgent, 'Referer': link}).text
        embed_unpacked = client_utils.unpacked(embed_html)
        embed_sources = re.findall(r'sources:\[(.+?)\]', embed_unpacked, re.S)[0]
        source_link = re.findall(r'(?:file|src)\s*[:=,]?\s*["\']([^"\']+)', embed_sources)[0]
        if item := make_direct_item(hostDict, source_link, host='furher.in', info=info, referer=link):
            sources.append(item)
        #else: log('scrape_sources - furher - non-item link: ' + str(url))
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return sources


def hlspanel(link, hostDict, info=None):
    sources = []
    try:
        headers = {'User-Agent': UserAgent, 'Referer': link, 'X-Requested-With': 'XMLHttpRequest'}
        url_hash = link.split('/video/')[1]
        getvid_link = f'https://hlspanel.xyz/player/index.php?data={url_hash}&do=getVideo'
        data = {"hash": url_hash, "r": link}
        page = scrapePage.srp_page(getvid_link, headers=headers, post=data).json()
        url = page["securedLink"]
        if item := make_direct_item(hostDict, url, info=info, referer=link):
            sources.append(item)
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return sources


def superembed(link, hostDict, info=None):
    sources = []
    try:
        #return sources # Not done looking into or coding.
        r = scrapePage.srp_page(link, headers={'User-Agent': UserAgent, 'Referer': link}).text
        i = parseDOM(r, 'iframe', ret='src')[0]
        p = re.findall(r'''window.atob\('(.+?)'\)''', i)[0]
        link = base64.b64decode(p)
        link = ensure_text(link, errors='ignore')
        url = link.replace(r'\/', '/').replace('///', '//')
        if item := make_item(hostDict, url, info=info):
            sources.append(item)
        #else: log('scrape_sources - superembed - non-item link: ' + str(url))
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return sources


def truepoweroflove(link, hostDict, info=None):
    sources = [] # Last Tested/Checked: 10-6-2023  Status: Working.
    try: #https://truepoweroflove.com/e/7ob3wdc0jkjx

        embed_html = scrapePage.srp_page(link, headers={'User-Agent': UserAgent, 'Referer': link}).text
        embed_unpacked = client_utils.unpacked(embed_html)
        embed_sources = re.findall(r'sources:\[(.+?)\]', embed_unpacked, re.S)[0]
        source_link = re.findall(r'(?:file|src)\s*[:=,]?\s*["\']([^"\']+)', embed_sources)[0]
        item = make_direct_item(hostDict, source_link, host='truepoweroflove.com', info=info, referer=link)
        if item:
            sources.append(item)
        #else: log('scrape_sources - truepoweroflove - non-item link: ' + str(url))
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return sources


def ronemo(link, hostDict, info=None):
    sources = []
    try:
        html = scrapePage.srp_page(link, headers={'User-Agent': UserAgent, 'Referer': link}).text
        url = re.findall(r'"link":"(.+?)",', html)[0]
        if item := make_direct_item(hostDict, url, info=info, referer=link):
            sources.append(item)
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return sources


def voxzer(link, hostDict, info=None):
    sources = []
    try:
        link = link.replace('/view/', '/list/')
        html = scrapePage.srp_page(link, headers={'User-Agent': UserAgent, 'Referer': link}).json()
        url = html['link']
        if item := make_direct_item(hostDict, url, info=info, referer=link):
            sources.append(item)
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return sources


def source_stream(link, hostDict, info=None):
    sources = []
    try:
        html = scrapePage.srp_page(link, headers={'User-Agent': UserAgent, 'Referer': link}).text
        url = parseDOM(html, 'source', ret='src')[0]
        if item := make_direct_item(hostDict, url, info=info, referer=link):
            sources.append(item)
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return sources


def get_recaptcha():
    response = requests.get("https://recaptcha.harp.workers.dev/?anchor=https%3A%2F%2Fwww.google.com%2Frecaptcha%2Fapi2%2Fanchor%3Far%3D1%26k%3D6Lf2aYsgAAAAAFvU3-ybajmezOYy87U4fcEpWS4C%26co%3DaHR0cHM6Ly93d3cuMmVtYmVkLnRvOjQ0Mw..%26hl%3Den%26v%3DPRMRaAwB3KlylGQR57Dyk-pF%26size%3Dinvisible%26cb%3D7rsdercrealf&reload=https%3A%2F%2Fwww.google.com%2Frecaptcha%2Fapi2%2Freload%3Fk%3D6Lf2aYsgAAAAAFvU3-ybajmezOYy87U4fcEpWS4C")
    return response.json()["rresp"]


def odnoklassniki(url):
    try:
        if '/safe.php?link=' in url:
            url = url.split('/safe.php?link=')[1]
        url = f'https:{url}' if url.startswith('//') else url
        #log('scrape_sources - odnoklassniki - starting url: ' + str(url))
        media_id = re.compile(r'//.+?/.+?/([\w]+)').findall(url)[0]
        #log('scrape_sources - odnoklassniki - media_id: ' + str(media_id))
        result = request('http://ok.ru/dk', post={'cmd': 'videoPlayerMetadata', 'mid': media_id})
        result = re.sub(r'[^\x00-\x7F]+', ' ', result)
        result = json.loads(result).get('videos', [])
        #log('scrape_sources - odnoklassniki - result: ' + str(result))
        hd = []
        for name, quali in {'ultra': '4K', 'quad': '1440p', 'full': '1080p', 'hd': 'HD'}.items():
            hd += [{'quality': quali, 'url': i.get('url')} for i in result if i.get('name').lower() == name]
        #log('scrape_sources - odnoklassniki - hd: ' + str(hd))
        sd = []
        for name, quali in {'sd': 'SD', 'low': 'SD', 'lowest': 'SD', 'mobile': 'SD'}.items():
            sd += [{'quality': quali, 'url': i.get('url')} for i in result if i.get('name').lower() == name]
        #log('scrape_sources - odnoklassniki - sd: ' + str(sd))
        url = hd + sd[:1]
        #log('scrape_sources - odnoklassniki - final url: ' + str(url))
        if url != []:
            return url
    except:
        error(f'Error from: {__name__}: url: {url} ')
        return


def get_search_startpage(title, site_domain, year=None, search_site='startpage'):
    """
    :Usages: title, r = get_search_startpage('desirulez.cc', tvshowtitle)
    :param title: 'Mere Sai'
    :type title: str
    :param site_domain: 'desirulez.cc'
    :type site_domain: str
    :param year: 2023
    :type year: int
    :param search_site: 'startpage' default or use Google
    :type search_site: str
    :return: to compare title in url with other filter
    :rtype: tuple
    """
    if year: title = f'{title}+{year}'
    title = title.lower().replace(' ', '-').replace('.', '-').replace("â€™", '%92')
    if 'startpage' in search_site: search_url = f'https://www.startpage.com/do/search?q={title}+sites:{site_domain}'
    else: search_url = f'https://www.google.com/search?hl=en&as_q={title}&as_epq=&as_oq=&as_eq=&as_nlo=&as_nhi=&lr=&cr=&as_qdr=all&as_sitesearch={site_domain}&as_occt=&safe=images&as_filetype=&as_rights=not+filtered+by+license&tbs='

    log(f'title: {title} search_url: {search_url}')
    result = scrapePage.srp_page(search_url, headers=dnt_headers).text
    if 'startpage' in search_url: r = parseDOM(result, 'div', attrs={'class': 'w-gl__result-second-line-container'})
    else: r = parseDOM(result, 'div', attrs={'id': 'search'})
    if 'startpage' in search_url: urls = parseDOM(r, 'a', ret='href')
    # log(f'title: {title} urls: {urls}')
    return title, urls


def get_movcloud(link):
    try:
        url = link.replace('https://movcloud.net/embed/', 'https://api.movcloud.net/stream/')
        resp = scrapePage.srp_page(url, headers={'User-Agent': UserAgent, 'Referer': 'https://movcloud.net'}).json()
        url = resp['data']
        url = url['sources']
        return url
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return []

def movcloud(link, hostDict):
    sources = []
    try:
        urls = get_movcloud(link)
        for url in urls:
            label = url['label']
            url = url['file']
            quality, info = get_release_quality(label, label)
            if item := make_item(hostDict, url, info=info):
                sources.append(item)
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return []


def vidcloud9(link, hostDict):
    sources = []
    try:
        # log("link:%s" % link)
        if not link.endswith('.m3u8'):
            resp = scrapePage.srp_page(link, headers={'User-Agent': UserAgent, 'Referer': link}).text
            # resp = ensure_str(url, errors='replace')
            # log("resp:%s" % resp)
            url = re.compile(r'data-video="(.+?)">.+?</li>').findall(resp)
            for url in url:
                if url.startswith('//'):
                    url = f'https:{url}'
                if 'vidnext.net' in url:
                    if '&typesub' in url:
                        resp = scrapePage.srp_page(link, headers={'User-Agent': UserAgent, 'Referer': link}).text
                        # resp = ensure_str(url, errors='ignore')
                        url = re.findall(r'(?:file)\s*[:=,]?\s*["\']([^"\']+)', resp)[0]
                        if item := make_item(hostDict, url):
                            sources.append(item)
                    else:
                        resp = scrapePage.srp_page(url, headers={'User-Agent': UserAgent, 'Referer': link}).text
                        # resp = ensure_str(iurl, errors='ignore')
                        urls = re.findall(r'data-video="(.+?)">', resp)
                        for url in urls:
                            if url.startswith('//'):
                                url = f'https:{url}'
                            if 'vidnext.net' in url:
                                resp = scrapePage.srp_page(url, headers={'User-Agent': UserAgent, 'Referer': url}).text
                                # resp = ensure_str(url, errors='ignore')
                                r = re.findall(r'(ep.+?.m3u8)', resp)
                                for r in r:
                                    url = url.split('ep')[0]
                                    url = url + r
                                    if item := make_item(hostDict, url):
                                        sources.append(item)
                            else:
                                if item := make_item(hostDict, url):
                                    sources.append(item)

                elif 'movcloud' in url:
                    urls = get_movcloud(link)
                    for url in urls:
                        label = url['label']
                        url = url['file']
                        quality, info = get_release_quality(label, label)
                        if item := make_item(hostDict, url, info=info):
                            sources.append(item)
                else:
                    if item := make_item(hostDict, url):
                        sources.append(item)
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return []


def vidcloud_pro(link, hostDict):
    sources = []
    try:
        resp = request(link, headers={'User-Agent': UserAgent, 'Referer': link})
        # resp = ensure_str(url, errors='ignore')
        url = re.findall(r'''sources = \[\{file["']?\s*[:=]?\s*["']([^"']+),"type"''', resp)[0]
        url = url.replace('\\', '')
        if item := make_item(hostDict, url):
            sources.append(item)
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return []


def vidsrc_me(link, hostDict):
    sources = []
    try:
        resp = request(link, headers={'User-Agent': UserAgent, 'Referer': 'https://v2.vidsrc.me'})
        # resp = ensure_str(r, errors='ignore')
        r = re.findall(r'data-hash="(.+?)"', resp)[0]
        r = f'https://v2.vidsrc.me/src/{r}'
        resp = request(r, headers={'User-Agent': UserAgent, 'Referer': 'https://v2.vidsrc.me'})
        # resp = ensure_str(url, errors='ignore')
        url = re.findall(r"'player' src='(.+?)'", resp)[0]
        # url = f'{url}|Referer=https://vidsrc.me'
        if item := make_direct_item(hostDict, url, referer='https://vidsrc.me'):
            sources.append(item)
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return []


def vidnext_net(link, hostDict):
    sources = []
    try:
        if 'vidnext.net' in link:
            if '&typesub' in link:
                resp = request(link, headers={'User-Agent': UserAgent, 'Referer': link})
                # resp = ensure_str(url, errors='ignore')
                url = re.findall(r'file\s*[:=]?\s*["\']([^"\']+)', resp)[0]
                if item := make_item(hostDict, url):
                    sources.append(item)
            else:
                resp = request(link, headers={'User-Agent': UserAgent, 'Referer': link})
                # resp = ensure_str(url, errors='ignore')
                url = re.findall(r'data-video="(.+?)">', resp)
                for url in url:
                    if url.startswith('//'):
                        url = f'https:{url}'
                    if 'vidnext.net' in url:
                        resp = request(url, headers={'User-Agent': UserAgent, 'Referer': url})
                        # resp = ensure_str(url, errors='ignore')
                        r = re.findall(r'(ep.+?.m3u8)', resp)
                        for r in r:
                            url = url.split('ep')[0]
                            url = url + r
                            if item := make_item(hostDict, url):
                                sources.append(item)

        else:
            if item := make_item(hostDict, link):
                sources.append(item)

        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return []


def hls3x(link, hostDict):
    sources = []
    try:
        resp = scrapePage.srp_page(link, headers={'User-Agent': UserAgent, 'Referer': link}).text
        # resp = ensure_str(url, errors='ignore')
        r = re.findall(r'(ep.+?.m3u8)', resp)
        for r in r:
            url = url.split('ep')[0]
            url = url + r
            if item := make_item(hostDict, url):
                sources.append(item)
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return []


def vidoo(link, hostDict):
    sources = []
    try:
        resp = scrapePage.srp_page(link, headers={'User-Agent': UserAgent, 'Referer': link}).text
        # resp = ensure_str(url, errors='ignore')
        r = re.findall(r'file\s*[:=]?\s*["\']([^"\']+)\},\{file:".+?",label:"(.+?)"', resp)
        for r in r:
            resp = scrapePage.srp_page(r[0], headers={'User-Agent': UserAgent, 'Referer': link}).text
            # resp = ensure_str(r, errors='ignore')
            url = re.findall(r'(https://.+?m3u8)', resp)[0]
            if item := make_item(hostDict, url):
                sources.append(item)
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return []


def mediashore(link, hostDict):
    sources = []
    try:
        try:
            resp = scrapePage.srp_page(link, headers={'User-Agent': UserAgent, 'Referer': link}).text
            # resp = ensure_str(url, errors='ignore')
            url = re.findall(r'<title>(.+?)</title>', resp)[0]
            if item := make_item(hostDict, url):
                sources.append(item)
        except:
            if item := make_item(hostDict, link):
                sources.append(item)
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return []


def abcvideo(link, hostDict):
    sources = []
    try:
        try:
            if 'html' in link:
                resp = scrapePage.srp_page(link, headers={'User-Agent': UserAgent, 'Referer': link}).text
                # resp = ensure_str(url, errors='ignore')
                url = re.findall(r'jwplayer.qualityLabel\', \'(.+?)\'', resp)[0]
            else:
                resp = scrapePage.srp_page(link, headers={'User-Agent': UserAgent, 'Referer': link}).text
                # resp = ensure_str(url, errors='ignore')
                url = re.findall(r'<title>(.+?)</title>', resp)[0]
            if item := make_item(hostDict, url):
                sources.append(item)
        except:
            if item := make_item(hostDict, link):
                sources.append(item)
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return []


def cloudvideo(link, hostDict):
    sources = []
    try:
        try:
            resp = scrapePage.srp_page(link, headers={'User-Agent': UserAgent, 'Referer': link}).text
            # resp = ensure_str(url, errors='ignore')
            url = re.findall(r'<title>(.+?)</title>', resp)[0]
            if item := make_item(hostDict, url):
                sources.append(item)
        except:
            if item := make_item(hostDict, link):
                sources.append(item)
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return []


def vidoza(link, hostDict):
    sources = []
    try:
        try:
            resp = scrapePage.srp_page(link, headers={'User-Agent': UserAgent, 'Referer': link}).text
            # resp = ensure_str(url, errors='ignore')
            url = re.findall(r'CONTENT="(.+?)">', resp)[0]
            if item := make_item(hostDict, url):
                sources.append(item)
        except:
            if item := make_item(hostDict, link):
                sources.append(item)
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return []


def fmovies_to(link, hostDict):
    sources = []
    try:
        r = scrapePage.srp_page(link).text
        # links = re.findall(r'''(?:src|file)\s*[:=]?\s*["']([^"']+)''', r)
        # links = parseDOM(r, 'ul', ret='data-video')
        # links = parseDOM(r, 'ul', attrs={'class': r'list-server-items.*?'})
        links = parseDOM(r, 'iframe', ret='src')
        # log(f'fmovies_to links: {links}')
        sources.extend({'source': 'fmovies', 'quality': '720p', 'url': url, 'direct': True,} for url in links)
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return []

################


def mixdrop(link, hostDict):
    sources = []
    try:
        try:
            if '?' in link: link = link.split('?')[0]
            resp = request(link, headers={'User-Agent': UserAgent, 'Referer': link})
            if not resp: request(link, verify=False, headers={'User-Agent': UserAgent, 'Referer': link})
            # resp = ensure_str(url, errors='ignore')
            url = re.findall(r'target="_blank">(.+?)</a>', resp)[0]
            if item := make_item(hostDict, url):
                sources.append(item)
        except:
            if item := make_item(hostDict, link):
                sources.append(item)
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return []


def upstream(link, hostDict):
    sources = []
    try:
        try:
            resp = request(link, headers={'User-Agent': UserAgent, 'Referer': link})
            # resp = ensure_str(url, errors='ignore')
            url = re.findall(r'</i>(.+?)</span>', resp)[0]
            if item := make_item(hostDict, url):
                sources.append(item)
        except:
            if item := make_item(hostDict, link):
                sources.append(item)
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return []


def gamovideo(link, hostDict):
    sources = []
    try:
        try:
            # url = request(link, headers={'User-Agent': UserAgent, 'Referer': link})
            url = request(link, headers={'User-Agent': UserAgent, 'Referer': link})
            # url = read_write_file(file_n='gomostream.com.html')
            url = re.findall(r'<Title>(.+?)</Title>', url)
            if item := make_item(hostDict, url):
                sources.append(item)
        except:
            if item := make_item(hostDict, link):
                sources.append(item)
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return []


def more_rapidvideo(link, hostDict, lang, info):
    if "rapidvideo.com" not in link:
        return []
    sources = []
    try:
        headers = {
            'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3555.0 Safari/537.36"}
        response = request(link, headers=headers)
        test = re.findall(r'''(https:\/\/www.rapidvideo.com\/e\/.*)">''', response)
        numGroups = len(test)
        for i in range(1, numGroups):
            url = test[i]
            if item := make_item(hostDict, url):
                sources.append(item)
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return sources


def more_cdapl(link, hostDict, lang, info):
    if "cda.pl" not in link:
        return []
    sources = []
    try:
        headers = {
            'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3555.0 Safari/537.36"}
        response = request(link, headers=headers)
        test = parseDOM(response, 'div', attrs={'class': 'wrapqualitybtn'})
        if urls := parseDOM(test, 'a', ret='href'):
            for url in urls:
                valid, host = is_host_valid(url, hostDict)
                q = check_url(url)
                direct = re.findall(r'''file["']?\s*[:=]?\s*["']([^"']+),"file_cast''', request(url, headers=headers))[
                    0].replace("\\/", "/")
                sources.append({'source': 'cda', 'quality': q, 'url': direct, 'info': info, 'direct': True})
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return sources


def more_vidnode(link, hostDict):
    sources = []  # By Shellc0de
    try:
        headers = {'Host': 'vidnode.net', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 'Upgrade-Insecure-Requests': '1', 'Accept-Language': 'en-US,en;q=0.9'}
        response = request(link, headers=headers, timeout=5)
        if urls := re.findall(
            r'''\{file\s*[:=]?\s*["']([^"']+).*?label:\s*['"](\d+\s*P)['"]''',
            response,
            re.DOTALL | re.I,
        ):
            for url, qual in urls:
                quality, info = get_release_quality(qual, url)
                host = url.split('//')[1].replace('www.', '')
                host = host.split('/')[0].lower()  # 'CDN'
                sources.append({'source': host, 'quality': quality, 'url': url, 'info': info, 'direct': True})
        return sources
    except:
        error(f'Error from: {__name__}: link: {link} ')
        return sources