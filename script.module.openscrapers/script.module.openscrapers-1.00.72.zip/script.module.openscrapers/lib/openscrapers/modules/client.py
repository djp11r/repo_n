# -*- coding: utf-8 -*-
"""
    OpenScrapers Module
"""
import re
import socket
import ssl
from dataclasses import dataclass
from gzip import GzipFile
from html import unescape
from io import BytesIO
from json import dumps, loads
from random import choice
from time import sleep, time
from traceback import format_exc, print_exc
from typing import Any, Dict, Iterable, Literal, Optional, Tuple, Union
from urllib.error import HTTPError, URLError
from urllib.parse import quote_plus, urlencode, urljoin, urlparse, parse_qs, unquote_plus

import requests
import urllib3
from openscrapers.modules import cache, cfscrape, client_utils, pyaes
from openscrapers.modules.control import dataPath, existsPath, get_useragent, setting, translate_path
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.log_utils import error as lerror, log
from openscrapers.modules.utils import byteify, get_headers_parse_url
from openscrapers.modules.build_session import build_session
from requests import Response, Session, Timeout

from requests.exceptions import RequestException, SSLError
from urllib3.exceptions import InsecureRequestWarning, ProtocolError

urllib3.disable_warnings(InsecureRequestWarning)
try: cache_resp = setting('cache_resp') == 'true'
except: cache_resp = True
_COOKIE_HEADER = "Cookie"
_HEADER_RE = re.compile(r"^([\w\d-]+?)=(.*?)$")

Headers = Dict[str, str]

# Regex to detect <meta charset="..."> or <meta http-equiv="Content-Type" ...>
META_CHARSET_RE = re.compile(rb'<meta[^>]+charset=["\']?([a-zA-Z0-9_\-]+)["\']?', re.IGNORECASE)
CONTENT_TYPE_RE = re.compile(rb'<meta[^>]+content=["\'][^>]*charset=([a-zA-Z0-9_\-]+)["\']', re.IGNORECASE)
UserAgent = cache.get(get_useragent, 2)

def agent():
    return UserAgent

def mobileagent(mobile='android'):
    _mobagents = [
        'Mozilla/5.0 (Linux; Android 13; T771K Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/130.0.6723.107 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/479.0.0.48.89;]',
        'Mozilla/5.0 (Linux; Android 14; V2339 Build/UP1A.231005.007; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/131.0.6778.39 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/491.0.0.58.78;IABMV/1;]',
        'Mozilla/5.0 (Linux; Android 14; RMX3708 Build/UP1A.231005.007; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/130.0.6723.83 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/488.0.0.78.79;IABMV/1;] FBNV/5',
        'Mozilla/5.0 (Linux; Android 14; 2409BRN2CA Build/UP1A.231005.007; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/130.0.6723.108 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/486.0.0.66.70;IABMV/1;]',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 17_7_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.7.2 Mobile/15E148 Safari/605.1.15 NewsSapphire/29.8.421122001',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 17_7_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.7.1 Mobile/15E148 Safari/605.1.15 BingSapphire/1.0.420822001',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 18_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1.1 Mobile/15E148 Safari/605.1.15 BingSapphire/29.6.421107001']

    if mobile == 'android': return choice(_mobagents[:4])
    else: return choice(_mobagents[5:7])


dnt_headers = {
    'User-Agent': UserAgent,
    'Accept': '*/*',
    'Accept-Encoding': 'identity;q=1, *;q=0',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'DNT': '1',
}

fheaders = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',
    'Accept-Language': 'en-US,en;q=0.5',
    'Accept-Encoding': 'gzip, deflate',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
    'Connection': 'keep-alive',
    'DNT': '1',
    'Sec-Gpc': '1',
    'Upgrade-Insecure-Requests': '1',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-User': '?1',
    'x-requested-with': 'XMLHttpRequest', }
# 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
# 'sec-fetch-site': 'cross-site',
# }


# Internal helpers


def _detect_bom(response: bytes) -> str | None:
    """Detect common BOMs and return the corresponding encoding."""
    if response.startswith(b'\xef\xbb\xbf'): return 'utf-8-sig'
    if response.startswith(b'\xff\xfe\x00\x00'): return 'utf-32-le'
    if response.startswith(b'\x00\x00\xfe\xff'): return 'utf-32-be'
    if response.startswith(b'\xff\xfe'): return 'utf-16-le'
    if response.startswith(b'\xfe\xff'): return 'utf-16-be'
    return None


def _detect_html_charset(response: bytes) -> str | None:
    """Extract charset from HTML <meta> tags."""
    m = META_CHARSET_RE.search(response)
    if m:
        return m.group(1).decode('ascii', 'ignore')

    m = CONTENT_TYPE_RE.search(response)
    if m:
        return m.group(1).decode('ascii', 'ignore')

    return None


def brutforce_decode(response: bytes, encoding: str = 'utf-8', errors: str = 'replace', *, extra_fallbacks: Iterable[str] = (), debug: bool = False) -> str | bytes:
    """
    Robust decoding helper with BOM detection, HTML charset sniffing,
    JSON BOM stripping, and ordered fallback encodings.

    Returns decoded text, or raw bytes if all attempts fail.
    """

    if debug: log(f'Starting brutforce_decode: {len(response):d} bytes')

    # ---------------------------------------------------------
    # 0. Handle None or already-decoded strings
    # ---------------------------------------------------------
    if response is None:
        if debug: log("decode_none")
        return None

    if isinstance(response, str):
        if debug: log("decode_already_str")
        return response

    # Must be bytes from here on
    # 1. BOM detection
    bom_enc = _detect_bom(response)
    if bom_enc:
        try:
            if debug: log(f'Detected BOM encoding: {bom_enc}')
            return response.decode(bom_enc, errors=errors)
        except Exception as e:
            if debug: log(f'BOM decode failed: {e}')

    # 2. HTML charset sniffing
    sniffed = _detect_html_charset(response)
    if sniffed:
        try:
            if debug: log(f'Detected HTML charset: {sniffed}')
            return response.decode(sniffed, errors=errors)
        except Exception as e:
            if debug: log(f'HTML charset decode failed: {e}')

    # 3. JSON BOM stripping (common in APIs)
    if response.startswith(b'\xef\xbb\xbf'):
        try:
            if debug: log('Stripping UTF‑8 BOM for JSON')
            return response[3:].decode('utf-8', errors=errors)
        except Exception as e:
            if debug: log(f'JSON BOM decode failed: {e}')

    # 4. Fallback
    fallbacks = [encoding,  # user‑preferred (default utf‑8)
        'utf-8', 'latin-1', 'iso-8859-1', *extra_fallbacks,  # user‑supplied extras
    ]

    for enc in fallbacks:
        try:
            if debug: log(f'Trying fallback encoding: {enc}')
            return response.decode(enc, errors=errors)
        except Exception: continue

    # 5. Give up — return raw bytes
    if debug: log('All decoding attempts failed; returning raw bytes')
    return response

def _strip_url(url):
    return get_headers_parse_url(url)

def _url_with_headers(url, headers):
    if not headers: return url
    return f'{url}|{urlencode(headers)}'

def strip_cookie_url(url):
    url, headers = _strip_url(url)
    if _COOKIE_HEADER in headers:
        del headers[_COOKIE_HEADER]
    return _url_with_headers(url, headers)

def get_referer(url):
    parsed_url = urlparse(url)
    return f'{parsed_url.scheme}://{(parsed_url.netloc or parsed_url.path)}/'

def build_headers(url: str, headers: Optional[Headers], mobile: bool, XHR: bool, referer: Optional[str], cookie: Optional[Union[str, Dict[str, str]]],):
    """Construct final request headers."""
    final: Headers = dict(headers or {})
    # Normalize URL
    url = f"https:{url}" if url.startswith("//") else url
    # Parse inline headers in URL
    if "|" in url:
        url, extra_headers = get_headers_parse_url(url)
        final.update(extra_headers)

    if "User-Agent" not in final:
        if mobile: final["User-Agent"] = cache.get(mobileagent, 2)
        else: final["User-Agent"] = UserAgent

    if "Referer" not in final:
        final["Referer"] = referer if referer is not None else get_referer(url)

    # Basic defaults
    final.setdefault("Accept-Language", "en-US,en")
    final.setdefault("Accept", "*/*")

    # XHR
    if XHR and "X-Requested-With" not in final:
        final["X-Requested-With"] = "XMLHttpRequest"

    # Cookies
    if cookie is not None:
        if isinstance(cookie, dict):
            cookie = "; ".join(f"{k}={v}" for k, v in cookie.items())
        final["Cookie"] = cookie

    # Compression
    final.setdefault("Accept-Encoding", "gzip")

    return url, final

def prepare_cookies(session: Session, url: str) -> None:
    """Load persistent cookies from disk into the session."""
    js = cache.cache_get(f'{urlparse(url).netloc}_cookies')
    if js:
        log(f'js: {type(js)} ...  {repr(js)}')
        try:
            if isinstance(js, dict): session.headers.update(js)
            else: session.headers.update(loads(str(js)))
        except Exception as err:
            log(f'prepare_cookies err: {type(err)} ...  {repr(err)}')


def send_request(session: Session, method: str, url: str, headers: Headers, post: Optional[Union[str, Dict[str, Any]]], timeout: int, allow_redirects: bool,) -> Response:
    """Send the HTTP request using requests."""
    if isinstance(post, dict): # JSON posting (your choice #2)
        return session.request(method, url, json=post, headers=headers, timeout=timeout, allow_redirects=allow_redirects)
    elif isinstance(post, str): return session.request(method, url, data=post.encode("utf-8"), headers=headers, timeout=timeout, allow_redirects=allow_redirects,)
    else: return session.request(method, url, headers=headers, timeout=timeout, allow_redirects=allow_redirects,)


OutputMode = Literal["text", "json", "elapsed", "file_size", "extended", "cookie", "geturl", "chunk", "headers", "response"]

def format_output_(response: Optional[Response], output: OutputMode, headers: Optional[Dict[str, str]] = None, session: Optional[Session] = None, request_headers: Optional[Dict[str, str]] = None,) -> Any:
    """
    Unified output formatter combining behavior of both legacy functions.
    Compatible with Python 3.14 and preserves all existing output modes.
    """

    if response is None: return None

    # Cookie source priority:
    # 1. session cookies (if provided) # 2. response cookies (fallback)
    def get_cookie_string() -> str:
        if session is not None: cookies = session.cookies.get_dict()
        else: cookies = response.cookies.get_dict()
        return "; ".join(f"{k}={v}" for k, v in cookies.items())

    match output:
        case "json": return response.json()
        case "headers": return dict(response.headers)
        case "geturl": return response.url
        case "cookie": return get_cookie_string()
        case "elapsed": return int(response.elapsed.total_seconds() * 1000)
        case "chunk": return response.text
        case "file_size": return int(response.headers.get("Content-Length", len(response.content)))
        case "timing": return response._timings if hasattr(response, "_timings") else {}
        case "response": return response # Your older version returned response.text, newer version returned the Response object. Keeping the more useful behavior:
        case "extended":
            cookie_str = get_cookie_string()
            return response.text, headers or request_headers or {}, dict(response.headers), cookie_str, response.url,
        case "text": return response.text # Default: raw text
        case _: return response.text # Default: raw text


def handle_cloudflare(url: str, headers: Dict[str, str], post: Optional[Union[str, Dict[str, Any], bytes]], timeout: int, verify: bool, session: Session, response: Response,) -> Response:
    """
    Unified Cloudflare handler combining:
      - HTML marker detection (old cloudflare_fallback)
      - Server header + status detection (old _handle_cloudflare_if_needed)
      - CSRF extraction
      - Cookie injection
      - cfscrape() fallback
      - Proxy fallback
    """

    status = response.status_code
    server = response.headers.get("Server", "").lower()
    text_lower = response.text.lower()

    # --- Cloudflare detection ---
    html_markers = ["__cf_chl_", "cf-browser-verification", "challenge-platform"]
    html_detected = any(marker in text_lower for marker in html_markers)
    header_detected = status in {403, 503} and server == "cloudflare"

    if not (html_detected or header_detected):
        return response

    # log(f"HttpClient: Cloudflare detected for {url}")

    # --- Step 1: Try fallback URL to extract CSRF + cookies ---
    try:
        fallback_url = get_referer(url)[:-1]
        cf_resp = session.get(fallback_url, timeout=timeout, verify=verify)

        cookies_dict = session.cookies.get_dict()
        csrf = re.findall(
            r'csrf\-token"\s*content\s*=\s*"([^"]+)"',
            cf_resp.text,
            re.DOTALL,
        )

        if cookies_dict:
            headers.update(cookies_dict)

        if csrf:
            headers["X-CSRF-TOKEN"] = csrf[0]

    except Exception as e:
        log(f"HttpClient: fallback URL fetch failed: {e}")

    # --- Step 2: Try cfscrape() (primary solution) ---
    scraper = cfscrape.CloudScraper()
    cf_alt = scraper.request(method='GET' if post is None else 'POST', url=url, headers=headers, data=post, timeout=int(timeout),)
    if cf_alt.status_code == 403: cf_alt = scraper.request(method='GET' if post is None else 'POST', url=url, data=post, timeout=int(timeout),)

    if cf_alt:
        log(f"HttpClient: Cloudflare detected and using cfscrape for {url}")
        return cf_alt

    # --- Step 3: Proxy fallback ---
    try:
        from openscrapers.modules.proxy import get_proxy_url

        proxy_url = get_proxy_url(url)
        if proxy_url:
            log(f"HttpClient: using proxy_url {proxy_url}")
            if post is not None:
                return session.post(proxy_url, data=post, timeout=timeout)
            return session.get(proxy_url, timeout=timeout)
    except Exception as e:
        log(f"HttpClient: proxy fallback failed: {e}")

    # --- Step 4: Give up, return original response ---
    return response


# Public API: request() — signature and behavior preserved

def request(url: str, headers: Optional[Headers] = None, post: Optional[Union[str, Dict[str, Any]]] = None, close: bool = True, redirect: bool = True, verify: bool = True, mobile: bool = False, XHR: bool = False, referer: Optional[str] = None, cookie: Optional[Union[str, Dict[str, str]]] = None, output: str = "text", timeout: str = "15", cache_: bool = cache_resp, compression: bool = False, error: bool = False, limit: Optional[str] = None, jpost: bool = False, cfflare: bool = False,) -> Any:
    """Modern hybrid request function using requests."""
    if not url: return None

    # Cache check
    if cache_ and (cached := cache.cache_get(url)):
        return cached.get("text")

    url, final_headers = build_headers(url=url, headers=headers, mobile=mobile, XHR=XHR, referer=referer, cookie=cookie,)
    session = build_session(url, verify)
    prepare_cookies(session, url)


    try:
        response = send_request(
            session=session,
            method="POST" if post else "GET",
            url=url,
            headers=final_headers,
            post=post,
            timeout=int(timeout),
            allow_redirects=redirect,
        )
    except requests.RequestException as err:
        lerror(f"Request error: {err}\nurl: {url}\nheaders: {final_headers}")
        return None

    # Cloudflare fallback
    response = handle_cloudflare(url=url, headers=final_headers, post=post, timeout=int(timeout), verify=verify, session=session, response=response,)

    # Output formatting
    # result = format_output(response, output, final_headers, True)
    result = format_output_(response=response, output=output, headers=final_headers, session=session,)
    # Cache insert
    if cache_ and output not in ("elapsed", "response", "file_size"):
        cache.cache_insert(url, {"text": result})
    if scookies:= session.cookies.get_dict():
        cache.cache_insert(f'{urlparse(url).netloc}_cookies', scookies)
    if close:
        session.close()

    return result



@dataclass
class CResponse:
    text: str
    status_code: int
    headers: Dict[str, Any]
    cookies: Dict[str, Any]
    url: str


class HttpClient:
    def __init__(self, cache_enabled: bool = True, max_retries: int = 3, backoff_base: float = 1.0, verify_default: bool = True,) -> None:
        self.cache_enabled = cache_enabled
        self.max_retries = max_retries
        self.backoff_base = backoff_base
        self.verify_default = verify_default

    # ------------- Public API -------------

    def srp_page(self, url: str, headers: Optional[Dict[str, str]] = None, post: Optional[Union[Dict[str, Any], str, bytes]] = None, referer: Optional[str] = None, cookie: Optional[str] = None, timeout: int = 10, verify: Optional[bool] = None, output: OutputMode = "response", mobile: bool = False, XHR: bool = False,) -> Any:
        if not url: return None

        verify = self.verify_default if verify is None else verify

        try:
            #url, headers = self._prepare_url_and_headers(url=url, headers=headers, referer=referer, mobile=mobile, XHR=XHR, verify=verify,)
            url, headers = build_headers(url=url, headers=headers, referer=referer, mobile=mobile, XHR=XHR, cookie=cookie,)
            # Cache lookup
            if self.cache_enabled:
                cached = cache.cache_get(url)
                if cached:
                    return CResponse(text=cached.get("text", ""), status_code=cached.get("status_code", 0), headers=cached.get("headers", {}), cookies=cached.get("cookies", {}), url=cached.get("url", url),)

            post_data = self._prepare_post_data(post)

            response, session = self._request_with_retries(url=url, post_data=post_data, timeout=timeout, verify=verify, cookie=cookie, headers=headers,)

            # Cache store
            if self.cache_enabled and response is not None:
                cache.cache_insert(url, {"text": response.text, "status_code": response.status_code, "headers": dict(response.headers), "url": response.url, "cookies": session.cookies.get_dict(),},)
            if scookies:= session.cookies.get_dict():
                cache.cache_insert(f'{urlparse(url).netloc}_cookies', scookies)
            # return format_output(response=response, output=output, headers=headers,)
            return format_output_(response=response, output=output, headers=headers, session=session,)

        except Exception as e:
            lerror(f"HttpClient.scrape_page error: {e} url={url}")
            return None

    # ------------- Internal helpers -------------

    def _prepare_url_and_headers(self, url: str, headers: Optional[Dict[str, str]], referer: Optional[str], mobile: bool, XHR: bool, verify: bool,) -> Tuple[str, Dict[str, str]]:
        # Normalize URL
        url = f"https:{url}" if url.startswith("//") else url
        headers = headers.copy() if headers else {}

        # Parse inline headers in URL
        if "|" in url:
            url, extra_headers = get_headers_parse_url(url)
            headers.update(extra_headers)

        # Handle verify override
        if headers.get("verifypeer") == "false":
            verify = False
            headers.pop("verifypeer", None)

        # User-Agent
        if "User-Agent" not in headers:
            if mobile: headers["User-Agent"] = cache.get(mobileagent, 2)
            else: headers["User-Agent"] = UserAgent

        # Referer
        if "Referer" not in headers: headers["Referer"] = referer or get_referer(url)

        # Defaults
        headers.setdefault("Accept-Language", "en-US,en")
        headers.setdefault("Accept", "*/*")
        if XHR: headers.setdefault("X-Requested-With", "XMLHttpRequest")

        # Encode URL safely
        url = quote_plus(url, safe="%/:=&?~#+!$,;'@()*[]|")

        return url, headers

    def _prepare_post_data(self, post: Optional[Union[Dict[str, Any], str, bytes]],) -> Optional[bytes]:
        if post is None: return None
        if isinstance(post, dict): return urlencode(post).encode()
        if isinstance(post, str): return post.encode()
        if isinstance(post, bytes): return post
        raise TypeError(f"Unsupported post type: {type(post)}")

    def _request_with_retries(self, url: str, post_data: Optional[bytes], timeout: int, verify: bool, cookie: Optional[str], headers: Dict[str, str],) -> Tuple[Response, Session]:
        last_exc: Optional[Exception] = None
        session = build_session(url, verify)
        prepare_cookies(session, url)

        for attempt in range(self.max_retries):
            backoff = self.backoff_base * (2 ** attempt) if attempt > 0 else 0
            if backoff > 0: sleep(backoff)

            with session:
                session.headers.update(headers)
                if cookie: session.headers.setdefault("Cookie", cookie)
                if "User-Agent" not in session.headers: session.headers["User-Agent"] = agent()

                try:
                    response = (
                        session.post(url, data=post_data, timeout=timeout, verify=verify)
                        if post_data is not None
                        else session.get(url, timeout=timeout, verify=verify)
                    )
                    response.encoding = "utf-8"
                    response = handle_cloudflare(url=url, headers=headers, post=post_data, timeout=timeout, verify=verify, response=response, session=session, )
                    return response, session
                except Exception as e:
                    # --- SPECIAL CASE: gaierror inside ProtocolError ---
                    if isinstance(e, ProtocolError) and isinstance(e.__cause__, socket.gaierror):
                        log(f"HttpClient: DNS resolution failed, not retrying: {e} url={url}")
                        return None#raise  or , return (None, session)
                    # --- NORMAL RETRY PATH ---
                    if isinstance(e, (SSLError, Timeout, ConnectionError, HTTPError, RequestException)):
                        last_exc = e
                        log(f"HttpClient attempt {attempt+1}/{self.max_retries} failed: {e} url={url}")
                        continue
                    # Anything else → re-raise
                    raise

        if last_exc: raise last_exc
        raise RuntimeError("HttpClient: request_with_retries failed without exception")


scrapePage = HttpClient(cache_enabled=cache_resp)
# Public API: scrapePage.srp_page(url: str, headers: Optional[Dict[str, str]] = None, post: Optional[Union[Dict[str, Any], str, bytes]] = None, referer: Optional[str] = None, cookie: Optional[str] = None, timeout: int = 10, verify: Optional[bool] = None, output: OutputMode = "", mobile: bool = False, XHR: bool = False,) -> Any:


def url_ok(url): #  Old Code Saved.
    r = requests.get(url, headers=dnt_headers)
    return r.status_code in [200, 301]


class cfcookie:
    def __init__(self):
        self.cookie = None
        self.ua = None

    def get(self, netloc, timeout):
        try:
            self.netloc = netloc
            self.timeout = timeout
            self._get_cookie(netloc, timeout)
            if self.cookie:
                cfdata = dumps({'Cookie': self.cookie, 'User-Agent': self.ua})
                cache.cache_insert(f'{urlparse(netloc).netloc}_cookies', cfdata)
                log(f'{netloc} returned cookie. collect tokens.')
            return (self.cookie, self.ua)
        except:
            lerror(f'Error from: {__name__}: netloc: {netloc} ')
            return (self.cookie, self.ua)

    def _get_cookie(self, netloc, timeout):
        if setting('fs_enable') == 'true':
            bypass_url = setting('fs_url')
            fs_timeout = int(setting('fs_timeout'))
            if not bypass_url.startswith('http'):
                log('Sorry, malformed flaresolverr url', 'error')
                return
            post = {'cmd': 'request.get', 'url': netloc, 'returnOnlyCookies': True, 'maxTimeout': fs_timeout * 1000}
        else:
            bypass_url = urljoin(setting('cs_url'), '/cf-clearance-scraper')
            if not bypass_url.startswith('http'):
                log('Sorry, malformed cf-clearance-scraper url', 'error')
                return
            post = {'url': netloc, 'mode': 'waf-session'}

        resp = request(bypass_url, post=post)
        if resp:
            resp = loads(resp)
            if setting('fs_enable') == 'true':
                soln = resp.get('solution')
                if soln.get('status') < 300:
                    cookie = '; '.join(['%s=%s' % (i.get('name'), i.get('value')) for i in soln.get('cookies')])
                    if 'cf_clearance' in cookie:
                        self.cookie = cookie
                        self.ua = soln.get('userAgent')
                    else:
                        log(f'{netloc} returned an error. Could not collect tokens.')
            else:
                if resp.get('code') < 300:
                    rheaders = resp.get('headers')
                    cookies = resp.get('cookies')
                    cookies = {x.get('name'): x.get('value') for x in cookies}
                    if 'cf_clearance' in cookies.keys():
                        self.cookie = "; ".join([x + "=" + y for x, y in cookies.items()])
                        self.ua = rheaders.get('user-agent')
                    else:
                        log(f'{netloc} returned an error. Could not collect tokens.', 'error')
        else:
            try:
                response = scrapePage.srp_page(bypass_url, post=post)
                self.ua = response.info().get('User-Agent', '')
                cookies = response.headers.get("Set-Cookie", "")
                cookie = '; '.join([f'{i.name}={i.value}' for i in cookies])
                if cookie: self.cookie = cookie
            except: lerror(f'get_cookie-Error: ({print_exc()}) ')

    def parseJSString(self, s):
        try:
            offset = 1 if s[0] == '+' else 0
            return int(eval(s.replace('!+[]', '1').replace('!![]', '1').replace('[]', '0').replace('(', 'str(')[offset:]))
        except: lerror(f'parseJSString-Error: ({print_exc()}) ')

class bfcookie:
    def __init__(self):
        self.COOKIE_NAME = 'BLAZINGFAST-WEB-PROTECT'

    def get(self, netloc, ua, timeout):
        try:
            headers = {'User-Agent': ua, 'Referer': netloc}
            result = request(netloc, headers=headers, timeout=timeout)
            match = re.findall(r'xhr\.open\("GET","([^,]+),', result, re.I)
            if not match: return False
            url_Parts = match[0].split('"')
            url_Parts[1] = '1680'
            url = urljoin(netloc, ''.join(url_Parts))
            match = re.findall(r'rid\s*?=\s*?([0-9a-zA-Z]+)', url_Parts[0])
            if not match: return False
            headers['Cookie'] = f'rcksid={match[0]}'
            result = request(url, headers=headers, timeout=timeout)
            return self.getCookieString(result, headers['Cookie'])
        except: lerror(f'Error from: {__name__}:  netloc: {netloc}')

    # not very robust but lazieness...
    def getCookieString(self, content, rcksid):
        vars = re.findall(r'toNumbers\("([^"]+)"', content)
        value = self._decrypt(vars[2], vars[0], vars[1])
        return f'{self.COOKIE_NAME}={value};{rcksid}'

    def _decrypt(self, msg, key, iv):
        from binascii import hexlify, unhexlify
        msg = unhexlify(msg)
        key = unhexlify(key)
        iv = unhexlify(iv)
        if len(iv) != 16: return False
        decrypter = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(key, iv))
        plain_text = decrypter.feed(msg)
        plain_text += decrypter.feed()
        return hexlify(plain_text)

class sucuri:
    def __init__(self):
        self.cookie = None

    def get(self, result):
        from base64 import b64decode
        try:
            s = re.compile(r"S\s*=\s*'([^']+)").findall(result)[0]
            s = b64decode(s)
            s = s.replace(' ', '')
            s = re.sub(r'String\.fromCharCode\(([^)]+)\)', r'chr(\1)', s)
            s = re.sub(r'\.slice\((\d+),(\d+)\)', r'[\1:\2]', s)
            s = re.sub(r'\.charAt\(([^)]+)\)', r'[\1]', s)
            s = re.sub(r'\.substr\((\d+),(\d+)\)', r'[\1:\1+\2]', s)
            s = re.sub(r';location.reload\(\);', '', s)
            s = re.sub(r'\n', '', s)
            s = re.sub(r'document\.cookie', 'cookie', s)
            cookie = ''
            exec(s)
            self.cookie = re.compile(r'([^=]+)=(.*)').findall(cookie)[0]
            self.cookie = f'{self.cookie[0]}={self.cookie[1]}'
            return self.cookie
        except: lerror(f'Error from: {__name__}: ')


def get_fheaders(url=None, headers=None):
    _headers = headers if headers else {'User-Agent': agent(), }
    if url and 'Referer' not in _headers:
        _headers['Referer'] = get_referer(url)
    if 'User-Agent' not in _headers: _headers['User-Agent'] = agent()
    return dict(_headers, **fheaders)


def direct_request(url):
    hea = {'Referer': '', 'User-Agent': 'okhttp/4.9.3', 'Accept-Encoding': 'gzip, deflate', 'Accept': '*/*', 'Connection': 'keep-alive'}
    resp = requests.get(url, headers=hea)
    # resp = _get_result(resp)
    json_text = GzipFile(fileobj=BytesIO(resp.content)).read()
    # log(f'json_text: {repr(json_text)}')
    return loads(json_text)


def _get_encoding(response):
    try:
        try: return response.info().getheader('Content-Encoding')
        except: return response.headers['Content-Encoding']
    except: lerror(f'Error from: {__name__}: ')
    return None



def refresh_redirect(url, headers=None):
    _headers = get_fheaders(url, headers)
    refresh = True
    html = ''
    while refresh:
        # log(f'refresh_redirect url: {url} _headers: {_headers}')
        if result := request(url, headers=_headers, output='extended'):
            html = result[0]
            response_headers = result[2]
            # log(f'result {type(result[0])}, response_code {type(result[1])}, response_headers {type(result[2])}, _headers {type(result[3])}, cookie {type(result[4])}, response_url {type(result[5])}')
            if response_headers.get('Refresh'): url = response_headers.get('Refresh').split(' ')[-1]
            elif 'http-equiv="refresh"' in html: url = unescape(re.findall(r'http-equiv="refresh".+?url=([^"]+)', html)[0])
            else: refresh = False
        else: refresh = False
    return html


def list_request(doms, query='', scheme='https://'):
    if isinstance(doms, list):
        for i in range(len(doms)):
            dom = choice(doms)
            try:
                base_link = dom if dom.startswith('http') else scheme + dom
                url = urljoin(base_link, query)
                # log(f'list_request i: {i} url: {url}')
                r = requests.get(url, headers={'User-Agent': agent(), 'Referer': base_link}, timeout=7)
                if r.ok:
                    #log('list_request chosen base: ' + base_link)
                    return r.text, base_link
                raise Exception()
            except Exception:
                doms = [d for d in doms if d != dom]
                lerror(f'list_request failed dom: {repr(i)} - {dom}')
    else:
        base_link = doms if doms.startswith('http') else scheme + doms
        url = urljoin(base_link, query)
        # log(f'list_request url: {url}')
        r = requests.get(url, headers={'User-Agent': agent(), 'Referer': base_link}, timeout=10)
        if r.ok:
            #log('list_request chosen base: ' + base_link)
            return r.text, base_link
        raise Exception()


def get_page_server(url, selector='', end_point='getp', timeout='30'):
    url_api = f'https://v-resol.vercel.app/api/{end_point}'
    ft = {'id': f'{url}/', 'selector': selector}
    return request(url_api, post=ft, timeout=timeout, verify=False)
