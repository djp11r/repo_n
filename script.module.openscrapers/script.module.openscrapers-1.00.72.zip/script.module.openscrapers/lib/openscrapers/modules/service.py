# -*- coding: utf-8 -*-

from traceback import print_exc

from openscrapers.modules.log_utils import log, error
from openscrapers.modules.control import monitor, set_property, clear_property, isVersionUpdate, clean_settings, addonVersion, condVisibility, notification, sleep, make_settings_dict, refresh_debugReversed, setting, setSetting, joinPath, makeDirs, dataPath, existsPath


def checksettingsfile():
	try:
		# log('[script.module.openscrapers]  CheckSettingsFile Service Starting...', 1)
		# window.clearProperty('openscrapers_settings')
		from openscrapers.modules.cache import cache_clear
		cache_clear()
		if not existsPath(dataPath):
			success = makeDirs(dataPath)
		settings_xml = joinPath(dataPath, 'settings.xml')
		if not existsPath(settings_xml):
			setSetting('module.provider', 'openscrapers')
		return
	except: error(f'Error: {print_exc()}', __name__)


def addoncheckupdate():
	# log('Addon checking available updates')
	try:
		import re
		import requests
		repo_xml = requests.get('https://raw.githubusercontent.com/djp11r/repo_n/mayb/script.module.openscrapers/addon.xml')
		if repo_xml.status_code != 200:
			return log(f'Could not connect to remote repo XML: status code = {repo_xml.status_code}')
		repo_version = re.search(r'<addon id=\"script.module.openscrapers\".*version=\"(\d*.\d*.\d*)\"', repo_xml.text, re.I).group(1)
		local_version = addonVersion()[:7] # 5 char max so pre-releases do try to compare more chars than github version
		log(f'repo_version: {repr(repo_version)} local_version: {repr(local_version)}')
		def check_version_numbers(current, new): # Compares version numbers and return True if github version is newer
			current = current.split('.')
			new = new.split('.')
			step = 0
			for i in current:
				if int(new[step]) > int(i): return True
				if int(i) > int(new[step]): return False
				if int(i) == int(new[step]):
					step += 1
					continue
			return False
		if check_version_numbers(local_version, repo_version):
			while condVisibility('Library.IsScanningVideo'):
				sleep(10000)
			msg = f' A newer version is available. Installed Version: v{local_version}, Repo Version: v{repo_version}'
			log(msg)
			notification(message=msg, time=5000)
		return # log('Addon update check complete')
	except: error(f'Error: {print_exc()}', __name__)


def checkundesirablesdatabase(self):
	log('"CheckUndesirablesDatabase" Service Starting...')
	from openscrapers.modules import undesirables
	try:
		if old_database := undesirables.Undesirables().check_database():
			undesirables.add_new_default_keywords()
	except: error(f'Error: {print_exc()}', __name__)
	return log('Finished "CheckUndesirablesDatabase" Service')


class OMain:
	def __init__(self):
		# Initialize the monitor internally
		self.monitor = monitor()
		self.threads = []
		self.startServices()

	def __enter__(self):
		# self.threads = (Thread(target=SettingsMonitor().run()), Thread(target=premAccntNotification))
		return self

	def __exit__(self, exc_type, exc_value, traceback):
		try: 
			for i in self.threads: i.join()
		except: pass
		# try: del dialog
		# except: pass
		try: del self.monitor
		except: pass

	def startServices(self):
		try: checksettingsfile()
		except: pass
		try: addoncheckupdate()
		except: pass
		# try: databaseMaintenance()
		# except: pass

	def onScreensaverActivated(self):
		set_property('os_pause_services', 'true')

	def onScreensaverDeactivated(self):
		clear_property('os_pause_services')

	def onSettingsChanged(self):
		clear_property('openscrapers_settings')
		# clear_property('os_pause_services')
		sleep(50)
		make_settings_dict()

	def onNotification(self, sender, method, data):
		if method == 'System.OnSleep': set_property('os_pause_services', 'true')
		elif method == 'System.OnWake': clear_property('os_pause_services')

