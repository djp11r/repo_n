
from openscrapers.modules.log_utils import log
from openscrapers.modules.service import OMain


if __name__ == '__main__':
	log('Settings & Main Monitor Service Starting')
	with OMain() as omain:
		while not omain.monitor.abortRequested():
			if omain.monitor.waitForAbort(1):
				break
	log('Settings & Main Monitor Service Stopped')
