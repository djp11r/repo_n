# -*- coding: utf-8 -*-
"""
	OpenScrapers Module
"""

from ast import literal_eval
from hashlib import md5
from json import dumps
from re import sub as re_sub
from sqlite3 import dbapi2 as db
from time import time

try:
	from openscrapers.modules.control import existsPath, dataPath, makeFile, cacheFile, undesirablescacheFile
	from openscrapers.modules.log_utils import log, error
except:
	from .log_utils import log, error
	cache_table = 'cache'
	cacheFile = 'cache.db'


def get(function, duration, *args, **kwargs):
	"""
	:param function: Function to be executed
	:param duration: Duration of validity of cache in hours
	:param args: Optional arguments for the provided function
	"""
	try:
		key = _hash_function(function, *args, **kwargs)
		cache_result = cache_get(key)
		if cache_result:
			try: result = literal_eval(cache_result['value'])
			except: result = cache_result['value']
			if _is_cache_valid(cache_result['date'], duration):
				return result

		fresh_result = repr(function(*args)) # may need a try-except block for server timeouts

		if cache_result and (result and len(result) == 1) and fresh_result == '[]': # fix for syncSeason mark unwatched season when it's the last item remaining
			if result[0].isdigit():
				remove(function, *args)
				return []

		invalid = False
		try: # Sometimes None is returned as a string instead of None type for "fresh_result"
			if not fresh_result or fresh_result in {'None', '', '[]', '{}'}: invalid = True
		except: pass

		if invalid: # If the cache is old, but we didn't get "fresh_result", return the old cache # do not cache_insert() None type, sometimes servers just down momentarily
			return result if cache_result else None
		cache_insert(key, fresh_result)
		return literal_eval(fresh_result)
	except:
		error()
		return None

def _is_cache_valid(cached_time, cache_timeout):
	# print('cached_time: %s cache_timeout: %s' % (cached_time, cache_timeout))
	now = int(time())
	diff = now - cached_time
	return (cache_timeout * 3600) > diff


def timeout(function, *args):
	try:
		key = _hash_function(function, args)
		result = cache_get(key)
		return int(result['date']) if result else 0
	except:
		error()
		return 0


def cache_existing(function, *args):
	try:
		if not (cache_result := cache_get(_hash_function(function, args))):
			return None
		if cache_result: return literal_eval(cache_result['value'])
	except:
		error()
		return None


def cache_get(key, duration=0):
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name='cache';''').fetchone()
		if not ck_table: return None
		results = dbcur.execute('''SELECT * FROM cache WHERE key=?''', (key,)).fetchone()
		if duration == 0: return results
		if results:
			# print(f'results: {results}')
			if _is_cache_valid(results['date'], duration):
				try: return eval(results['value'].encode('utf-8'))
				except: return eval(results['value'])  # fails
			else:
				dbcur.execute('''DELETE FROM cache WHERE key=?''', (key,))
				dbcur.connection.commit()
				return None
		else: return None
	except:
		error()
		return None
	finally:
		dbcur.close() ; dbcon.close()

def cache_insert(key, value, expires=None):
	try:
		if expires is None: expires = int(time()) + (24 * 3600) # HOURS multiply by 3600 to get seconds
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		if expires: pass
		else: expires = int(time()) + 300
		dbcur.execute('''CREATE TABLE IF NOT EXISTS cache (key TEXT, value TEXT, date INTEGER, UNIQUE(key));''')
		dbcur.execute('''INSERT OR REPLACE INTO cache Values (?, ?, ?)''', (key, value, expires))
		dbcur.connection.commit()
	except:
		error()
	finally:
		dbcur.close() ; dbcon.close()

def remove(function, *args):
	try:
		key = _hash_function(function, args)
		if key_exists := cache_get(key):
			dbcon = get_connection()
			dbcur = get_connection_cursor(dbcon)
			dbcur.execute('''DELETE FROM cache WHERE key=?''', (key,))
			dbcur.connection.commit()
	except:
		error()
	try: dbcur.close() ; dbcon.close()
	except: pass

def _hash_function(function_instance, *args, **kwargs):
	return _get_function_name(function_instance) + _generate_md5(*args, **kwargs)

def _get_function_name(function_instance):
	return re_sub('.+\smethod\s|.+function\s|\sat\s.+|\sof\s.+', '', repr(function_instance))

def _generate_md5(*args, **kwargs):
	md5_hash = md5()
	[md5_hash.update(str(arg).encode()) for arg in args]
	md5_hash.update(dumps(kwargs).encode())
	return md5_hash.hexdigest()

def cache_clear():
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		for t in [cache_table, 'rel_list', 'rel_lib']:
			try:
				dbcur.execute(f"DROP TABLE IF EXISTS {t}")
				dbcur.execute("VACUUM")
				dbcur.commit()
			except:
				pass
	except:
		error()
	finally:
		dbcur.close(); dbcon.close()


def get_connection():
	try:
		if not existsPath(dataPath): makeFile(dataPath)
	except: pass
	dbcon = db.connect(cacheFile, timeout=60)
	dbcon.execute('''PRAGMA page_size = 32768''')
	dbcon.execute('''PRAGMA journal_mode = OFF''')
	dbcon.execute('''PRAGMA synchronous = OFF''')
	dbcon.execute('''PRAGMA temp_store = memory''')
	dbcon.execute('''PRAGMA mmap_size = 30000000000''')
	dbcon.row_factory = _dict_factory
	return dbcon


def get_connection_cursor(dbcon):
	dbcur = dbcon.cursor()
	dbcur.execute('''PRAGMA synchronous = OFF''')
	dbcur.execute('''PRAGMA journal_mode = OFF''')
	return dbcur

def _dict_factory(cursor, row):
	return {col[0]: row[idx] for idx, col in enumerate(cursor.description)}



class Undesirables():
	def __init__(self):
		self.make_database_objects()

	def get_enabled(self):
		results = self.dbcur.execute('SELECT keyword FROM undesirables WHERE enabled = ?', (True,))
		return self.process_keywords(results)

	def get_default(self):
		results = self.dbcur.execute('SELECT keyword FROM undesirables WHERE user_defined = ?', (False,))
		return self.process_keywords(results)

	def get_user_defined(self):
		results = self.dbcur.execute('SELECT keyword FROM undesirables WHERE user_defined = ?', (True,))
		return self.process_keywords(results)

	def get_all(self):
		results = self.dbcur.execute('SELECT keyword FROM undesirables')
		return self.process_keywords(results)

	def set_many(self, undesirables):
		self.dbcur.executemany('INSERT OR REPLACE INTO undesirables VALUES (?, ?, ?)', undesirables)
		self.dbcon.commit()

	def make_connection(self):
		self.dbcon = db.connect(undesirablescacheFile, timeout=60)

	def make_cursor(self):
		self.dbcur = self.dbcon.cursor()
		self.dbcur.execute('''PRAGMA synchronous = OFF''')
		self.dbcur.execute('''PRAGMA journal_mode = OFF''')

	def make_database_objects(self):
		if not existsPath(dataPath): makeFile(dataPath)
		self.make_connection()
		self.make_cursor()
		self.dbcur.execute('CREATE TABLE IF NOT EXISTS undesirables (keyword TEXT NOT NULL, user_defined BOOL NOT NULL, enabled BOOL NOT NULL, UNIQUE(keyword))')

	def set_defaults(self, keywords):
		self.set_many([(i, False, True) for i in keywords])

	def process_keywords(self, results):
		keywords = [i[0] for i in results.fetchall()]
		if not keywords:
			from openscrapers.modules.source_utils import UNDESIRABLES
			keywords = UNDESIRABLES
			self.set_defaults(keywords)
		return keywords


try: undesirables_cache = [] #Undesirables()
except: undesirables_cache = []
