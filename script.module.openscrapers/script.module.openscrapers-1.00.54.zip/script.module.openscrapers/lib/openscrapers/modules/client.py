# -*- coding: utf-8 -*-
"""
    OpenScrapers Module
"""

import gzip
import json
# import random
import re
from html import unescape
from http import cookiejar
from io import BytesIO
from random import choice, randrange
from time import sleep, time
# from sys import version_info
from traceback import print_exc
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, quote_plus, unquote_plus, urlencode, urljoin, urlparse
from urllib.request import HTTPCookieProcessor, HTTPHandler, HTTPRedirectHandler, HTTPSHandler, ProxyHandler, Request, build_opener, install_opener, urlopen
from urllib.response import addinfourl

import requests
from requests import Session, Timeout
from requests.exceptions import SSLError, RequestException
from requests.adapters import HTTPAdapter, Retry
from openscrapers.modules import cache, client_utils
from openscrapers.modules.log_utils import log, error as lerror
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.utils import get_headers_parse_url, byteify
from openscrapers.modules import pyaes
from openscrapers.modules import cfscrape
from openscrapers.modules.control import translate_path, dataPath, existsPath, setting

from openscrapers.modules.client_session import Session
session = Session()


_COOKIE_HEADER = "Cookie"
_HEADER_RE = re.compile(r"^([\w\d-]+?)=(.*?)$")
UserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/114.0'
OldUserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:97.0) Gecko/20100101 Firefox/97.0'
MobileUserAgent = 'Mozilla/5.0 (Android 10; Mobile; rv:83.0) Gecko/83.0 Firefox/83.0'

dnt_headers = {
    'user-agent': UserAgent,
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-encoding': 'gzip, deflate, *;q=0',
    'accept-language': 'en-US;q=0.8,en;q=0.7',
    'content-type': 'application/x-www-form-urlencoded',
    'connection': 'keep-alive',
    'pragma': 'no-cache',
    'cache-control': 'no-cache',
    'dnt': '1'
}


def _strip_url(url):
    if url.find('|') == -1:
        return url, {}
    headers = url.split('|')
    target_url = headers.pop(0)
    out_headers = {}
    for h in headers:
        m = _HEADER_RE.findall(h)
        if not len(m):
            continue
        out_headers[m[0][0]] = unquote_plus(m[0][1])
    return target_url, out_headers


def _url_with_headers(url, headers):
    if not len(headers.keys()): return url
    headers_arr = [f'{key}={quote_plus(value)}' for key, value in iter(headers.items())]
    return '|'.join([url] + headers_arr)


def strip_cookie_url(url):
    url, headers = _strip_url(url)
    if _COOKIE_HEADER in headers.keys():
        del headers[_COOKIE_HEADER]
    return _url_with_headers(url, headers)


def _add_request_header(_request, headers=None):
    if headers is None: headers = {}
    try:
        scheme = urlparse(_request.get_full_url()).scheme
        host = _request.host
        referer = headers.get('Referer', '') or f'{scheme}://{host}/'
        _request.add_unredirected_header('Host', host)
        _request.add_unredirected_header('Referer', referer)
        for key in headers:
            if isinstance(headers[key], dict): continue
            # log(f'type headers[key]: {type(headers[key])} headers[key]: {headers[key]}')
            _request.add_header(key, headers[key])
        if 'User-Agent' not in headers: _request.add_header('User-Agent', agent())
    except: lerror(f'Error from: {__name__}: ')
    return _request


def _get_result(response, limit=None, ret_code=None):
    try:
        if not response: return
        if ret_code: return response.status
        try:
            result = response.read(int(limit) * 1024) if limit else response.read(5242880)
            result = result.decode(encoding='utf-8', errors='ignore')
        except AttributeError:
            result = response.text
        # log(f'result: {type(result)} : {result}')
        if isinstance(result, bytes):
            encoding = _get_encoding(response)
            if encoding == 'gzip': result = gzip.GzipFile(fileobj=BytesIO(result)).read()
            result = result.decode(encoding='utf-8', errors='ignore')
        return result
    except: lerror(f'Error from: {__name__}: ')

def _basic_request(url, headers=None, post=None, timeout=60, jpost=False, limit=None):
    try:
        _headers = headers if headers else {}
        if '|' in url:
            url, oheaders = get_headers_parse_url(url)
            _headers.update(oheaders)
        request = Request(url)
        if post is not None:
            if jpost:
                post = json.dumps(post)
                post = post.encode('utf8')
                request = Request(url, post)
                request.add_header('Content-Type', 'application/json')
            else:
                if isinstance(post, dict): post = bytes(urlencode(post), encoding='utf-8')
                if len(post) > 0: request = Request(url, data=post.encode('utf8'))
                else:
                    request.get_method = lambda: 'POST'
                    request.has_header = lambda header_name: (header_name == 'Content-type' or Request.has_header(request, header_name))
        request = _add_request_header(request, _headers)
        response = urlopen(request, timeout=int(timeout))
        return _get_result(response, limit)
    except:
        lerror(f'Error from: {__name__}: for url {url} ')
        return


def request(url, close=True, redirect=True, error=False, verify=True, post=None, headers=None, mobile=False, XHR=False,
            limit=None, referer=None, cookie=None, compression=False, output='', timeout='10', jpost=False, cfflare=False):
    if not url: return None
    if url.startswith('//'): url = f'https:{url}'
    if post:
        if isinstance(post, dict): post = bytes(urlencode(post), encoding='utf-8')
        elif isinstance(post, str): post = bytes(post, encoding='utf-8')

    try:
        _headers = headers if headers else {}
        if '|' in url:
            url, oheaders = get_headers_parse_url(url)
            _headers.update(oheaders)
        if _headers.get('verifypeer', '') == 'false':
            verify = False
            _headers.pop('verifypeer')

        handlers = []
        if output == 'cookie' or output == 'extended' or not close or redirect:
            cookies = cookiejar.LWPCookieJar()
            handlers += [HTTPHandler(), HTTPSHandler(), HTTPCookieProcessor(cookies)]
        if output == 'elapsed': start_time = time() * 1000
        opener = _get_unverified_context(verify, handlers)
        install_opener(opener)

        if 'User-Agent' in _headers:
            pass
        elif mobile:
            _headers['User-Agent'] = cache.get(mobileagent, 2)
        else:
            _headers['User-Agent'] = cache.get(agent, 2)
        if 'Referer' in _headers:
            pass
        elif referer is None:
            _headers['Referer'] = f'{urlparse(url).scheme}://{(urlparse(url).netloc or urlparse(url).path)}/'
        else:
            _headers['Referer'] = referer
        if 'Accept-Language' not in _headers:
            _headers['Accept-Language'] = 'en-US,en'
        if 'Accept' not in _headers:
            _headers['Accept'] = '*/*'
        if 'X-Requested-With' in _headers:
            pass
        elif XHR:
            _headers['X-Requested-With'] = 'XMLHttpRequest'
        if 'Cookie' in _headers:
            cookies = _headers['Cookie']
        elif cookie is not None:
            cookies = cookie
            if isinstance(cookie, dict):
                cookie = '; '.join(['{0}={1}'.format(x, y) for x, y in iter(cookie.items())])
            _headers['Cookie'] = cookie
        else:
            cpath = urlparse(url).netloc
            ccookie = retrieve(cpath + '.txt')
            if ccookie: _headers['Cookie'] = ccookie
            else:
                ccookie = retrieve(cpath + '.json')
                if ccookie:
                    cfhdrs = json.loads(ccookie)
                    _headers.update(cfhdrs)

        if 'Accept-Encoding' in _headers:
            pass
        elif compression and limit is None:
            _headers['Accept-Encoding'] = 'gzip'
        if redirect is False:
            class NoRedirectHandler(HTTPRedirectHandler):
                def http_error_302(self, req, fp, code, msg, _headers):
                    infourl = addinfourl(fp, _headers, req.get_full_url())
                    try: infourl.code = code
                    except HTTPError: infourl.code = code
                    return infourl

                http_error_300 = http_error_302
                http_error_301 = http_error_302
                http_error_303 = http_error_302
                http_error_307 = http_error_302
                http_error_308 = http_error_302

            opener = build_opener(NoRedirectHandler())
            install_opener(opener)
            try: del _headers['Referer']
            except BaseException: pass

        url = quote_plus(url, safe="%/:=&?~#+!$,;'@()*[]|")
        # url = client_utils.byteify(url.replace(' ', '%20'))
        req = Request(url, data=post)
        if post:
            if jpost:
                post = json.dumps(post)
                req = Request(url, post)
                req.add_header('Content-Type', 'application/json')
            else:
                if len(post) > 0: req = Request(url, data=post)
                else:
                    req.get_method = lambda: 'POST'
                    req.has_header = lambda header_name: (header_name == 'Content-type' or Request.has_header(req, header_name))

        if limit == '0': req.get_method = lambda: 'HEAD'
        req = _add_request_header(req, _headers)
        # log(f'sent headers: {req.headers}')
        try:
            response = urlopen(req, timeout=int(timeout))
            try: cookies = response.getheader('set-cookie')
            except: cookies = response.info().get_all('Set-Cookie')
        except HTTPError as error_response: # if HTTPError, using "as response" will be reset after entire Exception code runs and throws error around line 247 as "local variable 'response' referenced before assignment", re-assign it
            if error is True: response = error_response
            if error_response.info().get('Content-Encoding', '').lower() == 'gzip':
                buf = BytesIO(error_response.read())
                f = gzip.GzipFile(fileobj=buf)
                result = f.read()
                f.close()
            else: result = error_response.read()
            result = result.decode('latin-1', errors='ignore')
            server = error_response.info().get('Server')
            error_code = error_response.status
            if 'cloudflare' in server.lower():
                if error_code == 403 and 'cf-alert-error' in result:
                    import ssl
                    ctx = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
                    ctx.set_alpn_protocols(['http/1.0', 'http/1.1'])
                    handle = [HTTPSHandler(context=ctx)]
                    opener = build_opener(*handle)
                    try:
                        response = opener.open(req, timeout=20)
                    except HTTPError as e:
                        if e.code == 403:
                            ctx = ssl.SSLContext(ssl.PROTOCOL_TLSv1_1)
                            ctx.set_alpn_protocols(['http/1.1'])
                            handlers = [HTTPSHandler(context=ctx)]
                            opener = build_opener(*handlers)
                            try:
                                response = opener.open(req, timeout=15)
                            except HTTPError as e:
                                return e  # Give up
                elif any(x == error_code for x in [403, 429, 503]) and any(x in result for x in ['__cf_chl_f_tk', '__cf_chl_jschl_tk__=', '/cdn-cgi/challenge-platform/']):
                    netloc = f'{urlparse(url).scheme}://{(urlparse(url).netloc or urlparse(url).path)}/'
                    cookies, cf_ua = cfcookie().get(url, timeout)
                    if cookies is None:
                        log(f'This site has an unsolvable Cloudflare challenge. url: {url}')
                        if not error: return ''
                    _headers['Cookie'] = cookies
                    _headers['User-Agent'] = cf_ua
                    req = Request(url, data=post)
                    _add_request_header(req, _headers)
                    response = urlopen(req, timeout=int(timeout))
                else:
                    if not error: return log(f'url: {url} Error: {print_exc()}', __name__)
        except URLError as err:
            lerror(f'URLError from: {__name__}: Error: {err}\nurl: {url}\n_headers: {_headers}')
            return ''

        if output == 'cookie':
            # log(f'cookie: {cookie} cookies: {cookies}')
            if not cookies: return ''
            elif isinstance(cookies, dict): return '; '.join([f'{x}={y}' for x, y in iter(cookies.items())])
            elif isinstance(cookies, list): return '; '.join([f'{i.name}={i.value}' for i in cookies])
        elif output == 'elapsed':
            result = (time() * 1000) - start_time
            if close: response.close()
            return int(result)
        elif output == 'geturl':
            try: result = response.url
            except: result = response.geturl()
            return result
        elif output == 'headers':
            result = dict(response.headers)
            if close: response.close()
            return result
        elif output == 'response':
            result = _get_result(response, limit)
            return result
        elif output == 'chunk':
            try: content = int(response.headers['Content-Length'])
            except BaseException: content = (2049 * 1024)
            if content < (2048 * 1024): return
            try: result = response.read(16 * 1024)
            except: result = response  # testing
            return result
        elif output == 'file_size':
            try: content = int(response.headers['Content-Length'])
            except BaseException: content = '0'
            response.close()
            return content
        if not cfflare: result = _get_result(response, limit)

        if 'sucuri_cloudproxy_js' in str(result):  # who da fuck?
            su = sucuri().get(result)
            _headers['Cookie'] = su
            req = Request(url, data=post)
            req = _add_request_header(req, _headers)
            response = urlopen(req, timeout=int(timeout))
            result = _get_result(response, limit)
        if 'Blazingfast.io' in str(result) and 'xhr.open' in str(result):  # who da fuck?
            netloc = f'{urlparse(url).scheme}://{urlparse(url).netloc}'
            ua = _headers['User-Agent']
            _headers['Cookie'] = cache.get(bfcookie().get, 168, netloc, ua, timeout)
            result = _basic_request(url, headers=_headers, post=post, timeout=timeout, limit=limit)
        if output == 'extended':
            try: response_headers = dict([(item[0].title(), item[1]) for item in list(response.info().items())])  # behaves differently 18 to 19. 18 I had 3 "Set-Cookie:" it combined all 3 values into 1 key. In 19 only the last keys value was present.
            except BaseException: response_headers = dict(response.headers)
            try: response_url = response.geturl()
            except: response_url = response.url
            # try: response_code = str(response.status)
            # except: response_code = str(response.status_code)  # object from CFScrape Requests object.
            if not cookies: cookies = ''
            elif isinstance(cookies, dict): cookies = '; '.join([f'{x}={y}' for x, y in iter(cookies.items())])
            elif isinstance(cookies, list): cookies = '; '.join([f'{i.name}={i.value}' for i in cookies])
            if close: response.close()
            return result, _headers, response_headers, cookies, response_url
        elif output == 'json':
            content = json.loads(result)
            response.close()
            return content
        if close: response.close()
        return result
    except Exception as err:
        lerror(f'Error from: {__name__}: Error: {err}\nurl: {url}\n_headers: {_headers}')
        return None


def scrapePage(url, referer=None, headers=None, post=None, cookie=None, timeout=20, verify=True):
    try:
        if not url: return
        _headers = headers if headers else {}
        response = None
        url = f'https:{url}' if url.startswith('//') else url
        #url = quote_plus(url, safe="%/:=&?~#+!$,;'@()*[]|")
        if '|' in url:
            url, oheaders = get_headers_parse_url(url)
            _headers.update(oheaders)
        with session:
            session.headers.update(_headers)
            if referer and 'Referer' not in session.headers: session.headers.update({'Referer': referer})
            else:
                elements = urlparse(url)
                base = f'{elements.scheme}://{(elements.netloc or elements.path)}'
                session.headers.update({'Referer': base})
            if cookie and 'Cookie' not in session.headers: session.headers.update({'Cookie': cookie}) # not tested yet, just placed as a idea reminder.
            if 'python-requests' in str(session.headers) or 'User-Agent' not in session.headers: session.headers.update({'User-Agent': agent()})
            try:
                if post: response = session.post(url, data=post, timeout=int(timeout), verify=verify)
                else: response = session.get(url, timeout=int(timeout), verify=verify)
                """ ghetto fix for blockage that could probably be coded better."""
                # log(f'type: {type(response)} response.__dict__: {repr(response.__dict__)}')
                # log(f' type: {type(response)} response.__dict__: {repr(response)}')
                if isinstance(response, dict): return response
                resp_code = str(response.status_code)
                resp_header = response.headers
                resp_server = resp_header.get('Server', '')
                if resp_code in {'403', '503'} and resp_server == 'cloudflare':
                    #log(f'scrapePage - url with cloudflare: {repr(url)}')
                    from openscrapers.modules.proxy import get_proxy_url
                    if iurl := get_proxy_url(url):
                        log(f'scrapePage: using get_proxy_url: {iurl}')
                        if post: response = session.post(iurl, data=post, timeout=int(timeout))
                        else: response = session.get(iurl, timeout=int(timeout))
                        url = iurl
                response.encoding = 'utf-8'
                # response.raise_for_status()  # Commented out to make trakt progress option work properly again lol
            except SSLError as err:
                log(f'scrapePage SSLError" Error: {err} url: {url}')
                if int(timeout) < 40: scrapePage(url, headers=_headers, post=post, timeout=int(timeout) + 10, verify=False)
            except Timeout as err:
                log(f'scrapePage Timeout: Error: {err} url: {url}')
                if int(timeout) < 40: scrapePage(url, headers=_headers, post=post, timeout=int(timeout) + 10, verify=verify)
            except ConnectionError as err: log(f'scrapePage ConnectionError: Error: {err} url: {url} session.headers:{session.headers}')
            except HTTPError as err: log(f'scrapePage HTTPError: Error: {err} url: {url} session.headers:{session.headers}')
            except RequestException as err: log(f'scrapePage RequestException: Error: {err} url: {url} session.headers:{session.headers}')
            except Exception as e: log(f'scrapePage except Exception as e: {e} url: {url}')
        # cookies_dictionary = session.cookies.get_dict()
        # log(f'cookies_dictionary: {cookies_dictionary}')
        # log(f'session_headers send: {session.headers}')
        # log(f'response.headers recived: {response.headers}')
        # if response.status_code in (301, 307, 308, 503, 403):
        #     response = cf_responce(url, fheaders)
        #     # log(f'repr(response) : {repr(response)}')
        #     if response.status_code > 400: # if cfscrape server still responds with 403
        #         log(f'from: url: {url} cfscrape-Error : ')  # HTTP Error 403: Forbidden
        #         return response
        # if testing: testing_write_html(url, response)
        if not response: log(f'scrapePage No response from url: {url} {response}')
        return response
    except Exception:
        lerror(f'Error from: {__name__}: url: {url} ')
        return


def url_ok(url): #  Old Code Saved.
    r = scrapePage(url)
    return r.status_code in [200, 301]


def randomagent():
    BR_VERS = [
        [f'{i}.0' for i in range(95, 100)],
        ['97.0.4692.71', '97.0.4692.99', '98.0.4758.82', '98.0.4758.102', '99.0.4844.151', '100.0.4896.75', '100.0.4896.88 ', '101.0.4951.41', '101.0.4951.64', '102.0.5005.63'],
        ['11.0']]
    WIN_VERS = ['Windows NT 11.0', 'Windows NT 10.0', 'Windows NT 8.1', 'Windows NT 8.0', 'Windows NT 7.0']
    FEATURES = ['; WOW64', '; Win64; IA64', '; Win64; x64', '']
    RAND_UAS = ['Mozilla/5.0 ({win_ver}{feature}; rv:{br_ver}) Gecko/20100101 Firefox/{br_ver}',
                'Mozilla/5.0 ({win_ver}{feature}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{br_ver} Safari/537.36',
                'Mozilla/5.0 ({win_ver}{feature}; Trident/7.0; rv:{br_ver}) like Gecko']  # (compatible, MSIE) removed, dead browser may no longer be compatible and it fails for glodls with "HTTP Error 403: Forbidden"
    index = randrange(len(RAND_UAS))
    return RAND_UAS[index].format(
            win_ver=choice(WIN_VERS),
            feature=choice(FEATURES),
            br_ver=choice(BR_VERS[index]))


def mobileagent(mobile='android'):
    _mobagents = [
        'Mozilla/5.0 (Linux; Android 8.1.0; LM-Q710(FGN); WebView/3.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.5195.19 Mobile Safari/537.36 EdgA/100.0.1185.50',
        'Mozilla/5.0 (Android 12; Mobile; rv:68.0) Gecko/68.0 Firefox/94.0',
        'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.5195.19 Mobile Safari/537.36 EdgA/100.0.1185.50',
        'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.5195.19 Mobile Safari/537.36 EdgA/100.0.1185.50 EdgA/95.0.1020.42',
        'Mozilla/5.0 (Linux; Android 10; SM-G970F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.5195.19 Mobile Safari/537.36 EdgA/100.0.1185.50 OPR/63.3.3216.58675',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 15_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 15_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 EdgiOS/95.0.1020.40 Mobile/15E148 Safari/605.1.15',
        'Mozilla/5.0 (iPad; CPU OS 15_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 15_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/96.0.4664.36 Mobile/15E148 Safari/604.1',
        'Mozilla/5.0 (iPad; CPU OS 15_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/96.0.4664.36 Mobile/15E148 Safari/604.1',
        'Mozilla/5.0 (iPad; CPU OS 10_2_1 like Mac OS X) AppleWebKit/602.4.6 (KHTML, like Gecko) Version/10.0 Mobile/14D27 Safari/602.1']

    if mobile == 'android': return choice(_mobagents[:7])
    else: return choice(_mobagents[8:14])


def agent():
    return choice(
            ['Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/104.0.1293.70',
             'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/104.0.1293.70',
             'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/104.0.1293.70',
             'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0',
             'Mozilla/5.0 (Macintosh; Intel Mac OS X 12.0; rv:94.0) Gecko/20100101 Firefox/94.0',
             'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:94.0) Gecko/20100101 Firefox/94.0',
             'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/104.0.1293.70',
             'Mozilla/5.0 (Windows NT 10.0; WOW64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/104.0.1293.70',
             'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/104.0.1293.70'])


def store(ftext, fname):
    try:
        fpath = translate_path(dataPath) + fname
        with open(fpath, 'w', encoding='utf-8') as f:
            f.write(ftext)
    except: pass


def retrieve(fname):
    try:
        fpath = translate_path(dataPath) + fname
        if existsPath(fpath):
            with open(fpath, encoding='utf-8') as f:
                ftext = f.readlines()
            return '\n'.join(ftext)
        else: return None
    except: return None


class cfcookie:
    def __init__(self):
        self.cookie = None
        self.ua = None

    def get(self, netloc, timeout):
        try:
            self._get_cookie(netloc, timeout)
            if self.cookie:
                cfdata = json.dumps({'Cookie': self.cookie, 'User-Agent': self.ua})
                store(cfdata, urlparse(netloc).netloc + '.json')
                log(f'{netloc} returned cookie. collect tokens.')
            return (self.cookie, self.ua)
        except:
            lerror(f'Error from: {__name__}: netloc: {netloc} ')
            return (self.cookie, self.ua)

    def _get_cookie(self, netloc, timeout):
        fs_url = setting('fs_url')
        if not fs_url.startswith('http'):
            log('Sorry, malformed flaresolverr url')
            return
        post = {'cmd': 'request.get',
                'url': netloc,
                'returnOnlyCookies': True}
        resp = _basic_request(fs_url, post=post, jpost=True)
        if resp:
            resp = json.loads(resp)
            soln = resp.get('solution')
            if soln.get('status') < 300:
                cookie = '; '.join(['%s=%s' % (i.get('name'), i.get('value')) for i in soln.get('cookies')])
                if 'cf_clearance' in cookie:
                    self.cookie = cookie
                    self.ua = soln.get('userAgent')
                else:
                    log(f'{netloc} returned an error. Could not collect tokens.')


class bfcookie:
    def __init__(self):
        self.COOKIE_NAME = 'BLAZINGFAST-WEB-PROTECT'

    def get(self, netloc, ua, timeout):
        try:
            headers = {'User-Agent': ua, 'Referer': netloc}
            result = _basic_request(netloc, headers=headers, timeout=timeout)
            match = re.findall(r'xhr\.open\("GET","([^,]+),', result, re.I)
            if not match: return False
            url_Parts = match[0].split('"')
            url_Parts[1] = '1680'
            url = urljoin(netloc, ''.join(url_Parts))
            match = re.findall(r'rid\s*?=\s*?([0-9a-zA-Z]+)', url_Parts[0])
            if not match: return False
            headers['Cookie'] = f'rcksid={match[0]}'
            result = _basic_request(url, headers=headers, timeout=timeout)
            return self.getCookieString(result, headers['Cookie'])
        except: lerror(f'Error from: {__name__}:  netloc: {netloc}')

    # not very robust but lazieness...
    def getCookieString(self, content, rcksid):
        vars = re.findall(r'toNumbers\("([^"]+)"', content)
        value = self._decrypt(vars[2], vars[0], vars[1])
        return f'{self.COOKIE_NAME}={value};{rcksid}'

    def _decrypt(self, msg, key, iv):
        from binascii import hexlify, unhexlify
        msg = unhexlify(msg)
        key = unhexlify(key)
        iv = unhexlify(iv)
        if len(iv) != 16: return False
        decrypter = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(key, iv))
        plain_text = decrypter.feed(msg)
        plain_text += decrypter.feed()
        return hexlify(plain_text)


class sucuri:
    def __init__(self):
        self.cookie = None

    def get(self, result):
        from base64 import b64decode
        try:
            s = re.compile(r"S\s*=\s*'([^']+)").findall(result)[0]
            s = b64decode(s)
            s = s.replace(' ', '')
            s = re.sub(r'String\.fromCharCode\(([^)]+)\)', r'chr(\1)', s)
            s = re.sub(r'\.slice\((\d+),(\d+)\)', r'[\1:\2]', s)
            s = re.sub(r'\.charAt\(([^)]+)\)', r'[\1]', s)
            s = re.sub(r'\.substr\((\d+),(\d+)\)', r'[\1:\1+\2]', s)
            s = re.sub(r';location.reload\(\);', '', s)
            s = re.sub(r'\n', '', s)
            s = re.sub(r'document\.cookie', 'cookie', s)
            cookie = ''
            exec(s)
            self.cookie = re.compile(r'([^=]+)=(.*)').findall(cookie)[0]
            self.cookie = f'{self.cookie[0]}={self.cookie[1]}'
            return self.cookie
        except: lerror(f'Error from: {__name__}: ')


fheaders = {
    'Accept-Language': 'en-US,en',
    'Accept': '*/*',
    'Connection': 'keep-alive',
    'DNT': '1',
    'Upgrade-Insecure-Requests': '1',
    'x-requested-with': 'XMLHttpRequest', }
# 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
# 'sec-fetch-dest': 'document',
# 'sec-fetch-mode': 'navigate',
# 'sec-fetch-site': 'cross-site',
# }
# 'Pragma': 'no-cache',
# 'Cache-Control': 'no-cache',


def make_session(url='https://'):
    try:
        session = Session()
        retries = Retry(total=3,  # number of total retries
                connect=2, # retry once in case we can't connect to url
                read=2, # retry once in case we can't read the response from url
                redirect=3, # retry once in case we're redirected by url
                backoff_factor=1,  # The pause between for each retry
                status_forcelist=[429, 500, 502, 503, 504], # this is a list of statuses to consider to be an error and retry. definitely retry if url is unwell
                )

        session.mount(url, HTTPAdapter(max_retries=retries))
        # session.mount('http://', HTTPAdapter(max_retries=retries))
        # session.headers.update(fheaders)
        # session.headers.update({'User-Agent': agent()})
        return session
    except:
        lerror(f'Error from: {__name__}: ')
        return None


def get_fheaders(url=None, headers=None):
    _headers = headers if headers else {'User-Agent': agent(), }
    if url and 'Referer' not in _headers:
        base = f'{urlparse(url).scheme}://{(urlparse(url).netloc or urlparse(url).path)}/'
        _headers['Referer'] = base
    if 'User-Agent' not in _headers: _headers['User-Agent'] = agent()
    return dict(_headers, **fheaders)


def cf_responce(url, headers=None, post=None, timeout='30'):
    try:
        # url = quote(url, safe=':/')
        _headers = get_fheaders(url, headers)
        if post: _headers.update({'Content-Type': 'application/json'})
        else: _headers.update({'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'})
        data = None
        if post:
            if isinstance(post, dict): data = post
            else:
                try: data = parse_qs(post)
                except: pass
        scraper = cfscrape.CloudScraper()
        response = scraper.request(method='GET' if post is None else 'POST', url=url, headers=_headers, data=data, timeout=int(timeout))
        if response.status_code == 403: response = scraper.request(method='GET' if post is None else 'POST', url=url, data=data, timeout=int(timeout))
        return response
    except: lerror(f'Error from: {__name__}: url: {url} ')


def _get_encoding(response):
    try:
        try: return response.info().getheader('Content-Encoding')
        except: return response.headers['Content-Encoding']
    except: lerror(f'Error from: {__name__}: ')
    return None


def _get_unverified_context(verifySsl, handlers, TLSv1_2=True):
    import ssl
    ctx = None
    if verifySsl:
        try:
            from openscrapers.modules.control import get_kodi_certi_file
            ctx = ssl.create_default_context(cafile=get_kodi_certi_file())
            ctx.set_alpn_protocols(['http/1.1'])
        except: pass
    if not verifySsl or ctx is None:
        ctx = ssl._create_unverified_context()
        ssl._create_default_https_context = ssl._create_unverified_context
        ctx.check_hostname = False
        if TLSv1_2: ctx = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
        else: ctx = ssl.SSLContext(ssl.PROTOCOL_TLSv1_1)
        ctx.verify_mode = ssl.VerifyMode.CERT_NONE
        ctx.set_alpn_protocols(['http/1.1'])
    if ctx: handlers += [HTTPSHandler(context=ctx, debuglevel=1)]
    return build_opener(*handlers)


def get_content(response, encoding=None):
    try:
        content_type = response.headers.get('content-type', '').lower()
        text_content = any(x in content_type for x in ['text', 'json', 'xml', 'mpegurl'])
        if 'charset=' in content_type: encoding = content_type.split('charset=')[-1]
        if encoding is None:
            epatterns = [r'<meta\s+http-equiv="Content-Type"\s+content="(?:.+?);\s+charset=(.+?)"', r'xml\s*version.+encoding="([^"]+)']
            for epattern in epatterns:
                epattern = epattern.encode('utf8')
                if r := re.search(epattern, response.content, re.IGNORECASE):
                    encoding = r[1].decode('utf8')
                    break
        if encoding is None:
            if r := re.search(b'^#EXT', response.content, re.IGNORECASE):
                encoding = 'utf8'
        if encoding is not None: return response.content.decode(encoding, errors='ignore')
        elif text_content: return response.content.decode('latin-1', errors='ignore')
        else: log('Unknown Page Encoding')
    except: lerror(f'Error from: {__name__}: ')
    return


def refresh_redirect(url, headers=None):
    _headers = get_fheaders(url, headers)
    refresh = True
    html = ''
    while refresh:
        # log(f'refresh_redirect url: {url} _headers: {_headers}')
        if result := request(url, headers=_headers, output='extended'):
            html = result[0]
            response_headers = result[2]
            # log(f'result {type(result[0])}, response_code {type(result[1])}, response_headers {type(result[2])}, _headers {type(result[3])}, cookie {type(result[4])}, response_url {type(result[5])}')
            if response_headers.get('Refresh'): url = response_headers.get('Refresh').split(' ')[-1]
            elif 'http-equiv="refresh"' in html: url = unescape(re.findall(r'http-equiv="refresh".+?url=([^"]+)', html)[0])
            else: refresh = False
        else: refresh = False
    return html


def list_request(doms, query='', scheme='https://'):
    if isinstance(doms, list):
        for i in range(len(doms)):
            dom = choice(doms)
            try:
                base_link = dom if dom.startswith('http') else scheme + dom
                url = urljoin(base_link, query)
                # log(f'list_request i: {i} url: {url}')
                r = requests.get(url, headers={'User-Agent': agent(), 'Referer': base_link}, timeout=7)
                if r.ok:
                    #log('list_request chosen base: ' + base_link)
                    return r.text, base_link
                raise Exception()
            except Exception:
                doms = [d for d in doms if d != dom]
                log(f'list_request failed dom: {repr(i)} - {dom}')
    else:
        base_link = doms if doms.startswith('http') else scheme + doms
        url = urljoin(base_link, query)
        # log(f'list_request url: {url}')
        r = requests.get(url, headers={'User-Agent': agent(), 'Referer': base_link}, timeout=10)
        if r.ok:
            #log('list_request chosen base: ' + base_link)
            return r.text, base_link
        raise Exception()