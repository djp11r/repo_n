# -*- coding: utf-8 -*-

from random import choice

import requests
from openscrapers.modules.log_utils import log, error

API_URL = 'https://api.themoviedb.org/3/'
ART_URL = 'https://image.tmdb.org/t/p/original'
HEADERS = {'Content-Type': 'application/json;charset=utf-8'}
API_KEY = 'c8b7db701bac0b26edfcc93b39858972'


def find_movie_by_external_source(imdb):
    try:
        url = f'{API_URL}find/{imdb}?api_key={API_KEY}&language=en-US&external_source=imdb_id'
        result = requests.get(url, headers=HEADERS).json()
        return result['movie_results'][0]
    except Exception as err:
        error(f'find_movie_by_external_source: {err}')
        return


def find_tvshow_by_external_source(imdb=None, tvdb=None):
    try:
        if imdb:
            url = f'{API_URL}find/{imdb}?api_key={API_KEY}&language=en-US&external_source=imdb_id'
        elif tvdb:
            url = f'{API_URL}find/{tvdb}?api_key={API_KEY}&language=en-US&external_source=tvdb_id'
        result = requests.get(url, headers=HEADERS).json()
        return result['tv_results'][0]
    except Exception as err:
        error(f'find_tvshow_by_external_source: {err}')
        return


def clean_title_to_comparisons(string):
    """
        Method that takes a string and returns it cleaned of any special characters in order to do proper string comparisons
    """
    try: return ''.join(e for e in string.lower() if e.isalnum())
    except: return string


def clean_title_to_search(title):
    ftitle = ''
    for word in title.split(' '):
        if word.isalnum() is False:
            w = ""
            for i in range(len(word)):
                if word[i].isalnum():
                    w += word[i]
            word = w
        ftitle += ' ' + word
    return ftitle.strip()


def get_query(title):
    title = title.lower()
    if 'superstar singer' in title: return 'superstar singer'
    elif 'dance deewane' in title: return 'dance deewane'
    elif 'india got talent' in title: return 'india got talent season'
    elif 'jhalak dikhhla jaa' in title: return 'jhalak dikhhla jaa season'
    elif 'crime patrol' in title: return 'crime patrol 48 hours'
    elif 'indias best dancer' in title: return 'indias best dancer'
    elif 'kaun banega crorepati' in title: return 'kaun banega crorepati season'
    elif 'bigg boss ott' in title: return 'bigg boss ott'
    elif 'bigg boss' in title: return 'bigg boss'
    elif 'indian idol' in title: return 'indian idol'
    elif 'the kapil sharma show' in title: return 'the kapil sharma show season'
    return title


def _do_tmdb_request(values, method='search/multi', lang='en'):
    api_key = choice(['8877595a1e6647d272148c99133df1fb', 'bc96b19479c7db6c8ae805744d0bdfe2', 'b370b60447737762ca38457bd77579b3', 'edde6b5e41246ab79a2697cd125e1781', 'c8b7db701bac0b26edfcc93b39858972', 'af3a53eb387d57fc935e9128468b1899']) # 6a5be4999abf74eba1f9a8311294c267
    url = f'http://api.themoviedb.org/3/{method}?language={lang}&api_key={api_key}&{values}'
    try: response = requests.get(url, headers=HEADERS, timeout=20)
    except: response = None
    data = response.json()
    # log(f'from method: {method} values: {values} url: {url}\ndata: {data}')
    return data


def tmdb_search(query, season=1, only_tmbdid=True):
    """

    :param query:
    :return: dict for meta
    """

    query_part = query.split('|')
    if query_part[1].isdigit(): title, year, media_type, runtime = query_part[0], query_part[1], 'movie', 120
    else: title, year, media_type, runtime = query_part[1], None, 'tvshow', 30
    title = get_query(title)
    tmdb_id = None
    if year: name = title + '&year=' + year
    else: name, year = title, '2024'
    # log(f'name: {name} title: {title} year: {year}')
    meta = _do_tmdb_request('query=' + name, 'search/multi')
    meta_get = meta.get
    if meta and meta_get('total_results') == 1 and meta_get('results'):
        tmdb_id = meta_get('results')[0].get('id')
        media_type = meta_get('results')[0].get('media_type')
    elif meta and meta_get('total_results') > 1 and meta_get('results'):
        results = [r for r in meta_get('results') if (r.get('title') and clean_title_to_comparisons(r.get('title').lower()) in clean_title_to_comparisons(name.lower())) and r.get('release_date', '0000')[:4] == year]
        if not results: results = [r for r in meta_get('results') if (r.get('name') and clean_title_to_comparisons(r.get('name').lower()) in clean_title_to_comparisons(name.lower()))]
        if len(results) > 1:
            fresults = [r for r in results if r.get('original_language') != 'en']
            if len(fresults) > 0:
                tmdb_id = fresults[0].get('id')
                media_type = fresults[0].get('media_type')
            else:
                tmdb_id = results[0].get('id')
                media_type = results[0].get('media_type')
        elif len(results) == 1:
            tmdb_id = results[0].get('id')
            media_type = results[0].get('media_type')
    if only_tmbdid: return tmdb_id
    else: return get_meta_tmbd(tmdb_id, media_type, title, query, year, season, runtime)


def get_meta_tmbd(tmdb_id, media_type, title, query, year, season, runtime):
    md = None
    if tmdb_id:
        tmdb_image_url = 'https://image.tmdb.org/t/p/'
        # Attempt to grab all info in one request
        extra_append = 'append_to_response=casts,trailers,external_ids,videos,credits,content_ratings,release_dates,alternative_titles,translations,images'
        meta = _do_tmdb_request(extra_append, f'{media_type}/{tmdb_id}')
        if meta is not None:
            meta_get = meta.get
            # Parse out extra info from request
            mpaa = 'NR'
            if not meta_get('title'): title = title.title()
            else: title = meta_get('title')
            try: country = [x.get('name') for x in meta_get('production_countries')]
            except: country = []
            try: studio = [x.get('name') for x in meta_get('production_companies')]
            except: studio = []
            premiered = meta_get('release_date') or meta_get('first_air_date')
            md = {
                'tmdb_id': str(meta_get('id')),
                'tvdb_id': query,
                'title': title,
                'tagline': meta_get('tagline'),
                'mediatype': meta_get('media_type') or media_type,
                'plot': meta_get('overview'),
                'country': country,
                'studio': studio,
                'mpaa': mpaa,
                'rating': meta_get('vote_average'),
                'votes': meta_get('vote_count'),
                'premiered': premiered,
                }

            imdb_id = meta_get('imdb_id') if meta_get('imdb_id') else query
            md.update({'imdb_id': imdb_id, 'imdbnumber': imdb_id, })
            if premiered: md.update({'year': str(premiered[:4])})
            else: md.update({'year': year})
            if meta_get('runtime'): md.update({'duration': meta_get('runtime') * 60})
            else: md.update({'duration': runtime * 60})

            casts = meta_get('casts')
            if casts:
                if casts.get('cast'):
                    cast = [{'name': x.get('name'), 'role': x.get('character'), 'thumbnail': f'{tmdb_image_url}w138_and_h175_face{x.get("profile_path")}'} for x in casts['cast']]
                    md.update({'cast': cast[:10]})
                if casts.get('crew'):
                    director = [x.get('name') for x in casts['crew'] if x.get('job') == 'Director']
                    writer = list(set([x.get('name') for x in casts['crew'] if x.get('job') in ['Story', 'Screenplay', 'Dialogue', 'Writing']]))
                    md.update({'director': director, 'writer': writer})

            genres = meta_get('genres')
            if genres:
                genre = [x.get('name') for x in genres]
                md.update({'genre': genre})

            trailers = meta_get('trailers')
            if trailers:
                # We only want YouTube trailers
                trailers = trailers['youtube']
                # Only want trailers - no Featurettes etc.
                found_trailer = next((item for item in trailers if 'Trailer' in item["name"] and item['type'] == 'Trailer'), None)
                if found_trailer:
                    trailer_id = found_trailer['source']
                    md.update({'trailer': f'plugin://plugin.video.youtube/play/?video_id={trailer_id}'})

            if meta_get('poster_path'): md.update({'poster': f'{tmdb_image_url}w500{meta_get("poster_path")}'})
            if meta_get('backdrop_path'): md.update({'fanart': f'{tmdb_image_url}w1280{meta_get("backdrop_path")}'})
            if media_type == 'movie': md['extra_info'] = {'status': meta_get('status'), 'budget': meta_get('budget') or '$0', 'revenue': meta_get('revenue') or '$0', 'homepage': meta_get('homepage'), 'collection_name': meta_get('collection_name'), 'collection_id': meta_get('collection_id')}
            else:
                season = season if season > 1 else len(meta_get('seasons') or 1)
                created_by = meta_get('created_by', None)
                try: ei_created_by = ', '.join([i['name'] for i in created_by])
                except: ei_created_by = 'N/A'
                extra_info = {'status': meta_get('status'), 'homepage': meta_get('homepage'), 'created_by': ei_created_by, 'type': meta_get('type'), 'last_episode_to_air': meta_get('last_episode_to_air'), 'next_episode_to_air': meta_get('next_episode_to_air')}
                md.update({'tvshowtitle': title, 'seasons': season, 'season': season, 'extra_info': extra_info, 'season_data': meta_get('seasons') or [], 'total_aired_eps': meta_get('number_of_episodes') or 1})
        # print(f'item: {item}')
    return md