# -*- coding: utf-8 -*-
"""
    **Created by Tempest**
    **If you see this in a addon other than Tempest and says it was
    created by someone other than Tempest they stole it from me**
"""
import json
import re

from openscrapers import parse_qs, urlencode, quote_plus
from openscrapers.modules import log_utils
from openscrapers.modules.client import request
from openscrapers.modules.hindi_utils import convert_youtube_duration_to_minutes


class source:
    def __init__(self):
        self.domain = ['youtube.com']
        self.base_link = 'https://www.youtube.com/'
        self.key = 'AIzaSyCjf8izIeXa1oFZo7_HeL0WgrOq1WF_I1k'
        # self.key_link = f'&key={self.key}'
        self.search_link = f'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoDuration=long&videoType=movie&maxResults=50&q=%s&key={self.key}'
        self.search_link2 = f'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoDuration=long&videoType=episode&maxResults=50&q=%s&key={self.key}'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            return urlencode({'imdb': imdb, 'title': title, 'year': year})
        except:
            return

    def sources(self, url, hostDict):
        sources = []
        if url is None: return sources
        try:
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            query = f'{data["title"]} {int(data["year"])}'

            squery = f'{query} full movie|movie|full'
            query_url = self.search_link % quote_plus(squery)
            # log_utils.log(f'query_url: {query_url}')

            query_url += "&relevanceLanguage=en"
            headers = {"Accept": "application/json"}
            response = request(query_url, headers=headers)
            # log_utils.log(f'response type: {type(response)} response: {response}')
            json_items = eval(response).get('items', [])
            # log_utils.log(f'search json_items {json_items}')
            for search_result in json_items:
                # query = query.split('-')[0].lower().replace('.', '')
                item_title = str(search_result["snippet"]["title"].replace('.', ''))
                # log_utils.log(f'search item_title {item_title}')
                if re.findall(data['title'], item_title, re.IGNORECASE):
                    # if (any(re.findall(r'Full Movie|Movie', item_title, re.IGNORECASE)) and re.findall(data['title'], item_title, re.IGNORECASE) and search_result["id"]["kind"] == "youtube#video"):
                    vid_id = search_result["id"]["videoId"]
                    payload = {'id': vid_id, 'part': 'contentDetails', 'key': self.key}
                    url = f'https://www.googleapis.com/youtube/v3/videos/?&{urlencode(payload)}'
                    response = request(url, headers={"Accept": "application/json"})
                    response = json.loads(response)
                    # log_utils.log(f'type: {type(resp_dict)} duration: {resp_dict}')
                    dur = response["items"][0]["contentDetails"]["duration"]
                    duration = convert_youtube_duration_to_minutes(dur)
                    # log_utils.log(f'dur: {dur} duration: {duration}')
                    if duration > 70:
                        v_link = f'plugin://plugin.video.youtube/play/?video_id={vid_id}'
                        sources.append({'source': 'youtube', 'quality': 'SD', 'url': v_link, 'info': f'{duration} minutes', 'name_info': item_title, 'direct': True})
            return sources
        except Exception:
            log_utils.error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        return url
