# -*- coding: utf-8 -*-
"""
	OpenScrapers Module
"""

import gzip
import random
from random import choice, randrange
import re
# from sys import version_info
import traceback
from time import sleep

import requests
import simplejson as json


from requests import Session, exceptions
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
# from urllib3.exceptions import MaxRetryError, ReadTimeoutError


from openscrapers.modules import cache
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules import log_utils

from http import cookiejar
from html import unescape
from io import BytesIO

from urllib.parse import quote_plus, urlencode, parse_qs, urlparse, urljoin, quote
from urllib.response import addinfourl
from urllib.error import HTTPError, URLError
from urllib.request import build_opener, install_opener, ProxyHandler, Request, urlopen, HTTPHandler, HTTPSHandler, HTTPRedirectHandler, HTTPCookieProcessor
import ssl


def list_request(doms, query='', scheme='https://'):
	if isinstance(doms, list):
		for i in range(len(doms)):
			dom = random.choice(doms)
			try:
				base_link = scheme + dom if not dom.startswith('http') else dom
				url = urljoin(base_link, query)
				# log_utils.log(f'list_request i: {i} url: {url}')
				r = requests.get(url, headers={'User-Agent': agent(), 'Referer': base_link}, timeout=7)
				if r.ok:
					#log_utils.log('list_request chosen base: ' + base_link)
					return r.text, base_link
				raise Exception()
			except Exception:
				doms = [d for d in doms if not d == dom]
				log_utils.log('list_request failed dom: ' + repr(i) + ' - ' + dom)
				pass
	else:
		base_link = scheme + doms if not doms.startswith('http') else doms
		url = urljoin(base_link, query)
		# log_utils.log(f'list_request url: {url}')
		r = requests.get(url, headers={'User-Agent': agent(), 'Referer': base_link}, timeout=10)
		if r.ok:
			#log_utils.log('list_request chosen base: ' + base_link)
			return r.text, base_link
		raise Exception()


def request(url, close=True, redirect=True, error=False, proxy=None, post=None, headers=None, mobile=False, XHR=False, limit=None, referer=None, cookie=None, compression=True, output='', timeout='30', verifySsl=True, drop_tls_level=False, flare=True, ignoreErrors=None, as_bytes=False):

	if not url: return None
	if url.startswith('//'): url = 'http:' + url

	if isinstance(post, dict):
		post = bytes(urlencode(post), encoding='utf-8')
	elif isinstance(post, str):
		post = bytes(post, encoding='utf-8')

	try:
		handlers = []
		if proxy is not None:
			handlers += [ProxyHandler({'http': '%s' % proxy}), HTTPHandler]
			# opener = build_opener(*handlers)
			# install_opener(opener)

		if output == 'cookie' or output == 'extended' or close is not True or redirect:
			cookies = cookiejar.LWPCookieJar()
			handlers += [HTTPHandler(), HTTPSHandler(), HTTPCookieProcessor(cookies)]
			# opener = build_opener(*handlers)
			# install_opener(opener)

		if not verifySsl:
			ctx = _get_unverified_context(False, drop_tls_level)
		else:
			ctx = _get_unverified_context(verifySsl, drop_tls_level)
		handlers += [HTTPSHandler(context=ctx, debuglevel=1)]
		opener = build_opener(*handlers)
		install_opener(opener)
		try: headers.update(headers)
		except: headers = {}
		if 'User-Agent' in headers: pass
		elif mobile is not True: headers['User-Agent'] = cache.get(randomagent, 12)
		else: headers['User-Agent'] = cache.get(randommobileagent, 12)
		if 'Referer' in headers: pass
		elif referer is None: headers['Referer'] = '%s://%s/' % (urlparse(url).scheme, urlparse(url).netloc)
		else: headers['Referer'] = referer
		if 'Accept-Language' not in headers: headers['Accept-Language'] = 'en-US'
		if 'X-Requested-With' in headers: pass
		elif XHR: headers['X-Requested-With'] = 'XMLHttpRequest'
		if 'Cookie' in headers: pass
		elif cookie: headers['Cookie'] = cookie
		if 'Accept-Encoding' in headers: pass
		elif compression and limit is None: headers['Accept-Encoding'] = 'gzip'

		if redirect is False:
			class NoRedirectHandler(HTTPRedirectHandler):
				def http_error_302(self, reqst, fp, code, msg, head):
					infourl = addinfourl(fp, head, reqst.get_full_url())
					infourl.status = code
					infourl.code = code
					return infourl

				http_error_300 = http_error_302
				http_error_301 = http_error_302
				http_error_303 = http_error_302
				http_error_307 = http_error_302

			opener = build_opener(NoRedirectHandler())
			install_opener(opener)
			try: del headers['Referer']
			except: pass

		# url = quote(url, safe=':/')
		req = Request(url, data=post)
		_add_request_header(req, headers)
		try:
			response = opener.open(req, timeout=int(timeout))
			# try: response = opener.open(req, timeout=int(timeout))
			# except Exception as err:
				# log_utils.log(f'client.request: Error {err} url: {url} ')
				# if 'CERTIFICATE_VERIFY_FAILED' in str(err):
					# _get_unverified_context(False, drop_tls_level)
					# handlers += [HTTPSHandler(context=ctx, debuglevel=1)]
					# opener = build_opener(*handlers)
					# install_opener(opener)
					# response = opener.open(req, timeout=int(timeout))
		except HTTPError as error_response:# if HTTPError, using "as response" will be reset after entire Exception code runs and throws error around line 247 as "local variable 'response' referenced before assignment", re-assign it
			response = error_response
			try: ignore = ignoreErrors and (int(response.code) == ignoreErrors or int(response.code) in ignoreErrors)
			except: ignore = False

			if not ignore:
				if response.code in (301, 307, 308, 503, 403): # 403:Forbidden added 3/3/21 for cloudflare, fails on bad User-Agent
					cf_result = _get_result(response)
					if not as_bytes:
						cf_result = cf_result.decode(encoding='utf-8', errors='ignore')
					if flare and 'cloudflare' in str(response.info()).lower():
						log_utils.log('client module calling cfscrape: url=%s' % url, level=log_utils.LOGDEBUG)
						try:
							from openscrapers.modules import cfscrape
							if isinstance(post, dict): data = post
							else:
								try: data = parse_qs(post)
								except: data = None
							scraper = cfscrape.CloudScraper()
							# possible bad User-Agent in headers, let cfscrape assign
							if response.code == 403: response = scraper.request(method='GET' if post is None else 'POST', url=url, data=data, timeout=int(timeout))
							else: response = scraper.request(method='GET' if post is None else 'POST', url=url, headers=headers, data=data, timeout=int(timeout))
							result = response.content
							flare = 'cloudflare'  # Used below
							try: cookies = response.request._cookies
							except: log_utils.error()
							if response.status_code == 403: # if cfscrape server still responds with 403
								log_utils.error(f'from: line# 169 url: {url} cfscrape-Error : ') # HTTP Error 403: Forbidden
								return response
						except:
							log_utils.error(f'from: {__name__} url: {url} cfscrape-Error ')
					elif 'cf-browser-verification' in str(cf_result):
						netloc = '%s://%s' % (urlparse(url).scheme, urlparse(url).netloc)
						ua = headers['User-Agent']
						cf = cache.get(cfcookie().get, 168, netloc, ua, timeout)
						headers['Cookie'] = cf
						req = Request(url, data=post)
						_add_request_header(req, headers)
						response = urlopen(req, timeout=int(timeout))
						result = _get_result(response)
					else:
						if error is False:
							log_utils.error(f'line# 184 from: {__name__}  url={url} Error: ')
							return None
				else:
					if error is False:
						log_utils.error(f'line# 188 from: {__name__}  url={url} Error: ')
						return None
					elif error is True and response.code in (401, 404, 405): # no point in continuing after this exception runs with these response.code's
						try: response_headers = dict([(item[0].title(), item[1]) for item in list(response.info().items())]) # behaves differently 18 to 19. 18 I had 3 "Set-Cookie:" it combined all 3 values into 1 key. In 19 only the last keys value was present.
						except:
							log_utils.error()
							response_headers = response.headers
						return (str(response), str(response.code), response_headers)

		if output == 'cookie':
			# if not cookies: cookies = response.info().get_all('Set-Cookie')
			try: result = '; '.join(['%s=%s' % (i.name, i.value) for i in cookies])
			except: pass
			try: result = cf
			except: pass
			if close is True: response.close()
			return result
		elif output == 'geturl':
			result = response.geturl()
			if close is True: response.close()
			return result
		elif output == 'headers':
			result = response.headers
			if close is True: response.close()
			return result
		elif output == 'response':
			result = _get_result(response)
			return str(response.code), result
		elif output == 'chunk':
			try: content = int(response.headers['Content-Length'])
			except: content = (2049 * 1024)
			if content < (2048 * 1024): return
			try: result = response.read(16 * 1024)
			except: result = response # testing
			if close is True: response.close()
			return result
		elif output == 'file_size':
			try: content = int(response.headers['Content-Length'])
			except: content = '0'
			if close is True: response.close()
			return content
		if flare != 'cloudflare':
			if limit == '0': result = response.read(224 * 1024)
			elif limit is not None: result = response.read(int(limit) * 1024)
			else: result = response.read(5242880)
		try: encoding = response.headers["Content-Encoding"]
		except: encoding = None
		if encoding == 'gzip': result = gzip.GzipFile(fileobj=BytesIO(result)).read()
		if not as_bytes:
			# result = result.decode('utf-8') # UnicodeDecodeError -> 'utf-8' codec can't decode byte 0xe5
			result = result.decode(encoding='utf-8', errors='ignore')

		if not as_bytes and 'sucuri_cloudproxy_js' in result: # who da fuck?
			su = sucuri().get(result)
			headers['Cookie'] = su
			req = Request(url, data=post)
			_add_request_header(req, headers)
			response = urlopen(req, timeout=int(timeout))
			if limit == '0': result = response.read(224 * 1024)
			elif limit is not None: result = response.read(int(limit) * 1024)
			else: result = response.read(5242880)
			try: encoding = response.headers["Content-Encoding"]
			except: encoding = None
			if encoding == 'gzip': result = gzip.GzipFile(fileobj=BytesIO(result)).read()

		if not as_bytes and 'Blazingfast.io' in result and 'xhr.open' in result: # who da fuck?
			netloc = '%s://%s' % (urlparse(url).scheme, urlparse(url).netloc)
			ua = headers['User-Agent']
			headers['Cookie'] = cache.get(bfcookie().get, 168, netloc, ua, timeout)
			result = _basic_request(url, headers=headers, post=post, method='POST', timeout=timeout, limit=limit)
		if output == 'extended':
			try: response_headers = dict([(item[0].title(), item[1]) for item in list(response.info().items())]) # behaves differently 18 to 19. 18 I had 3 "Set-Cookie:" it combined all 3 values into 1 key. In 19 only the last keys value was present.
			except: response_headers = response.headers
			try: response_code = str(response.code)
			except: response_code = str(response.status_code) # object from CFScrape Requests object.
			try: cookie = '; '.join(['%s=%s' % (i.name, i.value) for i in cookies])
			except: pass
			try: cookie = cf
			except: pass
			if close is True: response.close()
			return (result, response_code, response_headers, headers, cookie)
		elif output == 'json':
			result = _get_result(response)
			content = json.loads(result)
			response.close()
			return content
		else:
			#result = _get_result(response)
			if close is True: response.close()
			# if not as_bytes: result = ensure_text(result, errors='ignore')
			return result
	except Exception as err:
		# log_utils.error('client.request:  url: %s \nrequest-Error: (%s) ' % (url, traceback.print_exc()))
		log_utils.log(f'line# 284 from: {__name__} Error: {err} >> url: {url} headers: {headers}')
		return None


def _basic_request(url, headers=None, post=None, method='GET', timeout='30', limit=None, ret_code=None):
	try:
		try: headers.update(headers)
		except: headers = {}
		# url = quote(url, safe=':/')
		req = Request(url, data=post, method=method)
		_add_request_header(req, headers)
		response = urlopen(req, timeout=int(timeout))
		return _get_result(response, limit, ret_code)
	except:
		# log_utils.log('_basic_request-Error: (%s) => %s' % (traceback.print_exc()), url), __name__, log_utils.LOGDEBUG)
		log_utils.log(f'line# 296 from: {__name__} url: {url} Error: {traceback.print_exc()}')


def _add_request_header(_request, headers):
	try:
		if not headers: headers = {}
		scheme = _request.type
		host = _request.host
		referer = headers.get('Referer') if 'Referer' in headers else '%s://%s/' % (scheme, host)
		_request.add_unredirected_header('Host', host)
		_request.add_unredirected_header('Referer', referer)
		for key in headers:
			if isinstance(headers[key], dict): continue
			# print("type headers[key]: {} headers[key]: {}".format(type(headers[key]), headers[key]))
			_request.add_header(key, headers[key])
	except:
		# log_utils.log('_add_request_header-Error: (%s) =>' % (traceback.print_exc()), __name__, log_utils.LOGDEBUG)
		log_utils.log(f'from: {__name__} Error: {traceback.print_exc()}')


def _get_result(response, limit=None, ret_code=None):
	try:
		if ret_code: return response.code
		if limit == '0': result = response.read(224 * 1024)
		elif limit: result = response.read(int(limit) * 1024)
		else: result = response.read(5242880)
		encoding = _get_encoding(response)
		if encoding == 'gzip': result = gzip.GzipFile(fileobj=BytesIO(result)).read()
		return result
	except:
		log_utils.log(f'from: {__name__} Error: {traceback.print_exc()}')


def replaceHTMLCodes(txt):
	# Some HTML entities are encoded twice. Decode double.
	return _replaceHTMLCodes(_replaceHTMLCodes(txt))


def _replaceHTMLCodes(txt):
	try:
		if not txt: return ''
		txt = re.sub(r"(&#[0-9]+)([^;^0-9]+)", "\\1;\\2", txt) # fix html codes with missing semicolon
		txt = unescape(txt)
		txt = txt.replace("&quot;", "\"")
		txt = txt.replace("&amp;", "&")
		txt = txt.replace("&lt;", "<")
		txt = txt.replace("&gt;", ">")
		txt = txt.replace("&apos;", "'")
		txt = txt.replace("&#38;", "&")
		txt = txt.replace("&nbsp;", "")
		txt = txt.replace('&#8230;', '...')
		txt = txt.replace('&#8217;', '\'')
		txt = txt.replace('&#8211;', '-')
		txt = txt.strip()
		return txt
	except:
		log_utils.error()
		return txt


def cleanHTML(txt):
	txt = re.sub(r'<.+?>|</.+?>|\n', '', txt)
	return _replaceHTMLCodes(_replaceHTMLCodes(txt))


def randomagent():
	BR_VERS = [
		['%s.0' % i for i in range(95, 100)],
		['97.0.4692.71', '97.0.4692.99', '98.0.4758.82', '98.0.4758.102', '99.0.4844.151', '100.0.4896.75', '100.0.4896.88 ', '101.0.4951.41', '101.0.4951.64', '102.0.5005.63'],
		['11.0']]
	WIN_VERS = ['Windows NT 11.0', 'Windows NT 10.0', 'Windows NT 8.1', 'Windows NT 8.0', 'Windows NT 7.0']
	FEATURES = ['; WOW64', '; Win64; IA64', '; Win64; x64', '']
	RAND_UAS = ['Mozilla/5.0 ({win_ver}{feature}; rv:{br_ver}) Gecko/20100101 Firefox/{br_ver}',
				'Mozilla/5.0 ({win_ver}{feature}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{br_ver} Safari/537.36',
				'Mozilla/5.0 ({win_ver}{feature}; Trident/7.0; rv:{br_ver}) like Gecko'] # (compatible, MSIE) removed, dead browser may no longer be compatible and it fails for glodls with "HTTP Error 403: Forbidden"
	index = randrange(len(RAND_UAS))
	return RAND_UAS[index].format(
		win_ver=choice(WIN_VERS),
		feature=choice(FEATURES),
		br_ver=choice(BR_VERS[index]))


def randommobileagent(mobile='android'):
	_mobagents = [
		'Mozilla/5.0 (Linux; Android 7.1; vivo 1716 Build/N2G47H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.98 Mobile Safari/537.36',
		'Mozilla/5.0 (Linux; Android 7.0; SM-J710MN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Mobile Safari/537.36',
		'Mozilla/5.0 (Android 10; Mobile; rv:84.0) Gecko/84.0 Firefox/84.0',
		'Mozilla/5.0 (Android 12; Mobile; rv:68.0) Gecko/68.0 Firefox/94.0',
		'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.50 Mobile Safari/537.36',
		'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.50 Mobile Safari/537.36 EdgA/95.0.1020.42',
		'Mozilla/5.0 (Linux; Android 10; SM-G970F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.50 Mobile Safari/537.36 OPR/63.3.3216.58675',
		'Mozilla/5.0 (iPhone; CPU iPhone OS 15_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1',
		'Mozilla/5.0 (iPhone; CPU iPhone OS 15_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 EdgiOS/95.0.1020.40 Mobile/15E148 Safari/605.1.15',
		'Mozilla/5.0 (iPad; CPU OS 15_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1',
		'Mozilla/5.0 (iPhone; CPU iPhone OS 15_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/96.0.4664.36 Mobile/15E148 Safari/604.1',
		'Mozilla/5.0 (iPad; CPU OS 15_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/96.0.4664.36 Mobile/15E148 Safari/604.1',
		'Mozilla/5.0 (iPhone; CPU iPhone OS 13_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1.2 Mobile/15E148 Safari/605.1',
		'Mozilla/5.0 (iPad; CPU OS 10_2_1 like Mac OS X) AppleWebKit/602.4.6 (KHTML, like Gecko) Version/10.0 Mobile/14D27 Safari/602.1']

	if mobile == 'android':
		return choice(_mobagents[:7])
	else:
		return choice(_mobagents[8:14])


def agent():
	return choice(
			["Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36",
			"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36",
			"Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36",
			"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0",
			"Mozilla/5.0 (Macintosh; Intel Mac OS X 12.0; rv:94.0) Gecko/20100101 Firefox/94.0",
			"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:94.0) Gecko/20100101 Firefox/94.0",
			"Mozilla/5.0 (Macintosh; Intel Mac OS X 12_0_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Safari/605.1.15",
			"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36 Edg/95.0.1020.44",
			"Mozilla/5.0 (Macintosh; Intel Mac OS X 12_0_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36 Edg/94.0.992.31",
			"Mozilla/5.0 (Windows NT 10.0; WOW64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36 OPR/81.0.4196.31",
			"Mozilla/5.0 (Macintosh; Intel Mac OS X 12_0_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36 OPR/81.0.4196.31",
			"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36 OPR/81.0.4196.31"])


class cfcookie:
	def __init__(self):
		self.cookie = None

	def get(self, netloc, ua, timeout):
		from threading import Thread
		threads = []
		for i in list(range(0, 15)):
			threads.append(Thread(target=self.get_cookie, args=(netloc, ua, timeout)))
		[i.start() for i in threads]
		for i in list(range(0, 30)):
			if self.cookie is not None: return self.cookie
			sleep(1)

	def get_cookie(self, netloc, ua, timeout):
		try:
			headers = {'User-Agent': ua}
			req = Request(netloc)
			_add_request_header(req, headers)

			try: response = urlopen(req, timeout=int(timeout))
			except HTTPError as response:
				result = response.read(5242880)
				encoding = _get_encoding(response)
				if encoding == 'gzip': result = gzip.GzipFile(fileobj=BytesIO(result)).read()

			jschl = re.findall(r'name\s*=\s*["\']jschl_vc["\']\s*value\s*=\s*["\'](.+?)["\']/>', result, re.I)[0]
			init = re.findall(r'setTimeout\(function\(\){\s*.*?.*:(.*?)};', result, re.I)[-1]
			builder = re.findall(r"challenge-form\'\);\s*(.*)a.v", result, re.I)[0]
			decryptVal = self.parseJSString(init)
			lines = builder.split(';')

			for line in lines:
				if len(line) > 0 and '=' in line:
					sections = line.split('=')
					line_val = self.parseJSString(sections[1])
					decryptVal = int(eval(str(decryptVal) + sections[0][-1] + str(line_val)))

			answer = decryptVal + len(urlparse(netloc).netloc)
			query = '%s/cdn-cgi/l/chk_jschl?jschl_vc=%s&jschl_answer=%s' % (netloc, jschl, answer)

			if 'type="hidden" name="pass"' in result:
				passval = re.findall(r'name\s*=\s*["\']pass["\']\s*value\s*=\s*["\'](.*?)["\']', result, re.I)[0]
				query = '%s/cdn-cgi/l/chk_jschl?pass=%s&jschl_vc=%s&jschl_answer=%s' % (netloc, quote_plus(passval), jschl, answer)
				sleep(6)
			cookies = cookiejar.LWPCookieJar()
			handlers = [HTTPHandler(), HTTPSHandler(), HTTPCookieProcessor(cookies)]
			opener = build_opener(*handlers)
			opener = install_opener(opener)
			try:
				req = Request(query)
				_add_request_header(req, headers)
				response = urlopen(req, timeout=int(timeout))
			except: pass

			cookie = '; '.join(['%s=%s' % (i.name, i.value) for i in cookies])
			if 'cf_clearance' in cookie: self.cookie = cookie
		except:
			log_utils.log('get_cookie-Error: (%s) ' % (traceback.print_exc()), __name__, log_utils.LOGDEBUG)

	def parseJSString(self, s):
		try:
			offset = 1 if s[0] == '+' else 0
			val = int(eval(s.replace('!+[]', '1').replace('!![]', '1').replace('[]', '0').replace('(', 'str(')[offset:]))
			return val
		except:
			log_utils.log('parseJSString-Error: (%s) ' % (traceback.print_exc()), __name__, log_utils.LOGDEBUG)


class bfcookie:
	def __init__(self):
		self.COOKIE_NAME = 'BLAZINGFAST-WEB-PROTECT'

	def get(self, netloc, ua, timeout):
		try:
			headers = {'User-Agent': ua, 'Referer': netloc}
			result = _basic_request(netloc, headers=headers, timeout=timeout)
			match = re.findall(r'xhr\.open\("GET","([^,]+),', result, re.I)
			if not match: return False
			url_Parts = match[0].split('"')
			url_Parts[1] = '1680'
			url = urljoin(netloc, ''.join(url_Parts))
			match = re.findall(r'rid\s*?=\s*?([0-9a-zA-Z]+)', url_Parts[0])
			if not match: return False
			headers['Cookie'] = 'rcksid=%s' % match[0]
			result = _basic_request(url, headers=headers, timeout=timeout)
			return self.getCookieString(result, headers['Cookie'])
		except:
			log_utils.log('bfcookie-Error: (%s) ' % (traceback.print_exc()), __name__, log_utils.LOGDEBUG)

	# not very robust but lazieness...
	def getCookieString(self, content, rcksid):
		vars = re.findall(r'toNumbers\("([^"]+)"', content)
		value = self._decrypt(vars[2], vars[0], vars[1])
		cookie = '%s=%s;%s' % (self.COOKIE_NAME, value, rcksid)
		return cookie

	def _decrypt(self, msg, key, iv):
		from binascii import unhexlify, hexlify
		from openscrapers.modules import pyaes
		msg = unhexlify(msg)
		key = unhexlify(key)
		iv = unhexlify(iv)
		if len(iv) != 16: return False
		decrypter = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(key, iv))
		plain_text = decrypter.feed(msg)
		plain_text += decrypter.feed()
		f = hexlify(plain_text)
		return f


class sucuri:
	def __init__(self):
		self.cookie = None

	def get(self, result):
		from base64 import b64decode
		try:
			s = re.compile(r"S\s*=\s*'([^']+)").findall(result)[0]
			s = b64decode(s)
			s = s.replace(' ', '')
			s = re.sub(r'String\.fromCharCode\(([^)]+)\)', r'chr(\1)', s)
			s = re.sub(r'\.slice\((\d+),(\d+)\)', r'[\1:\2]', s)
			s = re.sub(r'\.charAt\(([^)]+)\)', r'[\1]', s)
			s = re.sub(r'\.substr\((\d+),(\d+)\)', r'[\1:\1+\2]', s)
			s = re.sub(r';location.reload\(\);', '', s)
			s = re.sub(r'\n', '', s)
			s = re.sub(r'document\.cookie', 'cookie', s)
			cookie = ''
			exec(s)
			self.cookie = re.compile(r'([^=]+)=(.*)').findall(cookie)[0]
			self.cookie = '%s=%s' % (self.cookie[0], self.cookie[1])
			return self.cookie
		except:
			log_utils.log('sucuri-Error: (%s) ' % (traceback.print_exc()), __name__, log_utils.LOGDEBUG)


def cf_responce(url, headers=None, post=None, timeout='20'):
	try:
		from openscrapers.modules import cfscrape
		# url = quote(url, safe=':/')
		headers = get_fheaders(url, headers)
		data = None
		if post:
			if isinstance(post, dict):
				data = post
			else:
				try: data = parse_qs(post)
				except: pass
		scraper = cfscrape.CloudScraper()
		try: response = scraper.request(method='GET' if post is None else 'POST', url=url, headers=headers, data=data, timeout=int(timeout))
		except: response = scraper.request(method='GET' if post is None else 'POST', url=url, headers=headers, data=data, verify=False, timeout=int(timeout))
		return response
	except:
		log_utils.error()


def R_Session(customheaders=None):
	try: customheaders.update(customheaders)
	except: customheaders = {}
	try:
		session = Session()
		retries = Retry(total=3,  # number of total retries
						connect=2,  # retry once in case we can't connect to url
						read=2,  # retry once in case we can't read the response from url
						redirect=3,  # retry once in case we're redirect by url
						backoff_factor=1,  # The pause between for each retry
						status_forcelist=[429, 500, 502, 503, 504],  # this is a list of statuses to consider to be an error and retry. definitely retry if url is unwell
						method_whitelist=frozenset(['GET', 'POST']))

		session.mount('https://', HTTPAdapter(max_retries=retries))
		session.mount('http://', HTTPAdapter(max_retries=retries))
		session.headers.update(
			{
				'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
				'User-Agent': customheaders['User-Agent'] if 'User-Agent' in customheaders else agent(),
				'Accept-Language': 'en-US,en;q=0.5',
				'x-requested-with': 'XMLHttpRequest',
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
				'Upgrade-Insecure-Requests': '1',
				'DNT': '1'
			}
		)
		if 'cookies' in customheaders:
			session.cookies.update(customheaders['cookies'])
		return session
	except:
		log_utils.log(f'Scrape - Exception: {traceback.print_exc()}')
		return None


def get_fheaders(url, headers):
	try: headers.update(headers)
	except: headers = {}
	if 'Referer' not in headers:
		elements = urlparse(url)
		# html_filename = "%s.html" % (elements.netloc or elements.path)
		base = '%s://%s' % (elements.scheme, (elements.netloc or elements.path))
		headers['Referer'] = base
	if 'User-Agent' not in headers: headers['User-Agent'] = agent()
	fheaders = {'x-requested-with': 'XMLHttpRequest',
				'Accept-Language': 'en-US,en;q=0.5',
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
				'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
				'Upgrade-Insecure-Requests': '1',
				'DNT': '1', }
	# "Sec-Fetch-Dest": "document", }
	# "Sec-Fetch-Mode": "navigate"}
	fheaders.update(headers)
	return fheaders


def r_request(url, headers=None, post=None, timeout=20, verify=True):
	try:
		if not url: return
		try: from openscrapers import testing
		except: testing = True
		# url = "https:" + url if not url.startswith('http') else url
		# url = quote(url, safe=':/')
		fheaders = get_fheaders(url, headers)
		# print("fheaders: {}".format(fheaders))
		with R_Session() as R_session:
			R_session.headers.update(fheaders)
			try:
				if post: response = R_session.post(url, data=post, timeout=int(timeout), verify=verify)
				else: response = R_session.get(url, timeout=int(timeout), verify=verify)
				response.raise_for_status()
				# Code here will only run if the request is successful
			except exceptions.SSLError as err:
				log_utils.log(f'r_request SSLError" Error: {err}')
				r_request(url, headers=fheaders, post=post, timeout=timeout, verify=False)
			except exceptions.Timeout as err:
				log_utils.log(f'r_request Timeout: Error: {err}')
				r_request(url, headers=fheaders, post=post, timeout=timeout + 10, verify=verify)
			except exceptions.ConnectionError as err:
				log_utils.log(f'r_request ConnectionError: Error: {err}')  # return type('FailedResponse', (object,), {'ok': False})
			except exceptions.HTTPError as err:
				log_utils.log(f'r_request HTTPError: Error: {err}')
			except exceptions.RequestException as err:
				log_utils.log(f'r_request RequestException: Error: {err}')
			except Exception as e:
				log_utils.log(f'r_request except Exception as e: {e}')  # return type('FailedResponse', (object,), {'ok': False})

		# session_cookies = R_session.cookies
		# cookies_dictionary = session_cookies.get_dict()
		# log_utils.log(f'cookies_dictionary: {cookies_dictionary}')
		# session_headers = R_session.headers
		# log_utils.log(f'session_headers send: {session_headers}')
		# log_utils.log(f'response.headers recived: {response.headers}')
		if response.status_code in (301, 307, 308, 503, 403):
			response = cf_responce(url, fheaders)
			# log_utils.log(f'repr(response) : {repr(response)}')
			if response.status_code > 400:  # if cfscrape server still responds with 403
				log_utils.log(f'from: line# 689 url: {url} cfscrape-Error : ') # HTTP Error 403: Forbidden
				return response

		if testing:
			testing_write_html(url, response)
		return response
	except Exception as e:
		log_utils.error(f'Exception: {e} module: r_request url: {url} traceback: {traceback.print_exc()}')
		return


def _get_encoding(response):
	try:
		try:
			encoding = response.info().getheader('Content-Encoding')
			return encoding
		except:
			encoding = response.headers['Content-Encoding']
			return encoding
	except:
		log_utils.log(f'From: {__name__} Error: {traceback.print_exc()} ')
	return None


def _get_unverified_context(verifySsl, drop_tls_level):
	import ssl
	if not verifySsl:
		try:
			ctx = ssl.create_default_context()
			ctx.check_hostname = False
			ctx.verify_mode = ssl.CERT_NONE
			return ctx
		except:
			pass
	else:
		try:
			from openscrapers.modules.control import get_kodi_certi_file
			ctx = ssl.create_default_context(cafile=get_kodi_certi_file())
			# ctx = ssl.create_default_context(cafile=certifi.where())
			if drop_tls_level:
				ctx.protocol = ssl.PROTOCOL_TLSv1_1
			return ctx
		except:
			pass


def testing_write_html(url, responce):
	from openscrapers.modules.hindi_sources import read_write_file
	elements = urlparse(url)
	html_filename = '%s.html' % (elements.netloc or elements.path)
	html_filename = 'JSTesting/%s' % html_filename
	log_utils.log(f'USE html_filename: {html_filename}')
	try: data = responce.text
	except: data = responce
	read_write_file(file_n=html_filename, read=False, result=data)


def scrapePage(url, referer=None, headers=None, post=None, cookie=None):
	try:
		if not url: return
		url = "https:" + url if url.startswith('//') else url
		with requests.Session() as session:
			if headers: session.headers.update(headers)
			if referer and 'Referer' not in session.headers:
				session.headers.update({'Referer': referer})
			else:
				elements = urlparse(url)
				base = '%s://%s' % (elements.scheme, (elements.netloc or elements.path))
				session.headers.update({'Referer': base})
			# not tested yet, just placed as a idea reminder.
			if cookie and not 'Cookie' in session.headers: session.headers.update({'Cookie': cookie})
			if not 'User-Agent' in session.headers: session.headers.update({'User-Agent': agent()})
			if post: page = session.post(url, data=post, timeout=10)
			else: page = session.get(url, timeout=10)
			page.encoding = 'utf-8'
			page.raise_for_status()
		return page
	except Exception:
		log_utils.error(f'{__name__}_ scrapePage: ')
		return
