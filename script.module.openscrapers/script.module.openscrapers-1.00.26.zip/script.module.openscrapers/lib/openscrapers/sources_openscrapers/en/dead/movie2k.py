# -*- coding: utf-8 -*-
"""
    **Created by Tempest**
    **If you see this in a addon other than Tempest and says it was
    created by someone other than Tempest they stole it from me**
"""

import re, requests, base64
import traceback
from openscrapers import urlencode, parse_qs, quote_plus, urljoin
from openscrapers.modules import log_utils
from openscrapers.modules import client
from openscrapers.modules import scrape_source


class source:
    def __init__(self):
        self.priority = 40
        self.language = ['en']
        self.domains = ['movie2k.123movies.online']
        self.base_link = 'https://movie2k.123movies.online'
        self.search_link = '/?cat=tv&search=%s&exact=&actor=&director=&year=%s&advanced_search=true'
        self.search_link2 = '/?cat=movie&search=%s&exact=&actor=&director=&year=%s&advanced_search=true'
        self.headers = {'User-Agent': client.agent(), 'Referer': self.base_link}

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        items = []
        try:

            if url is None:
                return sources

            hostDict = hostprDict + hostDict

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']

            if 'tvshowtitle' in data:
                urls = self.search_link % (data['tvshowtitle'], data['year'])
                url = urljoin(self.base_link, urls)
                posts = requests.get(url, headers={'User-Agent': client.agent(), 'Referer': urls}).text
                url = re.findall(r'<div class="title"><a title=".+?" href="(.+?)">(.+?)</a></div><div class="year"> (.+?)</div>', posts)
                for url, title, year in url:
                    if data['tvshowtitle'] in title and data['year'] in year:
                        code = url.split('movie2k-')[1]
                        # url = requests.get(url, headers={'User-Agent': client.agent(), 'Referer': urls}).content
                        url = "https://movie2k.123movies.online/watch-tv-%s-season-%s-episode-%s-online-movie2k-%s" % (data['tvshowtitle'], data['season'], data['episode'], code)
                        url = requests.get(url, headers={'User-Agent': client.agent(), 'Referer': url}).text
                        more_links = re.compile(r'<a href="(.+?)">View More Links</a></li></ul>').findall(url)[0]
                        if more_links:
                            url = requests.get(more_links,
                                               headers={'User-Agent': client.agent(), 'Referer': more_links}).text
                            url = re.findall(r'href="(.+?)" id="#iframe"', url)
                            items += url
                        else:
                            url = re.findall(r'href="(.+?)" id="#iframe"', url)
                            items += url

            else:
                urls = self.search_link2 % (data['title'], data['year'])
                url = urljoin(self.base_link, urls)
                posts = requests.get(url, headers=self.headers).text
                url = re.findall('<div class="title"><a title=".+?" href="(.+?)">(.+?)</a></div><div class="year"> (.+?)</div>', posts)
                for url, title, year in url:
                    if data['title'] in title and data['year'] in year:
                        url = self.base_link + url
                        url = requests.get(url, headers={'User-Agent': client.agent(), 'Referer': urls}).text
                        more_links = re.compile('<a href="(.+?)">View More Links</a></li></ul>').findall(url)[0]
                        url = re.compile('href="(.+?)" id="#iframe"').findall(url)
                        items += url

            for item in items:
                try:
                    url = requests.get(item, headers={'User-Agent': client.agent(), 'Referer': item}).text
                    url = re.findall(r'target="_blank">(.+?)</a>', url)[0]
                    if url.startswith('//'):
                        url = 'https:' + url
                    for gsource in scrape_source.getMore(url, hostDict):
                        sources.append(gsource)
                except:
                    log_utils.log('---MOVIE2K Testing - Exception: \n' + str(traceback.format_exc()))
                    pass

            return sources
        except Exception:
            log_utils.error(f'{__name__}_ sources: ')
            return []

    def resolve(self, url):
        if 'jetload' in url:
            url = requests.get(url, headers=self.headers).text
            url = re.findall(r"var x_source = '(.+?)'", url)[0]
            return url
        else:
            log_utils.error(f'{__name__}_ resolve: ')
            return url
