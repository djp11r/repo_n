# -*- coding: UTF-8 -*-

"""
	OpenScrapers Project
"""

import re

import requests

from openscrapers import urljoin

from openscrapers.modules import client
from openscrapers.modules import cleantitle
from openscrapers.modules import source_utils
from openscrapers.modules import log_utils


class source:
	def __init__(self):
		self.priority = 40
		self.language = ['en']
		self.domains = ['moviescouch.vip', 'moviescouch.xyz', 'moviescouch.pro', 'moviescouch.pw']
		self.base_link = 'https://moviescouch.vip'
		self.search_link = '/?s=%s'
		self.headers = {'User-Agent': client.agent()}


	def movie(self, imdb, title, localtitle, aliases, year):
		try:
			search_id = cleantitle.getsearch(title)
			url = urljoin(self.base_link, self.search_link)
			url = url % (search_id.replace(':', ' ').replace(' ', '+'))
			search_results = client.r_request(url)
			# search_results = py_tools.ensure_text(search_results, errors='replace')
			match = re.compile(r'<article id=.+?href="(.+?)" title="(.+?)"', re.DOTALL).findall(search_results.text)
			for row_url, row_title in match:
				if cleantitle.get(title) in cleantitle.get(row_title):
					if str(year) in str(row_title):
						return row_url
			return
		except:
			log_utils.error(f'{__name__}_ movie: ')
			return


	def sources(self, url, hostDict, hostprDict):
		sources = []
		try:
			if not url:	return sources
			html = client.r_request(url)
			# html = py_tools.ensure_text(html, errors = 'replace')
			links = re.compile('<iframe src="(.+?)"', re.DOTALL).findall(html.text)
			for link in links:
				try:
					quality = re.compile('<li>Quality: – (.+?)</li>', re.DOTALL).findall(html)[0]
					info = re.compile('<li>Size: – (.+?)</li>', re.DOTALL).findall(html)[0]
				except:
					quality, info = source_utils.get_release_quality(link)
				host = link.split('//')[1].replace('www.', '')
				host = host.split('/')[0].split('.')[0].title()
				valid, host = source_utils.is_host_valid(host, hostDict)
				if valid:
					sources.append({'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': link, 'direct': False, 'debridonly': False})
			return sources
		except:
			log_utils.error(f'{__name__}_ sources: ')
			return sources


	def resolve(self, url):
		return url
