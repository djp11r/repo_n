# -*- coding: utf-8 -*-

import re, json
from openscrapers import urlencode

from openscrapers.modules import log_utils
from openscrapers.modules import client
from openscrapers.modules import source_utils
from openscrapers.modules.py_tools import six_decode, ensure_str, ensure_text
from openscrapers.modules import cfscrape
from openscrapers.modules.hindi_sources import read_write_file

# cfscraper = cfscrape.create_scraper()
# log_utils.log('---Testing - Exception: \n' + str(url))

"""Example...

from openscrapers.modules import scrape_sources
for source in scrape_sources.process(url, hostDict):
    sources.append(source)

scrape_sources.rescrape(url)

scrape_sources.prepare_link(url)

"""


def prepare_link(url):
    if not url:
        return
    url = "https:" + url if url.startswith('//') else url
    if 'doodstream.com' in url:
        url = url.replace('doodstream.com', 'dood.watch')
    if 'dood.so' in url:
        url = url.replace('dood.so', 'dood.la')
    if 'dood.to' in url:
        url = url.replace('dood.to', 'dood.ws')
    if 'eplayvid.com' in url:
        url = url.replace('eplayvid.com', 'eplayvid.net')
    if 'gomostream.com' in url:
        url = url.replace('gomostream.com', 'gomo.to')
    if 'sendit.cloud' in url:
        url = url.replace('sendit.cloud', 'send.cm')
    if 'vidcloud.icu' in url:
        url = url.replace('vidcloud.icu', 'vidembed.io')
    if 'vidcloud9.com' in url:
        url = url.replace('vidcloud9.com', 'vidembed.io')
    if 'vidembed.cc' in url:
        url = url.replace('vidembed.cc', 'vidembed.io')
    if 'vidnext.net' in url:
        url = url.replace('vidnext.net', 'vidembed.me')
    if 'vidoza.net' in url:
        url = url.replace('vidoza.net', 'vidoza.co')
    #log_utils.log('scrape_sources - prepare_link link: ' + str(url))
    return url


def getMore(link, hostDict, host=None, info=None):
    sources = []
    if link is None: return sources
    link = six_decode(link)
    if link.startswith('//'): link = 'https:%s' % link
    if ' ' in link: link = link.replace(' ', '+')
    # print("getMore url In: {}".format(link))
    link = prepare_link(link)
    host = link if host is None else host
    info = link if info is None else info
    if 'linkbin.me' in host:
            for source in linkbin(link, hostDict):
                sources.append(source)
    elif any(i in host for i in ['gomo.to', 'gomostream.com', 'gomoplayer.com']):
            for source in gomo(link, hostDict):
                sources.append(source)
    elif any(i in host for i in ['database.gdriveplayer.us', 'databasegdriveplayer.co', 'series.databasegdriveplayer.co']):
        for source in gdriveplayer(link, hostDict):
            sources.append(source)
    elif 'vidlink.org' in host:
        for source in vidlink(link, hostDict):
            sources.append(source)
    elif any(i in host for i in ['vidembed.me', 'vidembed.io', 'vidembed.cc', 'vidcloud9.com']):
        for source in vidembed(link, hostDict):
            sources.append(source)
    elif 'voxzer.org' in host:
        for source in voxzer(link, hostDict):
            sources.append(source)
    elif '2embed.ru' in host:
        for source in twoembed(link, hostDict):
            sources.append(source)
    elif "cloudvideo.tv" in link:
        for source in cloudvideo(link, hostDict):
            sources.append(source)
    elif "abcvideo.cc" in link:
        for source in abcvideo(link, hostDict):
            sources.append(source)
    elif "vidoza.net" in link:
        for source in vidoza(link, hostDict):
            sources.append(source)
    elif "upstream.to" in link:
        for source in upstream(link, hostDict):
            sources.append(source)
    elif "mixdrop.co" in link:
        for source in mixdrop(link, hostDict):
            sources.append(source)
    elif "mediashore.org" in link:
        for source in mediashore(link, hostDict):
            sources.append(source)
    elif "movcloud" in link:
        for source in movcloud(link, hostDict):
            sources.append(source)
    elif "vidcloud.pro" in link:
        for source in vidcloud_pro(link, hostDict):
            sources.append(source)
    elif 'vidcloud9' in link:
        for source in vidcloud9(link, hostDict):
            sources.append(source)
    elif 'vidsrc' in link:
        for source in vidsrc(link, hostDict):
            sources.append(source)
    elif 'vidsrc.me' in link:
        for source in vidsrc_me(link, hostDict):
            sources.append(source)
    elif 'vidnext.net' in link:
        for source in vidnext_net(link, hostDict):
            sources.append(source)
    elif 'vidoo' in link:
        for source in vidoo(link, hostDict):
            sources.append(source)
    elif 'hls3x.vidcloud9.com' in link:
        for source in hls3x(link, hostDict):
            sources.append(source)
    elif 'fmovies' in link:
        for source in fmovies_to(link, hostDict):
            sources.append(source)
    else:
        valid, host = source_utils.is_host_valid(link, hostDict)
        if valid:
            quality, info = source_utils.get_release_quality(link, link)
            # if control.setting('dev') == 'true':
            #     log_utils.log('---SCRAPER Testing - Exception: \n' + str(link))
            if link.startswith('http'):
                sources.append({'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': link, 'direct': False, 'debridonly': False})
    return sources


def linkbin(link, hostDict):
    sources = []
    try:
        html = client.scrapePage(link).text
        urls = re.findall('<li class="signle-link"><a href="(.+?)" target="_blank">', html)
        for url in urls:
            url = prepare_link(url)
            valid, host = source_utils.is_host_valid(url, hostDict)
            if valid:
                quality, info = source_utils.get_release_quality(url, url)
                sources.append({'source': host, 'quality': quality, 'info': info, 'url': url, 'direct': False, 'language': 'en', 'debridonly': False})
        return sources
    except Exception:
        #log_utils.log('linkbin', 1)
        return sources


def gomo(link, hostDict):
    sources = []
    try:
        domain = re.findall('(?://|\.)(gomo\.to|gomostream\.com|gomoplayer\.com)/', link)[0]
        gomo_link = 'https://%s/decoding_v3.php' % domain
        result = client.request(link)
        tc = re.compile('tc = \'(.+?)\';').findall(result)[0]
        if (tc):
            token = re.compile('"_token": "(.+?)",').findall(result)[0]
            post = {'tokenCode': tc, '_token': token}
            def tsd(tokenCode):
                _13x48X = tokenCode
                _71Wxx199 = _13x48X[4:18][::-1]
                return _71Wxx199 + "18" + "432782"
            headers = {'Host': domain, 'Referer': link, 'User-Agent': client.UserAgent, 'x-token': tsd(tc)}
            urls = client.request(gomo_link, XHR=True, post=post, headers=headers, output='json')
            for url in urls:
                if not url:
                    continue
                url = prepare_link(url)
                headers = {'User-Agent': client.UserAgent, 'Referer': url}
                if 'gomo.to' in url:
                    url = client.request(url, headers=headers, output='geturl')
                    if not url:
                        continue
                    if 'gomoplayer.com' in url:
                        html = client.request(url, headers=headers)
                        unpacked = client.unpacked(html)
                        links = re.compile('file:"(.+?)"').findall(unpacked)
                        for link in links:
                            if '/srt/' in link:
                                continue
                            quality, info = source_utils.get_release_quality(link, link)
                            link += '|%s' % urlencode({'Referer': url})
                            sources.append({'source': 'gomoplayer', 'quality': quality, 'info': info, 'url': link, 'direct': True, 'language': 'en', 'debridonly': False})
                    elif any(i in url for i in ['database.gdriveplayer.us', 'databasegdriveplayer.co', 'series.databasegdriveplayer.co']):
                        for source in gdriveplayer(url, hostDict):
                            sources.append(source)
                    else:
                        valid, host = source_utils.checkHost(url, hostDict)
                        quality, info = source_utils.get_release_quality(url, url)
                        sources.append({'source': host, 'quality': quality, 'url': url, 'info': info, 'direct': False, 'language': 'en', 'debridonly': False})
                        #sources.append({'source': 'gomo', 'quality': 'SD', 'url': url, 'direct': True})
                else:
                    valid, host = source_utils.checkHost(url, hostDict)
                    if valid:
                        quality, info = source_utils.get_release_quality(url, url)
                        sources.append({'source': host, 'quality': quality, 'url': url, 'info': info, 'direct': False, 'language': 'en', 'debridonly': False})
        return sources
    except Exception:
        #log_utils.log('gomo', 1)
        return sources


def gdriveplayer(link, hostDict):
    sources = []
    try:
        html = client.scrapePage(link).text
        servers = client.parseDOM(html, 'ul', attrs={'class': 'list-server-items'})[0]
        urls = client.parseDOM(servers, 'a', ret='href')
        for url in urls:
            if not url or url.startswith('/player.php'):
                continue
            url = prepare_link(url)
            valid, host = source_utils.is_host_valid(url, hostDict)
            if valid:
                quality, info = source_utils.get_release_quality(url, url)
                sources.append({'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': url, 'direct': False, 'debridonly': False})
        return sources
    except:
        return []


def vidembed(link, hostDict):
    sources = []
    try:
        try:
            html = client.scrapePage(link).text
            urls = client.parseDOM(html, 'li', ret='data-video')
            if urls:
                for url in urls:
                    url = prepare_link(url)
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    if valid:
                        quality, info = source_utils.get_release_quality(url, url)
                        sources.append({'source': host, 'quality': quality, 'info': info, 'url': url, 'direct': False, 'language': 'en', 'debridonly': False})
        except:
            pass
        valid, host = source_utils.is_host_valid(link, hostDict)
        if valid:
            quality, info = source_utils.get_release_quality(link, link)
            sources.append({'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False, 'language': 'en', 'debridonly': False})
        return sources
    except Exception:
        #log_utils.log('vidembed', 1)
        return sources


def vidlink(link, hostDict):
    sources = []
    try:
        return sources # site for update_views bit needs cfscrape so the links are trash.
        # return sources is added to cock block the urls from being seen lol.
        postID = link.split('/embed/')[1]
        post_link = 'https://vidlink.org/embed/update_views'
        payload = {'postID': postID}
        headers = {'User-Agent': client.UserAgent, 'Referer': link}
        headers['X-Requested-With'] = 'XMLHttpRequest'
        ihtml = client.request(post_link, post=payload, headers=headers)
        if ihtml:
            linkcode = client.unpacked(ihtml)
            linkcode = linkcode.replace('\\', '')
            links = re.findall(r'var file1="(.+?)"', linkcode)[0]
            stream_link = links.split('/pl/')[0]
            headers = {'Referer': 'https://vidlink.org/', 'User-Agent': client.UserAgent}
            response = client.request(links, headers=headers)
            urls = re.findall(r'[A-Z]{10}=\d+x(\d+)\W[A-Z]+=\"\w+\"\s+\/(.+?)\.', response)
            if urls:
                for qual, url in urls:
                    url = stream_link + '/' + url + '.m3u8'
                    #log_utils.log('scrape_sources - process vidlink link: ' + str(url))
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    if valid:
                        quality, info = source_utils.get_release_quality(qual, url)
                        sources.append({'source': host, 'quality': quality, 'info': info, 'url': url, 'direct': False, 'language': 'en', 'debridonly': False})
        return sources
    except Exception:
        #log_utils.log('vidlink', 1)
        return sources


def twoembed(link, hostDict):
    sources = []
    items = []
    try:
        headers = {'User-Agent': client.agent(), 'Referer': link}
        r = client.scrapePage(link, headers={'User-Agent': client.agent(), 'Referer': link}).text
        r = re.compile('data-id="(.+?)">.+?</a>').findall(r)
        r = [i for i in r]
        items += r
        for item in items:
            item = 'https://www.2embed.ru/ajax/embed/play?id=%s&_token=' % item
            headers['Referer'] = item
            resp = client.scrapePage(item, headers={'User-Agent': client.agent(), 'Referer': item}).text
            urls = re.findall('"link":"(.+?)","sources"', resp)
            # print("urls: {}".format(urls))
            for url in urls:
                # if 'vidcloud.pro' in url:
                headers['Referer'] = url
                resp = client.scrapePage(url, headers={'User-Agent': client.agent(), 'Referer': url}).text
                # print("resp: {}".format(resp))
                r = re.findall(r'sources = \[{"file":"(.+?)","type"', resp)[0]
                r = r.replace('\\', '')
                valid, host = source_utils.is_host_valid(url, hostDict)
                quality, info = source_utils.get_release_quality(url, url)
                if r.startswith('http'):
                    sources.append({'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': r, 'direct': False, 'debridonly': False})
                else:
                    url = prepare_link(url)
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    if valid:
                        quality, info = source_utils.get_release_quality(url, url)
                        if url.startswith('http'):
                            sources.append({'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': url, 'direct': False,'debridonly': False})
        return sources
    except:
        log_utils.error('twoembed: %s' % link)
        return []


def voxzer(link, hostDict):
    sources = []
    try:
        link = link.replace('/view/', '/list/')
        html = client.scrapePage(link).json()
        url = html['link']
        url += '|%s' % urlencode({'Referer': link})
        valid, host = source_utils.is_host_valid(url, hostDict)
        sources.append({'source': host, 'quality': 'HD', 'url': url, 'direct': True, 'language': 'en', 'info': '', 'debridonly': False})
        return sources
    except Exception:
        #log_utils.log('voxzer', 1)
        return sources


def movcloud(link, hostDict):
    sources = []
    try:
        url = link.replace('https://movcloud.net/embed/', 'https://api.movcloud.net/stream/')
        url = client.request(url, headers={'User-Agent': client.agent(), 'Referer': 'https://movcloud.net'})
        resp = ensure_str(url, errors='replace')
        url = json.loads(resp)
        url = url['data']
        url = url['sources']
        for url in url:
            label = url['label']
            url = url['file']
            quality, info = source_utils.get_release_quality(label, label)
            # if control.setting('dev') == 'true':
            #     log_utils.log('---MOVCLOUD Testing - Exception: \n' + str(url))
            if url.startswith('http'):
                sources.append(
                    {'source': 'movcloud', 'quality': quality, 'language': 'en', 'info': info, 'url': url, 'direct': False,
                     'debridonly': False})
        return sources
    except:
        log_utils.error('movcloud: %s' % link)
        return []


def vidcloud9(link, hostDict):
    sources = []
    try:
        # print("link:%s" % link)
        if not link.endswith('.m3u8'):
            url = client.request(link, headers={'User-Agent': client.agent(), 'Referer': link})
            resp = ensure_str(url, errors='replace')
            # print("resp:%s" % resp)
            url = re.compile('data-video="(.+?)">.+?</li>').findall(resp)
            for url in url:
                if url.startswith('//'):
                    url = 'https:' + url
                if 'vidnext.net' in url:
                    if '&typesub' in url:
                        url = client.request(link, headers={'User-Agent': client.agent(), 'Referer': link})
                        resp = ensure_str(url, errors='ignore')
                        url = re.findall("file: '(.+?)'", resp)[0]
                        # if control.setting('dev') == 'true':
                        #     log_utils.log('---VIDCLOUD9_VIDNEXT_HLS Testing - Exception: \n' + str(url))
                        if url.startswith('http'):
                            sources.append(
                                {'source': 'HLS', 'quality': 'SD', 'language': 'en', 'info': '', 'url': url,
                                 'direct': False, 'debridonly': False})
                    else:
                        url = client.request(url, headers={'User-Agent': client.agent(), 'Referer': link})
                        resp = ensure_str(url, errors='ignore')
                        url = re.findall('data-video="(.+?)">', resp)
                        for url in url:
                            if url.startswith('//'):
                                url = 'https:' + url
                            if 'vidnext.net' in url:
                                url = client.request(url, headers={'User-Agent': client.agent(), 'Referer': url})
                                resp = ensure_str(url, errors='ignore')
                                r = re.findall('(ep.+?.m3u8)', resp)
                                for r in r:
                                    url = url.split('ep')[0]
                                    url = url + r
                                    if '.720.m3u8' in url:
                                        quality = '720p'
                                    else:
                                        quality = 'SD'
                                    # if control.setting('dev') == 'true':
                                    #     log_utils.log('---VIDCLOUD9_VIDNEXT_HLS3X Testing - Exception: \n' + str(url))
                                    if url.startswith('http'):
                                        sources.append(
                                            {'source': 'HLS3X', 'quality': quality, 'language': 'en', 'info': '', 'url': url,
                                             'direct': False, 'debridonly': False})
                            else:
                                valid, host = source_utils.is_host_valid(url, hostDict)
                                if valid:
                                    # if control.setting('dev') == 'true':
                                    #     log_utils.log('---VIDCLOUD9_VIDNEXT Testing - Exception: \n' + str(url))
                                    quality, info = source_utils.get_release_quality(url, url)
                                    if url.startswith('http'):
                                        sources.append(
                                            {'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': url,
                                             'direct': False, 'debridonly': False})

                elif 'movcloud' in url:
                    url = url.replace('https://movcloud.net/embed/', 'https://api.movcloud.net/stream/')
                    url = client.request(url, headers={'User-Agent': client.agent(), 'Referer': 'https://movcloud.net'})
                    url = json.loads(url)
                    url = url['data']
                    url = url['sources']
                    for url in url:
                        label = url['label']
                        url = url['file']
                        # if control.setting('dev') == 'true':
                        #     log_utils.log('---MOVCLOUD Testing - Exception: \n' + str(url))
                        quality, info = source_utils.get_release_quality(label, label)
                        if url.startswith('http'):
                            sources.append(
                                {'source': 'movcloud', 'quality': quality, 'language': 'en', 'info': info, 'url': url,
                                 'direct': False, 'debridonly': False})
                else:
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    # if control.setting('dev') == 'true':
                    #     log_utils.log('---VIDCLOUD9_1 Testing - Exception: \n' + str(url))
                    if valid:
                        quality, info = source_utils.get_release_quality(url, url)
                        if url.startswith('http'):
                            sources.append(
                                {'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': url,
                                 'direct': False, 'debridonly': False})
        # else:
        #     valid, host = source_utils.is_host_valid(link, hostDict)
        #     sources.append({'source': host, 'quality': '720p', 'language': 'en', 'info': '', 'url': link, 'direct': True, 'debridonly': False})
        return sources
    except:
        log_utils.error('vidcloud9: %s' % link)
        return []


def vidcloud_pro(link, hostDict):
    sources = []
    try:
        url = client.request(link, headers={'User-Agent': client.agent(), 'Referer': link})
        resp = ensure_str(url, errors='ignore')
        url = re.findall(r'sources = \[{"file":"(.+?)","type"', resp)[0]
        url = url.replace('\\', '')
        valid, host = source_utils.is_host_valid(link, hostDict)
        if valid:
            # if control.setting('dev') == 'true':
            #     log_utils.log('---VIDCLOUD_PRO Testing - Exception: \n' + str(url))
            quality, info = source_utils.get_release_quality(url, url)
            if url.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': url,
                     'direct': False, 'debridonly': False})
        return sources
    except:
        log_utils.error('vidcloud_pro: %s' % link)
        return []


def vidsrc(link, hostDict):
    sources = []
    try:
        # r = cfscraper.get(link, headers={'User-Agent': client.agent(), 'Referer': 'https://v2.vidsrc.me'}).content
        # r = ensure_text(r, errors='replace')
        r = client.scrapePage(link).text
        r = re.findall('data-hash="(.+?)"', r)[0]
        r = 'https://v2.vidsrc.me/src/%s' % r
        # r2 = cfscraper.get(r, headers={'User-Agent': client.agent(), 'Referer': 'https://v2.vidsrc.me'}).content
        # r2 = ensure_text(r2, errors='replace')
        r2 = client.scrapePage(link).text
        links = re.findall("'player' src='(.+?)'", r2)
        links = [link + '|Referer=https://vidsrc.me' for link in links]
        for url in links:
            url = url if url.startswith('http') else 'https:{0}'.format(url)
            sources.append({'source': 'CDN', 'quality': '720p', 'language': 'en', 'info': '', 'url': url, 'direct': True, 'debridonly': False})
        return sources
    except:
        log_utils.error('vidsrc: %s' % link)
        return []


def vidsrc_me(link, hostDict):
    sources = []
    try:
        r = client.request(link, headers={'User-Agent': client.agent(), 'Referer': 'https://v2.vidsrc.me'})
        resp = ensure_str(r, errors='ignore')
        r = re.findall('data-hash="(.+?)"', resp)[0]
        r = 'https://v2.vidsrc.me/src/%s' % r
        url = client.request(r, headers={'User-Agent': client.agent(), 'Referer': 'https://v2.vidsrc.me'})
        resp = ensure_str(url, errors='ignore')
        url = re.findall("'player' src='(.+?)'", resp)[0]
        url = url + '|Referer=https://vidsrc.me'
        # if control.setting('dev') == 'true':
        #     log_utils.log('---VIDSRC_ME Testing - Exception: \n' + str(url))
        quality, info = source_utils.get_release_quality(url, url)
        if url.startswith('http'):
            sources.append(
                {'source': 'CDN', 'quality': quality, 'language': 'en', 'info': info, 'url': url, 'direct': True,
                 'debridonly': False})
        return sources
    except:
        log_utils.error('vidsrc_me: %s' % link)
        return []


def vidnext_net(link, hostDict):
    sources = []
    try:
        if 'vidnext.net' in link:
            if '&typesub' in link:
                url = client.request(link, headers={'User-Agent': client.agent(), 'Referer': link})
                resp = ensure_str(url, errors='ignore')
                url = re.findall("file: '(.+?)'", resp)[0]
                # if control.setting('dev') == 'true':
                #     log_utils.log('---VIDNEXT_HLS Testing - Exception: \n' + str(url))
                if url.startswith('http'):
                    sources.append(
                        {'source': 'HLS', 'quality': 'SD', 'language': 'en', 'info': '', 'url': url,
                         'direct': False, 'debridonly': False})
            else:
                url = client.request(link, headers={'User-Agent': client.agent(), 'Referer': link})
                resp = ensure_str(url, errors='ignore')
                url = re.findall('data-video="(.+?)">', resp)
                for url in url:
                    if url.startswith('//'):
                        url = 'https:' + url
                    if 'vidnext.net' in url:
                        url = client.request(url, headers={'User-Agent': client.agent(), 'Referer': url})
                        resp = ensure_str(url, errors='ignore')
                        r = re.findall('(ep.+?.m3u8)', resp)
                        for r in r:
                            url = url.split('ep')[0]
                            url = url + r
                            if '.720.m3u8' in url:
                                quality = '720p'
                            else:
                                quality = 'SD'
                            # if control.setting('dev') == 'true':
                            #     log_utils.log('---VIDNEXT_HLS3X Testing - Exception: \n' + str(url))
                            if url.startswith('http'):
                                sources.append(
                                    {'source': 'HLS3X', 'quality': quality, 'language': 'en', 'info': '', 'url': url, 'direct': False,
                                     'debridonly': False})

        else:
            valid, host = source_utils.is_host_valid(link, hostDict)
            if valid:
                # if control.setting('dev') == 'true':
                #     log_utils.log('---VIDNEXT_1 Testing - Exception: \n' + str(link))
                quality, info = source_utils.get_release_quality(link, link)
                if link.startswith('http'):
                    sources.append(
                        {'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': link, 'direct': False,
                         'debridonly': False})

        return sources
    except:
        log_utils.error('vidnext_net: %s' % link)
        return []


def hls3x(link, hostDict):
    sources = []
    try:
        url = client.request(link, headers={'User-Agent': client.agent(), 'Referer': link})
        resp = ensure_str(url, errors='ignore')
        r = re.findall('(ep.+?.m3u8)', resp)
        for r in r:
            url = url.split('ep')[0]
            url = url + r
            if '.720.m3u8' in url:
                quality = '720p'
            else:
                quality = 'SD'
            info = source_utils.get_release_quality(url)
            # if control.setting('dev') == 'true':
            #     log_utils.log('---HLS3X Testing - Exception: \n' + str(url))
            if url.startswith('http'):
                sources.append(
                    {'source': 'HLS3X', 'quality': quality, 'language': 'en', 'info': info, 'url': url, 'direct': False,
                     'debridonly': False})
        return sources
    except:
        log_utils.error('hls3x: %s' % link)
        return []


def vidoo(link, hostDict):
    sources = []
    try:
        url = client.request(link, headers={'User-Agent': client.agent(), 'Referer': link})
        resp = ensure_str(url, errors='ignore')
        r = re.findall(r'file:"(.+?)"\},\{file:".+?",label:"(.+?)"', resp)
        for r in r:
            quality, info = source_utils.get_release_quality(r[1], r[0])
            r = client.request(r[0], headers={'User-Agent': client.agent(), 'Referer': link})
            resp = ensure_str(r, errors='ignore')
            r = re.findall('(https://.+?m3u8)', resp)[0]
            # if control.setting('dev') == 'true':
            #     log_utils.log('---VIDOO Testing - Exception: \n' + str(r))
            if r.startswith('http'):
                sources.append(
                    {'source': 'VIDOO', 'quality': quality, 'language': 'en', 'info': info, 'url': r, 'direct': False,
                     'debridonly': False})
        return sources
    except:
        log_utils.error('vidoo: %s' % link)
        return []


def mediashore(link, hostDict):
    sources = []
    try:
        try:
            url = client.request(link, headers={'User-Agent': client.agent(), 'Referer': link})
            resp = ensure_str(url, errors='ignore')
            r = re.findall('<title>(.+?)</title>', resp)[0]
            valid, host = source_utils.is_host_valid(link, hostDict)
            quality, info = source_utils.get_release_quality(r, r)
            # if control.setting('dev') == 'true':
            #     log_utils.log('---MEDIASHORE Testing - Exception: \n' + str(r))
            if r.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': r, 'direct': False,
                     'debridonly': False})
        except:
            valid, host = source_utils.is_host_valid(link, hostDict)
            quality, info = source_utils.get_release_quality(link, link)
            # if control.setting('dev') == 'true':
            #     log_utils.log('---MEDIASHORE Testing - Exception: \n' + str(link))
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': link, 'direct': False,
                     'debridonly': False})
        return sources
    except:
        log_utils.error('mediashore: %s' % link)
        return []


def abcvideo(link, hostDict):
    sources = []
    try:
        try:
            if 'html' in link:
                url = client.request(link, headers={'User-Agent': client.agent(), 'Referer': link})
                resp = ensure_str(url, errors='ignore')
                r = re.findall('jwplayer.qualityLabel\', \'(.+?)\'', resp)[0]
                valid, host = source_utils.is_host_valid(link, hostDict)
                quality, info = source_utils.get_release_quality(r, r)
                # if control.setting('dev') == 'true':
                #     log_utils.log('---ABCVIDEO Testing - Exception: \n' + str(r))
                if r.startswith('http'):
                    sources.append(
                        {'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': r, 'direct': False,
                         'debridonly': False})
            else:
                url = client.request(link, headers={'User-Agent': client.agent(), 'Referer': link})
                resp = ensure_str(url, errors='ignore')
                r = re.findall('<title>(.+?)</title>', resp)[0]
                valid, host = source_utils.is_host_valid(link, hostDict)
                quality, info = source_utils.get_release_quality(r, r)
                # if control.setting('dev') == 'true':
                #     log_utils.log('---ABCVIDEO Testing - Exception: \n' + str(r))
                if r.startswith('http'):
                    sources.append(
                        {'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': r, 'direct': False,
                         'debridonly': False})
        except:
            valid, host = source_utils.is_host_valid(link, hostDict)
            quality, info = source_utils.get_release_quality(link, link)
            # if control.setting('dev') == 'true':
            #     log_utils.log('---ABCVIDEO Testing - Exception: \n' + str(link))
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': link, 'direct': False,
                     'debridonly': False})
        return sources
    except:
        log_utils.error('abcvideo: %s' % link)
        return []


def cloudvideo(link, hostDict):
    sources = []
    try:
        try:
            url = client.request(link, headers={'User-Agent': client.agent(), 'Referer': link})
            resp = ensure_str(url, errors='ignore')
            r = re.findall('<title>(.+?)</title>', resp)[0]
            valid, host = source_utils.is_host_valid(link, hostDict)
            quality, info = source_utils.get_release_quality(r, r)
            # if control.setting('dev') == 'true':
            #     log_utils.log('---CLOUDVIDEO Testing - Exception: \n' + str(r))
            if r.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': r, 'direct': False,
                     'debridonly': False})
        except:
            valid, host = source_utils.is_host_valid(link, hostDict)
            quality, info = source_utils.get_release_quality(link, link)
            # if control.setting('dev') == 'true':
            #     log_utils.log('---CLOUDVIDEO Testing - Exception: \n' + str(link))
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': link, 'direct': False,
                     'debridonly': False})
        return sources
    except:
        log_utils.error('cloudvideo: %s' % link)
        return []


def mixdrop(link, hostDict):
    sources = []
    try:
        try:
            url = client.request(link, headers={'User-Agent': client.agent(), 'Referer': link})
            resp = ensure_str(url, errors='ignore')
            r = re.findall('target="_blank">(.+?)</a>', resp)[0]
            valid, host = source_utils.is_host_valid(link, hostDict)
            quality, info = source_utils.get_release_quality(r, r)
            # if control.setting('dev') == 'true':
            #     log_utils.log('---MIXDROP Testing - Exception: \n' + str(r))
            if r.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': r, 'direct': False,
                     'debridonly': False})
        except:
            valid, host = source_utils.is_host_valid(link, hostDict)
            quality, info = source_utils.get_release_quality(link, link)
            # if control.setting('dev') == 'true':
            #     log_utils.log('---MIXDROP Testing - Exception: \n' + str(link))
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': link, 'direct': False,
                     'debridonly': False})
        return sources
    except:
        log_utils.error('mixdrop: %s' % link)
        return []


def upstream(link, hostDict):
    sources = []
    try:
        try:
            url = client.request(link, headers={'User-Agent': client.agent(), 'Referer': link})
            resp = ensure_str(url, errors='ignore')
            r = re.findall('</i>(.+?)</span>', resp)[0]
            valid, host = source_utils.is_host_valid(link, hostDict)
            quality, info = source_utils.get_release_quality(r, r)
            # if control.setting('dev') == 'true':
            #     log_utils.log('---UPSTREAM Testing - Exception: \n' + str(r))
            if r.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': r, 'direct': False,
                     'debridonly': False})
        except:
            valid, host = source_utils.is_host_valid(link, hostDict)
            quality, info = source_utils.get_release_quality(link, link)
            # if control.setting('dev') == 'true':
            #     log_utils.log('---UPSTREAM Testing - Exception: \n' + str(link))
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': link, 'direct': False,
                     'debridonly': False})
        return sources
    except:
        log_utils.error('upstream: %s' % link)
        return []


def vidoza(link, hostDict):
    sources = []
    try:
        try:
            url = client.request(link, headers={'User-Agent': client.agent(), 'Referer': link})
            resp = ensure_str(url, errors='ignore')
            r = re.findall('CONTENT="(.+?)">', resp)[0]
            valid, host = source_utils.is_host_valid(link, hostDict)
            quality, info = source_utils.get_release_quality(r, r)
            # if control.setting('dev') == 'true':
            #     log_utils.log('---VIDOZA Testing - Exception: \n' + str(r))
            if r.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': r, 'direct': False,
                     'debridonly': False})
        except:
            valid, host = source_utils.is_host_valid(link, hostDict)
            quality, info = source_utils.get_release_quality(link, link)
            # if control.setting('dev') == 'true':
            #     log_utils.log('---VIDOZA Testing - Exception: \n' + str(link))
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': link, 'direct': False,
                     'debridonly': False})
        return sources
    except:
        log_utils.error('vidoza: %s' % link)
        return []


def fmovies_to(link, hostDict):
    sources = []
    try:
        r = client.r_request(link).text
        # links = re.findall(r'''(?:src|file)[:=]\s*['"]([^"']+)''', r)
        # links = client.parseDOM(r, 'ul', ret='data-video')
        # links = client.parseDOM(r, 'ul', attrs={'class': r'list-server-items.*?'})
        links = client.parseDOM(r, 'iframe', ret='src')
        # log_utils.log("fmovies_to links: {}".format(links))
        for url in links:
            # url = "%s|%s" % (url, source_utils.append_headers(self.headers))
            sources.append({'source': 'fmovies', 'quality': '720p', 'language': 'en', 'info': '', 'url': url, 'direct': True, 'debridonly': False})
        return sources
    except:
        log_utils.error('fmovies_to: %s' % link)
        return []


def gamovideo(link, hostDict):
    sources = []
    try:
        try:
            # url = client.request(link, headers={'User-Agent': client.agent(), 'Referer': link})
            url = client.r_request(link, headers={'User-Agent': client.agent(), 'Referer': link}).text
            # url = read_write_file(file_n='gomostream.com.html')
            r = re.findall('<Title>(.+?)</Title>', url)
            # print(f'r: {r}')
            valid, host = source_utils.is_host_valid(link, hostDict)
            quality, info = source_utils.get_release_quality(r[0], r[0])
            # if control.setting('dev') == 'true':
            #     log_utils.log('---GAMOVIDEO Testing - Exception: \n' + str(r))
            if r[0].startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': r, 'direct': False,
                     'debridonly': False})
        except:
            valid, host = source_utils.is_host_valid(link, hostDict)
            quality, info = source_utils.get_release_quality(link, link)
            # if control.setting('dev') == 'true':
            #     log_utils.log('---GAMOVIDEO Testing - Exception: \n' + str(link))
            if link.startswith('http'):
                sources.append(
                    {'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': link, 'direct': False,
                     'debridonly': False})
        return sources
    except:
        log_utils.error('gamovideo: %s' % link)
        return []


def sgoogle(link, hostDict):
    sources = []
    try:
        # if control.setting('dev') == 'true':
        #     log_utils.log('---GOOGLE_1 Testing - Exception: \n' + str(link))
        if link.startswith('http'):
            sources.append({'source': 'gvideo', 'quality': 'SD', 'language': 'en', 'info': '', 'url': link,
                            'direct': True, 'debridonly': False})
        return sources
    except:
        return []


def more_rapidvideo(link, hostDict, lang, info):
    if "rapidvideo.com" in link:
        sources = []
        try:
            headers = {
                'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3555.0 Safari/537.36"}
            response = requests.get(link, headers=headers).content
            test = re.findall(r"""(https:\/\/www.rapidvideo.com\/e\/.*)">""", response)
            numGroups = len(test)
            for i in range(1, numGroups):
                url = test[i]
                valid, host = source_utils.is_host_valid(url, hostDict)
                q = source_utils.check_url(url)
                sources.append({'source': host, 'quality': q, 'language': lang, 'url': url, 'info': info, 'direct': False, 'debridonly': False})
            return sources
        except:
            return sources
    else:
        return []


def more_cdapl(link, hostDict, lang, info):
    if "cda.pl" in link:
        sources = []
        try:
            headers = {
                'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3555.0 Safari/537.36"}
            response = requests.get(link, headers=headers).content
            test = client.parseDOM(response, 'div', attrs={'class': 'wrapqualitybtn'})
            urls = client.parseDOM(test, 'a', ret='href')
            if urls:
                for url in urls:
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    q = source_utils.check_url(url)
                    direct = re.findall("""file":"(.*)","file_cast""", requests.get(url, headers=headers).content)[
                        0].replace("\\/", "/")
                    sources.append({'source': 'CDA', 'quality': q, 'language': lang, 'url': direct, 'info': info, 'direct': True, 'debridonly': False})
            return sources
        except:
            return sources
    else:
        return []


def more_vidnode(link, hostDict):
    sources = []  # By Shellc0de
    try:
        headers = {'Host': 'vidnode.net', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 'Upgrade-Insecure-Requests': '1', 'Accept-Language': 'en-US,en;q=0.9'}
        response = client.request(link, headers=headers, timeout=5)
        urls = re.findall(r'''\{file:\s*['"]([^'"]+).*?label:\s*['"](\d+\s*P)['"]''', response, re.DOTALL | re.I)
        if urls:
            for url, qual in urls:
                quality, info = source_utils.get_release_quality(qual, url)
                host = url.split('//')[1].replace('www.', '')
                host = host.split('/')[0].lower()  # 'CDN'
                sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': True, 'debridonly': False})
        return sources
    except:
        return sources