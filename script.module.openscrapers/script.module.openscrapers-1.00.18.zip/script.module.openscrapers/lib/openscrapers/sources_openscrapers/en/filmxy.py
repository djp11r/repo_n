# -*- coding: utf-8 -*-

import re

from openscrapers import parse_qs, urljoin, urlencode
from openscrapers.modules import client
from openscrapers.modules import cleantitle
from openscrapers.modules import log_utils
from openscrapers.modules import scrape_source


class source:
    def __init__(self):
        self.priority = 40
        self.language = ['en']
        self.domains = ['filmxy.pw', 'filmxy.me', 'filmxy.one', 'filmxy.tv', 'filmxy.live', 'filmxy.cc']
        self.base_link = 'https://www.filmxy.pw'
        self.search_link = 'https://www.google.com/search?q=%s+%s+site:filmxy.pw'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            log_utils.error(f'{__name__}_ movie: ')
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url is None: return
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = data['title']
            year = data['year']
            search_title = cleantitle.get_plus(title)
            check_title = '%s+(%s)' % (search_title, year)
            search_url = self.search_link % (search_title, year)
            html = client.scrapePage(search_url).text
            results = re.findall('<a href="(.+?)"><h3(.+?)</h3>', html)
            results = [(i[0], i[1]) for i in results if len(i[0]) > 0 and len(i[1]) > 0]
            result = [i[0] for i in results if check_title in cleantitle.get_plus(i[1])][0]
            result_url = re.compile('q=(.+?)&amp', re.DOTALL).findall(result)[0]
            result_html = client.scrapePage(result_url).text
            page_results = client.parseDOM(result_html, 'div', attrs={'class': 'video-section'})[0]
            page_urls = client.parseDOM(page_results, 'a', ret='data-player')
            for url in page_urls:
                url = client.replaceHTMLCodes(url)
                url = client.parseDOM(url, 'iframe', ret='src')[0]
                for source in scrape_source.getMore(url, hostDict):
                    sources.append(source)
            page_links = client.parseDOM(page_results, 'a', attrs={'target': '_blank'}, ret='href')
            for link in page_links:
                if any(i in link for i in ['vip-membership', 'rapidvideo.com', 'rapidvid.to', 'openload.co', 'streamango.com', 'streamcherry.com']):
                    continue
                for source in scrape_source.getMore(link, hostDict):
                    sources.append(source)
            return sources
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        return url


"""


'https://clicknupload.co/0yhz9pasu2t4'
'https://clicknupload.co/i0jcumammn6j'
'https://dood.watch/d/1a5pwgz6q1kr'
'https://dood.watch/d/kpzyly4k3woi'
'https://dood.watch/e/1a5pwgz6q1kr'
'https://dood.watch/e/kpzyly4k3woi'
'https://mediashore.org/f/q272waee3l1g86x'
'https://mediashore.org/v/q272waee3l1g86x'
'https://mediashore.org/v/q272waee60lg2jw'
'https://mediashore.org/v/w7m74annrelmjpz'
'https://mirrorace.com/m/3EGU6'
'https://mirrorace.com/m/4kEmw'
'https://racaty.net/ls5rwd9s4n5j'
'https://racaty.net/vz6ac6refd38'
'https://uptobox.com/5qyxwjg2co1n'
'https://uptobox.com/ib2j1m9pmag0'
'https://uptobox.com/nzl75sw82u4y'
'https://uptobox.com/v5ljccns4h2q'
'https://uptostream.com/iframe/5qyxwjg2co1n'
'https://uptostream.com/iframe/ib2j1m9pmag0'
'https://uptostream.com/iframe/nzl75sw82u4y'
'https://uptostream.com/iframe/v5ljccns4h2q'
'https://www.filefactory.com/file/2ka9lkx4fuwp'
'https://www.filefactory.com/file/4iehrydrke17'


"""


