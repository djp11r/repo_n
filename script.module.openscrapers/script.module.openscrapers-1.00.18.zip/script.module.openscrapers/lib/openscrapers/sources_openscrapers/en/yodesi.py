# -*- coding: UTF-8 -*-
# import json
import re

# from openscrapers import quote_plus

import requests
# from bs4 import BeautifulSoup, SoupStrainer
from openscrapers.modules import client, log_utils
from openscrapers.modules.hindi_sources import get_source_dict, resolve_gen, host


class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "yodesi"
        self.domains = ['yodesitv.info']
        self.base_link = 'http://www.yodesitv.info'
        self.search_link = 'http://www.yodesitv.info/feed/?s=%s&submit=Search'
        self.info_link = 'http://www.yo-desi.com/player.php?id=%s'
        self.headers = {'User-Agent': client.agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # log_utils.log("From: {} \nimdb {} \ntvdb {}\n tvshowtitle {}, localtvshowtitle {}, aliases {}, year {} ".format(self.name, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))
        try:
            try:
                url = aliases[0]['url']
                # log_utils.log(f'show url: {url}')
                if 'yodesitv' in url: return url
            except: pass #log_utils.error(f'{__name__}_ tvshow: ')
            query = '%s' % tvshowtitle
            # url = query
            # scraper_debug('>>> #### 0AAAA - yodesi EP url : %s' % ( url))
            return query
        except:
            log_utils.error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # scraper_debug("From: {} url {} ... \nimdb {} .. tvdb {}\n title {}, premiered {}, season {}, episode {} ".format(self.name, url, imdb, tvdb, title, premiered, season, episode))
        try:
            # scraper_debug('tvdb: %s title: %s episode: %s season: %s' % (tvdb, title, episode, season))
            if type(tvdb) == int: return
            if 'watch-online' in url: return url
            if '|' in tvdb:
                # scraper_debug("type yodesi tvdb %s" % type(tvdb))
                # tvdb = tvdb.split('|')
                # ch_name = tvdb[0]
                # title = tvdb[1]
                # episode = episode.lower().replace(' ', '-').replace('.', '')
                # nch_name = ch_name.replace("WEB SERIES", "")
                # web_series = ["ALT Balaji", "Hotstar", "Eros Now", "SonyLiv", "Netflix", "Mx Player", "Zee5"]
                # # tvshowtitle = tvshowtitle.lower().replace(' ', '-').replace('.', '-')
                # if nch_name in web_series:
                    # # ch_name = ch_name.lower().replace(' ', '-').replace('.', '-')
                    # query = '%s-watch-online-%s' % (stitle, episode)
                # scraper_debug('after tvdb: %s ch_name: %s stitle: %s episode: %s' % (tvdb, ch_name, title, episode))
                # scraper_debug('title: %s' % title)
                url = url.lower()
                if 'bigg boss' in url:
                    # scraper_debug('C.I.D in stitle', stitle, episode)
                    query = 'bigg-boss-15-%s-watch-online' % title
                elif 'the kapil sharma show' in url:
                    query = 'the-kapil-sharma-show-season-3-%s-watch-online' % title
                elif 'best dancer' in url:
                    query = 'india-best-dancer-2-%s-watch-online' % title
                elif 'episode' in title.lower():
                    query = '%s-watch-online-%s' % (url, title)
                else:
                    # scraper_debug('last using tvdb : %s' % tvdb)
                    query = '%s-%s-watch-online' % (url, title)

                query = query.lower().replace(' ', '-').replace('.', '-').replace("'", '')
                url = '%s/%s/' % (self.base_link, query)
                # scraper_debug('episode url :  %s \nepisode: %s' % (url, episode))
                return url
                # if episode in url:
                    # scraper_debug('>>>> episode url :  %s \nepisode: %s' % (url, episode))
                    # return url
            # else: return
        except:
            log_utils.error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        # scraper_debug("From: {} url: {} ".format(self.name, url))
        try:
            if not url: return sources
            result = requests.get(url, headers=self.headers).text
            if not result:
                return sources
            # mlink = SoupStrainer('div', {'class': 'thecontent'})
            # thecontent = BeautifulSoup(result, 'html.parser', parse_only = mlink)
            # items = thecontent.findAll('p')

            result = client.parseDOM(result, 'div', attrs={'class': 'thecontent'})
            items = client.parseDOM(result, 'p')
            for item in items:
                # scraper_debug(item)
                urls = client.parseDOM(item, 'a', ret='href')
                furls = []
                vidhost = None
                for j in range(0, len(urls)):
                    # scraper_debug('@@@ urls %s\nlen(urls): %s' % (urls[j], len(urls)))
                    try:
                        headers = {'Referer': urls[j]}
                        self.headers.update(headers)
                        result = requests.get(urls[j], headers=self.headers).text
                        if result:
                            links = client.parseDOM(result, 'iframe', ret = 'src')
                            for link in links:
                                if 'vkprime' in link or 'speed' in link or 'watchvideo.us' in link:
                                    vidhost = host(link)
                                    furls.append(link)
                                elif 'flow.' in link:
                                    # vidhost = 'CDN'
                                    furls.append(urls[j])
                    except:
                        pass
                if len(furls) > 0:
                    sources = get_source_dict(furls, sources, vidhost)
            # dumper = dumper
            # scraper_debug('SOURCES \n%s' % json.dumps(self.name, sources, default = dumper, indent = 2))
            return sources
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # scraper_debug('In type of url {} url: {}'.format(type(url), url))
        url = resolve_gen(url)
        return url
