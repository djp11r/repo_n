# -*- coding: utf-8 -*-
"""
    **Created by Tempest**
    **If you see this in a addon other than Tempest and says it was
    created by someone other than Tempest they stole it from me**
"""

import re
import traceback

import requests

try:
    from urlparse import parse_qs, urljoin
    from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, parse_qs, quote_plus, urljoin
from openscrapers.modules import log_utils
from openscrapers.modules import client
from openscrapers.modules import source_utils
from openscrapers.modules import cfscrape


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['a.132movies.online']
        self.base_link = 'https://a.132movies.online'
        self.search_link = '/episodes/watch-video-%s-123movies-gostream'
        self.headers = {'User-Agent': client.agent()}

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url is None:
                return sources

            hostDict = hostprDict + hostDict

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            query = '%s-episode-%d-season-%d' % (data['tvshowtitle'], int(data['episode']), int(data['season']))
            query = re.sub(r'(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            url = self.search_link % quote_plus(query).lower().replace('+', '-').replace('sg-1', 'sg1').replace('--', '-')
            url = urljoin(self.base_link, url)
            print('url: %s' % url)
            headers = {
                'User-Agent': client.agent(),
                'Upgrade-Insecure-Requests': '1',
                'Sec-Fetch-Site': 'same-origin',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-User': '?1',
                'Sec-Fetch-Dest': 'document', }
            cfscraper = cfscrape.create_scraper()
            r = cfscraper.get(url, headers=headers).text
            # print('resp: %s' % r)
            r = re.findall(r'<iframe src="(.+?)" scrolling=no', r)

            for url in r:
                # log_utils.log('---Testing - Exception: \n' + str(url))
                if url.startswith('http'):
                    valid, hoster = source_utils.is_host_valid(url, hostDict)
                    sources.append(
                        {'source': hoster, 'quality': 'SD', 'language': 'en', 'info': '', 'url': url, 'direct': False,
                         'debridonly': False})

            return sources
        except Exception:
            log_utils.log('---FMOVIES.132MOVIES.ONLINE Testing - Exception: \n' + str(traceback.format_exc()))
            return []

    def resolve(self, url):
        try:
            url = client.request(url)
            url = re.findall(r'sources: \[\{file:"*(.+?)"\}\]', url)[0]
            url = url.replace('https://', 'http://')
            return url
        except:
            return url
