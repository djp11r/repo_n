# -*- coding: UTF-8 -*-

import re

from openscrapers.modules import client, log_utils
from openscrapers.modules.hindi_sources import scraper_debug, get_source_dict, urlRewrite, host


class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "bollyfuntv"
        self.domains = ['serialghar.com']
        self.base_link = 'https://serialghar.com/'
        self.headers = {'User-Agent': client.agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # scraper_debug("From: {} \nimdb {} \ntvdb {}\n tvshowtitle {}, localtvshowtitle {}, aliases {}, year {} ".format(self.name, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))
        try:
            query = '%s' % (tvshowtitle)

            url = query
            # scraper_debug('>>> #### 0AAAA - yodesi EP url : %s' % ( url))
            return url
        except:
            log_utils.error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # scraper_debug("From: {} url {} ... \nimdb {} .. tvdb {}\n title {}, premiered {}, season {}, episode {} ".format(self.name, url, imdb, tvdb, title, premiered, season, episode))
        try:
            if type(tvdb) == int: return
            if 'episode' in title.lower(): return
            if '|' in tvdb:
                # scraper_debug("type bollyfuntv tvdb %s" % type(tvdb))
                # tvdb = tvdb.split('|')
                # ch_name = tvdb[0].lower().replace(' ', '-').replace('.', '')
                stitle = url.lower().replace(' ', '-').replace('.', '')
                # url = f'{self.base_link}category/{stitle}/'
                # scraper_debug("url {}".format(url))
                # result = client.r_request(url, headers=self.headers).text
                # if not result: return
                # scraper_debug("result {}".format(result))
                title = title.lower().replace(' ', '-').replace('.', '')
                eurl = f'{self.base_link}/{stitle}-{title}-video-episode/'
                # scraper_debug("eurl {}".format(eurl))
                # items = client.parseDOM(result, 'article', attrs={'class': 'item-list'})
                # items = client.parseDOM(result, 'h2')
                # scraper_debug(f"len(items): {len(items)} items: {items}")
                # for item in items:
                #     url = client.parseDOM(item, 'a', ret='href')[0]
                #     # print('item: %s' % url)
                #     if eurl in url:
                #         # print('if eurl in url item: %s' % url)
                return eurl
            else: return
        except:
            log_utils.error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict, hostprDict):
        # scraper_debug("From: {} \nurl {}".format(self.name, url))
        sources = []
        try:
            if not url: return sources
            # result = client.request(url)
            result = client.r_request(url, headers=self.headers).text
            if not result: return sources
            # read_write_file(read=False, result=result)
            result = client.parseDOM(result, 'div', attrs={'class': 'entry'})
            # log_utils.log(result)
            items = client.parseDOM(result, 'p')
            # log_utils.log(items)
            for item in items:
                # log_utils.log("item: {}".format(item))
                urls = client.parseDOM(item, 'a', ret='href')
                if urls:
                    # log_utils.log("urls: {}".format(urls))
                    furks = []
                    for i in range(0, len(urls)):
                        if any(re.findall(r'vkprime|vkspeed', str(urls[0]), re.IGNORECASE)) and 'vid' in urls[i]:
                            furks.append(urlRewrite(urls[i]))
                    # log_utils.log("furks: {}".format(furks))
                    if furks: sources = get_source_dict(furks, sources)
            # dumper = dumper
            # scraper_debug('SOURCES \n\n%s' % json.dumps(sources, default = dumper, indent = 2))
            return sources
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return sources

    def resolve(self, url):
        # scraper_debug('In type of url {} url: {}'.format(type(url), url))
        # if any(re.findall(r'vkprime|vkspeed', url, re.IGNORECASE)):
        #     if ' , ' in url: iurl = url.split(' , ')
        #     else: iurl = [url]
        #     furl = []
        #     for i in range(0, len(iurl)):
        #         url = urlRewrite(iurl[i])
        #         if url: furl.append(url)
        #     # scraper_debug('bollyfuntv len furl: {} type furl {} furl: {}'.format(len(furl), type(furl), furl))
        #     if len(furl) > 0:
        #         if len(furl) > 2: url = ' , '.join(furl)
        #         else: url = furl[0]
            # scraper_debug('bollyfuntv type of url {} url: {}'.format(type(url), url))
        return url
