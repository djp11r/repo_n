# -*- coding: utf-8 -*-

import re
import requests
from six import ensure_text
from openscrapers import urlparse

from openscrapers.modules import client
from openscrapers.modules import cleantitle
from openscrapers.modules import source_utils
from openscrapers.modules import log_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['movieninja.pro']
        self.base_link = 'https://movieninja.pro'
        self.moviepage_link = '/%s-%s/'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            movieTitle = cleantitle.geturl(title)
            url = self.base_link + self.moviepage_link % (movieTitle, year)
            return url
        except Exception:
            log_utils.log('Testing Exception', 1)
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            hostDict = hostprDict + hostDict
            sources = []
            if url == None:
                return sources
            log_utils.log('Addon Testing starting url: \n' + repr(url))
            html = client.r_request(url)
            links = re.compile('''document\.getElementById\("myFrame"\)\.src = "(.+?)"''', re.DOTALL).findall(html)
            for link in links:
                log_utils.log('Addon Testing sources link: \n' + repr(link))
                link = "https:" + link if not link.startswith('http') else link
                if 'gdriveplayer.live' in link:
                    try:
                        html = client.r_request(link)
                        url = client.parseDOM(html, 'iframe', ret='src')[0]
                        url = "https:" + url if not url.startswith('http') else url
                        log_utils.log('Addon Testing sources url: \n' + repr(url))
                        valid, host = source_utils.is_host_valid(url, hostDict)
                        qual, info = source_utils.get_release_quality(url, url)
                        sources.append({'source': host, 'quality': qual, 'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': False})
                    except:
                        pass
                else:
                    log_utils.log('Addon Testing sources link: \n' + repr(link))
                    valid, host = source_utils.is_host_valid(link, hostDict)
                    qual, info = source_utils.get_release_quality(link, link)
                    sources.append({'source': host, 'quality': qual, 'language': 'en', 'url': link, 'info': info, 'direct': False, 'debridonly': False})
            return sources
        except Exception:
            log_utils.log('Testing Exception', 1)
            return sources


    def resolve(self, url):
        return url


