# -*- coding: utf-8 -*-
"""
    OpenScrapers Module
"""

import json
import re
import time
from base64 import b64decode
from traceback import print_exc
from datetime import datetime
from urllib.parse import quote_plus

from openscrapers import urljoin

from openscrapers.modules import cleandate
from openscrapers.modules import cache
from openscrapers.modules.build_session import build_session
from openscrapers.modules import client_utils
from openscrapers.modules.log_utils import log, error
from openscrapers.modules.utils import make_qrcode
from openscrapers.modules import control
from openscrapers.windows.base import getProgressWindow

BASE_URL = 'https://api.trakt.tv'
V2_API_KEY = control.setting('trakt.client') or '1038ef327e86e7f6d39d80d2eb5479bff66dd8394e813c5e0e387af0f84d89fb' #'e3a8d1c673dfecb7f669b23ecbf77c75fcfd24d3e8c3dbc7f79ed995262fa1db'
CLIENT_SECRET = control.setting('trakt.secret') or '8d27a92e1d17334dae4a0590083a4f26401cb8f721f477a79fd3f218f8534fd1' # '73bee6aeee29cb75db4d8771458a440017f7cfe842e85f457ed9d81f7910b349'
REDIRECT_URI = 'urn:ietf:wg:oauth:2.0:oob'
headers = {'Content-Type': 'application/json', 'trakt-api-key': '', 'trakt-api-version': '2'}
_last_request_time = 0.0
session = build_session(BASE_URL)

def getTraktCredentialsInfo():
    user = control.setting('trakt.user').strip()
    token = control.setting('trakt.token')
    refresh = control.setting('trakt.refresh')
    return user != '' and token != '' and refresh != ''

def trakt_user_active():
    if not getTraktCredentialsInfo(): return False
    try: expires_at = float(control.setting('trakt.expires'))
    except: expires_at = 0.0
    return time.time() > expires_at


def __getTrakt(url, post=None, with_auth=True, retry=0):
    global _last_request_time
    if time.time() - _last_request_time > 300:  # flush stale pooled connections after 5 min idle
        try: session.close()
        except: pass
    url = url if url.startswith(BASE_URL) else urljoin(BASE_URL, url)
    headers = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': V2_API_KEY}
    if not trakt_user_active() and with_auth:
        token = control.setting('trakt.token')
        if token: headers['Authorization'] = f'Bearer {token}'
    # else:
        # token = refresh_token(f'openscraper retry: {retry}')
        # if token and with_auth: headers['Authorization'] = 'Bearer ' + token
        # control.sleep(500)
    # log(f'url: {url}\npost: {post}\nretry: {retry}\nheaders: {headers}')
    for _attempt in range(2):
        try:
            session = build_session(BASE_URL)
            response = session.request(
                'post' if post else 'get',
                url,
                data=json.dumps(post) if post else None,
                headers=headers,
                timeout=20 if post else 11
            )
            _last_request_time = time.time()
            break
            # if not response.ok: response.raise_for_status()
        except Exception as e:
            if _attempt == 0 and not post:  # Only retry GETs; retrying POSTs risks double-submission to /sync/history
                log(f'getTrakt: connection reset, retrying with fresh connection... Error: {e}')
                session.close()
            else:
                raise
    try:
        _code = response.status_code
        if response and _code in (200, 201):
            return response, response.headers
        log(f'retry: {retry} _code: {repr(_code)} repr(response) {repr(response)}')
        try:
            result = response.json() if 'json' in response.headers.get('Content-Type', '') else response.text
            error = result.get('error_description')
            if 'invalid_grant' in result.get('error'):
                if _code == 400 and 'grant is invalid' in error and retry >= 1: revoke()
                return
        except: error = f'Check the log for Unknow error'
        if _code in [423, 500, 502, 503, 504, 520, 521, 522, 524]:
            log(f'Trakt Error: {_code} error: {error}')
            return
        elif _code in {429}:
            log(f'Trakt Rate Limit Reached: {_code} error: {error}')
            headers = response.headers
            if 'Retry-After' in headers:
                control.notification(f'Openscraper Trakt Error:', error)
                control.sleep(1000 * int(headers.get('Retry-After', 1)))
                __getTrakt(url, post, retry=+1)
        elif _code == 401:
            if retry >= 3:
                control.notification(f'Openscraper Trakt Error:', error)
                log(f'error: {error} \nToo many re-auth attempts, stopping to prevent infinite loop error: {repr(error)}')
                if 'Unauthorized for url' in error: revoke()
                return
            if trakt_user_active():
                token = refresh_token(f'openscraper retry: {retry}')
                if token: __getTrakt(url, post, retry=+1)
                else: return
        elif _code in {404}:
            log(f'Trakt Object Not Found: retry: {retry} {_code} error: {error}')
            return
        elif _code not in [405, 403]: return response
    except: log(f'send_query RequestException: \n {repr(print_exc())}')
    # response.encoding = 'utf-8'
    return


def getTraktAsJson(url, post=None, with_auth=True):
    try:
        res_headers = {}
        r = __getTrakt(url, post, with_auth=True)
        if not r: return None
        if isinstance(r, tuple) and len(r) == 2: r, res_headers = r[0], r[1]
        if not r: return None
        r = r.json()
        if 'X-Sort-By' in res_headers and 'X-Sort-How' in res_headers:
            r = sort_list(res_headers.get('X-Sort-By', 'title'), res_headers.get('X-Sort-How', 'asc'), r)
        return r
    except:
        error()
    return


def refresh_token(_info=''):
    refresh_at = cleandate.utc_to_datetime(float(control.setting("trakt.expires")))
    log(f'{_info} trakt.refresh at: {refresh_at}')
    V2_API_KEY, CLIENT_SECRET, refresh = control.setting('trakt.client'), control.setting('trakt.secret'), control.setting('trakt.refresh')
    data = {'client_id': V2_API_KEY, 'client_secret': CLIENT_SECRET, 'redirect_uri': 'urn:ietf:wg:oauth:2.0:oob', 'grant_type': 'refresh_token', 'refresh_token': refresh}
    # log(f'refresh_token data: \n{repr(data)}', 1)
    response = getTraktAsJson('/oauth/token', data, False)
    try:
        # log(f'refresh_token response: \n {repr(response)}', 1)
        token, refresh, expires = response['access_token'], response['refresh_token'], str(int(response['created_at']) + int(response['expires_in']))
        control.setSetting('trakt.token', token)
        control.setSetting('trakt.refresh', refresh)
        control.setSetting('trakt.expires', expires)
        expires_in = cleandate.utc_to_datetime(float(expires))
        control.setSetting('trakt_renual', expires_in)
        log(f'_info: {_info} refresh_token: expires on {repr(expires_in)}')
        # control.sleep(1000)
        return token
    except:
        control.notification(f'Openscraper Trakt Error:')
        # log(f'Error refresh_token {repr(print_exc())}')
        # result = response.json()
        # error = result.get('error')
        # if 'invalid_grant' in error or 'unauthorized_client' in error: revoke()
        return


def get_device_token():
    result = None
    device_codes = getTraktAsJson('/oauth/device/code', {'client_id': V2_API_KEY}, with_auth=False)
    # headers = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': V2_API_KEY}
    data = {'code': device_codes['device_code'], 'client_id': V2_API_KEY, 'client_secret': CLIENT_SECRET}
    start = time.time()
    expires_in = device_codes['expires_in'] + start
    sleep_interval = device_codes['interval']
    user_code = str(device_codes['user_code'])
    token_url = f'https://trakt.tv/activate?code={user_code}'
    progres_msg = f'Please Scan the QR Code[CR][CR] Or open this link in a browser: [B]{token_url}[/B][CR]When prompted enter : [COLOR FF6CB201]{user_code}[/COLOR]'
    qr_code = make_qrcode(token_url, 'trakt') or ''
    progress_d = getProgressWindow('Trakt Account Authorization', qr_code, 1)
    # progress_d.set_controls()
    progress_d.update(0, progres_msg)
    try:
        progress = 0
        while not progress_d.iscanceled() and progress < expires_in:
            response = getTraktAsJson('oauth/device/token', post=data, with_auth=False)
            if response:
                result = response
                break
            progres_ = '%02d:%02d' % divmod(expires_in - time.time(), 60)
            if progres_ == '00:00' or progress_d.iscanceled(): break
            progress_d.update(progress, f'Remaining Time: [B]{progres_}[/B][CR]{progres_msg}')
            control.sleep(max(sleep_interval, 1)*1000)
            progress = max((time.time() - start), 0)
    finally:
        try: progress_d.close()
        except: pass
    return result


def authTrakt():
    try:
        if getTraktCredentialsInfo():
            if control.yesnoDialog('An account already exists.[CR]Do you want to reset?', heading='Trakt'):
                revoke()
            else: return
        r = get_device_token()
        token, refresh = r['access_token'], r['refresh_token']
        control.setSetting('trakt.client', V2_API_KEY)
        control.setSetting('trakt.secret', CLIENT_SECRET)
        control.setSetting('trakt.token', token)
        control.setSetting('trakt.refresh', refresh)
        expires_in = str(time.time() + r['expires_in'])
        control.setSetting('trakt.expires', expires_in)
        expires_in = cleandate.utc_to_datetime(float(expires_in))
        control.setSetting('trakt_renual', expires_in)
        # headers = {'Content-Type': 'application/json', 'trakt-api-key': V2_API_KEY, 'trakt-api-version': 2, 'Authorization': 'Bearer %s' % token}
        # result= requests.get(urljoin(BASE_URL, '/users/me'), headers=headers, timeout=30).json()
        try:
            result, hed = __getTrakt('/users/me')
            user = result.json()['username']
            if user: control.setSetting('trakt.user', user)
        except: error(f'authTrakt: {repr(print_exc())}')
        control.notification(message='Trakt Authorized...')
    except:
        error(f'authTrakt: {repr(print_exc())}')
        control.openSettings(query='2.3')


def revoke(fromsettings=0):
    # control.window.clearProperty('openscrapers_settings')
    data = {"token": control.setting('trakt.token')}
    # control.setSetting('trakt.user', '')
    try:
        __getTrakt('oauth/revoke', post=data)
    except: pass
    control.setSetting('trakt.expires', '0.0')
    control.setSetting('trakt.token', '')
    control.setSetting('trakt.refresh', '')
    control.notification(message='Trakt Authorization Revoked')
    if fromsettings == 1: control.openSettings('3.1')

def account_info_to_dialog():
    from datetime import timedelta
    try:
        account_info = getTraktAsJson("users/settings")
        stats = getTraktAsJson(f'users/{account_info["user"]["ids"]["slug"]}/stats')
        if not account_info or not stats: return control.notification(message='Error to Get Info')
        username = account_info['user']['username']
        timezone = account_info['account']['timezone']
        joined = control.jsondate_to_datetime(account_info['user']['joined_at'], "%Y-%m-%dT%H:%M:%S.%fZ")
        private = account_info['user']['private']
        vip = account_info['user']['vip']
        if vip: vip = f'{str(account_info["user"]["vip_years"])} Years'
        total_given_ratings = stats['ratings']['total']
        movies_collected = stats['movies']['collected']
        movies_watched = stats['movies']['watched']
        movie_minutes = stats['movies']['minutes']
        if movie_minutes == 0: movies_watched_minutes = ['0 days', '0:00:00']
        elif movie_minutes < 1440: movies_watched_minutes = ['0 days', "{:0>8}".format(str(timedelta(minutes=movie_minutes)))]
        else: movies_watched_minutes = ("{:0>8}".format(str(timedelta(minutes=movie_minutes)))).split(', ')
        movies_watched_minutes = '%s %s hours %s minutes' % (movies_watched_minutes[0], movies_watched_minutes[1].split(':')[0], movies_watched_minutes[1].split(':')[1])
        shows_collected = stats['shows']['collected']
        shows_watched = stats['shows']['watched']
        episodes_watched = stats['episodes']['watched']
        episode_minutes = stats['episodes']['minutes']
        if episode_minutes == 0: episodes_watched_minutes = ['0 days', '0:00:00']
        elif episode_minutes < 1440: episodes_watched_minutes = ['0 days', "{:0>8}".format(str(timedelta(minutes=episode_minutes)))]
        else: episodes_watched_minutes = ("{:0>8}".format(str(timedelta(minutes=episode_minutes)))).split(', ')
        episodes_watched_minutes = '%s %s hours %s minutes' % (episodes_watched_minutes[0], episodes_watched_minutes[1].split(':')[0], episodes_watched_minutes[1].split(':')[1])
        items = []
        items += [f'Username: {username}']
        items += [f'Timezone: {timezone}']
        items += [f'Joined: {joined}']
        items += [f'Private: {private}']
        items += [f'VIP Status: {vip}']
        items += [f'Ratings Given: {str(total_given_ratings)}']
        items += [f'Movies: {movies_collected} Collected, {movies_watched} Watched for {movies_watched_minutes}']
        items += [f'Shows: {shows_collected} Collected, {shows_watched} Watched']
        items += [f'Episodes: {episodes_watched} Watched for {episodes_watched_minutes}']
        return control.selectDialog(items, 'Trakt')
    except:
        control.notification(message='Error to Get Info')
        error()
        return


def getTraktIndicatorsInfo():
    indicators = control.setting('indicators') if getTraktCredentialsInfo() == False else control.setting('indicators.alt')
    return True if indicators == '1' else False


def getTraktAddonMovieInfo():
    try: scrobble = control.addon('script.trakt').getSetting('scrobble_movie')
    except: scrobble = ''
    try: ExcludeHTTP = control.addon('script.trakt').getSetting('ExcludeHTTP')
    except: ExcludeHTTP = ''
    try: authorization = control.addon('script.trakt').getSetting('authorization')
    except: authorization = ''
    return scrobble == 'true' and ExcludeHTTP == 'false' and not not authorization


def getTraktAddonEpisodeInfo():
    try: scrobble = control.addon('script.trakt').getSetting('scrobble_episode')
    except: scrobble = ''
    try: ExcludeHTTP = control.addon('script.trakt').getSetting('ExcludeHTTP')
    except: ExcludeHTTP = ''
    try: authorization = control.addon('script.trakt').getSetting('authorization')
    except: authorization = ''
    return scrobble == 'true' and ExcludeHTTP == 'false' and not not authorization


def manager(name, imdb, tmdb, content):
    try:
        post = {"movies": [{"ids": {"imdb": imdb}}]} if content == 'movie' else {"shows": [{"ids": {"tmdb": tmdb}}]}
        items = [('Add to Collection', '/sync/collection')]
        items += [('Remove from Collection', '/sync/collection/remove')]
        items += [('Add to Watchlist', '/sync/watchlist')]
        items += [('Remove from Watchlist', '/sync/watchlist/remove')]
        items += [('Add to new List', '/users/me/lists/%s/items')]
        result = getTraktAsJson('/users/me/lists')
        lists = [(i['name'], i['ids']['slug']) for i in result]
        lists = [lists[i//2] for i in range(len(lists)*2)]
        for i in range(0, len(lists), 2):
            lists[i] = (str(f'Add to {lists[i][0]}'), f'/users/me/lists/{lists[i][1]}/items',)
        for i in range(1, len(lists), 2):
            lists[i] = (str(f'Remove from {lists[i][0]}'), f'/users/me/lists/{lists[i][1]}/items/remove',)
        items += lists
        select = control.selectDialog([i[0] for i in items], 'Trakt Manager')
        if select == -1: return
        elif select == 4:
            t = 'Add to new List'
            k = control.keyboard('', t)
            k.doModal()
            new = k.getText() if k.isConfirmed() else None
            if new is None or new == '': return
            result = __getTrakt('/users/me/lists', post={"name": new, "privacy": "private"})[0]
            try: slug = client_utils.json_loads_as_str(result)['ids']['slug']
            except: return control.notification('Trakt Manager', heading=str(name), sound=True, icon='ERROR')
            result = __getTrakt(items[select][1] % slug, post=post)[0]
        else: result = __getTrakt(items[select][1], post=post)[0]
        icon = control.infoLabel('ListItem.Icon') if result is not None else 'ERROR'
    except:
        return


def slug(name):
    name = name.strip()
    name = name.lower()
    name = re.sub(r'[^a-z0-9_]', '-', name)
    name = re.sub(r'--+', '-', name)
    if name.endswith('-'): name = name.rstrip('-')
    return name


def sort_list(sort_key, sort_direction, list_data):
    reverse = sort_direction != 'asc'
    if sort_key == 'rank': return sorted(list_data, key=lambda x: x['rank'], reverse=reverse)
    elif sort_key == 'added': return sorted(list_data, key=lambda x: x['listed_at'], reverse=reverse)
    elif sort_key == 'title': return sorted(list_data, key=lambda x: x[x['type']].get('title'), reverse=reverse)
    elif sort_key == 'released': return sorted(list_data, key=lambda x: _released_key(x[x['type']]), reverse=reverse)
    elif sort_key == 'runtime': return sorted(list_data, key=lambda x: x[x['type']].get('runtime', 0), reverse=reverse)
    elif sort_key == 'popularity': return sorted(list_data, key=lambda x: x[x['type']].get('votes', 0), reverse=reverse)
    elif sort_key == 'percentage': return sorted(list_data, key=lambda x: x[x['type']].get('rating', 0), reverse=reverse)
    elif sort_key == 'votes': return sorted(list_data, key=lambda x: x[x['type']].get('votes', 0), reverse=reverse)
    else: return list_data

def _released_key(item):
    if 'released' in item: return item['released'] or '0'
    elif 'first_aired' in item: return item['first_aired'] or '0'
    else: return '0'


def getActivity():
    try:
        i = getTraktAsJson('/sync/last_activities')
        activity = [
            i['movies']['collected_at'],
            i['episodes']['collected_at'],
            i['movies']['watchlisted_at'],
            i['shows']['watchlisted_at'],
            i['seasons']['watchlisted_at'],
            i['episodes']['watchlisted_at'],
            i['lists']['updated_at'],
            i['lists']['liked_at'],
        ]
        activity = [int(cleandate.iso_2_utc(i)) for i in activity]
        activity = sorted(activity, key=int)[-1]
        return activity
    except:
        pass


def getWatchedActivity():
    try:
        i = getTraktAsJson('/sync/last_activities')
        activity = [i['movies']['watched_at'], i['episodes']['watched_at']]
        activity = [int(cleandate.iso_2_utc(i)) for i in activity]
        activity = sorted(activity, key=int)[-1]
        return activity
    except:
        pass


def cachesyncMovies(timeout=0):
    return cache.get(syncMovies, timeout, control.setting('trakt.user').strip())


def syncMovies():
    try:
        if not getTraktCredentialsInfo(): return
        indicators = getTraktAsJson('/users/me/watched/movies')
        indicators = [i['movie']['ids'] for i in indicators]
        return [str(i['imdb']) for i in indicators if 'imdb' in i]
    except:
        pass


def timeoutsyncMovies():
    timeout = cache.timeout(syncMovies, control.setting('trakt.user').strip())
    return timeout


def syncTVShows():
    try:
        if not getTraktCredentialsInfo(): return
        indicators = getTraktAsJson('/users/me/watched/shows?extended=full')
        indicators = [(i['show']['ids']['tmdb'], i['show']['aired_episodes'], sum(([(s['number'], e['number']) for e in s['episodes']] for s in i['seasons']), [],),) for i in indicators]
        return [(str(i[0]), int(i[1]), i[2]) for i in indicators]
    except:
        pass


def cachesyncTVShows(timeout=0):
    return cache.get(syncTVShows, timeout, control.setting('trakt.user').strip())


def timeoutsyncTVShows():
    return cache.timeout(syncTVShows, control.setting('trakt.user').strip()) or 0


def syncSeason(imdb):
    try:
        if not getTraktCredentialsInfo(): return
        indicators = getTraktAsJson(f'/shows/{imdb}/progress/watched?specials=false&hidden=false')
        indicators = indicators['seasons']
        indicators = [(i['number'], [x['completed'] for x in i['episodes']]) for i in indicators]
        return ['%01d' % int(i[0]) for i in indicators if False not in i[1]]
    except:
        pass


def syncTraktStatus():
    try:
        cachesyncMovies()
        cachesyncTVShows()
        control.notification(control.lang(32092))
    except:
        control.notification('Trakt sync failed')
        pass


def markMovieAsWatched(imdb):
    if not imdb.startswith('tt'): imdb = f'tt{imdb}'
    return __getTrakt('/sync/history', {"movies": [{"ids": {"imdb": imdb}}]})[0]


def markMovieAsNotWatched(imdb):
    if not imdb.startswith('tt'): imdb = f'tt{imdb}'
    return __getTrakt('/sync/history/remove', {"movies": [{"ids": {"imdb": imdb}}]})[0]


def markTVShowAsWatched(imdb):
    return __getTrakt('/sync/history', {"shows": [{"ids": {"imdb": imdb}}]})[0]


def markTVShowAsNotWatched(imdb):
    return __getTrakt('/sync/history/remove', {"shows": [{"ids": {"imdb": imdb}}]})[0]


def markEpisodeAsWatched(imdb, season, episode):
    season, episode = int('%01d' % int(season)), int('%01d' % int(episode))
    return __getTrakt('/sync/history', {"shows": [{"seasons": [{"episodes": [{"number": episode}], "number": season}], "ids": {"imdb": imdb}}]})[0]


def markEpisodeAsNotWatched(imdb, season, episode):
    season, episode = int('%01d' % int(season)), int('%01d' % int(episode))
    return __getTrakt('/sync/history/remove', {"shows": [{"seasons": [{"episodes": [{"number": episode}], "number": season}], "ids": {"imdb": imdb}}]})[0]


def scrobbleMovie(imdb, watched_percent, action):
    if not imdb.startswith('tt'): imdb = 'tt' + imdb
    return __getTrakt('/scrobble/%s' % action, {"movie": {"ids": {"imdb": imdb}}, "progress": watched_percent})[0]


def scrobbleEpisode(imdb, season, episode, watched_percent, action):
    if not imdb.startswith('tt'): imdb = 'tt' + imdb
    season, episode = int('%01d' % int(season)), int('%01d' % int(episode))
    return __getTrakt('/scrobble/%s' % action, {"show": {"ids": {"imdb": imdb}}, "episode": {"season": season, "number": episode}, "progress": watched_percent})[0]


def getMovieTranslation(id, lang, full=False):
    url = f'/movies/{id}/translations/{lang}'
    try:
        item = getTraktAsJson(url)[0]
        return item if full else item.get('title')
    except:
        pass


def getTVShowTranslation(id, lang, season='', episode='', full=False):
    if season and episode:
        url = f'/shows/{id}/seasons/{season}/episodes/{episode}/translations/{lang}'
    else:
        url = f'/shows/{id}/translations/{lang}'
    try:
        item = getTraktAsJson(url)[0]
        return item if full else item.get('title')
    except:
        pass


def getMovieAliases(id):
    try: return getTraktAsJson(f'/movies/{id}/aliases')
    except: return []


def getTVShowAliases(id):
    try: return getTraktAsJson(f'/shows/{id}/aliases')
    except: return []


def getMovieSummary(id, full=False):
    try:
        url = f'/movies/{id}'
        if full: url += '?extended=full'
        return getTraktAsJson(url)
    except:
        return


def getTVShowSummary(id, full=False):
    try:
        url = f'/shows/{id}'
        if full: url += '?extended=full'
        return getTraktAsJson(url)
    except:
        return


def getPeople(id, content_type, full=False): #Uses imdb_id
    try:
        url = f'/{content_type}/{id}/people'
        if full: url += '?extended=full'
        return getTraktAsJson(url)
    except:
        return


def SearchAll(title, year='', full=True):
    try:
        return SearchMovie(title, year, full) + SearchTVShow(title, year, full)
    except:
        return


def SearchMovie(title, year='', full=True):
    try:
        url = f'/search/movie?query={quote_plus(title)}'
        if year: url += f'&year={year}'
        if full: url += '&extended=full'
        return getTraktAsJson(url)
    except:
        return


def SearchTVShow(title, year='', full=False):
    try:
        url = f'/search/show?query={quote_plus(title)}'
        if year: url += f'&year={year}'
        if full: url += '&extended=full'
        return getTraktAsJson(url)
    except:
        return


def IdLookup(content, type, type_id):
    try:
        r = getTraktAsJson('/search/%s/%s?type=%s' % (type, type_id, content))
        return r[0].get(content, {}).get('ids', [])
    except:
        return {}


def getGenre(content, type, type_id):
    try:
        r = getTraktAsJson(f'/search/{type}/{type_id}?type={content}&extended=full')
        return r[0].get(content, {}).get('genres', [])
    except:
        error()
        return []


def getEpisodeRating(imdb, season, episode):
    try:
        if not imdb.startswith('tt'): imdb = 'tt' + imdb
        url = '/shows/%s/seasons/%s/episodes/%s/ratings' % (imdb, season, episode)
        r = getTraktAsJson(url)
        r1 = r.get('rating', '0')
        r2 = r.get('votes', '0')
        return str(r1), str(r2)
    except:
        return


def getEpisodeSummary(db_id, season, episode='', full=False):
    try:
        if not episode: url = f'/shows/{db_id}/seasons/{season}' #url += '?translations=en'
        else: url = f'/shows/{db_id}/seasons/{season}/episodes/{episode}'
        if full: url += '?extended=full'
        return getTraktAsJson(url)
    except:
        return


#/shows/game-of-thrones/seasons/1/people
#/shows/game-of-thrones/seasons/1/people?extended=guest_stars

#/shows/game-of-thrones/seasons/1/episodes/1/people
#/shows/game-of-thrones/seasons/1/episodes/1/people?extended=guest_stars


def getSeasonsSummary(db_id, full=False, episodes=False):  #Uses imdb_id, full or episodes but not both.
    try:
        url = f'/shows/{db_id}/seasons'
        if full: url += '?extended=full'
        if episodes: url += '?extended=episodes'
        return getTraktAsJson(url)
    except:
        return


def getStudio(db_id, content_type): #Uses imdb_id
    try:
        url = f'/{content_type}/{db_id}/studios'
        return getTraktAsJson(url)
    except:
        return


def SearchEpisode(title, season, episode, full=False):
    try:
        url = f'/search/{title}/seasons/{season}/episodes/{episode}'
        if full: url += '&extended=full'
        return getTraktAsJson(url)
    except:
        return
