# -*- coding: utf-8 -*-
"""
    OpenScrapers Module
"""
from __future__ import annotations
import os
import random
import sys
import time

from datetime import datetime
from json import dumps as jsdumps, loads as jsloads
from sys import argv
from traceback import print_exc
from xml.dom.minidom import parse as mdParse
from typing import List, Dict, Optional
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


def getKodiVersion():
    return int(xbmc.getInfoLabel("System.BuildVersion")[:2])

def addon(_id='script.module.openscrapers'):
    return xbmcaddon.Addon(id=_id)

def addon_info(info):
    return addon().getAddonInfo(info)

def get_property(prop):
	return xbmcgui.Window(10000).getProperty(prop)

def set_property(prop, value):
	return xbmcgui.Window(10000).setProperty(prop, value)

def clear_property(prop):
	return xbmcgui.Window(10000).clearProperty(prop)

monitor = xbmc.Monitor
condVisibility = xbmc.getCondVisibility
infoLabel = xbmc.getInfoLabel
execute = xbmc.executebuiltin
jsonrpc = xbmc.executeJSONRPC
keyboard = xbmc.Keyboard
log = xbmc.log
xbmc_player = xbmc.Player
progress_line = '%s[CR]%s[CR]%s'
deleteDir = xbmcvfs.rmdir
deleteFile = xbmcvfs.delete
existsPath = xbmcvfs.exists
legalFilename = xbmcvfs.makeLegalFilename
listDir = xbmcvfs.listdir
openFile = xbmcvfs.File
makeFile = xbmcvfs.mkdir
makeDirs = xbmcvfs.mkdirs
renameFile = xbmcvfs.rename
translate_path = xbmcvfs.translatePath
joinPath = os.path.join
isfilePath = os.path.isfile
absPath = os.path.abspath

addon_settings = translate_path(joinPath(addon_info('path'), 'resources', 'settings.xml'))
dataPath = translate_path(addon_info('profile'))
cacheFile = joinPath(dataPath, 'cache.db')
undesirablescacheFile = joinPath(dataPath, 'undesirables.db')
user_settings = joinPath(dataPath, 'settings.xml')
temppath = translate_path('special://temp')
userdata = translate_path('special://profile/')
plexSharesFile = ''

FF_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0'
FF_LINUX_USER_AGENT = 'Mozilla/5.0 (X11; Linux x86_64; rv:151.0) Gecko/20100101 Firefox/151.0'
FF_ANDROID_USER_AGENT = 'Mozilla/5.0 (Android 16; Mobile; rv:151.0) Gecko/151.0 Firefox/151.0'
FF_MAC_USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 15.7; rv:150.0) Gecko/20100101 Firefox/150.0'
FF_IOS_USER_AGENT = 'Mozilla/5.0 (iPhone; CPU iPhone OS 26_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) FxiOS/140.2 Mobile/15E148 Safari/605.1.15'
FF_IPAD_USER_AGENT = 'Mozilla/5.0 (iPad; CPU OS 15_7_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) FxiOS/151.0 Mobile/15E148 Safari/605.1.15'
OPERA_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/133.0.0.0'
OPERA_MAC_USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 15_7_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/133.0.0.0'
OPERA_LINUX_USER_AGENT = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/133.0.0.0'
IOS_USER_AGENT = 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1'
IPAD_USER_AGENT = 'Mozilla/5.0 (iPad; CPU OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1'
ANDROID_USER_AGENT = 'Mozilla/5.0 (Linux; Android 15; SN512C Build/AP3A.240905.015.A2; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/147.0.7727.137 Mobile Safari/537.36'
EDGE_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.3967.96'
EDGE_MAC_USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.3967.96'
CHROME_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36'
CHROME_LINUX_USER_AGENT = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36'
CHROME_ANDROID_USER_AGENT = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.216 Mobile Safari/537.36'
CHROME_MAC_USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36'
CHROME_IOS_USER_AGENT = 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/149.0.7827.45 Mobile/15E148 Safari/604.1'
SAFARI_USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15'
ANDROID_KEYS = ['ANDROID_DATA', 'ANDROID_ROOT', 'ANDROID_STORAGE', 'ANDROID_ARGUMENT']


def make_listitem():
	return xbmcgui.ListItem(offscreen=True)

def get_addon_version():
	return addon_info('version')

def setting(id, fallback=None):
	raw = get_property('openscrapers_settings')
	try: settings_dict = jsloads(raw) if raw else make_settings_dict()
	except: settings_dict = {}
	if settings_dict is None: settings_dict = settings_fallback(id)
	if not isinstance(settings_dict, dict):
		# log(f'id: {id} settings_dict: {type(settings_dict)}', 1)#log(f'id: {id} settings_dict: {type(settings_dict)} {repr(settings_dict)}', 1)
		settings_dict = {}
	value = settings_dict.get(id, '')
	if fallback is None: return value
	return value if value != '' else fallback

def settings_fallback(id):
	return {id: addon().getSetting(id)}

def setSetting(id, value):
	return addon().setSetting(id, value)

def set_external_setting(id, value, eaddon='script.module.openscrapers'):
	return addon(eaddon).setSetting(id, value)

def make_settings_dict(): # service runs upon a setting change
	try:
		root = mdParse(user_settings) #minidom instead of element tree
		curSettings = root.getElementsByTagName("setting") #minidom instead of element tree
		settings_dict = {}
		for item in curSettings:
			setting_id = item.getAttribute('id') #minidom instead of element tree
			try: setting_value = item.firstChild.data #minidom instead of element tree
			except: setting_value = None
			if setting_value is None: setting_value = ''
			settings_dict[setting_id] = setting_value
		#log(f'settings_dict = {repr(settings_dict)}', 1)
		set_property('openscrapers_settings', jsdumps(settings_dict))
		return settings_dict
	except:
		log(f'error make_settings_dict: {print_exc()}', 1)
		return None

def refresh_debugReversed(): # called from service "onSettingsChanged" to clear openscrapers.log if setting to reverse has been changed
	if get_property('openscrapers.debug.reversed') != setting('debug.reversed'):
		set_property('openscrapers.debug.reversed', setting('debug.reversed'))
		execute('RunPlugin(plugin://script.module.openscrapers/?action=tools_clearLogFile)')

def lang(language_id):
	return str(addon().getLocalizedString(language_id))

def sleep(time):
	return xbmc.sleep(time)

def isVersionUpdate():
	versionFile = joinPath(dataPath, 'installed.version')
	try:
		if not xbmcvfs.exists(versionFile):
			f = open(versionFile, 'w')
			f.close()
	except:
		log('OpenScrapers Addon Data Path Does not Exist. Creating Folder....', 1)
		addon_folder = translate_path('special://profile/addon_data/script.module.openscrapers')
		if not existsPath(addon_folder): makeDirs(addon_folder)
	try:
		with open(versionFile, 'r') as fh: oldVersion = fh.read()
	except: oldVersion = '0'
	try:
		curVersion = addon_info('version')
		if oldVersion != curVersion:
			with open(versionFile, 'w') as fh: fh.write(curVersion)
			set_default()
			return True
		else: return False
	except Exception as e:
		log(f'{e}', 1)
		return False

def addonId():
	return addon_info('id')

def addonName():
	return addon_info('name')

def addonVersion():
	return addon_info('version')

def addonIcon():
	return addon_info('icon')

def addonPath():
	return translate_path(addon_info('path'))

def addonEnabled(addon_id):
	return condVisibility(f'System.AddonIsEnabled({addon_id})')

def addonInstalled(addon_id):
	return condVisibility(f'System.HasAddon({addon_id})')

def openSettings(query=None, id='script.module.openscrapers'):
	try:
		if 'resolveurl' in id:
			execute('RunPlugin(plugin://script.module.resolveurl/?mode=reset_cache)')
			sleep(100)
			notification(message='resolveurl reset cache', time=2000)
		hide()
		execute(f'Addon.OpenSettings({id})')
		if not query: return
		c = query.split('.')
		execute(f'SetFocus({int(c[0]) - 200:d})')
		execute(f'SetFocus({int(c[1]) - 180:d})')
	except:
		log(f'error: {print_exc()}', 1)
	return

def getProviderDefaults():
	provider_defaults = {}
	try:
		for item in mdParse(addon_settings).getElementsByTagName("setting"): #holy shit look at that.
			setting_id = item.getAttribute('id') #minidom instead of element tree
			if not setting_id.startswith('provider.'): continue
			try: defaulttext = item.getElementsByTagName('default')[0].firstChild.data #minidom instead of element tree
			except: defaulttext = 'false'
			provider_defaults[setting_id] = defaulttext or 'false'
	except: pass
	return provider_defaults

def setProviderDefaults(provider_defaults=None):
	try:
		if provider_defaults is None: provider_defaults = getProviderDefaults()
		for k, v in provider_defaults.items(): setSetting(k, v)
	except: return

def hide():
	execute('Dialog.Close(busydialog)')
	return execute('Dialog.Close(busydialognocancel)')

def notification(title=None, message=None, icon=None, time=3000, sound=False):
	if title == 'default' or title is None: title = addonName()
	if isinstance(title, int): heading = lang(title)
	else: heading = str(title)
	if isinstance(message, int): body = lang(message)
	else: body = str(message)
	if not icon or icon == 'default': icon = addonIcon()
	elif icon == 'INFO': icon = xbmcgui.NOTIFICATION_INFO
	elif icon == 'WARNING': icon = xbmcgui.NOTIFICATION_WARNING
	elif icon == 'ERROR': icon = xbmcgui.NOTIFICATION_ERROR
	return xbmcgui.Dialog().notification(heading, body, icon, time, sound=sound)

def yesnoDialog(line, heading=addon_info('name'), nolabel='', yeslabel=''):
	return xbmcgui.Dialog().yesno(heading, line, nolabel, yeslabel)

def selectDialog(list, heading=addon_info('name')):
	return xbmcgui.Dialog().select(heading, list, useDetails=True)

def multiselectDialog(list, preselect=[], heading=addon_info('name')):
	return xbmcgui.Dialog().multiselect(heading, list, preselect=preselect)

def okDialog(title=None, message=None):
	if title == 'default' or title is None: title = addonName()
	if isinstance(title, int): heading = lang(title)
	else: heading = str(title)
	if isinstance(message, int): body = lang(message)
	else: body = str(message)
	return xbmcgui.Dialog().ok(heading, body)

def progressDialog():
	return xbmcgui.DialogProgress()

def contextmenuDialog(items=None, labels=None):
	if items:
		labels = [i[0] for i in items]
		choice = xbmcgui.Dialog().contextmenu(labels)
		if choice >= 0: return items[choice][1]()
		else: return False
	else: return xbmcgui.Dialog().contextmenu(labels)

def multiselectDialog_(title=None, items=None, preselect=None):
	if title == 'default' or title is None: title = addonName()
	if items:
		labels = [i for i in items]
		if preselect == None:
			return multiselectDialog(labels, heading=title)
		else:
			return multiselectDialog(labels, preselect=preselect, title=title)
	else: return

def inputdialog(title=None, default=''):
	if title == 'default' or title is None: title = addonName()
	return xbmcgui.Dialog().input(heading=title, default=default, type=xbmcgui.INPUT_ALPHANUM)


def getSettingDefault(id):
	import re
	try:
		settings = open(addon_settings, 'r')
		value = ' '.join(settings.readlines())
		value.strip('\n')
		settings.close()
		value = re.findall(fr'id=\"{id}\".*?default=\"(.*?)\"', value)[0]
		return value
	except:
		return None


def check_version_numbers(current, new):
	# Compares version numbers and return True if new version is newer
	current = current.split('.')
	new = new.split('.')
	step = 0
	for i in current:
		if int(new[step]) > int(i):
			return True
		if int(i) == int(new[step]):
			step += 1
			continue
	return False

def set_reuselanguageinvoker():
	# if getKodiVersion() < 18:
		# notification(message=32116)
		# return
	try:
		addon_xml = joinPath(addon_info('path'), 'addon.xml')
		try:
			tree = mdParse(addon_xml)
			reuse = tree.getElementsByTagName("reuselanguageinvoker")[0]
			current_value = reuse.firstChild.data
		except: return log('ReuseLanguageInvokerCheck failed to get settings.xml value', 1)
		#tree = mdParse(addon_xml)
		#root = tree.getroot()
		#for item in root.iter('reuselanguageinvoker'):
		#	current_value = str(item.text)
		if current_value:
			new_value = 'true' if current_value == 'false' else 'false'
			if not yesnoDialog(lang(33018) % (current_value, new_value), '', ''):
				return openSettings()
			if new_value == 'true' and not yesnoDialog(lang(33019), '', ''): return
			# item.text = new_value
			hash_start = gen_file_hash(addon_xml)
			newxml = str(tree.toxml())[22:] #for some reason to xml adds this so we remove it."<?xml version="1.0" ?>"
			with open(addon_xml, "w") as f:
				f.write(newxml)
			hash_end = gen_file_hash(addon_xml)
			if hash_start != hash_end:
				setSetting('reuse.languageinvoker', new_value)
				okDialog(message=f'{lang(33017) % new_value}\n{lang(33020)}')
			else:
				return okDialog(message=33021)
			current_profile = infoLabel('system.profilename')
			execute(f'LoadProfile({current_profile})')
	except Exception as e: log(f'set_reuselanguageinvoker error: {repr(e)}', 1)
	return

def display_string(object):
	try:
		if type(object) is str:
			return deaccentString(object)
	except NameError:
		pass
	if type(object) is int:
		return f'{object}'
	if type(object) is bytes:
		object = ''.join(chr(x) for x in object)
		return object


def deaccentString(text):
	import unicodedata
	try:
		if isinstance(text, bytes):
			text = text.decode('utf-8')
	except UnicodeDecodeError:
		text = f'{text}'
	text = ''.join(c for c in unicodedata.normalize('NFD', text) if unicodedata.category(c) != 'Mn')
	return text

def strip_non_ascii_and_unprintable(text):
	try:
		from string import printable
		result = ''.join(char for char in text if char in printable)
		return result.encode('ascii', errors='ignore').decode('ascii', errors='ignore')
	except Exception as e:
		log(f'strip_non_ascii_and_unprintable error: {repr(e)}', 1)
		return text


def gen_file_hash(file):
	try:
		from hashlib import md5
		md5_hash = md5()
		with open(file, 'rb') as afile:
			buf = afile.read()
			md5_hash.update(buf)
			return md5_hash.hexdigest()
	except Exception as e: log(f'gen_file_hash error: {repr(e)}', 1)


def getModuleName():
	scraper_folders = os.path.join(addon_info('path'), 'lib', 'openscrapers', 'sources_openscrapers', 'en')
	# print(f'scraper_folders : {scraper_folders}')
	nameList = []
	nameListappend = nameList.append
	for file in os.listdir(scraper_folders):
		if file not in ['__pycache__', 'dead', 'undertest', 'hindi', '__init__.py']:
			# print(f's: {file}')
			try: nameListappend(file.split('.')[0].lower())
			except: pass
	return nameList


def platform():
	if condVisibility('system.platform.android'): return 'android'
	elif condVisibility('system.platform.linux'): return 'linux'
	elif condVisibility('system.platform.windows'): return 'windows'
	elif condVisibility('system.platform.osx'): return 'osx'
	elif condVisibility('system.platform.atv2'): return 'atv2'
	elif condVisibility('system.platform.ios'): return 'ios'


def get_useragent(force_platform=False):
    if setting('platform_us') == 'false':
        _USER_AGENTS = [FF_USER_AGENT, OPERA_USER_AGENT, EDGE_USER_AGENT, CHROME_USER_AGENT,
        FF_MAC_USER_AGENT, OPERA_MAC_USER_AGENT, EDGE_MAC_USER_AGENT, CHROME_MAC_USER_AGENT, SAFARI_USER_AGENT,
        FF_LINUX_USER_AGENT, OPERA_LINUX_USER_AGENT, CHROME_LINUX_USER_AGENT,
        FF_ANDROID_USER_AGENT, ANDROID_USER_AGENT, CHROME_ANDROID_USER_AGENT]
        user_agent = random.choice(_USER_AGENTS)
        setSetting('current_ua', user_agent)
        return user_agent

    if force_platform: _platform = setting('platform')
    else: _platform = platform()
    # log(f'_platform: {_platform} os.environ: {os.environ}', 1)
    if _platform == "windows":
        _USER_AGENTS = [FF_USER_AGENT, OPERA_USER_AGENT, EDGE_USER_AGENT, CHROME_USER_AGENT]
    elif _platform == "ios":
        _USER_AGENTS = [FF_MAC_USER_AGENT, OPERA_MAC_USER_AGENT, EDGE_MAC_USER_AGENT, CHROME_MAC_USER_AGENT, SAFARI_USER_AGENT]
    elif _platform == "android" or hasattr(sys, 'getandroidapilevel') or any(key in os.environ for key in android_keys):
        _USER_AGENTS = [FF_ANDROID_USER_AGENT, ANDROID_USER_AGENT, CHROME_ANDROID_USER_AGENT]
    else:
        _USER_AGENTS = [FF_LINUX_USER_AGENT, OPERA_LINUX_USER_AGENT, CHROME_LINUX_USER_AGENT]
    user_agent = random.choice(_USER_AGENTS)
    setSetting('current_ua', user_agent)
    return user_agent

def openBrowser(link):
	myplatform = platform()
	if myplatform == 'android':
		mycommand = 'StartAndroidActivity(,android.intent.action.VIEW,,%s)'
		return xbmc.executebuiltin(mycommand % link)
	else:
		import webbrowser
		return webbrowser.open(link)


def copy2clip(txt):
	platform = sys.platform
	if platform == 'win32':
		try:
			import subprocess
			cmd = 'echo %s|clip' % txt.strip()
			return subprocess.check_call(cmd, shell=True)
		except:
			pass
	elif platform == 'linux':
		try:
			from subprocess import PIPE, Popen
			p = Popen(['xsel', '-pi'], stdin=PIPE)
			p.communicate(input=txt)
		except:
			pass

def get_kodi_certi_file():
	cafile = translate_path('special://xbmc/system/certs/cacert.pem')
	if not cafile:
		import certifi
		cafile = certifi.where()
	return cafile

def supported_video_extensions():
	supported_video_extensions = xbmc.getSupportedMedia('video').split('|')
	unsupported = ['', '.url', '.bin', '.zip', '.rar', '.001', '.disc', '.7z', '.tar.gz', '.tar.bz2', '.tar.xz', '.tgz', '.tbz2', '.gz', '.bz2', '.xz', '.tar']
	return [i for i in supported_video_extensions if i not in unsupported]

def moderator():
	from urllib.parse import urlparse
	netloc = [urlparse(argv[0]).netloc, '', 'plugin.video.metalliq', 'script.extendedinfo', 'plugin.program.super.favourites', 'plugin.video.themoviedb.helper']
	if not infoLabel('Container.PluginName') in netloc: pass
	#sys.exit()

def jsondate_to_datetime(jsondate_object, resformat, remove_time=False):
	if remove_time:
		try: datetime_object = datetime.strptime(jsondate_object, resformat).date()
		except TypeError: datetime_object = datetime(*(time.strptime(jsondate_object, resformat)[:6])).date()
	else:
		try: datetime_object = datetime.strptime(jsondate_object, resformat)
		except TypeError: datetime_object = datetime(*(time.strptime(jsondate_object, resformat)[:6]))
	return datetime_object

def function_monitor(func, query='0.0'):
	func()
	sleep(10)
	openSettings(query)
	while not condVisibility('Window.IsVisible(addonsettings)'):
		sleep(50)
	sleep(10)
	release_active_monitor()

def delete_file(_file):
	try: deleteFile(_file)
	except Exception as e:
		# log(f'delete_file error: {repr(e)}', 1)
		from os import unlink, remove
		try:
			unlink(_file)
			remove(_file)
		except Exception as e: pass#log(f'2 delete_file error: {repr(e)}', 1)


def getlan_choice():
	return [('None', '', ''), ('Afrikaans', 'af', 'afr'), ('Albanian', 'sq', 'alb'), ('Arabic', 'ar', 'ara'), ('Armenian', 'hy', 'arm'), ('Basque', 'eu', 'baq'), ('Bengali', 'bn', 'ben'), ('Bosnian', 'bs', 'bos'), ('Breton', 'br', 'bre'), ('Bulgarian', 'bg', 'bul'), ('Burmese', 'my', 'bur'), ('Catalan', 'ca', 'cat'), ('Chinese', 'zh', 'chi'), ('Croatian', 'hr', 'hrv'), ('Czech', 'cs', 'cze'), ('Danish', 'da', 'dan'), ('Dutch', 'nl', 'dut'), ('English', 'en', 'eng'), ('Esperanto', 'eo', 'epo'), ('Estonian', 'et', 'est'), ('Finnish', 'fi', 'fin'), ('French', 'fr', 'fre'), ('Galician', 'gl', 'glg'), ('Georgian', 'ka', 'geo'), ('German', 'de', 'ger'), ('Greek', 'el', 'ell'), ('Hebrew', 'he', 'heb'), ('Hindi', 'hi', 'hin'), ('Hungarian', 'hu', 'hun'), ('Icelandic', 'is', 'ice'), ('Indonesian', 'id', 'ind'), ('Italian', 'it', 'ita'), ('Japanese', 'ja', 'jpn'), ('Kazakh', 'kk', 'kaz'), ('Khmer', 'km', 'khm'), ('Korean', 'ko', 'kor'), ('Latvian', 'lv', 'lav'), ('Lithuanian', 'lt', 'lit'), ('Luxembourgish', 'lb', 'ltz'), ('Macedonian', 'mk', 'mac'), ('Malay', 'ms', 'may'), ('Malayalam', 'ml', 'mal'), ('Mongolian', 'mn', 'mon'), ('Montenegrin', 'me', 'mne'), ('Norwegian', 'no', 'nor'), ('Occitan', 'oc', 'oci'), ('Persian', 'fa', 'per'), ('Polish', 'pl', 'pol'), ('Portuguese', 'pt', 'por'), ('Portuguese(Brazil)', 'pb', 'pob'), ('Romanian', 'ro', 'rum'), ('Russian', 'ru', 'rus'), ('Sinhalese', 'si', 'sin'), ('Slovak', 'sk', 'slo'), ('Slovenian', 'sl', 'slv'), ('Spanish', 'es', 'spa'), ('Swahili', 'sw', 'swa'), ('Swedish', 'sv', 'swe'), ('Syriac', 'sy', 'syr'), ('Tagalog', 'tl', 'tgl'), ('Tamil', 'ta', 'tam'), ('Telugu', 'te', 'tel'), ('Thai', 'th', 'tha'), ('Turkish', 'tr', 'tur'), ('Ukrainian', 'uk', 'ukr'), ('Urdu', 'ur', 'urd'), ('Vietnamese', 'vi', 'vie')]

def get_sub_settings():
	auto_enable = setting('subtitles.auto_enable', 'true')
	lang = setting('subtitles.lang_primary', 'en')
	audio_preference = setting('audio.preference', 'true')
	secondary_lang = setting('subtitles.lang_secondary', 'hin')
	return {'auto_enable': auto_enable, 'language': lang, 'audio_preference': audio_preference, 'secondary_language': secondary_lang}

def set_inputstream(litem, url, is_type='0'):
	if is_type == '1': # adaptive
		litem.setContentLookup(False)
		adaptive_plugin = translate_path('special://home/addons/inputstream.adaptive')
		if not existsPath(adaptive_plugin): notification(title='Need to install inputstream Addon', message='Error'); return litem
			# try:
				# executebuiltin('InstallAddon(script.module.inputstreamhelper)', True)
				# executebuiltin('InstallAddon(inputstream.adaptive)', True)
			# except: return litem
		litem.setProperty('inputstream', 'inputstream.adaptive')
		litem.setProperty('inputstream.adaptive.max_bandwidth', '100000000000')
		litem.setProperty('http-reconnect', 'true')
		if '.m3u8' in url.lower(): litem.setMimeType('application/vnd.apple.mpegurl') #and inputstreamhelper.Helper('hls').check_inputstream():
		elif '.ism' in url.lower(): litem.setMimeType('application/vnd.ms-sstr+xml')
		elif '.mpd' in url.lower(): litem.setMimeType('application/dash+xml')
		if '|' in url:
			url, strhdr = url.split('|')
			litem.setProperty('inputstream.adaptive.stream_headers', strhdr)
			litem.setProperty('inputstream.adaptive.common_headers', strhdr)
			# litem.setProperty('inputstream.adaptive.manifest_headers', strhdr)
	elif is_type == '2': # ffmpeg
		ffmpeg_plugin = translate_path('special://home/addons/inputstream.ffmpegdirect')
		if not existsPath(ffmpeg_plugin): notification(title='Need to install inputstream Addon', message='Error'); return litem
			# try: executebuiltin('InstallAddon(inputstream.ffmpegdirect)', True)
			# except: return litem
		litem.setProperty('inputstream', 'inputstream.ffmpegdirect')
		litem.setMimeType('application/x-mpegURL')
		litem.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
		litem.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift')
		litem.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
	return litem


def create_dir(file_n):
    from pathlib import Path
    # Create 'my/new/path' and any missing parent folders
    # .parent points to "my/new/folder"
    # mkdir(parents=True) creates "my", "new", and "folder" if they are missing
    Path(file_n).parent.mkdir(parents=True, exist_ok=True)

def read_write_file(file_n='test.html', result=None):
    """
    :useged:
    from openscrapers.modules.hindi_sources import read_write_file
    read_write_file('test_%s.html' % hdlr, result=r)
    :return:
    """
    if file_n.startswith('special://home/userdata'): file_n = translate_path(file_n)
    if not existsPath(file_n):
        create_dir(file_n) # from file to to parent dir
        with open(file_n, 'w', encoding='utf8', errors='ignore') as logf:
            logf.write('')

    if result:
        try:
            if isinstance(result, str): result = result.replace('&nbsp;', '').replace('&#8211;', '').replace('&amp;', '&')
            with open(file_n, mode='w', encoding='utf-8', errors='ignore') as f:
                f.write(str(result))
        except: log(f'Error: in read_write_file: {print_exc()}')
    else:
        try:
            with open(file_n, mode='r', encoding='utf-8', errors='ignore') as f:
                result = f.read()
        except: log(f'Error: in read_write_file: {print_exc()}')
    return result

# Helpers

def parse_xml(xml_path: str) -> ET.Element:
    """Parse xml file path into an ElementTree root."""
    return (ET.parse(xml_path)).getroot()
    # return ET.fromstring(xml_text) # for xml text data


def get_default_value(node: ET.Element) -> Optional[str]:
    """Return the <default> value if present."""
    default = node.find("default")
    return default.text.strip() if default is not None and default.text else None

def set_default() -> None: # set_default
    """Extract defaults for settings whose id starts with 'url.' and apply them."""
    try:
        root = parse_xml(addon_settings)
        # defaults: List[Dict[str, str]] = []

        for setting in root.iter("setting"):
            setting_id = setting.get("id")
            if not setting_id or not setting_id.startswith("url."):
                continue

            default_value = get_default_value(setting)
            if default_value:
                # defaults.append({"id": setting_id, "default": default_value})
                setSetting(setting_id, default_value)
        notification(message='url reset default set', time=2000)
    except Exception as exc:
        log(f"set_default error: {exc} {print_exc()}", 1)


def clean_settings(): # clean_settings
    def _make_content(dict_object):
        content = '<settings version="2">'
        new_line = '\n    '
        for item in dict_object:
            _id = item['id']
            if _id in active_settings:
                if 'default' in item and 'value' in item: content += f'{new_line}<setting id="{_id}" default="{item["default"]}">{item["value"]}</setting>'
                elif 'default' in item: content += f'{new_line}<setting id="{_id}" default="{item["default"]}" />'
                elif 'value' in item: content += f'{new_line}<setting id="{_id}">{item["value"]}</setting>'
                else: content += f'{new_line}<setting id="{_id}" />'
                #content = content.replace('></setting>', ' />')
            # else: removed_settings_append(item)
        content += '\n</settings>'
        return content
    try:
        active_settings, current_user_settings, removed_settings = [], [], []
        active_append, current_append, removed_settings_append = active_settings.append, current_user_settings.append, removed_settings.append
        for i in mdParse(addon_settings).getElementsByTagName('setting'):
            setting_id = i.getAttribute('id')
            if setting_id: active_append(setting_id)
        # log(f'active_settings: {len(active_settings)} {active_settings}', 1)
        for item in mdParse(user_settings).getElementsByTagName('setting'):
            dict_item = {}
            setting_id = item.getAttribute('id')
            if not setting_id in active_settings:
                removed_settings_append(item)
                continue
            setting_default = item.getAttribute('default')
            try: setting_value = item.firstChild.data
            except: setting_value = None
            dict_item['id'] = setting_id
            if setting_value: dict_item['value'] = setting_value
            if setting_default: dict_item['default'] = setting_default
            current_append(dict_item)
        set_property('openscrapers_settings', jsdumps(current_user_settings))
        # log(f'current_user_settings: {len(current_user_settings)} {current_user_settings}', 1)
        new_content = _make_content(current_user_settings)
        if removed_settings:
            with openFile(user_settings, 'w') as f: f.write(new_content)
            sleep(200)
        from openscrapers.modules.cache import cache_clear
        cache_clear()
        notification(message=lang(32036).format(str(len(removed_settings))))
    except Exception as e:
        log(f'error: {e}', 1)
        notification(message=32037)


_PREFERRED_CHOICES = [
    # ('pass', "https://tvpass.org/playlist/m3u"),
    # ('us_pass', "/us_tvpass.m3u"),
    ('us', "/us.m3u"),
    # ('us1', "/us.m3u"),
    ('us_pl', "/us_pluto.m3u"),
    ('us_bi', "/us_tubi.m3u"),
    ('us_moveonjoy', "/us_moveonjoy.m3u"),
    ('us_dis', "/us_distro.m3u"),
    ('india', "/in.m3u"),
    ('sports', "https://raw.githubusercontent.com/iptv/categories/sports.m3u"),
]

_PREFERRED_LABELS = [name for name, _ in _PREFERRED_CHOICES]
_PREFERRED_PRESELECT = list(range(len(_PREFERRED_LABELS)))

def preferred_channels_choice():
    labels = _PREFERRED_LABELS
    preselect = _PREFERRED_PRESELECT
    choice = multiselectDialog(labels, preselect, 'Un Select url source to get playlists')
    # log(f'choice: {repr(choice)}', 1)
    if choice == None: return
    urls = [_PREFERRED_CHOICES[i][1] for i in choice]
    # log(f'urls: {repr(urls)}', 1)
    return urls


def save_preferred_choices(path: str):
    """
    Save choices to disk as JSON.
    Format: [ ["name", "url"], ... ]
    """
    data = list(_PREFERRED_CHOICES)
    tmp = path + ".tmp"

    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

    os.replace(tmp, path)  # atomic write


# --- persistence: load from disk ---

def load_preferred_choices(path: str):
    """
    Load choices from disk and update module-level structures.
    """
    if not os.path.exists(path):
        return False

    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    # Replace in-place for hot-path stability
    _PREFERRED_CHOICES[:] = [tuple(item) for item in data]

    # Rebuild labels + preselect
    _PREFERRED_LABELS[:] = [name for name, _ in _PREFERRED_CHOICES]
    _PREFERRED_PRESELECT[:] = list(range(len(_PREFERRED_LABELS)))

    return True

def edit_url_ui():
    """
    Interactive UI to edit URLs in _PREFERRED_CHOICES.
    Ultra‑micro: minimal allocations, no XML windows.
    """

    # Step 1: choose which entry to edit
    labels = _PREFERRED_LABELS
    idx = selectDialog(labels, "Select entry to edit")
    if idx < 0:
        return False

    name, old_url = _PREFERRED_CHOICES[idx]
    # Step 2: ask for new URL
    new_url = inputdialog(f"Edit URL for '{name}'", old_url)

    if not new_url or new_url == old_url:
        return False

    # Step 3: apply mutation
    _PREFERRED_CHOICES[idx] = (name, new_url)

    # Step 4: rebuild labels + preselect
    _PREFERRED_LABELS[:] = [n for n, _ in _PREFERRED_CHOICES]
    _PREFERRED_PRESELECT[:] = list(range(len(_PREFERRED_LABELS)))

    notification("Updated", f"{name} URL updated")
    return True
