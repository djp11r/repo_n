from __future__ import annotations

import asyncio
import json
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Iterable, List, Literal, Optional, Tuple
from urllib.parse import urlparse, urlunparse
from traceback import print_exc

try:
    from openscrapers.modules.client import request
    from openscrapers.modules.log_utils import log, error
    from openscrapers.modules.control import preferred_channels_choice, read_write_file, notification, set_external_setting
except Exception:  # pragma: no cover
    from modules.client import request
    from modules.log_utils import log, error
    from modules.control import read_write_file, notification, set_external_setting


# 1. Diagnostics

def _now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds") + "Z"


def log_event(event: str, **fields) -> None:
    record = {
        "ts": _now_iso(),
        "event": event,
        **fields,
    }
    try:
        # Keep it lightweight but structured
        log(json.dumps(record, ensure_ascii=False))
    except Exception:
        # Fallback to plain log if JSON/logging fails
        try:
            log(f"{event} | {fields}")
        except Exception:
            pass


# 2. Trie matcher (substring keywords)

class KeywordTrie:
    """
    Substring-based keyword matcher using a simple trie.

    - Build once with a set of lowercase keywords.
    - Call matches(text_lc) to check if any keyword appears as a substring.
    """

    __slots__ = ("root",)

    def __init__(self, keywords: Iterable[str]) -> None:
        root: Dict[str, Dict] = {}
        for word in keywords:
            if not word:
                continue
            node = root
            for ch in word:
                node = node.setdefault(ch, {})
            node["$"] = True
        self.root = root

    def matches(self, text: str) -> bool:
        root = self.root
        n = len(text)
        for i in range(n):
            node = root
            j = i
            while j < n:
                ch = text[j]
                nxt = node.get(ch)
                if nxt is None:
                    break
                node = nxt
                if "$" in node:
                    return True
                j += 1
        return False


# 3. URL utilities

ReachMode = Literal["off", "prefer", "require"]

DOMAIN_TLD_MIN = 2
DOMAIN_TLD_MAX = 63

_reach_cache: Dict[str, bool] = {}
_norm_cache: Dict[str, str] = {}


def is_valid_url(url: str) -> bool:
    try:
        parsed = urlparse(url)
    except Exception:
        return False

    if parsed.scheme not in ("http", "https"):
        return False

    if not parsed.netloc:
        return False

    host = parsed.hostname
    if not host:
        return False

    # Domain-like host
    parts = host.split(".")
    if len(parts) >= 2:
        tld = parts[-1]
        if DOMAIN_TLD_MIN <= len(tld) <= DOMAIN_TLD_MAX and all(p and p.replace("-", "").isalnum() for p in parts):
            return True

    # IPv4
    if len(parts) == 4:
        try:
            if all(p.isdigit() and 0 <= int(p) <= 255 for p in parts):
                return True
        except ValueError:
            return False

    return False


def normalize_url(url: str) -> str:
    cached = _norm_cache.get(url)
    if cached is not None:
        return cached

    p = urlparse(url)

    scheme = p.scheme.lower()
    host = p.hostname.lower() if p.hostname else ""

    port = p.port
    if (scheme == "http" and port == 80) or (scheme == "https" and port == 443):
        netloc = host
    elif port:
        netloc = f"{host}:{port}"
    else:
        netloc = host

    path = p.path or "/"
    if path != "/" and path.endswith("/"):
        path = path.rstrip("/")

    norm = urlunparse((scheme, netloc, path, "", "", ""))
    _norm_cache[url] = norm
    return norm


async def _head_reachable(url: str, timeout: float = 3.0) -> bool:
    """
    Async-friendly reachability check using a thread executor for http.client.
    """
    import http.client

    def _check() -> bool:
        try:
            parsed = urlparse(url)
            conn_cls = http.client.HTTPSConnection if parsed.scheme == "https" else http.client.HTTPConnection
            conn = conn_cls(parsed.netloc, timeout=timeout)
            path = parsed.path or "/"
            conn.request("HEAD", path)
            resp = conn.getresponse()
            return resp.status < 400
        except Exception:
            return False

    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _check)


async def cached_is_reachable(url: str, timeout: float = 3.0) -> bool:
    norm = normalize_url(url)
    if norm in _reach_cache:
        log_event("reach.cached", url=url, normalized=norm, ok=_reach_cache[norm])
        return _reach_cache[norm]

    ok = await _head_reachable(url, timeout=timeout)
    _reach_cache[norm] = ok
    log_event("reach.checked", url=url, normalized=norm, ok=ok)
    return ok


def get_page(url: str) -> Optional[str]:
    if url.startswith("https"):
        return request(url)
    else:
        return read_write_file(url)


# 4. Filters & category detection

NONDESIRABLE = {
    "marathi", "malayalam", "tamil", "urdu", "albania", "exyu", "telugu",
    "kannada", "odisha", "radio", "türk", "east africa", "france",
    "pakistan", "taiwan news", "music", "bhojpuri", "espanol", "novelas", "noticias", "bangla", "latin",
}

DESIRABLE = {
    "bollywood hd", "bollywood classic", "star movies", "india news (1080p)",
    "india news gujarati", "zee news", "zee classic", "zee cinema",
    "star sports 1", "star sports 2", "max movies", "gujarat first",
    "animal planet us", "cinemax", "cnbc usa", "cnn", "comedy central",
    "a&e east", "aaj tak", "b4u movies", "bharat samachar",
    "britbox mysteries", "documentary+", "national geographic", "amc", "fx",
    "discovery channel", "discovery family", "fox business", "fox news",
    "hallmark", "hbo", "history channel", "showtime", "starz", "syfy",
    "weather", "tmc", "tnt", "travel", "turner classic movies",
    "usa network", "24 hour free movies", "fox news channel",
    "livenow from fox", "atlanta's", "tv asia", "fox weather",
}

ATTR_ORDER = ["tvg-id", "tvg-logo", "group-title", "http-referrer", "http-user-agent"]

CATEGORY_MAP = {
    "News": {"fox business", "fox news", "cnbc usa", "cnn", },
    "Movies": {"star movies", "max movies", "cinemax", "hallmark", "hbo", "showtime",
        "tmc", "tnt", "turner classic", "fx movie", "starz", "syfy",
    },
    "Documentary": {"animal planet", "history", "national geographic", "documentary", "discovery"},
    "Weather": {"weather"},
    "Sports": {"star sports"},
    "Indian": {"india news (1080p)", "gujarat first", "aaj tak", "b4u movies", "bharat samachar", "tv asia", "bollywood hd", "bollywood classic", "zee news", "zee classic", "zee cinema", },
}


class UnifiedScanner:
    """using a bitmask in the trie nodes"""
    __slots__ = ("trie", "fail", "output")

    def __init__(self, desirable=None, nondesirable=None):
        # Allow empty initialization for loading from pickle
        if desirable is None and nondesirable is None:
            self.trie = [{}]
            self.output = [0]
            self.fail = [0]
            return

        self.trie = [{}]
        self.output = [0]
        
        # 1. Build the Trie
        for kw, mask in ([(d, 1) for d in desirable] + [(n, 2) for n in nondesirable]):
            node = 0
            for char in kw.lower():
                if char not in self.trie[node]:
                    self.trie.append({})
                    self.output.append(0)
                    self.trie[node][char] = len(self.trie) - 1
                node = self.trie[node][char]
            self.output[node] |= mask

        # 2. Build Failure Links (BFS)
        self.fail = [0] * len(self.trie)
        queue = deque(self.trie[0].values())
        while queue:
            u = queue.popleft()
            for char, v in self.trie[u].items():
                f = self.fail[u]
                while char not in self.trie[f] and f != 0:
                    f = self.fail[f]
                self.fail[v] = self.trie[f].get(char, 0)
                self.output[v] |= self.output[self.fail[v]]
                queue.append(v)

    def is_desirable(self, text: str) -> bool:
        node = 0
        found_desirable = False
        for char in text.lower():
            while char not in self.trie[node] and node != 0:
                node = self.fail[node]
            node = self.trie[node].get(char, 0)
            
            mask = self.output[node]
            if mask & 2: return False  # Nondesirable found
            if mask & 1: found_desirable = True # Desirable found
        return found_desirable


# Initialization for filtered out nondisireble desireble
scanner = UnifiedScanner(DESIRABLE, NONDESIRABLE)
# Usage
# "Filamchi Bhojpuri" -> False (Bhojpuri triggers mask 2)
# "Star Movies" -> True (Triggers mask 1)
# print(scanner.is_desirable("Filamchi Bhojpuri")) 


def detect_group(title_lc: str, group_t: str) -> str:
    for group, keywords in CATEGORY_MAP.items():
        for kw in keywords:
            if kw in title_lc:
                return group
    if group_t:
        return group_t
    return "Live"


# 5. Data structures

@dataclass
class Channel:
    title: str
    url: str
    tvg_id: str = ""
    tvg_logo: str = ""
    group_title: str = ""
    http_referrer: str = ""
    http_user_agent: str = ""
    headers: Dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> Dict:
        return {
            "title": self.title,
            "url": self.url,
            "tvg_id": self.tvg_id,
            "tvg_logo": self.tvg_logo,
            "group_title": self.group_title,
            "http_referrer": self.http_referrer,
            "http_user_agent": self.http_user_agent,
            "headers": dict(self.headers),
        }


Summary = Dict[str, object]


def new_summary() -> Summary:
    return {
        "added": 0,
        "invalid": 0,
        "duplicates": 0,
        "unreachable": 0,
        "skipped_nondesirable": 0,
        "total_input": 0,
        "duplicates_item": [],
    }


# 6. Streaming parser (no regex in hot path)

def _parse_extinf_line(line: str) -> Optional[Tuple[str, str]]:
    """
    Parse a single EXTINF line of the form:

        #EXTINF:-1 key="value" key2="value2",Title

    Returns (params_str, title) or None if invalid.
    """
    if not line.startswith("#EXTINF:"):
        return None

    # Strip prefix
    rest = line[len("#EXTINF:"):]
    # Expect duration first, but we don't really need it beyond validation
    # Format: -1 key="value",Title
    # Find first comma that separates params from title
    comma_idx = rest.find(",")
    if comma_idx == -1:
        return None

    params_part = rest[:comma_idx].strip()
    title = rest[comma_idx + 1 :].strip()

    # params_part may start with duration, e.g. "-1 tvg-id="x""
    # Split once on space to drop duration
    if " " in params_part:
        _, params = params_part.split(" ", 1)
    else:
        # Only duration, no params
        params = ""

    return params, title


def _parse_params(params: str) -> Dict[str, str]:
    """
    Parse key="value" pairs from params string.
    No regex: simple state machine.
    """
    result: Dict[str, str] = {}
    i = 0
    n = len(params)

    while i < n:
        # Skip whitespace
        while i < n and params[i].isspace():
            i += 1
        if i >= n:
            break

        # Parse key
        start_key = i
        while i < n and params[i] not in ("=", " ", "\t"):
            i += 1
        key = params[start_key:i]
        key = key.strip()
        if not key:
            # Skip until next space or end
            while i < n and not params[i].isspace():
                i += 1
            continue

        # Skip whitespace before '='
        while i < n and params[i].isspace():
            i += 1
        if i >= n or params[i] != "=":
            # Malformed, skip this token
            while i < n and not params[i].isspace():
                i += 1
            continue
        i += 1  # skip '='

        # Skip whitespace before value
        while i < n and params[i].isspace():
            i += 1
        if i >= n:
            break

        # Expect quoted value
        if params[i] != '"':
            # Malformed, skip token
            while i < n and not params[i].isspace():
                i += 1
            continue
        i += 1  # skip opening quote
        start_val = i
        while i < n and params[i] != '"':
            i += 1
        value = params[start_val:i]
        # Skip closing quote
        if i < n and params[i] == '"':
            i += 1

        result[key] = value

    return result


async def parse_playlist(text: str, *, validate: bool = True, check_reach: bool = False,) -> Tuple[List[Dict], Summary]:
    """
    Async-first playlist parser.

    Returns (channels, summary) where channels is a list of dicts.
    """
    # log_event("parse.start")

    if isinstance(text, bytes):
        text = text.decode("utf-8", errors="ignore")

    summary: Summary = new_summary()
    channels: List[Channel] = []
    seen: set[str] = set()

    # State
    current: Optional[Channel] = None
    pending_headers: Dict[str, str] = {}

    # Pre-lowercase text for faster matching
    lines = text.split("\n")
    summary["total_input"] = len(lines)

    for raw_line in lines:
        line = raw_line.strip()
        if not line:
            continue

        # VLC options before EXTINF
        if line.startswith("#EXTVLCOPT:"):
            try:
                opt = line[len("#EXTVLCOPT:") :]
                key, value = opt.split("=", 1)
                key = key.strip().lower()
                value = value.strip()
                if key == "http-referrer":
                    pending_headers["Referer"] = value
                elif key == "http-user-agent":
                    pending_headers["User-Agent"] = value
            except ValueError:
                pass
            continue

        # EXTINF line
        if line.startswith("#EXTINF:"):
            parsed = _parse_extinf_line(line)
            if not parsed:
                continue
            params_str, title = parsed
            title = title.strip()
            title_lc = title.lower()

            # log_event("parse.extinf", title=title)

            # Desirable filter
            if not scanner.is_desirable(title_lc):
                summary["skipped_nondesirable"] = int(summary["skipped_nondesirable"]) + 1
                # log_event("channel.skipped_nondesirable", title=title)
                pending_headers.clear()
                current = None
                continue

            attrs = _parse_params(params_str)
            current = Channel(
                title=title,
                url="",
                tvg_id=attrs.get("tvg-id", ""),
                tvg_logo=attrs.get("tvg-logo", ""),
                group_title=attrs.get("group-title", ""),
                http_referrer=attrs.get("http-referrer", ""),
                http_user_agent=attrs.get("http-user-agent", ""),
                headers={},
            )
            continue

        # URL line (must follow EXTINF)
        if current and not line.startswith("#"):
            url = line.strip()
            # log_event("parse.url", url=url, title=current.title)

            if validate and not is_valid_url(url):
                summary["invalid"] = int(summary["invalid"]) + 1
                log_event("url.invalid_syntax", url=url)
                current = None
                pending_headers.clear()
                continue

            norm = normalize_url(url) if (validate or check_reach) else url

            if norm in seen:
                summary["duplicates"] = int(summary["duplicates"]) + 1
                duplicates_item = summary.get("duplicates_item") or []
                if isinstance(duplicates_item, list):
                    duplicates_item.append(f"{current.title}_{url}")
                summary["duplicates_item"] = duplicates_item
                log_event("channel.duplicate", url=url, normalized=norm)
                current = None
                pending_headers.clear()
                continue

            # Reachability (async)
            if check_reach:
                ok = await cached_is_reachable(url)
                if not ok:
                    summary["unreachable"] = int(summary["unreachable"]) + 1
                    log_event("url.unreachable", url=url)
                    current = None
                    pending_headers.clear()
                    continue
                else:
                    log_event("url.reachable", url=url)

            seen.add(norm)
            current.url = url

            # Attach VLC headers if any were collected
            if pending_headers:
                current.headers = dict(pending_headers)

            channels.append(current)
            summary["added"] = int(summary["added"]) + 1
            # log_event("channel.added", title=current.title, url=current.url)

            current = None
            pending_headers.clear()
            continue

    # Convert to list[dict] for public API
    result = [ch.to_dict() for ch in channels]
    # log_event("parse.done", added=summary["added"])
    return result, summary


def parse_playlist_sync(text: str, *, validate: bool = True, check_reach: bool = False,) -> Tuple[List[Dict], Summary]:
    """
    Sync wrapper for parse_playlist.
    """
    return asyncio.run(parse_playlist(text, validate=validate, check_reach=check_reach))


# 7. Writer

def build_channel_block(ch: Dict) -> str:
    title = (ch.get("title") or "Unknown").replace(",", " ").strip()
    url = (ch.get("url") or "").strip()
    if not url:
        return ""

    title_lc = title.lower()

    raw_attrs = {
        "tvg-id": ch.get("tvg_id") or "",
        "tvg-logo": ch.get("tvg_logo") or "",
        "group-title": detect_group(title_lc, ch.get("group_title") or ""),
        "http-referrer": ch.get("http_referrer") or "",
        "http-user-agent": ch.get("http_user_agent") or "",
    }

    attrs = [
        f'{key}="{value}"'
        for key in ATTR_ORDER
        if (value := raw_attrs.get(key))  # type: ignore[assignment]
    ]

    lines = [f'#EXTINF:-1 {" ".join(attrs)},{title}']

    headers = ch.get("headers") or {}
    if headers:
        ref = headers.get("referer") or headers.get("Referer")
        if ref:
            lines.append(f"#EXTVLCOPT:http-referrer={ref}")
        ua = headers.get("user-agent") or headers.get("User-Agent")
        if ua:
            lines.append(f"#EXTVLCOPT:http-user-agent={ua}")

    lines.append(url)
    return "\n".join(lines)


async def write_playlist(channels: List[Dict]) -> str:
    """
    Async writer: deterministic, canonical M3U output.
    """
    log_event("write.start", count=len(channels))
    # Stable sort by title (case-insensitive)
    sorted_channels = sorted(channels, key=lambda c: (c.get("title") or "").lower())
    blocks = [build_channel_block(ch) for ch in sorted_channels]
    body = "\n".join(b for b in blocks if b)
    text = "#EXTM3U\n" + body + ("\n" if body else "")
    log_event("write.done", count=len(sorted_channels))
    return text


def write_playlist_sync(channels: List[Dict]) -> str:
    return asyncio.run(write_playlist(channels))


# 8. Multi-URL loader (modern replacement for parse_list)

async def load_playlists(urls: List[str], *, validate: bool = True, check_reach: bool = False,) -> Tuple[List[Dict], Summary]:
    """
    Async loader: fetch multiple playlists, parse, and merge.
    """
    log_event("load.start", urls=len(urls))
    merged: List[Dict] = []
    summary: Summary = new_summary()

    for url in urls:
        try:
            if url.startswith('/'): url = f'https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams{url}'
            # log(f"load_playlists.get_page: {url}")
            data = get_page(url)
        except Exception as e:
            log(f"load_playlists.get_page.error: {url} :: {e}")
            continue

        if not data:
            continue

        channels, local_summary = await parse_playlist(
            data,
            validate=validate,
            check_reach=check_reach,
        )

        # Merge summaries
        for key in ("added", "invalid", "duplicates", "unreachable", "skipped_nondesirable", "total_input"):
            summary[key] = int(summary.get(key, 0)) + int(local_summary.get(key, 0))

        # Merge duplicates_item
        dup_global = summary.get("duplicates_item") or []
        dup_local = local_summary.get("duplicates_item") or []
        if isinstance(dup_global, list) and isinstance(dup_local, list):
            dup_global.extend(dup_local)
        summary["duplicates_item"] = dup_global

        merged.extend(channels)

    log_event("load.done", added=summary["added"], total=len(merged))
    return merged, summary


def load_playlists_sync(urls: List[str], *, validate: bool = True, check_reach: bool = False,) -> Tuple[List[Dict], Summary]:
    return asyncio.run(load_playlists(urls, validate=validate, check_reach=check_reach))


# 9. Example integration helper (Kodi-style)

def generate_and_write_playlist_sync():
    """
    new API.
    """
    urls = preferred_channels_choice()
    log(f"nos of urls: {len(urls)}")
    apath = "special://home/userdata/addon_data/pvr.iptvsimple/iptv.m3u.cache_1.m3u"
    try:
        set_external_setting("m3uPathType", "0", "pvr.iptvsimple")
        set_external_setting("m3uPath", apath, "pvr.iptvsimple")
    except Exception:
        log(f"print_exc: {print_exc()}")

    merged, summary = load_playlists_sync(urls, validate=True, check_reach=False)
    msg = f"M3U list created in pvr.iptvsimple Added channels: {len(merged)}"
    if len(merged) >= 50:
        final_text = write_playlist_sync(merged)
        read_write_file(apath, final_text)
    log(f"final_text: {msg}")
    notification(message=msg)
    return
