# -*- coding: utf-8 -*-
import datetime
import json
import random
import re
import traceback


from openscrapers import parse_qs, urlparse, urlencode, quote_plus, testing

from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.utils import byteify
from openscrapers.modules.py_tools import isPY3, ensure_str
from openscrapers.modules.client import r_request, agent
from openscrapers.modules.log_utils import log, error

if isPY3:
    bytes = bytes
    str = unicode = basestring = str


def keep_readable(text):
    text = text.replace('&#8216;', "'")
    text = text.replace('&#8217;', "'")
    text = text.replace('&#8220;', '"')
    text = text.replace('&#8221;', '"')
    text = text.replace('&#8211;', ' ')
    text = text.replace('&#8230;', ' ')
    text = text.replace("&amp;", "&")
    text = text.replace("-", "")
    # text = text.encode('ascii', 'ignore').decode('unicode_escape').strip()
    return text


def getcontent(crawl_response):
    #log(crawl_response.getheaders())
    content = crawl_response.content

    encoding = crawl_response.headers.get("Content-Encoding")
    # response.headers.get('Content-Encoding') == "deflate":
    #charest and content_type
    # message = crawl_response.info()
    content_type = crawl_response.headers.get("Content-Type")
    if content_type != 'text/html':
        pass

    if not encoding:
        pass
    else:
        # Decompress
        try:
            if encoding == 'br':
                import brotli
                content = brotli.decompress(content)

            if encoding == 'gzip':
                import gzip
                content = gzip.decompress(content)
        except Exception as e:
            # log(f"Error: decompress: {e}")
            pass

        #charset
    charset = None
    # charset = message.get_content_charset(None)
    charset = crawl_response.headers.get("charset")

    if not charset:
        charset = crawl_response.headers.get("charset")
        if not charset:
            import chardet
            result = chardet.detect(content)
            charset = result['encoding']
        else:
            charset = charset[0]
    if not charset:  # default set utf-8
        charset = 'utf-8'
    # log(f"charset: {charset}")

    # if charset != 'utf-8':  # convert utf-8
    #     content = content.encode('utf-8', errors = 'ignore').decode("utf-8")
    # else:
    # content = content.decode(charset, errors = 'ignore').encode('utf-8', errors = 'ignore')
    content = content.decode('iso-8859-1')
    # content = content.decode("utf-8")
    content = content.replace('\n', '').replace('\t', '').replace('\r', '')
    # OR
    # content = replace_html_codes(content)
    return content


def scraper_debug(provider):
    msg = f'{provider} - Exception: \n{traceback.print_exc()}'
    # print(msg)
    log(msg, 0)


def dumper(obj):
    try:
        return obj.toJSON()
    except:
        return obj.decode("utf-8")


def getVideoID(url):
    try:
        return re.compile('(id|url|v|si|sin|sim|data-config|file|dm|wat|vid)=(.+?)##').findall(url + '##')[0][1]
    except:
        return


def get_mod_url(url):
    try:
        url_id = getVideoID(url)
        if not url_id:
            return
        if 'flow.php' in url:
            iurl = f'https://flow.business-loans.pw/embed17/{url_id}'
        elif 'flix.php' in url:
            iurl = f'https://flow.business-loans.pw/nflix17/{url_id}'
        elif 'daily' in url:
            iurl = f'https://flow.business-loans.pw/plyr17/{url_id}'
        elif 'tere-sheher-mein' in url:
            iurl = f'https://flow.business-loans.pw/plyr2/{url_id}'
        elif 'ishqbaaz' in url:
            iurl = f'http://flow.bestarticles.me/embed2//{url_id}'
        return iurl
    except:
        return


def urlRewrite(url):
    # "https://vkprime.com/embed-7pws6soif1cn.html"
    # "https://vkspeed.com/embed-nji2heqsr6y4.html"
    url_dics = [{
        'host': 'vkprime.php',
        'url': 'http://vkprime.com/embed-%s.html'}, {
        'host': 'vkspeed.php',
        'url': 'http://vkspeed.com/embed-%s.html'}, {
        'host': 'speed.php',
        'url': 'http://vkspeed.com/embed-%s-600x380.html'}]
    try:
        videoID = getVideoID(url)
        for i in url_dics:
            try:
                if re.compile(i['host']).findall(url)[0]:
                    return i['url'] % videoID
            except:
                pass
        return url
    except:
        return url


def byte_to_str(bytes_or_str):
    if isinstance(bytes_or_str, bytes): # Check if it's in bytes
        bytes_or_str = bytes_or_str.decode('utf-8')
    #     log(bytes_or_str.decode('utf-8'))
    # else:
    #     log("Object not of byte type")
    return bytes_or_str


def host(url):
    try: url = byte_to_str(url)
    except: pass
    host = re.findall(r'([\w]+[.][\w]+)$', urlparse(url.strip().lower()).netloc)[0]
    return str(host.split('.')[0])


def to_utf8(obj):
    try:
        if isinstance(obj, unicode):
            obj = obj.encode('utf-8', 'ignore')
        elif isinstance(obj, dict):
            import copy
            obj = copy.deepcopy(obj)
            for key, val in obj.items():
                obj[key] = to_utf8(val)
        elif obj is not None and hasattr(obj, "__iter__"):
            obj = obj.__class__([to_utf8(x) for x in obj])
        else: pass
    except: pass
    return obj


def stringify_nodes(data):
    if isinstance(data, list): 
        return [stringify_nodes(x) for x in data]
    elif isinstance(data, dict):
        dkeys = list(data.keys())
        for i, k in enumerate(dkeys):
            try:
                dkeys[i] = k.decode()
            except:
                pass
        data = dict(zip(dkeys, list(data.values())))
        return {stringify_nodes(key): stringify_nodes(val) for key, val in data.items()}
    elif isinstance(data, bytes):
        try:
            return data.decode()
        except:
            return data
    else:
        return data


def clean_title(title):
    cleanup = ['Watch', 'Onilne', 'Tamil', 'Dubbed', 'WAtch ', 'Free', 'Full', 'AMZN', 'SCR', 'DvDRip', 'DvDScr', 'Full Movie Online Free', 'Uncensored', 'Full Movie Online', 'Watch Online ', 'Free HD', 'Online Full Movie', 'Downlaod', 'Bluray', 'Full Free', 'Malayalam Movie', ' Malayalam ', 'Full Movies', 'Full Movie', 'Free Online', 'Movie Online',
               'Watch', 'movie', 'Movie ', 'Songs', 'Hindi', 'Korean', 'Web', 'tamil', 'RIP', 'Tamil Movie', ' Hindi', 'Hilarious Comedy Scenes', 'Super Comedy Scenes', 'Ultimate Comedy Scenes', 'Watch...', 'BDRip', 'Super comedy Scenes', 'Comedy Scenes', 'hilarious comedy Scenes', '...', 'Telugu Movie', 'Sun TV Show', 'Vijay TV Show',
               'Gujarati', 'WebDL', 'WEB', 'Film', 'ESUBS', 'Web', '~', 'Sun Tv Show', 'Download', 'Starring', u'\u2013', 'Tamil Full Movie', 'Tamil Horror Movie', 'Tamil Dubbed Movie', '|', '-', ' Full ', u'\u2019', '/', 'Pre HDRip', '(DVDScr Audio)', 'PDVDRip', 'DVDSCR', '(HQ Audio)', 'HQ', ' Telugu', 'BRRip', 'DVDScr', 'DVDscr', 'PreDVDRip', 'DVDRip',
               'DVDRIP', 'WEBRip', 'Rip', ' Punjabi', 'TCRip', 'HDRip', 'HDTVRip', 'HD-TC', 'HDTV', 'TVRip', '720p', 'DVD', 'HD', ' Dubbed', '( )', '720p', '(UNCUT)', 'UNCUT', '(Clear Audio)', 'DTHRip', '(Line Audio)', ' Kannada', ' Hollywood', 'TS', 'CAM', 'Online Full', '[+18]', 'Streaming Free', 'Permalink to ', 'And Download', '()', 'Full English', ' English', 'Online', ' Tamil', ' Bengali',
               ' Bhojpuri', 'Print Free', 'DL']

    for word in cleanup:
        if word in title:
            title = title.replace(word, '')

    title = title.strip()
    # title = title.encode('utf8')
    return title


def keepclean_title(title):
    if title is None: return
    exctract_date = re.compile(r'(\d{1,2}[th|st|nd|rd]* [Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|August|Sep|September|Oct|October|Nov|November|Dec|December]* \d{2,4})')
    episode_data = re.compile(r'[Ee]pisodes.+?(\d+)|[Ee]p (\d+)|[Ee](\d+)|[sS]eason.+?(\d+)|[sS]eason(\d+)|[sS](\d+)')
    # ansi_pattern = re.compile(r"(\x9B|\x1B\[)[0-?]*[ -\/]*[@-~]")
    ansi_pattern = re.compile(r'[^\x00-\x7f]')
    try:
        if ':' in title: title = title.split(':')[0]
        title = re.sub(exctract_date, '', title)  # remove date like 18th April 2021
        title = re.sub(episode_data, '', title)  # remove episod 12 or season 1 etc
        title = re.sub(ansi_pattern, '', title)  # remove ansi_pattern
        title = re.sub(r'&#(\d+);', '', title)
        title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
        title = title.replace('&quot;', '\"').replace('&amp;', '&')
        title = re.sub(r'([:;\-"\',!_.?~$@])', '', title)  # remove all characters in bracket
        title = re.sub(r'\<[^>]*\>|\([^>]*\)', '', title) # remove like this <any thing> or (any thing)
        # title = re.sub(r'\([^>]*\)', '', title)  # remove in bracket like (any thing) etc
        # title = re.sub(r'\n|([[].+?[]])|([(].+?[)])|\s(vs|v[.])\s|(:|;|-|"|,|\'|\_|\.|\?)|\(|\)|\[|\]|\{|\}|\s', '', title).lower()
        # title = re.sub(r'\n|([\[({].+?[})\]])|([:;\-"\',!_.?~$@])|\s', '', title)
        return title.strip()
    except: return title


def safe_string(obj):
    try:
        try:
            return str(obj)
        except UnicodeEncodeError:
            return obj.encode('utf-8', 'ignore').decode('ascii', 'ignore')
        except:
            return ""
    except:
        return obj


def replace_html_codes(txt):
    try:
        from HTMLParser import HTMLParser
        unescape = HTMLParser().unescape
    except ImportError:
        from html.parser import HTMLParser
        from html import unescape
    txt = safe_string(txt)
    txt = byteify(txt)
    txt = re.sub("(&#[0-9]+)([^;^0-9]+)", "\\1;\\2", txt)
    txt = unescape(txt)
    txt = txt.replace("&quot;", "\"")
    txt = txt.replace("&amp;", "&")
    return txt


non_str_list = ['p2p.drivewires', 'tvcine.me', 'business-phone.org/ad', 'tvarticles.org/ad',
                'tvnation.me/include', 'tvarticles.me/ad', 'drivewire.xyz', 'olangal.', 'magnet:',
                'desihome.', 'thiruttuvcd', '.filmlinks4u', 'cineview', 'bollyheaven', 'videolinkz',
                'moviefk.co', 'goo.gl', 'imdb.', 'mgid.', 'atemda.', 'movierulz.ht', 'facebook.',
                'twitter.', 'm2pub', 'abcmalayalam', 'india4movie.co', 'embedupload.',
                '#', 'tamilraja.', 'multiup.', 'filesupload.', 'fileorbs.', 'tamil.ws',
                'insurance-donate.', '.blogspot.', 'yodesi.net', 'desi-tashan.', 'yomasti.co/ads',
                'ads.yodesi', '/ads/', 'mylifeads.', 'yaartv.', 'steepto.', '/movierulztv',
                '/email-protection', 'oneload.xyz', 'tvnation.me/drive.php?']

embed_list = ['cineview', 'bollyheaven', 'videolinkz', 'vidzcode', 'escr.',
              'embedzone', 'embedsr', 'fullmovie-hd', 'links4.pw', 'esr.',
              'embedscr', 'embedrip', 'movembed', 'power4link.us', 'adly.biz',
              'watchmoviesonline4u', 'nobuffer.info', 'yomasti.co', 'hd-rulez.',
              'techking.me', 'onlinemoviesworld.xyz', 'cinebix.com', 'vids.xyz',
              'desihome.', 'loan-', 'filmshowonline.', 'hinditwostop.', 'media.php',
              'hindistoponline', 'telly-news.', 'tellytimes.', 'tellynews.', 'tvcine.',
              'business-', 'businessvoip.', 'toptencar.', 'serialinsurance.',
              'youpdates', 'loanadvisor.', 'tamilray.', 'embedrip.', 'xpressvids.',
              'beststopapne.', 'bestinforoom.', '?trembed=', 'tamilserene.',
              'tvnation.', 'techking.', 'etcscrs.', 'etcsr1.', 'etcrips.', 'etcsrs.',
              'tvpost.cc']


def threadwrap(func, extr_iurl, que):
    """
    :useges:
    from Queue import Queue
    que = Queue()
    furls = hindi_sources.threadwrap(hindi_sources.link_extractor, extr_iurl, que)
    log(f'ilink: {str(que.get())}')
    :param func:
    :param extr_iurl:
    :param que:
    :param furls:

    :return:
    """
    threads = []
    # from Queue import Queue
    import threading
    # que = Queue()
    # log(f'extr_iurl: {extr_iurl}')
    for iurl in extr_iurl:
        # log(f'iurl: {iurl}')
        threads.append(threading.Thread(target=lambda q, arg: q.put(func(iurl)), args=(que, iurl)))
    [i.start() for i in threads]
    [i.join() for i in threads]
    # log(f'threads: {threads}')
    # if str(que.get()) is not None:
    # while not que.empty():
    #     log(f'ilink: {str(que.get())}')
    #     if str(que.get()) is not None:
    #         furls.append(que.get())
    # return furls


def get_source_dict(urls, sources, ihost=None):
    # log(f'urls: {urls}')
    if ihost is None:
        ihost = host(urls[0])
    # log(f'ihost {ihost} len(urls) {len(urls)} type of urls {type(urls)}')
    direct = False
    if ihost in ['clockks']:
        direct = True

    if len(urls) > 1:
        j = 0
        for ji in urls:
            if any(re.findall(r'speed|vkprime', str(ji), re.IGNORECASE)):
                j += 1
                sources.append({
                    'source': ihost,
                    'quality': '720p',
                    'language': 'en',
                    'info': f'Part:{j}',
                    'url': ji,
                    'direct': False,
                    'debridonly': False})

    if len(urls) > 1:
        unfo = f'All parts: {str(len(urls))}'
        url = ' , '.join(urls)
    else:
        unfo = 'All part: Single'
        url = urls[0]
    sources.append({
        'source': ihost,
        'quality': '720p',
        'language': 'en',
        'info': unfo,
        'url': url,
        'direct': direct,
        'debridonly': False})

    return sources


def get_headersfrom_url(url):
    headers = {}
    # print(f'>>>> from _base vid_link:  {url}')
    if '|' in url:
        url, hdrs = url.split('|')
        hitems = hdrs.split('&')
        for hitem in hitems:
            hdr, value = hitem.split('=')
            headers.update({hdr: value})
    return headers


def append_headers(headers):
    return '|%s' % '&'.join(['%s=%s' % (key, quote_plus(headers[key])) for key in headers])


def link_extractor(url, headers=None):
    # log(f'link_extractor url: {repr(url)}')
    try:
        if headers is None:
            headers = {'User-Agent': agent()}#, 'Referer': url, }
        # log(f'headers: {headers}')
        result = r_request(url, headers=headers).text
        # result = cfScraper.get(url, headers=headers).text
        # result = to_utf8(remove_accents(result))
        # result = result.replace('\n', ' ')
        # read_write_file(file_n='test_imdb_.html', read=False, result=result)
        # result = read_write_file()
        redirect_url = meta_redirect(result)
        # log(f'redirect_url: {redirect_url}')
        if redirect_url: result = r_request(redirect_url, headers=headers).text
        # if redirect_url: result = cfScraper.get(redirect_url, headers=headers).text
        # result += get_packed_data(result)
        # log(f'link_extractor result: {result}')
        links = parseDOM(result, 'iframe', ret='src')
        links += re.findall(r'"(?:file|src)":"([^"]+m3u8)', result)
        # log(f'link_extractor total: {len(links)} links: {links}')
        # if not links: return # None, None
        for link in links:
            # log(f'link_extractor link: {link}')
            if 'vkprime' in link or 'speed' in link or 'watchvideo.us' in link:
                vidhost = host(link)
                return vidhost, link
            elif 'flow.' in link:# or 'business-trade' in link:# or not link.endswith('.html'):
                if 'business-trade' in link:
                    headers['Referer'] = 'http://business-trade.me/'
                elif 'business-credits' in link:
                    headers['Referer'] = 'http://business-credits.cc/'
                # log(f'link_extractor flow in  link : {link}')
                vidhost, vidurl = link_extractor2(link, headers)
                return vidhost, vidurl
            elif not any([x in link for x in non_str_list]) and not any([x in link for x in embed_list]):
                vidhost, vidurl = resolve_url(link)
                return vidhost, vidurl
    except Exception as e:
        log(f'Error: in link_extractor: {traceback.print_exc()}')
    return None, None


def link_cfscraper_extractor(url, headers=None):
    # log(f'link_cfscraper_extractor url: {url}')
    if headers is None:
        headers = {'User-Agent': agent(), 'Referer': url}
    data = r_request(url, headers=headers).text
    # log(f'shtml {data}')
    redirect_url = meta_redirect(data)
    # log(f'redirect_url: {redirect_url}')
    data = r_request(redirect_url, headers=headers).text
    # log(f'data: {data}')
    _frame_regex = r'(?:iframe|source).+?(?:src)=(?:\"|\')(.+?)(?:\"|\')'
    links = re.compile(_frame_regex, re.IGNORECASE).findall(data)
    # log(f'data regex links: {links}')

    vidhost = vidurl = None
    for link in links:
        if not link.endswith('.html') and 'index.php?' not in link:
            # log(f'flow.tvlogy: {link}')
            data = r_request(link, headers=headers).text
            vidurl = re.findall(r'"(?:file|src)":"([^"]+m3u8)', data)[0]
            # log(f'vidurl: {vidurl}')
            vhdr = {'Range': 'bytes=0-'}
            headers.update(vhdr)
            vidurl += append_headers(headers)
            # log(f'vidurl: {vidurl}')
            vidhost = 'CDN'
            if vidurl:
                # log(f'vidhost: {vidhost} vidurl: {vidurl}')
                return vidhost, vidurl
    return vidhost, vidurl


def find_match(regex, text, index=0):
    results = re.findall(text, regex, flags=re.DOTALL | re.IGNORECASE)
    return results[index]


def meta_redirect(content):
    redirect_re = re.compile('<meta[^>]*?url=(.*?)["\']', re.IGNORECASE)
    match = redirect_re.search(str(content))
    # log(f'meta_redirect match: {repr(match)}')
    redirect_url = None
    if match:
        redirect_url = match.groups()[0].strip()
        # if redirect_url.startswith('http://tellygossips.net/'):
        #     redirect_url = redirect_url
    return redirect_url


def link_extractor2(url, headers=None):
    # log(f'link_extractor2 url: {url}')
    if headers is None:
        headers = {'User-Agent': agent(), 'Referer': url}
    try:
        shtml = r_request(url, headers=headers).text
    except:
        log(f'link_extractor2 shtml traceback.print_exc(): {traceback.print_exc()}')
        return None, None

    try:
        vidurl = re.findall(r'"(?:file|src)":"([^"]+m3u8)', shtml)[0]#.encode('utf8')
        if 'player/index.php?' not in vidurl:
            vhdr = {'Range': 'bytes=0-'}
            headers.update(vhdr)
            vidurl += append_headers(headers)
            vidhost = 'CDN'
            # log(f"link_extractor2 1 : {vidurl}")
            if vidurl:
                return vidhost, vidurl
    except:
        try:
            links = parseDOM(shtml, 'iframe', ret='src')
            for link in links:
                if 'vkprime' in link or 'speed' in link or 'watchvideo.us' in link:
                    # log(f"link_extractor2 2 : {link}")
                    vidhost = host(link)
                    return vidhost, link
                elif not any([x in link for x in non_str_list]) and not any([x in link for x in embed_list]):
                    vidhost, vidurl = resolve_url(link)
                    return vidhost, vidurl
        except: return None, None
    return None, None


def resolve_url(url):
    try:
        import resolveurl
        if resolveurl.HostedMediaFile(url):
            # log(f'-------> from iframe not from non_str_list & embed_list  link : {url}')
            vidhost = host(url)
            return vidhost, url
        else:
            log(f'Resolveurl cannot resolve : {url}')
    except:
        log(f'resolve_url from iframe not from non_str_list & embed_list  link : {url}')
    return None, None


def resolve_gen(url):
    # scraper_debug(f'In resolve_gen(url) type of url {type(url)} url: {url}')
    if not any(re.findall(r'dailymotion|vup|streamtape|vidoza|mixdrop|mystream|doodstream|watchvideo|vkprime|vkspeed', url, re.IGNORECASE)):
        if ' , ' in url: iurl = url.split(' , ')
        else: iurl = [url]
        # scraper_debug(f'In len of iurl {len(iurl)} iurl: {iurl}')
        furl = []
        for i in range(0, len(iurl)):
            host, url = link_extractor(iurl[i])
            if url: furl.append(url)
        # scraper_debug(f'yodesi len furl: {len(furl)} type furl {type(furl)} furl: {furl}')
        if len(furl) > 0: url = ' , '.join(furl)
        else: url = furl[0]
    if testing: scraper_debug(f'Out resolve_gen(url)type of url {type(url)} url: {url}')
    return url


def scrape_sources(html, result_blacklist=None, scheme='http', patterns=None, generic_patterns=True):
    if patterns is None:
        patterns = []

    def __parse_to_list(_html, regex):
        _blacklist = ['.jpg', '.jpeg', '.gif', '.png', '.js', '.css', '.htm', '.html', '.php', '.srt', '.sub', '.xml', '.swf', '.vtt', '.mpd']
        _blacklist = set(_blacklist + result_blacklist)
        streams = []
        labels = []
        for r in re.finditer(regex, _html, re.DOTALL):
            match = r.groupdict()
            stream_url = match['url'].replace('&amp;', '&')
            file_name = urlparse(stream_url[:-1]).path.split('/')[-1] if stream_url.endswith("/") else urlparse(stream_url).path.split('/')[-1]
            label = match.get('label', file_name)
            if label is None:
                label = file_name
            blocked = not file_name or any(item in file_name.lower() for item in _blacklist) or any(item in label for item in _blacklist)
            if stream_url.startswith('//'):
                stream_url = scheme + ':' + stream_url
            if '://' not in stream_url or blocked or (stream_url in streams) or any(stream_url == t[1] for t in source_list):
                continue
            labels.append(label)
            streams.append(stream_url)

        matches = zip(labels, streams) if not isPY3 else list(zip(labels, streams))
        if matches:
            log('@@@@ Scrape sources |%s| found |%s|' % (regex, matches), __name__)
        return matches #labels, streams

    if result_blacklist is None:
        result_blacklist = []
    elif isinstance(result_blacklist, str):
        result_blacklist = [result_blacklist]

    html = html.replace(r"\/", "/")
    html += get_packed_data(html)

    source_list = []
    if generic_patterns or not patterns:
        source_list += __parse_to_list(html, r'''["']?label\s*["']?\s*[:=]\s*["']?(?P<label>[^"',]+)["']?(?:[^}\]]+)["']?\s*file\s*["']?\s*[:=,]?\s*["'](?P<url>[^"']+)''')
        source_list += __parse_to_list(html, r'''["']?\s*(?:file|src)\s*["']?\s*[:=,]?\s*["'](?P<url>[^"']+)(?:[^}>\]]+)["']?\s*label\s*["']?\s*[:=]\s*["']?(?P<label>[^"',]+)''')
        source_list += __parse_to_list(html, r'''video[^><]+src\s*[=:]\s*['"](?P<url>[^'"]+)''')
        source_list += __parse_to_list(html, r'''source\s+src\s*=\s*['"](?P<url>[^'"]+)['"](?:.*?res\s*=\s*['"](?P<label>[^'"]+))?''')
        source_list += __parse_to_list(html, r'''["'](?:file|url)["']\s*[:=]\s*["'](?P<url>[^"']+)''')
        source_list += __parse_to_list(html, r'''param\s+name\s*=\s*"src"\s*value\s*=\s*"(?P<url>[^"]+)''')
        # source_list += __parse_to_list(html, r'''["']?\s*(?:file|url)\s*["']?\s*[:=]\s*["'](?P<url>[^"']+)''')
        # source_list += __parse_to_list(html, '''(?i)<iframe.+?src=["']([^'"]+)''')
    for regex in patterns:
        source_list += __parse_to_list(html, regex)

    source_list = list(set(source_list))

    log(f'@@@@ last source_list [{source_list}]', __name__)
    # source_list = sort_sources_list(source_list)

    return source_list


def get_packed_data(html):
    packed_data = ''
    for match in re.finditer(r'(eval\s*\(function.*?)</script>', html, re.DOTALL | re.I):
        try:
            from openscrapers.modules.jsunpack import unpack
            js_data = unpack(match.group(1))
            js_data = js_data.replace('\\', '')
            packed_data += js_data
        except:
            pass

    return packed_data


def test_patterns(text, patterns=[]):
    """Given source text and a list of patterns, look for
    matches for each pattern within the text and print
    them to stdout.
    useges:
    test_patterns('abbaaabbbbaaaaa',
              [ 'ab*',     # a followed by zero or more b
                'ab+',     # a followed by one or more b
                'ab?',     # a followed by zero or one b
                'ab{3}',   # a followed by three b
                'ab{2,3}', # a followed by two to three b
                ])
    :return:
    """
    # Show the character positions and input text
    log(''.join(str(i / 10 or ' ') for i in range(len(text))))
    log(''.join(str(i % 10) for i in range(len(text))))
    log(text)

    # Look for each pattern in the text and print the results
    for pattern in patterns:
        log(f'Matching "{pattern}"')
        for match in re.finditer(pattern, text):
            s = match.start()
            e = match.end()
            # log('  %2d : %2d = "%s"' % (s, e - 1, text[s:e]))
            log(f'  {s:2d} : {e - 1:2d} = "{text[s:e]}"')
    return


def regex_patterns():
    """
    Use this regular expression to find all of consecutive whitespaces. Very useful for text editing purposes to cure text
    :return:
    """
    pattern = r'''(?:\s)\s'''
    text = '''330                                                                  
                                                                              
    layout (location = 0) in vec3 Position;                                       
                                                                                  
    void main()    '''
    data = re.sub(pattern, '', text)
    log(f'data: {data.strip()}')
    """
    remove Matches all non-ascii characters including spaces until reaching an ascii character in text
    """
    pattern = r'''[^\x00-\x7F]+\ *(?:[^\x00-\x7F]| )*'''
    text = '''ABCabc~ |	*	Õ×ë
                テ  スト。
                －Τα εννέα πουλιά －
                ＭＩＲＲＯＲ'''
    data = re.sub(pattern, '', text)
    log(f'data: {data.strip()}')
    """
    get text between 2 marker
    as-is will fail with an AttributeError if there are no "AAA" and "ZZZ" in text
    """
    text = 'gfgfdAAA1234ZZZuijjk'
    data = re.search(r"(?<=AAA).*?(?=ZZZ)", text).group(0)
    log(f'data: {data}')
    """Get URL and Lable from:
    value="87"/>
    <td class="line-content">  sources:[{file: 'https://hls2x.vidembed.net/load/hls/YcZQc1FGQYWuj_fAI2F7Pg/1625270480/242436/a8d172bb473a8ba8e2feddc34c478e4b/ep.11.1618011076.m3u8',label: 'hls P','type' : 'hls'}],</td>
    </tr>
    """
    result = """value="87"/>
    <td class="line-content">  sources:[{file: 'https://hls2x.vidembed.net/load/hls/YcZQc1FGQYWuj_fAI2F7Pg/1625270480/242436/a8d172bb473a8ba8e2feddc34c478e4b/ep.11.1618011076.m3u8',label: 'hls P','type' : 'hls'}],</td>
    </tr>"""
    data = re.search(r'''["']?\s*(?:file|src)\s*["']?\s*[:=,]?\s*["'](?P<url>[^"']+)(?:[^}>\]]+)["']?\s*label\s*["']?\s*[:=]\s*["']?(?P<label>[^"',]+)''', result)
    log(f'data: {data.group("url")}')
    log(f'data: {data.group("label")}')
    """It will remove all the control characters"""
    text = "Saina\xa0(2021)"
    # result = re.sub(r'[^\x00-\x7f]', '', text)
    result = re.sub(pattern, '', text)
    log(result)
    """clean title from (Season 1|Season 2|S01|S02)"""
    text = "suite Season 1|F.B.I. Season 2|S01|S02"
    result = re.sub(r'([Ss]eason) \d{1,2}|[Ss]\d{1,2}', '', text)
    log(result)
    """Removing Digits from a String"""
    text = "The film Pulp Fiction was released in year 1994"
    result = re.sub(r"\d", "", text)
    log(result) # The film Pulp Fiction was released in year
    """Removing Alphabet Letters from a String"""
    text = "The film Pulp Fiction was released in year 1994"
    result = re.sub(r"[a-z]", "", text, flags=re.I)
    log(result) # 1994
    """Removing Word Characters"""
    text = "The film, '@Pulp Fiction' was ? released in % $ year 1994."
    result = re.sub(r"\w", "", text, flags=re.I)
    log(result) # , '@ '  ?   % $  .
    """Removing Non-Word Characters"""
    text = "The film, '@Pulp Fiction' was ? released in % $ year 1994."
    result = re.sub(r"\W", "", text, flags=re.I)
    log(result) # ThefilmPulpFictionwasreleasedinyear1994
    """Grouping Multiple Patterns"""
    text = "The film, '@Pulp Fiction' was ? released _ in % $ year 1994."
    result = re.sub(r"[,@\'?\.$%_]", "", text, flags=re.I)
    log(result) # The film Pulp Fiction was  released  in   year 1994
    """Removing Multiple Spaces"""
    text = "The film      Pulp Fiction      was released in   year 1994."
    result = re.sub(r"\s+", " ", text, flags=re.I)
    log(result) # The film Pulp Fiction was released in year 1994.
    """Removing Spaces from Start and End"""
    text = "         The film Pulp Fiction was released in year 1994"
    result = re.sub(r"^\s+", "", text)
    log(result)
    """"remove space at the end of the string"""
    text = "The film Pulp Fiction was released in year 1994      "
    result = re.sub(r"\s+$", "", text)
    log(result) # The film Pulp Fiction was released in year 1994
    """Removing a Single Character"""
    text = "The film Pulp Fiction     s was b released in year 1994"
    result = re.sub(r"\s+[a-zA-Z]\s+", " ", text)
    log(result) # The film Pulp Fiction was released in year 1994
    """Splitting a String"""
    text = "The film      Pulp   Fiction was released in year 1994      "
    result = re.split(r"\s+", text)
    log(result) # ['The', 'film', 'Pulp', 'Fiction', 'was', 'released', 'in', 'year', '1994', '']
    text = "The film, Pulp Fiction, was released in year 1994"
    result = re.split(r"\,", text)
    log(result) # ['The film', ' Pulp Fiction', ' was released in year 1994']
    """Finding All Instances"""
    text = "I want to buy a mobile between 200 and 400 euros"
    result = re.findall(r"\d+", text)
    log(result) # ['200', '400']
    """"""


def extractJS(data, function=False, variable=False, match=False, evaluate=False, values=False):
    log("")
    scripts = parseDOM(data, "script")
    if len(scripts) == 0:
        log("Couldn't find any script tags. Assuming javascript file was given.")
        scripts = [data]

    lst = []
    log("Extracting", 0)
    for script in scripts:
        tmp_lst = []
        if function:
            tmp_lst = re.compile(r'\(.*?\).*?;', re.M | re.S).findall(script)
            # tmp_lst = re.compile(function + r'\(.*?\).*?;', re.M | re.S).findall(script)
        elif variable:
            # tmp_lst = re.compile(variable.replace("[", r"\[").replace("]", r"\]") + '[ ]+=.*?;', re.M | re.S).findall(script)
            # log(">>>> script: " + repr(script), 0)
            tmp_lst = re.compile(r'var.*?=.*?(.+)[,;]{1}', re.M | re.S).findall(script)
            # log('tmp_lst: ' + repr(tmp_lst))
            # log("????tmp_lst: " + repr(tmp_lst), 0)
        else:
            tmp_lst = [script]
        if len(tmp_lst) > 0:
            log(f"Found: {repr(tmp_lst)}", 0)
            lst += tmp_lst
        else:
            log(f"Found nothing on: {script}", 0)

    lst = [i for i in lst if i != u''] # remove empty item from list
    test = range(0, len(lst))
    log(f"lst: >>>>> {lst}")

    # test.reverse()
    for i in test:
        if match and lst[i].find(match) == -1:
            log(f"Removing item: {repr(lst[i])}", 0)
            del lst[i]
        else:
            log(f"Cleaning item: {repr(lst[i])}", 0)
            if lst[i][0] == u"\n":
                lst[i] == lst[i][1:]
            if lst[i][len(lst) - 1] == u"\n":
                lst[i] == lst[i][:len(lst) - 2]
            lst[i] = lst[i].strip()

    if values or evaluate:
        for i in range(0, len(lst)):
            log(f"Getting values {lst[i]}")
            if function:
                if evaluate:  # include the ( ) for evaluation
                    data = re.compile(r"(\(.*?\))", re.M | re.S).findall(lst[i])
                else:
                    data = re.compile(r"\((.*?)\)", re.M | re.S).findall(lst[i])
            elif variable:
                tlst = re.compile(variable + r".*?=.*?;", re.M | re.S).findall(lst[i])
                data = []
                for tmp in tlst:  # This breaks for some stuff. "ad_tag": "http://ad-emea.doubleclick.net/N4061/pfadx/com.ytpwatch.entertainment/main_563326'' # ends early, must end with }
                    cont_char = tmp[0]
                    cont_char = tmp[tmp.find("=") + 1:].strip()
                    cont_char = cont_char[0]
                    if cont_char in "'\"":
                        log(f"Using {cont_char} as quotation mark", 1)
                        tmp = tmp[tmp.find(cont_char) + 1:tmp.rfind(cont_char)]
                    else:
                        log("No quotation mark found", 1)
                        tmp = tmp[tmp.find("=") + 1: tmp.rfind(";")]

                    tmp = tmp.strip()
                    if len(tmp) > 0:
                        data.append(tmp)
            else:
                log("ERROR: Don't know what to extract values from")

            log(f"Values extracted: {repr(data)}")
            if len(data) > 0:
                lst[i] = data[0]

    if evaluate:
        for i in range(0, len(lst)):
            log(f"Evaluating {lst[i]}")
            data = lst[i].strip()
            try:
                try:
                    lst[i] = json.loads(data)
                except:
                    log("Couldn't json.loads, trying eval")
                    lst[i] = eval(data)
            except:
                log(f"Couldn't eval: {repr(data)} from {repr(lst[i])}")

    log(f"Done: {len(lst)}")
    return lst


# urlReWriteDict = [{'host': 'vidwatch.php', 'url': 'http://vidwatch.me/embed-%s.html'}, {'host': 'speedwatch.php', 'url': 'http://speedwatch.us/embed-%s.html'}, {'host': 'logy.php', 'url': 'http://tvlogy.to/embed1/%s'}, {'host': 'vkprime.php', 'url': 'http://vkprime.com/embed-%s.html'}, {'host': 'vkspeed.php', 'url': 'http://vkspeed.com/embed-%s-600x380.html'}, {'host': 'watchvideo.php', 'url': 'http://watchvideo.us/embed-%s.html'}, {'host': 'watchers.php', 'url': 'http://watchers.to/embed-%s-725x410.html'}, {'host': 'player.php', 'url': 'https://watchshare.net/embed/%s'}, {'host': 'speed.php', 'url': 'http://vkspeed.com/embed-%s-600x380.html'}, {'host': 'irshare.php', 'url': 'https://irshare.net/embed-%s/'}, {'host': 'tune.php', 'url': 'https://tune.pk/player/embed_player.php?vid=%s'}, {'host': 'xpressvids.info', 'url': 'https://watchshare.net/embed/%s'}, {'host': 'letwatch.php', 'url': 'http://letwatch.us/embed-%s-650x400.html'}, {'host': 'lw.php', 'url': 'http://letwatch.us/embed-%s-650x400.html'}, {'host': 'let.php', 'url': 'http://letwatch.us/embed-%s-650x400.html'}, {'host': 'playwire.php', 'url': 'http://config.playwire.com/%s/player.json'}, {'host': 'pw.php', 'url': 'http://config.playwire.com/%s/player.json'}, {'host': 'ddaily.php', 'url': 'http://www.dailymotion.com/embed/video/%s'}, {'host': 'dm.php', 'url': 'http://www.dailymotion.com/embed/video/%s'}, {'host': 'speedplay.php', 'url': 'http://speedplay.me/embed-%s.html'}, {'host': 'cloudy.php', 'url': 'http://www.cloudy.ec/embed.php?id=%s&width=650&height=410'}, {'host': 'tvlogy.php', 'url': 'http://tvlogy.to/watch.php?v=%s'}, {'host': 'idowatch.php', 'url': 'http://idowatch.us/embed-%s.html'}, {'host': 'playu.php', 'url': 'http://playu.net/embed-%s-700x440.html'}, {'host': 'nowvideo.php', 'url': 'http://embed.nowvideo.sx/embed.php?v=%s&amp;wmode=direct&amp;autoplay=true&controls=false'}, {'host': 'nv.php', 'url': 'http://embed.nowvideo.sx/embed.php?v=%s&amp;wmode=direct&amp;autoplay=true&controls=false'}, {'host': 'openload.php', 'url': 'https://openload.co/embed/%s/'}, {'host': 'thevideo.php', 'url': 'http://www.thevideo.me/embed-%s-650x400.html'}, {'host': 'vodlocker.php', 'url': 'http://vodlocker.com/embed-%s-650x400.html'}, {'host': 'vidto.php', 'url': 'http://vidto.me/embed-%s-640x360.html'}, {'host': 'vidzi.php', 'url': 'http://vidzi.tv/embed-%s-640x360.html'}, {'host': 'vidgg.php', 'url': 'http://www.vidgg.to/embed/?id=%s&amp;px=1'}, {'host': 'aurora.php', 'url': 'http://www.auroravid.to/embed/?v=%s&amp;px=1'}, {'host': 'cloudtime.php', 'url': 'http://www.cloudtime.to/embed/?v=%s&amp;px=1'}, {'host': 'vidoza.php', 'url': 'https://vidoza.net/embed-%s/'}, {'host': 'estream.php', 'url': 'http://estream.to/embed-%s.html'}, {'host': 'goflicker.php', 'url': 'http://goflicker.com/embed-%s-520x400.html'}]


def ordinal(integer):
    int_to_string = str(integer)

    if int_to_string == '1' or int_to_string == '-1':
        # log(f'{int_to_string}st')
        return int_to_string + 'st'
    elif int_to_string == '2' or int_to_string == '-2':
        # log(f'{int_to_string}nd')
        return int_to_string + 'nd'
    elif int_to_string == '3' or int_to_string == '-3':
        # log(f'{int_to_string}rd')
        return int_to_string + 'rd'
    elif int_to_string[-1] == '1' and int_to_string[-2] != '1':
        # log(f'{int_to_string}st')
        return int_to_string + 'st'
    elif int_to_string[-1] == '2' and int_to_string[-2] != '1':
        # log(f'{int_to_string}nd')
        return int_to_string + 'nd'
    elif int_to_string[-1] == '3' and int_to_string[-2] != '1':
        # log(f'{int_to_string}rd')
        return int_to_string + 'rd'
    else:
        # log(f'{int_to_string}th')
        return int_to_string + 'th'


def daterange(weekend=False):
    weekday_dict = []
    weekend_dict = []
    end_date = datetime.date.today()  # end_date = date(2018, 1, 1)
    start_date = (end_date - datetime.timedelta(.25*365 / 12))  # start_date = date(2017, 1, 1)
    # log(f"start_date : {start_date}")
    for n in range(int((end_date - start_date).days)):
        d = start_date + datetime.timedelta(n)
        weekno = d.weekday()
        # log(f"start_date : {d} :: {weekno}")
        day = d.strftime("%d").lstrip('0')
        day = ordinal(day)
        mont = d.strftime("%B")
        year = d.strftime("%Y")
        if weekend and weekno >= 5:
            weekend_dict.append('{} {} {}'.format(day, mont, year))
        if weekno < 5:
            weekday_dict.append('{} {} {}'.format(day, mont, year))
    if weekend:
        return weekend_dict
    else:
        return weekday_dict


def get_hindi_show_episod():
    title = ['Taarak Mehta Ka Ooltah Chashmah', 'Mere Sai', 'Crime Patrol', 'the kapil sharma show', 'bigg boss']

    tvshowtitle = random.choice(title)
    if tvshowtitle in 'the kapil sharma show':
        episodes = daterange(weekend=True)
    else:
        episodes = daterange()
    episode = random.choice(episodes)
    serattearm = f'{tvshowtitle}-{episode}'
    return serattearm.lower().replace(' ', '-').replace('.', '-')


def open_file_wrapper(file, mode='r', encoding='utf-8'):
    """
    use:
    json_path = os.path.join(path, filename)
    with open_file_wrapper(json_path)() as json_result:
        return json.load(json_result)
    """
    if 'JSTesting' not in file: file = f"JSTesting/{file}"
    # if py_tools.isPY2:
    #     return lambda: open(file, mode)
    return lambda: open(file, mode, encoding=encoding)


def read_write_file(file_n='test.html', read=True, result=''):
    """
    :useged:
    from openscrapers.modules.hindi_sources import read_write_file
    read_write_file('test_%s.html' % hdlr, read=False, result=r)
    :param file_n:
    :param read:
    :param result:
    :return:

    """
    if read:
        with open_file_wrapper(file_n, mode='r')() as f:
            result = f.read()
        return result
    else:
        try:
            result = result.replace('\n', ' ').replace('\t', '').replace('&nbsp;', '').replace('&#8211;', '')
            with open_file_wrapper(file_n, mode='w')() as f:
                f.write(ensure_str(result))
        except:
            log(f'Error: in read_write_file: {traceback.print_exc()}')


# if __name__ == '__main__':
#     regex_patterns()
