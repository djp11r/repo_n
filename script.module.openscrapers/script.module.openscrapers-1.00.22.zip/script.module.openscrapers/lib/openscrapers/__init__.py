# -*- coding: UTF-8 -*-

import os
import traceback
from pkgutil import walk_packages


try:
	from .modules import cfscrape
	cfScraper = cfscrape.create_scraper()
except ImportError:
	from .modules import log_utils
	log_utils.log('cfscrape import exc', 1)

from urllib.parse import parse_qs, urljoin, urlparse, urlencode, quote, unquote, quote_plus, unquote_plus, parse_qsl

try:
	from openscrapers.modules.control import setting as getSetting, joinPath
	from openscrapers.modules.log_utils import log, error
	debug = getSetting('debug.enabled') == 'true'
	provider = getSetting('module.provider').lower()
	testing = False
except:
	log = error = print
	LOGWARNING = 'LOGWARNING'
	__addon__ = None
	debug = True
	testing = True
	provider = 'sources_openscrapers'
	joinPath = os.path.join
hindi_providers = ('desirulez', 'einthusan', 'desicinemas', 'hindilinks4u', 'bollyfuntv', 'watchapne', 'desiserials', 'desitelly', 'yodesi', 'playdesi')
sourceFolder = 'sources_openscrapers'

def sources(specified_folders=None, ret_all=False, vid_type=None, media_type=None):
	try:
		sourceDict = []
		sourceDict_append = sourceDict.append
		sourceFolderLocation = joinPath(os.path.dirname(__file__), sourceFolder)
		# sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
		# if specified_folders: sourceSubFolders = specified_folders
		not_usefull = []
		not_usefull_append = not_usefull.append
		for loader, module_name, is_pkg in walk_packages([joinPath(sourceFolderLocation, 'en')]):
			if is_pkg: continue
			if not ret_all and not enabledCheck(module_name):
				continue
			if media_type and module_name not in hindi_providers:
				continue
			elif not media_type and module_name in hindi_providers:
				continue
			# if ret_all or enabledCheck(module_name):
			try:
				module = loader.find_module(module_name).load_module(module_name)
				# log(f'vid_type: {vid_type} module_name: {module_name} is_pkg: {is_pkg} loader: {loader} ')
				if vid_type == 'episode':
					try:
						if getattr(module.source(), 'tvshow'):
							sourceDict_append((module_name, module.source))
					except: not_usefull_append(module_name)
				elif vid_type == 'movie':
					try:
						if getattr(module.source(), 'movie'):
							sourceDict_append((module_name, module.source))
					except: not_usefull_append(module_name)
				else:
					sourceDict_append((module_name, module.source))
				# sourceDict_append((module_name, module.source()))
			except Exception as e:
				log(f'Error: Loading module: "{module_name}": {traceback.format_exc()}')
		if debug: log(f'not usefull for vid_type: {vid_type} Providers {not_usefull}')
		return sourceDict
	except:
		log(f'Error: sources: "{traceback.print_exc()}"')
		return []

def getScraperFolder():
	try:
		sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
		sourceSubFolders = [x for x in sourceSubFolders if x not in ['__pycache__', 'help', 'modules', 'cfscrape', 'pyaes']]
		return [i for i in sourceSubFolders if 'openscrapers' in i.lower()][0]
	except:
		error('getScraperFolder: ')
		return 'sources_openscrapers'

def enabledCheck(module_name):
	try:
		if getSetting('provider.' + module_name) == 'true': return True
		else: return False
	except:
		# error()
		return True


def custom_base_link(scraper):
	try:
		url = getSetting('url.' + scraper)
		if url and url.startswith('http'):# and url.endswith('/'):
			url = url[:-1]
		else:
			url = None
	except:
		url = None
	return url

def pack_sources():
	return []


def providerSources():
	sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
	return getModuleName(sourceSubFolders)


def providerNames():
	providerList = []
	append = providerList.append
	# provider = getSetting('module.provider')
	sourceFolder = getScraperFolder()
	sourceFolderLocation = joinPath(os.path.dirname(__file__), sourceFolder)
	sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
	for i in sourceSubFolders:
		for loader, module_name, is_pkg in walk_packages([joinPath(sourceFolderLocation, i)]):
			if is_pkg: continue
			correctName = module_name.split('_')[0]
			append(correctName)
	return providerList


def getAllHosters():
	def _sources(sourceFolder, append):
		sourceFolderLocation = os.path.join(os.path.dirname(__file__), sourceFolder)
		sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
		for i in sourceSubFolders:
			for loader, module_name, is_pkg in walk_packages([os.path.join(sourceFolderLocation, i)]):
				if is_pkg: continue
				try: mn = str(module_name).split('_')[0]
				except: mn = str(module_name)
				append(mn)
	sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
	appendList = []
	append = appendList.append
	for item in sourceSubFolders:
		if item not in ['__pycache__', 'modules', 'cfscrape', 'pyaes']:
			_sources(item, append)
	return list(set(appendList))


def getModuleName(scraper_folders):
	nameList = []
	append = nameList.append
	for s in scraper_folders:
		if not s in ['__pycache__', 'modules', 'cfscrape', 'pyaes']:
			try: append(s.split('_')[1].lower().title())
			except: pass
	return nameList
