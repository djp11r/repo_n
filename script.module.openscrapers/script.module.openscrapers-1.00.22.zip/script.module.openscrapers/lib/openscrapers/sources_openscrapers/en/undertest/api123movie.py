# -*- coding: utf-8 -*-
"""
    **Created by Tempest**
    **If you see this in a addon other than Tempest and says it was
    created by someone other than Tempest they stole it from me**
"""
import random
import re
import base64
import traceback

try:
    from urlparse import parse_qs, urljoin
    from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, parse_qs, quote_plus, urljoin

from openscrapers.modules import cfscrape
from openscrapers.modules import client
from openscrapers.modules import source_utils
from openscrapers.modules import log_utils
from openscrapers.modules.py_tools import ensure_text, ensure_str
from openscrapers.modules.hindi_sources import read_write_file


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['api.123movie.cc']
        self.base_link = 'https://api.123movie.cc'
        self.search_link = 'e/movie/%s'
        self.search_link2 = 'e/tv/%s/%s/%s'#'/tv-imdb/%s-%s-%s'
        self.headers = {'User-Agent': client.agent(), 'Referer': self.base_link}

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            source_utils.scraper_error('api.123movie.cc')
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            source_utils.scraper_error('api.123movie.cc')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            source_utils.scraper_error('api.123movie.cc')
            return

    def searchShow(self, imdb, tvdb, title, season, episode):
        try:
            title = title.replace(' ', '-').replace('.', '').replace(':', '').replace('.-.', '.').replace('\'', '').lower()
            urls = [#'%s/tmdb_api.php?se=%s&ep=%s&tmdb=%s&server_name=vcu' % (self.base_link, season, episode, tvdb),
                    #'%s/tmdb_api?se=%s&ep=%s&tmdb=%s&server_name=vcs' % (self.base_link, season, episode, tvdb),
                    #'%s/jadeed.php?ep=%s-%sx%s&server_name=serverf4&t=%s' % (self.base_link, title, season, episode, tvdb),
                    # '%s/jadeed.php?ep=%s-%sx%s&server_name=f5_series&t=%s' % (self.base_link, tvdb, season, episode, tvdb),
                    '%s/jadeed.php?ep=%s-%sx%s&server_name=pretty' % (self.base_link, title, season, episode),]
            return urls
        except:
            source_utils.scraper_error('api.123movie.cc')
            return

    def searchMovie(self, imdb):
        try:
            urls = []
            servers = ['vcu', 'vcs', 'streamtape', 'hydrax', 'serverf4']
            for server in servers:
                url = 'https://api.123movie.cc/imdb.php?imdb=%s&server=%s' % (imdb, server)
                urls.append(url)
            return urls
        except:
            source_utils.scraper_error('api.123movie.cc')
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url is None: return sources
            hostDict = hostprDict + hostDict

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            if 'tvshowtitle' in data:
                query = self.searchShow(data['imdb'], data['tvdb'], data['tvshowtitle'].lower(), data['season'], data['episode'])
            else:
                query = self.searchMovie(data['imdb'])
            log_utils.log('query url: ' + repr(query))
            for url in query:
                log_utils.log('episod url: ' + repr(url))
            url = random.sample(query, k=1)[0]
            log_utils.log('url: ' + repr(url))
            cfScraper = cfscrape.create_scraper()
            # url = 'https://api.123movie.cc/tmdb_api?se=7&ep=9&tmdb=82696&server_name=vcs'
            posts = cfScraper.get(url, headers=self.headers).text
            posts = ensure_text(posts, errors='replace')
            # read_write_file(file_n='server_vcs.html', read=False, result=posts)
            # posts = read_write_file(file_n='server_vcs.html')
            urls = re.findall('<div class="server" data-src="(.+?)">', posts)
            # return
            # log_utils.log('r: ' + repr(urls))
            urls = [ensure_text(url, errors='ignore') for url in urls]
            urls = [urljoin(self.base_link, url) if url.startswith('/') else url for url in urls]
            # log_utils.log('apimdb_all_urls: %s' % (urls))
            for url in urls:
                if any(v in url for v in ['googledrive2', 'vidcloud', 'streamsb']): #Do not work >>> 'upstream', 'ninjastream', 'streamsb', 'voxzer', 'mixdrop', 'dood'
                    try:
                        # log_utils.log('############ ')
                        # log_utils.log('GD url: ' + repr(url))
                        r = cfScraper.get(url, headers=self.headers).text
                        r = ensure_text(r, errors='replace')
                        # if 'upstream' in url: filename = 'upstream.html'
                        # elif 'ninjastream' in url: filename = 'ninjastream.html'
                        # elif 'streamsb' in url: filename = 'streamsb.html'
                        # else: filename = 'voxzer.html'
                        # read_write_file(file_n=filename, read=False, result=r)
                        # r = read_write_file(file_n=filename)
                        r = ensure_str(r, errors='replace')
                        # log_utils.log('r: %s' % (r))
                        # links = re.findall("file:'(.+?)'", r)
                        links = re.findall(r'''(?:src|file)[:=]\s*['"]([^"']+)''', r)
                        # log_utils.log('links: ' + repr(links))
                        for url in links:
                            if url.startswith('http'):
                                # log_utils.log('url: ' + repr(url))
                                valid, host = source_utils.is_host_valid(url, hostDict)
                                # log_utils.log('valid: %s, host: %s' % (valid, host))
                                # if valid:
                                sources.append({'source': host, 'quality': '720p', 'language': 'en', 'info': '', 'url': url, 'direct': False, 'debridonly': False})
                    except:
                        source_utils.scraper_error('api.123movie.cc')
                        pass
            return sources
        except Exception:
            source_utils.scraper_error('api.123movie.cc')
            return sources

    def resolve(self, url):
        return url
