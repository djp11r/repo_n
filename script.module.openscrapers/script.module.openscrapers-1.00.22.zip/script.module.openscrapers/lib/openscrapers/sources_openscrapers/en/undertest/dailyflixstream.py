# -*- coding: UTF-8 -*-


import requests
from six import ensure_text
from openscrapers import urlparse

from openscrapers.modules import client
from openscrapers.modules import cleantitle
from openscrapers.modules import source_utils
from openscrapers.modules import log_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['dailyflix.stream']
        self.base_link = 'https://dailyflix.stream'
        self.search_link = '/search/%s/feed/rss2/'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = self.base_link + self.search_link % imdb
            html = client.r_request(url)
            items = client.parseDOM(html, 'item')
            r = [(client.parseDOM(i, 'title'), client.parseDOM(i, 'link')) for i in items]
            r = [(i[0][0], i[1][0]) for i in r if len(i[0]) > 0 and len(i[1]) > 0]
            url = [i[1] for i in r if cleantitle.get(title) == cleantitle.get(i[0])][0]
            return url
        except Exception:
            log_utils.log('Testing Exception', 1)
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            hostDict = hostprDict + hostDict
            sources = []
            if url == None:
                return sources
            log_utils.log('Addon Testing starting url: \n' + repr(url))
            html = client.r_request(url)
            links = client.parseDOM(html, 'iframe', ret='src')
            for link in links:
                log_utils.log('Addon Testing link: \n' + repr(link))
                valid, host = source_utils.is_host_valid(link, hostDict)
                qual, info = source_utils.get_release_quality(link, link)
                sources.append({'source': host, 'quality': qual, 'language': 'en', 'url': link, 'info': info, 'direct': False, 'debridonly': False})
            return sources
        except Exception:
            log_utils.log('Testing Exception', 1)
            return sources


    def resolve(self, url):
        return url


