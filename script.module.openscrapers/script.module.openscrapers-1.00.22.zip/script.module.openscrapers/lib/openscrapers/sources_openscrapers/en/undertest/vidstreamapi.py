# -*- coding: utf-8 -*-
"""
    **Created by Tempest**
    **If you see this in a addon other than Tempest and says it was
    created by someone other than Tempest they stole it from me**
"""
import base64
import re
import traceback

import requests

from openscrapers import urlencode, parse_qs
from openscrapers.modules import log_utils
from openscrapers.modules import client
from openscrapers.modules import source_utils
from openscrapers.modules.py_tools import ensure_text
from openscrapers.modules.dom_parser import parseDOM
from openscrapers.modules.utils import json_loads_as_str
from openscrapers.modules.hindi_sources import read_write_file


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['vidstreamapi.com']
        self.base_link = 'https://www.vidstreamapi.com'
        self.api = '1eb288d32891978f51589e98055a429f'
        self.headers = {'User-Agent': client.agent(), "Content-type": "application/x-www-form-urlencoded"}

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        items = []
        try:
            if url is None:
                return sources
            hostDict += hostprDict

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            if 'tvshowtitle' in data:
                payload = {'api': self.api, 'id': data['imdb'], 'season': data['season'], 'episode': data['episode']}
            else:
                payload = {'api': self.api, 'id': data['imdb'], 'season': '', 'episode': ''}
            print('payload : %s' % payload)
            # payload  = urlencode(payload )
            # print('payload : %s' % payload )
            url = 'https://www.vidstreamapi.com/stream_src.php'
            # print("url: %s" % url)
            r_post = requests.post(url, data=payload, headers=self.headers)
            print(r_post.status_code, r_post.reason, r_post.text)
            read_write_file(file_n='test_vidstreamapi.html', read=False, result=r_post.text)
            # r_post = read_write_file(file_n='test_vidstreamapi.html')
            # if r_post.status_code == 200:
            if r_post:
                try:
                    # itemurl = 'https://www.wakandaforever.cc/embed.php?video_id=4c3647ab24ee2c079b026c4ff95395870b8b549a84b15d3ede377212d328d5c4'
                    respo = requests.get(r_post.text, headers={'User-Agent': client.agent()}).text
                    read_write_file(file_n='vid_vidstreamapi.html', read=False, result=respo)
                    # respo = read_write_file(file_n='test_vidstreamapi.html')
                    scripts = parseDOM(respo, "script")
                    var_script = [script for script in scripts if 'var' in script]
                    # print('var_script: ' + repr(var_script))
                    var_m = re.search(r'(?<=var).*?=(.+)[,;]{1}', var_script[0])
                    var_m = var_m.group(1).replace("\'", "")
                    # print('var_m: ' + repr(var_m))
                    jsload_var = json_loads_as_str(var_m)
                    urls = [item['url'] for item in jsload_var]
                    print('urls: ' + repr(urls))
                    urls = [ensure_text(base64.b64decode(url), errors='ignore') for url in urls]
                    urls = ['https:%s' % url if url.startswith('//') else url for url in urls]
                    urls = list(set(urls))
                    for url in urls:
                        valid, host = source_utils.is_host_valid(url, hostDict)
                        sources.append({'source': host, 'quality': 'SD', 'language': 'en', 'url': url, 'direct': False, 'debridonly': False})
                except:
                    log_utils.log('vidstreamapi - Exception: \n' + str(traceback.format_exc()))
            return sources
        except Exception:
            log_utils.log('vidstreamapi - Exception: \n' + str(traceback.format_exc()))
            return sources

    def resolve(self, url):
        return url
