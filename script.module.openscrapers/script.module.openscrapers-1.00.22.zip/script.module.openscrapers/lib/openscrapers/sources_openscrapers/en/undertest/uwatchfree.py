# -*- coding: UTF-8 -*-

from openscrapers.modules import client
from openscrapers.modules import source_utils
from openscrapers.modules import log_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['uwatchfree.as']
        self.base_link = 'https://www.uwatchfree.as'
        self.search_link = '/search/%s/feed/rss2/'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = self.base_link + self.search_link % imdb
            html = client.r_request(url)
            posts = client.parseDOM(html, 'item')
            for post in posts:
                if not imdb in post:
                    raise Exception()
                url = client.parseDOM(post, 'a', ret='href')[0]
            return url
        except Exception:
            log_utils.log('Testing Exception', 1)
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            hostDict = hostprDict + hostDict
            sources = []
            if url == None:
                return sources
            html = client.r_request(url)
            body = client.parseDOM(html, 'tbody')[0]
            links = client.parseDOM(body, 'a', ret='href')
            for link in links:
                html = client.r_request(link)
                links = client.parseDOM(html, 'iframe', ret='src')
                for link in links:
                    log_utils.log('Addon Testing link: \n' + repr(link))
                    valid, host = source_utils.is_host_valid(link, hostDict)
                    qual, info = source_utils.get_release_quality(link, link)
                    sources.append({'source': host, 'quality': qual, 'language': 'en', 'url': link, 'info': info, 'direct': False, 'debridonly': False})
            return sources
        except Exception:
            log_utils.log('Testing Exception', 1)
            return sources

    def resolve(self, url):
        return url


