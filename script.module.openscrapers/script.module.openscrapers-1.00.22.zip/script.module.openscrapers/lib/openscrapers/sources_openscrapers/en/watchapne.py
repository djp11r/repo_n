# -*- coding: UTF-8 -*-

# import json
# import re
import re
import traceback
from openscrapers import urlencode

import requests
from openscrapers.modules import client, log_utils
from openscrapers.modules.hindi_sources import get_source_dict, link_extractor, host, append_headers, get_headersfrom_url
# from openscrapers.modules.hindi_sources import read_write_file

class source:

    def __init__(self):
        self.priority = 5
        self.language = ['en']
        self.name = "watchapne"
        self.domains = ['watchapne.co']
        self.base_link = 'https://watchapne.co'
        self.referer = self.base_link
        self.headers = {'User-Agent': client.agent(),}
    
    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            query = title.replace(' ', '-').replace(':', '')
            start_url = "https://watchapne.co/movie/%s" % query
            # print('movie url: {}'.format(start_url))
            return start_url
        except:
            log_utils.error(f'{__name__}_ movie: ')
            return
    
    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # scraper_debug("From: {} \nimdb {} \ntvdb {}\n tvshowtitle {}, localtvshowtitle {}, aliases {}, year {} ".format(self.name, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))
        try:
            query = tvshowtitle.replace(' ', '-')
            url = query
            # scraper_debug('>>> #### 0AAAA - watchapne EP url : %s' % ( url))
            return url
        except:
            log_utils.error(f'{__name__}_ tvshow: ')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # scraper_debug("From: {} url {} ... \nimdb {} .. tvdb {}\n title {}, premiered {}, season {}, episode {} ".format(self.name, url, imdb, tvdb, title, premiered, season, episode))
        try:
            if type(tvdb) == int: return
            if '|' in tvdb:
                # scraper_debug("type watchapne tvdb %s" % type(tvdb))
                # query = '{}/{}'.format(url, title).replace(' ', '-')
                query = '{}'.format(url).replace(' ', '-')
                # title = '{}'.format(title).replace(' ', '-')
                # print("query {} title: {} ".format(query, title))
                if 'episode' in title.lower():
                    url = 'https://watchapne.co/web-series/%s' % query
                    self.referer = 'https://watchapne.co/web-series/channel/'
                    release_title = title.strip()
                else:
                    url = 'https://apnetv.me/Hindi-Serial/%s' % query
                    self.referer = 'https://apnetv.co/Hindi-Serials'
                    release_title = re.sub(r'\d{4}', '', title).strip()  # remove year from title
                # print("show url %s" % url)
                result = client.r_request(url, headers=self.headers).text
                # result = read_write_file(file_n='apnetv.co.html')

                # release_title = '8th August'
                # scraper_debug("watchapne release_title: %s" % release_title)
                try:
                    results = client.parseDOM(result, 'div', attrs={'class': 's-epidode clearfix'})
                    for result in results:
                        if release_title in result:
                            # scraper_debug("watchapne episode result: %s" % result)
                            url = client.parseDOM(result, "a", ret="href")[0]
                            return url
                except:
                    log_utils.error(f'{__name__}_ episode: ')
            return
        except:
            log_utils.error(f'{__name__}_ episode: ')
            return

    def sources(self, url, hostDict, hostprDict):
        # scraper_debug("From: {} url: {} ".format(self.name, url))
        sources = []
        try:
            if not url:	return sources
            # print('url: %s' % url)
            result = requests.get(url, headers=self.headers).text
            if not result: return
            result = client.parseDOM(result, 'div', attrs={'class': 'bottom_episode_list'})
            # print('result: %s' % result)
            items = client.parseDOM(result, 'li')
            for item in items:
                urls = client.parseDOM(item, 'a', ret='href')
                # log_utils.log('urls: %s' % urls)
                furls = []
                vidhost = None
                for j in range(0, len(urls)):
                    try:
                        vhdr = {'Referer': self.referer}
                        link = f'{urls[j]}{append_headers(vhdr)}'
                        furls.append(link)
                    except:
                        log_utils.error(f'{__name__}_ sources: ')
                if len(furls) > 0:
                    sources = get_source_dict(furls, sources, vidhost)
            # dumper = dumper
            # scraper_debug('SOURCES \n\n%s' % json.dumps(sources, default = dumper, indent = 2))
            return sources
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return sources
    
    def apne_twostop(self, url, headers):
        # headers.update(self.headers)
        # url = url.replace('www.hindistoponline.com', 'hindigostop.com')
        # log_utils.log(f'headers >>> : {headers}')
        html = requests.get(url, headers=headers).text
        try:
            urltopost = re.search(r'''<form.*action=["'](.+?)["']''', html)
            urltopost = urltopost.group(1)
            inputNameValue = re.compile('''input.*?name=["'](.+?)["'].+?value=["'](.+?)["']''', re.M)
            formFields = inputNameValue.findall(html)
            # scraper_debug('0 formFields {}'.format(formFields))
            postFields = {}
            for field in formFields:
                # print('0 field {}'.format(field))
                postFields[field[0].encode("ascii")] = field[1].encode("ascii")
            # scraper_debug('0 postFields {}'.format(postFields))
            html = requests.post(urltopost, headers=headers, data=postFields).text
            # log_utils.log(f'html >>> : {html}')
            return html
        except Exception as e:
            log_utils.error('%s_ apne_twostop: ' % __name__)
    
    def resolve(self, url):
        # scraper_debug('In type of url {} url: {}'.format(type(url), url))
        try:
            if not any(re.findall(r'dailymotion|vup|streamtape|vidoza|mixdrop|mystream|doodstream|watchvideo|vkprime|vkspeed', url, re.IGNORECASE)):
                if ' , ' in url: iurl = url.split(' , ')
                else: iurl = [url]
                # scraper_debug('In len of iurl {} iurl: {}'.format(len(iurl), iurl))
                furl = links = []
                headers = get_headersfrom_url(url)
                headers.update({'User-Agent': client.agent()})
                # headers = {'User-Agent': client.agent(), 'Referer': self.referer}
                for i in range(0, len(iurl)):
                    # links = None
                    # log_utils.log('iurl[i] >>> : %s' % iurl[i])
                    # vhdr = {'Referer': self.referer}
                    if 'watchapne.co' in iurl[i]:
                        link = iurl[i]# + append_headers(vhdr)
                        if link.endswith('.m3u8'): headers.update({'Range': 'bytes=0-'})
                        link = '{0}|{1}'.format(link, urlencode(headers))
                        furl.append(link)
                    elif 'go.clockks.com' in iurl[i] or 'go.tellynewsarticles.com' in iurl[i]:
                        html = self.apne_twostop(iurl[i], headers)
                        links = re.findall('''(?i)<iframe.+?src=["']([^'"]+)''', html)
                    elif 'hinditwostop' in iurl[i]:
                        html = requests.get(iurl[i], headers=headers).text
                        links = re.findall('''(?i)<iframe.+?src=["']([^'"]+)''', html)
                        headers.update({'Origin': 'https://apnevideo.co'})
                    if links:
                        link = links[0]# + append_headers(vhdr)
                        if '?url=' in link:
                            link = link.split('?url=')[1]
                        if link.endswith('.m3u8'): headers.update({'Range': 'bytes=0-'})
                        link = '{0}|{1}'.format(link, urlencode(headers))
                        furl.append(link)
                # log_utils.log(f'watchapne len furl: {len(furl)} type furl {type(furl)} furl: {furl}')
                if len(furl) > 0: url = ' , '.join(furl)
                else: url = furl[0]
                # log_utils.log(f'watchapne type of url {type(url)} url: {url}')
                return url
        except Exception as e:
            log_utils.error(f'{__name__}_ url: {url} resolve: {e}')
            return
