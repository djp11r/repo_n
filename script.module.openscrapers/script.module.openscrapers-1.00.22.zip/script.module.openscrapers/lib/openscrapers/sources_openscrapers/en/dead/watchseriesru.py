# -*- coding: utf-8 -*-

"""

"""


import re

import requests

try: from urlparse import urljoin
except ImportError: from urllib.parse import urljoin

from openscrapers.modules import cleantitle, client, source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['watch-series.ru']
        self.base_link = 'https://watch-series.live'
        self.search_link = '/series/%s-season-%s-episode-%s'
        self.headers = {'User-Agent': client.agent()}

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = cleantitle.geturl(tvshowtitle)
            return url
        except Exception:
            source_utils.scraper_error('watchseriesru')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return
            tvshowtitle = url
            url = self.base_link + self.search_link % (tvshowtitle, season, episode)
            return url
        except Exception:
            source_utils.scraper_error('watchseriesru')
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if not url: return sources
            # r = client.request(url, headers=headers)
            r = requests.get(url, headers = self.headers).text
            match = re.compile('data-video="(.+?)">').findall(str(r))
            for url in match:
                if 'vidcloud' in url:
                    url = urljoin('https:', url)
                    # r = client.request(url, headers=headers)
                    r= requests.get(url, headers = self.headers).text
                    regex = re.compile("file: '(.+?)'").findall(r)
                    for direct_links in regex:
                        sources.append({'source': 'cdn', 'quality': 'SD', 'language': 'en', 'info': '', 'url': direct_links, 'direct': False, 'debridonly': False})

                else:
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    sources.append({'source': host, 'quality': 'SD', 'language': 'en', 'info': '', 'url': url, 'direct': False, 'debridonly': False})
            return sources
        except:
            source_utils.scraper_error('watchseriesru')
            return []

    def resolve(self, url):
        return url
