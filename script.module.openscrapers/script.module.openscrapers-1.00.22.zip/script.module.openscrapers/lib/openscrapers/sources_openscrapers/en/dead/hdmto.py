# -*- coding: UTF-8 -*-

"""
	OpenScrapers Project
"""

import re

# import requests
from openscrapers.modules import cleantitle
from openscrapers.modules import client, log_utils
from openscrapers.modules import source_utils


class source:
	def __init__(self):
		self.priority = 40
		self.language = ['en']
		self.domains = ['hdm.to']
		self.base_link = 'https://hdm.to'
		self.search_link = '/search/%s+%s'
		self.headers = {'User-Agent': client.agent()}

	def movie(self, imdb, title, localtitle, aliases, year):
		try:
			t = cleantitle.geturl(title).replace('-', '+').replace('++', '+')
			self.title = t
			url = self.base_link + self.search_link % (t, year)
			r = client.request(url)
			u = client.parseDOM(r, "div", attrs={"class": "col-md-2 col-sm-2 mrgb"})
			for i in u:
				link = re.compile('<a href="(.+?)"').findall(i)
				for url in link:
					if not cleantitle.get(title) in cleantitle.get(url):
						continue
					return url
		except:
			log_utils.error('%s_ movie: ' % __name__)
			return


	def sources(self, url, hostDict, hostprDict):
		# log_utils.log('url = %s' % url, __name__, log_utils.LOGDEBUG)
		sources = []
		try:
			if not url: return sources

			t = client.request(url)
			#site has magnets also
			# t = re.sub(r'\n|\t', '', t)
			# torrents = re.compile(r'Torrent:\s*(.*)</span><div').findall(t)[0]
			# tor_list = re.findall(r'href="(.+?)">(.+?)</a', torrents)
			# name = re.compile('<h2 class="movieTitle">(.+?)</h2>').findall(t)[0]
			# name = re.sub('[^A-Za-z0-9]+', '.', name).lstrip('.')

			# for torrent, qual in tor_list:
				# hash = torrent.split('download/')[1]
				# url = 'magnet:%s' % hash
				# url = 'magnet:?xt=urn:btih:%s&dn=Avengers.Endgame.%s' % (hash, qual)
				# quality, info = source_utils.get_release_quality(name, url)

				# if qual == '3D':
					# quality = '1080p'
				# dsize = 0

				# info = ' | '.join(info)

				# sources.append({'source': 'torrent', 'seeders': 1, 'hash': hash, 'name': name + '.' + quality, 'quality': quality,
											# 'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': True, 'size': dsize})

			r = re.compile('<iframe.+?src="(.+?)"').findall(t)

			for url in r:
				url = url.replace(" ", "+")
				if 'youtube' in url:
					continue
				url = url.split('//1o.to/')[1]
				url = 'https://hls.1o.to/vod/%s/playlist.m3u8' % url
				sources.append({'source': 'direct', 'quality': '720p', 'info': '', 'language': 'en', 'url': url, 'direct': True, 'debridonly': False})

			return sources
		except:
			log_utils.error('%s_ sources: ' % __name__)
			return []

	def resolve(self, url):
		return url
