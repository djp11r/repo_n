# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 10-16-2019 by JewBMX in Scrubs.
# modified by Venom for Openscrapers (updated url 8-03-2020)

"""
    OpenScrapers Project
"""

import base64
import json
import re
import time
import traceback


from openscrapers import urlencode, quote, unquote_plus, parse_qs, urljoin

from openscrapers.modules import client
from openscrapers.modules import log_utils
from openscrapers.modules import cleantitle
from openscrapers.modules import directstream
from openscrapers.modules import scrape_source
from openscrapers.modules import py_tools


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['showbox.watch', 'showbox.works', 'showbox.space']
        self.base_link = 'https://showbox.watch' #'https://showbox.works'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            aliases = {'country': 'us', 'title': title}
            url = {'imdb': imdb, 'title': title, 'year': year, 'aliases': aliases}
            url = urlencode(url)
            return url
        except:
            log_utils.error(f'{__name__}_ movie: ')
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            # aliases = json.loads(aliases)
            aliases = {'country': 'us', 'title': tvshowtitle}
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year, 'aliases': aliases}
            url = urlencode(url)
            return url
        except:
            log_utils.error(f'{__name__}_ tvshow: ')
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None:
                return
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            log_utils.error(f'{__name__}_ episode: ')
            return


    def searchShow(self, title, season, episode, aliases, headers):
        try:
            url = '%s/show/%s/season/%01d/episode/%01d' % (self.base_link, cleantitle.geturl(title), int(season), int(episode))
            url = client.request(url, headers=headers, output='geturl', verifySsl=False, timeout='10')
            return url
        except:
            log_utils.error(f'{__name__}_ searchShow: ')
            return


    def searchMovie(self, title, year, aliases, headers):
        try:
            url = '%s/movie/%s' % (self.base_link, cleantitle.geturl(aliases['title']))
            url = client.request(url, headers=headers, output='geturl', verifySsl=False, timeout='10')
            if url is None:
                url = '%s/movie/%s-%s' % (self.base_link, cleantitle.geturl(aliases['title']), year)
                url = client.request(url, headers=headers, output='geturl', verifySsl=False, timeout='10')
            return url
        except:
            log_utils.error(f'{__name__}_ searchMovie: ')
            return


    def searchMovie2(self, title, year, headers):
        try:
            url = '%s/movie/%s-%s' % (self.base_link, cleantitle.geturl(title), year)
            url = client.request(url, headers=headers, output='geturl', verifySsl=False, timeout='10')
            return url
        except:
            log_utils.error(f'{__name__}_ searchMovie2: ')
            return


    def sources(self, url, hostDict, hostprDict):
        sources = []
        # url = 'episode=11&title=King+of+Kings&tvdb=260449&season=6&tvshowtitle=Vikings&premiered=2021-01-01&imdb=tt2306299&year=2013&aliases=%7B%27country%27%3A+%27us%27%2C+%27title%27%3A+%27Vikings%27%7D'
        if not url: return sources
        try:
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            imdb = data['imdb']
            aliases = eval(data['aliases'])
            headers = {}
            if 'tvshowtitle' in data:
                url = self.searchShow(title, int(data['season']), int(data['episode']), aliases, headers)
            else:
                url = self.searchMovie(title, data['year'], aliases, headers)
            # log_utils.log("url: {}".format(url))
            r = client.request(url, headers=headers, output='extended', verifySsl=False, timeout='10')
            # log_utils.log("url: {} \nr: {}".format(url, r))
            if r and imdb not in r[0]:
                url = self.searchMovie2(title, data['year'], headers)
                r = client.request(url, headers=headers, output='extended', verifySsl=False, timeout='10')
            if not r: return sources
            # log_utils.log("response_code: {} \nresponse_headers: {} \nheaders: {} \ncookie: {} \nresult: {}".format(r[1], r[2], r[3], r[4], r[0]))
            cookie = r[4]
            headers = r[2]
            result = r[0]
            try:
                r = re.findall(r'(https:.*?redirector.*?)[\'\"]', result)
                for i in r:
                    sources.append({'source': 'gvideo', 'quality': directstream.googletag(i)[0]['quality'], 'language': 'en', 'info': '', 'url': i, 'direct': True, 'debridonly': False})
            except: log_utils.error('SHOWBOX - gvideo Exception: %s' % str(traceback.format_exc()))

            try:
                auth = re.findall(r'__utmx=(.+)', cookie)[0].split(';')[0]
            except:
                auth = 'false'
            auth = 'Bearer %s' % unquote_plus(auth)
            # log_utils.log("type(auth): {} auth: {}".format(type(auth), auth))
            # log_utils.log("type(headers): {} headers: {}".format(type(headers), headers))
            headers['Authorization'] = auth
            headers['Referer'] = url
            # log_utils.log("type(headers): {} headers: {}".format(type(headers), headers))
            u = '/ajax/vsozrflxcw.php'
            self.base_link = client.request(self.base_link, headers=headers, verifySsl=False, output='geturl')
            u = urljoin(self.base_link, u)
            # log_utils.log("u >>> : {}".format(u))
            if u.startswith('http'):
                action = 'getEpisodeEmb' if '/episode/' in url else 'getMovieEmb'
                tim = str(int(time.time())) if py_tools.isPY2 else py_tools.ensure_binary(str(int(time.time())))
                elid = quote(base64.encodebytes(tim)).strip()
                token = re.findall(r"var\s+tok\s*=\s*'([^']+)", result)[0]
                idEl = re.findall(r'elid\s*=\s*"([^"]+)', result)[0]
                post = {'action': action, 'idEl': idEl, 'token': token, 'nopop': '', 'elid': elid}
                post = urlencode(post)
                if cookie: cookie = '%s;%s=%s' % (cookie, idEl, elid)
                else: cookie = '%s=%s' % (idEl, elid)
                headers['Cookie'] = cookie
                r = client.request(u, post=post, headers=headers, verifySsl=False, cookie=cookie, XHR=True)
                r = str(json.loads(r))
                r = re.findall(r'\'(http.+?)\'', r) + re.findall(r'\"(http.+?)\"', r)
                # print("r2: %s" % r)
                for i in r:
                    for source in scrape_source.getMore(i, hostDict):
                        sources.append(source)
                return sources
        except:
            log_utils.error(f'{__name__}_ sources: ')
            return sources


    def resolve(self, url):
        try:
            if 'google' in url and 'googleapis' not in url:
                return directstream.googlepass(url)
            else:
                return url
        except:
            log_utils.error(f'{__name__}_ resolve: ')
