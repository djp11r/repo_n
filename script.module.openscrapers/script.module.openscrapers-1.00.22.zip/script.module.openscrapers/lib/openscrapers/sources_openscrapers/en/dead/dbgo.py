# -*- coding: utf-8 -*-
"""
    **Created by Tempest**
    **If you see this in a addon other than Tempest and says it was
    created by someone other than Tempest they stole it from me**
"""

import re
import base64

import requests

from openscrapers import urlencode, parse_qs, quote_plus, urljoin
# from openscrapers.modules import log_utils
from openscrapers.modules.source_utils import scraper_error
from openscrapers.modules.py_tools import ensure_str


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['dbgo.fun']
        self.base_link = 'https://dbgo.fun'
        self.search_link = '/video.php?id='
        self.headers = {'Referer': 'https://cdn.dbgo.fun'}

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url: return
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url is None:
                return sources

            hostDict = hostprDict + hostDict

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            if 'tvshowtitle' in data:
                url = "%s%s/S%sE%s" % (self.search_link, data['imdb'], data['season'], data['episode'])
            else:
                url = "%s%s" % (self.search_link, quote_plus(data['imdb']))
            # url = self.search_link % quote_plus(data['imdb'])
            url = urljoin(self.base_link, url)
            url = 'https://dbgo.fun/video.php?id=tt2467372/S3E10'
            # print("url: %s" % url)
            try:
                # url = client.request(url, headers=self.headers)
                url = requests.get(url, headers=self.headers).text
                # read_write_file(file_n='test_dbgo.html', read=False, result=url)
                # url = read_write_file(file_n='test_dbgo.html')
                url = re.findall('file:"#2(.*?)"', url)[0].replace('//eS95L3kv', '').replace('//ei96L3ov', '').replace('//eC94L3gv', '')
                url = '%s|Referer=https://cdn.dbgo.fun/' % ensure_str(base64.b64decode(url), errors='replace')
                # print("final url: %s" % url)
                sources.append({'source': 'CDN', 'quality': '720p', 'language': 'en', 'info': '', 'url': url, 'direct': False, 'debridonly': False})
            except:
                scraper_error('DBGO')

            return sources
        except Exception:
            scraper_error('DBGO')
            return []

    def resolve(self, url):
        return url
