# -*- coding: utf-8 -*-
import requests
from openscrapers.modules import log_utils

API_URL = 'https://api.themoviedb.org/3/'
ART_URL = 'https://image.tmdb.org/t/p/original'
HEADERS = {'Content-Type': 'application/json;charset=utf-8'}
API_KEY = 'c8b7db701bac0b26edfcc93b39858972'


def find_movie_by_external_source(imdb):
    try:
        url = f'{API_URL}find/{imdb}?api_key={API_KEY}&language=en-US&external_source=imdb_id'
        result = requests.get(url, headers=HEADERS).json()
        item = result['movie_results'][0]
        return item
    except Exception as err:
        log_utils.log(f'find_movie_by_external_source: {err}')
        return


def find_tvshow_by_external_source(imdb=None, tvdb=None):
    try:
        if imdb:
            url = f'{API_URL}find/{imdb}?api_key={API_KEY}&language=en-US&external_source=imdb_id'
        elif tvdb:
            url = f'{API_URL}find/{tvdb}?api_key={API_KEY}&language=en-US&external_source=tvdb_id'
        result = requests.get(url, headers=HEADERS).json()
        # print(f'result: {result}')
        item = result['tv_results'][0]
        return item
    except Exception as err:
        log_utils.log(f'find_tvshow_by_external_source: {err}')
        return
