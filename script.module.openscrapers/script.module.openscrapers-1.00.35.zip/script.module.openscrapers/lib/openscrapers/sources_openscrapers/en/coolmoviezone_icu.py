# -*- coding: UTF-8 -*-

import re

from openscrapers import parse_qs, urlencode

from openscrapers.modules import client
from openscrapers.modules import cleantitle
from openscrapers.modules import scrape_sources
#from openscrapers.modules import log_utils


class source:
    def __init__(self):
        try:
            self.results = []
            self.domains = ['coolmoviezone.icu', 'coolmoviezone.pics', 'coolmoviezone.homes', 'coolmoviezone.agency',
                'coolmoviezone.company', 'coolmoviezone.cfd', 'coolmoviezone.show', 'coolmoviezone.studio',
                'coolmoviezone.ninja', 'coolmoviezone.online', 'coolmoviezone.io', 'coolmoviezone.biz', 'coolmoviezone.info'
            ]
            self.base_link = 'https://coolmoviezone.icu'
            self.search_link = '/search/%s/feed/rss2/'
        except Exception:
            #log_utils.log('__init__', 1)
            return


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year, 'aliases': aliases}
            url = urlencode(url)
            return url
        except:
            #log_utils.log('movie', 1)
            return


    def sources(self, url, hostDict):
        try:
            if url == None:
                return self.results
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            aliases = eval(data['aliases'])
            title = data['title']
            year = data['year']
            check_term = '%s (%s)' % (title, year)
            check_title = cleantitle.get_plus(check_term)
            search_url = self.base_link + self.search_link % cleantitle.geturl(title)
            html = client.scrapePage(search_url).text
            items = client.parseDOM(html, 'item')
            r = [(client.parseDOM(i, 'title'), client.parseDOM(i, 'link')) for i in items]
            r = [(i[0][0], i[1][0]) for i in r if len(i[0]) > 0 and len(i[1]) > 0]
            url = [i[1] for i in r if check_title == cleantitle.get_plus(i[0])][0]
            html = client.scrapePage(url).text
            links = re.compile('<td align="center"><strong><a href="(.+?)">', re.DOTALL).findall(html)
            for link in links:
                for source in scrape_sources.process(hostDict, link):
                    self.results.append(source)
            return self.results
        except Exception:
            #log_utils.log('sources', 1)
            return self.results


    def resolve(self, url):
        return url


