# -*- coding: UTF-8 -*-
# (updated 01-02-2022)
'''
	Fenomscrapers Project
'''

from json import loads as jsloads
import random
import re

from openscrapers import parse_qs, urlencode, quote_plus, quote

try: from openscrapers.modules.control import setting as getSetting
except: pass
from openscrapers.modules.client import scrapePage
from openscrapers.modules import source_utils
from openscrapers.modules import log_utils


class source:
	def __init__(self):
		self.results = []
		self.base_link = 'https://filepursuit.p.rapidapi.com' # 'https://rapidapi.com/azharxes/api/filepursuit' to obtain key
		self.search_link = '/?type=video&q=%s'
		self.api_key = random.choice(['c382fe48e3mshb1509420b500abfp1283b6jsn881275945a74', 'e1235ccc65msh9c6da42a2ff1797p199cefjsnaa4033afc078'])

	def movie(self, imdb, title, localtitle, aliases, year):
		try:
			url = {'imdb': imdb, 'title': title, 'aliases': aliases, 'year': year}
			url = urlencode(url)
			return url
		except:
			return

	def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
		try:
			url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'aliases': aliases, 'year': year}
			url = urlencode(url)
			return url
		except:
			return

	def episode(self, url, imdb, tvdb, title, premiered, season, episode):
		try:
			if not url: return
			url = parse_qs(url)
			url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
			url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
			url = urlencode(url)
			return url
		except:
			return

	def sources(self, url, hostDict):
		sources = []
		if not url: return sources
		append = sources.append
		try:
			# try: api_key = getSetting('filepursuit.api')
			# except: api_key = self.api_key
			# if api_key == '': return sources
			headers = {"x-rapidapi-host": "filepursuit.p.rapidapi.com", "x-rapidapi-key": self.api_key}

			data = parse_qs(url)
			data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

			title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$','s')
			aliases = data['aliases']
			episode_title = data['title'] if 'tvshowtitle' in data else None
			year = data['year']
			hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else year

			query = '%s %s' % (title, hdlr)
			query = re.sub(r'(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', '', query)
			url = '%s%s' % (self.base_link, self.search_link % quote_plus(query))
			# log_utils.log('url = %s' % url, log_utils.LOGDEBUG)
			r = scrapePage(url, headers=headers, timeout=10).text
			#log_utils.log('r.json = %s' % r, log_utils.LOGDEBUG)
			if not r: return sources
			r = jsloads(r)
			if 'not_found' in r['status']: return sources
			results = r['files_found']
		except:
			log_utils.error(f'{__name__}_ sources: ')
			return sources

		undesirables = source_utils.get_undesirables()
		check_foreign_audio = source_utils.check_foreign_audio()
		for item in results:
			try:
				url = item['file_link']
				try: size = int(item['file_size_bytes'])
				except: size = 0
				# try: referrer_link = item['referrer_link']
				# except: referrer_link = 0
				try: name = item['file_name']
				except: name = item['file_link'].split('/')[-1]
				name = source_utils.clean_name(name)

				if not source_utils.check_title(title, aliases, name, hdlr, year): continue
				name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				# link_header = client.request(url, output='headers', timeout=5) # to slow to check validity of links
				# if not any(value in str(link_header) for value in ('stream', 'video/mkv')): continue

				quality, info = source_utils.get_release_quality(name_info, url)
				try:
					dsize, isize = source_utils.convert_size(size, to='GB')
					# if isize: info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)
				url = quote(url, safe=':/')
				# url = "%s|Referer=%s" % (url, referrer_link)

				append({'source': 'filepursuit', 'provider': 'filepursuit', 'quality': quality, 'name': name, 'name_info': name_info,
							'url': url, 'info': info, 'direct': True, 'size': dsize})
			except:
				log_utils.error(f'{__name__}_ sources: ')
		return sources

	def resolve(self, url):
		return url

# url = "https://filepursuit.p.rapidapi.com/"
# querystring = {"q":"<REQUIRED>"}
# headers = {
    # 'x-rapidapi-host': "filepursuit.p.rapidapi.com",
    # 'x-rapidapi-key': "e1235ccc65msh9c6da42a2ff1797p199cefjsnaa4033afc078"
    # }
# response = requests.request("GET", url, headers=headers, params=querystring)
# print(response.text)
