# -*- coding: utf-8 -*-
"""
	Infinity Add-on
"""

from sys import argv
from urllib.parse import parse_qsl
from resources.lib import router

if __name__ == '__main__':
	try:
		url = dict(parse_qsl(argv[2].replace('?', '')))
	except:
		url = {}
	router.router(url)