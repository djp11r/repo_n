from urllib.parse import urlencode

import chardet
import hashlib
import io
import json
import os
import re
import requests
import shutil
import time
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import xbmcplugin
import xml.etree.ElementTree as ET
from copy import copy


AddonID = 'plugin.video.playlistLoader'
Addon = xbmcaddon.Addon(AddonID)
addonInfo = Addon.getAddonInfo
addonName = addonInfo("name")
icon = addonInfo('icon')
executebuiltin = xbmc.executebuiltin
transPath = xbmcvfs.translatePath
joinPath = os.path.join
addItem = xbmcplugin.addDirectoryItem
content = xbmcplugin.setContent
directory = xbmcplugin.endOfDirectory
resolve = xbmcplugin.setResolvedUrl

dialog = xbmcgui.Dialog()
numeric_input = xbmcgui.INPUT_NUMERIC
item = xbmcgui.ListItem

addon_data_dir = transPath(Addon.getAddonInfo("profile"))
cacheDir = joinPath(addon_data_dir, "cache")
tvdb_path = joinPath(cacheDir, "TVDB")
tmdb_path = joinPath(cacheDir, "TMDB")
makeGroups = Addon.getSetting("makeGroups") == "true"
UA = 'Mozilla/5.0 (Windows NT 6.1; rv:11.0) Gecko/20100101 Firefox/11.0'

def notification(line1, time=5000, icon=icon, sound=False):
	if isinstance(line1, int): line1 = local_string(line1)
	dialog.notification('playlistLoader', line1, icon, time, sound)

def container_refresh():
	return executebuiltin('Container.Refresh')

def logger(function, level=1):
	xbmc.log('###playlistLoader###: %s' % (function), level)

def getLocaleString(string):
    try: string = int(string)
    except: return string
    try: string = str(Addon.getLocalizedString(string))
    except: string = Addon.getLocalizedString(string)
    return string


def ReadFile(fileName):
    try:
        with open(fileName, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        content = content.replace("\n\n", "\n")
    except Exception as ex:
        logger(str(ex), 3)
        content = ""
    return content


def SaveFile(fileName, text):
    try:
        with open(fileName, 'w', encoding='utf-8', errors='ignore') as f:
            content = f.write(text)
    except:
        return False
    return True


def ReadList(fileName):
    try:
        with open(fileName, 'r', encoding='utf-8') as handle:
            content = json.load(handle)
    except Exception as ex:
        logger(str(ex), 5)
        if os.path.isfile(fileName):
            shutil.copyfile(fileName, "{0}_bak.txt".format(fileName[:fileName.rfind('.')]))
            executebuiltin('Notification({0}, Cannot read file: "{1}". \nBackup createad, {2}, {3})'.format(addonName, os.path.basename(fileName), 5000, icon))
        content = []

    return content


def SaveList(filname, chList):
    try:
        with io.open(filname, 'w', encoding='utf-8') as handle:
            handle.write(json.dumps(chList, indent=4, ensure_ascii=False))
        success = True
    except Exception as ex:
        logger(str(ex), 3)
        success = False
    return success


def OKmsg(title, line1, line2=None, line3=None):
    dlg = xbmcgui.Dialog()
    dlg.ok(title, line1, line2, line3)


def isFileNew(file, deltaInSec):
    lastUpdate = 0 if not os.path.isfile(file) else int(os.path.getmtime(file))
    now = int(time.time())
    return False if (now - lastUpdate) > deltaInSec else True


def isFromCache(address, cache=0):
    if address.startswith('http'):
        fileLocation = joinPath(cacheDir, hashlib.md5(address.encode('utf8')).hexdigest())
        retval = isFileNew(fileLocation, cache * 60)
    else:
        retval = isFileNew(address, cache * 60)
    return retval


def GetList(address, cache=0):
    if address.startswith('http'):
        fileLocation = joinPath(cacheDir, hashlib.md5(address.encode('utf8')).hexdigest())
        fromCache = isFileNew(fileLocation, cache * 60)
        if fromCache:
            response = ReadFile(fileLocation)
        else:
            response = requests.get(address, headers={"User-agent": UA})
            if cache > 0:
                SaveFile(fileLocation, response)
            response = response.text
    else:
        response = ReadFile(address)
    return response


def plx2list(url, cache):
    response = GetList(url, cache)
    matches = re.compile("^background=(.*?)$", re.I + re.M + re.U + re.S).findall(response)
    background = None if len(matches) < 1 else matches[0]
    chList = [{"background": background}]
    matches = re.compile('^type(.*?)#$', re.I + re.M + re.U + re.S).findall(response)
    for match in matches:
        item = re.compile('^(.*?)=(.*?)$', re.I + re.M + re.U + re.S).findall("type{0}".format(match))
        item_data = {}
        for field, value in item:
            item_data[field.strip().lower()] = value.strip()
        item_data['group'] = 'Main'
        chList.append(item_data)
    return chList


def m3u2list(url, cache):
    response = GetList(url, cache) + "#EXT#"
    matches = re.compile('(?s)^#EXTINF:-?[0-9]*(.*?),(.*?)\n(.*?)#EXT#', re.M).findall(response.replace('#EXTINF', '#EXT#\n#EXTINF'))
    li = []
    for params, display_name, uri in matches:
        url = uri
        if uri.startswith('#'):
            for ln in uri.splitlines():
                if not ln.startswith('#'): url = ln
                else:
                    if ln.startswith('#EXTGRP'):
                        params += ln.replace('"', '').replace("#EXTGRP:", ' group_title="') + '"'

        item_data = {"params": params, "display_name": display_name.strip(), "url": url.strip()}
        li.append(item_data)
    chList = []
    for channel in li:
        item_data = {"display_name": (channel["display_name"].decode("utf-8", "ignore")), "url": channel["url"]}
        matches = re.compile(' (.*?)="(.*?)"').findall(channel["params"])
        for field, value in matches:
            item_data[field.strip().lower().replace('-', '_')] = value.strip()
        chList.append(item_data)
    return chList


def SaveDict(filname, dict):
    try:
        with io.open(filname, 'w', encoding='utf-8') as handle:
            handle.write(json.dumps(dict))
        success = True
    except Exception as ex:
        logger(str(ex), 3)
        success = False
    return success


def dictify(r, root=True):
    if root:
        return {r.tag: dictify(r, False)}
    d = copy(r.attrib)
    if r.text:
        d["_text"] = r.text
    for x in r.findall("./*"):
        if x.tag not in d:
            d[x.tag] = []
        d[x.tag].append(dictify(x, False))
    return d


def epg2dict(url, cache):
    eDict = {}
    fn = joinPath(cacheDir, hashlib.md5((url + '.ebk').encode('utf8')).hexdigest())
    if isFromCache(url, cache):
        eDict = ReadList(fn)
        if not eDict: eDict = {}
    if not eDict:
        response = GetList(url, cache)
        try:
            root = ET.fromstring(response)
            doc = dictify(root)
            ID = 'id'
            SRC = 'src'
            CHANNEL = 'channel'
            START = 'start'
            STOP = 'stop'
            TEXT = '_text'

        except:
            return {}
        '''
            try:
                logger(str('*****'))


                data = StringIO(zlib.decompress(response))
                #data = gzip.GzipFile('', 'rb', 9, StringIO(response))
                content = data.read()
                doc = xmltodict.parse(content)

                url_file_handle=StringIO( response )
                logger(str(url_file_handle))
                gzip_file_handle = gzip.GzipFile(fileobj=url_file_handle)
                logger(str(gzip_file_handle))
                decompressed_data = gzip_file_handle.read()
                logger(str(decompressed_data))
                gzip_file_handle.close()
                doc = xmltodict.parse(decompressed_data)
            except:
                return {}
        '''

        nList = []
        dList = []
        pDict = {}
        for ch in doc['tv']['channel']:
            try:
                nList.append(GetEncodeString(ch['display-name'][TEXT]))
                try: dList.append((ch[ID], ch['icon'][0][SRC]))
                except: dList.append((ch[ID], ""))
            except:
                for dname in ch['display-name']:
                    nList.append(GetEncodeString(dname[TEXT]))
                    try: dList.append((ch[ID], ch['icon'][0][SRC]))
                    except: dList.append((ch[ID], ""))

        for prg in doc['tv']['programme']:
            if pDict.get(prg[CHANNEL]) == None:
                pDict[prg[CHANNEL]] = []
            else:
                try: pDict[prg[CHANNEL]].append((prg[START], prg[STOP], prg['title'][0][TEXT]))
                except: pass

        if len(nList):
            eDict[u'name'] = nList;
            eDict[u'data'] = dList
            eDict[u'prg'] = pDict

        SaveDict(fn, eDict)

    return eDict


def GetEncodeString(str):
    try:
        str = str.decode(chardet.detect(str)["encoding"]).encode("utf-8")
    except:
        try:
            str = str.encode("utf-8")
        except:
            pass
    return str


def DelFile(filname):
    try:
        if os.path.isfile(filname):
            os.unlink(filname)
    except Exception as ex:
        logger(str(ex), 3)


def GetKeyboardText(title="", defaultText=""):
    keyboard = xbmc.Keyboard(defaultText, title)
    keyboard.doModal()
    text = "" if not keyboard.isConfirmed() else keyboard.getText()
    return text

"""
Search for a movie / tvshow detail with The movie DB
"""


def searchTMDB(item_name):
    api_key = Addon.getSetting("themoviedb_api_key")
    response = requests.get("https://api.themoviedb.org/3/search/movie?api_key=%s&query=%s" % (api_key, item_name))
    return response.json()


"""
Search for a movie / tvshow detail with The TV DB
"""


def getTheTvDbToken():
    username = Addon.getSetting("thetvdb_username")
    user_key = Addon.getSetting("thetvdb_user_key")
    api_key = Addon.getSetting("thetvdb_api_key")

    credentials = {"apikey": api_key, "userkey": user_key, "username": username}
    r = requests.post('https://api.thetvdb.com/login', json=credentials)
    if r.status_code != 200:
        return False

    response = r.json()
    return response["token"]


"""
Scan a given playlist index with the tv db
"""


def startTheTvDbScan(index, playlistsFile, token):
    search_series = "https://api.thetvdb.com/search/series?%s"
    search_poster = "https://api.thetvdb.com/series/%s/images/query?keyType=poster"
    search_fanarts = "https://api.thetvdb.com/series/%s/images/query?keyType=fanart"
    images_route = "https://www.thetvdb.com/banners/%s"

    # Checking base tvdb directory.
    if not os.path.exists(tvdb_path):
        os.mkdir(tvdb_path)

    tvdb_playlist_path = joinPath(tvdb_path, str(index))

    # Remove all previous scans.
    if os.path.exists(tvdb_playlist_path):
        shutil.rmtree(tvdb_playlist_path)

    os.mkdir(tvdb_playlist_path)

    chList = ReadList(playlistsFile)
    item = chList[index]
    url = item["url"]
    content = m3u2list(url, cache=0)

    groups = []
    groups_infos = {}
    groups_404 = []
    headers = {"Accept": "application/json", "Accept-Language": "%s" % Addon.getSetting("language_1").lower(), 'Authorization': 'Bearer ' + token, "User-agent": UA}

    # Preparing progress bar.
    progress = xbmcgui.DialogProgress()
    progress.create(Addon.getLocalizedString(32028))
    step = 1
    not_found = 0

    for movie_item in content:
        # Handling "Cancel" action.
        if progress.iscanceled():
            break

        if not movie_item["group_title"] in groups:
            percent = (step * 100) / len(content)
            progress.update(int(percent), Addon.getLocalizedString(32029) + movie_item["group_title"], "", "")

            params = {"name": movie_item["group_title"]}
            params = urlencode(params)
            res = requests.get(search_series % params, headers=headers)

            if not res.status_code == 200:
                # Then fallback language.
                headers["Accept-Language"] = "en"
                res = requests.get(search_series % params, headers=headers)

            res = res.json()
            try:
                aired = res["data"][0]["firstAired"] if ("firstAired" in res["data"][0] and len(res["data"][0]["firstAired"]) > 0) else "1800-01-01"
                idx = -1
            except KeyError:
                # Nothing found.

                if not movie_item["group_title"] in groups_404:
                    not_found += 1
                    progress.update(int(percent), "", "", Addon.getLocalizedString(32030) + str(not_found))
                groups_404.append(movie_item["group_title"])
                continue

            for data in res["data"]:
                cmp = data["firstAired"] if ("firstAired" in data and len(data["firstAired"]) > 0) else "1800-01-01"
                dtcmp = strptime2(cmp, "%Y-%m-%d")
                if strptime2(aired, "%Y-%M-%d").date() <= dtcmp.date():
                    aired = cmp
                    idx += 1

            # Getting poster and fanarts.
            progress.update(int(percent), Addon.getLocalizedString(32029) + movie_item["group_title"] + " - " + Addon.getLocalizedString(32031), "", "")
            poster = requests.get(search_poster % str(res["data"][idx]["id"]), headers=headers)
            fanarts = requests.get(search_fanarts % str(res["data"][idx]["id"]), headers=headers)

            if not poster.status_code == 200:
                # Fallback language for posters ... most of posters are availables in english.
                headers["Accept-Language"] = "en"
                poster = requests.get(search_poster % str(res["data"][idx]["id"]), headers=headers)

            poster = poster.json()
            try:
                poster = images_route % poster["data"][0]["thumbnail"]
            except KeyError:
                poster = ""

            if not fanarts.status_code == 200:
                fanarts = requests.get(search_fanarts % str(res["data"][idx]["id"]), headers=headers)

            fanarts = fanarts.json()
            try:
                fanarts = [images_route % fanarts["data"][i]["fileName"] for i in range(len(fanarts["data"]))]
            except KeyError:
                fanarts = []

            # Reset to the default language.
            headers["Accept-Language"] = Addon.getSetting("language_1").lower()

            # Registering values into an array.
            groups_infos[movie_item["group_title"]] = {"overview": res["data"][idx]["overview"], "firstAired": aired, "poster": poster, "fanarts": fanarts, "tvdb_id": res["data"][idx]["id"]}

            groups.append(movie_item["group_title"])

        progress.update(int(percent), "", Addon.getLocalizedString(32032) + movie_item["group_title"], "")
        step += 1

    progress.close()

    # Savin this list to json
    with open(joinPath(tvdb_playlist_path, "groups.json"), 'w') as outfile:
        json.dump(groups_infos, outfile)

    with open(joinPath(tvdb_playlist_path, "groups.json"), 'w') as outfile:
        json.dump(groups_infos, outfile)

    # item["name"]
    """
    # UNCOMMENT FOR DEBUG ONLY !!!
    for info in groups_infos:
        logger("\n\n----------------------------------------------------------------------------", xbmc.LOGERROR)
        logger("---- Key : %s" % groups_infos[info]["poster"], xbmc.LOGERROR)
        logger("First Aired : %s" % groups_infos[info]["firstAired"], xbmc.LOGERROR)
        logger("tvdb_id : %s" % groups_infos[info]["tvdb_id"], xbmc.LOGERROR)
        logger("overview : %s" % groups_infos[info]["overview"], xbmc.LOGERROR)
        logger("----------------------------------------------------------------------------", xbmc.LOGERROR)
    """


"""
Return true if this m3u was scanned with the tv db function.
"""


def isScannedByTheTvDB(index):
    return os.path.exists(joinPath(tvdb_path, str(index)))


"""
Remove the tv db data for given playlist index.
"""


def removeTheTvDBData(index):
    shutil.rmtree(joinPath(tvdb_path, str(index)), ignore_errors=True)
    return True if not os.path.exists(joinPath(tvdb_path, str(index))) else False


"""
Return true if this m3u was scanned with the movie db function.
"""


def isScannedByTheMovieDB(index):
    return os.path.exists(joinPath(tmdb_path, str(index)))


"""
Remove the movie db data for given playlist index.
"""


def removeTheMovieDBData(index):
    shutil.rmtree(joinPath(tmdb_path, str(index)), ignore_errors=True)
    return True if not os.path.exists(joinPath(tmdb_path, str(index))) else False


"""
Load data from regisered the tv db nidex file
"""


def loadDataFromTheTvDB(index):
    jfile = joinPath(tvdb_path, str(index))
    jfile = joinPath(jfile, "groups.json")
    json_data = open(jfile).read()
    data = json.loads(json_data)
    return data


"""
Same than above for the movie db
"""


def loadDataFromTheMovieDB(index):
    jfile = joinPath(tmdb_path, str(index))
    jfile = joinPath(jfile, "groups.json")
    json_data = open(jfile).read()
    data = json.loads(json_data)
    return data


"""
Search for the right meta id.
"""


def searchMetaTVDBId(url, playlistsFile):
    json_playlists = open(playlistsFile).read()
    data = json.loads(json_playlists)
    i = 0
    for playlist in data:
        if playlist["url"] == url:
            return i
        i += 1
    return None


"""
Compat for datetime.
"""


def strptime2(string_date, sformat):
    from datetime import datetime as dt
    try:
        res = dt.strptime(string_date, sformat)
    except TypeError:
        res = dt(*(time.strptime(string_date, sformat)[0:6]))
    return res
