# -*- coding: utf-8 -*-
"""
	Infinity Add-on
"""

# from urllib.parse import quote_plus
from resources.lib.common import logger

def router(params):
	# params = dict(parse_qsl(sys.argv[2].replace('?', '')))
	# logger(params)
	url = params.get('url')
	logos = params.get('logos', '')
	epg = params.get('epg', '')
	name = params.get('name')
	iconimage = params.get('iconimage', '')
	cache = int(params.get('cache', '0'))
	index = int(params.get('index', '-1'))
	move = int(params.get('move', '0'))
	mode = int(params.get('mode', '0'))
	uuid = params.get('uuid', '0')

	if mode == 0:
		from resources.lib.navigator import Categories
		Categories()
	elif mode == 1:
		from resources.lib.navigator import PlxCategory
		PlxCategory(url, cache)
	elif mode == 2 or mode == 10:
		from resources.lib.navigator import m3uCategory
		m3uCategory(url, logos, epg, cache, mode, index)
	elif mode == 3 or mode == 32:
		from resources.lib.navigator import PlayUrl
		PlayUrl(name, url, iconimage)
	elif mode == 20:
		from resources.lib.navigator import AddNewList
		AddNewList()
	elif mode == 21:
		from resources.lib.navigator import MoveInList
		from resources.lib.common import playlistsFile
		MoveInList(uuid, move, playlistsFile)
	elif mode == 22:
		from resources.lib.navigator import RemoveFromLists
		from resources.lib.common import playlistsFile
		RemoveFromLists(uuid, playlistsFile)
	elif mode == 23:
		from resources.lib.navigator import ChangeKey
		from resources.lib.common import playlistsFile
		ChangeKey(uuid, playlistsFile, "name", 30004)
	elif mode == 24:
		from resources.lib.navigator import ChangeChoice
		from resources.lib.common import playlistsFile
		ChangeChoice(uuid, playlistsFile, "url", 30002, 30005, 30006, 30016, 30017, None, 1, '.plx|.m3u|.m3u8')
	elif mode == 25:
		from resources.lib.navigator import ChangeChoice
		from resources.lib.common import playlistsFile
		ChangeChoice(uuid, playlistsFile, "image", 30022, 30022, 30022, 30024, 30025, 30021, 2)
	elif mode == 26:
		from resources.lib.navigator import ChangeChoice
		from resources.lib.common import playlistsFile
		ChangeChoice(uuid, playlistsFile, "logos", 30018, 30019, 30020, 30019, 30020, 30021, 0)
	elif mode == 27:
		from resources.lib.common import DelFile, playlistsFile
		DelFile(playlistsFile)
	elif mode == 28:
		from resources.lib.navigator import ChangeCache
		from resources.lib.common import playlistsFile
		ChangeCache(uuid, playlistsFile)
	elif mode == 29:
		from resources.lib.navigator import ChangeChoice
		from resources.lib.common import playlistsFile
		ChangeChoice(uuid, playlistsFile, "epg", 30046, 30047, 30048, 30047, 30048, 30021, 0)
	elif mode == 30:
		from resources.lib.navigator import ListFavorites
		ListFavorites()
	elif mode == 31:
		from resources.lib.navigator import AddFavorites
		AddFavorites(url, iconimage, name)
	elif mode == 33:
		from resources.lib.navigator import RemoveFromFavourites
		RemoveFromFavourites(index)
	elif mode == 34:
		from resources.lib.navigator import AddNewFavorite
		AddNewFavorite()
	elif mode == 35:
		from resources.lib.navigator import ChangeKey
		from resources.lib.common import favoritesFile
		ChangeKey(index, favoritesFile, "name", 30014, favourites=True)
	elif mode == 36:
		from resources.lib.navigator import ChangeKey
		from resources.lib.common import favoritesFile
		ChangeKey(index, favoritesFile, "url", 30015, favourites=True)
	elif mode == 37:
		from resources.lib.navigator import ChangeChoice
		from resources.lib.common import favoritesFile
		ChangeChoice(index, favoritesFile, "image", 30023, 30023, 30023, 30024, 30025, 30021, 2, favourites=True)
	elif mode == 38:
		from resources.lib.navigator import MoveInFavourites
		MoveInFavourites(index, move)
	elif mode == 39:
		from resources.lib.common import DelFile
		DelFile(favoritesFile)
		# sys.exit()
	elif mode == 43:
		from resources.lib.navigator import AddNewDirectory
		AddNewDirectory()
	elif mode == 44:
		from resources.lib.navigator import ShowDirectoryContents
		ShowDirectoryContents(uuid)
	elif mode == 45:
		from resources.lib.navigator import AddToDirectory
		AddToDirectory(uuid)
	elif mode == 46:
		from resources.lib.navigator import DeleteDirectory
		DeleteDirectory(uuid, with_contents=True)
	elif mode == 47:
		from resources.lib.navigator import DeleteDirectory
		DeleteDirectory(uuid)
	elif mode == 40:
		from resources.lib.common import OKmsg
		OKmsg("Playlist Loader", "Comming soon !!")
		"""
		xbmc.log("The movie db scan request", xbmc.LOGERROR)
		# First make sure no the tv db data was here.
		if common.isScannedByTheTvDB(index):
			common.removeTheTvDBData(index)
		"""
	elif mode == 41:
		from resources.lib.common import makeGroups, isScannedByTheMovieDB, removeTheMovieDBData, getTheTvDbToken, OKmsg, getLocaleString, startTheTvDbScan, executebuiltin
		if makeGroups:
			# First make sur no scan from the movie db was here.
			if isScannedByTheMovieDB(index):
				removeTheMovieDBData(index)

			token = getTheTvDbToken()
			if token is False:
				OKmsg("The TV Db 1", getLocaleString(30042))
			else:
				startTheTvDbScan(index, playlistsFile, token)
				executebuiltin("XBMC.Container.Refresh()")
		else:
			OKmsg("The TV Db 2", getLocaleString(30043))
	elif mode == 42:
		from resources.lib.common import removeTheTvDBData, OKmsg, executebuiltin, getLocaleString
		ok = removeTheTvDBData(index)
		if ok:
			OKmsg("The TV Db 3", getLocaleString(32034))
			executebuiltin("XBMC.Container.Refresh()")
		else:
			OKmsg("The TV Db 4", getLocaleString(32035))
	elif mode == 50:
		from resources.lib.navigator import ToggleGroups
		ToggleGroups()
