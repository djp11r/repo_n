# -*- coding: utf-8 -*-
import hashlib, io, json, os, re, shutil, time, urllib
import random
import urllib.request
import xml.etree.ElementTree as ET
from copy import copy
from typing import Union
from urllib.parse import urlencode

import requests
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, xbmcvfs

AddonID = 'plugin.video.playlistloader'
Addon = xbmcaddon.Addon(AddonID)
addonInfo = Addon.getAddonInfo
addonName = addonInfo('name')
icon = addonInfo('icon')
executebuiltin = xbmc.executebuiltin
transPath = xbmcvfs.translatePath
joinPath = os.path.join
addItem = xbmcplugin.addDirectoryItem
setcontent = xbmcplugin.setContent
directory = xbmcplugin.endOfDirectory
resolve = xbmcplugin.setResolvedUrl

dialog = xbmcgui.Dialog()
numeric_input = xbmcgui.INPUT_NUMERIC
item = xbmcgui.ListItem

addonDir = transPath(addonInfo('path'))
iconsDir = transPath(joinPath(addonDir, 'resources', 'images'))
libDir = transPath(joinPath(addonDir, 'resources', 'lib'))

addon_data_dir = transPath(Addon.getAddonInfo('profile'))
cacheDir = transPath(joinPath(addon_data_dir, 'cache'))

playlistsFile = transPath(joinPath(addon_data_dir, 'playLists.txt'))
vDirectoriesFile = transPath(joinPath(addon_data_dir, 'virtual_directoriesLists.txt'))
favoritesFile = transPath(joinPath(addon_data_dir, 'favorites.txt'))
default_folder_image = transPath(joinPath(iconsDir, 'folder.png'))
default_list_image = transPath(joinPath(iconsDir, 'list.png'))

tvdb_path = joinPath(cacheDir, 'TVDB')
tmdb_path = joinPath(cacheDir, 'TMDB')
makeGroups = Addon.getSetting('makeGroups') == 'true'
cache = Addon.getSetting('cache') == 'true'
cachetime = Addon.getSetting('cachetime')
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0'

def init_addon():
    if not os.path.exists(cacheDir): os.makedirs(cacheDir)
    if not (os.path.isfile(favoritesFile)): SaveList(favoritesFile, [])
    if not (os.path.isfile(vDirectoriesFile)): SaveList(vDirectoriesFile, [])


def logger(function, level=1):
    xbmc.log(f'###playlistloader###: {function}', level)

def get_file_name(url):
    return re.sub(r'[:/]', '_', url)

def get_temp_flie(url):
    return transPath(joinPath(addon_data_dir, get_file_name(url) + '.txt'))

def get_by_regex(regex, content: str) -> Union[str, None]:
    """Matches content by regex and returns the value captured by the first group, or None if there was no match

    :param regex: A compiled regex to match
    :type regex: re.Pattern
    :param content: The content on which the regex should be applied
    :type content: str
    :rtype: str, None
    """
    match = re.search(regex, content)
    return match[1] if match else None

def getLocaleString(string):
    try: string = int(string)
    except: return string
    try: string = str(Addon.getLocalizedString(string))
    except: string = Addon.getLocalizedString(string)
    return string

def openurl(url, headers={}, user_data={}, cookieJar=None, justCookie=False):
    #url = urllib.quote(url, ':/')
    if headers is not None: headers = {'User-Agent': UA}
    session = requests.Session()
    with session:
        session.headers.update(headers)
        if cookieJar is not None: session.cookies = cookieJar
        session.headers.update({'Accept-encoding': 'gzip'})
        if "User-Agent" not in session.headers.keys(): session.headers.update({'User-Agent': UA})
        if user_data: response = session.get(url, data=user_data, stream=True)
        else: response = session.get(url, stream=True)
        if justCookie:
            if "Set-Cookie" in response.headers: data = response.headers['Set-Cookie']
            else: data = None
        else:
            if "Content-Encoding" in response.headers.keys() and response.headers['Content-Encoding'] == 'gzip':
                data = bytes()
                for chunk in response.iter_content(chunk_size=1024):
                    data += chunk  # data.decode("utf-8").replace("\r", "")
            else:
                # data = response.text.replace("\r", "")
                data = response.content
    # response.close()
    return data

def ReadFile(fileName):
    try:
        if fileName.startswith('special'): fileName = transPath(fileName)
        with open(fileName, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        content = content.replace("\n\n", "\n")
        #f = xbmcvfs.File(fileName)
        #content = f.read().replace("\n\n", "\n")
        #f.close()
    except Exception as ex:
        logger(f'ReadFile Error: {str(ex)} in: {repr(fileName)}', 3)
        content = ''
        ReadFile(transPath(fileName))
    return content

def SaveFile(fileName, text):
    try:
        if not cache: return True
        if fileName.startswith('special'): fileName = transPath(fileName)
        with open(fileName, 'w', encoding='utf-8', errors='ignore') as f:
            content = f.write(text)
    except Exception as ex:
        logger(f'SaveFile {repr(fileName)} Error: {str(ex)}', 3)
        SaveFile(transPath(fileName), text)
        return False
    return True

def ReadList(fileName):
    try:
        if fileName.startswith('special'): fileName = transPath(fileName)
        # if not (os.path.isfile(fileName)): SaveList(fileName, [])
        with open(fileName, 'r', encoding='utf-8') as handle:
            content = json.load(handle)
    except Exception as ex:
        logger(f'ReadList Error: {str(ex)} in: {repr(fileName)}', 3)
        # if os.path.isfile(fileName):
        # shutil.copyfile(fileName, "{0}_bak.txt".format(fileName[:fileName.rfind('.')]))
        # executebuiltin('Notification({0}, Cannot read file: "{1}". \nBackup createad, {2}, {3})'.format(addonName, os.path.basename(fileName), 5000, icon))
        content = []
    return content

def isFileNew(file, deltaInSec):
    lastUpdate = 0 if not os.path.isfile(file) else int(os.path.getmtime(file))
    now = int(time.time())
    return False if (now - lastUpdate) > deltaInSec else True

def isFromCache(address, cache=cachetime):
    if address.startswith('http'):
        fileLocation = joinPath(cacheDir, get_file_name(address))
        retval = isFileNew(fileLocation, cache * 60)
    else: retval = isFileNew(address, cache * 60)
    return retval

def GetList(address, cache=cachetime):
    if address.startswith('http'):
        fileLocation = joinPath(cacheDir, get_file_name(address))
        fromCache = isFileNew(fileLocation, cache * 60)
        if fromCache: response = ReadFile(fileLocation)
        else:
            response = openurl(address).decode("utf-8")
            if cache > 0: SaveFile(fileLocation, response)
    else: response = ReadFile(address)
    return response

def get_ch_list(url, cache=cachetime, m3u2=True):
    file_location = joinPath(cacheDir, get_file_name(url))
    from_cache = isFileNew(file_location, cache * 60)
    tmpListFile = get_temp_flie(url)
    if from_cache and os.path.isfile(tmpListFile): return ReadList(tmpListFile)
    response = GetList(url, cache)
    ch_list = []
    if m3u2:
        channels = re.findall(r'#EXTINF:.*?(.*?)\n(.*?)\n', response)
        #channels = re.compile(r'#EXTINF:(.+?),(.*?)[\n\r]+([^\n]+)').findall(response)
        # logger(f'channels: {channels}')
        _title_regex = re.compile(r'''.*?tvg-name="(.*?)"|.*?tvg-id="(.*?)"''', flags=re.I)
        _title1_regex = re.compile(r'''(?!.*=\",?.*\")[,](.*?)$''', flags=re.I)
        _grop_title_regex = re.compile(r'''.*?group-title="(.*?)$|.*?group-title="(.*?)"''', flags=re.I)
        _logo_regex = re.compile(r'''tvg-logo="(.*?)"''', flags=re.I)
        _file_regex = re.compile(r"^[a-zA-Z]:\\((?:.*?\\)*).*\.[\d\w]{3,5}$|^(/[^/]*)+/?.[\d\w]{3,5}$")
        for item in channels:
            try:
                stream_link = None
                info = item[0]
                url = item[1]
                title = get_by_regex(_title_regex, info)
                gtitle = get_by_regex(_grop_title_regex, info)
                if not title and gtitle: title = gtitle
                if not title: title = get_by_regex(_title1_regex, info)
                logo = get_by_regex(_logo_regex, info)
                if url.startswith('http'): stream_link = url
                else: stream_link = get_by_regex(_file_regex, url)
                if stream_link: ch_list.append({'name': title, 'url': stream_link.strip(), 'image': logo})
                # print(f'title: {title} {stream_link}')
            except: logger(f'error item: {item}')
    else:
        matches = re.compile("^background=(.*?)$", re.I + re.M + re.U + re.S).findall(response)
        background = None if len(matches) < 1 else matches[0]
        ch_list = [{"background": background}]
        matches = re.compile('^type(.*?)#$', re.I + re.M + re.U + re.S).findall(response)
        for match in matches:
            item = re.compile('^(.*?)=(.*?)$', re.I + re.M + re.U + re.S).findall("type{0}".format(match))
            item_data = {}
            for field, value in item:
                item_data[field.strip().lower()] = value.strip()
            item_data['group'] = 'Main'
            ch_list.append(item_data)
    SaveList(tmpListFile, ch_list)
    return ch_list

def SaveDict(fileName, dict):
    try:
        with io.open(fileName, 'w', encoding='utf-8') as handle:
            handle.write(json.dumps(dict))
        success = True
    except Exception as ex:
        logger(f'SaveDict Error: {str(ex)} in: {repr(fileName)}', 3)
        success = False
    return success

def dictify(r, root=True):
    if root: return {r.tag: dictify(r, False)}
    d = copy(r.attrib)
    if r.text: d['_text'] = r.text
    for x in r.findall('./*'):
        if x.tag not in d:
            d[x.tag] = []
        d[x.tag].append(dictify(x, False))
    return d

def GetEncodeString(data):
    import chardet
    if isinstance(data, str): return data.encode('utf-8', 'ignore')
    try: data = data.decode(chardet.detect(data)['encoding']).encode('utf-8')
    except:
        try: data = data.encode('utf-8')
        except: pass
    return data

def strptime2(string_date, sformat):
    """
    Compat for datetime.
    """
    from datetime import datetime as dt
    try: res = dt.strptime(string_date, sformat)
    except TypeError: res = dt(*(time.strptime(string_date, sformat)[0:6]))
    return res


def plx2list(url, cache=cachetime):
    response = GetList(url, cache)
    matches = re.compile("^background=(.*?)$", re.I + re.M + re.U + re.S).findall(response)
    background = None if len(matches) < 1 else matches[0]
    chList = [{"background": background}]
    matches = re.compile('^type(.*?)#$', re.I + re.M + re.U + re.S).findall(response)
    for match in matches:
        item = re.compile('^(.*?)=(.*?)$', re.I + re.M + re.U + re.S).findall("type{0}".format(match))
        item_data = {}
        for field, value in item:
            item_data[field.strip().lower()] = value.strip()
        item_data['group'] = 'Main'
        chList.append(item_data)
    return chList

def epg2dict(url, cache=cachetime):
    eDict = {}
    fn = joinPath(cacheDir, get_file_name(url) + '.ebk')
    if isFromCache(url, cache):
        eDict = ReadList(fn)
        if not eDict: eDict = {}
    if not eDict:
        response = GetList(url, cache)
        try:
            root = ET.fromstring(response)
            doc = dictify(root)
            ID = 'id'
            SRC = 'src'
            CHANNEL = 'channel'
            START = 'start'
            STOP = 'stop'
            TEXT = '_text'

        except:
            return {}
        '''
            try:
                logger(str('*****'))


                data = StringIO(zlib.decompress(response))
                #data = gzip.GzipFile('', 'rb', 9, StringIO(response))
                content = data.read()
                doc = xmltodict.parse(content)

                url_file_handle=StringIO( response )
                logger(str(url_file_handle))
                gzip_file_handle = gzip.GzipFile(fileobj=url_file_handle)
                logger(str(gzip_file_handle))
                decompressed_data = gzip_file_handle.read()
                logger(str(decompressed_data))
                gzip_file_handle.close()
                doc = xmltodict.parse(decompressed_data)
            except:
                return {}
        '''

        nList = []
        dList = []
        pDict = {}
        for ch in doc['tv']['channel']:
            try:
                nList.append(GetEncodeString(ch['display-name'][TEXT]))
                try: dList.append((ch[ID], ch['icon'][0][SRC]))
                except: dList.append((ch[ID], ''))
            except:
                for dname in ch['display-name']:
                    nList.append(GetEncodeString(dname[TEXT]))
                    try: dList.append((ch[ID], ch['icon'][0][SRC]))
                    except: dList.append((ch[ID], ''))

        for prg in doc['tv']['programme']:
            if pDict.get(prg[CHANNEL]) is None: pDict[prg[CHANNEL]] = []
            else:
                try: pDict[prg[CHANNEL]].append((prg[START], prg[STOP], prg['title'][0][TEXT]))
                except: pass

        if len(nList):
            eDict['name'] = nList
            eDict['data'] = dList
            eDict['prg'] = pDict
        SaveDict(fn, eDict)
    return eDict

def DelFile(fileName):
    try:
        if os.path.isfile(fileName):
            os.unlink(fileName)
    except Exception as ex:
        logger(f'SaveDict Error: {str(ex)} in: {repr(fileName)}', 3)

def SaveList(fileName, chList):
    try:
        #logger(f'SaveList {repr(chList)} \n type chList: {type(chList)}', 3)
        with open(fileName, 'w', encoding='utf-8') as handle:
            handle.write(str(json.dumps(chList)))  # handle.write(json.dumps(chList, ensure_ascii=False))
        success = True
    except Exception as ex:
        logger(f'SaveList Error: {str(ex)} in: {repr(fileName)}', 3)
        success = False
    return success

def OKmsg(title, line1):
    dlg = xbmcgui.Dialog()
    dlg.ok(title, line1)

def notification(line1, time=5000, icon=icon, sound=False):
    if isinstance(line1, int): line1 = getLocaleString(line1)
    dialog.notification('playlistloader', line1, icon, time, sound)

def container_refresh():
    return executebuiltin('Container.Refresh')


class SmartRedirectHandler(urllib.request.HTTPRedirectHandler):
    def http_error_301(self, req, fp, code, msg, headers):
        result = urllib.request.HTTPRedirectHandler.http_error_301(self, req, fp, code, msg, headers)
        return result

    def http_error_302(self, req, fp, code, msg, headers):
        result = urllib.request.HTTPRedirectHandler.http_error_302(self, req, fp, code, msg, headers)
        return result

def getfinalurl(url):
    link = url
    try:
        opener = requests.Session()
        opener.headers.update({'User-Agent': UA})
        f = opener.get(url)
        link = f.url
        if link is None or link == '': link = url
    except Exception as ex:
        logger(str(ex), 3)
    return link

def opensettings(id=AddonID):
    return executebuiltin(f'Addon.OpenSettings({id})')

def GetKeyboardText(title='', defaultText=''):
    keyboard = xbmc.Keyboard(defaultText, title)
    keyboard.doModal()
    text = '' if not keyboard.isConfirmed() else keyboard.getText()
    return text

def searchTMDB(item_name):
    """
    Search for a movie / tvshow detail with The movie DB
    """
    api_key = Addon.getSetting('themoviedb_api_key')
    response = requests.get(f'https://api.themoviedb.org/3/search/movie?api_key={api_key}&query={item_name}')
    return response.json()

def getTheTvDbToken():
    username = Addon.getSetting('thetvdb_username')
    user_key = Addon.getSetting('thetvdb_user_key')
    api_key = Addon.getSetting('thetvdb_api_key')

    credentials = {'apikey': api_key, 'userkey': user_key, 'username': username}
    r = requests.post('https://api.thetvdb.com/login', json=credentials)
    if r.status_code != 200: return False
    response = r.json()
    return response['token']

def startTheTvDbScan(index, playlistsFile, token):
    """
    Scan a given playlist index with the tv db
    """
    search_series = 'https://api.thetvdb.com/search/series?%s'
    search_poster = 'https://api.thetvdb.com/series/%s/images/query?keyType=poster'
    search_fanarts = 'https://api.thetvdb.com/series/%s/images/query?keyType=fanart'
    images_route = 'https://www.thetvdb.com/banners/%s'

    # Checking base tvdb directory.
    if not os.path.exists(tvdb_path): os.mkdir(tvdb_path)

    tvdb_playlist_path = joinPath(tvdb_path, str(index))

    # Remove all previous scans.
    if os.path.exists(tvdb_playlist_path): shutil.rmtree(tvdb_playlist_path)

    os.mkdir(tvdb_playlist_path)
    chList = ReadList(playlistsFile)
    item = chList[index]
    url = item['url']
    content = get_ch_list(url, cache=0)

    groups = []
    groups_infos = {}
    groups_404 = []
    headers = {'Accept': 'application/json', 'Accept-Language': f'{Addon.getSetting("language_1").lower()}', 'Authorization': 'Bearer ' + token, 'User-agent': UA}

    # Preparing progress bar.
    progress = xbmcgui.DialogProgress()
    progress.create(Addon.getLocalizedString(32028))
    step = 1
    not_found = 0

    for movie_item in content:
        # Handling "Cancel" action.
        if progress.iscanceled(): break

        if not movie_item['group_title'] in groups:
            percent = (step * 100) / len(content)
            progress.update(int(percent), Addon.getLocalizedString(32029) + movie_item['group_title'])

            params = {'name': movie_item['group_title']}
            params = urlencode(params)
            res = requests.get(search_series % params, headers=headers)

            if not res.status_code == 200:
                # Then fallback language.
                headers['Accept-Language'] = 'en'
                res = requests.get(search_series % params, headers=headers)

            res = res.json()
            try:
                aired = res['data'][0]['firstAired'] if (
                            'firstAired' in res['data'][0] and len(res['data'][0]['firstAired']) > 0) else '1800-01-01'
                idx = -1
            except KeyError:
                # Nothing found.

                if not movie_item['group_title'] in groups_404:
                    not_found += 1
                    progress.update(int(percent), Addon.getLocalizedString(32030) + str(not_found))
                groups_404.append(movie_item['group_title'])
                continue

            for data in res['data']:
                cmp = data['firstAired'] if ('firstAired' in data and len(data['firstAired']) > 0) else '1800-01-01'
                dtcmp = strptime2(cmp, '%Y-%M-%d')
                if strptime2(aired, '%Y-%M-%d').date() <= dtcmp.date():
                    aired = cmp
                    idx += 1

            # Getting poster and fanarts.
            progress.update(int(percent), Addon.getLocalizedString(32029) + movie_item[
                'group_title'] + ' - ' + Addon.getLocalizedString(32031))
            poster = requests.get(search_poster % str(res['data'][idx]['id']), headers=headers)
            fanarts = requests.get(search_fanarts % str(res['data'][idx]['id']), headers=headers)

            if not poster.status_code == 200:
                # Fallback language for posters ... most of posters are availables in english.
                headers['Accept-Language'] = 'en'
                poster = requests.get(search_poster % str(res['data'][idx]['id']), headers=headers)

            poster = poster.json()
            try: poster = images_route % poster['data'][0]["thumbnail"]
            except KeyError: poster = ''

            if not fanarts.status_code == 200: fanarts = requests.get(search_fanarts % str(
                res['data'][idx]['id']), headers=headers)

            fanarts = fanarts.json()
            try: fanarts = [images_route % fanarts['data'][i]['fileName'] for i in range(len(fanarts['data']))]
            except KeyError: fanarts = []

            # Reset to the default language.
            headers['Accept-Language'] = Addon.getSetting('language_1').lower()

            # Registering values into an array.
            groups_infos[movie_item['group_title']] = {'overview': res['data'][idx][
                'overview'], 'firstAired': aired, 'poster': poster, 'fanarts': fanarts, 'tvdb_id': res['data'][idx][
                'id']}

            groups.append(movie_item['group_title'])

        progress.update(int(percent), Addon.getLocalizedString(32032) + movie_item['group_title'])
        step += 1

    progress.close()

    # Savin this list to json
    with open(joinPath(tvdb_playlist_path, 'groups.json'), 'w') as outfile:
        json.dump(groups_infos, outfile)

    with open(joinPath(tvdb_playlist_path, 'groups.json'), 'w') as outfile:
        json.dump(groups_infos, outfile)

    # item['name']
    """
    # UNCOMMENT FOR DEBUG ONLY !!!
    for info in groups_infos:
        logger('\n\n----------------------------------------------------------------------------', xbmc.LOGERROR)
        logger(f'---- Key : {groups_infos[info]['poster']}', xbmc.LOGERROR)
        logger(f'First Aired : {groups_infos[info]['firstAired']}', xbmc.LOGERROR)
        logger(f'tvdb_id : {groups_infos[info]['tvdb_id']}', xbmc.LOGERROR)
        logger(f'overview : {groups_infos[info]['overview']}', xbmc.LOGERROR)
        logger('----------------------------------------------------------------------------', xbmc.LOGERROR)
    """

def isScannedByTheTvDB(index):
    """
    Return true if this m3u was scanned with the tv db function.
    """
    return os.path.exists(joinPath(tvdb_path, str(index)))

def removeTheTvDBData(index):
    """
    Remove the tv db data for given playlist index.
    """
    shutil.rmtree(joinPath(tvdb_path, str(index)), ignore_errors=True)
    return True if not os.path.exists(joinPath(tvdb_path, str(index))) else False

def isScannedByTheMovieDB(index):
    """
    Return true if this m3u was scanned with the movie db function.
    """
    return os.path.exists(joinPath(tmdb_path, str(index)))

def removeTheMovieDBData(index):
    """
    Remove the movie db data for given playlist index.
    """
    shutil.rmtree(joinPath(tmdb_path, str(index)), ignore_errors=True)
    return True if not os.path.exists(joinPath(tmdb_path, str(index))) else False

def loadDataFromTheTvDB(index):
    """
    Load data from regisered the tv db nidex file
    """
    jfile = joinPath(tvdb_path, str(index))
    jfile = joinPath(jfile, 'groups.json')
    json_data = open(jfile).read()
    data = json.loads(json_data)
    return data

def loadDataFromTheMovieDB(index):
    """
    Same than above for the movie db
    """
    jfile = joinPath(tmdb_path, str(index))
    jfile = joinPath(jfile, 'groups.json')
    json_data = open(jfile).read()
    data = json.loads(json_data)
    return data

def searchMetaTVDBId(url, playlistsFile):
    """
    Search for the right meta id.
    """
    json_playlists = open(playlistsFile).read()
    data = json.loads(json_playlists)
    i = 0
    for playlist in data:
        if playlist['url'] == url:
            return i
        i += 1
    return None
