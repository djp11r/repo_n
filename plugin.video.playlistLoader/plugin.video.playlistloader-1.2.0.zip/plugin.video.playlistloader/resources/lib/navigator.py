# -*- coding: utf-8 -*-
# code by Avigdor and Nux007 (https://github.com/Nux007/Kodi-plugin.video.playlistLoader)

import os
import sys
import uuid as random

from datetime import datetime
from urllib.parse import quote_plus, urlencode
from dateutil import parser, tz
from resources.lib.common import Addon, cacheDir, default_folder_image, default_list_image, favoritesFile, getLocaleString, iconsDir, joinPath, logger, makeGroups, playlistsFile, vDirectoriesFile, get_temp_flie, cachetime
from resources.lib.common import ReadList, SaveList, GetKeyboardText, notification, container_refresh, dialog, numeric_input, item, addItem, directory, setcontent, resolve, get_ch_list, epg2dict, getfinalurl, get_file_name


def AddListItems(chList, addToVdir=True):
    cacheList = []
    i = 0

    for item in chList:
        mode = 1 if '.plx' in item['url'] else 2
        name = item['name']
        image = item.get('image') or default_list_image
        uuid4 = item['uuid']
        logos = item.get('logos', '')
        epg = item.get('epg', '')
        cacheMin = item.get('cache') or cachetime
        if item['url'].startswith('http'): cacheList.append(get_file_name(item['url']))
        AddDir(name.title(), item['url'], mode, image, logos, epg, index=i, uuid=uuid4, cacheMin=cacheMin, addToVdir=addToVdir)
        i += 1

    try:
        for the_file in os.listdir(cacheDir):
            file_path = joinPath(cacheDir, the_file)
            if os.path.isfile(file_path) and the_file not in cacheList: os.unlink(file_path)
    except Exception as ex:
        if not os.path.exists(cacheDir): os.makedirs(cacheDir)
        logger(f'AddListItems Error: {ex}', 3)


def Categories():
    """
    Main menu items.
    """

    # Displaying virtual directories.
    vDirs = ReadList(vDirectoriesFile)
    y = 0
    for vDir in vDirs:
        dir_icon = vDir.get('image') or default_folder_image
        AddDir(f'[COLOR green][B]{str(vDir["name"])}[/B][/COLOR]', f'{y}', 44, dir_icon, uuid=vDir['uuid'], isFolder=True)
        y += 1

    ignored = []
    for vdir in vDirs:
        if len(vdir['data']) > 0: ignored += vdir['data']
    i = 0
    chList = ReadList(playlistsFile)
    addList = []
    try:
        for uitem in chList:
            if 'uuid' in uitem and not uitem['uuid'] in ignored: addList.append(chList[i])
            i += 1
    except: addList = chList
    AddListItems(addList)
    AddDir('Favorites', 'favorites', 30, joinPath(iconsDir, 'favourites.png'))
    AddDir('Add a new list', 'newList', 20, joinPath(iconsDir, 'newlist.png'), isFolder=False)
    AddDir('Add new directory', 'newDirectory', 43, joinPath(iconsDir, 'new.png'), isFolder=False)
    AddDir('Settings', 'setting', 50, joinPath(iconsDir, 'settings.png'), isFolder=False)
    endDirectory()


def AddNewList():
    listName = GetKeyboardText('List name').strip()
    if len(listName) < 1: return
    listUrl = GetChoice(30002, 30005, 30006, 30016, 30017, fileType=1, fileMask='.plx|.m3u|.m3u8')
    if len(listUrl) < 1: return
    image = GetChoice(30022, 30022, 30022, 30024, 30025, 30021, fileType=2)
    logosUrl = '' if listUrl.endswith('.plx') else GetChoice(30018, 30019, 30020, 30019, 30020, 30021, fileType=0)
    if logosUrl.startswith('http') and not logosUrl.endswith('/'): logosUrl += '/'
    epgUrl = '' if listUrl.endswith('.plx') else GetChoice(30046, 30047, 30048, 30047, 30048, 30021, fileType=1, fileMask='.xml')
    if epgUrl.startswith('http') and not epgUrl.endswith('/'): epgUrl += '/'
    # cacheInMinutes = GetNumFromUser(getLocaleString(30034), 60) if listUrl.startswith('http') else cachetime
    # if cacheInMinutes is None: cacheInMinutes = cachetime
    chList = ReadList(playlistsFile)
    for item in chList:
        if item['url'].lower() == listUrl.lower():
            notification(item['name'])
            return
    chList.append({'name': listName, 'url': listUrl, 'image': image, 'logos': logosUrl, 'epg': epgUrl, 'cache': cachetime, 'uuid': str(random.uuid4())})
    if SaveList(playlistsFile, chList): container_refresh()


def GetChoice(choiceTitle, fileTitle, urlTitle, choiceFile, choiceUrl, choiceNone=None, fileType=1, fileMask=None, defaultText=''):
    choice = ''
    choiceList = [getLocaleString(choiceFile), getLocaleString(choiceUrl)]
    if choiceNone is not None: choiceList = [getLocaleString(choiceNone)] + choiceList
    method = GetSourceLocation(getLocaleString(choiceTitle), choiceList)
    if choiceNone is None and method == 0 or choiceNone is not None and method == 1:
        if not defaultText.startswith('http'): defaultText = ''
        choice = GetKeyboardText(getLocaleString(fileTitle), defaultText).strip()
    elif choiceNone is None and method == 1 or choiceNone is not None and method == 2:
        if defaultText.startswith('http'): defaultText = ''
        choice = dialog.browse(fileType, getLocaleString(urlTitle), 'files', fileMask, False, False, defaultText)
    return choice


def RemoveFromLists(iuuid, listFile):
    # Removin the tv db and the movie db data first to ensure a clean file system.
    """
    if isScannedByTheTvDB(index):
        removeTheTvDBData(index)

    if isScannedByTheMovieDB(index):
        removeTheMovieDBData(index)
    """
    chList = ReadList(listFile)
    vDirsList = ReadList(vDirectoriesFile)
    i = 0
    for playlist in chList:
        if playlist['uuid'] == iuuid:
            del chList[i]
        i += 1
    # Removing from vdir lists.
    for vDir in vDirsList:
        i = 0
        for uuid4 in vDir['data']:
            if iuuid in uuid4:
                del vDir['data'][i]
            i += 1
    SaveList(listFile, chList)
    SaveList(vDirectoriesFile, vDirsList)
    container_refresh()


def RemoveFromFavourites(index):
    favList = ReadList(favoritesFile)
    if index < 0 or index >= len(favList): return
    del favList[index]
    SaveList(favoritesFile, favList)
    container_refresh()


def PlxCategory(url, cache):
    tmpList = []
    chList = get_ch_list(url, cache, False)
    background = chList[0]['background']
    for channel in chList[1:]:
        iconimage = '' if not channel.has_key('thumb') else channel['thumb']
        name = channel['name']
        if channel['type'] == 'playlist': AddDir(f'[{str(name)}]', channel['url'], 1, iconimage, background=background)
        else:
            AddDir(name, channel['url'], 3, iconimage, isFolder=False, IsPlayable=True, background=background)
            tmpList.append({'url': channel['url'], 'image': iconimage, 'name': str(name)})
    SaveList(get_temp_flie(url), tmpList)
    endDirectory()


def m3uCategory(url, logos, epg, cache, mode, gListIndex=-1):
    """
    meta_id = searchMetaTVDBId(url, playlistsFile)
    if not meta_id is None:
        if isScannedByTheTvDB(meta_id):
            meta = loadDataFromTheTvDB(meta_id)

    elif isScannedByTheMovieDB(gListIndex):
        meta = loadDataFromTheMovieDB(gListIndex)
    """
    meta = None
    tmpList = []
    chList = get_ch_list(url, cache)
    if (mode == 2 or mode == 10) and epg is not None and epg != '':
        epgDict = epg2dict(epg, cache=720)
        dnow = datetime.now(tz.UTC)
        to_zone = tz.tzlocal()
        use_percent = 'true'
        use_time = 'true'
    else: epgDict = {}

    #logger('EPGDICT')
    #logger(str(epgDict))
    groupChannels = []

    for channel in chList:
        if makeGroups: matches = [groupChannels.index(x) for x in groupChannels if len(x) > 0 and x[0].get('group_title', x[0]['name']) == channel.get('group_title', channel['name'])]
        if makeGroups and len(matches) == 1: groupChannels[matches[0]].append(channel)
        else: groupChannels.append([channel])

    for channels in groupChannels:
        idx = groupChannels.index(channels)
        if gListIndex > -1 and gListIndex != idx: continue
        isGroupChannel = gListIndex < 0 and len(channels) > 1
        chs = [channels[0]] if isGroupChannel else channels

        #logger(f'chs: {chs}')
        for channel in chs:
            # name = GetEncodeString(channel['name']) if not isGroupChannel else GetEncodeString(channel.get('group_title', channel['name']))
            name = channel['name'] if not isGroupChannel else channel.get('group_title', channel['name'])
            plot = '' if meta is None else meta[channel['group_title']]['overview'] if channel['group_title'] in meta else ''
            fanart = channel.get('image')
            # fanart = '' if meta is None else meta[channel['group_title']]['fanarts'][0] if (channel['group_title'] in meta and len(meta[channel['group_title']]['fanarts']) > 0) else ''

            if isGroupChannel:
                name = f'{name}'
                chUrl = url
                try: image = channel['tvg_logo'] if meta is None else meta[channel['group_title']]['poster'] if channel['group_title'] in meta else channel['tvg_logo']
                except KeyError: image = channel.get('image') or 'DefaultTVShows.png'
                AddDir(name, url, 10, epg=epg, index=idx, iconimage=image, cacheMin=cache, plot=plot, fanart=fanart)
            else:
                chUrl = channel['url']
                image = channel.get('tvg_logo') or channel.get('logos') or channel.get('image')
                """
                if image == '' and epgDict:
                    if name.decode('utf-8') in epgDict.get(u'name'):
                        image = epgDict[u'data'][epgDict[u'name'].index(name.decode('utf-8'))][1]
                    if name in epgDict.get(u'name'):
                        image = epgDict[u'data'][epgDict[u'name'].index(name)][1]
                """
                if epgDict:
                    idx = None
                    id = None
                    if epgDict.get(u'name'):
                        if name in epgDict.get(u'name'): idx = epgDict[u'name'].index(name)
                        if image == '' and idx is not None: image = epgDict[u'data'][idx][1]
                        t2len = 0
                        title2nd = ''
                        edescr = ''
                        next = False
                        if idx is not None:
                            #logger(str( epgDict.get('prg').get(epgDict[u'data'][idx][0])))
                            if epgDict.get('prg').get(epgDict[u'data'][idx][0]):
                                for start, stop, title in epgDict.get('prg').get(epgDict[u'data'][idx][0]):
                                    stime = parser.parse(start)
                                    etime = parser.parse(stop)
                                    if stime <= dnow <= etime or next:
                                        ebgn = stime.astimezone(to_zone).strftime('%H:%M')
                                        eend = etime.astimezone(to_zone).strftime('%H:%M')
                                        if use_time == 'true':
                                            stmp = f'{ebgn}-{eend}'
                                            t2len += (len(stmp) + 1)
                                            if not next: title2nd += f' [COLOR FF00BB66]{stmp}[/COLOR]'
                                            else:  title2nd += f' {stmp}'
                                        title2nd += f' {title}'
                                        t2len += (len(title) + 1)
                                        title2nd = title2nd.replace('&quot;', '`').replace('&amp;', ' & ')
                                        if not t2len: t2len = len(name)
                                        if not next:
                                            plot += f'[B][COLOR FF0084FF]{ebgn}-{eend}[/COLOR]\n[COLOR FFFFFFFF] {title}[/COLOR][/B]'
                                            name = f'[B]{name.ljust(int(t2len * 1.65))}[/B]\n{title2nd}'
                                            next = True
                                        else:
                                            plot += f'[COLOR FF999999]\n\n{ebgn}-{eend} {title}[/COLOR]\n'
                                            next = False
                                            break
                                    elif dnow < stime and not next:
                                        break
                if logos is not None and logos != '' and image != '' and not image.startswith('http'):
                    image = logos + image
                AddDir(name, chUrl, 3, image, epg=epg, index=-1, isFolder=False, IsPlayable=True, plot=plot, fanart=fanart)
            tmpList.append({'url': chUrl, 'image': image, 'name': name})
    SaveList(get_temp_flie(url), tmpList)
    endDirectory()


def PlayUrl(name, url, iconimage=None):
    if url.startswith('acestream://'): url = f'plugin://program.plexus/?mode=1&url={url}&name={name}&iconimage={iconimage}'
    elif url.startswith('https://www.youtube.com'):
        auxurl = url[url.find('v=') + 2:]
        url = f'plugin://plugin.video.youtube/play/?video_id={auxurl}'
    else: url = getfinalurl(url)
    logger(f'--- Playing {name}. {url}', 2)
    listitem = item(path=url, offscreen=True)
    info_tag = listitem.getVideoInfoTag()
    info_tag.setMediaType('movie')
    info_tag.setTitle(str(name))
    listitem.setArt({'icon': iconimage})
    if '.mpd' in url:
        listitem.setProperty('inputstream', 'inputstream.adaptive')
        listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
    if iconimage is not None:
        try: listitem.setArt({'thumb': iconimage})
        except: listitem.setThumbnailImage(iconimage)
    resolve(int(sys.argv[1]), True, listitem)


def AddDir(name, url, mode, iconimage='', logos='', epg='', index=-1, uuid='0', isFolder=True, IsPlayable=False, background=None, cacheMin=cachetime, plot='', fanart='', addToVdir=True):
    urlParams = {'name': name, 'url': url, 'mode': mode, 'iconimage': iconimage, 'logos': logos, 'epg': epg, 'cache': cacheMin, 'uuid': uuid}
    liz = item(label=str(name), offscreen=True)
    info_tag = liz.getVideoInfoTag()
    info_tag.setMediaType('Video')
    info_tag.setTitle(str(name))
    info_tag.setPlot(plot)
    info_tag.setPlotOutline(plot)
    liz.setArt({'icon': iconimage})
    liz.setProperty('fanart_image', fanart)
    items = []

    listMode = 21  # Lists
    if IsPlayable: liz.setProperty('IsPlayable', 'true')
    if background is not None: liz.setProperty('fanart_image', background)
    if mode == 1 or mode == 2:
        items = [('Remove from Playlist Loader', f'RunPlugin({sys.argv[0]}?index={index}&mode=22&uuid={uuid})'), ('Rename', f'RunPlugin({sys.argv[0]}?index={index}&mode=23&uuid={uuid})'), ('Change source', f'RunPlugin({sys.argv[0]}?index={index}&mode=24&uuid={uuid})'), ('Change logo', f'RunPlugin({sys.argv[0]}?index={index}&mode=25&uuid={uuid})')]
        if mode == 2 and not url.endswith('.plx'):
            items.append(('Change channels logos source', f'RunPlugin({sys.argv[0]}?index={index}&mode=26&uuid={uuid})'))
            items.append(('Change / Remove EPG source', f'RunPlugin({sys.argv[0]}?index={index}&mode=29&uuid={uuid})'))
        if url.startswith('http'): items.append(('Change caching time of list', f'RunPlugin({sys.argv[0]}?index={index}&mode=28&uuid={uuid})'))
    elif mode == 3: items = [('Add to Playlist Loader favorites', f'RunPlugin({sys.argv[0]}?url={quote_plus(url)}&mode=31&iconimage={iconimage}&name={name}&uuid={uuid})')]
    elif mode == 32:
        items = [('Remove from Playlist Loader favorites', f'RunPlugin({sys.argv[0]}?index={index}&mode=33)'), ('Rename', f'RunPlugin({sys.argv[0]}?index={index}&mode=35)'), ('Change source', f'RunPlugin({sys.argv[0]}?index={index}&mode=36)'), ('Change logo', f'RunPlugin({sys.argv[0]}?index={index}&mode=37)')]
        listMode = 38 # Favourits
    elif mode == 44: items = [('Delete directory and content', f'RunPlugin({sys.argv[0]}?index={index}&mode=46&uuid={uuid})'), ('Delete directory and move contents to root', f'RunPlugin({sys.argv[0]}?index={index}&mode=47&uuid={uuid})')]

    """
    if isScannedByTheTvDB(index):
        tvdb_item = (getLocaleString(32033), f'XBMC.RunPlugin({sys.argv[0]}?index={index}&mode=42&move=0)')
    else:
        tvdb_item = (getLocaleString(30041), f'XBMC.RunPlugin({sys.argv[0]}?index={index}&mode=41&move=0)')
    """

    if mode == 1 or mode == 2 or mode == 32:
        items += [('Move up', f'RunPlugin({sys.argv[0]}?index={index}&mode={listMode}&move=-1&uuid={uuid})'), ('Move down', f'RunPlugin({sys.argv[0]}?index={index}&mode={listMode}&move=1&uuid={uuid})')]  #('Move to', 'RunPlugin({0}?index={1}&mode={2}&move=0&uuid={3})'.format(sys.argv[0], index, listMode, uuid))]
        if addToVdir: items += [('Add to existing directory', f'RunPlugin({sys.argv[0]}?index={index}&mode=45&move=-1&uuid={uuid})'),]

    if mode == 10: urlParams['index'] = index
    liz.addContextMenuItems(items)
    u = f'{sys.argv[0]}?{urlencode(urlParams)}'
    addItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)


def endDirectory(content=''):
    from sys import argv # some functions throw invalid handle -1 unless this is imported here.
    syshandle = int(argv[1])
    setcontent(syshandle, content) # some skins use their own thumb for things like "genres" when content type is set here
    directory(syshandle, cacheToDisc=True)


def GetSourceLocation(title, chList):
    return dialog.select(title, chList)


def AddFavorites(url, iconimage, name):
    # Checking if url already in list.
    favList = ReadList(favoritesFile)
    for item in favList:
        if item['url'].lower() == url.lower():
            notification(name)
            return

    chList = ReadList(get_temp_flie(url))
    for channel in chList:
        if channel['name'].lower() == name.lower():
            url = channel['url']
            iconimage = channel['image']
            break
    if not iconimage: iconimage = ''
    data = {'url': url, 'image': iconimage, 'name': name}
    favList.append(data)
    SaveList(favoritesFile, favList)
    notification(name)


def AddNewDirectory():
    dir_name = GetKeyboardText('Add new directory', 'My new directory name')
    dir_icon = dialog.browse(1, 'Select an icon for this directory (optional)', 'files')
    if dir_name != '':
        vDirs = ReadList(vDirectoriesFile)
        vDirs.append({'name': dir_name, 'data': [], 'icon': default_folder_image, 'uuid': str(random.uuid4())})
        SaveList(vDirectoriesFile, vDirs)
        container_refresh()


def AddToDirectory(playlist_uuid):
    # if vdir is none, ask to choose one
    vdirs = ReadList(vDirectoriesFile)
    svdir = dialog.select('Choose the directory were to attach this playlist', [item['name'] for item in vdirs])
    vdirs[svdir]['data'].append(playlist_uuid)
    SaveList(vDirectoriesFile, vdirs)
    container_refresh()


def DeleteDirectory(iuuid, with_contents=False):
    vDirs = ReadList(vDirectoriesFile)
    y = 0
    for vdir in vDirs:
        if vdir['uuid'] == iuuid:
            if with_contents:
                contents = ReadList(playlistsFile)
                i = 0
                uuids = vdir['data']
                uuids = [uuid4 for uuid4 in uuids]
                for content in contents:
                    if content['uuid'] in uuids: del contents[i]
                    i += 1
                SaveList(playlistsFile, contents)
            del vDirs[y]
            SaveList(vDirectoriesFile, vDirs)
            container_refresh()
        y += 1


def ShowDirectoryContents(directory_uuid):
    vDirs = ReadList(vDirectoriesFile)
    dirFiles = lsDir(directory_uuid)
    if dirFiles is None: return
    chList = ReadList(playlistsFile)
    lPlaylists = []
    for pUuid in dirFiles:
        for playlist in chList:
            if pUuid == playlist['uuid']: lPlaylists.append(playlist)
    AddListItems(lPlaylists, addToVdir=False)


def ListFavorites():
    AddDir(f'[COLOR yellow][B]Add a new channel[/B][/COLOR]', 'favorites', 34, joinPath(iconsDir, 'favourites.png'), isFolder=False)
    chList = ReadList(favoritesFile)
    i = 0
    for channel in chList:
        AddDir(channel['name'], channel['url'], 32, channel['image'], index=i, isFolder=False, IsPlayable=True)
        i += 1
    endDirectory()


def AddNewFavorite():
    chName = GetKeyboardText('Channel name')
    if len(chName) < 1: return
    chUrl = GetKeyboardText('Channel URL')
    if len(chUrl) < 1: return
    image = GetChoice(30023, 30023, 30023, 30024, 30025, 30021, fileType=2)
    favList = ReadList(favoritesFile)
    for item in favList:
        if item['url'].lower() == chUrl.lower():
            notification(chName)
            return
    data = {'url': chUrl, 'image': image, 'name': chName}
    favList.append(data)
    if SaveList(favoritesFile, favList): container_refresh()


def GetPlaylistIndex(iuuid, listFile):
    chList = ReadList(listFile)
    i = 0
    for playlist in chList:
        if playlist['uuid'] == iuuid: return i
        i += 1


def lsDir(iuuid):
    chDirs = ReadList(vDirectoriesFile)
    for vdir in chDirs:
        if vdir['uuid'] == iuuid: return vdir['data']
    return None


def ChangeKey(iuuid, listFile, key, title, favourites=False):
    chList = ReadList(listFile)
    index = GetPlaylistIndex(iuuid, listFile) if not favourites else iuuid
    chListstr = GetKeyboardText(title, chList[index][key])
    if len(chListstr) < 1: return
    chList[index][key] = chListstr
    if SaveList(listFile, chList): container_refresh()


def ChangeChoice(iuuid, listFile, key, choiceTitle, fileTitle, urlTitle, choiceFile, choiceUrl, choiceNone=None, fileType=1, fileMask=None, favourites=False):
    index = GetPlaylistIndex(iuuid, listFile) if not favourites else iuuid
    chList = ReadList(listFile)
    defaultText = chList[index].get(key, '')
    option = GetChoice(choiceTitle, fileTitle, urlTitle, choiceFile, choiceUrl, choiceNone, fileType, fileMask, defaultText)
    if key == 'url' and len(option) < 1: return
    elif key == 'logos' and option.startswith('http') and not option.endswith('/'): option += '/'
    chList[index][key] = option
    if SaveList(listFile, chList): container_refresh()


def MoveInFavourites(index, step):
    theList = ReadList(favoritesFile)
    if index + step >= len(theList) or index + step < 0: return
    if step == 0: step = GetIndexFromUser(len(theList), index)
    if step < 0: tempList = theList[0:index + step] + [theList[index]] + theList[index + step:index] + theList[index + 1:]
    elif step > 0: tempList = theList[0:index] + theList[index + 1:index + 1 + step] + [theList[index]] + theList[index + 1 + step:]
    else: return
    SaveList(favoritesFile, tempList)
    container_refresh()


def MoveInList(iuuid, step, listFile):
    def moveOnPlaylist(index, step, tList):
        tempList = None
        if index + step >= len(tList) or index + step < 0: return None
        if step == 0: step = GetIndexFromUser(len(tList), index)
        if step < 0: tempList = tList[0:index + step] + [tList[index]] + tList[index + step:index] + tList[index + 1:]
        elif step > 0: tempList = tList[0:index] + tList[index + 1:index + 1 + step] + [tList[index]] + tList[index + 1 + step:]
        else: return None
        return tempList

    theList = ReadList(listFile)

    # Checking that playlist is not in a directory.
    dir = False
    vdirs = ReadList(vDirectoriesFile)
    for vdir in vdirs:
        uuids4 = [uuid4 for uuid4 in vdir['data']]
        if iuuid in uuids4: dir = vdir

    if not dir is False:
        # Moving two sides, directories and global list ( in case of directory removal )
        dirFiles = lsDir(dir['uuid'])

        ffiles = [tfile for tfile in theList if tfile['uuid'] in dirFiles]
        rfiles = [tfile for tfile in theList if tfile['uuid'] not in dirFiles]
        ffiles = moveOnPlaylist(dirFiles.index(iuuid), step, ffiles)

        if not ffiles is None: SaveList(listFile, rfiles + ffiles)

        # Movin it directory side.
        idx = vdirs.index(vdir)
        vdir['data'] = [item['uuid'] for item in ffiles]
        vdirs[idx] = vdir
        SaveList(vDirectoriesFile, vdirs)

    else:
        dirFiles = [item for data in vdirs for item in lsDir(data['uuid'])]
        dirItems = [playlist for playlist in ReadList(listFile) if playlist['uuid'] in dirFiles]
        notDirFiles = [playlist for playlist in ReadList(listFile) if not playlist['uuid'] in dirFiles]

        idx = 0
        for playlist in notDirFiles:
            if playlist['uuid'] == iuuid: break
            idx += 1

        ffiles = moveOnPlaylist(idx, step, notDirFiles)
        if not ffiles is None: SaveList(listFile, dirItems + ffiles)
    container_refresh()

    """
    # Moving themoviedb and thetvdb data if any.
    if isScannedByTheTvDB(index):
        removeTheTvDBData(index)
        OKmsg("The TV Db", 'Show groups in channels lists')

    if isScannedByTheMovieDB(index):
        removeTheMovieDBData(index)
        OKmsg("The TV Db", 'Yes')
    """


def GetNumFromUser(title, defaultt=''):
    choice = dialog.input(title, defaultt=defaultt, type=numeric_input)
    return None if choice == '' else int(choice)


def GetIndexFromUser(listLen, index):
    location = GetNumFromUser(f'Select a new location (1-{listLen})')
    return 0 if location is None or location > listLen or location <= 0 else location - 1 - index


def ChangeCache(iuuid, listFile):
    index = GetPlaylistIndex(iuuid, listFile)
    chList = ReadList(listFile)
    defaultText = chList[index].get('cache', 0)
    # cacheInMinutes = GetNumFromUser('Select minutes for cache the list on disc', str(defaultText)) if chList[index].get('url', '0').startswith('http') else cachetime
    # if cacheInMinutes is None: return
    chList[index]['cache'] = cachetime
    if SaveList(listFile, chList): container_refresh()


def ToggleGroups():
    notMakeGroups = 'false' if makeGroups else 'true'
    Addon.setSetting('makeGroups', notMakeGroups)
    container_refresh()
