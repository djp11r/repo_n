# -*- coding: UTF-8 -*-

import re
import sys
import traceback

from urllib.parse import quote_plus

MENU_ICON = "DefaultAddonProgram.png"


def setView(content, viewType):
    from modules.control import getSetting, getKodiVersion, execute, getCurrentViewId, skin, log
    if content:
        content(int(sys.argv[1]), content)
    if getSetting('auto-view') == 'true':
        views = getSetting('viewType2')
        if views == '50' and getKodiVersion >= 17 and skin == 'skin.estuary':
            views = '55'
        if views == '500' and getKodiVersion >= 17 and skin == 'skin.estuary':
            views = '50'
        log(f"@@@@@@@@@  views {views}")
        return execute(f"Container.SetViewMode({views})")
    else:
        views = getCurrentViewId()
        log(f"@@@@@@@@@ get  views {views}")
        return execute(f"Container.SetViewMode({views})")


def CreateDir(name, url, action, icon, fanart, description, isFolder=False):
    from modules.control import setting, sysaddon, addItem, make_listitem
    CustomColor = setting('my_ColorChoice')
    if CustomColor == '':
        CustomColor = 'none'
    if icon is None or icon == '':
        icon = MENU_ICON
    u = sys.argv[0] + "?url=" + quote_plus(url) + "&action=" + str(action) + "&name=" + quote_plus(name) + "&icon=" + quote_plus(icon) + "&fanart=" + quote_plus(fanart) + "&description=" + quote_plus(description)
    # ok = True
    cm = []
    cm.append(('jp Tools Settings', f'RunPlugin({sysaddon}?action=settings&query=(4.0))'))
    name = f'[COLOR {CustomColor}][B]{name}[/B][/COLOR]'
    listitem = make_listitem()
    listitem.setLabel(name)
    listitem.setArt({'poster': "DefaultAddonProgram.png", 'icon': icon, 'thumb': icon})
    listitem.addContextMenuItems(cm)
    listitem.setInfo('video', {'title': name, 'Plot': description})
    # liz.setProperty("Fanart_Image", fanart)
    ok = addItem(handle=int(sys.argv[1]), url=u, listitem=listitem, isFolder=isFolder)
    return ok


def MAIN_MENU():
    from modules.control import AddonFanart, execute, getSettingEnabled, AddonIcon, AddonTitle, endOfdirectory
    # setView('addons', 'views')
    execute(f"Container.SetViewMode({'55'})")
    if getSettingEnabled('navi.dev'):
        CreateDir('Testing dialog', 'url', 'testtingd', MENU_ICON, AddonFanart, '', isFolder=True)
    # if getSettingEnabled('navi.maintenance'):
    if getSettingEnabled('navi.m_menu'):
        CreateDir('ETools', 'url', 'm_menu', AddonIcon, AddonFanart, '', isFolder=True)
        CreateDir('File DL', 'url', 'perso_m', MENU_ICON, AddonFanart, '', isFolder=True)
    if getSettingEnabled('navi.apks'):
        CreateDir('Apk DL', 'url', 'applist_m', MENU_ICON, AddonFanart, '', isFolder=True)
    CreateDir('Maintenance', 'url', 'maintenance', MENU_ICON, AddonFanart, 'Maintenance Menu.', isFolder=True)
    if getSettingEnabled('navi.tools'):
        CreateDir('Tools', 'url', 'tools', MENU_ICON, AddonFanart, 'Tools Menu.', isFolder=True)
    if getSettingEnabled('navi.utils'):
        CreateDir('Utilities', 'url', 'utilities', MENU_ICON, AddonFanart, 'Utilities Menu.', isFolder=True)
    # if getSettingEnabled('navi.settings'):
    CreateDir('Settings', 'url', 'settings', MENU_ICON, AddonFanart, f'{AddonTitle} Settings.')
    if getSettingEnabled('navi.logs'):
        CreateDir('Logs', 'url', 'log_tools', MENU_ICON, AddonFanart, 'Debug Logs Menu.')
    if getSettingEnabled('navi.changelog'):
        CreateDir('ChangeLog', 'url', 'changeLog', MENU_ICON, AddonFanart, f'{AddonTitle} ChangeLog.')
    endOfdirectory(int(sys.argv[1]), cacheToDisc=True)


def MAINTENANCE():
    from modules.control import AddonFanart, endOfdirectory
    # setView('addons', 'views')  # descriptions left as template while i think i about adding stats to these options.
    CreateDir('Clear All (Cache, Packages, Thumbnails)', 'url', 'clear_ALL', MENU_ICON, AddonFanart, 'description')
    CreateDir('Clear Cache', 'url', 'deleteCache', MENU_ICON, AddonFanart, 'description')
    CreateDir('Clear Packages', 'url', 'deletePackages', MENU_ICON, AddonFanart, 'description')
    CreateDir('Clear Thumbnails', 'url', 'clearThumb', MENU_ICON, AddonFanart, 'description')
    CreateDir('[I]Clear Resolvers Cache[/I]', 'url', 'reset_ResolversCache', MENU_ICON, AddonFanart, 'description')
    CreateDir('[I]Clear Empty Folders[/I]', 'url', 'clearEmptyFolders', MENU_ICON, AddonFanart, 'description')
    endOfdirectory(int(sys.argv[1]))


def TOOLS():
    from modules.control import AddonFanart, endOfdirectory
    # setView('addons', 'views')
    CreateDir('Backup/Restore', 'url', 'backup_restore', MENU_ICON, AddonFanart, 'Backup and Restore Menu.')
    CreateDir('AdvancedSettings', 'url', 'advancedSettings', MENU_ICON, AddonFanart, 'Advanced Settings Menu.')
    CreateDir('Net Info', 'url', 'netINFO', MENU_ICON, AddonFanart, 'View Device Net Info.', isFolder=True)
    CreateDir('Kodi ShortCuts', 'url', 'kodishortz', MENU_ICON, AddonFanart, 'Useful Kodi Shortcuts to speed up Setup.')
    CreateDir('Kodi DB ShortCuts', 'url', 'kodiDBshortz', MENU_ICON, AddonFanart, 'Kodi Shortcuts for DB Stuff.')
    CreateDir('Builds/Wizards', 'url', 'builds', MENU_ICON, AddonFanart, 'Builds and Wizards Menu.', isFolder=True)
    endOfdirectory(int(sys.argv[1]))


def UTILITIES():
    from modules.control import AddonFanart, endOfdirectory
    # setView('addons', 'views')
    CreateDir('SpeedTest', 'url', 'speedTest', MENU_ICON, AddonFanart, 'Run a SpeedTest real quick.')
    CreateDir('Check Sources', 'url', 'checkSources', MENU_ICON, AddonFanart, 'Check for any Broken Sources.')
    CreateDir('Check Repos', 'url', 'checkRepos', MENU_ICON, AddonFanart, 'Check for any Broken Repos.')
    CreateDir('Check for Updates (ALL)', 'url', 'forceUpdate', MENU_ICON, AddonFanart, 'Check for any new Updates.')
    CreateDir('Disable AutoUpdates(Notify but dont install)', 'url', 'disableAutoUpdates', MENU_ICON, AddonFanart, 'Set AutoUpdates To Notify but not Auto Intsall.')
    CreateDir('Enable Unknown Sources', 'url', 'enableUnknownSources', MENU_ICON, AddonFanart, 'Enable Unknown Sources.')
    CreateDir('Enable Addons (ALL)', 'url', 'enableAddons', MENU_ICON, AddonFanart, 'Enable All Addons.')
    endOfdirectory(int(sys.argv[1]))


def BUILDS():
    from modules.control import AddonFanart, setting, getSetting, endOfdirectory
    # setView('addons', 'views')
    CreateDir('Kodi Version Check', 'url', 'getKodiVersion', MENU_ICON, AddonFanart, 'Check My Kodi Version.')
    CreateDir('Current Profile Check', 'url', 'checkCurrentProfile', MENU_ICON, AddonFanart, 'Check My Current Profile.')
    wizard1 = setting('enable_wiz1')
    if wizard1 != 'false':
        try:
            name = getSetting('name1')
            url = getSetting('url1')
            img = getSetting('img1')
            fanart = getSetting('img1')
            CreateDir(f'[Wizard] {name}', url, 'install_build', img, fanart, 'My Custom Build.', isFolder=False)
        except:
            pass
    wizard2 = setting('enable_wiz2')
    if wizard2 != 'false':
        try:
            name = getSetting('name2')
            url = getSetting('url2')
            img = getSetting('img2')
            fanart = getSetting('img2')
            CreateDir(f'[Wizard] {name}', url, 'install_build', img, fanart, 'My Custom Build.', isFolder=False)
        except:
            pass
    wizard3 = setting('enable_wiz3')
    if wizard3 != 'false':
        try:
            name = getSetting('name3')
            url = getSetting('url3')
            img = getSetting('img3')
            fanart = getSetting('img3')
            CreateDir(f'[Wizard] {name}', url, 'install_build', img, fanart, 'My Custom Build.', isFolder=False)
        except:
            pass
    CreateDir('[I]Swap Skin[/I]', 'url', 'skinSWAP', MENU_ICON, AddonFanart, 'Swap to Default Skin.')
    CreateDir('[I]Force Close Kodi[/I]', 'url', 'Force_Close', MENU_ICON, AddonFanart, 'Force Close Kodi.')
    CreateDir('[I]Reload Skin[/I]', 'url', 'reloadMySkin', MENU_ICON, AddonFanart, 'Reload Current Skin.')
    CreateDir('[I]Reload Profile[/I]', 'url', 'reloadProfile', MENU_ICON, AddonFanart, 'Reload My User Profile.')
    CreateDir('[I]Fresh Start[/I]', 'url', 'fresh_start', MENU_ICON, AddonFanart, 'Wipe Kodi like a Factory Reset.')
    CreateDir('Wizard Settings', 'url', 'wizSettings', MENU_ICON, AddonFanart, 'Open up Wizard Settings.')
    endOfdirectory(int(sys.argv[1]), cacheToDisc=True)


def perso_m():
    from modules.control import infoDialog, log, endOfdirectory
    from modules.utilz import workingURL, OPEN_URL
    import json
    p_file_url = 'https://raw.githubusercontent.com/djp11r/repo_n/mayb/etc/allxml/perso_file.json'
    if not workingURL(p_file_url):
        infoDialog('Error to get p_file ...')
    data = OPEN_URL(p_file_url).text
    data = json.loads(data)
    for item in data:
        if item['section'] == 'custom':
            CreateDir(item['name'], item['url'], 'myinstall', item['icon'], item['fanart'], item['description'], isFolder=False)
    endOfdirectory(int(sys.argv[1]), cacheToDisc=True)


def applist():
    from modules.control import infoDialog, endOfdirectory, log
    from modules.utilz import workingURL, OPEN_URL
    import json
    from modules.traktit import get_kodi_frm_enet
    p_file_url = 'https://raw.githubusercontent.com/djp11r/repo_n/mayb/etc/allxml/apks.json'
    if not workingURL(p_file_url):
        infoDialog('Error to get p_file ...')
    try:
        data = OPEN_URL(p_file_url).text
        data = json.loads(data)
        kodiapp_list = get_kodi_frm_enet()
        # log(f'data: {repr(data)} ==')
        # log(f'data: {repr(data + kodiapp_list)} ==')
        data = data + kodiapp_list
        for item in data:
            # log(f'item {item["name"]} ==')
            item_name = f"{item['name']} v{item.get('version', '')}"
            mode = item.get('mode', 'appinstall')
            CreateDir(item_name, item['url'], mode, item['icon'], item['fanart'], item['description'], isFolder=False)
        endOfdirectory(int(sys.argv[1]))
    except:
        log(f"Error applist: {traceback.format_exc()}")


def m_menu():
    from modules.control import AddonFanart, endOfdirectory
    # setView('addons', 'views')
    CreateDir('Get Addon from Enet', 'url', 'get_adon_frm_enet', MENU_ICON, AddonFanart, 'get Addon from enet.')
    CreateDir('Get setting files from ENET', 'url', 'get_setting_enet', MENU_ICON, AddonFanart, 'Get setting files to ENET.')
    CreateDir('View Log File', 'url', 'viewlog', MENU_ICON, AddonFanart, 'View Log.')
    CreateDir('Clean Log File', 'url', 'clean_log_file', MENU_ICON, AddonFanart, 'Clean Log File.')
    CreateDir('Send setting files to ENET', 'url', 'send_setting_enet', MENU_ICON, AddonFanart, 'Send setting files to ENET.')
    CreateDir('Send kodi Log to ENET', 'url', 'send_kodi_log_enet', MENU_ICON, AddonFanart, 'Send kodi Log to ENET.')
    CreateDir('Reset setting', 'url', 'reset_upd_setting', MENU_ICON, AddonFanart, 'Reset setting To default.')
    CreateDir('All Errors', 'url', 'errorChecking', MENU_ICON, AddonFanart, 'All Errors in log file.')
    CreateDir('Convert path to special', 'url', 'FIX_SPECIAL', MENU_ICON, AddonFanart, 'Convert path to special.')
    CreateDir('Extract zip', 'url', 'zipextr', MENU_ICON, AddonFanart, 'extract zip in packag folder.')
    CreateDir('Clear Old Thumbs', 'url', 'deleteold_Thumbnails', MENU_ICON, AddonFanart, 'Clear Old Thumbs.')
    CreateDir('Clean addon_data folders', 'url', 'clane_adondata', MENU_ICON, AddonFanart, 'Clean addon_data folders.')
    CreateDir('Clean All Log File', 'url', 'clean_all_log_file', MENU_ICON, AddonFanart, 'Clean All Log File.')
    CreateDir('Save userdata n zip', 'url', 'get_userdata', MENU_ICON, AddonFanart, 'Save userdata n zip.')
    CreateDir('DNS Leak Test', 'url', 'dns_leak_test', MENU_ICON, AddonFanart, 'DNS Leak Test.')
    CreateDir('You Tube API update', 'url', 'set_api', MENU_ICON, AddonFanart, 'You Tube API update.')
    endOfdirectory(int(sys.argv[1]))
