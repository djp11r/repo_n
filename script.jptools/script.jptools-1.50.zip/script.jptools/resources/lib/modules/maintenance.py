# -*- coding: utf-8 -*-


from modules.control import joinPath, transPath


def clean_oldlog(mode='verbose'):
    from os import listdir
    from modules.control import logpath, infoDialog, log
    logfilepath = listdir(logpath)
    # log(f'logfilepath: {logfilepath}')
    try:
        for item in logfilepath:
            # if item.endswith('.log'):
            if item.endswith('.log') and item not in ['kodi.log', 'kodi.old.log']:
                # log(f'item to clean: {item}')
                l_file = joinPath(logpath, item)
                # log(f'item to clean: {l_file}')
                with open(l_file, 'w') as logFile:
                    logFile.write('')
        if mode == 'verbose': infoDialog('Clean Old log files Completed.')
    except Exception as e:
        log(f"clean_oldlog Error: {str(e)}")  # return


class cacheEntry(object):
    def __init__(self, namei, pathi):
        self.name = namei
        self.path = pathi

    def setupCacheEntries(self):
        entries = 5  #make sure this refelcts the amount of entries you have
        dialogName = ["WTF", "4oD", "BBC iPlayer", "Simple Downloader", "ITV"]
        pathName = ["special://profile/addon_data/plugin.video.whatthefurk/cache", "special://profile/addon_data/plugin.video.4od/cache", "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache", "special://profile/addon_data/script.module.simple.downloader", "special://profile/addon_data/plugin.video.itv/Images"]
        cacheEntries = []
        for x in range(entries):
            cacheEntries.append(cacheEntry(dialogName[x], pathName[x]))
        return cacheEntries


def clearCache(mode='verbose'):
    from modules.control import condVisibility, getSettingEnabled, existsPath, infoDialog
    tempPath = transPath('special://temp')
    tempPath2 = transPath('special://addons/temp')
    cachePath = joinPath(transPath('special://home'), 'cache')
    if existsPath(cachePath) is True and getSettingEnabled('tune.cachePath') is True:
        total_files, total_folds = cleanfolder(cachePath)
        file_count = total_files + total_folds
        if mode == 'verbose':
            infoDialog(f'Clean cache Completed [ {file_count:d} ]')

    if existsPath(tempPath):
        total_files, total_folds = cleanfolder(tempPath)
        file_count = total_files + total_folds
        if mode == 'verbose':
            infoDialog(f'Clean temp Completed [ {file_count:d} ]')
    if existsPath(tempPath2):
        total_files, total_folds = cleanfolder(tempPath2)
        file_count = total_files + total_folds

    if condVisibility('system.platform.ATV2'):
        atv2_cache_a = joinPath('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        total_files, total_folds = cleanfolder(atv2_cache_a)
        file_count = total_files + total_folds

        atv2_cache_b = joinPath('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        total_files, total_folds = cleanfolder(atv2_cache_b)
        file_count += total_files + total_folds

        if mode == 'verbose':
            infoDialog(f'Clean Caches Completed [ {file_count:d} ]')

    cacheEntries = []
    file_count = 0
    for entry in cacheEntries:
        clear_cache_path = transPath(entry.path)
        if existsPath(clear_cache_path) == True and getSettingEnabled('tune.cacheEntries') == True:
            total_files, total_folds = cleanfolder(clear_cache_path)
            file_count += total_files + total_folds
            if mode == 'verbose':
                infoDialog(f'Clean Caches Completed [ {file_count:d} ]')
    if mode == 'verbose':
        infoDialog('Clean Cache Completed.')


def O_deleteThumbnails(mode='verbose'):
    from os import walk, unlink
    import shutil
    from modules.control import getSettingEnabled, existsPath, infoDialog, databasepath
    thumbnailPath = transPath('special://thumbnails')
    THUMBS = transPath(joinPath('special://home/userdata/Thumbnails', ''))
    if existsPath(thumbnailPath):
        if getSettingEnabled('tune.thumbs1'):
            #if yesnoDialog("Delete Thumbnails", "This option deletes all thumbnails", "Are you sure you want to do this?"):
            for root, dirs, files in walk(thumbnailPath):
                file_count = 0
                file_count += len(files)
                if file_count > 0:
                    for f in files:
                        try:
                            unlink(joinPath(root, f))
                        except:
                            pass
    if existsPath(THUMBS):
        try:
            if getSettingEnabled('tune.thumbs2'):
                for root, dirs, files in walk(THUMBS):
                    file_count = 0
                    file_count += len(files)
                    #Count files and give option to delete
                    if file_count > 0:
                        for f in files:
                            unlink(joinPath(root, f))
                        for d in dirs:
                            shutil.rmtree(joinPath(root, d))
        except:
            pass
    try:
        if getSettingEnabled('tune.thumbs3'):
            text13 = joinPath(databasepath, "Textures13.db")
            unlink(text13)
    except:
        pass
    if mode == 'verbose':
        infoDialog('Clean Thumbs Completed.')


def deleteold_Thumbnails(mode='verbose'):
    from modules.control import color2, deleteFile, oldthumb, existsPath, log, infoDialog, databasepath
    from os.path import getsize
    import sqlite3 as database
    THUMBS = transPath(joinPath('special://home/userdata/Thumbnails', ''))
    use = 30
    ids = []
    images = []
    size = 0
    dbfile = joinPath(databasepath, "Textures13.db")
    if existsPath(dbfile):
        try:
            textdb = database.connect(dbfile)
            textexe = textdb.cursor()
            log(f"[Clean Old Thumbnails] Cleaning thumbnails older than {str(oldthumb)}, or haven't been accessed at least {use} times.")
            textexe.execute("SELECT idtexture FROM sizes WHERE usecount < ? AND lastusetime < ?", (use, str(oldthumb)))
            found = textexe.fetchall()
            for rows in found:
                idfound = rows[0]
                ids.append(idfound)
                textexe.execute("SELECT cachedurl FROM texture WHERE id = ?", (idfound,))
                found2 = textexe.fetchall()
                for rows2 in found2:
                    images.append(rows2[0])
            for id in ids:
                textexe.execute("DELETE FROM sizes   WHERE idtexture = ?", (id,))
                textexe.execute("DELETE FROM texture WHERE id        = ?", (id,))
            try: textexe.execute("VACUUM")
            except Exception as err: log(f'err1: {repr(err)}')
            try: textdb.execute("VACUUM")
            except Exception as err: log(f'err2: {repr(err)}')
            textdb.commit()
            textexe.close()
            for image in images:
                path = joinPath(THUMBS, image)
                try:
                    imagesize = getsize(path)
                    deleteFile(path)
                    size += imagesize
                except:
                    pass
            removed = f"{size / 1024000.0:.0f}"
            log(f"{len(images)} total thumbs cleaned up. size: {removed}")
            if len(images) > 0:
                msg = f"[COLOR {color2}]Clear Thumbs: {len(images)} Files / {removed} MB[/COLOR]!"
            else:
                msg = f"[COLOR {color2}]Clear Thumbs: [COLOR red]Images : {len(images)}![/COLOR][/COLOR]"
            infoDialog(str(msg))
        except Exception as e:
            log(f"DB Connection Error: {str(e)}")
            return False
    else:
        log(f'{dbfile} not found.')
        return False


def purgePackages(mode='verbose'):
    from modules.control import infoDialog
    purgePath = transPath('special://home/addons/packages')
    total_files, total_folds = cleanfolder(purgePath)
    file_count = total_files + total_folds
    if mode == 'verbose':
        infoDialog(f'Clean Packages Completed [ {file_count:d} ]')


def clean_MyVideos_db(modify=False):
    from modules.control import log, databasepath
    import sqlite3 as database
    try:
        db_file = joinPath(databasepath, "MyVideos121.db")
        try:
            textdb = database.connect(db_file)
            cursor = textdb.cursor()
        except Exception as e:
            log(f"DB Connection Error: {str(e)}")
            return False
        q = "SELECT name FROM sqlite_master WHERE type='table'"
        # q = "SELECT name from sqlite_master where type= 'table' AND name NOT LIKE 'sqlite_%'"
        cursor.execute(q)
        tables_in_db = cursor.fetchall()
        for i in tables_in_db:
            if "path" in i[0]:
                log(i[0])
                find_delet = '%Z:\\ENet\\TVShow Subscriptions\\%'
                # q = "SELECT * FROM {} WHERE idParentPath IS NULL OR idParentPath = ''".format(i[0])
                q = "SELECT * FROM {} WHERE strPath LIKE '{}'".format(i[0], find_delet)
                cursor.execute(q)
                data = cursor.fetchall()
                j = 0
                for row in data:
                    j += 1
                    log(row)
                log(f"\nTotal rows : {j}")

                # delete Null
                # dq_p = "DELETE FROM {} WHERE idParentPath IS NULL OR idParentPath = ''".format(i[0])
                # print(q)
                dq_p = "DELETE * FROM {} WHERE strPath LIKE '{}'".format(i[0], find_delet)
                log(dq_p)  # cursor.execute(dq_p)  # cursor.connection.commit()  # cursor.execute("VACUUM")  # cursor.connection.commit()

    except Exception as error:
        log(error)
    finally:
        # Close all cursors
        cursor.close()


def cleanfolder(folder):
    from os import walk, unlink, remove
    from modules.control import deleteFile, log
    import shutil
    file_tokeep = ("kodi.log", "kodi.old.log", "xbmc.log", "xbmc.old.log", "spmc.log", "spmc.old.log")
    # log(folder)
    total_files = 0
    total_folds = 0
    try:
        for root, dirs, files in walk(folder):
            if len(dirs) >= 0:
                for d in dirs:
                    try:
                        shutil.rmtree(joinPath(root, d))
                        total_folds += 1
                    except:
                        log(f"Error Deleting Folder: {d}")
            if len(files) >= 0:
                for f in files:
                    try:
                        if f in file_tokeep:
                            continue
                        unlink(joinPath(root, f))
                        total_files += 1
                    except:
                        log(f"Error unlink file: {f}")
                    try:
                        if f in file_tokeep:
                            continue
                        try:
                            deleteFile(joinPath(root, f))
                        except:
                            remove(joinPath(root, f))
                    except Exception as e:
                        log(f"Error: {e} Deleting file: {f}")
    except Exception as e:
        log(f"cleanfolder Error: {str(e)}")
    return total_files, total_folds
