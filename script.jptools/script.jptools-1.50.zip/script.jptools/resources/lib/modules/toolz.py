# -*- coding: UTF-8 -*-
from traceback import format_exc


def Folder_Size(dirname=None, filesize='b'):
    from modules.control import homepath, joinPath
    import os
    if not dirname: dirname = homepath
    finalsize = 0
    for dirpath, dirnames, filenames in os.walk(dirname):
        for f in filenames:
            fp = joinPath(dirpath, f)
            finalsize += os.path.getsize(fp)
    return human_size(finalsize)


def human_size(byte_s, units=[' bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB']):
    """ Returns a human readable reprentation of bytes and unit """
    return (byte_s, units[0]) if byte_s < 1024 else human_size(byte_s >> 10, units[1:])


def dialogWatch():
    from modules.control import condVisibility, execute, sleep
    x = 0
    while not condVisibility("Window.isVisible(yesnodialog)") and x < 100:
        x += 1
        sleep(100)
    if condVisibility("Window.isVisible(yesnodialog)"): execute('SendClick(11)')


def swapUS():
    from modules.control import jsonrpc, infoDialog, sleep
    new = '"addons.unknownsources"'
    value = 'true'
    query = {"jsonrpc": "2.0", "method": "Settings.GetSettingValue", "params": {"setting": new}, "id": 1}
    response = jsonrpc(query)
    if 'true' in response: infoDialog("Unknown Sources: Already Enabled.")
    if 'false' in response:
        #thread.start_new_thread(dialogWatch, ())
        sleep(200)
        query = {"jsonrpc": "2.0", "method": "Settings.SetSettingValue", "params": {"setting": new, "value": value}, "id": 1}
        response = jsonrpc(query)
        infoDialog("Unknown Sources: Enabled.")


def AutoUpdateToggle_System():
    from modules.control import jsonrpc, execute
    #Sets system-wide auto-update.  Change the "value" number for desired action
    # 0-auto-update, 1 -notify of updates, 2-disable auto updates.
    jsonrpc({"jsonrpc": "2.0", "method": "Settings.SetSettingValue", "id": 1, "params": {"setting": "general.addonupdates", "value": 1}})
    #execute('xbmc.ActivateWindow(systemsettings)')
    execute('xbmc.ActivateWindow(AddonBrowser)')
    execute('SendClick(10125, 5)')


def AutoUpdateToggle_Addon():
    from modules.control import joinPath, databasepath
    import sqlite3 as database
    #The Addons27.db has a table called blacklist.  These are the addonIDs that you won't get auto-updated.
    #Couldn't figure out how to automatically set a unique ID for the table, so I just set I set the first value(ID) to 100
    addonsFile = joinPath(databasepath, 'Addons27.db')
    sourceFile = addonsFile
    dbcon = database.connect(sourceFile)
    dbcur = dbcon.cursor()
    ##Enable disable toggle could go below instead of (un)commenting below code.
    ##To Add to do not auto update list
    dbcur.execute("INSERT INTO blacklist Values (?,?)", ('100', 'plugin.video.exodusredux'))
    dbcon.commit()  ##To Remove from do not auto update list  # dbcur.execute("DELETE FROM blacklist WHERE addonID = 'plugin.video.exodusredux'")  #dbcon.commit()


def ForceUpdateCheck():
    from modules.control import execute, busy, idle, infoDialog
    busy()
    execute("UpdateAddonRepos")
    execute("UpdateLocalAddons")
    idle()
    infoDialog('Checking for Updates...')


def ENABLE_ADDONS():

    from xbmcvfs import listdir
    from modules.control import jsonrpc, transPath, log
    EXCLUDES_ADDONS = ['notification', 'packages', '__pycache__', 'temp']
    HOME_ADDONS = transPath('special://home/addons')
    # for root, dirs, files in walk(HOME_ADDONS, topdown = True):
    addons_list = listdir(HOME_ADDONS)
    # dirs[:] = [d for d in dirs]
    if addons_list:
        for addon_name in addons_list[0]:
            if not any(value in addon_name for value in EXCLUDES_ADDONS):
                # log("Enabled addon_name: %s" % (addon_name))
                try: jsonrpc({"jsonrpc": "2.0", "method": "Addons.SetAddonEnabled", "params": {"addonid": f"{addon_name}", "enabled": True}, "id": 1})
                except: log(f"Error: {format_exc()}")


def resetResolversCache():
    from modules.control import condVisibility, execute, log
    try:
        if condVisibility('System.HasAddon(script.module.resolveurl)'):
            execute('RunPlugin(plugin://script.module.resolveurl/?mode=reset_cache)')
    except Exception as e: log(f"resetResolversCache Error: {str(e)}")


def ReloadMySkin():
    from modules.control import execute
    execute("ReloadSkin()")


def Current_Profile():
    from modules.control import infoLabel
    return infoLabel('System.ProfileName')


def reloadProfile(profile=None):
    from modules.control import execute
    if profile is None: execute('LoadProfile(Master user)')
    else: execute(f'LoadProfile({profile})')


def getInfo(label):
    from modules.control import infoLabel
    try: return infoLabel(label)
    except: return False


def net_info():
    from modules.control import log, sleep
    from modules.utilz import OPEN_URL
    # import random
    infoLabel = ['Network.IPAddress', 'Network.MacAddress', 'Network.LinkState', 'Network.GatewayAddress', 'Network.DNS1Address']
    data = []
    # x = 0
    for info in infoLabel:
        temp = getInfo(info)
        y = 0
        while temp == "Busy" and y < 10:
            temp = getInfo(info)
            y += 1
            # log(f"{info} sleep {str(y)}")
            sleep(200)
        data.append(temp)  # x += 1
    # log(f"[Trakt Data] data: {data} ")
    netinfo = {"Internal IP": data[0], "Mac": data[1], "LinkState": data[2], "GatewayAddress": data[3], "DNS1Address": data[4], "External IP": "", "ISP": "", "City": "", "Country": "", "State": ""}
    try:
        # url = f"http://ipwhois.app/json/{inter_ip}"
        # url = random.choice(['http://extreme-ip-lookup.com/json/', 'http://ip-api.com/json'])
        url = "https://ipapi.co/json/"
        req = OPEN_URL(url)
        # log(f"[Trakt Data] data from : {url}\n {req} ")
        if req:
            geo = req.json()
            log(f"url: {url}\n geo: {geo} ")
            # netinfo.update({"External IP": geo['ip']})
            netinfo.update({"ISP": geo['org']})
            netinfo.update({"City": geo['city']})
            netinfo.update({"Country": geo['country']})
            netinfo.update({"State": geo['region_code']})
        # else:
        url = 'https://whatismyip.host/ip4'
        ip = OPEN_URL(url)
        # log(f"from whatismyip.host geo['ip']: {ip.text} ")
        netinfo.update({"External IP": ip.text})

        return netinfo
    except:
        log(f"[Trakt Data] Error: {format_exc()} ")
        return netinfo


def NETINFO():
    from modules.control import TextBox, log
    netinfo = net_info()
    string = ""
    i = 0
    log(f"[Trakt Data] netinfo: {netinfo}")
    for item in netinfo:
        i += 1
        string += f"[B][COLOR red]{i:02d}:[/B][/COLOR] {item:15}: {netinfo.get('%s' % item)}[CR]"
    TextBox('--[ JP Tools Net Info ]--', string)
