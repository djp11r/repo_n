# -*- coding: UTF-8 -*-


def mMenu():
    from modules.control import CustomColor, AddonTitle, SelectDialog, log
    my_options = ['get Addon enet', 'save userdata n zip', 'Save Trakt', 'Restore Trakt', 'Clean addons Trakt', 'Save Favorites', 'Restore Favorites', 'extract zip', 'You Tube API update', 'DNS Leak Test', 'Clear Old Thumbs', 'Convert path to special', 'Clean data folders', 'Reset setting', 'Log File Upload', 'View Log', 'Clean old logs', 'All Errors', '[[B] Close [/B]]']
    selectList = []
    for Item in my_options:
        selectList.append(f"[COLOR={CustomColor}]{Item}[/COLOR]")
    mychoice = SelectDialog(AddonTitle, selectList, key=False)
    # mychoice = mychoice.replace('[COLOR %s]' % (CustomColor), '').replace('[/COLOR]', '')
    # log("mychoice %s" % mychoice)
    if mychoice == f'[COLOR={CustomColor}]You Tube API update[/COLOR]':
        from modules.upd_yt_api import set_api
        set_api()
    elif mychoice == f'[COLOR={CustomColor}]DNS Leak Test[/COLOR]':
        from modules.dns_leak_test import dns_leak_test
        dns_leak_test()
    elif mychoice == f'[COLOR={CustomColor}]save userdata n zip[/COLOR]':
        from modules.traktit import get_userdata
        get_userdata()
    elif mychoice == f'[COLOR={CustomColor}]get Addon enet[/COLOR]':
        from modules.traktit import get_adon_frm_enet
        get_adon_frm_enet()
    elif mychoice == f'[COLOR={CustomColor}]Save Trakt[/COLOR]':
        from modules.traktit import trakt
        trakt('update', 'all')
    elif mychoice == f'[COLOR={CustomColor}]Restore Trakt[/COLOR]':
        from modules.traktit import trakt
        trakt('restore', 'all')
    elif mychoice == f'[COLOR={CustomColor}]Save Favorites[/COLOR]':
        from modules.wiz import BACKUPFAV
        BACKUPFAV()
    elif mychoice == f'[COLOR={CustomColor}]Restore Favorites[/COLOR]':
        from modules.wiz import RESTOREFAV
        RESTOREFAV()
    elif mychoice == f'[COLOR={CustomColor}]Clean addons Trakt[/COLOR]':
        from modules.traktit import trakt
        trakt('clearaddon', 'all')
    elif mychoice == f'[COLOR={CustomColor}]extract zip[/COLOR]':
        from modules.traktit import zipextr
        zipextr()
    elif mychoice == f'[COLOR={CustomColor}]Clear Old Thumbs[/COLOR]':
        from modules.maintenance import deleteold_Thumbnails
        deleteold_Thumbnails()
    elif mychoice == f'[COLOR={CustomColor}]Convert path to special[/COLOR]':
        from modules.wiz import FIX_SPECIAL
        FIX_SPECIAL()
    elif mychoice == f'[COLOR={CustomColor}]All Errors[/COLOR]':
        from modules.traktit import errorChecking
        errorChecking()
    elif mychoice == f'[COLOR={CustomColor}]Log File Upload[/COLOR]':
        from modules.utilz import upload_log
        upload_log()
    elif mychoice == f'[COLOR={CustomColor}]View Log[/COLOR]':
        from modules.traktit import viewlog
        viewlog()
    elif mychoice == f'[COLOR={CustomColor}]Clean data folders[/COLOR]':
        from modules.traktit import clane_adondata
        clane_adondata()
    elif mychoice == f'[COLOR={CustomColor}]Clean old logs[/COLOR]':
        from modules.maintenance import clean_oldlog
        clean_oldlog()
    elif mychoice == f'[COLOR={CustomColor}]Reset setting[/COLOR]':
        from modules.traktit import reset_upd_setting
        # log("mychoice %s" % mychoice)
        reset_upd_setting()
    elif mychoice == f'[COLOR={CustomColor}][[B] Close [/B]][/COLOR]': return
