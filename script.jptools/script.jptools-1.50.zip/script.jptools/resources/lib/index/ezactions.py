# -*- coding: UTF-8 -*-


from modules.control import setting, log

CustomColor = setting('my_ColorChoice')
if CustomColor == '':
    CustomColor = 'none'


def actChangeLog():
    from api import TextViewer
    from modules.control import transPath, joinPath, AddonID, AddonTitle, SelectDialog, getChangeLog
    changelogfile = transPath(joinPath(f'special://home/addons/{AddonID}', 'changelog.txt'))
    my_options = ['DialogWindow', 'TextViewer', '[[B] Close [/B]]']
    selectList = []
    for Item in my_options:
        selectList.append(f"[COLOR={CustomColor}]{Item}[/COLOR]")
    mychoice = SelectDialog(AddonTitle, selectList, key=False)
    # mychoice = mychoice.replace('[COLOR %s]' % (CustomColor), '').replace('[/COLOR]', '')
    if mychoice == f'[COLOR={CustomColor}]DialogWindow[/COLOR]':
        getChangeLog()
    elif mychoice == f'[COLOR={CustomColor}]TextViewer[/COLOR]':
        TextViewer.text_view(changelogfile)
    elif mychoice == f'[COLOR={CustomColor}][[B] Close [/B]][/COLOR]':
        return


def actLogMenu():
    from modules import utilz
    from modules.control import AddonTitle, SelectDialog
    my_options = ['[B]Log Viewer/Uploader[/B]', '[B]Clear CrashLogs[/B]', '[B]Clear DebugLogs[/B]', '[[B] Close [/B]]']
    selectList = []
    for Item in my_options:
        selectList.append(f"[COLOR={CustomColor}]{Item}[/COLOR]")
    mychoice = SelectDialog(AddonTitle, selectList, key=False)
    # mychoice = mychoice.replace(f'[COLOR {CustomColor}]', '').replace('[/COLOR]', '')
    if mychoice == f'[COLOR={CustomColor}][B]Log Viewer/Uploader[/B][/COLOR]':
        utilz.logView()
    elif mychoice == f'[COLOR={CustomColor}][B]Clear CrashLogs[/B][/COLOR]':
        utilz.Delete_Crash_Logs()
    elif mychoice == f'[COLOR={CustomColor}][B]Clear DebugLogs[/B][/COLOR]':
        utilz.Delete_DebugLogs()
    elif mychoice == f'[COLOR={CustomColor}][[B] Close [/B]][/COLOR]':
        return


def advancedSettingsMenu():
    from modules import advsetz
    from modules.control import AddonTitle, SelectDialog
    my_options = ['Create AdvancedSettings', 'View AdvancedSettings', 'Clear AdvancedSettings', '[[B] Close [/B]]']
    selectList = []
    for Item in my_options:
        selectList.append(f"[COLOR={CustomColor}]{Item}[/COLOR]")
    mychoice = SelectDialog(AddonTitle, selectList, key=False)
    # log("mychoice: %s" % mychoice)
    # mychoice = mychoice.replace('[COLOR %s]' % (CustomColor), '').replace('[/COLOR]', '')
    # log("mychoice: %s" % mychoice)
    # mc = '[COLOR=%s]Create AdvancedSettings[/COLOR]' % (CustomColor)

    if mychoice == f'[COLOR={CustomColor}]Create AdvancedSettings[/COLOR]':
        advsetz.advancedSettings()
    elif mychoice == f'[COLOR={CustomColor}]View AdvancedSettings[/COLOR]':
        advsetz.viewAdvancedSettings()
    elif mychoice == f'[COLOR={CustomColor}]Clear AdvancedSettings[/COLOR]':
        advsetz.clearAdvancedSettings()
    elif mychoice == f'[COLOR={CustomColor}][[B] Close [/B]][/COLOR]':
        return


def kodiMenu():
    from modules.control import AddonTitle, SelectDialog, execute
    my_options = ['FileManager', 'AddonBrowser', 'InterfaceSettings', 'SystemSettings', 'ShowSettings', 'SkinSettings', 'ShowSystemInfo', '[[B] Close [/B]]']
    selectList = []
    for Item in my_options:
        selectList.append(f"[COLOR={CustomColor}]{Item}[/COLOR]")
    mychoice = SelectDialog(AddonTitle, selectList, key=False)
    # mychoice = mychoice.replace('[/COLOR]', '')
    if mychoice == f'[COLOR={CustomColor}]FileManager[/COLOR]':
        execute("ActivateWindow(10003)")
    elif mychoice == f'[COLOR={CustomColor}]AddonBrowser[/COLOR]':
        execute("ActivateWindow(10040)")
    elif mychoice == f'[COLOR={CustomColor}]InterfaceSettings[/COLOR]':
        execute("ActivateWindow(10032)")
    elif mychoice == f'[COLOR={CustomColor}]SystemSettings[/COLOR]':
        execute("ActivateWindow(10016)")
    elif mychoice == f'[COLOR={CustomColor}]ShowSettings[/COLOR]':
        execute("ActivateWindow(10004)")
    elif mychoice == f'[COLOR={CustomColor}]SkinSettings[/COLOR]':
        execute("ActivateWindow(10035)")
    elif mychoice == f'[COLOR={CustomColor}]ShowSystemInfo[/COLOR]':
        execute("ActivateWindow(10007)")
    elif mychoice == f'[COLOR={CustomColor}][[B] Close [/B]][/COLOR]':
        return


def kodiDbMenu():
    from modules.control import AddonTitle, SelectDialog, execute
    my_options = ['CleanPlaylist', 'UpdateVideoDB', 'CleanVideoDB', 'UpdateMusicDB', 'CleanMusicDB', '[[B] Close [/B]]']
    selectList = []
    for Item in my_options:
        selectList.append(f"[COLOR={CustomColor}]{Item}[/COLOR]")
    mychoice = SelectDialog(AddonTitle, selectList, key=False)
    # mychoice = mychoice.replace('[/COLOR]', '')
    if mychoice == f'[COLOR={CustomColor}]CleanPlaylist[/COLOR]':
        execute("Playlist.Clear")
    elif mychoice == f'[COLOR={CustomColor}]UpdateVideoDB[/COLOR]':
        execute("UpdateLibrary(video)")
    elif mychoice == f'[COLOR={CustomColor}]CleanVideoDB[/COLOR]':
        execute("CleanLibrary(video)")
    elif mychoice == f'[COLOR={CustomColor}]UpdateMusicDB[/COLOR]':
        execute("UpdateLibrary(music)")
    elif mychoice == f'[COLOR={CustomColor}]CleanMusicDB[/COLOR]':
        execute("CleanLibrary(music)")
    elif mychoice == f'[COLOR={CustomColor}][[B] Close [/B]][/COLOR]':
        return
