# -*- coding: UTF-8 -*-
import glob
import json
import re


def currSkin():
    from modules.control import skin
    return skin


def getOld(old):
    from modules.control import jsonrpc
    try:
        old = f'"{old}"'
        query = f'{{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{{"setting":{old}}}, "id":1}}'
        response = jsonrpc(query)
        response = json.loads(response)
        if response.has_key('result'):
            if response['result'].has_key('value'):
                return response['result']['value']
    except: pass
    return None


def setNew(new, value):
    from modules.control import jsonrpc
    try:
        new = f'"{new}"'
        value = f'"{value}"'
        query = f'{{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{{"setting":{new},"value":{value}}}, "id":1}}'
        response = jsonrpc(query)
    except: pass
    return None


def swapSkins(skin):
    old = 'lookandfeel.skin'
    value = skin
    current = getOld(old)
    new = old
    setNew(new, value)


def lookandFeelData(do='save'):
    from modules.control import setSetting, log, setting, jsonrpc
    scan = ['lookandfeel.enablerssfeeds', 'lookandfeel.font', 'lookandfeel.rssedit', 'lookandfeel.skincolors', 'lookandfeel.skintheme', 'lookandfeel.skinzoom', 'lookandfeel.soundskin', 'lookandfeel.startupwindow', 'lookandfeel.stereostrength']
    if do == 'save':
        for item in scan:
            query = f'{{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{{"setting":"{item}"}}, "id":1}}'
            response = jsonrpc(query)
            if not 'error' in response:
                match = re.compile('{"value":(.+?)}').findall(str(response))
                setSetting(item.replace('lookandfeel', 'default'), match[0])
                log(f'{item} saved to {match[0]}')
    else:
        for item in scan:
            value = setting(item.replace('lookandfeel', 'default'))
            query = f'{{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{{"setting":"{item}","value":{value}}}, "id":1}}'
            response = jsonrpc(query)
            log(f'{item} restored to {value}')


def defaultSkin():
    from modules.control import log, joinPath, homepath, userdata, deleteFile, existsPath, setSetting
    log('[Default Skin Check]')
    ADDONS = joinPath(homepath, 'addons')
    GUISETTINGS = joinPath(userdata, 'guisettings.xml')
    tempgui = joinPath(userdata, 'guitemp.xml')
    gui = tempgui if existsPath(tempgui) else GUISETTINGS
    if not existsPath(gui): return False
    log(f'Reading gui file: {gui}')
    guif = open(gui, 'r+')
    msg = guif.read().replace('\n', '').replace('\r', '').replace('\t', '').replace('    ', '')
    guif.close()
    log('Opening gui settings')
    match = re.compile('<lookandfeel>.+?<ski.+?>(.+?)</skin>.+?</lookandfeel>').findall(msg)
    log(f'Matches: {str(match)}')
    if len(match) > 0:
        skinid = match[0]
        addonxml = joinPath(ADDONS, match[0], 'addon.xml')
        if existsPath(addonxml):
            addf = open(addonxml, 'r+')
            msg2 = addf.read().replace('\n', '').replace('\r', '').replace('\t', '')
            addf.close()
            match2 = re.compile('<addon.+?ame="(.+?)".+?>').findall(msg2)
            if len(match2) > 0: skinname = match2[0]
            else: skinname = 'no match'
        else: skinname = 'no file'
        log(f'[Default Skin Check] Skin name: {skinname}')
        log(f'[Default Skin Check] Skin id: {skinid}')
        setSetting('defaultskin', skinid)
        setSetting('defaultskinname', skinname)
        setSetting('defaultskinignore', 'false')
    if existsPath(tempgui):
        log('Deleting Temp Gui File.')
        deleteFile(tempgui)
    log('[Default Skin Check] End')


def checkSkin():
    from modules.control import log, setting, setSetting, homepath, joinPath, color1, color2, existsPath, AddonTitle, dialog, condVisibility, execute, sleep, infoDialog, skin
    ADDONS = joinPath(homepath, 'addons')
    log('Invalid Skin Check Start')
    DEFAULTSKIN = setting('defaultskin')
    DEFAULTNAME = setting('defaultskinname')
    DEFAULTIGNORE = setting('defaultskinignore')
    gotoskin = False
    if not DEFAULTSKIN == '':
        if existsPath(joinPath(ADDONS, DEFAULTSKIN)):
            if dialog.yesno(AddonTitle, f'[COLOR {color2}]It seems that the skin has been set back to [COLOR {color1}]{skin[5:].title()}[/COLOR]', 'Would you like to set the skin back to:[/COLOR]', f'[COLOR {color1}]{DEFAULTNAME}[/COLOR]'):
                gotoskin = DEFAULTSKIN
                gotoname = DEFAULTNAME
            else:
                log('Skin was not reset')
                setSetting('defaultskinignore', 'true')
                gotoskin = False
        else:
            setSetting('defaultskin', '')
            setSetting('defaultskinname', '')
            DEFAULTSKIN = ''
            DEFAULTNAME = ''
    if DEFAULTSKIN == '':
        skinname = []
        skinlist = []
        for folder in glob.glob(joinPath(ADDONS, 'skin.*/')):
            xml = f'{folder}/addon.xml'
            if existsPath(xml):
                f = open(xml, mode='r')
                g = f.read().replace('\n', '').replace('\r', '').replace('\t', '')
                f.close()
                match = re.compile('<addon.+?id="(.+?)".+?>').findall(g)
                match2 = re.compile('<addon.+?name="(.+?)".+?>').findall(g)
                log("%s: %s" % (folder, str(match[0])))
                if len(match) > 0:
                    skinlist.append(str(match[0]))
                    skinname.append(str(match2[0]))
                else: log(f'ID not found for {folder}')
            else: log(f'ID not found for {folder}')
        if len(skinlist) > 0:
            if len(skinlist) > 1:
                if dialog.yesno(AddonTitle, f'[COLOR {color2}]It seems that the skin has been set back to [COLOR {color1}]{skinlist[5:]}[/COLOR]', 'Would you like to view a list of avaliable skins?[/COLOR]'):
                    choice = dialog.select('Select skin to switch to!', skinname)
                    if choice == -1:
                        log('Skin was not reset')
                        setSetting('defaultskinignore', 'true')
                    else:
                        gotoskin = skinlist[choice]
                        gotoname = skinname[choice]
                else:
                    log('Skin was not reset')
                    setSetting('defaultskinignore', 'true')
            else:
                if dialog.yesno(AddonTitle, f'It seems that the skin has been set back to [B]{skinlist[5:]}[/B]', 'Would you like to set the skin back to: ', f'[B] {skinname[0]} [/B]'):
                    gotoskin = skinlist[0]
                    gotoname = skinname[0]
                else:
                    log('Skin was not reset')
                    setSetting('defaultskinignore', 'true')
        else:
            log('No skins found in addons folder.')
            setSetting('defaultskinignore', 'true')
            gotoskin = False
    if gotoskin:
        swapSkins(gotoskin)
        x = 0
        sleep(1000)
        while not condVisibility('Window.isVisible(yesnodialog)') and x < 150:
            x += 1
            sleep(200)
        if condVisibility('Window.isVisible(yesnodialog)'):
            execute('SendClick(11)')
            lookandFeelData('restore')
        else: infoDialog('Skin Swap Timed Out!')
    log('Invalid Skin Check End')
