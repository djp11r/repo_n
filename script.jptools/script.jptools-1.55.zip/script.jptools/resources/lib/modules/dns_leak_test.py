# -*- coding: utf-8 -*-

import json
import traceback
from platform import system as system_name
from random import randint
from subprocess import call as system_call

import requests


def ping(host):
    param = '-n' if system_name().lower() == 'windows' else '-c'
    command = ['ping', param, '1', host]
    if system_name().lower() == 'windows':
        retcode = system_call(command, creationflags=0x00000008)
        return retcode == 0
    else:
        return system_call(command)


def items_list(parsed_data):
    ip_add = parsed_data[0].get('ip')
    msg_text = 'DNS servers:'
    servers = finalmsg = 0
    for dns_server in parsed_data:
        if dns_server['type'] == 'dns':
            servers += 1
            if dns_server['country_name']:
                if dns_server['asn']: msg_text += f'\n[B][COLOR red]{servers:02d}:[/B][/COLOR] You use {dns_server["ip"]} [{dns_server["country_name"]}, {dns_server["asn"]}] DNS servers:'
                else: msg_text += f'\n[B][COLOR red]{servers:02d}:[/B][/COLOR] You use {dns_server["ip"]} [{dns_server["country_name"]}] DNS servers:'
            else: msg_text += f'\n[B][COLOR red]{servers:02d}:[/B][/COLOR] You use {dns_server["ip"]} DNS servers:'
        if dns_server['type'] == 'conclusion': finalmsg = f'\nconclusion: {dns_server["ip"]}'
    msg_text += f'\n\nYour IP: {ip_add}'
    msg_text += f'\nTotal servers used: {servers}'
    if finalmsg != 0: msg_text += finalmsg
    return msg_text


def dns_leak_test():
    try:
        from modules.control import log, TextBox
        leak_id = randint(1000000, 9999999)
        for x in range(0, 5):
            ping_to = '.'.join([str(x), str(leak_id), 'bash.ws'])
            # log(f'ping To: {ping_to}')
            ping(ping_to)

        url = f'https://bash.ws/dnsleak/test/{str(leak_id)}?json'
        response = requests.get(url)
        parsed_data = json.loads(response.content)
        # log(f'parsed_data {parsed_data}')
        items_text = ''
        items_text = items_list(parsed_data)
        # log(f'items_text {items_text}')
        TextBox('--[ JP Tools DNS Leak Report ]--', items_text)
    except: log(f'Error: {traceback.format_exc()}')
