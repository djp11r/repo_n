# -*- coding: UTF-8 -*-

import base64

from urllib.parse import urljoin
import requests


class api:
    def __init__(self):
        self.base_link = 'https://pastebin.com'
        self.paste_link = '/api/api_post.php'
        self.apiKey = base64.b64decode('MjNkNTNhMGMyMTdlZWY2OGM5ZWE3NDY0NDIwZTMzNmU=')

    def paste(self, text):
        url = urljoin(self.base_link, self.paste_link)
        payload = {'api_dev_key': self.apiKey, 'api_option': 'paste', 'api_paste_code': text}
        return requests.post(url, data=payload, timeout=10).content
