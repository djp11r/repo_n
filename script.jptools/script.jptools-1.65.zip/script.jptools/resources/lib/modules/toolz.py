# -*- coding: UTF-8 -*-
import re
import sqlite3 as database
from platform import machine
from traceback import format_exc

from modules.control import TextBox, busy, condVisibility, databasepath, execute, homepath, idle, infoDialog, infoLabel, joinPath, jsonrpc, log, sleep, transPath, listDir, get_soup, EXCLUDES_ADDONS
from modules.utilz import OPEN_URL
from modules.control import AddonID, SelectDialog, myMonitor, AddonIcon as icon, platform as mplatform, item as litem


BUILD_OPT = {'nightlies':'Unstable (Daily builds).','releases':'Stable (Final releases).','snapshots':'Semi-stable (Monthly builds).','test-builds':'Experimental (Debugging builds).'}
BASE_URL  = 'http://mirrors.kodi.tv/'


def Folder_Size(dirname=None, filesize='b'):
    import os
    if not dirname: dirname = homepath
    finalsize = 0
    for dirpath, dirnames, filenames in os.walk(dirname):
        for f in filenames:
            fp = joinPath(dirpath, f)
            finalsize += os.path.getsize(fp)
    return human_size(finalsize)


def human_size(byte_s, units=None):
    """ Returns a human-readable reprentation of bytes and unit """
    if units is None: units = [' bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB']
    return (byte_s, units[0]) if byte_s < 1024 else human_size(byte_s >> 10, units[1:])


def dialogWatch():
    x = 0
    while not condVisibility('Window.isVisible(yesnodialog)') and x < 100:
        x += 1
        sleep(100)
    if condVisibility('Window.isVisible(yesnodialog)'): execute('SendClick(11)')


def swapUS():
    new = '"addons.unknownsources"'
    query = {"jsonrpc": "2.0", "method": "Settings.GetSettingValue", "params": {"setting": new}, "id": 1}
    response = jsonrpc(query)
    if 'true' in response: infoDialog('Unknown Sources: Already Enabled.')
    if 'false' in response:
        sleep(200)
        value = 'true'
        query = {"jsonrpc": "2.0", "method": "Settings.SetSettingValue", "params": {"setting": new, "value": value}, "id": 1}
        response = jsonrpc(query)
        infoDialog('Unknown Sources: Enabled.')


def AutoUpdateToggle_System():
    #Sets system-wide auto-update.  Change the "value" number for desired action
    # 0-auto-update, 1 -notify of updates, 2-disable auto updates.
    jsonrpc({"jsonrpc": "2.0", "method": "Settings.SetSettingValue", "id": 1, "params": {"setting": "general.addonupdates", "value": 1}})
    #execute('xbmc.ActivateWindow(systemsettings)')
    execute('xbmc.ActivateWindow(AddonBrowser)')
    execute('SendClick(10125, 5)')


def AutoUpdateToggle_Addon():
    #The Addons33.db has a table called blacklist.  These are the addonIDs that you won't get auto-updated.
    #Couldn't figure out how to automatically set a unique ID for the table, so I just set I set the first value(ID) to 100
    addonsFile = joinPath(databasepath, 'Addons33.db')
    sourceFile = addonsFile
    dbcon = database.connect(sourceFile)
    dbcur = dbcon.cursor()
    ##Enable disable toggle could go below instead of (un)commenting below code.
    ##To Add to do not auto update list
    dbcur.execute('INSERT INTO blacklist Values (?,?)', ('100', 'plugin.video.exodusredux'))
    dbcon.commit()  ##To Remove from do not auto update list  # dbcur.execute("DELETE FROM blacklist WHERE addonID = 'plugin.video.exodusredux'")  #dbcon.commit()


def ForceUpdateCheck():
    busy()
    execute('UpdateAddonRepos')
    execute('UpdateLocalAddons')
    idle()
    infoDialog('Checking for Updates...')


def enable_addon(addon_name=AddonID):
    try: jsonrpc({"jsonrpc": "2.0", "method": "Addons.SetAddonEnabled", "params": {"addonid": f"{addon_name}", "enabled": True}, "id": 1})
    except: log(f'Error: {format_exc()}')


def ENABLE_ADDONS():

    HOME_ADDONS = transPath('special://home/addons')
    if addons_list := listDir(HOME_ADDONS):
        for addon_name in addons_list[0]:
            if all(value not in addon_name for value in EXCLUDES_ADDONS):
                # log("Enabled addon_name: %s" % (addon_name))
                enable_addon(addon_name)


def resetResolversCache():
    try:
        if condVisibility('System.HasAddon(script.module.resolveurl)'):
            execute('RunPlugin(plugin://script.module.resolveurl/?mode=reset_cache)')
    except Exception as e: log(f'resetResolversCache Error: {e}')


def ReloadMySkin():
    execute('ReloadSkin()')


def Current_Profile():
    return infoLabel('System.ProfileName')


def reloadProfile(profile=None):
    if profile is None: execute('LoadProfile(Master user)')
    else: execute(f'LoadProfile({profile})')


def getInfo(label):
    try: return infoLabel(label)
    except: return False


def net_info():
    infoLabel = ['Network.IPAddress', 'Network.MacAddress', 'Network.LinkState', 'Network.GatewayAddress', 'Network.DNS1Address']
    data = []
    for info in infoLabel:
        temp = getInfo(info)
        y = 0
        while temp == 'Busy' and y < 10:
            temp = getInfo(info)
            y += 1
            # log(f'{info} sleep {str(y)}')
            sleep(200)
        data.append(temp)
    # log(f'[Trakt Data] data: {data}')
    netinfo = {"Internal IP": data[0], "Mac": data[1], "LinkState": data[2], "GatewayAddress": data[3], "DNS1Address": data[4], "External IP": "", "ISP": "", "City": "", "Country": "", "State": ""}
    try:
        # url = f'http://ipwhois.app/json/{inter_ip}'
        # url = random.choice(['http://extreme-ip-lookup.com/json/', 'http://ip-api.com/json'])
        url = 'https://ipapi.co/json/'
        if req := OPEN_URL(url):
            geo = req.json()
            log(f'url: {url}\n geo: {geo} ')
            # netinfo.update({"External IP": geo['ip']})
            netinfo['ISP'] = geo['org']
            netinfo['City'] = geo['city']
            netinfo['Country'] = geo['country']
            netinfo['State'] = geo['region_code']
        # else:
        url = 'https://whatismyip.host/ip4'
        ip = OPEN_URL(url)
        # log(f'from whatismyip.host geo["ip"]: {ip.text}')
        netinfo['External IP'] = ip.text

        return netinfo
    except:
        log(f'[Trakt Data] Error: {format_exc()} ')
        return netinfo


def NETINFO():
    netinfo = net_info()
    log(f'[Trakt Data] netinfo: {netinfo}')
    string = "".join(f'[B][COLOR red]{i:02d}:[/B][/COLOR] {item:15}: {netinfo.get(f"{item}")}[CR]' for i, item in enumerate(netinfo, start=1))
    TextBox('--[ JP Tools Net Info ]--', string)


def get_platform_data():
    BRANCHS   =  {20:'nexus', 21:'omega', 22:'pegasus', }
    VER_QUERY     = {"jsonrpc":"2.0","method":"Application.GetProperties","params":{"properties":["version"]},"id":1}
    machine_type = machine()
    myplatform = mplatform()
    build = jsonrpc(VER_QUERY)[0]
    build = build.get('result',{}).get('version',{})
    branch = BRANCHS[int(build.get('major',''))]
    current_kodi_branch = '(%s.%s-%s)' %(build.get('major',''),build.get('minor',''),build.get('revision',''))
    if myplatform == 'android':
        _URL = BASE_URL + '%s/android/%s/'
        if '64' in machine_type: thisplatform = 'arm64-v8a'
        elif '86' in machine_type: thisplatform = 'x86'
        else: thisplatform = 'arm'
        app_endswith = '.apk'
    elif myplatform == 'windows':
        _URL = BASE_URL + '%s/windows/%s/'
        if '64' in machine_type: thisplatform = 'win64'
        elif '86' in machine_type: thisplatform = 'win32'
        else: thisplatform = ''
        app_endswith = '.exe'
    return {'url': _URL, 'branch': branch, 'current_kodi_branch': current_kodi_branch, 'thisplatform': thisplatform, 'app_endswith': app_endswith, 'myplatform': myplatform}


def get_soup_items(soup):
    try: #folders
        items = (soup.find_all('tr'))
        del items[0]
    except: #files
        items = (soup.find_all('a'))
    return [x.get_text() for x in items if x.get_text() is not None]


def builditems():
    from modules.traktit import appinstaller
    platform_data = get_platform_data()
    # log(f'platform_data: {platform_data}')
    # platform_data = {'url': 'http://mirrors.kodi.tv/%s/windows/%s/', 'branch': 'omega', 'current_kodi_branch': '(21.0-20230911-327fd81962)', 'thisplatform': 'win64', 'app_endswith': '.exe', 'myplatform': 'windows'}
    burl = platform_data['url']
    thisplatform = platform_data['thisplatform']
    branch = platform_data['branch']
    current_kodi_branch = platform_data['current_kodi_branch']
    app_endswith = platform_data['app_endswith']
    myplatform = platform_data['myplatform']
    def build_main():
        tmpLST = []
        for label in sorted(BUILD_OPT.keys()):
            liz = litem(label.title(), BUILD_OPT[label], path=burl%(label, thisplatform))
            liz.setArt({'poster': 'DefaultAddonProgram.png', 'icon': icon, 'thumb': icon})
            tmpLST.append(liz)
        # select = selectDialog(AddonTitle, tmpLST)
        select = SelectDialog('Select BUILD to install...', tmpLST)
        if select is None: return
        return tmpLST[select].getPath()
        # url = tmpLST[select].getPath()

    def buildItems(url):
        cacheResponce = OPEN_URL(url).text
        # log(f'url: {url} \ncacheResponce: {cacheResponce}')
        soup = get_soup(cacheResponce)
        if soup is None: return
        for item in get_soup_items(soup):
            # log(f'item: {item}')
            try: #folders
                label, label2 = re.compile("(.*?)/-(.*)").match(item).groups()
                # log(f'folders label: {label} label2: {label2}')
                if label == thisplatform: label2 = 'Current Platform (%s)' % thisplatform
                elif label.lower() == branch.lower(): label2 = 'Current Kodi Branch %s' % current_kodi_branch
                else: label2 = '' #Don't use time-stamp for folders
                # log(f'folders label2: {label2}')
                liz = litem(label.title(),label2,path=(url + label))
                liz.setArt({'icon':icon,'thumb':icon})
                yield liz
            except: #files
                label, label2 = re.compile("(.*?)\s(.*)").match(item).groups()
                if app_endswith in label:
                    # log(f'files label: {label} label2: {label2}')
                    labels = label.split(app_endswith)
                    title = labels[0]
                    title1 = labels[1]
                    # log(f'files label title: {title} title1: {title1}')
                    liz = litem(f'{title}{app_endswith}','%s %s'%(title1, label2.replace('MiB','MB ').strip()),path=f'{url}{title}{app_endswith}')
                    liz.setArt({'icon':icon,'thumb':icon})
                    yield liz

    def selectedpath(url, bypass=False):
        while not myMonitor.abortRequested():
            items  = list(buildItems(url))
            if len(items) == 0: break
            elif len(items) == 2 and not bypass and items[0].getLabel().lower() == 'parent directory' and not items[1].getLabel().startswith(app_endswith): select = 1 #If one folder bypass selection.
            else: select = SelectDialog(url.replace(BASE_URL,'./').replace('//','/'), items)
            if select is None: return #return on cancel.
            label  = items[select].getLabel()
            newURL = items[select].getPath()
            preURL = url.rsplit('/', 2)[0] + '/'
            if newURL.endswith(app_endswith):
                log(f'setLastPath label: {label}')
                return appinstaller(label, newURL)
            elif label.lower() == 'parent directory' and myplatform in preURL.lower():
                return selectedpath(preURL, True)
            elif label.lower() == 'parent directory' and myplatform not in preURL.lower():
                return selectedpath(build_main(), False)
            url = newURL + '/'

    url = build_main()
    # log(f'url form build_main: {url}')
    # url = 'http://mirrors.kodi.tv/nightlies/windows/win64/'
    # url = 'http://mirrors.kodi.tv/nightlies/windows/win64/Omega/'
    # url = 'http://mirrors.kodi.tv/nightlies/windows/win64/master/'
    selectedpath(url)