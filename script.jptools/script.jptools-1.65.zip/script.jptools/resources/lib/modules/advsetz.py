# -*- coding: UTF-8 -*-


import re
import sys

from api import TextViewer
from modules.control import AddonTitle, deleteFile, dialog, kodi_version, get_keyboard, infoLabel, joinPath, transPath

AdvancedSettingsFile = transPath(joinPath('special://profile/', 'advancedsettings.xml'))


def xml_data_advSettings_old(size):
    return f"""<advancedsettings>
      <network>
        <curlclienttimeout>10</curlclienttimeout>
        <curllowspeedtime>20</curllowspeedtime>
        <curlretries>2</curlretries>
        <cachemembuffersize>{size}</cachemembuffersize>
        <buffermode>2</buffermode>
        <readbufferfactor>20</readbufferfactor>
      </network>
</advancedsettings>"""



def xml_data_advSettings_New(size):
    return f"""<advancedsettings>
      <network>
        <disablehttp2>true</disablehttp2>
        <curlclienttimeout>10</curlclienttimeout>
        <curllowspeedtime>20</curllowspeedtime>
        <curlretries>2</curlretries>
      </network>
      <cache>
        <memorysize>{size}</memorysize>
        <buffermode>2</buffermode>
        <readfactor>20</readfactor>
      </cache>
</advancedsettings>"""


def xml_data_advSettings_pathsubstitution(size):
    return """<advancedsettings>
    <pathsubstitution>
        <substitute>
            <from>special://profile/Thumbnails/</from>
            <to>smb://SERVER/Kodi Thumbnails/STICK1</to>
        </substitute>
    </pathsubstitution>
</advancedsettings>"""


def advancedSettings():
    MEM = infoLabel('System.Memory(total)')
    FREEMEM = infoLabel('System.FreeMemory')
    BUFFER_F = re.sub('[^0-9]', '', FREEMEM)
    BUFFER_F = int(BUFFER_F) // 3
    BUFFERSIZE = BUFFER_F * 1024 * 1024
    # log(MEM)
    choice = dialog.yesno(AddonTitle, f'Free Memory: [B]{str(FREEMEM)}[/B]\nOptimal BufferSize is: [B]{str(BUFFER_F)} MB[/B]\nChoose an Option below...', yeslabel="[COLOR lime][B]Use Optimal[/B][/COLOR]", nolabel="[COLOR red]Input a Value[/COLOR]")
    if choice == 1:
        with open(AdvancedSettingsFile, 'w') as f:
            if kodi_version >= 17: xml_data = xml_data_advSettings_New(str(BUFFERSIZE))
            else: xml_data = xml_data_advSettings_old(str(BUFFERSIZE))
            f.write(xml_data)
            dialog.ok(AddonTitle, f'Buffer Size Set to: [B]{int(BUFFERSIZE)}[/B]  aka  [B]{int(BUFFER_F)} MB[/B]\nPlease restart Kodi for the settings to apply.')
    elif choice == 0:
        BUFFERSIZE = get_keyboard(default=str(BUFFERSIZE), heading='INPUT BUFFER SIZE')
        with open(AdvancedSettingsFile, 'w') as f:
            if kodi_version >= 17: xml_data = xml_data_advSettings_New(str(BUFFERSIZE))
            else: xml_data = xml_data_advSettings_old(str(BUFFERSIZE))
            f.write(xml_data)
            dialog.ok(AddonTitle, f'Buffer Size Set to: [B]{int(BUFFERSIZE)}[/B]  aka  [B]{(int(BUFFERSIZE) // (1024 * 1024))} MB[/B]\nPlease restart Kodi for the settings to apply.')


def viewAdvancedSettings():
    try:
        TextViewer.text_view(AdvancedSettingsFile)
    except:
        dialog.ok(AddonTitle, 'Error\nUnable to view the advancedsettings.xml file.\nMight not have one yet.')
        sys.exit(0)


def clearAdvancedSettings():
    try:
        deleteFile(AdvancedSettingsFile)
        dialog.ok(AddonTitle, 'Success', 'The advancedsettings.xml has been removed.')
    except:
        dialog.ok(AddonTitle, 'Error\nUnable to remove the advancedsettings.xml file.\nMight not have one yet.')
        sys.exit(0)
