#!/usr/bin/env python
# source: https://github.com/sanderjo/fast.com
"""
Python CLI-tool (without need for a GUI) to measure Internet speed with fast.com
"""

import json
import re
import socket
import time
from threading import Thread
from urllib.request import urlopen

from modules.control import dp, log


def gethtmlresult(url, result, index):
    """
    get the stuff from url in chuncks of size CHUNK, and keep writing the number of bytes retrieved into result[index]
    """
    req = urlopen(url)
    CHUNK = 100 * 1024
    i = 1
    while True:
        chunk = req.read(CHUNK)
        if not chunk: break
        result[index] = i * CHUNK
        i += 1


def application_bytes_to_networkbits(bytes):
    # convert bytes (at application layer) to bits (at network layer)
    return bytes * 8 * 1.0415  # 8 for bits versus bytes  # 1.0416 for application versus network layers


def findipv4(fqdn):
    """
        find IPv4 address of fqdn
    """
    return socket.getaddrinfo(fqdn, 80, socket.AF_INET)[0][4][0]


def findipv6(fqdn):
    """
        find IPv6 address of fqdn
    """
    return socket.getaddrinfo(fqdn, 80, socket.AF_INET6)[0][4][0]


def fast_com(verbose=False, maxtime=15, forceipv4=False, forceipv6=False):
    """
        verbose: print debug output
        maxtime: max time in seconds to monitor speedtest
        forceipv4: force speed test over IPv4
        forceipv6: force speed test over IPv6
    """
    dp.create('speedtest', '')
    dp.update(0)
    # goto fast.com to get the javascript file
    url = 'https://fast.com/'
    try: urlresult = urlopen(url)
    except: return 0
    response = urlresult.read().decode('ISO-8859-1', errors='replace')
    # log(f'response: {response}')
    links = re.findall(r'<script src="(.*?)"></script>', response)[0]
    # for line in response.split('\n'):
    # We're looking for a line like
    #           <script src="/app-40647a.js"></script>
    # if line.find('script src') >= 0:
    #     jsname = line.split('"')[1]  # At time of writing: '/app-40647a.js'
    # From that javascript file, get the token:
    url = f'https://fast.com{links}'
    log(f'url: {url}')
    try: urlresult = urlopen(url)
    except: return 0
    if verbose: log(f'javascript url is {url}')
    allJSstuff = urlresult.read().decode('ISO-8859-1', errors='replace')  # this is a obfuscated Javascript file
    # log(f'allJSstuff: {allJSstuff}')
    '''
    # OLD STUFF ... beautiful, but needs the js-beautifier module, which was a non-stardard requirement
    res = jsbeautifier.beautify(allJSstuff) # ... so un-obfuscate it
    for line in res.split('\n'):
        if line.find('token:') >= 0:
            token = line.split('"')[1]
    if verbose: print "token is", token
    '''
    '''
    We're searching for the "token:" in this string:
    .dummy,DEFAULT_PARAMS={https:!0,token:"YXNkZmFzZGxmbnNkYWZoYXNkZmhrYWxm",urlCount:3,e
    '''
    # token = re.findall(r'token:"(.*?)",', allJSstuff)[0]
    token = re.findall(r'token:"(.*?)",', str(allJSstuff), re.DOTALL | re.I)
    # log(f'token: {token}')
    # for line in allJSstuff.split(','):
    #     if line.find('token:') >= 0:
    #         if verbose: print("line is: %s" % line)
    #         token = line.split('"')[1]
    #         if verbose: print("token is: %s" % token)
    #         if token:
    #             break
    # https://api.fast.com/netflix/speedtest?https=true&token=YXNkZmFzZGxmbnNkYWZoYXNkZmhrYWxm&urlCount=3
    # https://api.fast.com/netflix/speedtest?https=true&token=YXNkZmFzZGxmbnNkYWZoYXNkZmhrYWxm&urlCount=3
    # lynx --dump  'https://api.fast.com/netflix/speedtest?https=true&token=YXNkZmFzZGxmbnNkYWZoYXNkZmhrYWxm&urlCount=3'  | python -mjson.tool
    #url = 'https://api.fast.com/netflix/speedtest?https=true&token=YXNkZmFzZGxmbnNkYWZoYXNkZmhrYWxm&urlCount=3'
    # With the token, get the (3) speed-test-URLS from api.fast.com (which will be in JSON format):
    baseurl = 'https://api.fast.com/'
    if forceipv4:
        # force IPv4 by connecting to an IPv4 address of api.fast.com (over ... HTTP)
        ipv4 = findipv4('api.fast.com')
        baseurl = f'http://{ipv4}/'  # HTTPS does not work IPv4 addresses, thus use HTTP
    elif forceipv6:
        # force IPv6
        ipv6 = findipv6('api.fast.com')
        baseurl = f'http://[{ipv6}]/'
    url = f'{baseurl}netflix/speedtest?https=true&token={token[0]}&urlCount=3'  # Not more than 3 possible
    if verbose: log(f"API url is: {url}")
    try: urlresult = urlopen(url, None, 2)  # 2 second time-out
    except:
        if verbose: log('No connection possible')  # probably IPv6, or just no network
        return 0  # no connection, thus no speed
    jsonresult = urlresult.read()
    parsedjson = json.loads(jsonresult)
    # Prepare for getting those URLs in a threaded way:
    amount = len(parsedjson)
    if verbose: log(f'Number of URLs: {amount}')
    threads = [None] * amount
    results = [0] * amount
    urls = [None] * amount
    for i, jsonelement in enumerate(parsedjson):
        urls[i] = jsonelement['url']  # fill out speed test url from the json format
        if verbose: log(f'jsonelement url: {jsonelement["url"]}')
    # Let's check whether it's IPv6:
    for url in urls:
        fqdn = url.split('/')[2]
        try:
            socket.getaddrinfo(fqdn, None, socket.AF_INET6)
            if verbose: log('IPv6')
        except: pass
    # Now start the threads
    for i in range(len(threads)):
        threads[i] = Thread(target=gethtmlresult, args=(urls[i], results, i))
        threads[i].daemon = True
        threads[i].start()
    # Monitor the amount of bytes (and speed) of the threads
    time.sleep(1)
    sleepseconds = 3  # 3 seconds sleep
    lasttotal = 0
    highestspeedkBps = 0
    maxdownload = 60  #MB
    nrloops = maxtime // sleepseconds
    upd = 100 // nrloops
    percent = 0
    for loop in range(nrloops):
        total = sum(results[i] for i in range(len(threads)))
        delta = total - lasttotal
        speedkBps = (delta / sleepseconds) / 1024
        percent += upd
        dp.update(percent, f'Start speedtest against fast.com ...\nSpeed: {speedkBps:.2f} kBps')
        # if verbose:
        log('~~~~~')
        log(f'Loop: {loop}')
        log(f'Speed: {speedkBps:.2f} kBps')
        log(f'Total MB: {(total / (1024 * 1024)):.2f}')
        log(f'Delta MB: {(delta / (1024 * 1024)):.2f}')
        log(f'Speed kB/s: {speedkBps:.2f}')
        log(f'aka Mbps: {(application_bytes_to_networkbits(speedkBps) / 1024):.2f}')
        '''
        if total/(1024*1024) > maxdownload:
            break
        '''
        lasttotal = total
        if speedkBps > highestspeedkBps: highestspeedkBps = speedkBps
        time.sleep(sleepseconds)

        if dp.iscanceled():
            log('DOWNLOAD CANCELLED')  # need to get this part working
            break
    '''
    print "Now wait for threads to end:"
    '''
    for i in range(len(threads)):
        threads[i].join()
    Mbps = (application_bytes_to_networkbits(highestspeedkBps) / 1024)
    Mbps = float(f'{Mbps:.1f}')
    log(f'Highest Speed (kB/s): {highestspeedkBps:.2f} aka Mbps {Mbps:.2f}')
    # print(f'Debug: total in bytes {total}')
    dp.close()
    return Mbps


######## MAIN #################
# if __name__ == "__main__":
#     print("let's speed test:")
    # print("\nSpeed test, IPv4, with verbose logging:")
    # print(fast_com(verbose = True, maxtime = 18, forceipv4 = True))
    # print("\nSpeed test, IPv6:")
    # print(fast_com(maxtime = 12, forceipv6 = True))
    #fast_com(verbose=True, maxtime=25)
    # print("\ndone")
