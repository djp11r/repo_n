# -*- coding: utf-8 -*-

import json
import sys
from traceback import print_exc

from modules.advsetz import advancedsettings, clearadvancedsettings, viewadvancedsettings
from modules.control import additem, addonfanart, addonicon, build_url, customcolor, endofdirectory, execute, getsetting, getsettingenabled, infodialog, kodi_version, log, make_listitem, selectdialog, sysaddon
from modules.traktit import get_kodi_frm_smb
from modules.utilz import delete_crash_logs, delete_debuglogs, logview, open_url, workingurl

menu_icon = 'DefaultAddonProgram.png'


class Navigator:

    def __init__(self):
        self.build_url = build_url
        self.additem = additem
        self.make_listitem = make_listitem
        self._getsetting = getsetting
        self._getsettingenabled = getsettingenabled
        self.handle = int(sys.argv[1])

    def main(self):
        getsetting = self._getsetting
        if getsetting('navi.dev') == 'true':
            self._add_fast('Testing dialog', 'testtingd')
            self._add_fast('You Tube Download', 'ytdl')
        if getsetting('navi.extra_menu') == 'true':
            self._add_fast('ETools', 'navigator.extra_menu', folder=True)
            self._add_fast('File DL', 'navigator.local_menu', folder=True)
        if getsetting('navi.apks') == 'true':
            self._add_fast('Apk DL', 'navigator.applist', folder=True)
        self._add_fast('Maintenance', 'navigator.maintenance', folder=True)
        if getsetting('navi.tools') == 'true':
            self._add_fast('Tools', 'navigator.tools', folder=True)
        self._add_fast('Settings', 'settings')
        if getsetting('navi.logs') == 'true':
            self._add_fast('Logs', 'navigator.actlogmenu')
            self._add_fast('ChangeLog', 'changelog')
        endofdirectory(self.handle)

    def _add_fast(self, name, mode, folder=False, icon=menu_icon, url=None):
        """
        """
        params = {'mode': mode, 'name': name}
        if folder:
            params['isFolder'] = 'true'
        if url:
            params['url'] = url
        build_url = self.build_url
        make_listitem = self.make_listitem
        additem = self.additem
        li = make_listitem()
        li.setLabel(name)
        li.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': icon})
        info = li.getVideoInfoTag()
        info.setMediaType('video')
        info.setPlot(' ')
        additem(self.handle, build_url(params), li, folder)

    def extra_menu(self):
        self._add_fast('Get Addon from smb', 'get_adon_frm_smb')
        self._add_fast('Send kodi Log to smb', 'send_kodi_log_smb')
        self._add_fast('View Log File', 'viewlog')
        self._add_fast('Get setting files from smb', 'get_setting_smb')
        self._add_fast('Clean Log File', 'clean_log_file')
        self._add_fast('Send setting files to smb', 'send_setting_smb')
        self._add_fast('Clean setting', 'reset_upd_setting')
        self._add_fast('All Errors', 'errorchecking')
        self._add_fast('Convert path to special', 'fix_special')
        self._add_fast('Extract zip', 'zipextr')
        self._add_fast('Clear Old Thumbs', 'deleteold_Thumbnails')
        self._add_fast('Clean addon_data folders', 'clane_adondata')
        self._add_fast('Clean All Log File', 'clean_all_log_file')
        self._add_fast('Save userdata n zip', 'get_userdata')
        self._add_fast('DNS Leak Test', 'dns_leak_test')
        self._add_fast('You Tube API update', 'set_api')
        self._add_fast('Skin setting forced backup', 'skin_backup')
        endofdirectory(self.handle)

    def maintenance(self):
        self._add_fast('Clear All (Cache, Packages, Thumbnails)', 'clear_all')
        self._add_fast('Clear Cache', 'deleteCache')
        self._add_fast('Clear Packages', 'deletepackages')
        self._add_fast('Clear Thumbnails', 'clearthumb')
        self._add_fast('Clear MyVideos db', 'clean_myvideos_db')
        self._add_fast('[I]Clear Resolvers Cache[/I]', 'reset_resolverscache')
        self._add_fast('[I]Clear Empty Folders[/I]', 'clearemptyfolders')
        endofdirectory(self.handle)

    def tools(self):
        self._add_fast('Backup/Restore', 'backup_restore')
        self._add_fast('AdvancedSettings', 'navigator.advancedsettingsmenu')
        self._add_fast('Net Info', 'netinfo')
        self._add_fast('Kodi App Installer', 'kodiappinstall')
        self._add_fast('Builds/Wizards', 'navigator.builds', folder=True)
        self._add_fast('Resolveurl Link tester', 'resolveurl_link_tester')
        self._add_fast('SpeedTest', 'speedtest')
        self._add_fast('Check Sources', 'checksources')
        self._add_fast('Check Repos', 'checkrepos')
        self._add_fast('Check for Updates (ALL)', 'forceupdate')
        self._add_fast('Disable AutoUpdates(Notify but dont install)', 'disableautoupdates')
        self._add_fast('Enable Unknown Sources', 'enableunknownsources')
        self._add_fast('Enable Addons (ALL)', 'enableaddons')
        endofdirectory(self.handle)

    def builds(self):
        getsetting = self._getsetting
        if getsetting('enable_wiz1') != 'false':
            self._add_fast(f"[Wizard] {getsetting('name1')}",
                           'install_build',
                           url=getsetting('url1'),
                           icon=getsetting('img1'))
        if getsetting('enable_wiz2') != 'false':
            self._add_fast(f"[Wizard] {getsetting('name2')}",
                           'install_build',
                           url=getsetting('url2'),
                           icon=getsetting('img2'))
        if getsetting('enable_wiz3') != 'false':
            self._add_fast(f"[Wizard] {getsetting('name3')}",
                           'install_build',
                           url=getsetting('url3'),
                           icon=getsetting('img3'))
        self._add_fast('[I]Swap Skin[/I]', 'skinswap')
        self._add_fast('[I]Force Close Kodi[/I]', 'force_close')
        self._add_fast('[I]Reload Skin[/I]', 'reloadmyskin')
        self._add_fast('[I]Reload Profile[/I]', 'reloadprofile')
        self._add_fast('[I]Fresh Start[/I]', 'fresh_start')
        endofdirectory(self.handle)

    def actlogmenu(self):
        opts = [
            ('[B]Log Viewer/Uploader[/B]', logview),
            ('[B]Clear CrashLogs[/B]', delete_crash_logs),
            ('[B]Clear DebugLogs[/B]', delete_debuglogs),]
        selectList = [f"[COLOR={customcolor}]{name}[/COLOR]" for name, _ in opts]
        selectList.append(f"[COLOR={customcolor}][[B] Close [/B]][/COLOR]")
        choice = selectdialog(selectList, key=False)
        if not choice:
            return
        for name, func in opts:
            if choice == f"[COLOR={customcolor}]{name}[/COLOR]":
                func()
                return

    def advancedsettingsmenu(self):
        opts = [
        ('Create AdvancedSettings', advancedsettings),
        ('View AdvancedSettings', viewadvancedsettings),
        ('Clear AdvancedSettings', clearadvancedsettings),]
        selectList = [f"[COLOR={customcolor}]{name}[/COLOR]" for name, _ in opts]
        selectList.append(f"[COLOR={customcolor}][[B] Close [/B]][/COLOR]")
        choice = selectdialog(selectList, key=False)
        if not choice: return
        for name, func in opts:
            if choice == f"[COLOR={customcolor}]{name}[/COLOR]":
                func()
                return

    def local_menu(self):
        repo = self._getsetting("git_repo")
        p_file_url = f"https://raw.githubusercontent.com/{repo}/data_dir/mayb/perso_file.json"
        if not workingurl(p_file_url): return infodialog("Error to get perso_m file ...")
        try: data = json.loads(open_url(p_file_url).text)
        except Exception: return infodialog("Error parsing perso_file.json")
        add_fast = self._add_fast
        for item in data:
            if item.get('section') == 'custom':
                add_fast(item['name'], 'myinstall', url=item['url'], icon=item['icon'])
        endofdirectory(self.handle)

    def applist(self):
        repo = self._getsetting("git_repo")
        p_file_url = f"https://raw.githubusercontent.com/{repo}/data_dir/mayb/apks.json"
        if not workingurl(p_file_url): return infodialog("Error to get applist file ...")
        try: data = json.loads(open_url(p_file_url).text)
        except Exception: return infodialog("Error parsing apks.json")
        try:
            smb_apps = get_kodi_frm_smb()
            data.extend(smb_apps)
        except Exception: pass
        add_fast = self._add_fast
        for item in data:
            name = item.get("name", "appinstall")
            version = item.get("version", "")
            label = f"{name} v{version}" if version else name
            add_fast(label, name, url=item['url'], icon=item['icon'])
        endofdirectory(self.handle)
