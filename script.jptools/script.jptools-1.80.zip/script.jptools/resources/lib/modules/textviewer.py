# -*- coding: UTF-8 -*-
from modules.control import addonpath
from xbmcgui import WindowXMLDialog

class TextViewerXML(WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        # super(TextViewerXML, self).__init__(self, args)
        WindowXMLDialog.__init__(self, args)
        self.left_action = 1
        self.right_action = 2
        self.up_action = 3
        self.down_action = 4
        self.closing_actions = [9, 10, 13, 92]
        self.selection_actions = [7, 100]
        self.context_actions = [101, 117]
        self.info_actions = [11, ]
        self.heading = 'JP Tools'
        self.window_id = 2060
        self.heading = kwargs.get('heading') or 'JP Tools'
        self.text = kwargs.get('text')

    def onInit(self):
        super(TextViewerXML, self).onInit()
        self.set_properties()
        self.setFocusId(self.window_id)

    def run(self):
        self.doModal()

    def onAction(self, action):
        if action in self.closing_actions or action in self.selection_actions:
            self.close()

    def set_properties(self):
        self.setProperty('text', self.text)
        self.setProperty('heading', self.heading)

def get_txt_win(text, heading='Log'):
    windows = TextViewerXML('textviewer.xml', addonpath, heading=heading, text=text)
    windows.run()
    del windows
    return