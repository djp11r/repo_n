# -*- coding: utf-8 -*-
import sys
from urllib.parse import parse_qsl

from modules.control import log


def routing():
    # log(f'routing params>>>> {sys.argv}')
    params = dict(parse_qsl(sys.argv[2][1:], keep_blank_values=True))
    # log(f'routing params>>>> {params}')
    _get = params.get
    mode = _get('mode', 'navigator.main')

    if 'navigator.' in mode:
        from modules.navigator import Navigator
        return exec('Navigator().%s()' % mode.split('.')[1])
    elif mode == 'settings':
        from modules.control import opensettings
        return opensettings()
    elif mode == 'colorchoice':
        from modules.control import colorchoice
        return colorchoice()
    elif mode == 'viewtypes':
        from modules.control import getviewtype
        return getviewtype()
    elif mode == 'changelog':
        from modules.control import getchangelog
        return getchangelog()
    elif mode == 'reset_resolverscache':
        from modules.control import resetresolverscache
        return resetresolverscache()
    elif mode == 'force_close':
        from modules.control import forceclose
        return forceclose()
    elif mode == 'reloadprofile':
        from modules.control import reloadprofile
        return reloadprofile()
    elif mode == 'resolveurl_link_tester':
        from modules.control import resolveurl_link_tester
        return resolveurl_link_tester()
    elif mode == 'dl_apk_file':
        from modules.traktit import dl_zip_smb
        return dl_zip_smb(_get('url'))
    elif 'setting_smb' in mode:
        from modules.traktit import get_send_files_smb
        if mode == 'send_setting_smb': return get_send_files_smb(True)
        elif mode == 'get_setting_smb': return get_send_files_smb()
    elif mode == 'myinstall':
        from modules.traktit import myinstall
        return myinstall(_get('name'), _get('url'))
    elif mode == 'ytdl':
        from modules.traktit import ytdl
        # log(f'url:{url}')
        return ytdl()
    elif mode == 'get_adon_frm_smb':
        from modules.get_smb_service import run_update_service
        return run_update_service()
    elif mode == 'reset_upd_setting':
        from modules.traktit import reset_upd_setting
        return reset_upd_setting()
    elif mode == 'zipextr':
        from modules.traktit import zipextr
        return zipextr()
    elif mode == 'get_userdata':
        from modules.traktit import get_userdata
        return get_userdata()
    elif mode == 'clane_adondata':
        from modules.traktit import clane_adondata
        return clane_adondata()
    elif mode == 'testtingd':
        from modules.testing_mod import test
        return test()
    elif 'clear_' in mode:
        from modules.maintenance import clearcache, purgepackages, thumb_cleaner, clean_myvideos_db
        if mode == 'clear_all':
            clearcache()
            purgepackages()
            thumb_cleaner()
            return
        elif mode == 'clear_cache': return clearcache()
        elif mode == 'clear_packages': return purgepackages()
        elif mode == 'clear_thumb': return thumb_cleaner()
        elif mode == 'clear_myvideos_db': return clean_myvideos_db()
    elif mode == 'send_kodi_log_smb':
        from modules.utilz import send_kodi_log_smb
        return send_kodi_log_smb()
    elif mode == 'clean_bineryfile':
        from modules.utilz import nested_file_delete
        return nested_file_delete()
    elif mode == 'errorchecking':
        from modules.utilz import errorchecking
        return errorchecking()
    elif mode == 'checksources':
        from modules.utilz import broken_sources
        return broken_sources()
    elif mode == 'checkrepos':
        from modules.utilz import broken_repos
        return broken_repos()
    elif 'clean_log_file' in mode:
        from modules.utilz import clean_log_file
        if mode == 'clean_log_file': return clean_log_file()
        elif mode == 'clean_log_file_all': return clean_log_file(True)
    elif mode == 'viewlog':
        from modules.utilz import viewlog
        return viewlog()
    elif mode == 'forceupdate':
        from modules.toolz import forceupdatecheck
        return forceupdatecheck()
    elif mode == 'enableaddons':
        from modules.toolz import enable_addons
        return enable_addons()
    elif mode == 'enableunknownsources':
        from modules.toolz import swapus
        return swapus()
    elif mode == 'reloadmyskin':
        from modules.toolz import reloadmyskin
        return reloadmyskin()
    elif mode == 'disableautoupdates':
        from modules.toolz import autoupdatetoggle_system
        return autoupdatetoggle_system(True)
    elif mode == 'netinfo':
        from modules.toolz import netinfo
        return netinfo()
    elif mode == 'appinstall':
        from modules.toolz import appinstaller
        return appinstaller(_get('name'), _get('url'))
    elif mode == 'kodiappinstall':
        from modules.toolz import builditems
        return builditems()
    elif mode == 'speedtest':
        from modules.speedtest import fast_com
        return fast_com()
    elif mode == 'clearemptyfolders':
        from modules.wiz import remove_empty_folders
        return remove_empty_folders()
    elif mode == 'skinswap':
        from modules.wiz import skinswap
        return skinswap()
    elif mode == 'fix_special':
        from modules.wiz import fix_special
        return fix_special()
    elif mode == 'backup_restore':
        from modules.wiz import backup_restore
        return backup_restore()
    elif mode == 'fresh_start':
        from modules.wiz import freshstart
        return freshstart()
    elif mode == 'install_build':
        from modules.wiz import buildinstaller
        return buildinstaller(params)
    elif mode == 'dns_leak_test':
        from modules.dns_leak_test import dns_leak_test
        return dns_leak_test()
    elif mode == 'set_api':
        from modules.upd_yt_api import set_api
        return set_api()
    return
