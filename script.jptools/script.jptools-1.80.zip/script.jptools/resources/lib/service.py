
from modules.service import jpmain
from modules.control import log


if __name__ == '__main__':
	log('Main Monitor Service Starting')
	with jpmain() as omain:
		while not omain.monitor.abortRequested():
			if omain.monitor.waitForAbort(1):
				break
	log('Main Monitor Service Stopped')