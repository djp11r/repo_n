# -*- coding: UTF-8 -*-

import json
import sys
from traceback import print_exc
from urllib.parse import quote_plus

from modules.advsetz import advancedsettings, clearadvancedsettings, viewadvancedsettings
from modules.control import additem, addonfanart, addonicon, addontitle, colorstring, endofdirectory, execute, \
    getsetting, getsettingenabled, infodialog, kodi_version, log, make_listitem, selectdialog, setting, sysaddon
from modules.traktit import get_kodi_frm_smb
from modules.utilz import delete_crash_logs, delete_debuglogs, logview, open_url, workingurl

menu_icon = 'DefaultAddonProgram.png'


def adddiritem(name, action, icon=menu_icon, fanart=addonfanart, description='', url='', isFolder=False):
    if icon is None or icon == '': icon = addonicon
    u = f'{sys.argv[0]}?action={str(action)}&name={quote_plus(name)}&icon={quote_plus(icon)}&fanart={quote_plus(fanart)}&description={quote_plus(description)}'
    if url: u = f'{u}&url={quote_plus(url)}'
    cm = [('Tools Settings', f'RunPlugin({sysaddon}?action=settings&query=(4.0))')]
    name = colorstring(name)
    litem = make_listitem()
    litem.setLabel(name)
    litem.setArt({'poster': 'DefaultAddonProgram.png', 'icon': icon, 'thumb': icon})
    litem.addContextMenuItems(cm)
    info_tag = litem.getVideoInfoTag(True)
    info_tag.setTitle(name)
    info_tag.setPlot(description)
    return additem(handle=int(sys.argv[1]), url=u, listitem=litem, isFolder=isFolder)


def main_menu():
    if getsettingenabled('navi.dev'):
        adddiritem('Testing dialog', 'testtingd', menu_icon, isFolder=True)
        adddiritem('You Tube Download', 'ytdl')
    if getsettingenabled('navi.extra_menu'):
        adddiritem('ETools', 'extra_menu', addonicon, isFolder=True)
        adddiritem('File DL', 'local_menu', isFolder=True)
    if getsettingenabled('navi.apks'): adddiritem('Apk DL', 'applist_m', isFolder=True)
    adddiritem('Maintenance', 'maintenance', description='Maintenance Menu.', isFolder=True)
    if getsettingenabled('navi.tools'): adddiritem('Tools', 'tools', isFolder=True)
    adddiritem('Settings', 'settings', addonicon)
    if getsettingenabled('navi.logs'): adddiritem('Logs', 'log_tools')
    if getsettingenabled('navi.changelog'): adddiritem('ChangeLog', 'changelog')
    endofdirectory(int(sys.argv[1]), cacheToDisc=True)


def maintenance():
    adddiritem('Clear All (Cache, Packages, Thumbnails)', 'clear_all')
    adddiritem('Clear Cache', 'clear_cache')
    adddiritem('Clear Packages', 'clear_packages')
    adddiritem('Clear Thumbnails', 'clear_thumb')
    adddiritem('Clear MyVideos db', 'clean_myvideos_db')
    adddiritem('Clear .pyc files', 'clean_bineryfile')
    adddiritem('Clear Resolvers Cache', 'reset_resolverscache')
    adddiritem('Clear Empty Folders', 'clearemptyfolders')
    adddiritem('Kodi Clean/Update DB', 'kodidbshortz')
    endofdirectory(int(sys.argv[1]))


def tools():
    adddiritem('Backup/Restore Menu.', 'backup_restore')
    adddiritem('AdvancedSettings Menu.', 'advancedsettings')
    adddiritem('Kodi App Installer', 'kodiappinstall', isFolder=True)
    adddiritem('Builds/Wizards Menu.', 'builds', isFolder=True)

    adddiritem('Resolveurl Link tester', 'resolveurl_link_tester')
    adddiritem('Run SpeedTest', 'speedtest')
    adddiritem('View Device Net Info.', 'netinfo', isFolder=True)
    adddiritem('Useful Kodi Shortcuts', 'kodishortz')
    adddiritem('Check Broken Sources', 'checksources')
    adddiritem('Check BrokenRepos', 'checkrepos')
    adddiritem('Check for Updates (All)', 'forceupdate')
    adddiritem('Disable AutoUpdates(Notify but dont install)', 'disableautoupdates')
    adddiritem('Enable Unknown Sources', 'enableunknownsources')
    adddiritem('Enable All Addons.', 'enableaddons')
    endofdirectory(int(sys.argv[1]))


def builds():
    # setView('addons', 'views')
    wizard1 = setting('enable_wiz1')
    if wizard1 != 'false':
        try: adddiritem(f'[Wizard] {getsetting("name1")}', url=getsetting('url1'), isFolder=False)
        except: pass
    wizard2 = setting('enable_wiz2')
    if wizard2 != 'false':
        try: adddiritem(f'[Wizard] {getsetting("name2")}', 'install_build', url=getsetting('url2'), isFolder=False)
        except: pass
    wizard3 = setting('enable_wiz3')
    if wizard3 != 'false':
        try: adddiritem(f'[Wizard] {getsetting("name3")}', 'install_build', url=getsetting('url3'), isFolder=False)
        except: pass
    adddiritem('Swap to Default Skin.', 'skinswap')
    adddiritem('Force Close Kodi', 'force_close')
    adddiritem('Reload Current Skin.', 'reloadmyskin')
    adddiritem('Reload Profile', 'reloadprofile')
    adddiritem('Fresh Start Factory Reset.', 'fresh_start')
    endofdirectory(int(sys.argv[1]), cacheToDisc=True)


def actlogmenu():
    my_options = ['Log Viewer/Uploader', 'Clear CrashLogs', 'Clear DebugLogs', 'Close']
    selectList = [item for item in my_options]
    mychoice = selectdialog(addontitle, selectList, key=False)
    # mychoice = mychoice.replace(f'[COLOR {customcolor}]', '').replace('[/COLOR]', '')
    if mychoice == 'Log Viewer/Uploader': logview()
    elif mychoice == 'Clear CrashLogs': delete_crash_logs()
    elif mychoice == 'Clear DebugLogs': delete_debuglogs()
    elif mychoice == 'Close': return


def advancedsettingsmenu():
    my_options = ['Create AdvancedSettings', 'View AdvancedSettings', 'Clear AdvancedSettings', 'Close']
    selectList = [item for item in my_options]
    mychoice = selectdialog(addontitle, selectList, key=False)
    # log(f'mychoice: {mychoice}')
    # mychoice = mychoice.replace(f'[COLOR {customcolor}]', '').replace('[/COLOR]', '')
    # log(f'mychoice: {mychoice}')
    # mc = f'[COLOR={customcolor}]Create AdvancedSettings[/COLOR]'

    if mychoice == 'Create AdvancedSettings': advancedsettings()
    elif mychoice == 'View AdvancedSettings': viewadvancedsettings()
    elif mychoice == 'Clear AdvancedSettings': clearadvancedsettings()
    elif mychoice == 'Close': return


def kodimenu():
    my_options = ['FileManager', 'AddonBrowser', 'InterfaceSettings', 'SystemSettings', 'ShowSettings', 'SkinSettings', 'ShowSystemInfo', 'Close']
    selectList = [item for item in my_options]
    mychoice = selectdialog(addontitle, selectList, key=False)
    # mychoice = mychoice.replace('[/COLOR]', '')
    if mychoice == 'FileManager': execute("ActivateWindow(10003)")
    elif mychoice == 'AddonBrowser': execute("ActivateWindow(10040)")
    elif mychoice == 'InterfaceSettings': execute("ActivateWindow(10032)")
    elif mychoice == 'SystemSettings': execute("ActivateWindow(10016)")
    elif mychoice == 'ShowSettings': execute("ActivateWindow(10004)")
    elif mychoice == 'SkinSettings': execute("ActivateWindow(10035)")
    elif mychoice == 'ShowSystemInfo': execute("ActivateWindow(10007)")
    elif mychoice == 'Close': return


def kodidbmenu():
    my_options = ['CleanPlaylist', 'UpdateVideoDB', 'CleanVideoDB', 'UpdateMusicDB', 'CleanMusicDB', 'Close']
    selectList = [item for item in my_options]
    mychoice = selectdialog(addontitle, selectList, key=False)
    # mychoice = mychoice.replace('[/COLOR]', '')
    if mychoice == 'CleanPlaylist': execute("Playlist.Clear")
    elif mychoice == 'UpdateVideoDB': execute("UpdateLibrary(video)")
    elif mychoice == 'CleanVideoDB': execute("CleanLibrary(video)")
    elif mychoice == 'UpdateMusicDB': execute("UpdateLibrary(music)")
    elif mychoice == 'CleanMusicDB': execute("CleanLibrary(music)")
    elif mychoice == 'Close': return


def local_menu():
    p_file_url = f'https://raw.githubusercontent.com/{getsetting("git_repo")}/data_dir/mayb/perso_file.json'
    if not workingurl(p_file_url): return infodialog('Error to get local_menu file ...')
    data = open_url(p_file_url).text
    data = json.loads(data)
    for item in data:
        if item['section'] == 'custom':
            adddiritem(item['name'], 'myinstall', item['icon'], item['fanart'], item['description'], item['url'])
    endofdirectory(int(sys.argv[1]), cacheToDisc=True)


def applist():
    p_file_url = f'https://raw.githubusercontent.com/{getsetting("git_repo")}/data_dir/mayb/apks.json'
    if not workingurl(p_file_url): return infodialog('Error to get applist file ...')
    try:
        data = open_url(p_file_url).text
        data = json.loads(data)
        kodiapp_list = get_kodi_frm_smb()
        # log(f'data: {repr(data)} ==')
        # log(f'data: {repr(data + kodiapp_list)} ==')
        data = data + kodiapp_list
        for item in data:
            # log(f'item {item['name']} ==')
            item_name = f'{item["name"]} v{item.get("version", "")}'
            mode = item.get('mode', 'appinstall')
            adddiritem(item_name, mode, item['icon'], item['fanart'], item['description'], item['url'])
        endofdirectory(int(sys.argv[1]))
    except: log(f'Error applist: {print_exc()}')


def extra_menu():
    adddiritem('Get Addon from smb', 'get_adon_frm_smb')
    adddiritem('Get setting files from smb', 'get_setting_smb')
    adddiritem('View Log File', 'viewlog')
    adddiritem('Clean Log File', 'clean_log_file')
    adddiritem('Send setting files to smb', 'send_setting_smb')
    adddiritem('Send kodi Log to smb', 'send_kodi_log_smb')
    adddiritem('Clean setting', 'reset_upd_setting')
    adddiritem('All Errors', 'errorchecking')
    adddiritem('Convert path to special', 'fix_special')
    adddiritem('Extract zip', 'zipextr')
    adddiritem('Clear Old Thumbs', 'clear_thumb')
    adddiritem('Clean addon_data folders', 'clane_adondata')
    adddiritem('Clean All Log File', 'clean_log_file_all')
    adddiritem('Save userdata n zip', 'get_userdata')
    adddiritem('DNS Leak Test', 'dns_leak_test')
    adddiritem('You Tube API update', 'set_api')
    endofdirectory(int(sys.argv[1]))