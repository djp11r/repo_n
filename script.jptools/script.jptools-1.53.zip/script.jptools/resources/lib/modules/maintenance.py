# -*- coding: utf-8 -*-


from modules.control import joinPath, transPath


def clean_oldlog(mode='verbose'):
    from os import listdir
    from modules.control import logpath, infoDialog, log
    logfilepath = listdir(logpath)
    # log(f'logfilepath: {logfilepath}')
    try:
        for item in logfilepath:
            # if item.endswith('.log'):
            if item.endswith('.log') and item not in ['kodi.log', 'kodi.old.log']:
                # log(f'item to clean: {item}')
                l_file = joinPath(logpath, item)
                # log(f'item to clean: {l_file}')
                with open(l_file, 'w') as logFile:
                    logFile.write('')
        if mode == 'verbose': infoDialog('Clean Old log files Completed.')
    except Exception as e: log(f"clean_oldlog Error: {str(e)}")


class cacheEntry(object):
    def __init__(self, namei, pathi):
        self.name = namei
        self.path = pathi

    def setupCacheEntries(self):
        entries = 5  #make sure this refelcts the amount of entries you have
        dialogName = ["WTF", "4oD", "BBC iPlayer", "Simple Downloader", "ITV"]
        pathName = ["special://profile/addon_data/plugin.video.whatthefurk/cache", "special://profile/addon_data/plugin.video.4od/cache", "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache", "special://profile/addon_data/script.module.simple.downloader", "special://profile/addon_data/plugin.video.itv/Images"]
        cacheEntries = []
        for x in range(entries):
            cacheEntries.append(cacheEntry(dialogName[x], pathName[x]))
        return cacheEntries


def clearCache(mode='verbose'):
    from os import remove
    from modules.control import condVisibility, getSettingEnabled, existsPath, infoDialog, homepath, listDir, log, deleteFile
    tempPaths = [transPath('special://temp'), joinPath(homepath, 'addons', 'temp')]
    cachePath = joinPath(homepath, 'cache')
    file_count = 0
    if existsPath(cachePath) is True and getSettingEnabled('tune.cachePath') is True:
        total_files, total_folds = cleanfolder(cachePath)
        file_count = total_files + total_folds
        if mode == 'verbose': infoDialog(f'Clean cache Completed [ {file_count:d} ]')

    for path in tempPaths:
        if existsPath(path):
            total_files, total_folds = cleanfolder(path)
            file_count = total_files + total_folds
    if mode == 'verbose': infoDialog(f'Clean temp Completed [ {file_count:d} ]')

    if condVisibility('system.platform.ATV2'):
        atv2_cache_a = joinPath('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        total_files, total_folds = cleanfolder(atv2_cache_a)
        file_count = total_files + total_folds

        atv2_cache_b = joinPath('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        total_files, total_folds = cleanfolder(atv2_cache_b)
        file_count += total_files + total_folds

        if mode == 'verbose': infoDialog(f'Clean Caches Completed [ {file_count:d} ]')

    cacheEntries = []
    file_count = 0
    for entry in cacheEntries:
        clear_cache_path = transPath(entry.path)
        if existsPath(clear_cache_path) == True and getSettingEnabled('tune.cacheEntries') == True:
            total_files, total_folds = cleanfolder(clear_cache_path)
            file_count += total_files + total_folds
            if mode == 'verbose': infoDialog(f'Clean Caches Completed [ {file_count:d} ]')
    home_clean = listDir(homepath)
    for item in home_clean:
        if 'kodi_crashlog' in item or 'kodi_stacktrace' in item:
            item_path = joinPath(homepath, item)
            log(f'item_path: {item_path}')
            try: deleteFile(item_path)
            except: remove(item_path)
    if mode == 'verbose': infoDialog('Clean Cache Completed.')


def thumb_cleaner():
    from os.path import getsize
    from modules.control import deleteFile, oldthumb, existsPath, log, infoDialog, dp, databasepath
    import sqlite3 as database
    thumbs_folder = transPath('special://thumbnails')
    dbfile = transPath(joinPath('special://database', 'Textures13.db'))
    item_list = []
    minimum_uses = 30
    size = images = 0
    if existsPath(dbfile):
        dbcon = database.connect(dbfile, isolation_level=None)
        dbcur = dbcon.cursor()
        dbcur.execute('''PRAGMA synchronous = OFF''')
        dbcur.execute('''PRAGMA journal_mode = OFF''')
    else: return infoDialog('there is no Database file: Failed')
    log(f"[Clean Old Thumbnails] Cleaning thumbnails older than {str(oldthumb)}, or haven't been accessed at least {minimum_uses} times.")
    dbcur.execute("SELECT idtexture FROM sizes WHERE usecount < ? AND lastusetime < ?", (minimum_uses, str(oldthumb)))
    result = dbcur.fetchall()
    result_length = len(result)
    if not result_length > 0: return infoDialog('No Thumbnails to Clear')
    for count, item in enumerate(result):
        _id = item[0]
        dbcur.execute("SELECT cachedurl FROM texture WHERE id = ?", (_id, ))
        url = dbcur.fetchall()[0][0]
        path = joinPath(thumbs_folder, url)
        try:
            item_list.append((_id,))
            imagesize = getsize(path)
            deleteFile(path)
            size += imagesize
            images += 1
        except: pass
    dbcur.executemany("DELETE FROM sizes WHERE idtexture = ?", item_list)
    dbcur.executemany("DELETE FROM texture WHERE id=?", item_list)
    dbcur.execute("VACUUM")
    dbcon.commit()
    dbcon.close()
    removed = f"{size / 1024000.0:.0f}"
    msg = f"[COLOR red]Clear Thumbs: {images} Files / {removed} MB[/COLOR]!"
    log(msg)
    return infoDialog(msg)


def purgePackages(mode='verbose'):
    from modules.control import infoDialog
    purgePath = transPath('special://home/addons/packages')
    total_files, total_folds = cleanfolder(purgePath)
    file_count = total_files + total_folds
    if mode == 'verbose': infoDialog(f'Clean Packages Completed [ {file_count:d} ]')


def clean_MyVideos_db(modify=False):
    from modules.control import log, databasepath
    import sqlite3 as database

    def keep_plugin_paths():
        q = f"SELECT * FROM {i[0]} WHERE strPath NOT LIKE '{keep_items}'"
        # q = f"SELECT * FROM {i[0]} WHERE idParentPath IS NULL OR idParentPath = ''"
        log(f'q: {q}')
        cursor.execute(q)
        data = cursor.fetchall()
        j = len(data)
        # for row in data:
        #     j += 1
        #     print(row)
        log(f"\nfrom Table {i[0]} Total rows : {j}")

        # delete Null
        # dq_p = f"DELETE FROM {i[0]} WHERE idParentPath IS NULL OR idParentPath = ''"
        dq_p = f"DELETE FROM {i[0]} WHERE strPath NOT LIKE '{keep_items}'"
        log(f'dq_p: {dq_p}')
        if j > 0:
            cursor.execute(dq_p)
            cursor.connection.commit()

    def clean_files_table():
        # q = f"SELECT * FROM {i[0]} WHERE strPath NOT LIKE '{keep_items}'"
        q = f"SELECT * FROM {i[0]} WHERE strFilename IS NULL OR strFilename = '' OR playCount IS NULL"
        log(f'q: {q}')
        cursor.execute(q)
        data = cursor.fetchall()
        j = len(data)
        log(f"\nfrom Table {i[0]} Total rows : {j}")
        # delete Null
        # dq_p = f"DELETE FROM {i[0]} WHERE idParentPath IS NULL OR idParentPath = ''"
        # dq_p = f"DELETE FROM {i[0]} WHERE strFilename IS NULL OR strFilename = '' OR playCount IS NULL"
        dq_p = f"DELETE FROM {i[0]} WHERE strFilename NOT LIKE 'plugin:%'"
        log(f'dq_p: {dq_p}')
        if j > 0:
            cursor.execute(dq_p)
            cursor.connection.commit()

    try:
        db_file = joinPath(databasepath, "MyVideos119.db")
        try:
            textdb = database.connect(db_file)
            cursor = textdb.cursor()
        except Exception as e:
            log(f"DB Connection Error: {str(e)}")
            return False
        q = "SELECT name FROM sqlite_master WHERE type='table'"
        # q = "SELECT name from sqlite_master where type= 'table' AND name NOT LIKE 'sqlite_%'"
        find_deletes = ('%ENet%', 'https:%', 'http:%')
        keep_items = '%plugin:%'
        cursor.execute(q)
        tables_in_db = cursor.fetchall()
        for i in tables_in_db:
            if "path" == i[0]:
                log(f'table: {i[0]}')
                keep_plugin_paths()
            if "files" == i[0]:
                log(f'table: {i[0]}')
                clean_files_table()
        cursor.execute("VACUUM")
        cursor.connection.commit()
    except Exception as error: log(f'e: {error}')
    finally: cursor.close()


def cleanfolder(folder):
    from os import walk, unlink, remove
    from modules.control import deleteFile, log
    import shutil
    file_tokeep = ("commoncache.db", "kodi.log", "kodi.old.log", "xbmc.log", "xbmc.old.log", "spmc.log", "spmc.old.log")
    # log(folder)
    total_files = 0
    total_folds = 0
    try:
        for root, dirs, files in walk(folder):
            if len(dirs) >= 0:
                for d in dirs:
                    try:
                        shutil.rmtree(joinPath(root, d))
                        total_folds += 1
                    except: log(f"Error Deleting Folder: {d}")
            if len(files) >= 0:
                for f in files:
                    try:
                        if f in file_tokeep: continue
                        unlink(joinPath(root, f))
                        total_files += 1
                    except: log(f"Error unlink file: {f}")
                    try:
                        if f in file_tokeep: continue
                        try: deleteFile(joinPath(root, f))
                        except: remove(joinPath(root, f))
                    except Exception as e: log(f"Error: {e} Deleting file: {f}")
    except Exception as e: log(f"cleanfolder Error: {str(e)}")
    return total_files, total_folds
