# -*- coding: utf-8 -*-

import datetime
import glob
import re
import shutil
import time
from os import listdir, makedirs, remove, sep, walk
from os.path import basename, exists, isdir
from traceback import print_exc

from xml.dom.minidom import parse as mdParse

import YDStreamExtractor
import xbmcvfs
from api import TextViewer
from bs4 import BeautifulSoup
from modules.control import AddonID, AddonTitle, TextBox, addondata, backupdir, color1, color2, color3, condVisibility, deleteFile, dialog, dp, execute, existsPath, getSetting, homepath, infoDialog, infoLabel, joinPath, jsonrpc, listDir, log, logpath, makeDirs, packages, platform, read_file, refresh, setSetting, setting, sleep, taddonid, transPath, userdata, userdatapath, wizlog, yesnoDialog
from modules.utilz import get_log_data, workingURL
from modules.wiz import ExtractNOProgress, ExtractZip, REMOVE_EMPTY_FOLDERS, downloader, zfile
from modules.maintenance import purgePackages

ADDONS = joinPath(homepath, 'addons')
ADDOND = joinPath(userdatapath, 'addon_data')
settings_backup = joinPath(addondata, 'settings_backup')
maxlines = 300
datai = ['players_url', 'trakt_watchedindicators', 'trakt_unwatchedcounts', 'trakt_management', 'trakt_token', 'trakt.userHidden', 'furk_password', 'furk_login', 'imdb.user', 'tm.user', 'trakt_access_token', 'trakt_expires_at', 'trakt_indicators_active', 'trakt_refresh_token', 'trakt_user', 'trakt_api_client_id', 'trakt_api_client_secret', 'trakt.auth', 'trakt.refresh', 'trakt.token', 'trakt.user', 'trakt.clientid',
         'trakt.scrobbling', 'trakt.secret', 'trakt.username']
activatet = 'RunPlugin(plugin://plugin.video.%s/?action=authTrakt)'
addon_folder = ['plugin.googledrive', 'plugin.video.bapsyt', 'plugin.video.deccandelight', 'plugin.video.infinite', 'plugin.video.infinity', 'plugin.video.youtube']
file_to_copy = ['settings.xml', 'accounts.db', 'access_manager.json', 'api_keys.json']


def ytdl(url):
    # url = 'http://www.youtube.com/watch?v=_yVv9dx88x0'
    # url = 'https://www.youtube.com/watch?v=8O0AgfjNv3w'
    vid = YDStreamExtractor.getVideoInfo(url, quality=3, resolve_redirects=True)
    # log(f'ytdl: vid: {vid}')
    # if not vid: vid ={'url': url, 'title': 'title', 'description': '', 'thumbnail': ''}
    path = addondata
    if result := YDStreamExtractor.downloadVideo(vid, path):
        full_path_to_file = result.filepath
        infoDialog(f'YDStreamExtractor.downloadVideo Done... path_to_file: {full_path_to_file}')
    elif result.status != 'canceled':
        #download failed
        error_message = result.message
        infoDialog(f'error_message...: {error_message}')


def countFiles(directory):
    files = []
    if isdir(directory):
        for path, dirs, filenames in walk(directory):
            files.extend(filenames)
    return len(files)


def zipfolder(foldername, target_dir, zips_dir):
    """
    as the name suggest
    :param foldername:
    :param target_dir:
    :param zips_dir:
    """
    try:
        zipobj = zfile.ZipFile(zips_dir + foldername, 'w', zfile.ZIP_DEFLATED)
        rootlen = len(target_dir)  # + 1  # + 1 # this is where add 1 extra folder on
        for base, dirs, files in walk(target_dir):
            for f in files:
                fn = joinPath(base, f)
                zipobj.write(fn, joinPath(foldername, fn[rootlen:]))
        zipobj.close()
    except Exception as e: log(f'An error occurred creating zip.file!\n{e}')


def copy_file(src, dest, file_to_save=None):
    # numFiles = countFiles(src)
    try:
        if file_to_save and not exists(dest): makeDirs(settings_backup)
        srcFile = joinPath(src, file_to_save)
        destFile = joinPath(dest, file_to_save)
        # log(f'Directory from: {srcFile}\nDirectory to  : {destFile}')
        shutil.copy(srcFile, destFile)
    # Directories are the same
    except shutil.Error as e: log(f'File are the same so not copied. Error: {e}')
    # Any error saying that the directory doesn't exist
    except OSError as e: log(f'File does not exist not copied. Error: {e}')


def get_userdata():
    addon_list = [addon for addon in addon_folder if condVisibility(f'System.HasAddon({addon})')]
    log(f'get_userdata: addon_list: {addon_list}')
    for addon in addon_list:
        if existsPath(joinPath(ADDOND, addon)):
            from_src = joinPath(ADDOND, addon)
            # log(f'from_src: {from_src}')
            for file in list(listDir(from_src)):
                # log(f'file: {file}')
                if file in file_to_copy:
                    from_src = joinPath(ADDOND, addon)
                    tofile_copy = from_src.replace(homepath, '')
                    to_dest = joinPath(backupdir, 'sourcexml_custom', tofile_copy)
                    if existsPath(from_src):
                        # log(f'addon: {addon}')
                        # log(f'get_userdata: addon: {addon}\nfrom_src: {from_src}\nto_dest: {to_dest}')
                        copy_file(from_src, to_dest, file)
    target_dir = joinPath(backupdir, 'sourcexml_custom')
    # log(f'This folder will b Zip target_dir: {target_dir}\n')
    myfile = joinPath(backupdir, 'sourcexml_custom.zip')
    if exists(myfile): remove(myfile)
    zipfolder('sourcexml_custom.zip', target_dir, backupdir + sep)
    # rename(joinPath(backupdir, 'userdata.zip'), myfile)
    # sleep(100)
    save_for_git = 'D:/GitHub/matrix_plus/repojp/etc'
    if exists(save_for_git):
        copy_file(backupdir, save_for_git, 'sourcexml_custom.zip')
        infoDialog('sourcexml_custom.zip file Created in backupdir folder...')


def get_video_plugins():
    plgn_list = []
    for adn_dir in glob.glob(joinPath(ADDOND, 'plugin.video.*')):
        ad_n = basename(adn_dir)
        if condVisibility(f'System.HasAddon({ad_n})'):
            acnm = ad_n.split('.')[2:]
            act = '.'.join(acnm)
            plgn_list.append(act)
    return plgn_list


def seting_id(who):
    set_ck = []
    if existsPath(joinPath(ADDOND, f'plugin.video.{who}')):
        for plg_i in datai:
            s_id = getSetting(plg_i)
            if s_id != '': set_ck.append(plg_i)
    return set_ck


def trakt(do, who):
    if not existsPath(addondata): makeDirs(addondata)
    if not existsPath(settings_backup): makeDirs(settings_backup)
    if who == 'all':
        plg_list = get_video_plugins()
        for plg_i in plg_list:
            log(f'[Trakt Data] do: {do} Addon installed: plugin.video.{plg_i}')
            plufin_path = transPath(joinPath(ADDOND, f'plugin.video.{plg_i}'))
            if existsPath(plufin_path):
                if do in ['clearaddon', 'restore', 'update']: updateTrakt(do, plg_i)
            else: log(f'[Trakt Data] plugin.video.{plg_i} is not installed path: {plufin_path}')  # setSetting('autonextacleannsave', str(nextsave))  #refresh()
    elif who:
        if existsPath(joinPath(ADDOND, f'plugin.video.{who}')): updateTrakt(do, who)
    else: log(f'[Trakt Data] Invalid Entry: {who}')


def updateTrakt(do, who):
    settings = joinPath(ADDOND, f'plugin.video.{who}', 'settings.xml')
    filei = joinPath(settings_backup, f'{who}_trakt')
    pathi = joinPath(ADDONS, f'plugin.video.{who}')
    set_ck = seting_id(who)
    log(f'[Trakt Data] who: {who} set_ck: ({set_ck})')
    iconi = ''
    expires_at = str(time.time() + 60 * 60 * 24 * 365)  #modify expires at in 365 days!.
    for ipath in glob.glob(joinPath(pathi, '*icon.*')): iconi = ipath
    if iconi == '': iconi = transPath(joinPath(f'special://home/addons/{AddonID}', 'icon.png'))
    if do == 'update':
        filet = False
        try:
            if len(set_ck) > 1:
                with open(filei, 'w') as f:
                    for s_id in datai:
                        if taddonid.getSetting(s_id) != '': f.write(f'<trakt>\n\t<id>{s_id}</id>\n\t<value>{taddonid.getSetting(s_id)}</value>\n</trakt>\n')
                infoDialog(f'[COLOR {color1}]{who}[/COLOR][CR][COLOR {color3}]Trakt Data: Saved![/COLOR]', time=2000)
        except Exception as e: log(f'[Trakt Data] Unable to Update {who} ({e})')
    elif do == 'restore':
        if existsPath(filei):
            f = read_file(filei)
            g = f.replace('\n', '').replace('\r', '').replace('\t', '')
            match = re.compile('<trakt><id>(.+?)</id><value>(.+?)</value></trakt>').findall(g)
            try:
                if len(match) > 0:
                    for s_id, value in match:
                        if s_id == 'trakt_expires_at': value = expires_at
                        taddonid.setSetting(s_id, value)
                        log(f'[Trakt Data] ### {s_id} ({value})')
                infoDialog(f'[COLOR {color1}]{who}[/COLOR][CR][COLOR {color3}]Trakt: Restored![/COLOR]', time=2000)
            except Exception as e: log(f'[Trakt Data] Unable to Restore {who} ({e}) {print_exc()}')
        else: infoDialog(f'{who}[CR]Trakt Data: [COLOR red]Not Found![/COLOR]', time=2000)
    elif do == 'clearaddon':
        try:
            if existsPath(settings) and existsPath(filei):
                f = read_file(filei)
                g = f.replace('\n', '').replace('\r', '').replace('\t', '')
                match = re.compile('<trakt><id>(.+?)</id><value>(.+?)</value></trakt>').findall(g)
                try:
                    if len(match) > 0:
                        for s_id, value in match:
                            if taddonid.getSetting(s_id) != '': taddonid.setSetting(s_id, '')
                except Exception as e: log(f'Error: {print_exc()}')
        except Exception as e: log(f'[Trakt Data] Unable to Clear Addon {who} ({e}) {print_exc()}')
        infoDialog(f'[COLOR {color1}]{who}[/COLOR][CR][COLOR red]Addon Data: Cleared![/COLOR]', time=2000)


def activateTrakt(who):
    if who:
        plufin_path = transPath(joinPath(ADDOND, f'plugin.video.{who}'))
        if existsPath(plufin_path):
            if 'openmeta' in who: act = 'RunPlugin(plugin://plugin.video.openmeta/authenticate_trakt)'
            elif '' in who: act = 'PlayMedia(plugin://plugin.video.seren/?action=authTrakt,return,return)'
            else: act = activatet % who
            taddonid = f'plugin.video.{who}'
            log(f'@@@ \n addon name == {taddonid} \n action == {act}\n')
            if act == '': taddonid.openSettings()
            else: url = execute(act)
        else: dialog.ok(AddonTitle, f'{who} is not currently installed.')
    else:
        refresh()
        return
    check = 0
    while who is None and check != 30:
        check += 1
        time.sleep(10)
    refresh()


def clearSaved(who, over=False):
    if who == 'all':
        for plg_i in settings_backup:
            if existsPath(plg_i):
                ad_n = basename(plg_i)
                acnm = ad_n.split('_')[0]
                clearSaved(acnm, True)
    elif who:
        file = joinPath(settings_backup, f'{who}_trakt')
        if existsPath(file):
            deleteFile(file)
            infoDialog(f'[COLOR {color1}]{who}[/COLOR][CR][COLOR {color2}]Trakt Data: Removed![/COLOR]', time=2000)
        setSetting(who, '')
    if not over: refresh()


def myinstall(name, url):
    log(f'@@@ name: {name} url: {url}')
    if not workingURL(url): return infoDialog('url not working.')
    file_name = url.split('/')[-1]
    if not existsPath(packages): makeDirs(packages)
    dp.create(AddonTitle, f'[COLOR {color2}][B]Downloading:[/B][/COLOR] [COLOR {color1}]{name}[/COLOR]')
    lib = joinPath(packages, file_name)
    try: deleteFile(lib)
    except: pass
    log(f'@@@ name: {name} file_name: {file_name}\nurl: {url}\nlib: {lib}')
    downloader(url, lib, dp)
    sleep(500)
    title = f'[COLOR {color2}][B]Installing:[/B][/COLOR] [COLOR {color1}]{name}[/COLOR]'
    dp.update(0, f'Please Wait:[CR]{title}')
    if 'trakt' in file_name.lower() or 'script' in file_name.lower():
        dp.close()
        return
    elif '.zip' in file_name.lower():
        dp.create('Extracting Zip', 'In Progress...')
        dp.update(0, 'Extracting Zip Please Wait')
        percent = ExtractZip(lib, homepath, dp)  # try: deleteFile(lib)  # except: pass
        time.sleep(2)
    dp.close()
    infoDialog('File has been successfully Updated.')


def zipextr():
    if not existsPath(packages): makeDirs(packages)
    mybuilds = transPath(packages)
    filelist = list(listdir(mybuilds))
    if not filelist:
        infoDialog('Nothing in Packages Folder[CR]Zip Extractor: [COLOR red]Not Found![/COLOR]', time=2000)
        return
    # log('[unZip package file: ] filelist: %s' % filelist)
    selected = dialog.select(f'{AddonTitle}: Select the items to Extract "package".', filelist)

    if selected == -1: infoDialog(f'[COLOR {color2}]Extract Item Canceled![/COLOR]')
    else:
        item = filelist[selected]
        path = transPath(joinPath(mybuilds, item))
        log(f'[unZip File] selected-1: {path}')
        if yesnoDialog(f'[COLOR {color2}]Would you like to Extract Item [COLOR {color1}]{item}[/COLOR] from package folder?[/COLOR]', f'[COLOR {color1}]{path}[/COLOR]', yeslabel='[B][COLOR green]Extract Item[/COLOR][/B]', nolabel='[B][COLOR red]No Cancel[/COLOR][/B]'):
            try:
                # deleteFile(path)
                ExtractNOProgress(path, mybuilds)
                msg = f'[COLOR {color2}]Extract {item} successful![/COLOR]'
            except:
                msg = f'[COLOR {color2}]Extract {item} unsuccessful![/COLOR]'
                log(f'[unZip File] Unable to extract: {path}\n{print_exc()}')
            infoDialog(msg, time=2000)


def clen_wiz_file():
    try:
        if not existsPath(wizlog):
            f = open(wizlog, 'w')
            f.close()
            return
        a = read_file(wizlog)
        lines = a.split('\n')
        if len(lines) > maxlines:
            log(f' ### found line lenght {len(lines)} need to reduce to : {maxlines / 3}')
            start = len(lines) - int(maxlines / 3)
            newfile = lines[start:]
            writing = '\n'.join(newfile)
            with open(wizlog, 'w', encoding='utf8') as logf:
                logf.write(writing)
    except Exception as e: log(f'clen_wiz_file Error: {e}')


def errorlist(logtext):
    # b = logtext.replace('\n', '[CR]').replace('\r', '')
    # match = re.compile('-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--').findall(logtext)
    match = re.compile('-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--', flags=re.DOTALL | re.IGNORECASE).findall(logtext)
    return list(match)


def errorChecking():
    log_file = joinPath(logpath, 'kodi.log')
    if existsPath(log_file):
        log(f'[@@@ errorChecking: ] logsfound:\n {log_file}')
        contents = read_file(log_file)
        error1 = errorlist(contents)
        i = 0
        if len(error1) > 0:
            string = ''
            for item in error1:
                i += 1
                string += f'[B][COLOR red]ERROR NUMBER {i}:[/B][/COLOR]{item.replace(homepath, "/").replace("                                        ", "")}\n'
            if i > 0:
                # TextViewer.text_view(f'{AddonTitle}: Errors in Log', string)
                TextBox('--[ JP Tools Log Viewer ]--', string)
        if len(error1) == 0 or i == 0:
            infoDialog(f'[COLOR {color1}]There is : {len(error1)} Error[/COLOR][CR][COLOR red]In Kodi Log![/COLOR]', time=2000)


def viewlog():
    contents = get_log_data()
    TextViewer.text_view(data=contents)


def clane_adondata():
    if dialog.yesno(AddonTitle, f'[COLOR {color2}]Would you like to remove [COLOR {color1}]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]', yeslabel=f'[B][COLOR {color3}]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
        import shutil
        total = 0
        for folder in glob.glob(joinPath(ADDOND, '*')):
            foldername = folder.replace(ADDOND, '').replace('\\', '').replace('/', '')
            if not existsPath(joinPath(ADDONS, foldername)):
                REMOVE_EMPTY_FOLDERS(folder)
                total += 1
                log(folder)
                shutil.rmtree(folder)
        infoDialog(f'[COLOR {color1}]Clean up Uninstalled[/COLOR][CR][COLOR {color2}]{total} Folders(s) Removed[/COLOR]')
    else: infoDialog(f'[COLOR {color1}]Remove Addon Data[/COLOR][CR][COLOR {color2}]Cancelled![/COLOR]')


def get_file_older_then_hrs(path, time_in_hrs=168):
    """ time_in_hrs = 168 = 24* 7 for 7days """

    st = xbmcvfs.Stat(path)
    file_time = st.st_mtime()
    time_now = datetime.datetime.now()
    time_diff = (datetime.timedelta(hours=time_in_hrs))
    past_time = time_now - time_diff
    comp_time = _get_timestamp(past_time)

    return file_time > comp_time


def _get_timestamp(date_time):
    return int(time.mktime(date_time.timetuple()))


def dl_zip_enet(srs_f, dest_f=None):
    #xbmcvfs.copy(f_enet,packages)
    # we don't use xbmcvfs.copy because we want to wait for the action to complete
    file_exten = ['.log', '.zip']
    if not dest_f:
        file = srs_f.split('/')[-1]
        # log(f'enet_files: {file}')
        dest_f = joinPath(packages, file)
        # log(f'dest_f: {dest_f}')
    if existsPath(dest_f) or any(item in str(dest_f) for item in file_exten):
        # log(f'dest_f: {dest_f}')
        srs_ = xbmcvfs.File(srs_f)
        srs__data = srs_.readBytes()
        srs_.close()
        dest_ = xbmcvfs.File(dest_f, 'w')
        dest_.write(srs__data)
        dest_.close()


def get_enet_fold_path():
    myplatform = platform()
    source_dir = getSetting('w_local_dir_path')#r'smb://ENET/Media/Data/'
    if myplatform == 'android': source_dir = getSetting('a_local_dir_path')
    return transPath(source_dir)


def unzip_instal_addon(install_list):
    HOME_ADDONS = transPath('special://home/addons')
    for addon in install_list:
        # log(f'install Addon: {addon["name"]}')
        try: ExtractNOProgress(addon['dir_'], HOME_ADDONS)
        except: log(f'[unZip File] Unable to extract: {addon}\n{print_exc()}')
    log(f'Total Nos of Addon Updated: {len(install_list)}')
    try:
        current_profile = infoLabel('system.profilename')
        execute(f'LoadProfile({current_profile})')
    except:
        log(f'Error LoadProfile: {print_exc()}')
        infoDialog('Error While Addons Update')


def remov_a_z(vers_str):
    vers_str = vers_str.split('-')[1].replace('~', '').replace('.zip', '')
    vers_str = re.sub(r'[a-z]+', '', vers_str.lower())
    vers_str = re.sub(r'\s+|\+', '', vers_str)
    # vers_str = re.sub(r'(\.zip|convert|\+matrix|a|b|c|d)', '', vers_str)
    return vers_str


def versiontuple(v):
    return tuple(map(int, (v.split("."))))


def intersect(List1, List2, age, enet_dir=''):
    # partial match before - list for values that match from List2
    newfiles, samefiles = [], []
    for i in List2:
        for j in List1:
            if i.split('-')[0] == j.split('-')[0]:  # match name
                if i == j: # match version
                    f_enet = joinPath(enet_dir, i)
                    if get_file_older_then_hrs(f_enet, age) is True:
                        samefiles.append(i)
                if i in j: continue
                p = re.findall('-', j)
                if len(p) > 1: continue
                # log('current: %s p: %s len(p): %s' % (j, p, len(p)))
                current = remov_a_z(j)
                new = remov_a_z(i)
                # log(f'current install: {j} new: {i}')
                # log(f'not_match_vers: {not_match_vers} current: {current} new: {new}')
                try:
                    if versiontuple(new) > versiontuple(current): #if check_version_numbers(current, new):
                        log(f'New Vers will install Addon: {i} Current Vers: {current} New Vers: {new}')
                        newfiles.append(i)
                except: log(f'Error to Check vers of Addon: {i} Current Vers: {current} New Vers: {new} error:{print_exc()}')  # if not not_match_vers: ret.append(i)
    return newfiles, samefiles


def get_adon_frm_enet():
    query = {'jsonrpc': '2.0', 'id': '1', 'method': 'Addons.GetAddons', 'params': {'properties': ['version']}}
    json_response = jsonrpc(query)
    # log(f'json_response: {json_response}')
    addonItems = json_response[0]['result']['addons']
    # log(f'addonItems: {addonItems}')
    install_addons = [f'{addonItem["addonid"]}-{addonItem["version"]}.zip' for addonItem in addonItems]
    # log(f'Installed install_addons: {install_addons}')
    source_dir = get_enet_fold_path()
    get_files_enet()
    dst_dir2 = f'{source_dir}addons/alladdons_/'
    # log(f'Installed for dst_dir2: {dst_dir2}')
    enet_dir = transPath(dst_dir2)
    new_addons = xbmcvfs.listdir(enet_dir)
    # log(f'new_addons: {repr(new_addons)}')
    age = int(setting('file_age'))
    newfiles, samefiles = intersect(install_addons, new_addons[1], age, enet_dir)
    # log(f'newfiles {len(newfiles)}: {newfiles}\nsamefiles {len(samefiles)}: {samefiles}')
    intersect_list = samefiles if not newfiles else newfiles + samefiles
    # log(f'rescrape intersect_list: {intersect_list}')
    if intersect_list: purgePackages()
    install_list = []
    for file in intersect_list:
        # log(f'enet file: {file}')
        f_enet = joinPath(enet_dir, file)
        # log(f'need to install enet file: {file}')
        dl_enet = joinPath(packages, file)
        # log(f'age:{age} need to Update From f_enet: {f_enet} To dl_enet : {dl_enet}')
        dl_zip_enet(f_enet, dl_enet)
        install_list.append({'name': file.split('-')[0], 'dir_': dl_enet})
    log(f'should get: {len(intersect_list)} Total addon Got: {len(install_list)} install_list get_adon_frm_enet: {install_list}')
    if install_list: unzip_instal_addon(install_list)


def send_kodi_log_enet():
    enet_dir = get_enet_fold_path()
    dl_zip_enet(joinPath(logpath, 'kodi.log'), joinPath(enet_dir, 'kodi.log'))
    infoDialog('send kodi.log file to ENET.')


def send_files_enet():
    dest_f = get_enet_fold_path()
    dl_zip_enet(joinPath(userdata, 'addon_data', 'script.module.myaccounts', 'settings.xml'), joinPath(dest_f, 'upd_local_addon_data', 'script.module.myaccounts', 'settings.xml'))
    dl_zip_enet(joinPath(userdata, 'addon_data', 'script.jptools', 'settings.xml'), joinPath(dest_f, 'upd_local_addon_data', 'script.jptools', 'settings.xml'))
    # dl_zip_enet(joinPath(userdata, 'addon_data', 'plugin.video.infinite', 'settings.xml'), joinPath(dest_f, 'upd_local_addon_data', 'plugin.video.infinite', 'settings.xml'))
    dl_zip_enet(joinPath(userdata, 'addon_data', 'plugin.video.infinity', 'settings.xml'), joinPath(dest_f, 'upd_local_addon_data', 'plugin.video.infinity', 'settings.xml'))
    if getSetting('getdb_file'):
        dl_zip_enet(joinPath(userdata, 'addon_data', 'plugin.video.infinite', 'databases', 'hindi_metacache.db'), joinPath(dest_f, 'upd_local_addon_data', 'plugin.video.infinite', 'databases', 'hindi_metacache.db'))
        dl_zip_enet(joinPath(userdata, 'addon_data', 'plugin.video.infinite', 'databases', 'navigator.db'), joinPath(dest_f, 'upd_local_addon_data', 'plugin.video.infinite', 'databases', 'navigator.db'))
        dl_zip_enet(joinPath(userdata, 'addon_data', 'plugin.video.infinite', 'databases', 'settings.db'), joinPath(dest_f, 'upd_local_addon_data', 'plugin.video.infinite', 'databases', 'settings.db'))
        dl_zip_enet(joinPath(userdata, 'addon_data', 'plugin.video.infinite', 'databases', 'skipintro.json'), joinPath(dest_f, 'upd_local_addon_data', 'plugin.video.infinite', 'databases', 'skipintro.json'))
    infoDialog('send file to ENET.')


def get_files_enet():
    srs_f = get_enet_fold_path()
    dl_zip_enet(joinPath(srs_f, 'upd_local_addon_data', 'script.module.myaccounts', 'settings.xml'), joinPath(userdata, 'addon_data', 'script.module.myaccounts', 'settings.xml'))
    dl_zip_enet(joinPath(srs_f, 'upd_local_addon_data', 'script.jptools', 'settings.xml'), joinPath(userdata, 'addon_data', 'script.jptools', 'settings.xml'))
    # dl_zip_enet(joinPath(srs_f, 'upd_local_addon_data', 'plugin.video.infinite', 'settings.xml'), joinPath(userdata, 'addon_data', 'plugin.video.infinite', 'settings.xml'))
    dl_zip_enet(joinPath(srs_f, 'upd_local_addon_data', 'plugin.video.infinity', 'settings.xml'), joinPath(userdata, 'addon_data', 'plugin.video.infinity', 'settings.xml'))
    if getSetting('getdb_file'):
        dl_zip_enet(joinPath(srs_f, 'upd_local_addon_data', 'plugin.video.infinite', 'databases', 'hindi_metacache.db'), joinPath(userdata, 'addon_data', 'plugin.video.infinite', 'databases', 'hindi_metacache.db'))
        dl_zip_enet(joinPath(srs_f, 'upd_local_addon_data', 'plugin.video.infinite', 'databases', 'skipintro.json'), joinPath(userdata, 'addon_data', 'plugin.video.infinite', 'databases', 'skipintro.json'))
        dl_zip_enet(joinPath(srs_f, 'upd_local_addon_data', 'plugin.video.infinite', 'databases', 'navigator.db'), joinPath(userdata, 'addon_data', 'plugin.video.infinite', 'databases', 'navigator.db'))
        dl_zip_enet(joinPath(srs_f, 'upd_local_addon_data', 'plugin.video.infinite', 'databases', 'settings.db'), joinPath(userdata, 'addon_data', 'plugin.video.infinite', 'databases', 'settings.db'))
    infoDialog('get file from ENET.')


def get_kodi_frm_enet():
    purgePackages()
    enet_dir = get_enet_fold_path()
    enet_dir = f'{enet_dir}Apps/'
    enet_files = xbmcvfs.listdir(enet_dir)
    # log(f'enet_files: {enet_files}')
    kodiapp_list = []
    for j in enet_files[1]:
        if 'kodi' in j and j.endswith('.apk'):
            enet_file_path = joinPath(enet_dir, j)
            # log(f'j: {j} enet_file_path: {enet_file_path}')
            kodiapp_list.append({'name': j, 'version': '', 'url': enet_file_path, 'icon': 'https://i.imgur.com/DH7rRx6.png', 'fanart': '', 'mode' : 'dl_apk_file', 'description': j})
    return kodiapp_list


def get_id(settings_file):
    xmlData = read_file(settings_file)
    soup = BeautifulSoup(xmlData, 'html.parser')
    id_list = []
    for tag in soup.find_all('setting'):
        repElemID = tag.get('id')
        id_list.append(repElemID)
    return id_list


def reset_provider(video_adon, settings_xml_data, settings_xml_default):
    # get default id values
    try:
        default_id = get_id(settings_xml_default)
        xmlData = read_file(settings_xml_data)
        soup = BeautifulSoup(xmlData, 'html.parser')
        # log(f'soup: \n{soup}')
        item_clean = False
        removedid = []
        for tag in soup.find_all('setting'):
            repElemID = tag.get('id')
            if repElemID not in default_id:
                removedid.append(repElemID)
                tag.decompose()
                item_clean = True
        #log(soup)
        if item_clean:
            log(f'CleanSettings for: {video_adon} removed : {removedid}')
            with open(settings_xml_data, 'w') as xmlFile:
                xmlFile.seek(0)
                #xmlFile.write('<settings version=\'2\'>')
                xmlFile.write(str(soup).replace('\n\n', ''))  #xmlFile.write(str(soup.prettify(formatter='minimal')))
            sleep(500)
    except: pass


def reset_upd_setting():
    plgn_list = []
    platform_type = getSetting('platform')
    build = platform()
    log(f'platform_type: {platform_type} build: {build}')
    if platform_type != build: setSetting('platform', build)
    for adn_dir in glob.glob(joinPath(ADDOND, '*.*')):
        ad_n = basename(adn_dir)
        if condVisibility(f'System.HasAddon({ad_n})'): plgn_list.append(ad_n)

    dp.create(AddonTitle, '')
    for video_adon in plgn_list:
        settings_xml_data = joinPath(userdatapath, 'addon_data', video_adon, 'settings.xml')
        settings_xml_default = joinPath(homepath, 'addons', video_adon, 'resources', 'settings.xml')
        if existsPath(settings_xml_default) and existsPath(settings_xml_data):
            dp.update(0, f'cleaning setting file: {video_adon}')
            # log(f'setting file cleaned for: {video_adon}\nsettings_xml_default: {settings_xml_default}\nsettings_xml_data: {settings_xml_data}')
            # reset_provider(video_adon, settings_xml_data, settings_xml_default)
            clean_settings(settings_xml_default, settings_xml_data, video_adon)
    dp.close()


def clean_settings(settings_xml_default, settings_xml_data, video_adon):
    def _make_content(dict_object):
        content = '<settings version="2">'
        new_line = '\n    '
        for item in dict_object:
            _id = item['id']
            if _id in active_settings:
                if 'default' in item and 'value' in item: content += f'{new_line}<setting id="{_id}" default="{item["default"]}">{item["value"]}</setting>'
                elif 'default' in item: content += f'{new_line}<setting id="{_id}" default="{item["default"]}"></setting>'
                elif 'value' in item: content += f'{new_line}<setting id="{_id}">{item["value"]}</setting>'
                else: content += f'{new_line}<setting id="{_id}"></setting>'
                content = content.replace('></setting>', ' />')
            else: removed_settings_append(item)
        content += '\n</settings>'
        return content

    try:
        active_settings, current_user_settings, removed_settings = [], [], []
        active_append, current_append, removed_settings_append = active_settings.append, current_user_settings.append, removed_settings.append
        for i in mdParse(settings_xml_default).getElementsByTagName('setting'):
            setting_id = i.getAttribute('id')
            if setting_id: active_append(setting_id)
        for i in mdParse(settings_xml_data).getElementsByTagName('setting'):
            dict_item = {}
            setting_id = i.getAttribute('id')
            setting_default = i.getAttribute('default')
            try: setting_value = i.firstChild.data
            except: setting_value = None
            dict_item['id'] = setting_id
            if setting_value: dict_item['value'] = setting_value
            if setting_default: dict_item['default'] = setting_default
            current_append(dict_item)
        new_content = _make_content(current_user_settings)
        with open(settings_xml_data, 'w') as f: f.write(new_content)
        sleep(200)
        infoDialog(f'{len(removed_settings)}  from: {video_adon} Obsolete Settings Entries Removed')
    except Exception as e:
        log(f'clean_settings error: {e}')


def skin_backup_restore(backup=False):
    if getSetting('skin_backup') != 'true': return
    if not exists(settings_backup): makeDirs(settings_backup)
    first_run = False
    plgn_list= ['skin.estuary', 'skin.aeon.nox.silvo']
    file_no = 0
    for video_adon in plgn_list:
        settings_xml_data = joinPath(userdatapath, 'addon_data', video_adon)
        settings_backup_addon_path = joinPath(settings_backup, video_adon)
        if existsPath(joinPath(settings_xml_data, 'settings.xml')):
            file_no += 1
            backup_addon_setting_file = existsPath(joinPath(settings_backup_addon_path, 'settings.xml'))
            if not backup_addon_setting_file or backup:
                copy_file(settings_xml_data, settings_backup_addon_path, 'settings.xml')
                # log(f'first_run {len(plgn_list) == file_no} not existsPath settings_backup_addon_path: {settings_backup_addon_path}')
                first_run = True
                log(f'Backup {video_adon} Setting')
                if len(plgn_list) == file_no: return
            if not first_run and backup_addon_setting_file:
                copy_file(settings_backup_addon_path, settings_xml_data, 'settings.xml')
                log(f'Restored {video_adon} Setting')
    if len(plgn_list) == file_no:
        # try: execute(f'LoadProfile({infoLabel("system.profilename")})')
        # except Exception as Err: log(f'Error: {Err} {print_exc()}')
        return


def appinstaller(name, url):
    if not workingURL(url):
        infoDialog('Error to get App file ...')
        return
    SETTINGS_LOC = '/storage/emulated/0/download'
    appname = url.split('/')[-1]
    log(f'@@@ appname: {appname} == \nurl: {url}  \nappname:{appname} ')
    log(f'platform(): {platform()}')
    use_manager = {0: 'com.android.documentsui', 1: packages}[1]
    log(f'use_manager(): {use_manager}')
    if platform() in ['android', 'atv2', 'arm']:
        try:
            dp.create(AddonTitle, f'[COLOR {color2}][B]Downloading:[/B][/COLOR] [COLOR {color1}]{name}[/COLOR]')
            # file_manager = int(updater.getSetting('File_Manager'))
            # custom_manager = updater.getSetting('Custom_Manager')
            # custom_manager = packages
            lib = joinPath(packages, appname)
            # use_manager = {0: 'com.android.documentsui', 1: custom_manager}[file_manager]
            # use_manager = {0: 'com.android.documentsui', 1: packages}[1]
            downloader(url, lib, dp)
            sleep(500)
            title = f'[COLOR {color2}][B]Installing:[/B][/COLOR] [COLOR {color1}]{name}[/COLOR]'
            dp.update(0, f'Please Wait:[CR]{title}')
            dp.close()
            log(f'Opening {lib} with {use_manager}')
            execute(f'StartAndroidActivity({use_manager},,,"content://{lib}")')
            # execute('StartAndroidActivity('','android.intent.action.INSTALL_PACKAGE ','application/vnd.android.package-archive','content://%s')'%apkfile)
            infoDialog(f'App {appname} has been install...')
        except: log(f'Error appinstaller: {print_exc()}')
    else: infoDialog(f'Its not android so can not install {appname} App file ...')
    return


def check_version_numbers(current, new):  # Compares version numbers and return True if github version is newer
    current = current.split('.')
    new = new.split('.')
    step = 0
    # log(f'current: {current} new: {new}')
    for i in current:
        if int(new[step]) > int(i): return True
        if int(i) > int(new[step]): return False
        if int(i) == int(new[step]):
            step += 1
            continue
    return False


# def compare_strings(a,b):
# result = True
# if len(a) != len(b): print('string lengths do not match!')
# for i,(x,y) in enumerate(zip(a,b)):
# if x != y:
# print(f'char miss-match {x,y} in element {i}')
# result = False
# if result: print('strings match!')
# return result