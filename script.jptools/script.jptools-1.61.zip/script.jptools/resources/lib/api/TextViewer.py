# -*- coding: UTF-8 -*-

import string

import xbmcgui
from modules.control import AddonTitle

moduleName = 'Log Viewer'
contents = ''
path = ''

# get actioncodes from keymap.xml
ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
ACTION_PAGE_UP = 5
ACTION_PAGE_DOWN = 6
ACTION_SELECT_ITEM = 7


class Viewer(xbmcgui.WindowXML):
    def __init__(self, strXMLname, strFallbackPath):
        self.previous_menu = 10
        self.back = 92
        self.page_up = 5
        self.page_down = 6
        # XML id's
        self.main_window = 1100
        self.title_box_control = 20301
        self.content_box_control = 20302
        self.list_box_control = 20303
        self.line_number_box_control = 20201
        self.scroll_bar = 20212

    def onInit(self):
        # title box
        title_box = self.getControl(self.title_box_control)
        title_box.setText(f'{AddonTitle} {moduleName}')
        # content box
        content_box = self.getControl(self.content_box_control)
        content_box.setText(contents)
        # Set initial focus
        self.setFocusId(self.scroll_bar)

    def onAction(self, action):
        # non Display Button control
        if action in [self.previous_menu, self.back]: self.close()

    def onClick(self, control_id):
        if control_id == 20293:
            self.close()
            text_view(path)

    def onFocus(self, control_id):
        pass


def text_view(loc=None, data=None):
    from modules.control import addonInfo, infoDialog, read_file
    global contents
    global path
    contents = ''
    path = loc
    # todo, path can be a url to an internet file
    if not path and not data: return
    contents = read_file(path) if path and not data else f"{data}"
    if not contents:
        infoDialog('The file was empty')
        return
    contents = contents.replace('ERROR', '[COLOR red]ERROR[/COLOR]:').replace('WARNING', '[COLOR gold]WARNING[/COLOR]:')
    win = Viewer('textview-skin.xml', addonInfo('path'))
    win.doModal()
    del win  # To call module put the following in the addon list or context menu  # import TextViewer  # TextViewer.text_view('log')
