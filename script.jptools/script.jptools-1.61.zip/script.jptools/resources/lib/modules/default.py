# -*- coding: UTF-8 -*-

import sys
from traceback import print_exc
from urllib.parse import quote_plus

from modules.control import AddonFanart, AddonIcon, AddonTitle, CustomColor, kodi_version, SelectDialog, addItem, endOfdirectory, execute, getCurrentViewId, getSetting, getSettingEnabled, infoDialog, log, make_listitem, setting, sysaddon
menu_icon = 'DefaultAddonProgram.png'


def adddiritem(name, url, action, icon, fanart, description, isFolder=False):
    # CustomColor = setting('my_ColorChoice')
    # if CustomColor == '': CustomColor = 'none'
    if icon is None or icon == '': icon = MENU_ICON
    u = f'{sys.argv[0]}?url={quote_plus(url)}&action={str(action)}&name={quote_plus(name)}&icon={quote_plus(icon)}&fanart={quote_plus(fanart)}&description={quote_plus(description)}'
    cm = [('Tools Settings', f'RunPlugin({sysaddon}?action=settings&query=(4.0))')]
    name = f'[COLOR {CustomColor}][B]{name}[/B][/COLOR]'
    listitem = make_listitem()
    listitem.setLabel(name)
    listitem.setArt({'poster': 'DefaultAddonProgram.png', 'icon': icon, 'thumb': icon})
    listitem.addContextMenuItems(cm)
    if kodi_version >= 20:
        info_tag = listitem.getVideoInfoTag()
        info_tag.setTitle(name)
        info_tag.setPlot(description)
    else: listitem.setInfo('video', {'title': name, 'Plot': description})
    return addItem(handle=int(sys.argv[1]), url=u, listitem=listitem, isFolder=isFolder)


def MAIN_MENU():
    # setView('addons', 'views')
    # execute(f'Container.SetViewMode({"55"})')
    if getSettingEnabled('navi.dev'):
        adddiritem('Testing dialog', 'url', 'testtingd', menu_icon, AddonFanart, '', isFolder=True)
        adddiritem('You Tube Download', 'url', 'ytdl', menu_icon, AddonFanart, f'{AddonTitle} Settings.')
    if getSettingEnabled('navi.m_menu'):
        adddiritem('ETools', 'url', 'm_menu', AddonIcon, AddonFanart, '', isFolder=True)
        adddiritem('File DL', 'url', 'perso_m', menu_icon, AddonFanart, '', isFolder=True)
    if getSettingEnabled('navi.apks'): adddiritem('Apk DL', 'url', 'applist_m', menu_icon, AddonFanart, '', isFolder=True)
    adddiritem('Maintenance', 'url', 'maintenance', menu_icon, AddonFanart, 'Maintenance Menu.', isFolder=True)
    if getSettingEnabled('navi.tools'): adddiritem('Tools', 'url', 'tools', menu_icon, AddonFanart, 'Tools Menu.', isFolder=True)
    if getSettingEnabled('navi.utils'): adddiritem('Utilities', 'url', 'utilities', menu_icon, AddonFanart, 'Utilities Menu.', isFolder=True)
    adddiritem('Settings', 'url', 'settings', AddonIcon, AddonFanart, f'{AddonTitle} Settings.')
    if getSettingEnabled('navi.logs'): adddiritem('Logs', 'url', 'log_tools', menu_icon, AddonFanart, 'Debug Logs Menu.')
    if getSettingEnabled('navi.changelog'): adddiritem('ChangeLog', 'url', 'changeLog', menu_icon, AddonFanart, f'{AddonTitle} ChangeLog.')
    endOfdirectory(int(sys.argv[1]), cacheToDisc=True)


def MAINTENANCE():
    # setView('addons', 'views')  # descriptions left as template while i think i about adding stats to these options.
    adddiritem('Clear All (Cache, Packages, Thumbnails)', 'url', 'clear_ALL', menu_icon, AddonFanart, 'description')
    adddiritem('Clear Cache', 'url', 'deleteCache', menu_icon, AddonFanart, 'description')
    adddiritem('Clear Packages', 'url', 'deletePackages', menu_icon, AddonFanart, 'description')
    adddiritem('Clear Thumbnails', 'url', 'clearThumb', menu_icon, AddonFanart, 'description')
    adddiritem('Clear MyVideos db', 'url', 'clean_MyVideos_db', menu_icon, AddonFanart, 'description')
    adddiritem('[I]Clear Resolvers Cache[/I]', 'url', 'reset_ResolversCache', menu_icon, AddonFanart, 'description')
    adddiritem('[I]Clear Empty Folders[/I]', 'url', 'clearEmptyFolders', menu_icon, AddonFanart, 'description')
    endOfdirectory(int(sys.argv[1]))


def TOOLS():
    # setView('addons', 'views')
    adddiritem('Backup/Restore', 'url', 'backup_restore', menu_icon, AddonFanart, 'Backup and Restore Menu.')
    adddiritem('AdvancedSettings', 'url', 'advancedSettings', menu_icon, AddonFanart, 'Advanced Settings Menu.')
    adddiritem('Net Info', 'url', 'netINFO', menu_icon, AddonFanart, 'View Device Net Info.', isFolder=True)
    adddiritem('Kodi ShortCuts', 'url', 'kodishortz', menu_icon, AddonFanart, 'Useful Kodi Shortcuts to speed up Setup.')
    adddiritem('Kodi DB ShortCuts', 'url', 'kodiDBshortz', menu_icon, AddonFanart, 'Kodi Shortcuts for DB Stuff.')
    adddiritem('Builds/Wizards', 'url', 'builds', menu_icon, AddonFanart, 'Builds and Wizards Menu.', isFolder=True)
    endOfdirectory(int(sys.argv[1]))


def UTILITIES():
    # setView('addons', 'views')
    adddiritem('SpeedTest', 'url', 'speedTest', menu_icon, AddonFanart, 'Run a SpeedTest real quick.')
    adddiritem('Check Sources', 'url', 'checkSources', menu_icon, AddonFanart, 'Check for any Broken Sources.')
    adddiritem('Check Repos', 'url', 'checkRepos', menu_icon, AddonFanart, 'Check for any Broken Repos.')
    adddiritem('Check for Updates (ALL)', 'url', 'forceUpdate', menu_icon, AddonFanart, 'Check for any new Updates.')
    adddiritem('Disable AutoUpdates(Notify but dont install)', 'url', 'disableAutoUpdates', menu_icon, AddonFanart, 'Set AutoUpdates To Notify but not Auto Intsall.')
    adddiritem('Enable Unknown Sources', 'url', 'enableUnknownSources', menu_icon, AddonFanart, 'Enable Unknown Sources.')
    adddiritem('Enable Addons (ALL)', 'url', 'enableAddons', menu_icon, AddonFanart, 'Enable All Addons.')
    endOfdirectory(int(sys.argv[1]))


def BUILDS():
    # setView('addons', 'views')
    adddiritem('Kodi Version Check', 'url', 'getKodiVersion', menu_icon, AddonFanart, 'Check My Kodi Version.')
    adddiritem('Current Profile Check', 'url', 'checkCurrentProfile', menu_icon, AddonFanart, 'Check My Current Profile.')
    wizard1 = setting('enable_wiz1')
    if wizard1 != 'false':
        try: adddiritem(f'[Wizard] {getSetting("name1")}', getSetting('url1'), 'install_build', getSetting('img1'), getSetting('img1'), 'My Custom Build.', isFolder=False)
        except: pass
    wizard2 = setting('enable_wiz2')
    if wizard2 != 'false':
        try: adddiritem(f'[Wizard] {getSetting("name2")}', getSetting('url2'), 'install_build', getSetting('img2'), getSetting('img2'), 'My Custom Build.', isFolder=False)
        except: pass
    wizard3 = setting('enable_wiz3')
    if wizard3 != 'false':
        try: adddiritem(f'[Wizard] {getSetting("name3")}', getSetting('url3'), 'install_build', getSetting('img3'), getSetting('img3'), 'My Custom Build.', isFolder=False)
        except: pass
    adddiritem('[I]Swap Skin[/I]', 'url', 'skinSWAP', menu_icon, AddonFanart, 'Swap to Default Skin.')
    adddiritem('[I]Force Close Kodi[/I]', 'url', 'Force_Close', menu_icon, AddonFanart, 'Force Close Kodi.')
    adddiritem('[I]Reload Skin[/I]', 'url', 'reloadMySkin', menu_icon, AddonFanart, 'Reload Current Skin.')
    adddiritem('[I]Reload Profile[/I]', 'url', 'reloadProfile', menu_icon, AddonFanart, 'Reload My User Profile.')
    adddiritem('[I]Fresh Start[/I]', 'url', 'fresh_start', menu_icon, AddonFanart, 'Wipe Kodi like a Factory Reset.')
    adddiritem('Wizard Settings', 'url', 'wizSettings', menu_icon, AddonFanart, 'Open up Wizard Settings.')
    endOfdirectory(int(sys.argv[1]), cacheToDisc=True)


def actLogMenu():
    from modules.utilz import logView, Delete_Crash_Logs, Delete_DebugLogs
    my_options = ['[B]Log Viewer/Uploader[/B]', '[B]Clear CrashLogs[/B]', '[B]Clear DebugLogs[/B]', '[[B] Close [/B]]']
    selectList = [f'[COLOR={CustomColor}]{Item}[/COLOR]' for Item in my_options]
    mychoice = SelectDialog(AddonTitle, selectList, key=False)
    # mychoice = mychoice.replace(f'[COLOR {CustomColor}]', '').replace('[/COLOR]', '')
    if mychoice == f'[COLOR={CustomColor}][B]Log Viewer/Uploader[/B][/COLOR]': logView()
    elif mychoice == f'[COLOR={CustomColor}][B]Clear CrashLogs[/B][/COLOR]': Delete_Crash_Logs()
    elif mychoice == f'[COLOR={CustomColor}][B]Clear DebugLogs[/B][/COLOR]': Delete_DebugLogs()
    elif mychoice == f'[COLOR={CustomColor}][[B] Close [/B]][/COLOR]': return


def advancedSettingsMenu():
    from modules.advsetz import advancedSettings, viewAdvancedSettings, clearAdvancedSettings
    my_options = ['Create AdvancedSettings', 'View AdvancedSettings', 'Clear AdvancedSettings', '[[B] Close [/B]]']
    selectList = [f'[COLOR={CustomColor}]{Item}[/COLOR]' for Item in my_options]
    mychoice = SelectDialog(AddonTitle, selectList, key=False)
    # log(f'mychoice: {mychoice}')
    # mychoice = mychoice.replace(f'[COLOR {CustomColor}]', '').replace('[/COLOR]', '')
    # log(f'mychoice: {mychoice}')
    # mc = f'[COLOR={CustomColor}]Create AdvancedSettings[/COLOR]'

    if mychoice == f'[COLOR={CustomColor}]Create AdvancedSettings[/COLOR]': advancedSettings()
    elif mychoice == f'[COLOR={CustomColor}]View AdvancedSettings[/COLOR]': viewAdvancedSettings()
    elif mychoice == f'[COLOR={CustomColor}]Clear AdvancedSettings[/COLOR]': clearAdvancedSettings()
    elif mychoice == f'[COLOR={CustomColor}][[B] Close [/B]][/COLOR]': return


def kodiMenu():
    my_options = ['FileManager', 'AddonBrowser', 'InterfaceSettings', 'SystemSettings', 'ShowSettings', 'SkinSettings', 'ShowSystemInfo', '[[B] Close [/B]]']
    selectList = [f'[COLOR={CustomColor}]{Item}[/COLOR]' for Item in my_options]
    mychoice = SelectDialog(AddonTitle, selectList, key=False)
    # mychoice = mychoice.replace('[/COLOR]', '')
    if mychoice == f'[COLOR={CustomColor}]FileManager[/COLOR]': execute("ActivateWindow(10003)")
    elif mychoice == f'[COLOR={CustomColor}]AddonBrowser[/COLOR]': execute("ActivateWindow(10040)")
    elif mychoice == f'[COLOR={CustomColor}]InterfaceSettings[/COLOR]': execute("ActivateWindow(10032)")
    elif mychoice == f'[COLOR={CustomColor}]SystemSettings[/COLOR]': execute("ActivateWindow(10016)")
    elif mychoice == f'[COLOR={CustomColor}]ShowSettings[/COLOR]': execute("ActivateWindow(10004)")
    elif mychoice == f'[COLOR={CustomColor}]SkinSettings[/COLOR]': execute("ActivateWindow(10035)")
    elif mychoice == f'[COLOR={CustomColor}]ShowSystemInfo[/COLOR]': execute("ActivateWindow(10007)")
    elif mychoice == f'[COLOR={CustomColor}][[B] Close [/B]][/COLOR]': return


def kodiDbMenu():
    my_options = ['CleanPlaylist', 'UpdateVideoDB', 'CleanVideoDB', 'UpdateMusicDB', 'CleanMusicDB', '[[B] Close [/B]]']
    selectList = [f'[COLOR={CustomColor}]{Item}[/COLOR]' for Item in my_options]
    mychoice = SelectDialog(AddonTitle, selectList, key=False)
    # mychoice = mychoice.replace('[/COLOR]', '')
    if mychoice == f'[COLOR={CustomColor}]CleanPlaylist[/COLOR]': execute("Playlist.Clear")
    elif mychoice == f'[COLOR={CustomColor}]UpdateVideoDB[/COLOR]': execute("UpdateLibrary(video)")
    elif mychoice == f'[COLOR={CustomColor}]CleanVideoDB[/COLOR]': execute("CleanLibrary(video)")
    elif mychoice == f'[COLOR={CustomColor}]UpdateMusicDB[/COLOR]': execute("UpdateLibrary(music)")
    elif mychoice == f'[COLOR={CustomColor}]CleanMusicDB[/COLOR]': execute("CleanLibrary(music)")
    elif mychoice == f'[COLOR={CustomColor}][[B] Close [/B]][/COLOR]': return


def perso_m():
    from modules.utilz import workingURL, OPEN_URL
    import json
    p_file_url = f'{getSetting("git_url")}/perso_file.json'
    if not workingURL(p_file_url): return infoDialog('Error to get perso_m file ...')
    data = OPEN_URL(p_file_url).text
    data = json.loads(data)
    for item in data:
        if item['section'] == 'custom':
            adddiritem(item['name'], item['url'], 'myinstall', item['icon'], item['fanart'], item['description'])
    endOfdirectory(int(sys.argv[1]), cacheToDisc=True)


def applist():
    from modules.utilz import workingURL, OPEN_URL
    import json
    from modules.traktit import get_kodi_frm_enet
    p_file_url = f'{getSetting("git_url")}/apks.json'
    if not workingURL(p_file_url): return infoDialog('Error to get applist file ...')
    try:
        data = OPEN_URL(p_file_url).text
        data = json.loads(data)
        kodiapp_list = get_kodi_frm_enet()
        # log(f'data: {repr(data)} ==')
        # log(f'data: {repr(data + kodiapp_list)} ==')
        data = data + kodiapp_list
        for item in data:
            # log(f'item {item['name']} ==')
            item_name = f'{item["name"]} v{item.get("version", "")}'
            mode = item.get('mode', 'appinstall')
            adddiritem(item_name, item['url'], mode, item['icon'], item['fanart'], item['description'])
        endOfdirectory(int(sys.argv[1]))
    except: log(f'Error applist: {print_exc()}')


def m_menu():
    # setView('addons', 'views')
    adddiritem('Get Addon from Enet', 'url', 'get_adon_frm_enet', menu_icon, AddonFanart, 'get Addon from enet.')
    adddiritem('Get setting files from ENET', 'url', 'get_setting_enet', menu_icon, AddonFanart, 'Get setting files to ENET.')
    adddiritem('View Log File', 'url', 'viewlog', menu_icon, AddonFanart, 'View Log.')
    adddiritem('Clean Log File', 'url', 'clean_log_file', menu_icon, AddonFanart, 'Clean Log File.')
    adddiritem('Send setting files to ENET', 'url', 'send_setting_enet', menu_icon, AddonFanart, 'Send setting files to ENET.')
    adddiritem('Send kodi Log to ENET', 'url', 'send_kodi_log_enet', menu_icon, AddonFanart, 'Send kodi Log to ENET.')
    adddiritem('Clean setting', 'url', 'reset_upd_setting', menu_icon, AddonFanart, 'Reset setting To default.')
    adddiritem('All Errors', 'url', 'errorChecking', menu_icon, AddonFanart, 'All Errors in log file.')
    adddiritem('Convert path to special', 'url', 'FIX_SPECIAL', menu_icon, AddonFanart, 'Convert path to special.')
    adddiritem('Extract zip', 'url', 'zipextr', menu_icon, AddonFanart, 'extract zip in packag folder.')
    adddiritem('Clear Old Thumbs', 'url', 'deleteold_Thumbnails', menu_icon, AddonFanart, 'Clear Old Thumbs.')
    adddiritem('Clean addon_data folders', 'url', 'clane_adondata', menu_icon, AddonFanart, 'Clean addon_data folders.')
    adddiritem('Clean All Log File', 'url', 'clean_all_log_file', menu_icon, AddonFanart, 'Clean All Log File.')
    adddiritem('Save userdata n zip', 'url', 'get_userdata', menu_icon, AddonFanart, 'Save userdata n zip.')
    adddiritem('DNS Leak Test', 'url', 'dns_leak_test', menu_icon, AddonFanart, 'DNS Leak Test.')
    adddiritem('You Tube API update', 'url', 'set_api', menu_icon, AddonFanart, 'You Tube API update.')
    adddiritem('Skin setting forced backup', 'url', 'skin_backup', menu_icon, AddonFanart, 'Skin setting restor update.')
    endOfdirectory(int(sys.argv[1]))
