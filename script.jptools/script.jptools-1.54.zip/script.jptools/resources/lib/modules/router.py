# -*- coding: utf-8 -*-
import sys
from urllib.parse import parse_qsl


def routing():
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    # params = get_params()
    _get = params.get
    url = None
    action = None
    try: action = _get("action")
    except: pass

    if action is None:
        from modules.default import MAIN_MENU
        MAIN_MENU()
    elif action == 'maintenance':
        from modules.default import MAINTENANCE
        MAINTENANCE()
    elif action == 'tools':
        from modules.default import TOOLS
        TOOLS()
    elif action == 'utilities':
        from modules.default import UTILITIES
        UTILITIES()
    elif action == 'builds':
        from modules.default import BUILDS
        BUILDS()
    elif action == 'wizSettings':
        from modules.control import openSettings
        openSettings(query='3.1')
    elif action == 'settings':
        from modules.control import openSettings
        openSettings()
    elif action == 'perso_m':
        from modules.default import perso_m
        perso_m()
    elif action == 'applist_m':
        from modules.default import applist
        applist()
    elif action == 'dl_apk_file':
        from modules.traktit import dl_zip_enet
        from modules.control import log
        # log(f'params: {params}')
        # log(f'url: {url}')
        dl_zip_enet(_get("url"))
    elif action == 'send_setting_enet':
        from modules.traktit import send_files_enet
        send_files_enet()
    elif action == 'get_setting_enet':
        from modules.traktit import get_files_enet
        get_files_enet()
    elif action == 'send_kodi_log_enet':
        from modules.traktit import send_kodi_log_enet
        send_kodi_log_enet()
    elif action == 'testtingd':
        from modules.under_dev import test_WindowXMLDialog
        test_WindowXMLDialog()
        # from modules.traktit import get_kodi_frm_enet
        # get_kodi_frm_enet()

    elif action == 'set_source_sorting':
        from modules.skip import set_source_sorting
        set_source_sorting(_get("source_sorting_list"))

    elif action == 'colorChoice':
        from api.colorChoice import colorChoice
        colorChoice()
    elif action == 'viewTypes':
        from api.viewTypes import getViewType
        getViewType()
    elif action == 'changeLog':
        from index.ezactions import actChangeLog
        actChangeLog()

    elif action == 'log_tools':
        from index.ezactions import actLogMenu
        actLogMenu()

    elif action == 'clear_ALL':
        from modules.maintenance import clearCache, purgePackages, thumb_cleaner
        clearCache()
        purgePackages()
        thumb_cleaner()

    elif action == 'deleteCache':
        from modules.maintenance import clearCache
        clearCache()

    elif action == 'deletePackages':
        from modules.maintenance import purgePackages
        purgePackages()

    elif action == 'clearThumb':
        from modules.maintenance import thumb_cleaner
        thumb_cleaner()
    elif action == 'clean_MyVideos_db':
        from modules.maintenance import clean_MyVideos_db
        clean_MyVideos_db()
    elif action == 'reset_ResolversCache':
        from modules.toolz import resetResolversCache
        from modules.control import infoDialog
        infoDialog('Clearing Resolver Cache...')
        resetResolversCache()

    elif action == 'clearEmptyFolders':
        from modules.wiz import REMOVE_EMPTY_FOLDERS
        from modules.control import infoDialog
        # infoDialog('Clearing Empty Folders...')
        REMOVE_EMPTY_FOLDERS()
        infoDialog('Done Clearing Empty Folders.')

    elif action == 'advancedSettings':
        from index.ezactions import advancedSettingsMenu
        advancedSettingsMenu()

    elif action == 'checkSources':
        from modules.utilz import Broken_Sources
        Broken_Sources()

    elif action == 'checkRepos':
        from modules.utilz import Broken_Repos
        Broken_Repos()

    elif action == 'forceUpdate':
        from modules.toolz import ForceUpdateCheck
        ForceUpdateCheck()

    elif action == 'enableAddons':
        from modules.toolz import ENABLE_ADDONS
        ENABLE_ADDONS()

    elif action == 'enableUnknownSources':
        from modules.toolz import swapUS
        swapUS()

    elif action == 'Force_Close':
        from modules.forceclose import ForceClose
        ForceClose()

    elif action == 'skinSWAP':
        from modules.wiz import skinswap
        skinswap()

    elif action == 'disableAutoUpdates':
        from modules.toolz import AutoUpdateToggle_System
        AutoUpdateToggle_System()

    elif action == 'kodishortz':
        from index.ezactions import kodiMenu
        kodiMenu()

    elif action == 'kodiDBshortz':
        from index.ezactions import kodiDbMenu
        kodiDbMenu()

    elif action == 'speedTest':
        from modules.control import OkDialog
        from index.speedTest import fast_com
        result = fast_com()
        ok = OkDialog("speedtest with FAST.com", "Result: %s Mbps" % result)

    elif action == 'getKodiVersion':
        from modules.control import get_Kodi_Version, infoDialog
        infoDialog(f'Kodi Version:[B] {get_Kodi_Version()} [/B]')

    elif action == 'checkCurrentProfile':
        from modules.toolz import Current_Profile
        from modules.control import infoDialog
        userName = Current_Profile()
        TestItem = f'Current Profile: {userName}'
        infoDialog(TestItem)

    elif action == 'backup_restore':
        from modules.control import SelectDialog
        from modules.wiz import backup, restoreFolder
        typeOfBackup = ['BACKUP', 'RESTORE']
        # s_type = selectDialog(typeOfBackup)
        s_type = SelectDialog("Select Option", typeOfBackup)
        if s_type == 0:
            modes = ['Full Backup', 'UserData Backup']
            # select = selectDialog(modes)
            select = SelectDialog("Select Option", modes)
            if select == 0:
                backup(mode='full')
            elif select == 1:
                backup(mode='userdata')
        elif s_type == 1:
            restoreFolder()

    elif action == 'reloadMySkin':
        from modules.control import yesnoDialog, AddonTitle
        yesDialog = yesnoDialog(AddonTitle, 'Are you sure you want to Reload Skin?', yeslabel='Yes', nolabel='No')
        if yesDialog:
            from modules.toolz import ReloadMySkin
            ReloadMySkin()

    elif action == 'reloadProfile':
        from modules.control import yesnoDialog, AddonTitle
        yesDialog = yesnoDialog(AddonTitle, 'Are you sure you want to Reload Profile?', yeslabel='Yes', nolabel='No')
        if yesDialog:
            from modules.toolz import reloadProfile, getInfo
            reloadProfile(getInfo('System.ProfileName'))

    elif action == 'fresh_start':
        from modules.control import yesnoDialog, AddonTitle, OkDialog
        yesDialog = yesnoDialog(AddonTitle, 'Are you sure you want to perform a Fresh Start?', yeslabel='Yes', nolabel='No')
        if yesDialog:
            OkDialog(AddonTitle, 'First gotta switch the skin to the default... Confluence or Estuary...')
            from modules.wiz import skinswap, FRESHSTART
            skinswap()
            FRESHSTART()

    elif action == 'install_build':
        from modules.control import yesnoDialog, AddonTitle
        yesDialog = yesnoDialog(AddonTitle, 'Are you sure you want to Install this Build?', yeslabel='Yes', nolabel='No')
        if yesDialog:
            from modules.wiz import skinswap, FRESHSTART, buildInstaller
            skinswap()
            yesDialog = yesnoDialog(AddonTitle, 'Do you want to perform a Fresh Start before Installing your Build?', yeslabel='Yes', nolabel='No')
            if yesDialog:
                FRESHSTART(mode='silent')
            buildInstaller(_get("url"))


    elif action == 'm_menu':
        from modules.default import m_menu
        m_menu()
    elif action == 'myinstall':
        from modules.traktit import myinstall
        myinstall(_get("name"), _get("url"))
    elif action == "netINFO":
        from modules.toolz import NETINFO
        NETINFO()
    elif action == 'appinstall':
        from modules.traktit import appinstaller
        appinstaller(_get("name"), _get("url"))
    elif action == 'ytdl':
        from modules.control import inputDialog, log
        url = inputDialog("Add Youtube URL")
        # log(f'url:{url}')
        from modules.traktit import ytdl
        ytdl(url)

    elif action == 'get_adon_frm_enet':
        from modules.traktit import get_adon_frm_enet
        get_adon_frm_enet()
    elif action == 'viewlog':
        from modules.traktit import viewlog
        viewlog()
    elif action == 'reset_upd_setting':
        from modules.traktit import reset_upd_setting
        reset_upd_setting()
    elif action == 'errorChecking':
        from modules.traktit import errorChecking
        errorChecking()
    elif action == 'FIX_SPECIAL':
        from modules.wiz import FIX_SPECIAL
        FIX_SPECIAL()
    elif action == 'zipextr':
        from modules.traktit import zipextr
        zipextr()
    elif action == 'get_userdata':
        from modules.traktit import get_userdata
        get_userdata()
    elif action == 'dns_leak_test':
        from modules.dns_leak_test import dns_leak_test
        dns_leak_test()
    elif action == 'set_api':
        from modules.upd_yt_api import set_api
        set_api()
    elif action == 'deleteold_Thumbnails':
        from modules.maintenance import thumb_cleaner
        thumb_cleaner()
    elif action == 'clane_adondata':
        from modules.traktit import clane_adondata
        clane_adondata()
    elif action == 'clean_log_file':
        from modules.utilz import clean_log_file
        clean_log_file()
    elif action == 'clean_all_log_file':
        from modules.utilz import clean_log_file
        clean_log_file(True)
