# -*- coding: UTF-8 -*-

import os
import sys
from datetime import date, datetime, timedelta

import unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcvfs
from xbmcaddon import Addon

integer = 1000


def addon(addon_id='script.jptools'):
	return Addon(id=addon_id)

def getKodiVersion():
    return int(xbmc.getInfoLabel("System.BuildVersion")[:2])

addonInfo = addon().getAddonInfo

transPath = xbmcvfs.translatePath
deleteFile = xbmcvfs.delete
makeDirs = xbmcvfs.mkdirs

listDir = os.listdir
existsPath = os.path.exists
joinPath = os.path.join

execute = xbmc.executebuiltin
lang = addon().getLocalizedString
lang2 = xbmc.getLocalizedString

setting = addon().getSetting

addItem = xbmcplugin.addDirectoryItem
endOfdirectory = xbmcplugin.endOfDirectory

dialog = xbmcgui.Dialog()
dp = xbmcgui.DialogProgress()
item = xbmcgui.ListItem
content = xbmcplugin.setContent
# property = xbmcplugin.setProperty
infoLabel = xbmc.getInfoLabel
condVisibility = xbmc.getCondVisibility
# jsonrpc = xbmc.executeJSONRPC
sleep = xbmc.sleep
skin = xbmc.getSkinDir()

AddonID = addonInfo('id')  # ie: 'script.jptools'
AddonTitle = addonInfo('name')  # ie: 'JP Tools'
AddonVersion = addonInfo('version')  # old label  VERSION
AddonIcon = addonInfo('icon')
AddonFanart = addonInfo('fanart')
AddonPath = addonInfo('path')
AddonProfile = transPath(addonInfo('profile'))

homepath = transPath('special://home/')  # used in cogs (Favs stuff)
logpath = transPath('special://logpath/')
userdata = transPath(joinPath('special://home/userdata', ''))  # used in wiz.py (backup)
thumbs = transPath(joinPath('special://home/userdata/Thumbnails', ''))  # used in maintenance.py
skinPath = transPath('special://skin/')

dataPath = transPath(addonInfo('profile'))  #.decode('utf-8')
viewsFile = joinPath(dataPath, 'views.db')
artPath = transPath(joinPath(AddonPath, 'art'))  # used here for theme defs
userdatapath = joinPath(homepath, 'userdata')  # used in cogs (Favs stuff)
databasepath = joinPath(userdatapath, 'Database')  # in clean.py
thumbspath = joinPath(userdatapath, 'Thumbnails')  # in clean.py
addondata = joinPath(userdatapath, 'addon_data', AddonID)  # used in cogs (Favs stuff)
wizlog = joinPath(logpath, 'jptools.log')  # Used here only for log
backupdir = transPath(joinPath('special://home/backupdir', ''))
iconmaint = joinPath(artPath, 'maintenance.png')
iconsettings = joinPath(artPath, 'settings.png')

packages = joinPath(homepath, 'addons', 'packages')
EXCLUDES = [AddonID, 'backupdir', 'script.module.requests', 'script.module.urllib3', 'script.module.chardet', 'script.module.idna', 'script.module.certifi', 'repository.JPB', 'metadata.common.fanart.tv', 'metadata.common.imdb.com', 'metadata.common.theaudiodb.com', 'metadata.common.themoviedb.org', 'metadata.tvshows.themoviedb.org', 'service.xbmc.versioncheck']
EXCLUDES_ADDONS = ['notification', 'packages']

atoday = date.today()
tomorrow = atoday + timedelta(days=1)
threedays = atoday + timedelta(days=3)
biweek = atoday + timedelta(days=14)
nextsave = atoday + timedelta(days=15)
oldthumb = atoday - timedelta(days=int(setting('thumb_age')))
days = [atoday.strftime("%Y-%m-%d"), threedays.strftime("%Y-%m-%d"), biweek.strftime("%Y-%m-%d")]
color1 = 'skyblue'  # 'blue'#'red'
color2 = 'white'
color3 = 'springgreen'
sysaddon = sys.argv[0]
CustomColor = setting('my_ColorChoice')
if CustomColor == '': CustomColor = 'none'


def get_Kodi_Version():
    try: KODIV = float(infoLabel("System.BuildVersion")[:4])
    except: KODIV = 0
    return KODIV


def getCurrentViewId():
    win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    return str(win.getFocusId())


def getSettingEnabled(item):
    is_enabled = setting(item).strip()
    if is_enabled == '' or is_enabled == 'false': return False
    return True


def getSetting(id):
    return addon().getSetting(id)


def to_unicode(text, encoding='utf-8', errors='strict'):
    """Force text to unicode"""
    if isinstance(text, bytes):
        return text.decode(encoding, errors)
    return text


def from_unicode(text, encoding='utf-8', errors='strict'):
    """Force unicode to text"""
    import sys
    if sys.version_info.major == 2 and isinstance(text, unicode):  # noqa: F821; pylint: disable=undefined-variable,useless-suppression
        return text.encode(encoding, errors)
    return text


def get_setting(key, default=None):
    """Get an add-on setting as string"""
    # We use Addon() here to ensure changes in settings are reflected instantly
    try:
        value = to_unicode(addon().getSetting(key))
    except RuntimeError:  # Occurs when the add-on is disabled
        return default
    if value == '' and default is not None:
        return default
    return value


def get_setting_bool(key, default=None):
    """Get an add-on setting as boolean"""
    try:
        return addon().getSettingBool(key)
    except (AttributeError, TypeError):  # On Krypton or older, or when not a boolean
        value = get_setting(key, default)
        if value not in ('false', 'true'):
            return default
        return bool(value == 'true')
    except RuntimeError:  # Occurs when the add-on is disabled
        return default


def get_setting_int(key, default=None):
    """Get an add-on setting as integer"""
    try:
        return addon().getSettingInt(key)
    except (AttributeError, TypeError):  # On Krypton or older, or when not an integer
        value = get_setting(key, default)
        try:
            return int(value)
        except ValueError:
            return default
    except RuntimeError:  # Occurs when the add-on is disabled
        return default


def setSetting(id, value):
    addon().setSetting(id, value)


def get_keyboard(default="", heading="", hidden=False):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    try:
        if keyboard.isConfirmed():
            return keyboard.getText()
    except: pass
    return default


def version():
    num = ''
    try: version = addon('xbmc.addon').getAddonInfo('version')
    except: version = '999'
    for i in version:
        if i.isdigit(): num += i
        else: break
    return int(num)


def make_listitem():
    return xbmcgui.ListItem(offscreen=True)


def normalize(msg):
    try:
        msg = ''.join(c for c in unicodedata.normalize('NFKD', msg) if unicodedata.category(c) != 'Mn')
        return str(msg)
    except:
        return msg


def log(msg, level=xbmc.LOGDEBUG):
    if setting('addon_debug') == 'true' and level == xbmc.LOGDEBUG: level = xbmc.LOGINFO
    try:
        # ex. "\n" is not a printable character so returns False on those cases
        if not msg.isprintable():  msg = f'{normalize(msg)} (NORMALIZED by log())'
        if isinstance(msg, bytes): msg = f'{msg.decode("utf-8", errors="replace")} (ENCODED by log())'
        if setting('addon_debug') == 'true':
            if not setting('debug.location') == '0':
                if not os.path.exists(wizlog): f = open(wizlog, 'w'); f.close()
                # for new line on bottom
                # with open(wizlog, 'a') as f:
                # line = "[%s %s] %s" % (datetime.now().date(), str(datetime.now().time())[:8], msg)
                # f.write(line.rstrip('\r\n')+'\n')
                # for new line on top
                with open(wizlog, 'r+', encoding='utf-8') as f:
                    line = f'[{datetime.now().date()} {str(datetime.now().time())[:8]}]: {msg}'
                    log_file = f.read()
                    f.seek(0, 0)
                    f.write(line.rstrip('\r\n') + '\n' + log_file)
            else: xbmc.log(f'{AddonTitle}: {msg}', level)
    except:
        import traceback
        xbmc.log(f'{AddonTitle}: {msg} \nError: {traceback.print_exc()}', level)


def infoDialog(message, heading=addonInfo('name'), icon='', time=None, sound=False):
    if time == None: time = 3000
    else: time = int(time)
    if icon == '': icon = AddonIcon
    elif icon == 'INFO': icon = xbmcgui.NOTIFICATION_INFO
    elif icon == 'WARNING': icon = xbmcgui.NOTIFICATION_WARNING
    elif icon == 'ERROR': icon = xbmcgui.NOTIFICATION_ERROR
    dialog.notification(heading, message, icon, time, sound=sound)


def TextBox(header, message):
    execute("ActivateWindow(10147)")
    controller = xbmcgui.Window(10147)
    sleep(500)
    controller.getControl(1).setLabel(header)
    controller.getControl(5).setText(message)


def OkDialog(title, message):
    dialog.ok(title, message)


def YesNoDialog(title, message, yes="Yes", no="No"):
    return dialog.yesno(title, message, yeslabel=yes, nolabel=no)


def yesnoDialog(line1, line2='', line3='', heading=addonInfo('name'), nolabel="No", yeslabel="Yes"):
    return dialog.yesno(heading, f"{line1}[CR]{line2}[CR]{line3}", nolabel, yeslabel)


def SelectDialog(title, options, key=True):
    # list_choice = dialog.select(string, dialog_list)
    # if list_choice >= 0: return function_list[list_choice]
    # else: return None
    mychoice = dialog.select(str(title), options)
    if key: return mychoice
    else: return options[mychoice]


def inputDialog(heading=None):
    if not heading: heading=AddonTitle
    else: heading = f'{AddonTitle}\n{heading}'
    return dialog.input(heading=heading, type=xbmcgui.INPUT_ALPHANUM)


def openSettings(query=None, id=addonInfo('id')):
    try:
        idle()
        execute(f'Addon.OpenSettings({id})')
        if query is None: raise Exception()
        c, f = query.split('.')
        if int(getKodiVersion()) >= 18:
            execute(f'SetFocus({int(c) - 100:d})')
            execute(f'SetFocus({int(f) - 80:d})')
        else:
            execute(f'SetFocus({int(c) + 100:d})')
            execute(f'SetFocus({int(f) + 200:d})')
    except: return


def refresh():
    return execute('Container.Refresh')


def closeOkDialog():
    return execute('Dialog.Close(okdialog, true)')


def busy():
    return execute('ActivateWindow(busydialognocancel)')


def idle():
    return execute('Dialog.Close(busydialognocancel)')


def getChangeLog():
    changelogfile = transPath(joinPath(AddonPath, 'changelog.txt'))
    text = read_file(changelogfile)
    id = 10147
    execute(f'ActivateWindow({id:d})')
    sleep(500)
    win = xbmcgui.Window(id)
    retry = 50
    while (retry > 0):
        try:
            sleep(10)
            retry -= 1
            win.getControl(1).setLabel(f'--[ v{AddonVersion} ChangeLog ]--')
            win.getControl(5).setText(text)
            return
        except: pass


def platform():  # used in ForceClose()
    if condVisibility('system.platform.android'): return 'android'
    elif condVisibility('system.platform.linux'): return 'linux'
    elif condVisibility('system.platform.windows'): return 'windows'
    elif condVisibility('system.platform.osx'): return 'osx'
    elif condVisibility('system.platform.atv2'): return 'atv2'
    elif condVisibility('system.platform.ios'): return 'ios'


def jsonrpc(*args, **kwargs):
    """Perform JSONRPC calls"""
    from json import dumps, loads

    # We do not accept both args and kwargs
    if args and kwargs:
        log('ERROR: Wrong use of jsonrpc()')
        return None

    # Process a list of actions
    if args:
        for (idx, cmd) in enumerate(args):
            if cmd.get('id') is None: cmd.update(id=idx)
            if cmd.get('jsonrpc') is None: cmd.update(jsonrpc='2.0')
        return loads(xbmc.executeJSONRPC(dumps(args)))

    # Process a single action
    if kwargs.get('id') is None: kwargs.update(id=0)
    if kwargs.get('jsonrpc') is None: kwargs.update(jsonrpc='2.0')
    return loads(xbmc.executeJSONRPC(dumps(kwargs)))


def json_rpc_multi(method, list_params=None):
    """
    Executes multiple JSON-RPC with the same method in Kodi

    :param method: The JSON-RPC method to call
    :type method: string
    :param list_params: Multiple list of parameters of the method call
    :type list_params: a list of dict
    :returns: dict -- Method call result
    """
    from json import dumps, loads
    request_data = [{'jsonrpc': '2.0', 'method': method, 'id': 1, 'params': params or {}} for params in list_params]
    request = dumps(request_data)
    log(f'Executing JSON-RPC: {{{request}}}')
    raw_response = xbmc.executeJSONRPC(request)
    if 'error' in raw_response: raise IOError(f'JSONRPC-Error {raw_response}')
    return loads(raw_response)


def taddonid(add):
    try: return addon(add)
    except: return False


def read_file(path):
    with open(path, 'r', encoding="utf8") as logf:
        contents = logf.read()
    return contents


def check_backup_dir():
    try:
        if not os.path.exists(backupdir): makeDirs(backupdir)  # log(f'service check_backup_dir is Done')
    except Exception as e:
        infoDialog(f'[COLOR red]Backup Dir Not Found: Create one First![CR]{e}[/COLOR]')
