# -*- coding: UTF-8 -*-
# Names and Digits from Aeon Nox Silvo, Alt names commented behind.


def getViewType():
    from modules.control import SelectDialog, AddonTitle, setSetting, execute
    mychoice = 'Default'
    my_options = ['Default', 'Info Wall', 'Landscape', 'ShowCase', 'ShowCase2', 'Wide List', 'Shift', 'Icons', 'Banner', 'Fanart', 'Wall', '[ [B] Close [/B] ]']
    mychoice = SelectDialog(AddonTitle, my_options, key=False)
    viewType2 = '50'
    if mychoice == 'Default': viewType2 = '50'
    elif mychoice == 'Info Wall': viewType2 = '51'  # Poster
    elif mychoice == 'Landscape': viewType2 = '52'  # Icon Wall
    elif mychoice == 'ShowCase': viewType2 = '53'  # Shift
    elif mychoice == 'ShowCase2': viewType2 = '54'  # Info Wall
    elif mychoice == 'Wide List': viewType2 = '55'
    elif mychoice == 'Shift': viewType2 = '57'
    elif mychoice == 'Icons': viewType2 = '500'  # Wall
    elif mychoice == 'Banner': viewType2 = '501'
    elif mychoice == 'Fanart': viewType2 = '502'
    elif mychoice == 'Wall': viewType2 = '503'
    elif mychoice == '[ [B] Close [/B] ]': return
    setSetting('viewType', mychoice)
    setSetting('viewType2', str(viewType2))
    execute(f"Container.SetViewMode({int(viewType2)})")
    return
