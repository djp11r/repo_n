# -*- coding: utf-8 -*-
import sys
from urllib.parse import parse_qsl

from modules.control import log


def routing():
    # params = dict(parse_qsl(sys.argv[2].replace('?','')))
    params = dict(parse_qsl(sys.argv[2][1:], keep_blank_values=True))
    # log(f'routing params>>>> {params}')
    _get = params.get
    action = _get('action')

    if action is None:
        from modules.default import main_menu
        main_menu()
    elif action == 'maintenance':
        from modules.default import maintenance
        maintenance()
    elif action == 'tools':
        from modules.default import tools
        tools()
    elif action == 'builds':
        from modules.default import builds
        builds()
    elif action == 'local_menu':
        from modules.default import local_menu
        local_menu()
    elif action == 'applist_m':
        from modules.default import applist
        applist()
    elif action == 'log_tools':
        from modules.default import actlogmenu
        actlogmenu()
    elif action == 'advancedsettings':
        from modules.default import advancedsettingsmenu
        advancedsettingsmenu()
    elif action == 'kodishortz':
        from modules.default import kodimenu
        kodimenu()
    elif action == 'kodidbshortz':
        from modules.default import kodidbmenu
        kodidbmenu()
    elif action == 'extra_menu':
        from modules.default import extra_menu
        extra_menu()
    elif action == 'settings':
        from modules.control import opensettings
        opensettings()
    elif action == 'colorchoice':
        from modules.control import colorchoice
        colorchoice()
    elif action == 'viewtypes':
        from modules.control import getviewtype
        getviewtype()
    elif action == 'changelog':
        from modules.control import getchangelog
        getchangelog()
    elif action == 'reset_resolverscache':
        from modules.control import resetresolverscache
        resetresolverscache()
    elif action == 'force_close':
        from modules.control import forceclose
        forceclose()
    elif action == 'reloadprofile':
        from modules.control import reloadprofile
        reloadprofile()
    elif action == 'resolveurl_link_tester':
        from modules.control import resolveurl_link_tester
        resolveurl_link_tester()
    elif action == 'dl_apk_file':
        from modules.traktit import dl_zip_smb
        dl_zip_smb(_get('url'))
    elif 'setting_smb' in action:
        from modules.traktit import get_send_files_smb
        if action == 'send_setting_smb': get_send_files_smb(True)
        elif action == 'get_setting_smb': get_send_files_smb()
    elif action == 'send_kodi_log_smb':
        from modules.traktit import send_kodi_log_smb
        send_kodi_log_smb()
    elif action == 'myinstall':
        from modules.traktit import myinstall
        myinstall(_get('name'), _get('url'))
    elif action == 'ytdl':
        from modules.traktit import ytdl
        # log(f'url:{url}')
        ytdl()
    elif action == 'get_adon_frm_smb':
        from modules.async_get_smbfile import get_smb
        get_smb()
    elif action == 'reset_upd_setting':
        from modules.traktit import reset_upd_setting
        reset_upd_setting()
    elif action == 'errorchecking':
        from modules.traktit import errorchecking
        errorchecking()
    elif action == 'zipextr':
        from modules.traktit import zipextr
        zipextr()
    elif action == 'get_userdata':
        from modules.traktit import get_userdata
        get_userdata()
    elif action == 'clane_adondata':
        from modules.traktit import clane_adondata
        clane_adondata()
    elif action == 'testtingd':
        from modules.testing_mod import test
        test()
    elif 'clear_' in action:
        from modules.maintenance import clearcache, purgepackages, thumb_cleaner, clean_myvideos_db
        if action == 'clear_all':
            clearcache()
            purgepackages()
            thumb_cleaner()
        elif action == 'clear_cache': clearcache()
        elif action == 'clear_packages': purgepackages()
        elif action == 'clear_thumb': thumb_cleaner()
        elif action == 'clear_myvideos_db': clean_myvideos_db()
    elif action == 'clean_bineryfile':
        from modules.utilz import nested_file_delete
        nested_file_delete()
    elif action == 'checksources':
        from modules.utilz import broken_sources
        broken_sources()
    elif action == 'checkrepos':
        from modules.utilz import broken_repos
        broken_repos()
    elif 'clean_log_file' in action:
        from modules.utilz import clean_log_file
        if action == 'clean_log_file': clean_log_file()
        elif action == 'clean_log_file_all': clean_log_file(True)
    elif action == 'viewlog':
        from modules.utilz import viewlog
        viewlog()
    elif action == 'forceupdate':
        from modules.toolz import forceupdatecheck
        forceupdatecheck()
    elif action == 'enableaddons':
        from modules.toolz import enable_addons
        enable_addons()
    elif action == 'enableunknownsources':
        from modules.toolz import swapus
        swapus()
    elif action == 'reloadmyskin':
        from modules.toolz import reloadmyskin
        reloadmyskin()
    elif action == 'disableautoupdates':
        from modules.toolz import autoupdatetoggle_system
        autoupdatetoggle_system(True)
    elif action == 'netinfo':
        from modules.toolz import netinfo
        netinfo()
    elif action == 'appinstall':
        from modules.toolz import appinstaller
        appinstaller(_get('name'), _get('url'))
    elif action == 'kodiappinstall':
        from modules.toolz import builditems
        builditems()
    elif action == 'speedtest':
        from modules.speedtest import fast_com
        fast_com()
    elif action == 'clearemptyfolders':
        from modules.wiz import remove_empty_folders
        remove_empty_folders()
    elif action == 'skinswap':
        from modules.wiz import skinswap
        skinswap()
    elif action == 'fix_special':
        from modules.wiz import fix_special
        fix_special()
    elif action == 'backup_restore':
        from modules.wiz import backup_restore
        backup_restore()
    elif action == 'fresh_start':
        from modules.wiz import freshstart
        freshstart()
    elif action == 'install_build':
        from modules.wiz import buildinstaller
        buildinstaller(params)
    elif action == 'dns_leak_test':
        from modules.dns_leak_test import dns_leak_test
        dns_leak_test()
    elif action == 'set_api':
        from modules.upd_yt_api import set_api
        set_api()
