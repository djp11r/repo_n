# -*- coding: utf-8 -*-

import datetime
import glob
import re
import shutil
import time
from os import listdir, makedirs, sep, walk
from os.path import basename, exists, isdir
from traceback import print_exc

from xml.dom.minidom import parse as mdparse

import xbmcvfs

from modules.control import execute, forceclose, addonid, addontitle, textbox, addondata, backupdir, color1, color2, color3, condvisibility, delete_file, dialog, dp, execute, existspath, getsetting, homepath, infodialog, infolabel, joinpath, jsonrpc, listdir, log, logpath, makedirs, packages, platform, read_file, refresh, setsetting, setting, sleep, taddonid, transpath, userdata, userdatapath, wizlog, yesnodialog, get_soup, addons_path, inputdialog
from modules.utilz import get_log_data, workingurl
from modules.wiz import extractzip, remove_empty_folders, zfile
from modules.downloader import dl_call
from modules.async_get_smbfile import dl_zip_smb
addond = joinpath(userdatapath, 'addon_data')
settings_backup = joinpath(addondata, 'settings_backup')
maxlines = 300
addon_folder = ['plugin.googledrive', 'plugin.video.bapsyt', 'plugin.video.deccandelight', 'plugin.video.infinite', 'plugin.video.infinity', 'plugin.video.youtube']
file_to_copy = ['settings.xml', 'accounts.db', 'access_manager.json', 'api_keys.json']


def ytdl():
    import YDStreamExtractor
    url = inputdialog('Add Youtube URL')
    # url = 'http://www.youtube.com/watch?v=_yVv9dx88x0'
    # url = 'https://www.youtube.com/watch?v=8O0AgfjNv3w'
    vid = YDStreamExtractor.getVideoInfo(url, quality=3, resolve_redirects=True)
    # log(f'ytdl: vid: {vid}')
    # if not vid: vid ={'url': url, 'title': 'title', 'description': '', 'thumbnail': ''}
    path = addondata
    if result := YDStreamExtractor.downloadVideo(vid, path): infodialog(f'YDStreamExtractor.downloadVideo Done... path_to_file: {result.filepath}')
    elif result.status != 'canceled': infodialog(f'error_message...: {result.message}')  #download failed


def countfiles(directory):
    files = []
    if isdir(directory):
        for path, dirs, filenames in walk(directory):
            files.extend(filenames)
    return len(files)


def zipfolder(foldername, target_dir, zips_dir):
    """
    as the name suggest
    :param foldername:
    :param target_dir:
    :param zips_dir:
    """
    try:
        zipobj = zfile.ZipFile(zips_dir + foldername, 'w', zfile.ZIP_DEFLATED)
        rootlen = len(target_dir)  # + 1  # + 1 # this is where add 1 extra folder on
        for base, dirs, files in walk(target_dir):
            for f in files:
                fn = joinpath(base, f)
                zipobj.write(fn, joinpath(foldername, fn[rootlen:]))
        zipobj.close()
    except Exception as e: log(f'An error occurred creating zip.file!\n{e}')


def copy_file(src, dest, file_to_save=None):
    # numFiles = countFiles(src)
    try:
        if file_to_save and not exists(dest): makedirs(settings_backup)
        srcFile = joinpath(src, file_to_save)
        destFile = joinpath(dest, file_to_save)
        # log(f'Directory from: {srcFile}\nDirectory to  : {destFile}')
        shutil.copy(srcFile, destFile)
    # Directories are the same
    except shutil.Error as e: log(f'File are the same so not copied. Error: {e}')
    # Any error saying that the directory doesn't exist
    except OSError as e: log(f'File does not exist not copied. Error: {e}')


def get_userdata():
    addon_list = [addon for addon in addon_folder if condvisibility(f'System.HasAddon({addon})')]
    log(f'get_userdata: addon_list: {addon_list}')
    for addon in addon_list:
        if existspath(joinpath(addond, addon)):
            from_src = joinpath(addond, addon)
            # log(f'from_src: {from_src}')
            for file in list(listdir(from_src)):
                # log(f'file: {file}')
                if file in file_to_copy:
                    from_src = joinpath(addond, addon)
                    tofile_copy = from_src.replace(homepath, '')
                    to_dest = joinpath(backupdir, 'sourcexml_custom', tofile_copy)
                    if existspath(from_src):
                        # log(f'addon: {addon}')
                        # log(f'get_userdata: addon: {addon}\nfrom_src: {from_src}\nto_dest: {to_dest}')
                        copy_file(from_src, to_dest, file)
    target_dir = joinpath(backupdir, 'sourcexml_custom')
    # log(f'This folder will b Zip target_dir: {target_dir}\n')
    myfile = joinpath(backupdir, 'sourcexml_custom.zip')
    if exists(myfile): delete_file(myfile)
    zipfolder('sourcexml_custom.zip', target_dir, backupdir + sep)
    # rename(joinpath(backupdir, 'userdata.zip'), myfile)
    # sleep(100)
    save_for_git = 'D:/GitHub/matrix_plus/repo_n/etc'
    if exists(save_for_git):
        copy_file(backupdir, save_for_git, 'sourcexml_custom.zip')
        infodialog('sourcexml_custom.zip file Created in backupdir folder...')


def myinstall(name, url):
    log(f'@@@ name: {name} url: {url}')
    if not workingurl(url): return infodialog('url not working.')
    file_name = url.split('/')[-1]
    if not existspath(packages): makedirs(packages)
    lib = joinpath(packages, file_name)
    delete_file(lib)
    log(f'@@@ name: {name} file_name: {file_name}\nurl: {url}\nlib: {lib}')
    dp.create(addontitle, f'[COLOR {color2}]Downloading:[/COLOR] [COLOR {color1}]{name}[/COLOR]')
    dl_call(url, lib, dp)
    sleep(500)
    title = f'[COLOR {color2}]Installing:[/COLOR] [COLOR {color1}]{name}[/COLOR]'
    dp.create(addontitle, title)
    dp.update(0, f'Please Wait:[CR]{title}')
    if 'trakt' in file_name.lower() or 'script' in file_name.lower():
        dp.close()
        return None
    elif '.zip' in file_name.lower():
        dp.create('Extracting Zip', 'In Progress...')
        percent = extractzip(lib, homepath, dp)  # delete_file(lib)
        #dp.update(percent, f'Extracting Zip Please Wait {percent} %...')
        time.sleep(2)
        if dp: dp.close()
    infodialog('File has been successfully Updated.')
    return None


def zipextr():
    if not existspath(packages): makedirs(packages)
    mybuilds = transpath(packages)
    filelist = list(listdir(mybuilds))[1]
    if not filelist:
        infodialog('No zip file in Packages Folder[CR]: [COLOR red]Not Found![/COLOR]', time=3000)
        return
    # log(f'[unZip package file: ] filelist: {filelist} :: {repr(filelist)}')
    selected = dialog.select(f'Select the item to Extract in "package" folder', filelist)

    if selected == -1: infodialog(f'[COLOR {color2}]Extract Item Canceled![/COLOR]')
    else:
        item = filelist[selected]
        path = transpath(joinpath(mybuilds, item))
        log(f'[unZip File] selected-1: {path}')
        if yesnodialog(f'[COLOR {color2}]Would you like to Extract in package folder?[/COLOR]', f'Item [COLOR {color1}]{item}[/COLOR] [CR][COLOR {color1}]{path}[/COLOR]', yes='Extract Item', no='No Cancel'):
            try:
                # delete_file(path)
                extractzip(path, mybuilds)
                msg = f'[COLOR {color2}]Extract {item} successful![/COLOR]'
            except:
                msg = f'[COLOR {color2}]Extract {item} unsuccessful![/COLOR]'
                log(f'[unZip File] Unable to extract: {path}\n{print_exc()}')
            infodialog(msg, time=2000)


def clen_wiz_file():
    try:
        if not existspath(wizlog):
            with open(wizlog, 'w', encoding='utf8') as logf:
                logf.write('')
            return
        a = read_file(wizlog)
        lines = a.split('\n')
        if len(lines) > maxlines:
            log(f' ### found line lenght {len(lines)} need to reduce to : {maxlines / 3}')
            start = len(lines) - int(maxlines / 3)
            newfile = lines[start:]
            writing = '\n'.join(newfile)
            with open(wizlog, 'w', encoding='utf8') as logf:
                logf.write(writing)
    except Exception as e: log(f'clen_wiz_file Error: {e}')


def errorlist(logtext):
    # b = logtext.replace('\n', '[CR]').replace('\r', '')
    # match = re.compile(r'-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--').findall(logtext)
    match = re.compile(r'-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--', flags=re.DOTALL | re.IGNORECASE).findall(logtext)
    return list(match)


def errorchecking():
    log_file = joinpath(logpath, 'kodi.log')
    if existspath(log_file):
        log(f'[@@@ errorchecking: ] logsfound:\n {log_file}')
        contents = read_file(log_file)
        error1 = errorlist(contents)
        i = 0
        if len(error1) > 0:
            string = ''
            for item in error1:
                i += 1
                string += f'[COLOR red]ERROR NUMBER {i}:[/COLOR]{item.replace(homepath, "/").replace("                                        ", "")}\n'
            if i > 0:
                # text_view(f'{addontitle}: Errors in Log', string)
                textbox('--[ JP Tools Log Viewer ]--', string)
        if len(error1) == 0 or i == 0:
            infodialog(f'[COLOR {color1}]There is : {len(error1)} Error[/COLOR][CR][COLOR red]In Kodi Log![/COLOR]', time=2000)


def clane_adondata():
    if dialog.yesno(addontitle, f'[COLOR {color2}]Would you like to remove [COLOR {color1}]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]', yeslabel=f'[COLOR {color3}]Remove Data[/COLOR]', nolabel='[COLOR red]Don\'t Remove[/COLOR]'):
        import shutil
        total = 0
        for folder in glob.glob(joinpath(addond, '*')):
            foldername = folder.replace(addond, '').replace('\\', '').replace('/', '')
            if not existspath(joinpath(addons_path, foldername)):
                remove_empty_folders(folder)
                total += 1
                log(folder)
                shutil.rmtree(folder)
        infodialog(f'[COLOR {color1}]Clean up Uninstalled[/COLOR][CR][COLOR {color2}]{total} Folders(s) Removed[/COLOR]')
    else: infodialog(f'[COLOR {color1}]Remove Addon Data[/COLOR][CR][COLOR {color2}]Cancelled![/COLOR]')


def disable_enable_addon(addon_name='plugin.video.infinite'):
    try:
        jsonrpc({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled', 'params': {'addonid': addon_name, 'enabled': False}})
        jsonrpc({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled', 'params': {'addonid': addon_name, 'enabled': True}})
    except: pass


def send_kodi_log_smb():
    smb_path = getsetting('smb_path')
    if not smb_path: infodialog('Can not find smb.'); return
    dl_zip_smb(joinpath(logpath, 'kodi.log'), joinpath(smb_path, 'kodi.log'))
    infodialog('send kodi.log file to smb.')


def get_send_files_smb(send=False):
    smb_path = getsetting('smb_path')
    if not smb_path: infodialog('Can not find smb.'); return
    if send:
        msg = 'send'
        srs_dir = f'{userdata}/addon_data'
        dst_dir = f'{smb_path}/upd_local_addon_data'
    else:
        msg = 'get'
        srs_dir = f'{smb_path}/upd_local_addon_data'
        dst_dir = f'{userdata}/addon_data'
    dl_zip_smb(joinpath(srs_dir, 'script.jptools', 'settings.xml'), joinpath(dst_dir, 'script.jptools', 'settings.xml'))
    dl_zip_smb(joinpath(srs_dir, 'script.module.openscrapers', 'settings.xml'), joinpath(dst_dir, 'script.module.openscrapers', 'settings.xml'))
    dl_zip_smb(joinpath(srs_dir, 'plugin.video.infinity', 'settings.xml'), joinpath(dst_dir, 'plugin.video.infinity', 'settings.xml'))
    if getsetting('getdb_file') == 'true':
        if send: dl_zip_smb(joinpath(srs_dir, 'plugin.video.infinite', 'metacache.db'), joinpath(dst_dir, 'plugin.video.infinite', 'metacache.db'))
        dl_zip_smb(joinpath(srs_dir, 'script.module.openscrapers', 'cache.db'), joinpath(dst_dir, 'script.module.openscrapers', 'cache.db'))
        dl_zip_smb(joinpath(srs_dir, 'plugin.video.infinite', 'navigator.db'), joinpath(dst_dir, 'plugin.video.infinite', 'navigator.db'))
        dl_zip_smb(joinpath(srs_dir, 'plugin.video.infinite', 'settings.db'), joinpath(dst_dir, 'plugin.video.infinite', 'settings.db'))
    infodialog(f'{msg} file from smb.')


def get_kodi_frm_smb():
    from modules.maintenance import purgepackages
    purgepackages()
    smb_path = getsetting('smb_path')
    if not smb_path: infodialog('Can not find smb.'); return
    smb_dir = f'{smb_path}/Apps/'
    smb_files = xbmcvfs.listdir(smb_dir)
    # log(f'smb_files: {smb_files}')
    kodiapp_list = []
    for j in smb_files[1]:
        if 'kodi' in j and j.endswith('.apk'):
            smb_file_path = joinpath(smb_dir, j)
            # log(f'j: {j} smb_file_path: {smb_file_path}')
            kodiapp_list.append({'name': j, 'version': '', 'url': smb_file_path, 'icon': 'https://i.imgur.com/DH7rRx6.png', 'fanart': '', 'mode': 'dl_apk_file', 'description': j})
    return kodiapp_list


def get_id(settings_file):
    xmlData = read_file(settings_file)
    soup = get_soup(xmlData)
    id_list = []
    for tag in soup.find_all('setting'):
        repElemID = tag.get('id')
        id_list.append(repElemID)
    return id_list


def reset_provider(a_adon, settings_xml_data, settings_xml_default):
    # get default id values
    try:
        default_id = get_id(settings_xml_default)
        xmlData = read_file(settings_xml_data)
        soup = get_soup(xmlData)
        # log(f'soup: \n{soup}')
        item_clean = False
        removedid = []
        for tag in soup.find_all('setting'):
            repElemID = tag.get('id')
            if repElemID not in default_id:
                removedid.append(repElemID)
                tag.decompose()
                item_clean = True
        #log(soup)
        if item_clean:
            log(f'CleanSettings for: {a_adon} removed : {removedid}')
            with open(settings_xml_data, 'w') as xmlFile:
                xmlFile.seek(0)
                #xmlFile.write('<settings version=\'2\'>')
                xmlFile.write(str(soup).replace('\n\n', ''))  #xmlFile.write(str(soup.prettify(formatter='minimal')))
            sleep(500)
    except: pass


def reset_upd_setting():
    plgn_list = []
    platform_type = getsetting('platform')
    build = platform()
    log(f'platform_type: {platform_type} build: {build}')
    if platform_type != build: setsetting('platform', build)
    for adn_dir in glob.glob(joinpath(addond, '*.*')):
        ad_n = basename(adn_dir)
        if 'script.module.resolveurl' in ad_n: continue
        if condvisibility(f'System.HasAddon({ad_n})'): plgn_list.append(ad_n)

    # dp.create(addontitle, '')
    for a_adon in plgn_list:
        settings_xml_data = joinpath(userdatapath, 'addon_data', a_adon, 'settings.xml')
        settings_xml_default = joinpath(addons_path, a_adon, 'resources', 'settings.xml')
        if existspath(settings_xml_default) and existspath(settings_xml_data):
            # dp.update(0, f'cleaning setting file: {a_adon}')
            # log(f'setting file cleaned for: {a_adon}\nsettings_xml_default: {settings_xml_default}\nsettings_xml_data: {settings_xml_data}')
            # reset_provider(a_adon, settings_xml_data, settings_xml_default)
            clean_settings(settings_xml_default, settings_xml_data, a_adon)


def clean_settings(settings_xml_default, settings_xml_data, a_adon):
    def _make_content(dict_object):
        content = '<settings version="2">'
        new_line = '\n    '
        for item in dict_object:
            _id = item['id']
            if _id in active_settings:
                if 'default' in item and 'value' in item: content += f'{new_line}<setting id="{_id}" default="{item["default"]}">{item["value"]}</setting>'
                elif 'default' in item: content += f'{new_line}<setting id="{_id}" default="{item["default"]}"></setting>'
                elif 'value' in item: content += f'{new_line}<setting id="{_id}">{item["value"]}</setting>'
                else: content += f'{new_line}<setting id="{_id}"></setting>'
                content = content.replace('></setting>', ' />')
            else: removed_settings_append(item)
        content += '\n</settings>'
        return content

    try:
        active_settings, current_user_settings, removed_settings = [], [], []
        active_append, current_append, removed_settings_append = active_settings.append, current_user_settings.append, removed_settings.append
        for i in mdparse(settings_xml_default).getElementsByTagName('setting'):
            setting_id = i.getAttribute('id')
            if setting_id: active_append(setting_id)
        for i in mdparse(settings_xml_data).getElementsByTagName('setting'):
            dict_item = {}
            setting_id = i.getAttribute('id')
            setting_default = i.getAttribute('default')
            try: setting_value = i.firstChild.data
            except: setting_value = None
            dict_item['id'] = setting_id
            if setting_value: dict_item['value'] = setting_value
            if setting_default: dict_item['default'] = setting_default
            current_append(dict_item)
        new_content = _make_content(current_user_settings)
        if removed_settings:
            with open(settings_xml_data, 'w') as f: f.write(new_content)
            sleep(200)
            log(f'setting file cleaned for: {a_adon} Removed Settings: {len(removed_settings)}')
            infodialog(f'{len(removed_settings)}  from: {a_adon} Obsolete Settings Entries Removed')
    except Exception as e:
        log(f'clean_settings a_adon: {a_adon} error: {e}')


def check_version_numbers(current, new):  # Compares version numbers and return True if github version is newer
    current = normalize_version(current)
    new = normalize_version(new)
    step = 0
    # log(f'current: {current} new: {new}')
    if new > current: return True
    return False

# def compare_strings(a,b):
# result = True
# if len(a) != len(b): print('string lengths do not match!')
# for i,(x,y) in enumerate(zip(a,b)):
# if x != y:
# print(f'char miss-match {x,y} in element {i}')
# result = False
# if result: print('strings match!')
# return result