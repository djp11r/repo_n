"""
addon_smb_pipeline.py

Unified sync + async SMB addon pipeline with:

- Deterministic version parsing
- Structured logging
- Sync + async API (aiofiles-style)
- asyncio.TaskGroup for concurrency
- Parallel SMB copies and age checks
- Simple benchmark harness
"""

from __future__ import annotations

import asyncio
import logging
import re
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from traceback import print_exc
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import xbmcvfs
from modules.wiz import extractzip
from modules.control import infolabel, addons_path, infodialog, kodi_open, execute, transpath, existspath, getsetting, joinpath, jsonrpc, listdir, log, packages
from modules.maintenance import purgepackages


# Types

VersionTuple = Tuple[int, int, int, int, int]


@dataclass(frozen=True)
class AddonFile:
    """Represents an addon ZIP file on SMB or local disk."""
    name: str          # addon id (base name)
    filename: str      # full filename, e.g. "plugin.video.foo-1.2.3.zip"
    path: str          # full path to file


# Version parsing (deterministic)

PRERELEASE_ORDER: Dict[Optional[str], int] = {
    None: 3,
    "alpha": 0, "a": 0,
    "beta": 1, "b": 1,
    "rc": 2, "pre": 2,
    "matrix": 3,
}

_PRE_RE = re.compile(r"(alpha|beta|rc|a|b|pre|matrix)[\.\-]?(\d*)", re.IGNORECASE)
_NUM_RE = re.compile(r"\d+")
_CLEAN_RE = re.compile(r"[+~ ]")


def normalize_version(vers_str: str) -> VersionTuple:
    """
    Convert a messy version string into a sortable semantic tuple:
    (major, minor, patch, prerelease_rank, prerelease_num)

    Deterministic:
    - Always returns a 5-tuple of ints.
    - Missing parts become 0.
    - Unknown prerelease tags fall back to final (PRERELEASE_ORDER[None]).
    """
    try:
        s = vers_str.split("-", 1)[1].lower()
    except IndexError:
        return 0, 0, 0, PRERELEASE_ORDER[None], 0

    s = _CLEAN_RE.sub("", s)
    if s.endswith(".zip"):
        s = s[:-4]

    pre = _PRE_RE.search(s)
    if pre:
        tag = pre.group(1).lower()
        num = int(pre.group(2) or 0)
        rank = PRERELEASE_ORDER.get(tag, PRERELEASE_ORDER[None])
        s = s.replace(pre.group(0), "")
    else:
        rank = PRERELEASE_ORDER[None]
        num = 0

    nums = _NUM_RE.findall(s)
    major = int(nums[0]) if len(nums) > 0 else 0
    minor = int(nums[1]) if len(nums) > 1 else 0
    patch = int(nums[2]) if len(nums) > 2 else 0

    return major, minor, patch, rank, num


# Sync core: file age, SMB copy, intersect, high-level pipeline

def get_file_older_then_hrs(path: str, hours: int = 168) -> bool:
    """
    Return True if file is newer than cutoff (same semantics as original),
    implemented with fast timestamp math.
    """
    try:
        f = xbmcvfs.Stat(path)
        file_time = f.st_mtime()
    except Exception as exc:
        log(f'Stat failed: path: {path}, error: {str(exc)}')
        return False

    cutoff = time.time() - (hours * 3600)
    return file_time > cutoff

def dl_zip_smb(src: str, dest: Optional[str] = None, chunk: int = 256 * 1024) -> None:
    """
    Synchronous SMB copy using chunked reads.
    """
    if dest is None:
        filename = src.rsplit("/", 1)[-1]
        dest = transpath(joinpath(packages, filename))

    if not existspath(src):
        log(f'Source missing: src: {src}')
        return

    if not dest.endswith((".zip", ".log")):
        log(f'Destination extension invalid: dest: {dest}')
        return

    try:
        with kodi_open(src, 'r') as s, kodi_open(dest, "w") as d:
            while True:
                buf = s.readBytes(chunk)
                if not buf:
                    break
                d.write(buf)
        log(f'SMB copy complete: src: {src}, dest: {dest}')
    except Exception as exc:
        log(f'SMB copy failed: src: {src}, dest: {dest}, error: {str(exc)}')

def intersect(installed: Sequence[str], available: Sequence[str], age: int, smb_dir: str,) -> Tuple[List[str], List[str]]:
    """
    Compare installed vs available versions.

    Returns:
        newfiles:  list of available files that are upgrades
        samefiles: list of files that match installed and are newer than 'age'
    """
    inst_map: Dict[str, List[str]] = {}
    for inst in installed:
        base = inst.split("-", 1)[0]
        inst_map.setdefault(base, []).append(inst)

    newfiles: List[str] = []
    samefiles: List[str] = []

    for avail in available:
        base = avail.split("-", 1)[0]
        if base not in inst_map:
            continue

        for inst in inst_map[base]:
            if avail == inst:
                smb_file = joinpath(smb_dir, avail)
                if get_file_older_then_hrs(smb_file, age):
                    samefiles.append(avail)
                continue

            if inst.count("-") > 1:
                continue

            if normalize_version(avail) > normalize_version(inst):
                newfiles.append(avail)

    return newfiles, samefiles

def unzip_instal_addon(install_list):
    for addon in install_list:
        # log(f'install Addon: {addon["name"]}')
        try: extractzip(addon['dir_'], addons_path)
        except: log(f'[unZip File] Unable to extract: {addon}')
    log(f'Total Nos of Addon Updated: {len(install_list)}')

# def get_adon_frm_smb(age: Optional[int] = None) -> None:
    # """
    # Synchronous high-level pipeline:
    # - Query installed addons via JSON-RPC
    # - List SMB directory
    # - Detect upgrades / same-version-but-old files
    # - Copy ZIPs locally
    # - Trigger install
    # """
    # query = {
        # "jsonrpc": "2.0",
        # "id": "1",
        # "method": "Addons.GetAddons",
        # "params": {"properties": ["version"]},
    # }
    # resp = jsonrpc(query)
    # addons = resp[0]["result"]["addons"]

    # installed = [f'{a["addonid"]}-{a["version"]}.zip' for a in addons]

    # smb_path = getsetting("smb_path")
    # if not smb_path:
        # infodialog("Cannot find SMB path")
        # return

    # smb_dir = transpath(f"{smb_path}/addons/alladdons_/")
    # _, files = listdir(smb_dir)

    # age = age if age is not None else int(getsetting("file_age"))

    # newfiles, samefiles = intersect(installed, files, age, smb_dir)
    # targets = newfiles + samefiles if newfiles else samefiles

    # if targets:
        # purgepackages()

    # install_list: List[Dict[str, str]] = []
    # for f in targets:
        # src = joinpath(smb_dir, f)
        # dst = joinpath(packages, f)
        # dl_zip_smb(src, dst)
        # install_list.append({"name": f.split("-")[0], "dir_": dst})

    # if install_list:
        # unzip_instal_addon(install_list)


# Async layer: unified sync+async API (aiofiles-style)

_SMB_EXECUTOR = ThreadPoolExecutor(max_workers=4)


async def async_intersect(installed: Sequence[str], available: Sequence[str], age: int, smb_dir: str) -> Tuple[List[str], List[str]]:
    """
    Async wrapper around intersect.
    """
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(
        _SMB_EXECUTOR,
        lambda: intersect(installed, available, age, smb_dir),
    )


async def async_unzip_instal_addon(available: Sequence[str]) -> None:
    """
    Async wrapper around unzip_instal_addon.
    """
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(
        _SMB_EXECUTOR,
        lambda: unzip_instal_addon(available),
    )

# async def async_get_file_older_then_hrs(path: str, hours: int = 168) -> bool:
    # """
    # Async wrapper around get_file_older_then_hrs.
    # """
    # loop = asyncio.get_running_loop()
    # return await loop.run_in_executor(
        # _SMB_EXECUTOR,
        # lambda: get_file_older_then_hrs(path, hours),
    # )


async def async_dl_zip_smb(src: str, dest: Optional[str] = None, chunk: int = 256 * 1024) -> None:
    """
    Async wrapper around dl_zip_smb.
    """
    loop = asyncio.get_running_loop()
    await loop.run_in_executor(
        _SMB_EXECUTOR,
        lambda: dl_zip_smb(src, dest, chunk),
    )


async def async_list_smb_dir(path: str) -> Tuple[List[str], List[str]]:
    """
    Async wrapper around kodi_listdir.
    """
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(
        _SMB_EXECUTOR,
        lambda: listdir(path),
    )


# async def async_get_adon_frm_smb(age: Optional[int] = None) -> None:
    # """
    # Async high-level pipeline (sequential SMB operations, but non-blocking to event loop).
    # """
    # query = {
        # "jsonrpc": "2.0",
        # "id": "1",
        # "method": "Addons.GetAddons",
        # "params": {"properties": ["version"]},
    # }
    # resp = jsonrpc(query)
    # addons = resp[0]["result"]["addons"]

    # installed = [f'{a["addonid"]}-{a["version"]}.zip' for a in addons]

    # smb_path = getsetting("smb_path")
    # if not smb_path:
        # infodialog("Cannot find SMB path")
        # return

    # smb_dir = transpath(f"{smb_path}/addons/alladdons_/")
    # _, files = await async_list_smb_dir(smb_dir)

    # age = age if age is not None else int(getsetting("file_age"))

    # newfiles, samefiles = intersect(installed, files, age, smb_dir)
    # targets = newfiles + samefiles if newfiles else samefiles

    # if targets:
        # purgepackages()

    # install_list: List[Dict[str, str]] = []
    # for f in targets:
        # src = joinpath(smb_dir, f)
        # dst = joinpath(packages, f)
        # await async_dl_zip_smb(src, dst)
        # install_list.append({"name": f.split("-")[0], "dir_": dst})

    # if install_list:
        # unzip_instal_addon(install_list)


# Async concurrency-optimized pipeline (TaskGroup)

async def async_get_adon_frm_smb_concurrent(age: Optional[int] = None) -> None:
    """
    Async + concurrent pipeline:
    - List SMB dir
    - Compute intersect
    - Copy all target ZIPs in parallel using asyncio.TaskGroup
    """
    query = {
        "jsonrpc": "2.0",
        "id": "1",
        "method": "Addons.GetAddons",
        "params": {"properties": ["version"]},
    }
    resp = jsonrpc(query)
    addons = resp[0]["result"]["addons"]

    installed = [f'{a["addonid"]}-{a["version"]}.zip' for a in addons]

    smb_path = getsetting("smb_path")
    if not smb_path:
        infodialog("Cannot find SMB path")
        return

    smb_dir = transpath(f"{smb_path}/addons/alladdons_/")
    _, files = await async_list_smb_dir(smb_dir)

    age = age if age is not None else int(getsetting("file_age"))

    newfiles, samefiles = await async_intersect(installed, files, age, smb_dir)
    targets = newfiles + samefiles if newfiles else samefiles

    if targets:
        purgepackages()

    install_list: List[Dict[str, str]] = []

    async with asyncio.TaskGroup() as tg:
        for f in targets:
            src = joinpath(smb_dir, f)
            dst = joinpath(packages, f)

            async def _copy_and_record(src=src, dst=dst, f=f):
                await async_dl_zip_smb(src, dst)
                install_list.append({"name": f.split("-")[0], "dir_": dst})

            tg.create_task(_copy_and_record())

    if install_list:
        await async_unzip_instal_addon(install_list)
        try:
            current_profile = infolabel('system.profilename')
            execute(f'LoadProfile({current_profile})')
        except:
            log(f'Error unzip_instal_addon: {print_exc()}')
            infodialog('Error While Addons Update')
    return


# ---------------------------------------------------------------------------
# Benchmark harness
# ---------------------------------------------------------------------------

def _bench_sync(iterations: int = 1) -> float:
    start = time.perf_counter()
    # for _ in range(iterations):
        # get_adon_frm_smb()
    return time.perf_counter() - start


async def _bench_async(iterations: int = 1, concurrent: bool = False) -> float:
    start = time.perf_counter()
    for _ in range(iterations):
        await async_get_adon_frm_smb_concurrent()
        # if concurrent: await async_get_adon_frm_smb_concurrent()
        # else: await async_get_adon_frm_smb()
    return time.perf_counter() - start


def get_smb():

    iters = 1

    # sync_time = _bench_sync(iters)
    # log(f"sync x{iters}: {sync_time:.3f}s")

    # async_time = asyncio.run(_bench_async(iters, concurrent=False))
    # log(f"async (sequential SMB) x{iters}: {async_time:.3f}s")

    async_conc_time = asyncio.run(_bench_async(iters, concurrent=True))
    log(f"async (concurrent SMB) x{iters}: {async_conc_time:.3f}s")
