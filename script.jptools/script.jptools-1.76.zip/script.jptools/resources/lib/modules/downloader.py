import os
import time
import socket
import threading
import urllib.request
import urllib.error
from modules.control import log

class _NullDP:
    def update(self, *args, **kwargs):
        pass

    def create(self, *args, **kwargs):
        pass

    def close(self):
        pass

    def iscanceled(self):
        return False


class Downloader:
    """
    Streaming download
    Resume support (when server supports Range)
    Automatic fallback to single‑thread mode if Range unsupported
    Multi‑threaded chunked download
    Per‑thread retries with exponential backoff
    Adaptive chunk sizing
    Smoothed progress bar
    Integration with your log() and dp objects
    """

    def __init__(self, headers=None, timeout=10, retries=3, backoff=2, threads=4, logger=None, quiet=False,):
        self.headers = headers or {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"}
        self.timeout = timeout
        self.retries = retries
        self.backoff = backoff
        self.threads = max(1, threads)
        self.quiet = quiet

        # Logging
        self.log = (lambda msg: None) if quiet else (logger or (lambda msg: None))

        # Progress smoothing
        self.displayed_downloaded = 0
        self.smoothing_factor = 0.15  # lower = smoother, higher = snappier

    # ----------------- Core helpers -----------------

    def _build_request(self, url, range_header=None):
        req = urllib.request.Request(url)
        for k, v in self.headers.items():
            req.add_header(k, v)
        if range_header: req.add_header("Range", range_header)
        return req

    def _smooth_progress(self, actual, total, dp, start_time):
        if self.quiet: return
        # Move displayed value toward actual value
        self.displayed_downloaded += (actual - self.displayed_downloaded) * self.smoothing_factor
        downloaded = self.displayed_downloaded

        if total <= 0:
            percent = 0
            total_mb = 0
        else:
            percent = min(downloaded * 100 / total, 100)
            total_mb = total / (1024 * 1024)

        downloaded_mb = downloaded / (1024 * 1024)

        elapsed = time.time() - start_time
        speed = downloaded / elapsed if elapsed > 0 else 0
        speed_kb = speed / 1024

        if speed > 0 and percent < 100 and total > 0: eta = (total - downloaded) / speed
        else: eta = 0

        eta_m = int(eta // 60)
        eta_s = int(eta % 60)

        dp.update(
            int(percent),
            f"{downloaded_mb:.02f} MB of {total_mb:.02f} MB"
            f"[CR]Speed: {speed_kb:.02f} KB/s  ETA: {eta_m:02d}:{eta_s:02d}"
            f"[CR]Downloading... Please Wait..."
        )

        if dp.iscanceled():
            dp.close()
            raise Exception("Canceled")

    def _server_supports_range(self, url):
        """Check if the server supports HTTP Range requests."""
        try:
            req = self._build_request(url, "bytes=0-0")
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                status = response.getcode()
                accept_ranges = response.headers.get("Accept-Ranges", "").lower()

                if accept_ranges == "none":
                    self.log("Server reports no Accept-Ranges support")
                    return False
                if status == 206:
                    self.log("Server supports Range requests (206 Partial Content)")
                    return True
                if status == 200:
                    self.log("Server ignored Range header (no range support)")
                    return False
        except Exception as e:
            self.log(f"Range test failed: {e}")
            return False
        return False

    # ----------------- Single-thread fallback -----------------

    def _single_thread_download(self, url, dest, dp):
        self.log("Starting single-thread streaming download")
        dp.update(0)
        self.displayed_downloaded = 0
        start_time = time.time()

        req = self._build_request(url)
        with urllib.request.urlopen(req, timeout=self.timeout) as response:
            total_size = int(response.headers.get("Content-Length", 0))
            downloaded = 0

            with open(dest, "wb") as f:
                while True:
                    chunk = response.read(64 * 1024)
                    if not chunk: break
                    f.write(chunk)
                    downloaded += len(chunk)
                    self._smooth_progress(downloaded, total_size, dp, start_time)

        dp.update(100)
        dp.close()
        self.log("Single-thread download complete")
        return True

    # ----------------- Threaded chunk download -----------------

    def _download_chunk(self, url, dest, start, end, thread_id):
        """Download a specific byte range to a temp file with retries and adaptive chunk size."""
        temp_file = f"{dest}.part{thread_id}"
        attempt = 0

        chunk_size = 64 * 1024          # 64 KB starting point
        min_chunk = 16 * 1024           # 16 KB
        max_chunk = 1024 * 1024         # 1 MB

        while attempt <= self.retries:
            try:
                range_header = f"bytes={start}-{end}"
                req = self._build_request(url, range_header)
                self.log(f"Thread {thread_id} downloading {range_header} (attempt {attempt+1})")

                with urllib.request.urlopen(req, timeout=self.timeout) as response:
                    with open(temp_file, "wb") as f:
                        pos = start
                        while pos <= end:
                            t0 = time.time()
                            chunk = response.read(chunk_size)
                            dt = time.time() - t0
                            if not chunk: break
                            f.write(chunk)
                            pos += len(chunk)
                            # Adaptive chunk sizing
                            if dt < 0.05: chunk_size = min(chunk_size * 2, max_chunk)
                            elif dt > 0.25: chunk_size = max(chunk_size // 2, min_chunk)
                self.log(f"Thread {thread_id} finished successfully")
                return True

            except Exception as e:
                attempt += 1
                self.log(f"Thread {thread_id} error: {e} (retry {attempt}/{self.retries})")
                if attempt > self.retries:
                    self.log(f"Thread {thread_id} failed permanently")
                    raise
                time.sleep(self.backoff ** attempt)
        return False

    def _merge_chunks(self, dest):
        """Merge .part files into final output."""
        self.log("Merging chunk files")
        with open(dest, "wb") as outfile:
            part = 0
            while True:
                part_file = f"{dest}.part{part}"
                if not os.path.exists(part_file): break
                with open(part_file, "rb") as pf:
                    outfile.write(pf.read())
                os.remove(part_file)
                part += 1
        self.log("Merge complete")

    # ----------------- Public API -----------------

    def download(self, url, dest, dp=None):
        if self.quiet or dp is None: dp = _NullDP()
        else: dp.create("Downloader", "")

        dp.update(0)
        self.displayed_downloaded = 0

        # HEAD-like request to get file size
        req = self._build_request(url)
        with urllib.request.urlopen(req, timeout=self.timeout) as response:
            total_size = int(response.headers.get("Content-Length", 0))

        # Check range support
        range_supported = self._server_supports_range(url)
        if not range_supported or self.threads == 1 or total_size <= 0:
            self.log("Falling back to single-thread mode")
            return self._single_thread_download(url, dest, dp)

        # Multi-thread download with range
        self.log(f"Starting multi-threaded download with {self.threads} threads")
        start_time = time.time()

        chunk_size = total_size // self.threads
        threads = []

        for i in range(self.threads):
            start = i * chunk_size
            end = (i + 1) * chunk_size - 1 if i < self.threads - 1 else total_size - 1

            t = threading.Thread(target=self._download_chunk, args=(url, dest, start, end, i), daemon=True,)
            threads.append(t)
            t.start()

        # Progress loop
        while any(t.is_alive() for t in threads):
            downloaded = 0
            for i in range(self.threads):
                part_file = f"{dest}.part{i}"
                if os.path.exists(part_file):
                    downloaded += os.path.getsize(part_file)
            self._smooth_progress(downloaded, total_size, dp, start_time)
            time.sleep(0.2)

        for t in threads:
            t.join()

        # Merge parts
        self._merge_chunks(dest)

        dp.update(100)
        dp.close()
        self.log("Download complete")
        return True

# dp: your dialog/progress object
# log: your existing logging function
# url, dest: as before

downloader = Downloader(headers={"User-Agent": "MyAddon/1.0"}, timeout=10, retries=3, backoff=2, threads=4, logger=log, quiet=False)

#downloader.download(url, dest, dp)
