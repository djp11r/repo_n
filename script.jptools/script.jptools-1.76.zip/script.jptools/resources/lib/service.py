# -*- coding: utf-8 -*-
# GNU General Public License v2.0 (see COPYING or https://www.gnu.org/licenses/gpl-2.0.txt)
import os
from datetime import date, timedelta
from threading import Thread

from xbmc import log, Monitor, Player
from xbmcgui import Window
from xbmcvfs import translatePath, mkdirs


firstrun_update_prop = 'jp.firstrun_update'
pause_services_prop = 'jp.pause_services'


def logger(function):
    log(f'###jptools###: {function}', 1)


class EssentialRun:
    def run(self):
        logger('EssentialRun Service Starting')
        from modules.toolz import autoupdatetoggle_system
        autoupdatetoggle_system()
        backupdir = translatePath(os.path.join('special://home/backupdir', ''))
        if not os.path.exists(backupdir): mkdirs(backupdir)
        return logger('EssentialRun Service Finished')


class Maintenance:
    def run(self):
        window = Window(10000)
        if window.getProperty(firstrun_update_prop) == 'true': return
        from modules.control import getsetting, get_active_source

        logger('Maintenance Service Starting')
        from time import time
        end_pause = int(time()) + int(getsetting('update_delay')) or 15
        monitor, player = Monitor(), Player()
        wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
        while not monitor.abortRequested():
            while time() < end_pause: wait_for_abort(1)
            while is_playing(): wait_for_abort(1)
            get_active_source()
            autoclean = getsetting('autoclean')
            autonext = getsetting('autonextacleannsave')
            atoday = date.today()
            current_date = atoday.strftime('%Y-%m-%d')
            logger(f'\nautonext <= current_date : {autonext.replace("-", "") <= current_date.replace("-", "")}\nautoclean : {repr(autoclean)} current_date : {repr(current_date)} autonext : {repr(autonext)}')

            from modules.maintenance import clean_oldlog
            clean_oldlog()

            if autoclean == 'true' and autonext.replace('-', '') <= current_date.replace('-', ''):
                from modules.maintenance import clearcache, clean_myvideos_db, thumb_cleaner, purgepackages
                from modules.control import addonid, addonversion, thumbs, packages, setsetting
                logger(f'Startup [{addonid}] [v.{addonversion}]')
                filesize = int(getsetting('filesize_alert'))
                filesize_thumb = int(getsetting('filesizethumb_alert'))
                autocleanfeq = getsetting('autocleanfeq')
                autocleanfeq = int(autocleanfeq) if autocleanfeq.isdigit() else 0
                autosetting = getsetting('autosetting')
                autocache = getsetting('clearcache')
                autopackages = getsetting('clearpackages')
                autothumbs = getsetting('clearthumbs')
                next_run = atoday + timedelta(autocleanfeq)

                if autocache == 'true':
                    from modules.control import resetresolverscache
                    clearcache('noverbose')
                    resetresolverscache()
                    clean_myvideos_db()
                    logger('[Auto Clean Up] Cache: is Done')
                else: logger('[Auto Clean Up] Cache: Off')
                from modules.toolz import folder_size
                if autothumbs == 'true':
                    thumbnails_size, unit2 = folder_size(thumbs)
                    if int(thumbnails_size) > filesize_thumb and unit2 == 'MB':
                        thumb_cleaner()
                        logger('[Auto Clean Up] Old Thumbs: is Done')
                else: logger('[Auto Clean Up] Old Thumbs: Off')
                if autopackages == 'true':
                    packagesdir_size, unit1 = folder_size(packages)
                    if int(packagesdir_size) > filesize and unit1 == 'MB':
                        purgepackages('noverbose')
                        logger('[Auto Clean Up] Packages: is Done')
                if autosetting:
                    from modules.traktit import reset_upd_setting
                    from modules.upd_yt_api import set_api
                    reset_upd_setting()
                    logger('[Auto Clean Up] Setting files: is Done')
                    try:
                        set_api('noverbose')
                        logger('[Auto Clean Up] Youtube API upd: is Done')
                    except: pass
                else: logger('[Auto Clean Up] setting: Off')
                logger(f'[Auto Clean Up] Next Clean Up will be on : {next_run}  Today is : {current_date}')
                try:
                    setsetting('autonextacleannsave', f'{next_run}')
                    setsetting('autolastacleannsave', f'{current_date}')
                except: pass
            break
        window.setProperty(firstrun_update_prop, 'true')
        try: del monitor
        except: pass
        try: del player
        except: pass
        return logger('Maintenance Service Finished')

class UpdateCheck:
    def run(self):
        from modules.control import getsetting, setsetting, get_timestamp, comper_time_with_current
        get_adon_file_due = getsetting('get_adon_file_due')
        logger(f'Auto DL get_adon_file_due: {get_adon_file_due} :: {comper_time_with_current(get_adon_file_due)}')
        if getsetting('get_adon_file') == 'true' and comper_time_with_current(get_adon_file_due):
            from modules.get_smb_service import run_update_service
            run_update_service()
            setsetting('get_adon_file_due', f'{get_timestamp(12, humanread=True)}')
            logger('Auto DL addon from enet done')
        else: logger('Auto DL addon from enet not doing')
        return logger('Auto DL Addons UpdateCheck Service Finished')
        

class main(Monitor):
    def __init__(self):
        Monitor.__init__(self)
        super().__init__()
        self.startServices()

    def startServices(self):
        # Start the EssentialRun
        EssentialRun().run()
        Thread(target=Maintenance().run).start()
        UpdateCheck().run()

    def onNotification(self, sender, method, data):
        if method in ('GUI.OnScreensaverActivated', 'System.OnSleep'):
            Window(10000).setProperty(pause_services_prop, 'true')
        elif method in ('GUI.OnScreensaverDeactivated', 'System.OnWake'):
            Window(10000).clearProperty(pause_services_prop)

main().waitForAbort()
logger('Main Monitor Service Finished')