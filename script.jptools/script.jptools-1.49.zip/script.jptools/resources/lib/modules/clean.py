# -*- coding: UTF-8 -*-

import glob
import re
import shutil


def removeFile(path):
    from modules.control import deleteFile, log
    log("Deleting File: %s" % path)
    try:
        deleteFile(path)
    except:
        return False


def removeFolder(path):
    from modules.control import log
    log("Deleting Folder: %s" % path)
    try:
        shutil.rmtree(path, ignore_errors=True, onerror=None)
    except:
        return False


def latestDB(DB):
    from modules.control import databasepath, joinPath
    if DB in ['Addons', 'ADSP', 'Epg', 'MyMusic', 'MyVideos', 'Textures', 'TV', 'ViewModes']:
        match = glob.glob(joinPath(databasepath, '%s*.db' % DB))
        comp = '%s(.+?).db' % DB[1:]
        highest = 0
        for file in match:
            try:
                check = int(re.compile(comp).findall(file)[0])
            except:
                check = 0
            if highest < check:
                highest = check
        return '%s%s.db' % (DB, highest)
    else:
        return False


def purgeDb(name):
    from modules.control import existsPath, log, infoDialog
    log('Purging DB %s.' % name)
    if existsPath(name):
        try:
            from sqlite3 import dbapi2 as database
            textdb = database.connect(name)
            textexe = textdb.cursor()
        except Exception as e:
            log(str(e))
            return False
    else:
        log('%s not found.' % name)
        return False
    textexe.execute("""SELECT name FROM sqlite_master WHERE type = 'table';""")
    for table in textexe.fetchall():
        if table[0] == 'version':
            log('Data from table `%s` skipped.' % table[0])
        else:
            try:
                textexe.execute("""DELETE FROM %s""" % table[0])
                textdb.commit()
                log('Data from table `%s` cleared.' % table[0])
            except Exception as e:
                log(str(e))
    log('%s DB Purging Complete.' % name)
    show = name.replace('\\', '/').split('/')
    infoDialog("Purge Database: %s Complete" % show[len(show) - 1])


def OClear_Thumb():
    from modules.control import log, AddonTitle, joinPath, yesnoDialog, databasepath, THUMBSPATH
    latest = latestDB('Textures')
    if yesnoDialog(AddonTitle, "Would you like to delete the %s and Thumbnails folder?" % latest, "They will repopulate on startup", nolabel='No, Cancel', yeslabel='Yes, Remove'):
        try:
            removeFile(joinPath(databasepath, latest))
        except:
            log('Failed to delete, Purging DB.')
            purgeDb(latest)
        removeFolder(THUMBSPATH)
        if yesnoDialog(AddonTitle, "Would you like to restart Kodi now?", "", nolabel='No', yeslabel='Yes'):
            from modules import forceClose
            forceClose.ForceClose()
        else:
            log('Clear Thumbnails Cancelled')
    else:
        log('Clear Thumbnails Cancelled')


def ODelete_Packages(url):
    from os import walk, unlink
    from modules.control import AddonTitle, joinPath, yesnoDialog, OkDialog, transPath
    print('############################################################       DELETING PACKAGES             ###############################################################')
    packages_cache_path = transPath(joinPath('special://home/addons/packages', ''))
    try:
        for root, dirs, files in walk(packages_cache_path):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                if yesnoDialog("Delete Package Cache Files", str(file_count) + " files found", "Do you want to delete them?", yeslabel='YES', nolabel='NO'):
                    for f in files:
                        unlink(joinPath(root, f))
                    for d in dirs:
                        shutil.rmtree(joinPath(root, d))
                    OkDialog(AddonTitle, "Complete")
    except:
        OkDialog(AddonTitle, "Sorry we were not able to remove Package Files")


def ODelete_Cache(url):
    from os import walk, unlink
    from modules.control import AddonTitle, joinPath, yesnoDialog, transPath, condVisibility, existsPath, infoDialog
    print('############################################################       DELETING STANDARD CACHE             ###############################################################')
    xbmc_cache_path = joinPath(transPath('special://home'), 'cache')
    if existsPath(xbmc_cache_path):
        for root, dirs, files in walk(xbmc_cache_path):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                if yesnoDialog(AddonTitle, str(file_count) + " Cache files found", "Do you want to delete them?", yeslabel='YES', nolabel='NO'):
                    for f in files:
                        try:
                            if f == "kodi.log" or f == "kodi.old.log" or f == "xbmc.log" or f == "xbmc.old.log" or f == "spmc.log" or f == "spmc.old.log" or f == "ezclean.log" or f == "scrubsv2.log":
                                continue
                            unlink(joinPath(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(joinPath(root, d))
                        except:
                            pass
    if condVisibility('system.platform.ATV2'):
        atv2_cache_a = joinPath('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        for root, dirs, files in walk(atv2_cache_a):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                if yesnoDialog(AddonTitle, str(file_count) + " Cache files found in 'Other'", "Do you want to delete them?", yeslabel='YES', nolabel='NO'):
                    for f in files:
                        unlink(joinPath(root, f))
                    for d in dirs:
                        shutil.rmtree(joinPath(root, d))
        atv2_cache_b = joinPath('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        for root, dirs, files in walk(atv2_cache_b):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                if yesnoDialog(AddonTitle, str(file_count) + " Cache files found in 'LocalAndRental'", "Do you want to delete them?", yeslabel='YES', nolabel='NO'):
                    for f in files:
                        unlink(joinPath(root, f))
                    for d in dirs:
                        shutil.rmtree(joinPath(root, d))
    wtf_cache_path = joinPath(transPath('special://profile/addon_data/plugin.video.whatthefurk/cache'), '')
    if existsPath(wtf_cache_path):
        for root, dirs, files in walk(wtf_cache_path):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                if yesnoDialog(AddonTitle, str(file_count) + " Cache files found", "Do you want to delete them?", yeslabel='YES', nolabel='NO'):
                    for f in files:
                        unlink(joinPath(root, f))
                    for d in dirs:
                        shutil.rmtree(joinPath(root, d))
    channel4_cache_path = joinPath(transPath('special://profile/addon_data/plugin.video.4od/cache'), '')
    if existsPath(channel4_cache_path):
        for root, dirs, files in walk(channel4_cache_path):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                if yesnoDialog(AddonTitle, str(file_count) + " Cache files found", "Do you want to delete them?", yeslabel='YES', nolabel='NO'):
                    for f in files:
                        unlink(joinPath(root, f))
                    for d in dirs:
                        shutil.rmtree(joinPath(root, d))

    iplayer_cache_path = joinPath(transPath('special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache'), '')
    if existsPath(iplayer_cache_path):
        for root, dirs, files in walk(iplayer_cache_path):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                if yesnoDialog(AddonTitle, str(file_count) + " Cache files found", "Do you want to delete them?", yeslabel='YES', nolabel='NO'):
                    for f in files:
                        unlink(joinPath(root, f))
                    for d in dirs:
                        shutil.rmtree(joinPath(root, d))

    downloader_cache_path = joinPath(transPath('special://profile/addon_data/script.module.simple.downloader'), '')
    if existsPath(downloader_cache_path):
        for root, dirs, files in walk(downloader_cache_path):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                if yesnoDialog(AddonTitle, str(file_count) + " Cache files found", "Do you want to delete them?", yeslabel='YES', nolabel='NO'):
                    for f in files:
                        unlink(joinPath(root, f))
                    for d in dirs:
                        shutil.rmtree(joinPath(root, d))

    itv_cache_path = joinPath(transPath('special://profile/addon_data/plugin.video.itv/Images'), '')
    if existsPath(itv_cache_path):
        for root, dirs, files in walk(itv_cache_path):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                if yesnoDialog(AddonTitle, str(file_count) + "Cache files found", "Do you want to delete them?", yeslabel='YES', nolabel='NO'):
                    for f in files:
                        unlink(joinPath(root, f))
                    for d in dirs:
                        shutil.rmtree(joinPath(root, d))

    temp_cache_path = joinPath(transPath('special://home/temp'), '')
    if existsPath(temp_cache_path):
        for root, dirs, files in walk(temp_cache_path):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                if yesnoDialog(AddonTitle, str(file_count) + " Cache files found", "Do you want to delete them?", yeslabel='YES', nolabel='NO'):
                    for f in files:
                        if f == "kodi.log" or f == "kodi.old.log" or f == "xbmc.log" or f == "xbmc.old.log" or f == "spmc.log" or f == "spmc.old.log" or f == "ezclean.log" or f == "scrubsv2.log":
                            continue
                        unlink(joinPath(root, f))
                    for d in dirs:
                        shutil.rmtree(joinPath(root, d))

    infoDialog('DELETING STANDARD CACHE Complet')
