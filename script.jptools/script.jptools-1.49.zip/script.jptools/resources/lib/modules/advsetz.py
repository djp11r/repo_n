# -*- coding: UTF-8 -*-


import re
import sys

from modules.control import transPath, joinPath

AdvancedSettingsFile = transPath(joinPath('special://profile/', 'advancedsettings.xml'))


def xml_data_advSettings_old(size):
    xml_data = """<advancedsettings>
      <network>
        <curlclienttimeout>10</curlclienttimeout>
        <curllowspeedtime>20</curllowspeedtime>
        <curlretries>2</curlretries>
        <cachemembuffersize>%s</cachemembuffersize>
        <buffermode>2</buffermode>
        <readbufferfactor>20</readbufferfactor>
      </network>
</advancedsettings>""" % size
    return xml_data


def xml_data_advSettings_New(size):
    xml_data = """<advancedsettings>
      <network>
        <disablehttp2>true</disablehttp2>
        <curlclienttimeout>10</curlclienttimeout>
        <curllowspeedtime>20</curllowspeedtime>
        <curlretries>2</curlretries>
      </network>
      <cache>
        <memorysize>%s</memorysize>
        <buffermode>2</buffermode>
        <readfactor>20</readfactor>
      </cache>
</advancedsettings>""" % size
    return xml_data


def advancedSettings():
    from modules.control import AddonTitle, dialog, infoLabel, get_Kodi_Version, get_keyboard
    MEM = infoLabel("System.Memory(total)")
    FREEMEM = infoLabel("System.FreeMemory")
    BUFFER_F = re.sub('[^0-9]', '', FREEMEM)
    BUFFER_F = int(BUFFER_F) // 3
    BUFFERSIZE = BUFFER_F * 1024 * 1024
    try:
        KODIV = get_Kodi_Version()
    except:
        KODIV = 16
    # log(MEM)
    choice = dialog.yesno(AddonTitle, "Free Memory: [B]%s[/B]\nOptimal BufferSize is: [B]%s MB[/B]\nChoose an Option below..." % (str(FREEMEM), str(BUFFER_F)), yeslabel="[COLOR lime][B]Use Optimal[/B][/COLOR]", nolabel="[COLOR red]Input a Value[/COLOR]")
    if choice == 1:
        with open(AdvancedSettingsFile, "w") as f:
            if KODIV >= 17:
                xml_data = xml_data_advSettings_New(str(BUFFERSIZE))
            else:
                xml_data = xml_data_advSettings_old(str(BUFFERSIZE))
            f.write(xml_data)
            dialog.ok(AddonTitle, "Buffer Size Set to: [B]%s[/B]  aka  [B]%s MB[/B]\nPlease restart Kodi for the settings to apply." % (int(BUFFERSIZE), int(BUFFER_F)))
    elif choice == 0:
        BUFFERSIZE = get_keyboard(default=str(BUFFERSIZE), heading="INPUT BUFFER SIZE")
        with open(AdvancedSettingsFile, "w") as f:
            if KODIV >= 17:
                xml_data = xml_data_advSettings_New(str(BUFFERSIZE))
            else:
                xml_data = xml_data_advSettings_old(str(BUFFERSIZE))
            f.write(xml_data)
            dialog.ok(AddonTitle, "Buffer Size Set to: [B]%s[/B]  aka  [B]%s MB[/B]\nPlease restart Kodi for the settings to apply." % (int(BUFFERSIZE), (int(BUFFERSIZE) // (1024 * 1024))))


def viewAdvancedSettings():
    from modules.control import dialog, AddonTitle
    try:
        from api import TextViewer
        TextViewer.text_view(AdvancedSettingsFile)
    except:
        dialog.ok(AddonTitle, "Error\nUnable to view the advancedsettings.xml file.\nMight not have one yet.")
        sys.exit(0)


def clearAdvancedSettings():
    from modules.control import AddonTitle, dialog, deleteFile
    try:
        deleteFile(AdvancedSettingsFile)
        dialog.ok(AddonTitle, "Success", 'The advancedsettings.xml has been removed.')
    except:
        dialog.ok(AddonTitle, "Error\nUnable to remove the advancedsettings.xml file.\nMight not have one yet.")
        sys.exit(0)
