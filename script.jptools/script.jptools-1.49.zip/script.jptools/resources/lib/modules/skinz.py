# -*- coding: UTF-8 -*-
import glob
import re

import json


def currSkin():
    from modules.control import skin
    return skin


def getOld(old):
    from modules.control import jsonrpc
    try:
        old = '"%s"' % old
        query = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % (old)
        response = jsonrpc(query)
        response = json.loads(response)
        if response.has_key('result'):
            if response['result'].has_key('value'):
                return response['result']['value']
    except:
        pass
    return None


def setNew(new, value):
    from modules.control import jsonrpc
    try:
        new = '"%s"' % new
        value = '"%s"' % value
        query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % (new, value)
        response = jsonrpc(query)
    except:
        pass
    return None


def swapSkins(skin):
    old = 'lookandfeel.skin'
    value = skin
    current = getOld(old)
    new = old
    setNew(new, value)


def lookandFeelData(do='save'):
    from modules.control import setSetting, log, setting, jsonrpc
    scan = ['lookandfeel.enablerssfeeds', 'lookandfeel.font', 'lookandfeel.rssedit', 'lookandfeel.skincolors', 'lookandfeel.skintheme', 'lookandfeel.skinzoom', 'lookandfeel.soundskin', 'lookandfeel.startupwindow', 'lookandfeel.stereostrength']
    if do == 'save':
        for item in scan:
            query = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":"%s"}, "id":1}' % (item)
            response = jsonrpc(query)
            if not 'error' in response:
                match = re.compile('{"value":(.+?)}').findall(str(response))
                setSetting(item.replace('lookandfeel', 'default'), match[0])
                log("%s saved to %s" % (item, match[0]))
    else:
        for item in scan:
            value = setting(item.replace('lookandfeel', 'default'))
            query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"%s","value":%s}, "id":1}' % (item, value)
            response = jsonrpc(query)
            log("%s restored to %s" % (item, value))


def defaultSkin():
    from modules.control import log, joinPath, homepath, userdata, deleteFile, existsPath, setSetting
    log("[Default Skin Check]")
    ADDONS = joinPath(homepath, 'addons')
    GUISETTINGS = joinPath(userdata, 'guisettings.xml')
    tempgui = joinPath(userdata, 'guitemp.xml')
    gui = tempgui if existsPath(tempgui) else GUISETTINGS
    if not existsPath(gui):
        return False
    log("Reading gui file: %s" % gui)
    guif = open(gui, 'r+')
    msg = guif.read().replace('\n', '').replace('\r', '').replace('\t', '').replace('    ', '')
    guif.close()
    log("Opening gui settings")
    match = re.compile('<lookandfeel>.+?<ski.+?>(.+?)</skin>.+?</lookandfeel>').findall(msg)
    log("Matches: %s" % str(match))
    if len(match) > 0:
        skinid = match[0]
        addonxml = joinPath(ADDONS, match[0], 'addon.xml')
        if existsPath(addonxml):
            addf = open(addonxml, 'r+')
            msg2 = addf.read().replace('\n', '').replace('\r', '').replace('\t', '')
            addf.close()
            match2 = re.compile('<addon.+?ame="(.+?)".+?>').findall(msg2)
            if len(match2) > 0:
                skinname = match2[0]
            else:
                skinname = 'no match'
        else:
            skinname = 'no file'
        log("[Default Skin Check] Skin name: %s" % skinname)
        log("[Default Skin Check] Skin id: %s" % skinid)
        setSetting('defaultskin', skinid)
        setSetting('defaultskinname', skinname)
        setSetting('defaultskinignore', 'false')
    if existsPath(tempgui):
        log("Deleting Temp Gui File.")
        deleteFile(tempgui)
    log("[Default Skin Check] End")


def checkSkin():
    from modules.control import log, setting, setSetting, homepath, joinPath, color1, color2, existsPath, AddonTitle, dialog, condVisibility, execute, sleep, infoDialog, skin
    ADDONS = joinPath(homepath, 'addons')
    log("Invalid Skin Check Start")
    DEFAULTSKIN = setting('defaultskin')
    DEFAULTNAME = setting('defaultskinname')
    DEFAULTIGNORE = setting('defaultskinignore')
    gotoskin = False
    if not DEFAULTSKIN == '':
        if existsPath(joinPath(ADDONS, DEFAULTSKIN)):
            if dialog.yesno(AddonTitle, "[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]" % (color2, color1, skin[5:].title()), "Would you like to set the skin back to:[/COLOR]", '[COLOR %s]%s[/COLOR]' % (color1, DEFAULTNAME)):
                gotoskin = DEFAULTSKIN
                gotoname = DEFAULTNAME
            else:
                log("Skin was not reset"); setSetting('defaultskinignore', 'true'); gotoskin = False
        else:
            setSetting('defaultskin', ''); setSetting('defaultskinname', ''); DEFAULTSKIN = ''; DEFAULTNAME = ''
    if DEFAULTSKIN == '':
        skinname = []
        skinlist = []
        for folder in glob.glob(joinPath(ADDONS, 'skin.*/')):
            xml = "%s/addon.xml" % folder
            if existsPath(xml):
                f = open(xml, mode='r')
                g = f.read().replace('\n', '').replace('\r', '').replace('\t', '')
                f.close()
                match = re.compile('<addon.+?id="(.+?)".+?>').findall(g)
                match2 = re.compile('<addon.+?name="(.+?)".+?>').findall(g)
                log("%s: %s" % (folder, str(match[0])))
                if len(match) > 0:
                    skinlist.append(str(match[0])); skinname.append(str(match2[0]))
                else:
                    log("ID not found for %s" % folder)
            else:
                log("ID not found for %s" % folder)
        if len(skinlist) > 0:
            if len(skinlist) > 1:
                if dialog.yesno(AddonTitle, "[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]" % (color2, color1, SKIN[5:].title()), "Would you like to view a list of avaliable skins?[/COLOR]"):
                    choice = dialog.select("Select skin to switch to!", skinname)
                    if choice == -1:
                        log("Skin was not reset"); setSetting('defaultskinignore', 'true')
                    else:
                        gotoskin = skinlist[choice]
                        gotoname = skinname[choice]
                else:
                    log("Skin was not reset"); setSetting('defaultskinignore', 'true')
            else:
                if dialog.yesno(AddonTitle, "It seems that the skin has been set back to [B]%s[/B]" % (SKIN[5:].title()), "Would you like to set the skin back to: ", '[B] %s [/B]' % (skinname[0])):
                    gotoskin = skinlist[0]
                    gotoname = skinname[0]
                else:
                    log("Skin was not reset"); setSetting('defaultskinignore', 'true')
        else:
            log("No skins found in addons folder."); setSetting('defaultskinignore', 'true'); gotoskin = False
    if gotoskin:
        swapSkins(gotoskin)
        x = 0
        sleep(1000)
        while not condVisibility("Window.isVisible(yesnodialog)") and x < 150:
            x += 1
            sleep(200)
        if condVisibility("Window.isVisible(yesnodialog)"):
            execute('SendClick(11)')
            lookandFeelData('restore')
        else:
            infoDialog('Skin Swap Timed Out!')
    log("Invalid Skin Check End")
