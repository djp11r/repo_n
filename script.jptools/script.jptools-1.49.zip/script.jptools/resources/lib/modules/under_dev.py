#!/bin/python
import json
import os
import re
# import urllib2
import sys
import traceback
import xbmc, xbmcgui

from modules.control import addonInfo, jsonrpc, log
from modules.utilz import os_path_join, os_path_split
# file = os.path.realpath(__file__)
# sys.path.append(os.path.join(os.path.dirname(file)))
# from utilz import OPEN_URL

# from modules.utilz import OPEN_URL
# Written by: Phantom Raspberry Blower
# Date: 21-02-2018
# Description: Module for downloading information about ip address

URL = 'https://ipinfo.io/%s'
API_KEY = 'AIzaSyDIJ9XX2ZvRKCJcFRrl-lRanEtFUow4piM'
IMG_SIZE = '480x390'

class IPInfo:

    def __init__(self, ipaddr='0.0.0.0'):
        self.clear()
        if ipaddr == '0.0.0.0':
            ipaddr = self._wan_ip_addr()
        if ipaddr != 'Error getting WAN IP Address!':
            self.__ip_addr = ipaddr
            self.get_ip_info(ipaddr)

    @property
    def ip_addr(self):
        return self.__ip_addr

    @property
    def city(self):
        return self.__city

    @property
    def region(self):
        return self.__region

    @property
    def postcode(self):
        return self.__postcode

    @property
    def coordinates(self):
        return self.__coordinates

    @property
    def country(self):
        return self.__country

    @property
    def hostname(self):
        return self.__hostname

    @property
    def addrtype(self):
        return self.__addr_type

    @property
    def asn(self):
        return self.__asn

    @property
    def organization(self):
        return self.__organization

    @property
    def route(self):
        return self.__route

    @property
    def description(self):
        return self.__description

    @property
    def mapimage(self):
        return self.__map_image

    def clear(self):
        self.__ip_addr = '0.0.0.0'
        self.__city = None
        self.__region = None
        self.__postcode = None
        self.__coordinates = None
        self.__country = None
        self.__hostname = None
        self.__addr_type = None
        self.__asn = None
        self.__organization = None
        self.__route = None
        self.__description = None
        self.__map_image = None

    def _regex_from_to(self, text, from_string, to_string, excluding=True):
        if excluding:
            r = re.search("(?i)" + from_string +
                          "([\S\s]+?)" +
                          to_string, text)
        else:
            r = re.search("(?i)(" +
                          from_string +
                          "[\S\s]+?" +
                          to_string +
                          ")", text)
        if r: r = r.group(1)
        else: r = ''
        return r

    def _get_url(self, url):
        """
        Download url and remove carriage return
        and tab spaces from page
        """
        # log("url: %s" % url)
        req = OPEN_URL(url)
        # log(req.text)
        if req: return req.text
        else: return 'Error! Unable to download url!'

    def _wan_ip_addr(self):
    # Get the WAN IP address
        try:
            return self._get_url('http://ip.42.pl/raw')
        except:
            return 'Error getting WAN IP Address!'

    def _ip_info(self, ipaddr=None):
        text = ''
        """
        Show Location
        """
        try:
            # ipaddr = "159.89.116.119"
            # response = self._get_url(URL % ipaddr)
            if ipaddr == 'Error getting WAN IP Address!':
                response = json.loads(self._get_url("https://ipapi.co/json/"))
                log('from: %s response: %s' % ("https://ipapi.co/json/", response))
            else:
                response = json.loads(self._get_url(URL % ipaddr))
                log('from: %s response: %s' % (URL % ipaddr, response))
            # address = response.replace('\t', '').replace('\n', '').replace('  ', '')
            # matchrows = re.compile('<dl class="row">(.+?)</dl>').findall(address)
            # for item in matchrows:
            #     matchitems = re.compile('<dt class="col-sm-4 mb-md-3">(.+?)</dt>'
            #                             '<dd class="col-sm-8 mb-md-9">(.+?)</dd>').findall(item)
            #     log('matchitems: %s' % matchitems)
            #     for key, value in matchitems:
            #         if '<a' in value:
            #             value = self._regex_from_to(value, '">', '</a>')
            #         text += ('%s: %s\n') % (key, value)
            self.__ip_addr = response.get('ip', 'Not Found')
            self.__coordinates = response.get('loc', 'Not Found')
            self.__country = response.get('country', 'Not Found')
            self.__hostname = response.get('org', 'Not Found')
            self.__asn = response.get('ip', 'Not Found')
            self.__organization = response.get('org', 'Not Found')
            self.__route = response.get('ip', 'Not Found')
            self.__addr_type = response.get('ip', 'Not Found')
            self.__region = response.get('timezone', 'Not Found')
            self.__postcode = response.get('postal', 'Not Found')
            self.__city = response.get('city', 'Not Found')
            try:
                # self.__map_image = 'https://www.google.com/maps/embed/v1/view?zoom=10&center=%s&key=%s' % (self.__coordinates, API_KEY)
                self.__map_image = 'https://maps.googleapis.com/maps/api/staticmap?center=%s&zoom=11&&size=%s&key=%s' % (lat_lon, IMG_SIZE, API_KEY)
                url = 'https://en.wikipedia.org/w/api.php?action=query&prop=extracts&titles=%s&exintro=&exsentences=2&explaintext=&redirects=&formatversion=2&format=json' % self.__city
                response = self._get_url(url)
                self.__description = self._regex_from_to(response, ',"extract":"', '"}]}')
            except:
                log('__description Error: %s' % traceback.print_exc())
                self.__description = 'description Not Found on wiki'

            return {'ip_addr': self.__ip_addr,
                    'city': self.__city,
                    'region': self.__region,
                    'postcode': self.__postcode,
                    'coordinates': self.__coordinates,
                    'country': self.__country,
                    'hostname': self.__hostname,
                    'addr_type': self.__addr_type,
                    'asn': self.__asn,
                    'organization': self.__organization,
                    'route': self.__route,
                    'description': self.__description,
                    'map_image': self.__map_image}
        except:
            log('_ip_info Error: %s' % traceback.print_exc())
            return 'Error getting IP address info!'

    def get_ip_info(self, ipaddr):
        """
        Return artist information as dictionary. If no result try either
        removing or prefixing the 'the' word.
        """
        self.clear()
        ipi = self._ip_info(ipaddr)
        # ipi = {'ip_addr': '14.1.120.0', 'description': '', 'postcode': '400703', 'map_image': 'https://www.google.com/maps/embed/v1/view?zoom=10&center=19.0323,73.0428&key=AIzaSyDIJ9XX2ZvRKCJcFRrl-lRanEtFUow4piM', 'asn': '14.1.120.0', 'city': 'Artist Village', 'country': 'IN', 'region': 'Asia/Kolkata', 'hostname': 'AS134881 JLINK INDIA', 'coordinates': '19.0323,73.0428', 'addr_type': '14.1.120.0', 'organization': 'AS134881 JLINK INDIA', 'route': '14.1.120.0'}
        # ipi: {'ip_addr': '206.189.68.216', 'description': 'Santa Clara (Portuguese and Spanish for Saint Clare or Saint Clair) may refer to:', 'postcode': '95051', 'map_image': 'https://www.google.com/maps/embed/v1/view?zoom=10&center=37.3483,-121.9844&key=AIzaSyDIJ9XX2ZvRKCJcFRrl-lRanEtFUow4piM', 'asn': '206.189.68.216', 'city': 'Santa Clara', 'country': 'US', 'region': 'America/Los_Angeles', 'hostname': 'AS14061 DigitalOcean, LLC', 'coordinates': '37.3483,-121.9844', 'addr_type': '206.189.68.216', 'organization': 'AS14061 DigitalOcean, LLC', 'route': '206.189.68.216'}
        log('ipi: %s' % ipi)
        return ipi


def test_WindowXMLDialog():
    """
    Show ip info including location
    """
    
    # log('>>> test_WindowXMLDialog: {}'.format(addonInfo('path')))
    # ip_info = {'ip_addr': '206.189.68.216', 'description': 'Santa Clara (Portuguese and Spanish for Saint Clare or Saint Clair) may refer to:', 'postcode': '95051', 'map_image': 'https://www.google.com/maps/embed/v1/view?zoom=10&center=37.3483,-121.9844&key=AIzaSyDIJ9XX2ZvRKCJcFRrl-lRanEtFUow4piM', 'asn': '206.189.68.216', 'city': 'Santa Clara', 'country': 'US', 'region': 'America/Los_Angeles', 'hostname': 'AS14061 DigitalOcean, LLC', 'coordinates': '37.3483,-121.9844', 'addr_type': '206.189.68.216', 'organization': 'AS14061 DigitalOcean, LLC', 'route': '206.189.68.216'}
    window = xbmcgui.WindowXMLDialog('next_episode.xml', addonInfo('path'))
    # window = xbmcgui.WindowXMLDialog('yes_no_progress_media.xml', addonInfo('path'))
    
    window.doModal()
    del window


def ip2location():
    """
    Show ip info including location
    """
    from modules.ipinfo import IPInfo
    ip_info = IPInfo()
    ip_info = ip_info._ip_info()
    log('ip2location >>> ip_info: %s' % ip_info)
    # ip_info = {'ip_addr': '206.189.68.216', 'description': 'Santa Clara (Portuguese and Spanish for Saint Clare or Saint Clair) may refer to:', 'postcode': '95051', 'map_image': 'https://www.google.com/maps/embed/v1/view?zoom=10&center=37.3483,-121.9844&key=AIzaSyDIJ9XX2ZvRKCJcFRrl-lRanEtFUow4piM', 'asn': '206.189.68.216', 'city': 'Santa Clara', 'country': 'US', 'region': 'America/Los_Angeles', 'hostname': 'AS14061 DigitalOcean, LLC', 'coordinates': '37.3483,-121.9844', 'addr_type': '206.189.68.216', 'organization': 'AS14061 DigitalOcean, LLC', 'route': '206.189.68.216'}
    window = xbmcgui.WindowXMLDialog('script-ip-2-location.xml', addonInfo('path'))
    win = xbmcgui.Window(10147)
    win.setProperty('HeadingLabel', '[COLOR blue]Location for IP Address:[/COLOR] ' + ip_info.get('ip_addr'))
    win.setProperty('MapImage', ip_info.get('mapimage'))
    win.setProperty('Region', ip_info.get('region'))
    win.setProperty('City', ip_info.get('city'))
    win.setProperty('PostCode', ip_info.get('postcode'))
    win.setProperty('Coordinates', ip_info.get('coordinates'))
    win.setProperty('Country', ip_info.get('country'))
    win.setProperty('Hostname', ip_info.get('hostname'))
    win.setProperty('AddressType', ip_info.get('addrtype'))
    win.setProperty('ASN', ip_info.get('asn'))
    win.setProperty('Organization', ip_info.get('organization'))
    win.setProperty('Route', ip_info.get('route'))
    win.setProperty('Description', ip_info.get('description'))
    window.doModal()
    del window
    # this work
    # from modules.ipinfo import IPInfo
    # ip_info = IPInfo()
    # if ip_info == 'Error getting IP address info!':
        # infoDialog(ip_info, 'IP 2 Location')
    # else:
        # window = xbmcgui.WindowXMLDialog('script-ip-2-location.xml', addonInfo('path'))
        # win = xbmcgui.Window(10147)
        # win.setProperty('HeadingLabel', '[COLOR blue]Location for IP Address:[/COLOR] ' + ip_info.ip_addr)
        # win.setProperty('MapImage', ip_info.mapimage)
        # win.setProperty('Region', ip_info.region)
        # win.setProperty('City', ip_info.city)
        # win.setProperty('PostCode', ip_info.postcode)
        # win.setProperty('Coordinates', ip_info.coordinates)
        # win.setProperty('Country', ip_info.country)
        # win.setProperty('Hostname', ip_info.hostname)
        # win.setProperty('AddressType', ip_info.addrtype)
        # win.setProperty('ASN', ip_info.asn)
        # win.setProperty('Organization', ip_info.organization)
        # win.setProperty('Route', ip_info.route)
        # win.setProperty('Description', ip_info.description)
        # window.doModal()
        # del window


# Class to handle the creation of dummy addons
class AddonTemplate():
    def __init__(self):
        # Record where the root of all the addons should be
        self.addonRoot = xbmc.translatePath('special://masterprofile').decode("utf-8")
        # This will have got the user data, now get the parent directory of that
        self.addonRoot = os_path_join(os_path_split(self.addonRoot)[0], "addons")
        # Make sure the directory ends in a slash
        self.addonRoot = os_path_join(self.addonRoot, "")
        self.addonTemplate = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<addon id="%s" name="%s" version="0.0.1" provider-name="robwebset">
    <requires>
        <import addon="xbmc.python" version="2.14.0"/>
    </requires>
    <extension point="xbmc.python.script" library="default.py"/>
    <extension point="xbmc.addon.metadata">
        <summary lang="en"></summary>
        <language></language>
        <platform>all</platform>
    </extension>
</addon>
'''

    # Create a dummy entry on disk for a given addon
    def createTemplateAddon(self, addonId, addonName):
        log("AddonTemplate: Creating template for id=%s, name=%s" % (addonId, addonName))

        # Create the correct directory in the addons section on disk
        if not xbmcvfs.exists(self.addonRoot):
            log("AddonTemplate: Addons directory does not exist: %s" % self.addonRoot)
            return False

        # Check if the addon directory already exists
        addonDir = os_path_join(self.addonRoot, addonId)
        addonDir = os_path_join(addonDir, "")
        if xbmcvfs.exists(addonDir):
            log("AddonTemplate: Addon directory already exists: %s" % addonDir)
            return False

        # Create the addon directory
        if not xbmcvfs.mkdir(addonDir):
            log("AddonTemplate: Failed to create addon directory %s" % addonDir)
            return False

        # Create the addon.xml file contents
        addonXml = self.addonTemplate % (addonId, addonName)
        addonXmlLocation = os_path_join(addonDir, "addon.xml")

        # Create the addon.xml file on disk
        try:
            f = xbmcvfs.File(addonXmlLocation, 'wb')
            f.write(str(addonXml))
            f.close()
        except:
            log("AddonTemplate: Failed to create addon.xml file %s (error = %s)" % (addonXmlLocation, traceback.format_exc()))
            return False

        return True


# Class to retrieve data from URepo
class URepo():
    def __init__(self, defaultUsername):
        self.url_prefix = 'https://github.com/robwebset/script.urepo.helper/blob/master/default.py'#base64.b64decode('aHR0cDovL3d3dy51cmVwby5vcmcvYXBpL3YxL2pzb24vMjU4OS8=')
        self.username = defaultUsername

    def getAddonCollection(self):
        collectionUrl = "%s?user=%s" % (self.url_prefix, self.username)

        collection = []

        # Make the call to theaudiodb.com
        xml_details = self._makeCall(collectionUrl)

        if xml_details not in [None, ""]:
            repo_version = re.findall(r'<addon id=\"(.+?)\".+version=\"(\d*.\d*.\d*)\"', xml_details.text)#[0]
            log('get_addonupd_list >>> repo_version: {}'.format(repo_version))

            # The results of the search come back as an array of entries
            for addon in repo_version:
                # Skip the URepo helper addon, we don't want to install ourself
                if addon[0] in [None, "", "script.urepo.helper"]:
                    continue
                log("URepo: Addon collection: %s" % addon[0])
                addonDetails = {'id': addon[0], 'vers': addon[1], 'zipname': "{}.{}.zip".format(addon[0], addon[1])}
                collection.append(addonDetails)

        return collection

    # Perform the API call
    def _makeCall(self, url):
        log("makeCall: Making query using %s" % url)
        repo_xml = None
        try:
            import requests
            repo_xml = requests.get('https://bitbucket.org/jai_s/repojp/raw/HEAD/addons.xml')
            # repo_xml = requests.get('https://bitbucket.org/jai_s/repojp/raw/HEAD/plugin.video.infinity/addon.xml')
            if not repo_xml.status_code == 200:
                log('status code = %s >>> Could not connect to remote repo XML: %s' % (repo_xml.status_code, repo_xml))
            
            # req = urllib2.Request(url)
            # req.add_header('Accept', 'application/json')
            # req.add_header('User-Agent', 'Kodi Browser')
            # response = urllib2.urlopen(req)
            # repo_xml = response.read()
            # try:
                # response.close()
                # log("makeCall: Request returned %s" % repo_xml)
            # except:
                # pass
        except:
            log("makeCall: Failed to retrieve details from %s: %s" % (url, traceback.format_exc()))

        return repo_xml


def get_addonupd_list():
    query = {"jsonrpc": "2.0", "id": "1", "method": "Addons.GetAddons", "params": {"properties": ["version"]}}
    json_response = jsonrpc(query)
    # log('json_response >>> json_response: %s' % json_response)
    has_addons = []
    addonItems = json_response[0]['result']['addons']
    # log("URepo: addonItems: %s" % json_response[0]['result']['addons'])
    for addonItem in addonItems:
        log("addonItem: %s" % addonItem)
        has_addons.append("{}-{}.zip".format(addonItem['addonid'], addonItem['version']))
    log("URepo: Detected Installed has_addons: %s" % has_addons)


def get_addonupd_list_test():
    query = {"jsonrpc": "2.0", "id": "1", "method": "Application.GetProperties", "params": {"properties": ["version", "name"]}}
    # query = {"jsonrpc": "2.0", "id": "1", "method": "Addons.GetAddonDetails", "params": {"addonid": "plugin.video.infinite", "properties": ["enabled"]}}
    # query = {"jsonrpc": "2.0", "id": "1", "method": "Addons.OutDated", "params": {}}
    # query = {"jsonrpc": "2.0", "id": "1", "method": "Addons.GetAddons", "params": {"type": "xbmc.player.musicviz"}}
    # query = {"jsonrpc": "2.0", "id": "1", "method": "Addons.GetAddons", "params": {"type": "xbmc.addon.video", "enabled": "all"}}
    query = {"jsonrpc": "2.0", "id": "1", "method": "Addons.GetAddons", "params": {"properties": ["enabled", "version", "broken", "name", "extrainfo", "dependencies"]}}
    # query = {"jsonrpc": "2.0", "id": "1", "method": "Addons.GetAddons", "params": {"type": "xbmc.addon.video", "properties": ["version", "name", "broken", "dependencies"]}}
    query = {"jsonrpc": "2.0", "id": "1", "method": "Addons.GetAddons", "params": {"properties": ["version"]}}
    json_response = jsonrpc(query)
    # log('json_response >>> json_response: %s' % json_response)
    has_addons = []
    addonItems = json_response[0]['result']['addons']
    # log("URepo: addonItems: %s" % json_response[0]['result']['addons'])
    for addonItem in addonItems:
        log("addonItem: %s" % addonItem)
        has_addons.append("{}.{}.zip".format(addonItem['addonid'], addonItem['version']))
    log("URepo: Detected Installed has_addons: %s" % has_addons)
    sys.exit(0)
    if ('result' in json_response) and ('addons' in json_response['result']):
        addonItems = json_response['result']['addons']
        log("URepo: addonItems: %s" % addonItems)
        for addonItem in addonItems:
            log("URepo: Detected Installed addonItem: %s" % addonItem)
            has_addons.append("{}.{}.zip".format(addonItem['addonid'], addonItem['version']))
            if addonItem['enabled'] is True and addonItem['broken'] is False:
                has_addons.append("{}.{}.zip".format(addonItem['addonid'], addonItem['version']))
            if (addonItem['enabled'] is True) and (addonItem['broken'] is False) and (addonItem['type'] == 'xbmc.addon.repository') and (addonItem['addonid'] == 'repository.JPB'):
                urepoInstalled = True
    addonsToInstall = []
    log("URepo: Detected Installed has_addons: %s" % has_addons)
    sys.exit(0)
    
    if urepoInstalled:
        try:
            xbmc.executebuiltin("ActivateWindow(busydialog)")

            # Make a call to the URepo repository to get the list of addons
            # selected for this user
            urepo = URepo('iamhear')
            urepoAddons = urepo.getAddonCollection()
            del urepo
            log('get_addonupd_list >>> urepoAddons: %s' % urepoAddons)

            requiredAddons = []

            if len(urepoAddons) > 0:
                existingAddons = []

                # Make the call to find out all the addons that are currently installed
                json_query = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Addons.GetAddons", "params": { "properties": ["enabled"] }, "id": 1}')
                json_response = json.loads(json_query)
                log("URepo: Detected Installed json_response: %s" % json_response)

                if ("result" in json_response) and ('addons' in json_response['result']):
                    # Check each of the addons that are installed on the system
                    for addonItem in json_response['result']['addons']:
                        addonId = addonItem['addonid']
                        log("URepo: Detected Installed Addon: %s" % addonId)
                        existingAddons.append(addonId)

                # Remove any addon that is already installed
                for urepoAddon in urepoAddons:
                    if urepoAddon['id'] in existingAddons:
                        log("URepo: Skipping %s as already installed" % urepoAddon['id'])
                    else:
                        requiredAddons.append(urepoAddon)
        finally:
            xbmc.executebuiltin("Dialog.Close(busydialog)")
        log('get_addonupd_list >>> requiredAddons: %s' % requiredAddons)
        if len(requiredAddons) > 0:
            selected = []
            # Extract the display name
            displayList = []
            for anAddon in requiredAddons:
                displayList.append(anAddon['name'])

            # Display a list of addons that will be installed
            # From Kodi v17 onwards there is an option to pre-select the items in the list
            if kodiVersion > 16:
                # Get the indexes to preselect
                preselectIdxs = []
                for i in range(0, len(requiredAddons)):
                    preselectIdxs.append(i)
                selected = xbmcgui.Dialog().multiselect(ADDON.getLocalizedString('Select Addons To Install'), displayList, preselect=preselectIdxs)
            else:
                selected = xbmcgui.Dialog().multiselect(ADDON.getLocalizedString('Select Addons To Install'), displayList)

            if (selected in [None, ""]) or (len(selected) < 1):
                log("URepo: Install operation cancelled, no addons to install")
            else:
                # Put together the list of addons to install
                for i in selected:
                    addonsToInstall.append(requiredAddons[i])

    # Perform the install for the required addons
    # if len(addonsToInstall) > 0:
        # successCountDisplay = ""
        # failedCountDisplay = ""
        # # Now create a template for each addon
        # addonTemplate = AddonTemplate()
        # for addon in addonsToInstall:
            # addonTemplate.createTemplateAddon(addon['id'], addon['name'])
        # # The following call will read in the template addons that were created
        # # into the Kodi installation, however they will be marked as disabled
        # xbmc.executebuiltin("UpdateLocalAddons", True)
        # xbmc.sleep(1000)
        # # Make a call for each addon to enable it as it will have been added as disabled originally
        # for addonToInstall in addonsToInstall:
            # log("URepo: Enabling addon %s" % addonToInstall['id'])
            # xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Addons.SetAddonEnabled", "params": { "addonid": "%s", "enabled": "toggle" }, "id": 1}' % addonToInstall['id'])
        # xbmc.sleep(1000)
        # # Now force a refresh of all of the addons so that we get the templates that
        # # were created replaced with the real addons
        # xbmc.executebuiltin("UpdateAddonRepos", True)


# if __name__ == "__main__":
#     ip_info = IPInfo()
#     log(ip_info)
