# -*- coding: utf-8 -*-


from modules.control import transPath, joinPath


def clean_oldlog(mode='verbose'):
    from os import listdir
    from modules.control import logpath, infoDialog
    logfilepath = listdir(logpath)
    # log('logfilepath: %s'%logfilepath)
    try:
        for item in logfilepath:
            # if item.endswith('.log'):
            if item.endswith('.log') and item not in ['kodi.log', 'kodi.old.log']:
                # log('item to clean: %s'%item)
                l_file = joinPath(logpath, item)
                # log('item to clean: %s'%l_file)
                with open(l_file, 'w') as logFile:
                    logFile.write('')
        if mode == 'verbose': infoDialog('Clean Old log files Completed.')
    except Exception as e:
        log("clean_oldlog Error: %s" % str(e))
        # return

class cacheEntry(object):
    def __init__(self, namei, pathi):
        self.name = namei
        self.path = pathi

    def setupCacheEntries(self):
        entries = 5  #make sure this refelcts the amount of entries you have
        dialogName = ["WTF", "4oD", "BBC iPlayer", "Simple Downloader", "ITV"]
        pathName = ["special://profile/addon_data/plugin.video.whatthefurk/cache", "special://profile/addon_data/plugin.video.4od/cache", "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache", "special://profile/addon_data/script.module.simple.downloader", "special://profile/addon_data/plugin.video.itv/Images"]
        cacheEntries = []
        for x in range(entries):
            cacheEntries.append(cacheEntry(dialogName[x], pathName[x]))
        return cacheEntries


def clearCache(mode='verbose'):
    from modules.control import condVisibility, getSettingEnabled, existsPath, infoDialog
    tempPath = transPath('special://temp')
    tempPath2 = transPath('special://addons/temp')
    cachePath = joinPath(transPath('special://home'), 'cache')
    if existsPath(cachePath) == True and getSettingEnabled('tune.cachePath') == True:
        total_files, total_folds = cleanfolder(cachePath)
        file_count = total_files + total_folds
        if mode == 'verbose':
            infoDialog('Clean cache Completed [ %d ]' % file_count)

    if existsPath(tempPath):
        total_files, total_folds = cleanfolder(tempPath)
        file_count = total_files + total_folds
        if mode == 'verbose':
            infoDialog('Clean temp Completed [ %d ]' % file_count)
    if existsPath(tempPath2):
        total_files, total_folds = cleanfolder(tempPath2)
        file_count = total_files + total_folds

    if condVisibility('system.platform.ATV2'):
        atv2_cache_a = joinPath('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        total_files, total_folds = cleanfolder(atv2_cache_a)
        file_count = total_files + total_folds

        atv2_cache_b = joinPath('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        total_files, total_folds = cleanfolder(atv2_cache_b)
        file_count += total_files + total_folds

        if mode == 'verbose':
            infoDialog('Clean Caches Completed [ %d ]' % file_count)

    cacheEntries = []
    file_count = 0
    for entry in cacheEntries:
        clear_cache_path = transPath(entry.path)
        if existsPath(clear_cache_path) == True and getSettingEnabled('tune.cacheEntries') == True:
            total_files, total_folds = cleanfolder(clear_cache_path)
            file_count += total_files + total_folds
            if mode == 'verbose':
                infoDialog('Clean Caches Completed [ %d ]' % file_count)
    if mode == 'verbose':
        infoDialog('Clean Cache Completed.')


def O_deleteThumbnails(mode='verbose'):
    from os import walk, unlink
    import shutil
    from modules.control import getSettingEnabled, existsPath, infoDialog
    thumbnailPath = transPath('special://thumbnails')
    THUMBS = transPath(joinPath('special://home/userdata/Thumbnails', ''))
    if existsPath(thumbnailPath):
        if getSettingEnabled('tune.thumbs1'):
            #if yesnoDialog("Delete Thumbnails", "This option deletes all thumbnails", "Are you sure you want to do this?"):
            for root, dirs, files in walk(thumbnailPath):
                file_count = 0
                file_count += len(files)
                if file_count > 0:
                    for f in files:
                        try:
                            unlink(joinPath(root, f))
                        except:
                            pass
    if existsPath(THUMBS):
        try:
            if getSettingEnabled('tune.thumbs2'):
                for root, dirs, files in walk(THUMBS):
                    file_count = 0
                    file_count += len(files)
                    #Count files and give option to delete
                    if file_count > 0:
                        for f in files:
                            unlink(joinPath(root, f))
                        for d in dirs:
                            shutil.rmtree(joinPath(root, d))
        except:
            pass
    try:
        if getSettingEnabled('tune.thumbs3'):
            text13 = joinPath(databasepath, "Textures13.db")
            unlink(text13)
    except:
        pass
    if mode == 'verbose':
        infoDialog('Clean Thumbs Completed.')


def deleteold_Thumbnails(mode='verbose'):
    from modules.control import color1, color2, deleteFile, oldthumb, existsPath, log, infoDialog, databasepath
    from os.path import getsize
    from sqlite3 import dbapi2 as database
    THUMBS = transPath(joinPath('special://home/userdata/Thumbnails', ''))
    use = 30
    ids = []
    images = []
    size = 0
    dbfile = joinPath(databasepath, "Textures13.db")
    if existsPath(dbfile):
        try:
            textdb = database.connect(dbfile)
            textexe = textdb.cursor()
            log("[Clean Old Thumbnails] Cleaning thumbnails older than {0}, or haven't been accessed at least {1} times.".format(str(oldthumb), use))
            textexe.execute("SELECT idtexture FROM sizes WHERE usecount < ? AND lastusetime < ?", (use, str(oldthumb)))
            found = textexe.fetchall()
            for rows in found:
                idfound = rows[0]
                ids.append(idfound)
                textexe.execute("SELECT cachedurl FROM texture WHERE id = ?", (idfound,))
                found2 = textexe.fetchall()
                for rows2 in found2:
                    images.append(rows2[0])
            for id in ids:
                textexe.execute("DELETE FROM sizes   WHERE idtexture = ?", (id,))
                textexe.execute("DELETE FROM texture WHERE id        = ?", (id,))
            # textexe.execute("VACUUM")
            textdb.commit()
            textexe.close()
            for image in images:
                path = joinPath(THUMBS, image)
                try:
                    imagesize = getsize(path)
                    deleteFile(path)
                    size += imagesize
                except:
                    pass
            removed = "%.0f" % (size / 1024000.0)
            log("%s total thumbs cleaned up. size: %s" % (len(images), removed))
            if len(images) > 0:
                msg = "[COLOR %s]Clear Thumbs: %s Files / %s MB[/COLOR]!" % (color2, len(images), removed)
            else:
                msg = "[COLOR %s]Clear Thumbs: [COLOR red]Images : %s![/COLOR][/COLOR]" % (color2, len(images))
            infoDialog(str(msg))
        except Exception as e:
            log("DB Connection Error: %s" % str(e))
            return False
    else:
        log('%s not found.' % dbfile); return False



def purgePackages(mode='verbose'):
    from modules.control import infoDialog
    purgePath = transPath('special://home/addons/packages')
    total_files, total_folds = cleanfolder(purgePath)
    file_count = total_files + total_folds
    if mode == 'verbose':
        infoDialog('Clean Packages Completed [ %d ]' % file_count)


def clean_MyVideos116(modify=False):
    from modules.control import log, databasepath
    from sqlite3 import dbapi2 as database
    try:
        db_file = joinPath(databasepath, "MyVideos116.db")
        try:
            textdb = database.connect(db_file)
            cursor = textdb.cursor()
        except Exception as e:
            log("DB Connection Error: %s" % str(e))
            return False
        q = "SELECT name FROM sqlite_master WHERE type='table'"
        # q = "SELECT name from sqlite_master where type= 'table' AND name NOT LIKE 'sqlite_%'"
        cursor.execute(q)
        tables_in_db = cursor.fetchall()
        for i in tables_in_db:
            # print(i[0])
            # print("-" * len(i[0]))
            if "path" in i[0]:
                log(i[0])
                find_delet = '%Z:\\ENet\\TVShow Subscriptions\\%'
                # q = "SELECT * FROM {} WHERE idParentPath IS NULL OR idParentPath = ''".format(i[0])
                q = "SELECT * FROM {} WHERE strPath LIKE '{}'".format(i[0], find_delet)
                cursor.execute(q)
                data = cursor.fetchall()
                j = 0
                for row in data:
                    j += 1
                    log(row)
                log("\nTotal rows : {}".format(j))

                # delete Null
                # dq_p = "DELETE FROM {} WHERE idParentPath IS NULL OR idParentPath = ''".format(i[0])
                # print(q)
                dq_p = "DELETE * FROM {} WHERE strPath LIKE '{}'".format(i[0], find_delet)
                log(dq_p)  # cursor.execute(dq_p)  # cursor.connection.commit()  # cursor.execute("VACUUM")  # cursor.connection.commit()

    except Exception as error:
        log(error)
    finally:
        # Close all cursors
        cursor.close()


def cleanfolder(folder):
    from os import walk, unlink, remove
    from modules.control import deleteFile, log
    import shutil
    file_tokeep = ("kodi.log", "kodi.old.log", "xbmc.log", "xbmc.old.log", "spmc.log", "spmc.old.log")
    # log(folder)
    total_files = 0
    total_folds = 0
    try:
        for root, dirs, files in walk(folder):
            if len(dirs) >= 0:
                for d in dirs:
                    try:
                        shutil.rmtree(joinPath(root, d))
                        total_folds += 1
                    except:
                        log("Error Deleting Folder: %s" % d)
            if len(files) >= 0:
                for f in files:
                    try:
                        if f in file_tokeep:
                            continue
                        unlink(joinPath(root, f))
                        total_files += 1
                    except:
                        log("Error unlink file: %s" % f)
                    try:
                        if f in file_tokeep:
                            continue
                        try:
                            deleteFile(joinPath(root, f))
                        except:
                            remove(joinPath(root, f))
                    except Exception as e:
                        log("Error: %s Deleting file: %s" % (e, f))
    except Exception as e:
        log("cleanfolder Error: %s" % str(e))
    return total_files, total_folds
