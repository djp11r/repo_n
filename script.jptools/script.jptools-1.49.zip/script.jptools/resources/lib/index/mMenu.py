# -*- coding: UTF-8 -*-

from modules.control import setting

# from api import colorChoice

CustomColor = setting('my_ColorChoice')
if CustomColor == '':
    CustomColor = 'none'


def mMenu():
    from modules.control import AddonTitle, SelectDialog, log
    my_options = ['get Addon enet', 'save userdata n zip', 'Save Trakt', 'Restore Trakt', 'Clean addons Trakt', 'Save Favorites', 'Restore Favorites', 'extract zip', 'You Tube API update', 'DNS Leak Test', 'Clear Old Thumbs', 'Convert path to special', 'Clean data folders', 'Reset setting', 'Log File Upload', 'View Log', 'Clean old logs', 'All Errors', '[[B] Close [/B]]']
    selectList = []
    for Item in my_options:
        selectList.append("[COLOR=%s]%s[/COLOR]" % (CustomColor, Item))
    mychoice = SelectDialog(AddonTitle, selectList, key=False)
    # mychoice = mychoice.replace('[COLOR %s]' % (CustomColor), '').replace('[/COLOR]', '')
    # log("mychoice %s" % mychoice)
    if mychoice == '[COLOR=%s]You Tube API update[/COLOR]' % (CustomColor):
        from modules.upd_yt_api import set_api
        set_api()
    elif mychoice == '[COLOR=%s]DNS Leak Test[/COLOR]' % (CustomColor):
        from modules.dns_leak_test import dns_leak_test
        dns_leak_test()
    elif mychoice == '[COLOR=%s]save userdata n zip[/COLOR]' % (CustomColor):
        from modules.traktit import get_userdata
        get_userdata()
    elif mychoice == '[COLOR=%s]get Addon enet[/COLOR]' % (CustomColor):
        from modules.traktit import get_adon_frm_enet
        get_adon_frm_enet()
    elif mychoice == '[COLOR=%s]Save Trakt[/COLOR]' % (CustomColor):
        from modules.traktit import trakt
        trakt('update', 'all')
    elif mychoice == '[COLOR=%s]Restore Trakt[/COLOR]' % (CustomColor):
        from modules.traktit import trakt
        trakt('restore', 'all')
    elif mychoice == '[COLOR=%s]Save Favorites[/COLOR]' % (CustomColor):
        from modules.wiz import BACKUPFAV
        BACKUPFAV()
    elif mychoice == '[COLOR=%s]Restore Favorites[/COLOR]' % (CustomColor):
        from modules.wiz import RESTOREFAV
        RESTOREFAV()
    elif mychoice == '[COLOR=%s]Clean addons Trakt[/COLOR]' % (CustomColor):
        from modules.traktit import trakt
        trakt('clearaddon', 'all')
    elif mychoice == '[COLOR=%s]extract zip[/COLOR]' % (CustomColor):
        from modules.traktit import zipextr
        zipextr()
    elif mychoice == '[COLOR=%s]Clear Old Thumbs[/COLOR]' % (CustomColor):
        from modules.maintenance import deleteold_Thumbnails
        deleteold_Thumbnails()
    elif mychoice == '[COLOR=%s]Convert path to special[/COLOR]' % (CustomColor):
        from modules.wiz import FIX_SPECIAL
        FIX_SPECIAL()
    elif mychoice == '[COLOR=%s]All Errors[/COLOR]' % (CustomColor):
        from modules.traktit import errorChecking
        errorChecking()
    elif mychoice == '[COLOR=%s]Log File Upload[/COLOR]' % (CustomColor):
        from modules.utilz import upload_log
        upload_log()
    elif mychoice == '[COLOR=%s]View Log[/COLOR]' % (CustomColor):
        from modules.traktit import viewlog
        viewlog()
    elif mychoice == '[COLOR=%s]Clean data folders[/COLOR]' % (CustomColor):
        from modules.traktit import clane_adondata
        clane_adondata()
    elif mychoice == '[COLOR=%s]Clean old logs[/COLOR]' % (CustomColor):
        from modules.maintenance import clean_oldlog
        clean_oldlog()
    elif mychoice == '[COLOR=%s]Reset setting[/COLOR]' % (CustomColor):
        from modules.traktit import reset_upd_setting
        # log("mychoice %s" % mychoice)
        reset_upd_setting()
    elif mychoice == '[COLOR=%s][[B] Close [/B]][/COLOR]' % (CustomColor):
        return
