# -*- coding: UTF-8 -*-


from modules.control import setting, log

CustomColor = setting('my_ColorChoice')
if CustomColor == '':
    CustomColor = 'none'


def actChangeLog():
    from api import TextViewer
    from modules.control import transPath, joinPath, AddonID, AddonTitle, SelectDialog, getChangeLog
    changelogfile = transPath(joinPath('special://home/addons/%s' % AddonID, 'changelog.txt'))
    my_options = ['DialogWindow', 'TextViewer', '[[B] Close [/B]]']
    selectList = []
    for Item in my_options:
        selectList.append("[COLOR=%s]%s[/COLOR]" % (CustomColor, Item))
    mychoice = SelectDialog(AddonTitle, selectList, key=False)
    # mychoice = mychoice.replace('[COLOR %s]' % (CustomColor), '').replace('[/COLOR]', '')
    if mychoice == '[COLOR=%s]DialogWindow[/COLOR]' % (CustomColor):
        getChangeLog()
    elif mychoice == '[COLOR=%s]TextViewer[/COLOR]' % (CustomColor):
        TextViewer.text_view(changelogfile)
    elif mychoice == '[COLOR=%s][[B] Close [/B]][/COLOR]' % (CustomColor):
        return


def actLogMenu():
    from modules import utilz
    from modules.control import AddonTitle, SelectDialog
    my_options = ['[B]Log Viewer/Uploader[/B]', '[B]Clear CrashLogs[/B]', '[B]Clear DebugLogs[/B]', '[[B] Close [/B]]']
    selectList = []
    for Item in my_options:
        selectList.append("[COLOR=%s]%s[/COLOR]" % (CustomColor, Item))
    mychoice = SelectDialog(AddonTitle, selectList, key=False)
    # mychoice = mychoice.replace('[COLOR %s]' % (CustomColor), '').replace('[/COLOR]', '')
    if mychoice == '[COLOR=%s][B]Log Viewer/Uploader[/B][/COLOR]' % (CustomColor):
        utilz.logView()
    elif mychoice == '[COLOR=%s][B]Clear CrashLogs[/B][/COLOR]' % (CustomColor):
        utilz.Delete_Crash_Logs()
    elif mychoice == '[COLOR=%s][B]Clear DebugLogs[/B][/COLOR]' % (CustomColor):
        utilz.Delete_DebugLogs()
    elif mychoice == '[COLOR=%s][[B] Close [/B]][/COLOR]' % (CustomColor):
        return


def advancedSettingsMenu():
    from modules import advsetz
    from modules.control import AddonTitle, SelectDialog
    my_options = ['Create AdvancedSettings', 'View AdvancedSettings', 'Clear AdvancedSettings', '[[B] Close [/B]]']
    selectList = []
    for Item in my_options:
        selectList.append("[COLOR=%s]%s[/COLOR]" % (CustomColor, Item))
    mychoice = SelectDialog(AddonTitle, selectList, key=False)
    # log("mychoice: %s" % mychoice)
    # mychoice = mychoice.replace('[COLOR %s]' % (CustomColor), '').replace('[/COLOR]', '')
    # log("mychoice: %s" % mychoice)
    # mc = '[COLOR=%s]Create AdvancedSettings[/COLOR]' % (CustomColor)

    if mychoice == '[COLOR=%s]Create AdvancedSettings[/COLOR]' % (CustomColor):
        advsetz.advancedSettings()
    elif mychoice == '[COLOR=%s]View AdvancedSettings[/COLOR]' % (CustomColor):
        advsetz.viewAdvancedSettings()
    elif mychoice == '[COLOR=%s]Clear AdvancedSettings[/COLOR]' % (CustomColor):
        advsetz.clearAdvancedSettings()
    elif mychoice == '[COLOR=%s][[B] Close [/B]][/COLOR]' % (CustomColor):
        return


def kodiMenu():
    from modules.control import AddonTitle, SelectDialog, execute
    my_options = ['FileManager', 'AddonBrowser', 'InterfaceSettings', 'SystemSettings', 'ShowSettings', 'SkinSettings', 'ShowSystemInfo', '[[B] Close [/B]]']
    selectList = []
    for Item in my_options:
        selectList.append("[COLOR=%s]%s[/COLOR]" % (CustomColor, Item))
    mychoice = SelectDialog(AddonTitle, selectList, key=False)
    # mychoice = mychoice.replace('[/COLOR]', '')
    if mychoice == '[COLOR=%s]FileManager[/COLOR]' % (CustomColor):
        execute("ActivateWindow(10003)")
    elif mychoice == '[COLOR=%s]AddonBrowser[/COLOR]' % (CustomColor):
        execute("ActivateWindow(10040)")
    elif mychoice == '[COLOR=%s]InterfaceSettings[/COLOR]' % (CustomColor):
        execute("ActivateWindow(10032)")
    elif mychoice == '[COLOR=%s]SystemSettings[/COLOR]' % (CustomColor):
        execute("ActivateWindow(10016)")
    elif mychoice == '[COLOR=%s]ShowSettings[/COLOR]' % (CustomColor):
        execute("ActivateWindow(10004)")
    elif mychoice == '[COLOR=%s]SkinSettings[/COLOR]' % (CustomColor):
        execute("ActivateWindow(10035)")
    elif mychoice == '[COLOR=%s]ShowSystemInfo[/COLOR]' % (CustomColor):
        execute("ActivateWindow(10007)")
    elif mychoice == '[COLOR=%s][[B] Close [/B]][/COLOR]' % (CustomColor):
        return


def kodiDbMenu():
    from modules.control import AddonTitle, SelectDialog, execute
    my_options = ['CleanPlaylist', 'UpdateVideoDB', 'CleanVideoDB', 'UpdateMusicDB', 'CleanMusicDB', '[[B] Close [/B]]']
    selectList = []
    for Item in my_options:
        selectList.append("[COLOR=%s]%s[/COLOR]" % (CustomColor, Item))
    mychoice = SelectDialog(AddonTitle, selectList, key=False)
    # mychoice = mychoice.replace('[/COLOR]', '')
    if mychoice == '[COLOR=%s]CleanPlaylist[/COLOR]' % (CustomColor):
        execute("Playlist.Clear")
    elif mychoice == '[COLOR=%s]UpdateVideoDB[/COLOR]' % (CustomColor):
        execute("UpdateLibrary(video)")
    elif mychoice == '[COLOR=%s]CleanVideoDB[/COLOR]' % (CustomColor):
        execute("CleanLibrary(video)")
    elif mychoice == '[COLOR=%s]UpdateMusicDB[/COLOR]' % (CustomColor):
        execute("UpdateLibrary(music)")
    elif mychoice == '[COLOR=%s]CleanMusicDB[/COLOR]' % (CustomColor):
        execute("CleanLibrary(music)")
    elif mychoice == '[COLOR=%s][[B] Close [/B]][/COLOR]' % (CustomColor):
        return
