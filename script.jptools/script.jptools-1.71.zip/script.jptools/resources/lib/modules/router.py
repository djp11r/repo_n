# -*- coding: utf-8 -*-
import sys
from urllib.parse import parse_qsl

from modules.control import log, addontitle, colorchoice, forceclose, getchangelog, getviewtype, infodialog, inputdialog, \
    kodi_version, okdialog, opensettings, selectdialog, yesnodialog
from modules.default import actlogmenu, advancedsettingsmenu, applist, builds, kodidbmenu, kodimenu, extra_menu, main_menu, \
    maintenance, local_menu, tools, utilities
from modules.dns_leak_test import dns_leak_test
from modules.maintenance import clean_myvideos_db, clearcache, purgepackages, thumb_cleaner
from modules.testing_mod import test
from modules.toolz import appinstaller, autoupdatetoggle_system, builditems, current_profile, enable_addons, forceupdatecheck, \
    getinfo, netinfo, reloadmyskin, reloadprofile, resetresolverscache, swapus
from modules.traktit import clane_adondata, dl_zip_smb, errorchecking, get_adon_frm_smb, \
    get_userdata, myinstall, reset_upd_setting, get_send_files_smb, send_kodi_log_smb, skin_backup_restore, ytdl, zipextr
from modules.upd_yt_api import set_api
from modules.utilz import broken_repos, broken_sources, clean_log_file, nested_file_delete, viewlog
from modules.wiz import backup, buildinstaller, fix_special, freshstart, remove_empty_folders, restorefolder, skinswap
from modules.speedtest import fast_com


def routing():
    # params = dict(parse_qsl(sys.argv[2].replace('?','')))
    params = dict(parse_qsl(sys.argv[2][1:], keep_blank_values=True))
    # log(f'routing params>>>> {params}')
    _get = params.get
    action = _get('action')

    if action is None: main_menu()
    elif action == 'maintenance': maintenance()
    elif action == 'tools': tools()
    elif action == 'utilities': utilities()
    elif action == 'builds': builds()
    elif action == 'wizsettings': opensettings(query='3.1')
    elif action == 'settings': opensettings()
    elif action == 'local_menu': local_menu()
    elif action == 'applist_m': applist()
    elif action == 'dl_apk_file': dl_zip_smb(_get('url'))
    elif action == 'send_setting_smb': get_send_files_smb(True)
    elif action == 'get_setting_smb': get_send_files_smb()
    elif action == 'send_kodi_log_smb': send_kodi_log_smb()
    elif action == 'clean_bineryfile': nested_file_delete()
    elif action == 'testtingd': url = test()
    elif action == 'colorchoice': colorchoice()
    elif action == 'viewtypes': getviewtype()
    elif action == 'changelog': getchangelog()
    elif action == 'log_tools': actlogmenu()
    elif action == 'clear_all':
        clearcache()
        purgepackages()
        thumb_cleaner()
    elif action == 'deletecache': clearcache()
    elif action == 'deletepackages': purgepackages()
    elif action == 'clearthumb': thumb_cleaner()
    elif action == 'clean_myvideos_db': clean_myvideos_db()
    elif action == 'reset_resolverscache': resetresolverscache()
    elif action == 'clearemptyfolders': remove_empty_folders()
    elif action == 'advancedsettings': advancedsettingsmenu()
    elif action == 'checksources': broken_sources()
    elif action == 'checkrepos': broken_repos()
    elif action == 'forceupdate': forceupdatecheck()
    elif action == 'enableaddons': enable_addons()
    elif action == 'enableunknownsources': swapus()
    elif action == 'force_close': forceclose()
    elif action == 'skinswap': skinswap()
    elif action == 'disableautoupdates': autoupdatetoggle_system()
    elif action == 'kodishortz': kodimenu()
    elif action == 'kodidbshortz': kodidbmenu()
    elif action == 'speedtest': result = fast_com()
    elif action == 'getkodiversion': infodialog(f'Kodi Version:[B] {kodi_version} [/B]')
    elif action == 'checkCurrentProfile':
        userName = current_profile()
        testitem = f'Current Profile: {userName}'
        infodialog(testitem)
    elif action == 'backup_restore':
        typeofbackup = ['BACKUP', 'RESTORE']
        s_type = selectdialog('Select Option', typeofbackup)
        if s_type == 0:
            modes = ['Full Backup', 'UserData Backup']
            select = selectdialog('Select Option', modes)
            if select == 0:
                backup(mode='full')
            elif select == 1:
                backup(mode='userdata')
        elif s_type == 1:
            restorefolder()
    elif action == 'reloadmyskin':
        if yesnodialog(addontitle, 'Are you sure you want to Reload Skin?'):
            reloadmyskin()
    elif action == 'reloadprofile':
        if yesnodialog(addontitle, 'Are you sure you want to Reload Profile?'):
            reloadprofile(getinfo('System.ProfileName'))
    elif action == 'fresh_start':
        if yesnodialog(addontitle, 'Are you sure you want to perform a Fresh Start?'):
            okdialog(addontitle, 'First gotta switch the skin to the default... Confluence or Estuary...')
            skinswap()
            freshstart()
    elif action == 'install_build':
        if yesnodialog(addontitle, 'Are you sure you want to Install this Build?'):
            skinswap()
            if yesnodialog(addontitle, 'Do you want to perform a Fresh Start before Installing your Build?'):
                freshstart(mode='silent')
            buildinstaller(_get('url'))

    elif action == 'extra_menu': extra_menu()
    elif action == 'netinfo': netinfo()
    elif action == 'myinstall': myinstall(_get('name'), _get('url'))
    elif action == 'appinstall': appinstaller(_get('name'), _get('url'))
    elif action == 'kodiappinstall': builditems()
    elif action == 'ytdl':
        url = inputdialog('Add Youtube URL')
        # log(f'url:{url}')
        ytdl(url)
    elif action == 'resolveurl_link_tester':
        from modules.control import resolveurl_link_tester
        url = inputdialog('Add URL to Test in resolvurl')
        # log(f'url:{url}')
        resolveurl_link_tester(url)
    elif action == 'get_adon_frm_smb': get_adon_frm_smb()
    elif action == 'viewlog': viewlog()
    elif action == 'reset_upd_setting': reset_upd_setting()
    elif action == 'skin_backup': skin_backup_restore(True)
    elif action == 'errorchecking': errorchecking()
    elif action == 'fix_special': fix_special()
    elif action == 'zipextr': zipextr()
    elif action == 'get_userdata': get_userdata()
    elif action == 'dns_leak_test': dns_leak_test()
    elif action == 'set_api': set_api()
    elif action == 'deleteold_Thumbnails': thumb_cleaner()
    elif action == 'clane_adondata': clane_adondata()
    elif action == 'clean_log_file': clean_log_file()
    elif action == 'clean_all_log_file': clean_log_file(True)