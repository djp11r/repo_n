# -*- coding: UTF-8 -*-

import glob
import re
import shutil
import sys
import time
import sqlite3
from os import remove, unlink, walk
from random import choice
from traceback import format_exc, print_stack
import requests
from modules.pastebin import pastebinapi
from modules.textviewer import get_txt_win
from modules.control import getsetting, addontitle, addonpath, databasepath, selectdialog, delete_file, okdialog, yesnodialog, dpro, existspath, infodialog, joinpath, listdir, log, logpath, transpath, yesnodialog, read_file


def db_connect(db_file):
    try:
        dbcon = sqlite3.connect(db_file, isolation_level=None, check_same_thread=False)
        dbcon.execute('''PRAGMA synchronous = OFF''')
        dbcon.execute('''PRAGMA journal_mode = OFF''')
        return dbcon
    except:
        log(f'Error db_connect:  {print_stack()}')
        return False

def db_close(dbcon):
    try:
        dbcon.commit()
        dbcon.execute('VACUUM')
    except:
        log(f'Error db_close:  {print_stack()}')
        dbcon.execute('VACUUM')
        dbcon.commit()
        dbcon.execute('VACUUM')
    finally:
        try: dbcon.close()
        except: pass
    return

def find_new_db(pattern):
    result = []
    for root, dirs, files in walk(databasepath):
        for name in files:
            if pattern in name and name.endswith('.db'):
                result.append(joinpath(root, name))
    return result

def open_url(url, headers=None, output='', timeout='30'):
    lheaders = {'User-Agent': u_agent(), 'Accept': '*/*', 'Accept-Encoding': 'identity;q=1, *;q=0', 'Accept-Language': 'en-US,en;q=0.5', 'Connection': 'keep-alive', 'Pragma': 'no-cache', 'Cache-Control': 'no-cache', 'DNT': '1'}

    if headers: lheaders |= headers
    try:
        try: response = requests.get(url, headers=lheaders, timeout=int(timeout))  # log(f'{response.headers}\n {response.request.headers}')
        except requests.exceptions.SSLError: response = requests.get(url, headers=lheaders, verify=False)
    except requests.exceptions.ConnectionError:
        log(f'open_url url: {url} Error: {format_exc()}')
        return
    if '200' in str(response.status_code): return response
    elif 'Retry-After' in response.headers:
        timeout = response.headers['Retry-After']
        time.sleep(int(timeout) + 1)
        return open_url(url, lheaders)


def u_agent():
    return choice(['Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36',
                   'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36',
                   'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36',
                   'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36'])


def workingurl(url):
    if url == 'http://': return False
    try: response = requests.get(url, timeout=30)
    except: log(f'open_url url: {url} Error: {format_exc()}')
    # log(f'open_url url: {url} response: {response}')
    return '200' in str(response)


def delete_crash_logs(mode='verbose'):
    crashfiles = list(glob.glob(joinpath(logpath, '*crashlog*.*')))
    tracefiles = list(glob.glob(joinpath(logpath, '*stacktrace*.*')))
    totalfiles = len(crashfiles) + len(tracefiles)
    if totalfiles > 0:
        if mode == 'verbose' and not yesnodialog(addontitle, f'Would you like to delete the Crash logs? Files Found: {totalfiles}', ):
            return
        if not crashfiles and not tracefiles and mode == 'verbose': infodialog('Clear Crash Logs: Clear Crash Logs Cancelled')
        elif crashfiles or tracefiles:
            for f in crashfiles:
                delete_file(f)
            for f in tracefiles:
                delete_file(f)
    elif mode == 'verbose': infodialog('Clear Crash Logs: No Crash Logs Found')


def delete_debuglogs():
    debuglogfiles = list(glob.glob(joinpath(logpath, '*.*log*')))
    totalfiles = len(debuglogfiles)
    if totalfiles > 0:
        if yes := yesnodialog(addontitle, f'Would you like to delete the Debug Logs?\n{totalfiles} Files Found', ):
            if debuglogfiles:
                for f in debuglogfiles:
                    if 'kodi.log' not in f: remove(f)
            infodialog(f'Clear Debug Logs: {totalfiles} Removed.')
            log(f'Clear Debug Logs: {totalfiles} Removed.')
        else:
            infodialog('Clear Debug Logs: Cancelled.')
            log('Clear Debug Logs: Cancelled.')
    else:
        infodialog('Clear Debug Logs: No Debug Logs Found.')
        log('Clear Debug Logs: No Debug Logs Found.')

# Literal replacements → single-pass C-optimized translation
REPLACEMENTS = {'ERROR':   '[COLOR red]ERROR[/COLOR]:', 'WARNING': '[COLOR gold]WARNING[/COLOR]:',}
# Build a single regex that matches any replacement key
REPLACEMENT_RE = re.compile("|".join(map(re.escape, REPLACEMENTS.keys())))

def apply_replacements(line: str) -> str:
    """Fast multi-token replacement using a single regex pass."""
    return REPLACEMENT_RE.sub(lambda m: REPLACEMENTS[m.group(0)], line)

# Fast prefix matcher (no MULTILINE, no ^ anchor, minimal backtracking)
LOG_PREFIX_RE = re.compile(    r"\s*\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\.\d+\s+T:\d+\s+")

def strip_log_prefix(line: str) -> str:
    """Strip timestamp/thread prefix using match() + zero-copy slicing."""
    m = LOG_PREFIX_RE.match(line)
    if m:
        return line[m.end():]
    return line


def errorlist(logtext):
    # b = logtext.replace('\n', '[CR]').replace('\r', '')
    # match = re.compile(r'-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--').findall(logtext)
    match = re.compile(r'-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--', flags=re.DOTALL | re.IGNORECASE).findall(logtext)
    return list(match)

def errorchecking():
    log_file = joinpath(logpath, 'kodi.log')
    if existspath(log_file):
        # log(f'[@@@ errorchecking: ] logsfound:\n {log_file}')
        contents = read_file(log_file)
        error1 = errorlist(contents)
        i = 0
        if len(error1) > 0:
            string = ''
            for item in error1:
                i += 1
                string += f'[COLOR red]ERROR NUMBER {i}:[/COLOR]{item.replace("                                        ", "")}\n'
            if i > 0: get_txt_win(string, 'All Errors')
        if len(error1) == 0 or i == 0:
            infodialog(f'[COLOR green]There is : {len(error1)} Error[/COLOR][CR][COLOR red]In Kodi Log![/COLOR]', time=2000)

def truncate_log_file(lfile=None, only_error=False):
    sendback = True
    if not lfile:
        lfile = joinpath(logpath, 'kodi.log')
        sendback = False
    with open(lfile, 'r', encoding='utf-8', errors='ignore') as f:
        Lines = f.readlines()
    # Slice the parts you want
    head = Lines[:24]          # first 24 lines
    tail = Lines[100:]         # line 350 → end (0‑indexed)
    total_line = len(Lines)
    log(f'total_line: {total_line}')
    if total_line >= 440: tail = Lines[440:]
    if total_line >= 335: tail = Lines[335:]
    if total_line >= 800: tail = Lines[(total_line // 2):]
    # elif total_line >= 200: tail = Lines[200:]
        # log(f'Lines: {len(Lines)} {repr(Lines)}')
    path_regex = re.compile(r'Users\\+(\w+)|Users%5c(\w+)%5c', re.IGNORECASE)
    kept = head + tail
    result = []
    r_append = result.append
    for line in kept:
        line = strip_log_prefix(line)
        line = apply_replacements(line)
        r_append(line)
    log(f'result: {len(result)} {type(result)}')
    result = ' '.join(result)
    result = path_regex.sub(r'special://', result)
    if only_error:
        with open(lfile, 'w', encoding='utf-8', errors='ignore') as r: r.writelines(result)
    with open(lfile, 'w', encoding='utf-8', errors='ignore') as r:
        r.writelines(result)
    if sendback: return result
    return

def get_logfilepath():
    logPaths, logNames = [], []
    dirs, files = listdir(logpath)
    for item in files:
        if item.endswith('.log'):
            logNames.append(item)
            logPaths.append(joinpath(logpath, item))
    return logPaths, logNames

def get_log_data(only_error=False):
    logPaths, logNames = get_logfilepath()
    selectLog = selectdialog(logNames, 'Select log file to View')
    if selectLog == -1: return
    selectedLog = logPaths[selectLog]
    # log(f'selectLog {repr(selectLog)} selectedLog {repr(selectedLog)} logPaths: {logPaths}')
    contents = truncate_log_file(selectedLog, only_error)
    return contents if contents else ''

def send_kodi_log_smb():
    from modules.get_smb_service import dl_zip_smb
    smb_path = getsetting('smb_path')
    if not smb_path: infodialog('Can not find smb.'); return
    truncate_log_file()
    log_file = joinpath(logpath, 'kodi.log')
    dl_zip_smb(log_file, joinpath(smb_path, 'kodi.log'))
    infodialog('send kodi.log file to smb.')

def clean_log_file(all_logs=False):
    logPaths, logNames = get_logfilepath()
    if not all_logs:
        selectLog = selectdialog(logNames, 'Select log file to View')
        if selectLog == -1: return
        selectedLog = logPaths[selectLog]
        with open(selectedLog, 'w', errors='ignore') as logFile:
            logFile.write('')
        infodialog(f'Clear Log File: {logNames[selectLog]}')
    else:
        for selectedLog in logPaths:
            with open(selectedLog, 'w', errors='ignore') as logFile:
                logFile.write('')
        infodialog(f'Clear Log File: {logNames}')
    return

def upload_log():
    data = get_log_data()
    if data == '': infodialog('Log File is Emtpy.')
    else:
        session = requests.Session()
        UserAgent = 'JP Tools'
        try:
            url = 'https://paste.kodi.tv/'
            response = session.post(f'{url}documents', data=data.encode('utf-8', errors='ignore'), headers={'User-Agent': UserAgent})
            # log(f'log_response: {response}')
            if 'key' in response.json():
                result = url + response.json()['key']
                msg = f'Your log file was uploaded to:[CR][CR]    {result}'
                log(f'log_upload_url: {result}')
                okdialog(msg)
            elif 'message' in response.json():
                infodialog(f'Log upload failed: {response.json()["message"]}')
                log(f'log_upload_msg: {response.json()["message"]}')
            else:
                infodialog('Log upload failed')
                log(f'log_error: {response.text}')
        except:
            infodialog('Unable to retrieve the paste url')
            log(f'upload_log fail: {format_exc()}')

def viewlog():
    text = get_log_data()
    get_txt_win(text)

def logview():
    modes = ['View Log', 'Upload Log (Pastebin)', 'Upload Log (paste.kodi.tv)']
    select = selectdialog(modes, 'Select log file Option...')
    try:
        if select == -1: raise Exception()
        if select == 0:
            viewlog()
        elif select == 1:
            contents = get_log_data()
            upload_Link = pastebinapi().paste(contents)
            log(f'LOGVIEW UPLOADED LINK: {upload_Link}')
            if upload_Link is None: okdialog('Cannot Upload Log to Pastebin', '')
            elif 'Error' not in upload_Link:
                label = f'Log Link: [COLOR purple] {upload_Link} [/COLOR]'
                okdialog(f'Log Uploaded to Pastebin:\n{label}')
            else: okdialog('Cannot Upload Log to Pastebin', f'Reason {upload_Link}')
        elif select == 2: upload_log()
    except: log(f'logView Error: {format_exc()}')


def broken_sources():
    SOURCES_FILE = transpath('special://home/userdata/sources.xml')
    if not existspath(SOURCES_FILE):
        okdialog('Error: It appears you do not currently have a sources.xml file on your system. We are unable to perform this test.')
        sys.exit()
    dp = dpro()
    dp.create(addontitle, 'Testing Internet Connection...')
    try: requests.get('http://www.google.com')
    except:
        okdialog('Error: It appears you do not currently have an active internet connection. This will cause false positives in the test. Please try again with an active internet connection.')
        sys.exit()
    found = 0
    passed = 0
    dp.update(0, 'Checking Sources...')
    a = open(SOURCES_FILE, errors='ignore').read()
    b = a.replace('\n', 'U').replace('\r', 'F')
    match = re.compile(r'<source>(.+?)</source>').findall(str(b))
    counter = 0
    line = 'Checking: %s Alive: %s Dead: %s'
    for item in match:
        name = re.compile(r'<name>(.+?)</name>').findall(item)[0]
        checker = re.compile(r'<path pathversion="1">(.+?)</path>').findall(item)[0]
        if 'http' in str(checker):
            # dp.update(0, '', 'Checking: '+name, '')
            try: checkme = requests.get(checker, timeout=30)
            except: checkme = 'null'
            try:
                error_out = 0
                if 'this does not matter its just a test' not in f'{checkme.text}': error_out = 0
            except: error_out = 1
            if error_out == 0:
                if '.zip' not in f'{checkme.text}' and 'repo' not in f'{checkme.text}':
                    choice = yesnodialog('Error conecting to the following: ', f'Source Name: {name} \nSource URL: {checker}\nWould you like to remove this source now?')
                    counter += 1
                    if choice == 1:
                        found = 1
                        h = open(SOURCES_FILE, errors='ignore').read()
                        i = h.replace('\n', 'U').replace('\r', 'F')
                        j = i.replace(str(item), '')
                        k = j.replace('U', '\n').replace('F', '\r')
                        l = k.replace('<source></source>', '').replace('        \n', '')
                        with open(SOURCES_FILE, mode='w', errors='ignore') as f:
                            f.write(l)
                else: passed += 1
            else:
                choice = yesnodialog('Error conecting to the following: ', f'Source Name: {name} \nSource URL: {checker} \nWould you like to remove this source now?')
                counter += 1
                if choice == 1:
                    found = 1
                    h = open(SOURCES_FILE, errors='ignore').read()
                    i = h.replace('\n', 'U').replace('\r', 'F')
                    j = i.replace(str(item), '')
                    k = j.replace('U', '\n').replace('F', '\r')
                    l = k.replace('<source></source>', '').replace('        \n', '')
                    with open(SOURCES_FILE, mode='w', errors='ignore') as f:
                        f.write(l)
                else: passed += 1
            if dp.iscanceled():
                okdialog('The source check was cancelled')
                dp.close()
                sys.exit()
            dp.update(0, line % (name, str(passed), str(counter)))
            dp.close()
    okdialog(f'We have checked your sources and found:\nWORKING SOURCES: {passed} \nDEAD SOURCES: {counter}')


def broken_repos():
    dp = dpro()
    dp.create(addontitle, 'Testing Internet Connection...')
    try: requests.get('http://www.google.com')
    except:
        dp.close()
        okdialog('Error: It appears you do not currently have an active internet connection. This will cause false positives in the test. Please try again with an active internet connection.')
        sys.exit()
    passed = 0
    failed = 0
    HOMEPATH = transpath('special://home/addons/')
    line = 'We are currently checking: %s Alive: %s Dead: %s'
    dp.update(0, '')
    url = HOMEPATH
    for root, dirs, files in walk(url):
        for file in files:
            if file == 'addon.xml':
                with open(joinpath(root, file), encoding='utf8', errors='ignore') as f:
                    a = f.read()
                if 'info compressed=' in str(a):
                    match = re.compile(r'<info compressed="false">(.+?)</info>').findall(a)
                    for checker in match:
                        # dp.update(0, '', checker, '')
                        try:
                            open_url(checker, timeout='30')
                            passed += 1
                        except:
                            try: checkme = requests.get(checker, timeout=30)
                            except: pass
                            try:
                                error_out = 0
                                if 'this does not matter its just a test' not in f'{checkme.text}':
                                    error_out = 0
                            except: error_out = 1
                            if error_out == 0:
                                if 'addon id=' not in f'{checkme.text}':
                                    failed += 1
                                    match = re.compile(r'<addon id="(.+?)".+?ame="(.+?)" version').findall(a)
                                    for repo_id, repo_name in match:
                                        default_path = transpath('special://home/addons/')
                                        file_path = transpath(file)
                                        full_path = default_path + repo_id
                                        choice = yesnodialog(f'The {repo_name} appears to be broken. We attempted to connect to the repo but it was unsuccessful.\nTo remove this repository please click YES')
                                        if choice == 1:
                                            try: shutil.rmtree(full_path)
                                            except: okdialog(f'Sorry we were unable to remove {repo_name}')
                                else: passed += 1
                            else:
                                failed += 1
                                match = re.compile(r'<addon id="(.+?)".+?ame="(.+?)" version').findall(a)
                                for repo_id, repo_name in match:
                                    default_path = transpath('special://home/addons/')
                                    file_path = transpath(file)
                                    full_path = default_path + repo_id
                                    choice = yesnodialog(f'The {repo_name} appears to be broken. We attempted to connect to the repo but it was unsuccessful.\nTo remove this repository please click YES')
                                    if choice == 1:
                                        try: shutil.rmtree(full_path)
                                        except: okdialog(f'Sorry we were unable to remove {repo_name}')
                        if dp.iscanceled():
                            okdialog('The repository check was cancelled')
                            dp.close()
                            sys.exit()
                        dp.update(0, line % (checker, str(passed), str(failed)))
    dp.close()
    okdialog(f'We have checked your repositories and found:\nWorking Repositories: {passed}\nDead Repositories: {failed}')


# Checks if a directory exists (Do not use for files)
def dir_exists(dirpath):
    import xbmcvfs
    directoryPath = dirpath
    # The xbmcvfs exists interface require that directories end in a slash
    # It used to be OK not to have the slash in Gotham, but it is now required
    if (not directoryPath.endswith('/')) and (not directoryPath.endswith('\\')):
        dirSep = '\\' if '\\' in directoryPath else '/'
        directoryPath = f'{directoryPath}{dirSep}'
    return xbmcvfs.exists(directoryPath)


# Splits a path the same way as os.path.split but supports paths of a different
# OS than that being run on
def os_path_split(fullpath):
    # Check if it ends in a slash
    if fullpath.endswith('/') or fullpath.endswith('\\'): fullpath = fullpath[:-1]  # Remove the slash character

    try: slash1 = fullpath.rindex('/')
    except: slash1 = -1

    try: slash2 = fullpath.rindex('\\')
    except: slash2 = -1

    # Parse based on the last type of slash in the string
    return fullpath.rsplit('/', 1) if slash1 > slash2 else fullpath.rsplit('\\', 1)


# There has been problems with calling join with non ascii characters,
# so we have this method to try and do the conversion for us
def os_path_join(dir, file):
    # Check if it ends in a slash
    if dir.endswith('/') or dir.endswith('\\'): dir = dir[:-1]  # Remove the slash character

    # Convert each argument - if an error, then it will use the default value
    # that was passed in
    try: dir = dir.decode('utf-8')
    except: pass
    try: file = file.decode('utf-8')
    except: pass
    return joinpath(dir, file)


# Performs a nested copy of one directory to another
def nestedcopy(rootSourceDir, rootTargetDir):
    import xbmcvfs
    log(f'nestedCopy: Copy {rootSourceDir} to {rootTargetDir}')

    # Make sure the target directory exists
    xbmcvfs.mkdirs(rootTargetDir)

    dirs, files = xbmcvfs.listdir(rootSourceDir)

    for file in files:
        try: file = file.decode('utf-8')
        except: pass
        sourceFile = f'{rootSourceDir}{file}'
        targetFile = f'{rootTargetDir}{file}'
        log(f'nestedCopy: Copy file {sourceFile} to {targetFile}')
        xbmcvfs.copy(sourceFile, targetFile)

    for adir in dirs:
        try: adir = adir.decode('utf-8')
        except: pass
        sourceDir = f'{rootSourceDir}{adir}/'
        targetDir = f'{rootTargetDir}{adir}/'
        log(f'nestedCopy: Copy directory {sourceDir} to {targetDir}')
        nestedcopy(sourceDir, targetDir)


def nesteddelete(rootDir):
    import xbmcvfs
    # If the file already exists, delete it
    if dir_exists(rootDir):
        # Remove the png files in the directory first
        dirs, files = xbmcvfs.listdir(rootDir)
        # Remove nested directories first
        for adir in dirs:
            nesteddelete(os_path_join(rootDir, adir))
        # If there are any nested files remove them
        for aFile in files:
            xbmcvfs.delete(os_path_join(rootDir, aFile))
        # Now remove the actual directory
        xbmcvfs.rmdir(rootDir)
    else: log(f'nestedDelete: Directory {rootDir} does not exist')


def nested_file_delete(purgePath=None):
    # If the file already exists, delete it
    if not purgePath: purgePath = transpath('special://home/addons/')
    if (not purgePath.endswith('/')) and (not purgePath.endswith('\\')):
        dirSep = '\\' if '\\' in purgePath else '/'
        purgePath = f'{purgePath}{dirSep}'
    if existspath(purgePath):
        # log(f'purgePath: {purgePath}')
        total_files = 0
        for root, dirs, files in walk(purgePath):
            files = [file for file in files if file.endswith('.pyc')]
            # log(f'files: {len(files)} : {files}')
            for aFile in files:
                remove_file = joinpath(root, aFile)
                delete_file(remove_file)
                total_files += 1
                # log(f'aFile: {remove_file}')
        infodialog(f'total files removed: {total_files}')
    else: log(f'nestedDelete: Directory {purgePath} does not exist')