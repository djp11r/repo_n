# -*- coding: utf-8 -*-
import re
from platform import machine
from traceback import format_exc

from modules.control import addon, addonicon, addonid, addontitle, auto_click_yes, busy, color1, color2, condvisibility, databasepath, dpro, excludes_addons, execute, existspath, forceclose, get_soup, getsetting, homepath, idle, infodialog, infolabel, item, joinpath, json_rpc_multi, jsonrpc, listdir, log, monitor, packages, platform, platform, selectdialog, sleep, transpath, yesnodialog
from modules.textviewer import get_txt_win
from modules.utilz import db_connect, open_url, workingurl

build_opt = {'nightlies': 'Unstable (Daily builds).', 'releases': 'Stable (Final releases).', 'snapshots': 'Semi-stable (Monthly builds).', 'test-builds': 'Experimental (Debugging builds).'}
base_url = 'http://mirrors.kodi.tv/'


def folder_size(dirname=None):
    import os
    if not dirname: dirname = homepath
    finalsize = 0
    for dirpath, dirnames, filenames in os.walk(dirname):
        for f in filenames:
            fp = joinpath(dirpath, f)
            try: finalsize += os.path.getsize(fp)
            except: pass
    return human_size(finalsize)


def human_size(byte_s, units=None):
    """ Returns a human-readable reprentation of bytes and unit """
    if units is None: units = [' bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB']
    return (byte_s, units[0]) if byte_s < 1024 else human_size(byte_s >> 10, units[1:])


def dialogwatch():
    x = 0
    while not condvisibility('Window.isVisible(yesnodialog)') and x < 100:
        x += 1
        sleep(100)
    if condvisibility('Window.isVisible(yesnodialog)'): execute('SendClick(11)')
    else: execute('SendClick(11)')
    # if condvisibility('Window.IsTopMost(warningdialog)'): execute('SendClick(warningdialog, 11)')


def swapus(silence=True):
    # data =jsonrpc({"method": "Settings.GetSettingValue", "params": {"setting": "locale.timezone"}, "id": 1})
    # log(f'1 locale.timezone data: {data}')
    data =jsonrpc({"method": "Settings.GetSettingValue", "params": {"setting": "addons.unknownsources"}, "id": 1})
    # log(f'1 addons.unknownsources data: {data}')
    if data and not data[0].get('result').get('value'):
        sleep(50)
        auto_click_yes()
        data =jsonrpc({"method": "Settings.SetSettingValue", "params": {"setting": "addons.unknownsources", "value": True}, "id": 1})
        # data =jsonrpc({"method": "Input.ExecuteAction", "params": { "action": "tap"}, "id": 1})
        log(f'addons.unknownsources data: {data}')
        # auto_click_yes()
        infodialog('Unknown Sources: Enabled.')
    if silence: infodialog('Unknown Sources: Already Enabled.')
    return


def autoupdatetoggle_system(silence=False):
    #Sets system-wide auto-update.  Change the "value" number for desired action
    # 0-auto-update, 1 -notify of updates, 2-disable auto updates.
    list_param = [
    {"setting": "addons.updatemode", "value": 1},
    {"setting": "filelists.showhidden", "value": True},
    {"setting": "filelists.allowfiledeletion", "value": True},
    {"setting": "smb.minprotocol", "value": 1},
    {"setting": "epg.pastdaystodisplay", "value": 0},
    {"setting": "epg.futuredaystodisplay", "value": 1},
    {"setting": "epg.selectaction", "value": 1},
    {"setting": "epg.epgupdate", "value": 2880},
    {"setting": "epg.preventupdateswhileplayingtv", "value": True}]
    json_rpc_multi("Settings.SetSettingValue", list_param)
    if getsetting('skin_restore') != 'false':
        jsonrpc({"method": "Settings.SetSettingValue", "params": {"setting": "general.addonupdates", "value": 1}, "id": 1})
        jsonrpc({"method": "Settings.SetSettingValue", "params": {"setting": "general.addonnotifications", "value": True}, "id": 1})
    if condvisibility('System.HasAddon(skin.aeon.nox.silvo)'):
        log(f'autoupdatetoggle_system: HasAddon(skin.aeon.nox.silvo): True')
        try:
            auto_click_yes()
            jsonrpc({"method": "Settings.SetSettingValue", "params": {"setting": "lookandfeel.skin", "value": "skin.aeon.nox.silvo"}, "id": 1})
            auto_click_yes()
            execute('Skin.SetBool(centermainmenu)')
            execute('Skin.SetBool(centeredinfoline)')
            execute('Skin.SetBool(enable.visiblesubmenu)')
            execute('Skin.SetBool(askeddefaultbackground)')
            execute('Skin.SetString(customdefaultbackground.path, "special://skin/extras/backgrounds/default_livecases.jpg")')
            # execute('SetGUILanguage(resource.language.en_en)')
        except: log(f'Error autoupdatetoggle_system: {format_exc()}')
    swapus(silence) # enable unknownsources
    return

def autoupdatetoggle_addon():
    #The Addons33.db has a table called blacklist.  These are the addonIDs that you won't get auto-updated.
    #Couldn't figure out how to automatically set a unique ID for the table, so I just set I set the first value(ID) to 100
    addons_dbfile = joinpath(databasepath, 'Addons33.db')
    dbcon = db_connect(addons_dbfile)
    ##Enable disable toggle could go below instead of (un)commenting below code.
    ##To Add to do not auto update list
    dbcon.execute('INSERT INTO blacklist Values (?,?)', ('100', 'plugin.video.exodusredux'))
    dbcon.commit()  ##To Remove from do not auto update list  # dbcur.execute("DELETE FROM blacklist WHERE addonID = 'plugin.video.exodusredux'")  #dbcon.commit()
    dbcon.close()

def forceupdatecheck():
    busy()
    execute('UpdateAddonRepos')
    execute('UpdateLocalAddons')
    idle()
    infodialog('Checking for Updates...')


def enable_addon(addon_name=addonid):
    try: jsonrpc({"jsonrpc": "2.0", "method": "Addons.SetAddonEnabled", "params": {"addonid": f"{addon_name}", "enabled": True}, "id": 1})
    except: log(f'Error: {format_exc()}')


def enable_addons():
    home_addons = transpath('special://home/addons')
    if addons_list := listdir(home_addons):
        for addon_name in addons_list[0]:
            if all(value not in addon_name for value in excludes_addons):
                # log("enabled addon_name: %s" % (addon_name))
                enable_addon(addon_name)

def current_profile():
    return infolabel('System.ProfileName')

def getinfo(label):
    try: return infolabel(label)
    except: return False

def net_info():
    infolabel = ['Network.IPAddress', 'Network.MacAddress', 'Network.IsDHCP', 'Network.GatewayAddress', 'Network.DNS1Address']
    data = []
    for info in infolabel:
        temp = getinfo(info)
        y = 0
        while temp == 'Busy' and y < 10:
            temp = getinfo(info)
            y += 1
            # log(f'{info} sleep {str(y)}')
            sleep(200)
        data.append(temp)
    # log(f'[trakt data] data: {data}')
    netinfo = {'internal ip': data[0], 'MacAddress': data[1], 'IsDHCP': str(data[2]), 'gatewayaddress': data[3], 'dns1address': data[4], 'external ip': '', 'isp': '', 'city': '', 'country': '', 'state': ''}
    try:
        # url = f'http://ipwhois.app/json/{inter_ip}'
        # url = random.choice(['http://extreme-ip-lookup.com/json/', 'http://ip-api.com/json'])
        url = 'https://ipapi.co/json/'
        if req := open_url(url):
            geo = req.json()
            log(f'url: {url}\n geo: {geo} ')
            # netinfo.update({"external ip": geo['ip']})
            netinfo['isp'] = geo['org']
            netinfo['city'] = geo['city']
            netinfo['country'] = geo['country']
            netinfo['state'] = geo['region_code']
        # else:
        url = 'https://whatismyip.host/ip4'
        ip = open_url(url)
        # log(f'from whatismyip.host geo["ip"]: {ip.text}')
        netinfo['external ip'] = ip.text
    except Exception as e:
        log(f'[trakt data] error: {format_exc()} ')
    return netinfo

def netinfo():
    netinfo = net_info()
    # log(f'[trakt data] netinfo: {netinfo}')
    string = '\n'.join(f'{i:02d}: {item:<15}: {netinfo.get(f"{item}")}' for i, item in enumerate(netinfo, start=1))
    # textbox('--[ net info ]--', string)
    get_txt_win(string, '--[ net info ]--')

def get_platform_data():
    branchs = {20: 'nexus', 21: 'omega', 22: 'pegasus', }
    ver_query = {"jsonrpc": "2.0", "method": "Application.GetProperties", "params": {"properties": ["version"]}, "id": 1}
    machine_type = machine()
    myplatform = platform()
    build = jsonrpc(ver_query)[0]
    build = build.get('result', {}).get('version', {})
    branch = branchs[int(build.get('major', ''))]
    current_kodi_branch = '(%s.%s-%s)' % (build.get('major', ''), build.get('minor', ''), build.get('revision', ''))
    _url = base_url + '%s/android/%s/'
    if '64' in machine_type: thisplatform = 'arm64-v8a'
    elif '86' in machine_type: thisplatform = 'x86'
    else: thisplatform = 'arm'
    app_endswith = '.apk'
    if myplatform == 'windows':
        _url = base_url + '%s/windows/%s/'
        if '64' in machine_type: thisplatform = 'win64'
        elif '86' in machine_type: thisplatform = 'win32'
        else: thisplatform = ''
        app_endswith = '.exe'
    return {'url': _url, 'branch': branch, 'current_kodi_branch': current_kodi_branch, 'thisplatform': thisplatform, 'app_endswith': app_endswith, 'myplatform': myplatform}

def get_soup_items(soup):
    try:  #folders
        items = (soup.find_all('tr'))
        del items[0]
    except:  #files
        items = (soup.find_all('a'))
    return [x.get_text() for x in items if x.get_text() is not None]

def appinstaller(name, url):
    if not workingurl(url):
        infodialog('Error to get App file ...')
        return
    appname = url.split('/')[-1]
    thisplatform = platform()
    lib = joinpath(packages, appname)
    log(f'platform(): {thisplatform}\n appname: {appname} \nurl: {url}\nlib: {lib}')

    def download_apk():
        try:
            from modules.downloader import dl_call
            dp = dpro()
            dp.create(addontitle, f'[COLOR {color2}]Downloading:[/COLOR] [COLOR {color1}]{name}[/COLOR]')
            dl_call(url, lib, dp)
            sleep(500)
            dp.close()
        except: log(f'Error download_apk: {format_exc()}')

    if not existspath(lib): download_apk()
    if thisplatform in ['android', 'atv2', 'arm']:
        try:
            # log(f'ok i am android: {url} lib: {lib}')
            # SETTINGS_LOC = '/storage/emulated/0/download'
            use_manager = {0: 'com.android.documentsui', 1: packages}[1]
            log(f'Opening {lib} with {use_manager}')
            execute(f'StartAndroidActivity({use_manager},,,"content://{lib}")')
            infodialog(f'App {appname} has been install...')
        except: log(f'Error appinstaller: {format_exc()}')
    elif thisplatform in ['windows']:
        try:
            from subprocess import call
            # log(f'ok i am window: {url} lib: {lib}')
            execute('AlarmClock(shutdowntimer,XBMC.Quit(),2.0,true)')
            forceclose()
            call(lib, shell=True)
        except: log(f'Error appinstaller: {format_exc()}')
    infodialog(f'Its not android so can not install {appname} App file ...')
    return

def builditems():
    platform_data = get_platform_data()
    # log(f'platform_data: {platform_data}')
    # platform_data = {'url': 'http://mirrors.kodi.tv/%s/windows/%s/', 'branch': 'omega', 'current_kodi_branch': '(21.0-20230911-327fd81962)', 'thisplatform': 'win64', 'app_endswith': '.exe', 'myplatform': 'windows'}
    burl = platform_data['url']
    thisplatform = platform_data['thisplatform']
    branch = platform_data['branch']
    current_kodi_branch = platform_data['current_kodi_branch']
    app_endswith = platform_data['app_endswith']
    myplatform = platform_data['myplatform']

    def build_main():
        tmplst = []
        for label in sorted(build_opt.keys()):
            liz = item(label.title(), build_opt[label], path=burl % (label, thisplatform))
            liz.setArt({'poster': 'DefaultAddonProgram.png', 'icon': addonicon, 'thumb': addonicon})
            tmplst.append(liz)
        # select = selectdialog(tmplst)
        select = selectdialog(tmplst, 'select build to install...')
        if select is None: return
        return tmplst[select].getPath()
        # url = tmplst[select].getPath()

    def builditems(url):
        cacheresponce = open_url(url).text
        # log(f'url: {url} \ncacheresponce: {cacheresponce}')
        soup = get_soup(cacheresponce)
        if soup is None: return
        for i in get_soup_items(soup):
            # log(f'i: {i}')
            try:  #folders
                label, label2 = re.compile(r"(.*?)/-(.*)").match(i).groups()
                # log(f'folders label: {label} label2: {label2}')
                if label == thisplatform: label2 = 'current platform (%s)' % thisplatform
                elif label.lower() == branch.lower(): label2 = 'current kodi branch %s' % current_kodi_branch
                else: label2 = ''  #don't use time-stamp for folders
                # log(f'folders label2: {label2}')
                liz = item(label.title(), label2, path=(url + label))
                liz.setArt({'icon': addonicon, 'thumb': addonicon})
                yield liz
            except:  #files
                label, label2 = re.compile(r"(.*?)\s(.*)").match(i).groups()
                if app_endswith in label:
                    # log(f'files label: {label} label2: {label2}')
                    labels = label.split(app_endswith)
                    title = labels[0]
                    title1 = labels[1]
                    # log(f'files label title: {title} title1: {title1}')
                    liz = item(f'{title}{app_endswith}', '%s %s' % (title1, label2.replace('MiB', 'MB ').strip()), path=f'{url}{title}{app_endswith}')
                    liz.setArt({'icon': addonicon, 'thumb': addonicon})
                    yield liz

    def selectedpath(url, bypass=False):
        moni = monitor()
        while not moni.abortRequested():
            items = list(builditems(url))
            if len(items) == 0: break
            elif len(items) == 2 and not bypass and items[0].getLabel().lower() == 'parent directory' and not items[1].getLabel().startswith(app_endswith): select = 1  #if one folder bypass selection.
            else: select = selectdialog(items, url.replace(base_url, './').replace('//', '/'))
            if select is None: return  #return on cancel.
            label = items[select].getLabel()
            newurl = items[select].getPath()
            preurl = url.rsplit('/', 2)[0] + '/'
            if newurl.endswith(app_endswith):
                log(f'setlastpath label: {label}')
                if yesnodialog('Kodi install?', f'You are about to install Kodi[CR]{label}[CR]Would you like to continue?', yes='Yes, Close', no='No, Cancel'): return appinstaller(label, newurl)
                break
            elif label.lower() == 'parent directory' and myplatform in preurl.lower():
                return selectedpath(preurl, True)
            elif label.lower() == 'parent directory' and myplatform not in preurl.lower():
                return selectedpath(build_main(), False)
            url = newurl + '/'

    url = build_main()
    # log(f'url form build_main: {url}')
    # url = 'http://mirrors.kodi.tv/nightlies/windows/win64/'
    # url = 'http://mirrors.kodi.tv/nightlies/windows/win64/Omega/'
    # url = 'http://mirrors.kodi.tv/nightlies/windows/win64/master/'
    selectedpath(url)