# -*- coding: UTF-8 -*-

import os
import sys
import time
from datetime import date, datetime, timedelta, timezone
from json import dumps, loads
from traceback import format_exc
from urllib.parse import urlencode
from xml.dom.minidom import parse as mdParse

import unicodedata
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


def get_infolabel(label):
    return xbmc.getInfoLabel(label)

def addon_info(info):
    return xbmcaddon.Addon('script.jptools').getAddonInfo(info)

def addon(_id='script.jptools'):
    return xbmcaddon.Addon(id=_id)

kodi_version = int(get_infolabel('System.BuildVersion')[0:2])

def external():
    return 'jptools' not in get_infolabel('Container.PluginName')

def getsetting(id):
    return addon().getSetting(id)

joinpath = os.path.join

transpath = xbmcvfs.translatePath
deletefe = xbmcvfs.delete
makedirs = xbmcvfs.mkdirs
listdir = xbmcvfs.listdir
existspath = xbmcvfs.exists
execute = xbmc.executebuiltin
additem = xbmcplugin.addDirectoryItem
endofdirectory = xbmcplugin.endOfDirectory
dpro = xbmcgui.DialogProgress
monitor = xbmc.Monitor
player = xbmc.Player
item = xbmcgui.ListItem
content = xbmcplugin.setContent
infolabel = xbmc.getInfoLabel
condvisibility = xbmc.getCondVisibility
sleep = xbmc.sleep

addonid = addon_info('id')  # ie: 'script.jptools'
addontitle = addon_info('name')  # ie: 'JP Tools'
addonversion = addon_info('version')  # old label  VERSION
addonicon = addon_info('icon')
addonfanart = addon_info('fanart')
addonpath = addon_info('path')
# addonprofile = transpath(addon_info('profile'))

homepath = transpath('special://home/')
logpath = transpath('special://logpath/')
userdata = transpath('special://profile/')
thumbs = transpath('special://thumbnails/')
skinPath = transpath('special://skin/')
temppath = transpath('special://temp')

datapath = transpath(addon_info('profile'))
settingsfile = joinpath(datapath, 'settings.xml')
viewsfile = joinpath(datapath, 'views.db')
mediapath = transpath(joinpath(addonpath, 'media'))
userdatapath = joinpath(homepath, 'userdata')
databasepath = joinpath(userdatapath, 'Database')
thumbspath = joinpath(userdatapath, 'Thumbnails')
addondata = joinpath(userdatapath, 'addon_data', addonid)
wizlog = joinpath(logpath, 'jptools.log')
backupdir = transpath(joinpath('special://home/backupdir', ''))
addons_path = transpath('special://home/addons')
iconmaint = joinpath(mediapath, 'maintenance.png')
iconsettings = joinpath(mediapath, 'settings.png')

packages = joinpath(homepath, 'addons', 'packages')
excludes = [addonid, 'backupdir', 'backup', 'script.module.requests', 'script.module.urllib3', 'script.module.chardet', 'script.module.idna', 'script.module.certifi', 'repository.JPB', 'metadata.common.fanart.tv', 'metadata.common.imdb.com', 'metadata.common.theaudiodb.com', 'metadata.common.themoviedb.org', 'metadata.tvshows.themoviedb.org', 'service.xbmc.versioncheck', 'script.module.youtube.dl', 'script.module.soupsieve', 'script.module.kodi-six', 'script.module.addon.signals']
excludes_addons = ['notification', 'packages', '__pycache__', 'temp']

atoday = date.today()
oldthumb = atoday - timedelta(days=int(getsetting('thumb_age')))
color1 = 'skyblue'  # 'blue'#'red'
color2 = 'white'
color3 = 'springgreen'
sysaddon = sys.argv[0]
customcolor = getsetting('my_ColorChoice')
if customcolor == '': customcolor = None
addon_debug = getsetting('addon_debug') == 'true'
debug_location = getsetting('debug.location') != '0'

def dialog():
    return xbmcgui.Dialog()

def kodi_open(path: str, mode: str = 'r'):
    return xbmcvfs.File(path, mode)

def datetime_to_utc(string_date: str | time.struct_time, date_format: str = '%Y-%m-%d %H:%M:%S') -> str | None:
    """Convert a formatted datetime string, numeric timestamp string, or struct_time to UTC datetime string."""
    if not string_date:
        return None

    try:
        # Case 1: time.struct_time
        if isinstance(string_date, time.struct_time):
            timestamp = time.mktime(string_date)
            return time.strftime(date_format, time.localtime(timestamp))

        # Case 2: numeric timestamp (e.g., "1771837100")
        if isinstance(string_date, (int, float)) or (isinstance(string_date, str) and string_date.isdigit()):
            return time.strftime(date_format, time.localtime(float(string_date)))

        # Case 3: formatted datetime string
        try:
            element = datetime.strptime(string_date, date_format)
        except ValueError:
            # Fallback for looser parsing
            element = datetime(*time.strptime(string_date, date_format)[0:6])

        # Assume naive datetime is UTC
        element = element.replace(tzinfo=timezone.utc)
        return element.strftime(date_format)

    except Exception as err:
        log(f'Error converting datetime: {err}')
        return None


def utc_to_datetime(date: float | str, reversedt: bool = False, date_format: str = '%Y-%m-%d %H:%M:%S') -> str | None:
    """Convert UTC timestamp to datetime string, or reverse to UTC datetime string."""
    if isinstance(date, str):
        dt = datetime.strptime(date, '%Y-%m-%d %H:%M:%S')
        date = dt.timestamp()
        # reversedt = True

    if reversedt:
        return datetime_to_utc(time.localtime(date), date_format)
    
    # Use localtime() instead of gmtime() to get your local timezone
    return time.strftime(date_format, time.localtime(date))

def comper_time_with_current(date: str):
    try:
        dt = datetime.strptime(date, '%Y-%m-%d %H:%M:%S')
        old_time = dt.timestamp()
        return old_time < int(time.time())
    except ValueError: return True

def get_timestamp(offset: int | None = None, humanread: bool = False) -> str | int:
    """Get current timestamp with optional hour offset.
    
    Args:
        offset: Hour offset from current time (None for current time)
        humanread: Return human-readable datetime string if True
        
    Returns:
        Unix timestamp (int) or datetime string (str)
    """
    current_time = int(time.time())
    timestamp = current_time if offset is None else current_time + offset * 3600

    return datetime_to_utc(timestamp) if humanread else timestamp

def build_url(url_params):
    return f'plugin://script.jptools/?{urlencode(url_params)}'


def getfuture_date(days=1):
    return atoday + timedelta(days)


def getcurrentviewid():
    win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    return str(win.getFocusId())


def getsettingenabled(item):
    is_enabled = getsetting(item).strip()
    return is_enabled not in ['', 'false']


def to_unicode(text, encoding='utf-8', errors='strict'):
    """Force text to unicode"""
    return text.decode(encoding, errors) if isinstance(text, bytes) else text


def from_unicode(text, encoding='utf-8', errors='strict'):
    """Force unicode to text"""
    import sys
    if sys.version_info.major == 2 and isinstance(text, unicode):  # noqa: F821; pylint: disable=undefined-variable,useless-suppression
        return text.encode(encoding, errors)
    return text

def get_property(prop):
    return xbmcgui.Window(10000).getProperty(prop)

def set_property(prop, value):
    return xbmcgui.Window(10000).setProperty(prop, value)

def clear_property(prop):
    return xbmcgui.Window(10000).clearProperty(prop)

def get_setting(key, default=None):
    """Get an add-on setting as string"""
    # We use Addon() here to ensure changes in settings are reflected instantly
    try:
        value = to_unicode(addon().getSetting(key))
    except RuntimeError:  # Occurs when the add-on is disabled
        return default
    return default if value == '' and default is not None else value


def get_setting_bool(key, default=None):
    """Get an add-on setting as boolean"""
    try:
        return addon().getSettingBool(key)
    except (AttributeError, TypeError):  # On Krypton or older, or when not a boolean
        value = get_setting(key, default)
        if value not in ('false', 'true'):
            return default
        return bool(value == 'true')
    except RuntimeError:  # Occurs when the add-on is disabled
        return default


def get_setting_int(key, default=None):
    """Get an add-on setting as integer"""
    try:
        return addon().getSettingInt(key)
    except (AttributeError, TypeError):  # On Krypton or older, or when not an integer
        value = get_setting(key, default)
        try:
            return int(value)
        except ValueError:
            return default
    except RuntimeError:  # Occurs when the add-on is disabled
        return default


def setsetting(id, value):
    addon().setSetting(id, value)


def make_settings_dict():  # service runs upon a setting change
    try:
        root = mdParse(settingsfile)
        curSettings = root.getElementsByTagName('setting')
        settings_dict = {}
        for item in curSettings:
            setting_id = item.getAttribute('id')
            try: setting_value = item.firstChild.data
            except: setting_value = None
            if setting_value is None: setting_value = ''
            dict_item = {setting_id: setting_value}
            settings_dict.update(dict_item)
        set_property('jptools_settings', dumps(settings_dict))
        return settings_dict
    except: return None


def opensettings(query=None, id=addonid):
    try:
        hide()
        execute(f'Addon.OpenSettings({id})')
        if query is None: return
        c, f = query.split('.')
        execute(f'SetFocus({int(c) - 100:d})')
        execute(f'SetFocus({int(f) - 80:d})')
    except: return


def get_keyboard(default='', heading='', hidden=False):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    try:
        if keyboard.isConfirmed():
            return keyboard.getText()
    except: pass
    return default


def current_skin():
    return xbmc.getSkinDir()


def version():
    num = ''
    try: version = addon('xbmc.addon').getAddonInfo('version')
    except: version = '999'
    for i in version:
        if i.isdigit(): num += i
        else: break
    return int(num)


def make_listitem():
    return xbmcgui.ListItem(offscreen=True)

def add_items(handle, item_list):
    xbmcplugin.addDirectoryItems(handle, item_list)

def normalize(msg):
    try: return ''.join(c for c in unicodedata.normalize('NFKD', msg) if unicodedata.category(c) != 'Mn')
    except: return msg


def log(msg, level=xbmc.LOGDEBUG):
    if addon_debug and level == xbmc.LOGDEBUG: level = xbmc.LOGINFO
    try:
        # ex. "\n" is not a printable character so returns False on those cases
        msg = f'~~~jptools~~~: {msg}'
        if not msg.isprintable():  msg = f'{normalize(msg)})'
        if isinstance(msg, bytes): msg = f'{msg.decode("utf-8", errors="replace")}'
        if addon_debug:
            if debug_location:
                if not os.path.exists(wizlog): f = open(wizlog, 'w'); f.close()
                # for new line on bottom
                # with open(wizlog, 'a') as f:
                # line = f'[{datetime.now().date()} {str(datetime.now().time())[:8]}] {msg}'
                # f.write(line.rstrip('\r\n')+'\n')
                # for new line on top
                with open(wizlog, 'r+', encoding='utf-8', errors='ignore') as f:
                    line = f'[{datetime.now().date()} {str(datetime.now().time())[:8]}]: {msg}'
                    log_file = f.read()
                    f.seek(0, 0)
                    f.write(line.rstrip('\r\n') + '\n' + log_file)
            else: xbmc.log(f'{msg}', level)
    except: xbmc.log(f'{msg} \nError: {format_exc()}', level)


def infodialog(message, heading=addontitle, icon='', time=None, sound=False):
    time = 3000 if time is None else int(time)
    if icon == '': icon = addonicon
    elif icon == 'INFO': icon = xbmcgui.NOTIFICATION_INFO
    elif icon == 'WARNING': icon = xbmcgui.NOTIFICATION_WARNING
    elif icon == 'ERROR': icon = xbmcgui.NOTIFICATION_ERROR
    dialog().notification(heading, message, icon, time, sound=sound)

def okdialog(message, title=addontitle):
    return dialog().ok(title, message)

def okbrowse(type, heading, shares):
    return dialog().browse(type, heading, shares, useThumbs=True, treatAsFolder=True, enableMultiple=False, )

def yesnodialog(message, title=addontitle, yes='Yes', no='No'):
    return dialog().yesno(title, message, yeslabel=f'[B][COLOR darkgreen]{yes}[/COLOR][/B]', nolabel=f'[B][COLOR coral]{no}[/COLOR][/B]')

def selectdialog(options, title=addontitle, key=True):
    mychoice = dialog().select(str(title), options)
    return mychoice if key else options[mychoice]

def inputdialog(heading=addontitle):
    return dialog().input(heading=heading, type=xbmcgui.INPUT_ALPHANUM)


def busy():
    return execute('ActivateWindow(busydialognocancel)')

def hide():
    execute('Dialog.Close(busydialog)')
    return execute('Dialog.Close(busydialognocancel)')

def closeall():
    return execute('Dialog.Close(all,true)')

def closeokdialog():
    return execute('Dialog.Close(okdialog, true)')

def refresh():
    return execute('Container.Refresh')

def idle():
    return execute('Dialog.Close(busydialognocancel)')


def getchangelog():
    from modules.textviewer import get_txt_win
    changelogfile = transpath(joinpath(addonpath, 'changelog.txt'))
    text = read_file(changelogfile)
    get_txt_win(text, 'changelog file')


def platform():
    if condvisibility('system.platform.android'): return 'android'
    elif condvisibility('system.platform.linux'): return 'linux'
    elif condvisibility('system.platform.windows'): return 'windows'
    elif condvisibility('system.platform.osx'): return 'osx'
    elif condvisibility('system.platform.atv2'): return 'atv2'
    elif condvisibility('system.platform.ios'): return 'ios'
    return


def executejsonrpc(request):
    raw_response = xbmc.executeJSONRPC(request)
    # log(f'JSONRPC-sucucces {raw_response} request: {request}')
    if 'error' in str(raw_response): log(f'JSONRPC-Error {raw_response} request: {request}')
    # else: log(f'JSONRPC-sucucces {raw_response}')
    return loads(raw_response)


def jsonrpc(*args, **kwargs):
    """Perform JSONRPC calls"""
    # We do not accept both args and kwargs
    if args and kwargs:
        log('ERROR: Wrong use of jsonrpc()')
        return None

    # Process a list of actions
    if args:
        for (idx, cmd) in enumerate(args):
            if cmd.get('id') is None: cmd.update(id=idx)
            if cmd.get('jsonrpc') is None: cmd.update(jsonrpc='2.0')
        return executejsonrpc(dumps(args))

    # Process a single action
    if kwargs:
        if kwargs.get('id') is None: kwargs.update(id=0)
        if kwargs.get('jsonrpc') is None: kwargs.update(jsonrpc='2.0')
        return executejsonrpc(dumps(args))


def json_rpc_multi(method, list_params=None):
    """
    Executes multiple JSON-RPC with the same method in Kodi

    :param method: The JSON-RPC method to call
    :type method: string
    :param list_params: Multiple list of parameters of the method call
    :type list_params: a list of dict
    :returns: dict -- Method call result
    """
    request_data = [{'jsonrpc': '2.0', 'method': method, 'id': 1, 'params': params or {}} for params in list_params]
    request = dumps(request_data)
    # log(f'Executing JSON-RPC: {request}')
    return executejsonrpc(request)


def taddonid(add):
    try: return addon(add)
    except: return False


def read_file(path):
    with open(path, 'r', encoding='utf8', errors='ignore') as logf:
        contents = logf.read()
    return contents


def check_backup_dir():
    try:
        if not os.path.exists(backupdir): makedirs(backupdir)
    except Exception as e:
        infodialog(f'[COLOR red]Backup Dir Not Found: Create one First![CR]{e}[/COLOR]')


def getviewtype():
    mychoice = 'Default'
    my_options = ['Default', 'Info Wall', 'Landscape', 'ShowCase', 'ShowCase2', 'Wide List', 'Shift', 'Icons', 'Banner', 'Fanart', 'Wall', '[ [B] Close [/B] ]']
    mychoice = selectdialog(my_options, key=False)
    viewType2 = '50'
    if mychoice == 'Default': viewType2 = '50'
    elif mychoice == 'Info Wall': viewType2 = '51'  # Poster
    elif mychoice == 'Landscape': viewType2 = '52'  # Icon Wall
    elif mychoice == 'ShowCase': viewType2 = '53'  # Shift
    elif mychoice == 'ShowCase2': viewType2 = '54'  # Info Wall
    elif mychoice == 'Wide List': viewType2 = '55'
    elif mychoice == 'Shift': viewType2 = '57'
    elif mychoice == 'Icons': viewType2 = '500'  # Wall
    elif mychoice == 'Banner': viewType2 = '501'
    elif mychoice == 'Fanart': viewType2 = '502'
    elif mychoice == 'Wall': viewType2 = '503'
    elif mychoice == '[ [B] Close [/B] ]': return
    setsetting('viewType', mychoice)
    setsetting('viewType2', str(viewType2))
    execute(f'Container.SetViewMode({int(viewType2)})')
    return


def setview(content, viewType):
    if content: content(int(sys.argv[1]), content)
    if getsetting('auto-view') == 'true':
        views = getsetting('viewType2')
        if views == '50' and kodi_version >= 17 and current_skin() == 'skin.estuary': views = '55'
        if views == '500' and kodi_version >= 17 and current_skin() == 'skin.estuary': views = '50'
        log(f'@@@@@@@@@  views {views}')
        return execute(f'Container.SetViewMode({views})')
    else:
        views = getcurrentviewid()
        log(f'@@@@@@@@@ get  views {views}')
        return execute(f'Container.SetViewMode({views})')


def colorchoice():
    chosen_color = color_chooser(no_color=True)
    setsetting('my_ColorChoice', chosen_color)
    execute('Container.Refresh')


def color_chooser(no_color=False):
    color_chart = ['black', 'white', 'whitesmoke', 'gainsboro', 'lightgray', 'silver', 'darkgray', 'gray', 'dimgray', 'snow', 'floralwhite', 'ivory', 'beige', 'cornsilk', 'antiquewhite', 'bisque', 'blanchedalmond', 'burlywood', 'darkgoldenrod', 'ghostwhite', 'azure', 'lightsaltegray', 'lightsteelblue', 'powderblue', 'lightblue', 'skyblue', 'lightskyblue', 'deepskyblue', 'dodgerblue', 'royalblue', 'blue',
                   'mediumblue', 'midnightblue', 'navy', 'darkblue', 'cornflowerblue', 'slateblue', 'slategray', 'yellowgreen', 'springgreen', 'seagreen', 'steelblue', 'teal', 'fuchsia', 'deeppink', 'darkmagenta', 'blueviolet', 'darkviolet', 'darkorchid', 'darkslateblue', 'darkslategray', 'indigo', 'cadetblue', 'darkcyan', 'darkturquoise', 'turquoise', 'cyan', 'paleturquoise', 'lightcyan', 'mintcream', 'honeydew', 'aqua',
                   'aquamarine', 'chartreuse', 'greenyellow', 'palegreen', 'lawngreen', 'lightgreen', 'lime', 'mediumspringgreen', 'mediumturquoise', 'lightseagreen', 'mediumaquamarine', 'mediumseagreen', 'limegreen', 'darkseagreen', 'forestgreen', 'green', 'darkgreen', 'darkolivegreen', 'olive', 'olivedab', 'darkkhaki', 'khaki', 'gold', 'goldenrod', 'lightyellow', 'lightgoldenrodyellow', 'lemonchiffon', 'yellow', 'seashell',
                   'lavenderblush', 'lavender', 'lightcoral', 'indianred', 'darksalmon', 'lightsalmon', 'pink', 'lightpink', 'hotpink', 'magenta', 'plum', 'violet', 'orchid', 'palevioletred', 'mediumvioletred', 'purple', 'maroon', 'mediumorchid', 'mediumpurple', 'mediumslateblue', 'thistle', 'linen', 'mistyrose', 'palegoldenrod', 'oldlace', 'papayawhip', 'moccasin', 'navajowhite', 'peachpuff', 'sandybrown', 'peru', 'chocolate',
                   'orange', 'darkorange', 'tomato', 'orangered', 'red', 'crimson', 'salmon', 'coral', 'firebrick', 'brown', 'darkred', 'tan', 'rosybrown', 'sienna', 'saddlebrown']
    color_display = [f'[COLOR={i}]{i.capitalize()}[/COLOR]' for i in color_chart]
    if no_color:
        color_chart.insert(0, 'No Color')
        color_display.insert(0, 'No Color')
    choice = selectdialog(color_display, 'Select Color scheme...', False)
    if not choice: return
    return choice.split(']')[0].replace('[COLOR=', '')


def colorstring(text, color=customcolor):
    return f'[COLOR {color}]{text}[/COLOR]'


def forceclose():
    choice = yesnodialog('Force Close Kodi', 'You are about to close Kodi[CR]Would you like to continue?', yes='Yes, Close', no='No, Cancel')
    if choice == 0: return
    myplatform = platform()
    sucucce = False
    log(f'Force close Trying Platform: {str(myplatform)}')
    if myplatform == 'osx':  # OSX
        _forceclose(' try osx force close #####', ['killall -9 Kodi', 'killall -9 XBMC'])
        okdialog('[B]WARNING !!![/B]', 'If you are seeing this message it means the force close[CR]was unsuccessful. Please force close XBMC/Kodi DO NOT exit cleanly via the menu.')
    elif myplatform == 'linux':  # Linux
        _forceclose(' try linux force close #####', ['killall Kodi', 'killall XBMC', 'killall -9 kodi.bin', 'killall -9 xbmc.bin'])
        okdialog('[B]WARNING !!![/B]', 'If you are seeing this message it means the force close[CR]was unsuccessful. Please force close XBMC/Kodi DO NOT exit cleanly via the menu.')
    elif myplatform == 'android':  # Android
        sucucce = _forceclose(' try android force close #####', ['adb shell am force-stop org.xbmc.kodi', 'adb shell am force-stop org.kodi', 'adb shell kill org.xbmc.kodi', 'adb shell kill org.kodi', 'Process.killProcess(android.os.Process.org.xbmc,kodi());', 'Process.killProcess(android.os.Process.org.kodi());', 'adb shell "pm clear org.xbmc.kodi"'])
        if not sucucce: sucucce = _forceclose(' try android force close #####', ['adb shell am force-stop org.xbmc.xbmc', 'adb shell am force-stop org.xbmc', 'adb shell kill org.xbmc.xbmc', 'adb shell kill org.xbmc', 'Process.killProcess(android.os.Process.org.xbmc.xbmc());', 'Process.killProcess(android.os.Process.org.xbmc());'])
        okdialog('Press the HOME button on your remote and [CR][B]FORCE STOP[/B] KODI via the Manage Installed Applications menu in settings[CR]on your Amazon home page then re-launch KODI')
    elif myplatform == 'windows':  # Windows
        sucucce = _forceclose(' try windows force close #####', ['@ECHO off', 'tskill Kodi.exe', '@ECHO off', 'TASKKILL /im Kodi.exe /f', '@ECHO off', 'tskill XBMC.exe', '@ECHO off', 'TASKKILL /im XBMC.exe /f'])
        okdialog('[B]WARNING !!![/B]', 'If you are seeing this message it means the force close[CR]was unsuccessful. Please force close XBMC/Kodi[CR]DO NOT exit cleanly via the menu.', )
    else:  #ATV
        log(' try atv force close #####')
        try: os.system('killall AppleTV')
        except: pass
        sucucce = _forceclose(' try raspbmc force close #####', ['sudo initctl stop kodi', 'sudo initctl stop xbmc'])
        okdialog('[B]WARNING !!![/B]', 'If you are seeing this message it means the force close[CR]was unsuccessful. Please force close XBMC/Kodi DO NOT exit via the menu.[CR]iOS detected. Press and hold both the Sleep/Wake and Home button for at least 10 seconds, until you see the Apple logo.')


def _forceclose(arg1, args):
    log(f'_forceclose arg1: {arg1}')
    sucucce = False
    for arg in args:
        try:
            log(f'_forceclose arg: {arg}')
            os.system(arg)
            sucucce = True
            # break
        except: log(f'not work arg: {arg}')
    return sucucce

def resolveurl_link_tester():
    import resolveurl
    link = inputdialog('Add URL to Test in resolvurl')
    log(f'Playing Link: |{link}|')
    if link.endswith('$$all'): hmf = resolveurl.HostedMediaFile(url=link[:-5], return_all=True)
    else: hmf = resolveurl.HostedMediaFile(url=link)
    if not hmf:
        log(f'Indirect hoster_url not supported by smr: {link}')
        infodialog(f'Link Not Supported: {link}')
        return False
    resolvers = [item.name for item in hmf.get_resolvers(validated=True)]
    log(f'Link Supported: |{link}| Resolvers: {", ".join(resolvers)}')

    try:
        if link.endswith('$$all'):
            allfiles = hmf.resolve()
            names = [x.get('name') for x in allfiles]
            item = dialog().select('Select file to play', names, preselect=0)
            if item == -1: return False
            stream_url = allfiles[item].get('link')
            if resolveurl.HostedMediaFile(stream_url): stream_url = resolveurl.resolve(stream_url)
        else: stream_url = hmf.resolve()
        if not stream_url or not isinstance(stream_url, str):
            try: msg = stream_url.msg
            except: raise Exception(link)
    except Exception as e:
        msg = f'error: {str(e)}\nlink: {link}'
        infodialog(f'Resolve Failed: {msg}')
        return False
    log(f'Link Resolved: |{link} >>> {stream_url}|')
    listitem = xbmcgui.ListItem(path=stream_url)
    # listitem.setContentLookup(False)
    listitem.setProperty("Video", "true")
    listitem.setProperty('IsPlayable', 'true')
    if '.mpd' in stream_url:
        listitem.setProperty('inputstream', 'inputstream.adaptive')
        listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        listitem.setMimeType('application/dash+xml')
        listitem.setContentLookup(False)
        if '|' in stream_url:
            stream_url, strhdr = stream_url.split('|')
            listitem.setProperty('inputstream.adaptive.stream_headers', strhdr)
            listitem.setPath(stream_url)
    player.play(stream_url, listitem)
    # xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)


def get_soup(Data):
    from bs4 import BeautifulSoup
    return BeautifulSoup(Data, 'html.parser')

def delete_file(_file):
    if not existspath(_file): return
    try: deletefe(_file)
    except Exception as e:
        log(f'Error: {repr(e)} Deleting file: {_file}')
        from os import unlink, remove
        try:
            unlink(_file)
            remove(_file)
        except Exception as e: log(f'Error: {repr(e)} unlink file: {_file}')


def get_dialog_name(dialog_id):
    dialog_names = {
        10100: "DialogOK",
        10101: "DialogYesNo",
        10103: "DialogKeyboard",
        10106: "DialogProgress",
        10107: "DialogBusy",
        10138: "DialogSeekBar",
        10160: "DialogNumeric",
        10161: "DialogGamepad",
        10140: "DialogVolumeBar",
        10159: "DialogSubtitles",
        10111: "DialogSubMenu",
        10147: "DialogContextMenu",
        10146: "DialogButtonMenu",
        10108: "DialogExtendedProgressBar",
        10109: "DialogNotification",
        10110: "DialogKaiToast"
    }
    return dialog_names.get(dialog_id, "Unknown or Custom Dialog")

def wait_for_modal_dialog_to_close(timeout=10):
    """
    Waits until all modal dialogs are closed or until timeout (in seconds) is reached.
    """
    start_time = time.time()
    while xbmc.getCondVisibility("System.HasActiveModalDialog"):
        if time.time() - start_time > timeout:
            log("Timeout waiting for modal dialog to close.")
            return False
        sleep(100)  # Sleep for 100ms
    log("All modal dialogs are closed.")
    return True

def wait_for_modal_dialog(timeout=10):
    """
    Waits for a modal dialog to appear within the timeout period.
    Returns the dialog ID if found, else None.
    """
    start = time.time()
    while time.time() - start < timeout:
        if xbmc.getCondVisibility("System.HasActiveModalDialog"):
            dialog_id = xbmcgui.getCurrentWindowDialogId()
            log(f"Modal dialog appeared: ID {dialog_id}")
            return dialog_id
        sleep(100)
    log("No modal dialog appeared within timeout.")
    return None

def log_dialog_controls(dialog_id):
    """
    Logs all controls in the given dialog window.
    """
    try:
        dialog = xbmcgui.Window(dialog_id)
    except Exception as err:
        log(f"Dialog ID {dialog_id} is not accessible. err: {err}")
        try:
            dialog_id = xbmcgui.getCurrentWindowDialogId()
            dialog = xbmcgui.Window(dialog_id)
        except RuntimeError:
            log(f"Dialog ID {dialog_id} is not accessible.")
            return
    focused_id = dialog.getFocusId()
    log(f"1Focused Control ID: {type(focused_id)} {repr(focused_id)}")
    if focused_id == 10 and dialog_id == 10100: execute('SendClick(10)')
    # 28 OK Button., 29: Cancel Button.
    # 10 Yes button, 11  No button

    for control_id in (10, 11, 28, 29):
        try:
            control = dialog.getControl(control_id)
            control_type = type(control).__name__
            label = getattr(control, 'getLabel', lambda: '')()
            visible = control.isVisible()
            enabled = control.isEnabled()
            x, y = control.getPosition()
            log(f"Control ID: {control_id}, Type: {control_type}, Label: '{label}', Visible: {visible}, Enabled: {enabled}, Position: ({x}, {y})")
        except Exception as err:
            continue

def auto_click_yes():
    x = 0
    sleep(200)
    # if condvisibility('System.HasActiveModalDialog'):
        # dialog_id = wait_for_modal_dialog()
        # if dialog_id:
            # sleep(300)  # Give Kodi time to fully initialize the dialog
            # log_dialog_controls(dialog_id)
    dialog_id = xbmcgui.getCurrentWindowDialogId()
    log(f'dialog ID: {type(dialog_id)} {repr(dialog_id)}')
    if dialog_id in (1129, 10100, 12002, 10138): execute('SendClick(11)') #(DialogConfirm.xml, WINDOW_DIALOG_YES_NO, WINDOW_DIALOG_OK, WINDOW_DIALOG_BUSY)
    while not condvisibility('Window.isVisible(yesnodialog)') and x < 100:
        x += 1
        sleep(20)
    # execute('SetFocus(9000,0)')
    if condvisibility('Window.isVisible(yesnodialog)'): execute('SendClick(11)')
    else: execute('SendClick(11)')
    return


def get_active_source():
    # xml_file = transpath('special://profile/mediasources.xml')
    if getsetting('getsetting_file') == 'false': return
    # xml_file = transpath('special://profile/passwords.xml')
    # if not existspath(xml_file):
        # log(f'not exist xml_file: {xml_file}')
        # setsetting('smb_path', 'smb://')
        # return
    # root = mdParse(xml_file) #minidom instead of element tree
    # sources = root.getElementsByTagName("location")
    # sources = root.getElementsByTagName("to")
    # log(f'sources: {sources}')
    # for item in sources:
        # source_dir = item.firstChild.data
        # path_acces = xbmcvfs.listdir(source_dir)
        # log(f'source_dir: {source_dir}\n item: {path_acces}')
        # if 'Data' in str(path_acces): break
    setsetting('smb_path', 'smb://cp:srusty@ENET/Media/Data')
    # setsetting('smb_path', f'{source_dir}Data')
    return


def reloadprofile():
    profile = infolabel('System.ProfileName')
    if yesnodialog(addontitle, 'Are you sure you want to Reload Profile?'):
        if profile is None: execute('LoadProfile(Master user)')
        else: execute(f'LoadProfile({profile})')


def reloadmyskin():
    if yesnodialog(addontitle, 'Are you sure you want to Reload Skin?'):
        return execute('ReloadSkin()')
    else: return


def resetresolverscache():
    try:
        if condvisibility('System.HasAddon(script.module.resolveurl)'):
            execute('runplugin(plugin://script.module.resolveurl/?mode=reset_cache)')
    except Exception as e: log(f'resetresolverscache error: {e}')