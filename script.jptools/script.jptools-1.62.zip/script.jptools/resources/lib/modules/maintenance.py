# -*- coding: utf-8 -*-

import shutil
import sqlite3 as database
from os import listdir, remove, unlink, walk
from os.path import getsize
from traceback import print_exc

from modules.control import condVisibility, databasepath, deleteFile, existsPath, getSettingEnabled, homepath, infoDialog, joinPath, listDir, log, logpath, oldthumb, transPath


def clean_oldlog(clean=False):
    from modules.traktit import get_file_older_then_hrs
    logfilepath = listdir(logpath)
    # log(f'logfilepath: {logfilepath}')
    try:
        for item in logfilepath:
            if clean and item.endswith('.log') and item not in ['kodi.log', 'kodi.old.log']:
                # log(f'item to clean: {item}')
                l_file = joinPath(logpath, item)
                # log(f'item to clean: {l_file}')
                with open(l_file, 'w') as logFile:
                    logFile.write('')
            if 'kodi_crashlog' in item or 'kodi_stacktrace' in item:
                item_path = joinPath(logpath, item)
                if get_file_older_then_hrs(item_path, 48) is False:
                    log(f'file delete path: {item_path}')
                    try: deleteFile(item_path)
                    except: remove(item_path)
        if clean: infoDialog('Clean Old log files Completed.')
    except Exception as e: log(f'clean_oldlog Error: {e}')


class cacheEntry(object):
    def __init__(self, namei, pathi):
        self.name = namei
        self.path = pathi

    def setupCacheEntries(self):
        entries = 5  #make sure this refelcts the amount of entries you have
        dialogName = ['WTF', '4oD', 'BBC iPlayer', 'Simple Downloader', 'ITV']
        pathName = ['special://profile/addon_data/plugin.video.whatthefurk/cache', 'special://profile/addon_data/plugin.video.4od/cache', 'special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache', 'special://profile/addon_data/script.module.simple.downloader', 'special://profile/addon_data/plugin.video.itv/Images']
        return [cacheEntry(dialogName[x], pathName[x]) for x in range(entries)]


def clearCache(mode='verbose'):
    tempPaths = [transPath('special://temp'), joinPath(homepath, 'addons', 'temp')]
    cachePath = joinPath(homepath, 'cache')
    file_count = 0
    if existsPath(cachePath) is True and getSettingEnabled('tune.cachePath') is True:
        total_files, total_folds = cleanfolder(cachePath)
        file_count = total_files + total_folds
        if mode == 'verbose': infoDialog(f'Clean cache Completed [ {file_count:d} ]')

    for path in tempPaths:
        if existsPath(path):
            total_files, total_folds = cleanfolder(path)
            file_count = total_files + total_folds
    if mode == 'verbose': infoDialog(f'Clean temp Completed [ {file_count:d} ]')

    if condVisibility('system.platform.ATV2'):
        atv2_cache_a = joinPath('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        total_files, total_folds = cleanfolder(atv2_cache_a)
        file_count = total_files + total_folds

        atv2_cache_b = joinPath('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        total_files, total_folds = cleanfolder(atv2_cache_b)
        file_count += total_files + total_folds

        if mode == 'verbose': infoDialog(f'Clean Caches Completed [ {file_count:d} ]')

    cacheEntries = []
    file_count = 0
    for entry in cacheEntries:
        clear_cache_path = transPath(entry.path)
        if existsPath(clear_cache_path) == True and getSettingEnabled('tune.cacheEntries') == True:
            total_files, total_folds = cleanfolder(clear_cache_path)
            file_count += total_files + total_folds
            if mode == 'verbose': infoDialog(f'Clean Caches Completed [ {file_count:d} ]')
    home_clean = listDir(homepath)
    for item in home_clean:
        if 'kodi_crashlog' in item or 'kodi_stacktrace' in item:
            item_path = joinPath(homepath, item)
            log(f'item_path: {item_path}')
            try: deleteFile(item_path)
            except: remove(item_path)
    if mode == 'verbose': infoDialog('Clean Cache Completed.')


def thumb_cleaner():
    thumbs_folder = transPath('special://thumbnails')
    # log(f'thumbs_folder: {repr(thumbs_folder)}')
    dbfile = transPath(joinPath('special://database', 'Textures13.db'))
    minimum_uses = 30
    size = images = 0
    if not existsPath(dbfile):
        return infoDialog('there is no Database file: Failed')
    dbcon = database.connect(dbfile, isolation_level=None)
    dbcur = dbcon.cursor()
    dbcur.execute('''PRAGMA synchronous = OFF''')
    dbcur.execute('''PRAGMA journal_mode = OFF''')
    dbcur.execute('SELECT cachedurl FROM texture', )
    lasthashcheck_result = dbcur.fetchall()
    not_to_delete = []
    for item in lasthashcheck_result:
        # log(f'item: {repr(item)}')
        try:
            item = item[0].split('/')[1]
            not_to_delete.append(item)
        except: pass

    # # log(f'FROM texture DELETE lasthashcheck IS NULL Total: {len(lasthashcheck_result)} results: {repr(lasthashcheck_result)}')
    # dbcur.execute('DELETE FROM texture WHERE lasthashcheck IS NULL OR lasthashcheck = ''', )
    # lasthashcheck_result = dbcur.fetchall()
    # log(f'FROM texture DELETE lasthashcheck IS NULL Total: {len(lasthashcheck_result)} results: {repr(lasthashcheck_result)}')
    dbcur.execute('SELECT idtexture FROM sizes WHERE usecount < ? AND lastusetime < ?', (minimum_uses, str(oldthumb)))
    result = dbcur.fetchall()
    log(f'Old Thumbnails than {oldthumb}, or have not been accessed at least {minimum_uses} times Total: {len(result)}')
    if len(result) <= 0: infoDialog('No Thumbnails to Clear')
    else:
        item_list = []
        for item in result:
            _id = item[0]
            dbcur.execute('SELECT cachedurl FROM texture WHERE id = ?', (_id, ))
            url = dbcur.fetchall()[0][0]
            path = joinPath(thumbs_folder, url)
            try:
                item_list.append((_id,))
                imagesize = getsize(path)
                deleteFile(path)
                size += imagesize
                images += 1
            except: pass
        dbcur.executemany('DELETE FROM sizes WHERE idtexture = ?', item_list)
        dbcur.executemany('DELETE FROM texture WHERE id=?', item_list)
    dbcur.execute('VACUUM')
    dbcon.commit()
    dbcon.close()
    # # if existsPath(thumbs_folder):
    # log(f'total: {len(not_to_delete)} : {repr(not_to_delete)}')
    if len(lasthashcheck_result) > 0:
        for root, dirs, files in walk(thumbs_folder):
            file_count = len(files)
            if file_count > 0:
                # log(f'len(files): {len(files)} {repr(files)}')
                for f in files:
                    if f not in not_to_delete:
                        # log(f'f: {f}')
                        try: unlink(joinPath(root, f))
                        except: log(f'Error unlink file: {f}')
                        try:
                            try: deleteFile(joinPath(root, f))
                            except: remove(joinPath(root, f))
                        except Exception as e: log(f'Error: {e} Deleting file: {f}')
    removed = f'{size / 1024000.0:.0f}'
    msg = f'[COLOR red]Clear Thumbs: {images} Files / {removed} MB[/COLOR]!'
    log(msg)
    return infoDialog(msg)


def purgePackages(mode='verbose'):
    purgePath = transPath('special://home/addons/packages')
    total_files, total_folds = cleanfolder(purgePath)
    file_count = total_files + total_folds
    if mode == 'verbose': infoDialog(f'Clean Packages Completed [ {file_count:d} ]')


def clean_MyVideos_db(modify=False):

    def clean_table(table, total_entry):
        query = None
        if 'files' == table:
            # query = f'SELECT * FROM {table} WHERE strPath NOT LIKE '{keep_items}'
            query = f'SELECT * FROM {table} WHERE strFilename IS NULL OR strFilename = "" OR playCount IS NULL'
            # delete Null
            # data_row_delete = f'DELETE FROM {table} WHERE idParentPath IS NULL OR idParentPath = '
            # data_row_delete = f'DELETE FROM {table} WHERE strFilename IS NULL OR strFilename = '' OR playCount IS NULL'
            data_row_delete = f'DELETE FROM {table} WHERE strFilename NOT LIKE "plugin:%"'
        elif 'path' == table:
            query = f'SELECT * FROM {table} WHERE strPath NOT LIKE "{keep_items}"'
            # query = f'SELECT * FROM {table} WHERE idParentPath IS NULL OR idParentPath = '
            # delete Null
            # data_row_delete = f'DELETE FROM {table} WHERE idParentPath IS NULL OR idParentPath = '
            data_row_delete = f'DELETE FROM {table} WHERE strPath NOT LIKE "{keep_items}"'
        if not query: return total_entry
        log(f'query: {query}\ndata_row_delete: {data_row_delete}')
        cursor.execute(query)
        data = cursor.fetchall()
        j = len(data)
        total_entry += j
        if j > 0:
            log(f'from Table {table} Total rows : {j} total_entry: {total_entry}')
            try:
                data_row_limit = f'DELETE FROM {table} WHERE ROWID IN (SELECT ROWID FROM {table} ORDER BY ROWID DESC LIMIT -1 OFFSET 200)'
                cursor.execute(data_row_delete)
                cursor.execute(data_row_limit)
                dbcon.commit()
            except: log(f'Error clean_table: {print_exc()}')
        return total_entry

    try:
        db_file = joinPath(databasepath, 'MyVideos122.db')
        if not existsPath(db_file): db_file = joinPath(databasepath, 'MyVideos121.db')
        try:
            dbcon = database.connect(db_file)
            cursor = dbcon.cursor()
            cursor.execute('''PRAGMA synchronous = OFF''')
            cursor.execute('''PRAGMA journal_mode = OFF''')
        except:
            log(f'Error clean_MyVideos_db: {print_exc()}')
            return False
        query = 'SELECT name FROM sqlite_master WHERE type="table"'
        # query = 'SELECT name from sqlite_master where type= 'table' AND name NOT LIKE 'sqlite_%''
        find_deletes = ('%ENet%', 'https:%', 'http:%')
        keep_items = '%plugin:%'
        cursor.execute(query)
        tables_in_db = cursor.fetchall()
        total_entry = 0
        for i in tables_in_db:
            if i[0] in ('files', 'path'):
                total_entry = clean_table(i[0], total_entry)
        dbcon.commit()
        dbcon.execute('VACUUM')
    except: log(f'Error clean_MyVideos_db: {print_exc()}')
    finally: dbcon.close()
    return infoDialog(f'total total_entry removed: {total_entry}')


def cleanfolder(folder):
    file_tokeep = ('commoncache.db', 'kodi.log', 'kodi.old.log', 'xbmc.log', 'xbmc.old.log', 'spmc.log', 'spmc.old.log')
    # log(folder)
    total_files = 0
    total_folds = 0
    try:
        for root, dirs, files in walk(folder):
            if len(dirs) >= 0:
                for d in dirs:
                    try:
                        shutil.rmtree(joinPath(root, d))
                        total_folds += 1
                    except: log(f'Error Deleting Folder: {d}')
            if len(files) >= 0:
                for f in files:
                    if f in file_tokeep: continue
                    try:
                        unlink(joinPath(root, f))
                        total_files += 1
                    except: log(f'Error unlink file: {f}')
                    try:
                        try: deleteFile(joinPath(root, f))
                        except: remove(joinPath(root, f))
                    except Exception as e: log(f'Error: {e} Deleting file: {f}')
    except Exception as e: log(f'cleanfolder Error: {e}')
    return total_files, total_folds
