# -*- coding: UTF-8 -*-

import os
import sys
from datetime import date, datetime, timedelta
from json import dumps as jsdumps
from xml.dom.minidom import parse as mdParse

import unicodedata
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
from xbmcaddon import Addon
import _strptime
import resolveurl

_addon_object = Addon()
getLocalizedString = _addon_object.getLocalizedString
get_infolabel = xbmc.getInfoLabel


kodi_version = int(get_infolabel('System.BuildVersion')[0:2])

def addon(addon_id='script.jptools'):
    return Addon(id=addon_id)



addonInfo = addon().getAddonInfo

transPath = xbmcvfs.translatePath
deleteFile = xbmcvfs.delete
makeDirs = xbmcvfs.mkdirs

listDir = xbmcvfs.listdir
existsPath = xbmcvfs.exists
joinPath = os.path.join

execute = xbmc.executebuiltin
lang = addon().getLocalizedString
lang2 = xbmc.getLocalizedString

setting = addon().getSetting

addItem = xbmcplugin.addDirectoryItem
endOfdirectory = xbmcplugin.endOfDirectory

dialog = xbmcgui.Dialog()
dp = xbmcgui.DialogProgress()
homeWindow = xbmcgui.Window(10000)
item = xbmcgui.ListItem
content = xbmcplugin.setContent
infoLabel = xbmc.getInfoLabel
condVisibility = xbmc.getCondVisibility
sleep = xbmc.sleep

AddonID = addonInfo('id')  # ie: 'script.jptools'
AddonTitle = addonInfo('name')  # ie: 'JP Tools'
AddonVersion = addonInfo('version')  # old label  VERSION
AddonIcon = addonInfo('icon')
AddonFanart = addonInfo('fanart')
AddonPath = addonInfo('path')
AddonProfile = transPath(addonInfo('profile'))

homepath = transPath('special://home/')
logpath = transPath('special://logpath/')
userdata = transPath(joinPath('special://home/userdata', ''))
thumbs = transPath(joinPath('special://home/userdata/Thumbnails', ''))
skinPath = transPath('special://skin/')

dataPath = transPath(addonInfo('profile'))
settingsFile = joinPath(dataPath, 'settings.xml')
viewsFile = joinPath(dataPath, 'views.db')
mediapath = transPath(joinPath(AddonPath, 'media'))
userdatapath = joinPath(homepath, 'userdata')
databasepath = joinPath(userdatapath, 'Database')
thumbspath = joinPath(userdatapath, 'Thumbnails')
addondata = joinPath(userdatapath, 'addon_data', AddonID)
wizlog = joinPath(logpath, 'jptools.log')
backupdir = transPath(joinPath('special://home/backupdir', ''))
iconmaint = joinPath(mediapath, 'maintenance.png')
iconsettings = joinPath(mediapath, 'settings.png')

packages = joinPath(homepath, 'addons', 'packages')
EXCLUDES = [AddonID, 'backupdir', 'script.module.requests', 'script.module.urllib3', 'script.module.chardet', 'script.module.idna', 'script.module.certifi', 'repository.JPB', 'metadata.common.fanart.tv', 'metadata.common.imdb.com', 'metadata.common.theaudiodb.com', 'metadata.common.themoviedb.org', 'metadata.tvshows.themoviedb.org', 'service.xbmc.versioncheck', 'script.module.youtube.dl', 'script.module.soupsieve', 'script.module.kodi-six', 'script.module.addon.signals']
EXCLUDES_ADDONS = ['notification', 'packages']

atoday = date.today()
tomorrow = atoday + timedelta(days=1)
threedays = atoday + timedelta(days=3)
biweek = atoday + timedelta(days=14)
nextsave = atoday + timedelta(days=15)
oldthumb = atoday - timedelta(days=int(setting('thumb_age')))
days = [atoday.strftime('%Y-%m-%d'), threedays.strftime('%Y-%m-%d'), biweek.strftime('%Y-%m-%d')]
color1 = 'skyblue'  # 'blue'#'red'
color2 = 'white'
color3 = 'springgreen'
sysaddon = sys.argv[0]
CustomColor = setting('my_ColorChoice')
if CustomColor == '': CustomColor = 'none'


def getCurrentViewId():
    win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    return str(win.getFocusId())


def getSettingEnabled(item):
    is_enabled = setting(item).strip()
    return is_enabled not in ['', 'false']


def getSetting(id):
    return addon().getSetting(id)


def to_unicode(text, encoding='utf-8', errors='strict'):
    """Force text to unicode"""
    return text.decode(encoding, errors) if isinstance(text, bytes) else text


def from_unicode(text, encoding='utf-8', errors='strict'):
    """Force unicode to text"""
    import sys
    if sys.version_info.major == 2 and isinstance(text, unicode):  # noqa: F821; pylint: disable=undefined-variable,useless-suppression
        return text.encode(encoding, errors)
    return text


def get_setting(key, default=None):
    """Get an add-on setting as string"""
    # We use Addon() here to ensure changes in settings are reflected instantly
    try:
        value = to_unicode(addon().getSetting(key))
    except RuntimeError:  # Occurs when the add-on is disabled
        return default
    return default if value == '' and default is not None else value


def get_setting_bool(key, default=None):
    """Get an add-on setting as boolean"""
    try:
        return addon().getSettingBool(key)
    except (AttributeError, TypeError):  # On Krypton or older, or when not a boolean
        value = get_setting(key, default)
        if value not in ('false', 'true'):
            return default
        return bool(value == 'true')
    except RuntimeError:  # Occurs when the add-on is disabled
        return default


def get_setting_int(key, default=None):
    """Get an add-on setting as integer"""
    try:
        return addon().getSettingInt(key)
    except (AttributeError, TypeError):  # On Krypton or older, or when not an integer
        value = get_setting(key, default)
        try:
            return int(value)
        except ValueError:
            return default
    except RuntimeError:  # Occurs when the add-on is disabled
        return default


def setSetting(id, value):
    addon().setSetting(id, value)


def make_settings_dict(): # service runs upon a setting change
    try:
        root = mdParse(settingsFile)
        curSettings = root.getElementsByTagName('setting')
        settings_dict = {}
        for item in curSettings:
            setting_id = item.getAttribute('id')
            try: setting_value = item.firstChild.data
            except: setting_value = None
            if setting_value is None: setting_value = ''
            dict_item = {setting_id: setting_value}
            settings_dict.update(dict_item)
        homeWindow.setProperty('infinity_settings', jsdumps(settings_dict))
        return settings_dict
    except: return None


def openSettings(query=None, id=addonInfo('id')):
    try:
        hide()
        execute(f'Addon.OpenSettings({id})')
        if query is None: return
        c, f = query.split('.')
        execute(f'SetFocus({int(c) - 100:d})')
        execute(f'SetFocus({int(f) - 80:d})')
    except: return


def get_keyboard(default='', heading='', hidden=False):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    try:
        if keyboard.isConfirmed():
            return keyboard.getText()
    except: pass
    return default


def current_skin():
    return xbmc.getSkinDir()


def version():
    num = ''
    try: version = addon('xbmc.addon').getAddonInfo('version')
    except: version = '999'
    for i in version:
        if i.isdigit(): num += i
        else: break
    return int(num)


def make_listitem():
    return xbmcgui.ListItem(offscreen=True)


def normalize(msg):
    try: return ''.join(c for c in unicodedata.normalize('NFKD', msg) if unicodedata.category(c) != 'Mn')
    except: return msg


def log(msg, level=xbmc.LOGDEBUG):
    if setting('addon_debug') == 'true' and level == xbmc.LOGDEBUG: level = xbmc.LOGINFO
    try:
        # ex. "\n" is not a printable character so returns False on those cases
        if not msg.isprintable():  msg = f'{normalize(msg)} (NORMALIZED by log())'
        if isinstance(msg, bytes): msg = f'{msg.decode("utf-8", errors="replace")} (ENCODED by log())'
        if setting('addon_debug') == 'true':
            if setting('debug.location') != '0':
                if not os.path.exists(wizlog): f = open(wizlog, 'w'); f.close()
                # for new line on bottom
                # with open(wizlog, 'a') as f:
                    # line = f'[{datetime.now().date()} {str(datetime.now().time())[:8]}] {msg}'
                    # f.write(line.rstrip('\r\n')+'\n')
                # for new line on top
                with open(wizlog, 'r+', encoding='utf-8', errors='ignore') as f:
                    line = f'[{datetime.now().date()} {str(datetime.now().time())[:8]}]: {msg}'
                    log_file = f.read()
                    f.seek(0, 0)
                    f.write(line.rstrip('\r\n') + '\n' + log_file)
            else: xbmc.log(f'{AddonTitle}: {msg}', level)
    except:
        import traceback
        xbmc.log(f'{AddonTitle}: {msg} \nError: {traceback.print_exc()}', level)


def infoDialog(message, heading=addonInfo('name'), icon='', time=None, sound=False):
    time = 3000 if time is None else int(time)
    if icon == '': icon = AddonIcon
    elif icon == 'INFO': icon = xbmcgui.NOTIFICATION_INFO
    elif icon == 'WARNING': icon = xbmcgui.NOTIFICATION_WARNING
    elif icon == 'ERROR': icon = xbmcgui.NOTIFICATION_ERROR
    dialog.notification(heading, message, icon, time, sound=sound)


def TextBox(header, message):
    execute('ActivateWindow(10147)')
    controller = xbmcgui.Window(10147)
    sleep(500)
    controller.getControl(1).setLabel(header)
    controller.getControl(5).setText(message)


def OkDialog(title, message):
    dialog.ok(title, message)


def YesNoDialog(title, message, yes='Yes', no='No'):
    return dialog.yesno(title, message, yeslabel=yes, nolabel=no)


def yesnoDialog(line1, line2='', line3='', heading=addonInfo('name'), nolabel='No', yeslabel='Yes'):
    return dialog.yesno(heading, f'{line1}[CR]{line2}[CR]{line3}', nolabel, yeslabel)


def SelectDialog(title, options, key=True):
    # list_choice = dialog.select(string, dialog_list)
    # if list_choice >= 0: return function_list[list_choice]
    # else: return None
    mychoice = dialog.select(str(title), options)
    return mychoice if key else options[mychoice]


def inputDialog(heading=None):
    heading = f'{AddonTitle}\n{heading}' if heading else AddonTitle
    return dialog.input(heading=heading, type=xbmcgui.INPUT_ALPHANUM)


def busy():
    return execute('ActivateWindow(busydialognocancel)')


def hide():
    execute('Dialog.Close(busydialog)')
    execute('Dialog.Close(busydialognocancel)')


def closeAll():
    return execute('Dialog.Close(all,true)')


def closeOkDialog():
    return execute('Dialog.Close(okdialog, true)')


def refresh():
    return execute('Container.Refresh')


def idle():
    return execute('Dialog.Close(busydialognocancel)')


def getChangeLog():
    changelogfile = transPath(joinPath(AddonPath, 'changelog.txt'))
    text = read_file(changelogfile)
    id = 10147
    execute(f'ActivateWindow({id:d})')
    sleep(500)
    win = xbmcgui.Window(id)
    retry = 50
    while retry > 0:
        try:
            sleep(10)
            retry -= 1
            win.getControl(1).setLabel(f'--[ v{AddonVersion} ChangeLog ]--')
            win.getControl(5).setText(text)
            return
        except: pass


def platform():  # used in ForceClose()
    if condVisibility('system.platform.android'): return 'android'
    elif condVisibility('system.platform.linux'): return 'linux'
    elif condVisibility('system.platform.windows'): return 'windows'
    elif condVisibility('system.platform.osx'): return 'osx'
    elif condVisibility('system.platform.atv2'): return 'atv2'
    elif condVisibility('system.platform.ios'): return 'ios'


def jsonrpc(*args, **kwargs):
    """Perform JSONRPC calls"""
    from json import dumps, loads

    # We do not accept both args and kwargs
    if args and kwargs:
        log('ERROR: Wrong use of jsonrpc()')
        return None

    # Process a list of actions
    if args:
        for (idx, cmd) in enumerate(args):
            if cmd.get('id') is None: cmd.update(id=idx)
            if cmd.get('jsonrpc') is None: cmd.update(jsonrpc='2.0')
        return loads(xbmc.executeJSONRPC(dumps(args)))

    # Process a single action
    if kwargs.get('id') is None: kwargs.update(id=0)
    if kwargs.get('jsonrpc') is None: kwargs.update(jsonrpc='2.0')
    return loads(xbmc.executeJSONRPC(dumps(kwargs)))


def json_rpc_multi(method, list_params=None):
    """
    Executes multiple JSON-RPC with the same method in Kodi

    :param method: The JSON-RPC method to call
    :type method: string
    :param list_params: Multiple list of parameters of the method call
    :type list_params: a list of dict
    :returns: dict -- Method call result
    """
    from json import dumps, loads
    request_data = [{'jsonrpc': '2.0', 'method': method, 'id': 1, 'params': params or {}} for params in list_params]
    request = dumps(request_data)
    log(f'Executing JSON-RPC: {{{request}}}')
    raw_response = xbmc.executeJSONRPC(request)
    if 'error' in raw_response: raise IOError(f'JSONRPC-Error {raw_response}')
    return loads(raw_response)


def taddonid(add):
    try: return addon(add)
    except: return False


def read_file(path):
    with open(path, 'r', encoding='utf8', errors='ignore') as logf:
        contents = logf.read()
    return contents


def check_backup_dir():
    try:
        if not os.path.exists(backupdir): makeDirs(backupdir)
    except Exception as e:
        infoDialog(f'[COLOR red]Backup Dir Not Found: Create one First![CR]{e}[/COLOR]')


def getViewType():
    mychoice = 'Default'
    my_options = ['Default', 'Info Wall', 'Landscape', 'ShowCase', 'ShowCase2', 'Wide List', 'Shift', 'Icons', 'Banner', 'Fanart', 'Wall', '[ [B] Close [/B] ]']
    mychoice = SelectDialog(AddonTitle, my_options, key=False)
    viewType2 = '50'
    if mychoice == 'Default': viewType2 = '50'
    elif mychoice == 'Info Wall': viewType2 = '51'  # Poster
    elif mychoice == 'Landscape': viewType2 = '52'  # Icon Wall
    elif mychoice == 'ShowCase': viewType2 = '53'  # Shift
    elif mychoice == 'ShowCase2': viewType2 = '54'  # Info Wall
    elif mychoice == 'Wide List': viewType2 = '55'
    elif mychoice == 'Shift': viewType2 = '57'
    elif mychoice == 'Icons': viewType2 = '500'  # Wall
    elif mychoice == 'Banner': viewType2 = '501'
    elif mychoice == 'Fanart': viewType2 = '502'
    elif mychoice == 'Wall': viewType2 = '503'
    elif mychoice == '[ [B] Close [/B] ]': return
    setSetting('viewType', mychoice)
    setSetting('viewType2', str(viewType2))
    execute(f'Container.SetViewMode({int(viewType2)})')
    return


def setView(content, viewType):
    if content: content(int(sys.argv[1]), content)
    if getSetting('auto-view') == 'true':
        views = getSetting('viewType2')
        if views == '50' and kodi_version >= 17 and current_skin() == 'skin.estuary': views = '55'
        if views == '500' and kodi_version >= 17 and current_skin() == 'skin.estuary': views = '50'
        log(f'@@@@@@@@@  views {views}')
        return execute(f'Container.SetViewMode({views})')
    else:
        views = getCurrentViewId()
        log(f'@@@@@@@@@ get  views {views}')
        return execute(f'Container.SetViewMode({views})')


def colorChoice():
    chosen_color = color_chooser(no_color=True)
    setSetting('my_ColorChoice', chosen_color)
    execute('Container.Refresh')


def color_chooser(no_color=False):
    color_chart = ['black', 'white', 'whitesmoke', 'gainsboro', 'lightgray', 'silver', 'darkgray', 'gray', 'dimgray', 'snow', 'floralwhite', 'ivory', 'beige', 'cornsilk', 'antiquewhite', 'bisque', 'blanchedalmond', 'burlywood', 'darkgoldenrod', 'ghostwhite', 'azure', 'lightsaltegray', 'lightsteelblue', 'powderblue', 'lightblue', 'skyblue', 'lightskyblue', 'deepskyblue', 'dodgerblue', 'royalblue', 'blue',
        'mediumblue', 'midnightblue', 'navy', 'darkblue', 'cornflowerblue', 'slateblue', 'slategray', 'yellowgreen', 'springgreen', 'seagreen', 'steelblue', 'teal', 'fuchsia', 'deeppink', 'darkmagenta', 'blueviolet', 'darkviolet', 'darkorchid', 'darkslateblue', 'darkslategray', 'indigo', 'cadetblue', 'darkcyan', 'darkturquoise', 'turquoise', 'cyan', 'paleturquoise', 'lightcyan', 'mintcream', 'honeydew', 'aqua',
        'aquamarine', 'chartreuse', 'greenyellow', 'palegreen', 'lawngreen', 'lightgreen', 'lime', 'mediumspringgreen', 'mediumturquoise', 'lightseagreen', 'mediumaquamarine', 'mediumseagreen', 'limegreen', 'darkseagreen', 'forestgreen', 'green', 'darkgreen', 'darkolivegreen', 'olive', 'olivedab', 'darkkhaki', 'khaki', 'gold', 'goldenrod', 'lightyellow', 'lightgoldenrodyellow', 'lemonchiffon', 'yellow', 'seashell',
        'lavenderblush', 'lavender', 'lightcoral', 'indianred', 'darksalmon', 'lightsalmon', 'pink', 'lightpink', 'hotpink', 'magenta', 'plum', 'violet', 'orchid', 'palevioletred', 'mediumvioletred', 'purple', 'maroon', 'mediumorchid', 'mediumpurple', 'mediumslateblue', 'thistle', 'linen', 'mistyrose', 'palegoldenrod', 'oldlace', 'papayawhip', 'moccasin', 'navajowhite', 'peachpuff', 'sandybrown', 'peru', 'chocolate',
        'orange', 'darkorange', 'tomato', 'orangered', 'red', 'crimson', 'salmon', 'coral', 'firebrick', 'brown', 'darkred', 'tan', 'rosybrown', 'sienna', 'saddlebrown']
    color_display = [f'[COLOR={i}]{i.capitalize()}[/COLOR]' for i in color_chart]
    if no_color:
        color_chart.insert(0, 'No Color')
        color_display.insert(0, 'No Color')
    choice = SelectDialog('Select Color scheme...', color_display, False)
    if not choice: return
    return choice.split(']')[0].replace('[COLOR=', '')


def ForceClose():
    # choice = yesnoDialog('Force Close Kodi', 'You are about to close Kodi', 'Would you like to continue?', nolabel = 'No, Cancel', yeslabel = 'Yes, Close')
    choice = YesNoDialog('Force Close Kodi', 'You are about to close Kodi[CR]Would you like to continue?', yes='Yes, Close', no='No, Cancel')
    if choice == 0: return
    myplatform = platform()
    log(f'Platform: {str(myplatform)}')
    # log('Force close failed!  Trying alternate methods.')
    if myplatform == 'osx':  # OSX
        _ForceClose('############ try osx force close #################', 'killall -9 XBMC', 'killall -9 Kodi', )
        OkDialog('[B]WARNING !!![/B]', 'If you\'re seeing this message it means the force close[CR]was unsuccessful. Please force close XBMC/Kodi DO NOT exit cleanly via the menu.')
    elif myplatform == 'linux':  # Linux
        _ForceClose('############ try linux force close #################', 'killall XBMC', 'killall Kodi', )
        _ForceClose('############ try linux force close #################''killall -9 xbmc.bin', 'killall -9 kodi.bin', )
        OkDialog('[B]WARNING !!![/B]', 'If you\'re seeing this message it means the force close[CR]was unsuccessful. Please force close XBMC/Kodi DO NOT exit cleanly via the menu.')
    elif myplatform == 'android':  # Android
        _ForceClose('############ try android force close #################', 'adb shell am force-stop org.xbmc.kodi', 'adb shell am force-stop org.kodi', )
        _ForceClose('############ try android force close #################', 'adb shell am force-stop org.xbmc.xbmc', 'adb shell am force-stop org.xbmc', )
        _ForceClose('############ try android force close #################', 'adb shell kill org.xbmc.kodi', 'adb shell kill org.kodi', )
        _ForceClose('############ try android force close #################', 'adb shell kill org.xbmc.xbmc', 'adb shell kill org.xbmc', )
        _ForceClose('############ try android force close #################', 'Process.killProcess(android.os.Process.org.xbmc,kodi());', 'Process.killProcess(android.os.Process.org.kodi());', )
        _ForceClose('############ try android force close #################', 'Process.killProcess(android.os.Process.org.xbmc.xbmc());', 'Process.killProcess(android.os.Process.org.xbmc());', )
        OkDialog(AddonTitle, 'Press the HOME button on your remote and [CR][B]FORCE STOP[/B] KODI via the Manage Installed Applications menu in settings[CR]on your Amazon home page then re-launch KODI')
    elif myplatform == 'windows':  # Windows
        _ForceClose('############ try windows force close #################', '@ECHO off', 'tskill XBMC.exe', )
        _ForceClose('############ try windows force close #################', '@ECHO off', 'tskill Kodi.exe', )
        _ForceClose('############ try windows force close #################', '@ECHO off', 'TASKKILL /im Kodi.exe /f', )
        _ForceClose('############ try windows force close #################', '@ECHO off', 'TASKKILL /im XBMC.exe /f', )
        OkDialog('[B]WARNING !!![/B]', 'If you\'re seeing this message it means the force close[CR]was unsuccessful. Please force close XBMC/Kodi[CR]DO NOT exit cleanly via the menu.', )
    else:  #ATV
        log('############ try atv force close #################')
        try: os.system('killall AppleTV')
        except: pass
        _ForceClose('############ try raspbmc force close #################', 'sudo initctl stop kodi', 'sudo initctl stop xbmc', )
        OkDialog('[B]WARNING !!![/B]', 'If you\'re seeing this message it means the force close[CR]was unsuccessful. Please force close XBMC/Kodi DO NOT exit via the menu.[CR]iOS detected. Press and hold both the Sleep/Wake and Home button for at least 10 seconds, until you see the Apple logo.')


def _ForceClose(arg1, arg2, arg3):
    log(arg1)
    try: os.system(arg2)
    except: pass
    try: os.system(arg3)
    except: pass


def resolveurl_link_tester(link):
    log(f'Playing Link: |{link}|')
    if link.endswith('$$all'): hmf = resolveurl.HostedMediaFile(url=link[:-5], return_all=True)
    else: hmf = resolveurl.HostedMediaFile(url=link)
    if not hmf:
        log(f'Indirect hoster_url not supported by smr: {link}')
        infoDialog(f'Link Not Supported: {link}')
        return False
    resolvers = [item.name for item in hmf.get_resolvers(validated=True)]
    log(f'Link Supported: |{link}| Resolvers: {", ".join(resolvers)}')

    try:
        if link.endswith('$$all'):
            allfiles = hmf.resolve()
            names = [x.get('name') for x in allfiles]
            item = xbmcgui.Dialog().select('Select file to play', names, preselect=0)
            if item == -1: return False
            stream_url = allfiles[item].get('link')
            if resolveurl.HostedMediaFile(stream_url): stream_url = resolveurl.resolve(stream_url)
        else: stream_url = hmf.resolve()
        if not stream_url or not isinstance(stream_url, str):
            try: msg = stream_url.msg
            except: raise Exception(link)
    except Exception as e:
        try: msg = str(e)
        except: msg = link
        infoDialog(f'Resolve Failed: {msg}')
        return False
    log(f'Link Resolved: |{link} >>> {stream_url}|')
    listitem = xbmcgui.ListItem(path=stream_url)
    # listitem.setContentLookup(False)
    listitem.setProperty("Video", "true")
    listitem.setProperty('IsPlayable', 'true')
    if '.mpd' in stream_url:
        listitem.setProperty('inputstream', 'inputstream.adaptive')
        listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        listitem.setMimeType('application/dash+xml')
        listitem.setContentLookup(False)
        if '|' in stream_url:
            stream_url, strhdr = stream_url.split('|')
            listitem.setProperty('inputstream.adaptive.stream_headers', strhdr)
            listitem.setPath(stream_url)
    player = xbmc.Player()
    player.play(stream_url, listitem)
    # xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)