# -*- coding: UTF-8 -*-

from datetime import date

from modules.control import AddonID, AddonVersion, check_backup_dir, getfuture_date, getSetting, infoDialog, log, packages, setSetting, thumbs
from modules.maintenance import clean_MyVideos_db, clean_oldlog, clearCache, purgePackages, thumb_cleaner
from modules.toolz import Folder_Size, ForceUpdateCheck, resetResolversCache
from modules.traktit import reset_upd_setting, skin_backup_restore
from modules.upd_yt_api import set_api


class AutoRun:
    def run(self):

        notify_mode = getSetting('notify_mode')
        auto_checkup = getSetting('auto_check4updates')

        if notify_mode == 'true':
            packagesdir_size, unit1 = Folder_Size(packages)
            thumbnails_size, unit2 = Folder_Size(thumbs)
            infoDialog(f'Packages: [B]{packagesdir_size} {unit1}[/B] thumbnails: [B]{thumbnails_size} {unit2} [/B] ')
            log(f'Packages: {packagesdir_size} {unit1} | Thumbnails: {thumbnails_size} {unit2}')
        # else: log('[notify mode] Not Enabled')

        if auto_checkup == 'true': ForceUpdateCheck()

        autoclean = getSetting('autoclean')
        autonext = getSetting('autonextacleannsave')
        atoday = date.today()
        current_date = atoday.strftime('%Y-%m-%d')
        log(f'autoclean : {repr(autoclean)} current_date : {repr(current_date)} autonext : {repr(autonext)}')
        log(f'autoclean: {autoclean == "true"} autonext <= current_date : {autonext.replace("-", "") <= current_date.replace("-", "")}')
        check_backup_dir()
        clean_oldlog()
        if getSetting('skin_backup'): skin_backup_restore()
        # else: skin_backup_restore()

        if autoclean == 'true' and autonext.replace('-', '') <= current_date.replace('-', ''):
            log(f'[ {AddonID} Startup ] [ v.{AddonVersion} ]')
            # clen_wiz_file()
            filesize = int(getSetting('filesize_alert'))
            filesize_thumb = int(getSetting('filesizethumb_alert'))
            autocleanfeq = getSetting('autocleanfeq')
            autocleanfeq = int(autocleanfeq) if autocleanfeq.isdigit() else 0
            autosetting = getSetting('autosetting')
            autocache = getSetting('clearcache')
            autopackages = getSetting('clearpackages')
            autothumbs = getSetting('clearthumbs')
            keeptrakt = getSetting('keeptrakt')
            next_run = getfuture_date(autocleanfeq)

            if autocache == 'true':
                clearCache('noverbose')
                resetResolversCache()
                clean_MyVideos_db()
                log('[Auto Clean Up] Cache: is Done')
            else: log('[Auto Clean Up] Cache: Off')
            if autothumbs == 'true':
                thumbnails_size, unit2 = Folder_Size(thumbs)
                if int(thumbnails_size) > filesize_thumb and unit2 == 'MB':
                    thumb_cleaner()
                    log('[Auto Clean Up] Old Thumbs: is Done')
            else: log('[Auto Clean Up] Old Thumbs: Off')
            if autopackages == 'true':
                packagesdir_size, unit1 = Folder_Size(packages)
                if int(packagesdir_size) > filesize and unit1 == 'MB':
                    purgePackages('noverbose')
                    log('[Auto Clean Up] Packages: is Done')
            if autosetting:
                reset_upd_setting()
                # Delete_Crash_Logs('noverbose')
                log('[Auto Clean Up] Setting files: is Done')
                try:
                    set_api('noverbose')
                    log('[Auto Clean Up] Youtube API upd: is Done')
                except: pass
            else: log('[Auto Clean Up] setting: Off')
            # if keeptrakt == 'true':
                # trakt('update', 'all')
                # log('[Trakt Data] Saved all Trakt Data')
            # else:
                # log('[Trakt Data] Not Enabled')
            log(f'[Auto Clean Up] Next Clean Up will be on : {next_run}  Today is : {current_date}')
            try:
                setSetting('autonextacleannsave', f'{next_run}')
                setSetting('autolastacleannsave', f'{current_date}')
            except: pass
        return
