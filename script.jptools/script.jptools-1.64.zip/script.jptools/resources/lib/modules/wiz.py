# -*- coding: UTF-8 -*-

import re
import shutil
import sys
import time
import zipfile as zfile
from datetime import datetime
from os import listdir, rmdir, walk
from os.path import abspath, basename, normpath, sep
from urllib.parse import quote_plus
from urllib.request import FancyURLopener

from modules.control import AddonID, AddonTitle, SelectDialog, addondata, color1, color2, condVisibility, deleteFile, dialog, dp, execute, existsPath, get_keyboard, homepath, infoDialog, joinPath, jsonrpc, kodi_version, log, makeDirs, openSettings, read_file, setting, sleep, transPath, userdata, userdatapath
from modules.maintenance import clearCache


def ENABLE_WIZARD():
    try:
        query = f'{{"jsonrpc":"2.0", "method":"Addons.SetAddonEnabled","params":{{"addonid":"{AddonID}","enabled":true}}, "id":1}}'
        jsonrpc(query)
    except: pass


def REMOVE_EMPTY_FOLDERS(folder=None):
    if folder is None: folder = homepath
    total = 0
    for root, dirs, files in walk(folder, topdown=True):
        if len(dirs) == 0 and len(files) == 0 and 'backupdir' not in dirs:
            shutil.rmtree(joinPath(root))
            total += 1
            log(f'Empty Folder: {root}')
    log(f'Total folders Removed : {total}')
    infoDialog(f'[COLOR {color2}]Total folders Removed : {total}[/COLOR]')


def FIX_SPECIAL():
    homepath.replace(r'\\', '/')
    encodedpath = quote_plus(homepath)
    encodedpath2 = quote_plus(homepath).replace('%3A', '%3a').replace('%5C', '%5c')
    dp.create(AddonTitle, 'Renaming paths...')
    for root, dirs, files in walk(userdata):
        for file in files:
            if file.endswith('.xml') or file.endswith('.hash') or file.endswith('.properies'):
                # log(f'FIX_SPECIAL file: {root} {file}')
                dp.update(0, f'[COLOR {color2}]Scanning: [COLOR {color1}]{root.replace(homepath, "")}[/COLOR][CR][COLOR {color1}]{file}[/COLOR][CR]Please Wait[/COLOR]')
                a = read_file(joinPath(root, file))
                b = a.replace(homepath, 'special://home/').replace(encodedpath, 'special://home/').replace(encodedpath2, 'special://home/').replace(r'\\', '/')
                with open(joinPath(root, file), 'w', encoding='utf8') as logf:
                    logf.write(str(b))
                if dp.iscanceled():
                    dp.close()
                    infoDialog(f'[COLOR {color2}]Convert Path Cancelled[/COLOR]')
                    sys.exit()
    log('[Convert Paths to Special] Complete')
    dp.close()
    infoDialog(f'[COLOR {color2}]Convert Path to Special is done.[/COLOR]')


def RESTOREFAV():
    FAVdest = joinPath(addondata, 'favs')  # (Favs stuff)
    FAVfile = joinPath(FAVdest, 'favourites.xml')  # (Favs stuff)
    if existsPath(FAVfile):
        yes_pressed = dialog.yesno('Do you want to Restore your favorites?', 'Click Yes if you want?')
        if yes_pressed == 0: return
        elif yes_pressed == 1:
            dp.create(AddonTitle, 'Restoring')
            shutil.copy(FAVfile, userdatapath)
            sleep(5)
            dp.close()
            infoDialog('[B]Your favorites are Restored![/B]')
    else: infoDialog('[B]No Backup found![/B]')


def BACKUPFAV():
    FAVOURITES = joinPath(userdatapath, 'favourites.xml')  # (Favs stuff)
    FAVdest = joinPath(addondata, 'favs')  # (Favs stuff)
    FAVfile = joinPath(FAVdest, 'favourites.xml')  # (Favs stuff)
    if not existsPath(FAVdest): makeDirs(FAVdest)
    if existsPath(FAVOURITES):
        yes_pressed = dialog.yesno('Do you want to Back-up your favorites?', 'Click Yes if you want?')
        if yes_pressed == 0: return
        elif yes_pressed == 1:
            dp.create(AddonTitle, 'Backing Up Favourites')
            shutil.copy(FAVOURITES, FAVdest)
            sleep(10)
            dp.close()
            infoDialog('[B]Your favorites are Backed up.![/B]')
    else: infoDialog('[B]You have no Favourites![/B]')


def DELFAV():
    FAVdest = joinPath(addondata, 'favs')  # (Favs stuff)
    FAVfile = joinPath(FAVdest, 'favourites.xml')  # (Favs stuff)
    if existsPath(FAVfile):
        yes_pressed = dialog.yesno('Do you want to Delete your favorites?', 'Click Yes if you want?')
        if yes_pressed == 0: return
        elif yes_pressed == 1:
            shutil.rmtree(joinPath(FAVdest))  #(FAVdest)
            infoDialog('[B]COMPLETE[/B][CR]Backed up deleted.')
    else: infoDialog('[B]No Backups to remove![/B]')


def FRESHSTART(mode='verbose'):
    EXCLUDES = [AddonID, 'backupdir', 'backup.zip', 'script.module.requests', 'script.module.urllib3', 'script.module.chardet', 'script.module.idna', 'script.module.certifi', 'repository.JPB']
    exclude_files = ['sources.xml', 'passwords.xml', 'mediasources.xml', 'advancedsettings.xml']
    if mode != 'silent': yes_pressed = dialog.yesno('Are you absolutely certain you want to wipe this install?', 'All addons EXCLUDING THIS WIZARD will be completely wiped!')
    else: yes_pressed = 1
    if yes_pressed == 0: return
    elif yes_pressed == 1:
        dp.create(AddonTitle, 'Wiping Install')
        try:
            for root, dirs, files in walk(homepath, topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                files[:] = [f for f in files if f not in exclude_files]
                for name in files:
                    try:
                        deleteFile(joinPath(root, name))
                        rmdir(joinPath(root, name))
                    except: pass
                for name in dirs:
                    try:
                        rmdir(joinPath(root, name))
                        rmdir(root)
                    except: pass
        except: pass
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    # RESTOREFAV()
    ENABLE_WIZARD()
    if mode != 'silent': dialog.ok(AddonTitle, 'Wipe Successful, The interface will now be reset...')
    # execute('Mastermode')
    if mode != 'silent': execute('LoadProfile(Master user)')


def skinswap():
    skinswapped = 0
    #SWITCH THE SKIN IF THE CURRENT SKIN IS NOT CONFLUENCE
    from modules.control import current_skin
    from modules.skinz import swapSkins
    current_skin = current_skin()
    log(f'skin: {current_skin}')
    # sys.exit(1)
    if current_skin not in ['skin.estuary']:
        choice = dialog.yesno(AddonTitle, 'Swap to the default Kodi Skin...[CR]Do you want to Proceed?', yeslabel='Yes', nolabel='No')
        if choice == 1:
            skin = 'skin.estuary'
            swapSkins(skin)
            skinswapped = 1
            time.sleep(1)
    #IF A SKIN SWAP HAS HAPPENED CHECK IF AN OK DIALOG (CONFLUENCE INFO SCREEN) IS PRESENT, PRESS OK IF IT IS PRESENT
    # sys.exit()
    if skinswapped == 1 and not condVisibility('Window.isVisible(yesnodialog)'):
        execute('Action(Select)')
    #IF THERE IS NOT A YES NO DIALOG (THE SCREEN ASKING YOU TO SWITCH TO CONFLUENCE) THEN SLEEP UNTIL IT APPEARS
    if skinswapped == 1:
        while not condVisibility('Window.isVisible(yesnodialog)'): time.sleep(1)
    #WHILE THE YES NO DIALOG IS PRESENT PRESS LEFT AND THEN SELECT TO CONFIRM THE SWITCH TO CONFLUENCE.
    if skinswapped == 1:
        while condVisibility('Window.isVisible(yesnodialog)'):
            execute('Action(Left)')
            execute('Action(Select)')
            time.sleep(1)
    if skinswapped == 1:
        skin = skin
        #CHECK IF THE SKIN IS NOT CONFLUENCE
        if skin not in ['skin.estuary']:
            choice = dialog.yesno(AddonTitle, '[B]ERROR: MAYBE AUTOSWITCH WAS NOT SUCCESFUL[/B][CR]CLICK YES TO MANUALLY SWITCH TO CONFLUENCE NOW.[CR]OR YOU CAN PRESS NO AND ATTEMPT THE AUTO SWITCH AGAIN IF YOU WISH.', yeslabel='YES', nolabel='NO')
            if choice == 1:
                execute('ActivateWindow(appearancesettings)')
                return
            else: sys.exit(1)


def _pbhook(numblocks, blocksize, filesize, dp, start_time):
    try:
        percent = min(numblocks * blocksize * 100 / filesize, 100)
        currently_downloaded = float(numblocks) * blocksize / (1024 * 1024)
        kbps_speed = numblocks * blocksize / (time.time() - start_time)
        if kbps_speed > 0 and percent != 100: eta = (filesize - numblocks * blocksize) / kbps_speed
        else: eta = 0
        kbps_speed /= 1024
        total = float(filesize) / (1024 * 1024)
        mbs = f'{currently_downloaded:.02f} MB of {total:.02f} MB'
        e = f'Speed: {kbps_speed:.02f} Kb/s '
        e += 'ETA: {:02d}'.format(divmod(eta, 60))
        string = 'Downloading... Please Wait...'
        dp.update(percent, f'{mbs}[CR]{e}[CR]{string}')
    except:
        percent = 100
        dp.update(percent)
        dp.close()
        return
    if dp.iscanceled():
        dp.close()
        raise Exception('Canceled')


class customdownload(FancyURLopener):
    version = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11'


def downloader(url, dest, dp=None):
    if not dp: dp.create(AddonTitle, '')
    dp.update(0)
    start_time = time.time()
    customdownload().retrieve(url, dest, lambda nb, bs, fs, url=url: _pbhook(nb, bs, fs, dp, start_time))


def ExtractNOProgress(_in, _out):
    try:
        if not _out.endswith(sep):
            _out += sep
        _in = transPath(_in)
        _out = transPath(_out)
        # log(f'_in:: : {_in}\n_out:: : {_out}')
        with zfile.ZipFile(_in) as zf:
            zf.extractall(_out)
    except Exception as e: log(f'Error:: : {e}')
    return True


def ExtractWithProgress(_in, _out, dp):
    zin = zfile.ZipFile(_in, 'r')
    nFiles = float(len(zin.infolist()))
    errors = 0
    for count, item in enumerate(zin.infolist(), start=1):
        update = count / nFiles * 100
        try: name = basename(item.filename)
        except: name = item.filename
        dp.update(int(update), f'Extracting... Errors:  {errors}[CR][B]{name}[/B]', )
        zin.extract(item, _out)
    return True


def ExtractZip(_in, _out, dp=None):
    if dp is not None: return ExtractWithProgress(_in, _out, dp)
    return ExtractNOProgress(_in, _out)


def CreateZip(folder, zip_filename, message_header, message1, exclude_dirs, exclude_files):
    abs_src = abspath(folder)
    for_progress = []
    ITEM = []
    dp.create(message_header, message1)
    try: deleteFile(zip_filename)
    except: pass
    for base, dirs, files in walk(folder):
        ITEM.extend(iter(files))
    N_ITEM = len(ITEM)
    count = 0
    line = 'Backing Up[CR]FILES: %s/%s [CR]File: [B]%s[/B][CR]Folder: [B]%s[/B][CR]Please Wait...'
    zip_file = zfile.ZipFile(zip_filename, 'w', zfile.ZIP_DEFLATED, allowZip64=True)
    # log(f'folder: {folder}')
    for dirpath, dirnames, filenames in walk(folder):
        try:
            dirnames[:] = [d for d in dirnames if d not in exclude_dirs]
            filenames[:] = [f for f in filenames if f not in exclude_files and not re.search(r'.pyo|.pyc|.csv|.log|.mp4|.mkv|.flv|.srt|kodi_crashlog|kodi_stacktrace', str(f), re.I)]
            for file in filenames:
                if '_backup' in zip_filename and file.endswith('.db') and 'addon_data' in dirpath:
                    continue
                count += 1
                try:
                    dirname = dirpath.replace(folder, '')
                    dir_name = dirname.replace('addons', '').replace('userdata', '').replace('addon_data', '')  #.replace('\\','')
                    dir_name = dir_name.strip()
                    # dir_name = dir_name.split('/')[0]
                    # dir_name = f'{dirname[0]} _ {dirname[1]}'
                except: dir_name = 'None'
                # log(f'dir_name: {dir_name}')
                for_progress.append(file)
                progress = len(for_progress) / float(N_ITEM) * 100
                dp.update(int(progress), line % (str(count), str(N_ITEM), str(file), dir_name))
                file = joinPath(dirpath, file)
                file = normpath(file)
                arcname = file[len(abs_src) + 1:]
                zip_file.write(file, arcname)
        except Exception as e: log(f'Error:: : {e}')
    zip_file.close()
    if dp.iscanceled():
        dp.close()


def restoreFolder():
    names = []
    links = []
    zipFolder = transPath(setting('restore.path'))
    if zipFolder == '' or zipFolder is None:
        infoDialog('Please Setup a Zip Files Location first')
        openSettings(query='2.0')
        return
    for zipF in listdir(zipFolder):
        if zipF.endswith('.zip'):
            url = transPath(joinPath(zipFolder, zipF))
            names.append(zipF)
            links.append(url)
    select = SelectDialog('Select zip file to restore', names)
    if select != -1: restore(links[select])


def restore(zipF):
    if yesDialog := dialog.yesno(AddonTitle, 'This will overwrite all your current settings ... Are you sure?', yeslabel='Yes', nolabel='No', ):
        try:
            dp.create('Restoring File In Progress...')
            dp.update(0, '[CR]In Progress...[CR]Extracting Zip Please Wait')
            ExtractZip(zipF, homepath, dp)
            dialog.ok(AddonTitle, 'Restore Complete')
            log('[Restore Build: ] Complete')
            from modules.control import ForceClose
            ForceClose()  #execute('ShutDown') #Testing with ForceClose()
        except: pass


def buildInstaller(url):
    if destination := dialog.browse(type=0, heading='Select Download Directory', shares='files', useThumbs=True, treatAsFolder=True, enableMultiple=False, ):
        dest = transPath(joinPath(destination, 'custom_build.zip'))
        downloader(url, dest)
        time.sleep(2)
        dp.create('Installing Build')
        dp.update(0, '[CR]In Progress...[CR]Extracting Zip Please Wait')
        ExtractZip(dest, homepath, dp)
        time.sleep(2)
        dp.close()
        dialog.ok(AddonTitle, 'Installation Complete...[CR]Your interface will now be reset[CR]Click ok to Start...')
        log('[Installing Build: ] Complete')
        execute('LoadProfile(Master user)')


def backup(mode='full'):
    backupdir = setting('download.path')
    if backupdir == '' or backupdir is None:
        infoDialog('Please Setup a Path for Downlads first')
        openSettings(query='1.3')
        return
    if mode == 'full':
        defaultName = f'kodi_{str(kodi_version).replace(".", "_")}_backup'
        BACKUPDATA = homepath
        FIX_SPECIAL()
    elif mode == 'userdata':
        defaultName = f'kodi_{str(kodi_version).replace(".", "_")}_userdata'
        BACKUPDATA = userdata
    else: return
    if existsPath(BACKUPDATA):
        if backupdir != '':
            name = get_keyboard(default=defaultName, heading='Name your Backup')
            today = datetime.now().strftime('%Y%m%d%H%M')
            today = re.sub('[^0-9]', '', str(today))
            zipDATE = f'_{today}.zip'
            name = re.sub(' ', '_', name) + zipDATE
            backup_zip = transPath(joinPath(backupdir, name))
            try: clearCache(mode='silent')  #maintenance.deleteThumbnails(mode = 'silent')  #maintenance.purgePackages(mode = 'silent')
            except: pass
            exclude_files = [name, 'Textures13.db', '.DS_Store', 'advancedsettings.xml', 'Thumbs.db', '.gitignore', 'gencache.tdb', 'smb.conf']
            exclude_dirs = ['color_palette', '.git', '.idea', 'packages', 'backupdir', 'cache', 'system', 'Thumbnails', 'peripheral_data', 'temp', 'My_Builds', 'keymaps', 'cdm', '.smb', 'inputstream.adaptive', 'inputstream.ffmpegdirect', 'inputstream.rtmp', 'vfs.sftp']
            CreateZip(BACKUPDATA, backup_zip, 'Creating Backup', 'Backing up files', exclude_dirs, exclude_files)
            dialog.ok(AddonTitle, 'Backup complete')
            log(f'[{mode} Backup: ] Complete')
        else: dialog.ok(AddonTitle, 'No backup location found. Please setup your Backup location')