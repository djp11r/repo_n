# -*- coding: utf-8 -*-

"""
        inspired from : https://github.com/rrosajp/plugin.program.yt-setup
        License summary below, for more details please read license.txt file

        This program is free software: you can redistribute it and/or modify
        it under the terms of the GNU General Public License as published by
        the Free Software Foundation, either version 2 of the License, or
        (at your option) any later version.
        This program is distributed in the hope that it will be useful,
        but WITHOUT ANY WARRANTY; without even the implied warranty of
        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
        GNU General Public License for more details.
        You should have received a copy of the GNU General Public License
        along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from urllib.parse import quote

from modules.control import addon, addonInfo, dialog, execute, infoDialog, infoLabel

YT_VERSION = infoLabel('System.AddonVersion(plugin.video.youtube)').partition('~')[0].replace('.', '')
if '+' in YT_VERSION: YT_VERSION = YT_VERSION.split('+')[0]
credential_dict = {'client_id': '77294159872-mqptakqrjp88fu4st5qn8k5r8rlq3dt0.apps.googleusercontent.com', 'api_key': 'AIzaSyCjf8izIeXa1oFZo7_HeL0WgrOq1WF_I1k', 'client_secret': '6f1FQe7ClAsu-S4YrXee6OX_'}


def set_api(mode='verbose'):
    conditions = [bool(addon('plugin.video.youtube').getSetting('youtube.api.id')), bool(addon('plugin.video.youtube').getSetting('youtube.api.key')), bool(addon('plugin.video.youtube').getSetting('youtube.api.secret'))]

    if any(conditions):
        if mode == 'verbose' and not dialog.yesno(addonInfo('name'), 'Current settings will be overwritten!', yeslabel='Continue', nolabel='Cancel',):
            return
        if int(YT_VERSION) <= 670: conditions.insert(0, addon('plugin.video.youtube').getSetting('youtube.api.enable') == 'true')

        # if dialog.yesno("Youtube API Setup", "Youtube Setup addon is now ready to store your keys", yeslabel="Proceed", nolabel="Cancel"):
        client_id = credential_dict['client_id']
        client_secret = credential_dict['client_secret']
        api_key = credential_dict['api_key']

        def call():
            plugin_call = 'plugin://plugin.video.youtube/api/update/?enable=true'
            route = f'{plugin_call}&client_id={quote(client_id)}&client_secret={quote(client_secret)}&api_key={quote(api_key)}'
            execute(f'RunPlugin({route})')

        if int(YT_VERSION) >= 543 and addon('plugin.video.youtube').getSetting('route543') == 'true': call()
        else:
            if int(YT_VERSION) < 670: addon('plugin.video.youtube').setSetting('youtube.api.enable', 'true')
            addon('plugin.video.youtube').setSetting('youtube.api.id', client_id)
            addon('plugin.video.youtube').setSetting('youtube.api.key', api_key)
            addon('plugin.video.youtube').setSetting('youtube.api.secret', client_secret)
            if mode == 'verbose': infoDialog('Success!\nYoutube API Setup', icon='INFO')  # else:  # infoDialog("Cancel", icon='INFO')
