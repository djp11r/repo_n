# -*- coding: utf-8 -*-

import glob
import re
import datetime
import shutil
import time
import traceback
from os import listdir, sep, walk, makedirs, rename, remove
from os.path import basename, exists, isdir

from bs4 import BeautifulSoup

import xbmcvfs


from modules.control import joinPath, homepath, addondata

ADDONS = joinPath(homepath, 'addons')
USERDATA = joinPath(homepath, 'userdata')

ADDOND = joinPath(USERDATA, 'addon_data')
TRAKTFOLD = joinPath(addondata, 'trakt')

maxlines = 300

datai = ['players_url', 'trakt_watchedindicators', 'trakt_unwatchedcounts', 'trakt_management', 'trakt_token', 'trakt.userHidden', 'furk_password', 'furk_login', 'imdb.user', 'tm.user', 'trakt_access_token', 'trakt_expires_at', 'trakt_indicators_active', 'trakt_refresh_token', 'trakt_user', 'trakt_api_client_id', 'trakt_api_client_secret', 'trakt.auth', 'trakt.refresh', 'trakt.token', 'trakt.user', 'trakt.clientid',
         'trakt.scrobbling', 'trakt.secret', 'trakt.username']
activatet = 'RunPlugin(plugin://plugin.video.%s/?action=authTrakt)'
addon_folder = ['plugin.googledrive', 'plugin.video.bapsyt', 'plugin.video.deccandelight', 'plugin.video.gdrive', 'plugin.video.infinite', 'plugin.video.infinity', 'plugin.video.youtube']
file_to_copy = ['settings.xml', 'accounts.db', 'access_manager.json', 'api_keys.json']


def makedirs_dest(dest):
    if not exists(dest):
        makedirs(dest)


def countFiles(directory):
    files = []
    if isdir(directory):
        for path, dirs, filenames in walk(directory):
            files.extend(filenames)
    return len(files)


def zipfolder(foldername, target_dir, zips_dir):
    """
    as the name suggest
    :param foldername:
    :param target_dir:
    :param zips_dir:
    """
    try:
        from modules.control import log
        from modules.wiz import zfile
        zipobj = zfile.ZipFile(zips_dir + foldername, 'w', zfile.ZIP_DEFLATED)
        rootlen = len(target_dir)  # + 1  # + 1 # this is where add 1 extra folder on
        for base, dirs, files in walk(target_dir):
            for f in files:
                fn = joinPath(base, f)
                zipobj.write(fn, joinPath(foldername, fn[rootlen:]))
        zipobj.close()
    except Exception as e:
        log("An error occurred creating zip.file!\n{}".format(e))


def copy_file(src, dest, file_to_save=None):
    # numFiles = countFiles(src)
    from modules.control import log
    try:
        if file_to_save:
            makedirs_dest(dest)
        srcFile = joinPath(src, file_to_save)
        destFile = joinPath(dest, file_to_save)
        # log('Directory from: %s\nDirectory to  : %s' % (srcFile, destFile))
        shutil.copy(srcFile, destFile)
    # Directories are the same
    except shutil.Error as e:
        log('File are the same so not copied. Error: %s' % e)
    # Any error saying that the directory doesn't exist
    except OSError as e:
        log('File does not exist not copied. Error: %s' % e)


def get_userdata():
    from modules.control import backupdir, condVisibility, log, existsPath, infoDialog, listDir
    addon_list = []
    for addon in addon_folder:
        if condVisibility('System.HasAddon(%s)' % addon):
            addon_list.append(addon)
    log('get_userdata: addon_list: %s' % (addon_list))
    for addon in addon_list:
        if existsPath(joinPath(ADDOND, addon)):
            from_src = joinPath(ADDOND, addon)
            # log('from_src: %s' % from_src)
            for file in list(listDir(from_src)):
                # log('file: %s' % file)
                if file in file_to_copy:
                    from_src = joinPath(ADDOND, addon)
                    tofile_copy = from_src.replace(homepath, '')
                    to_dest = joinPath(backupdir, "sourcexml_custom", tofile_copy)
                    if existsPath(from_src):
                        # log('addon: %s' % addon)
                        # log('get_userdata: addon: %s\nfrom_src: %s\nto_dest: %s' % (addon, from_src, to_dest))
                        copy_file(from_src, to_dest, file)
    target_dir = joinPath(backupdir, "sourcexml_custom")
    # log("This folder will b Zip target_dir: {}\n".format(target_dir))
    myfile = joinPath(backupdir, "sourcexml_custom.zip")
    if exists(myfile):
        remove(myfile)
    zipfolder("sourcexml_custom.zip", target_dir, backupdir + sep)
    # rename(joinPath(backupdir, "userdata.zip"), myfile)
    # sleep(100)
    save_for_git = "D:/GitHub/matrix_plus/repojp/etc"
    if exists(save_for_git):
        copy_file(backupdir, save_for_git, "sourcexml_custom.zip")
        infoDialog("sourcexml_custom.zip file Created in backupdir folder...")


def get_video_plugins():
    from modules.control import condVisibility
    plgn_list = []
    for adn_dir in glob.glob(joinPath(ADDOND, 'plugin.video.*')):
        ad_n = basename(adn_dir)
        if condVisibility('System.HasAddon(%s)' % ad_n):
            acnm = ad_n.split(".")[2:]
            act = ".".join(acnm)
            plgn_list.append(act)
    return plgn_list


def seting_id(who):
    from modules.control import existsPath, getSetting
    set_ck = []
    if existsPath(joinPath(ADDOND, 'plugin.video.%s' % who)):
        for plg_i in datai:
            s_id = getSetting(plg_i)
            if s_id != '':
                set_ck.append(plg_i)
    return set_ck


def trakt(do, who):
    from modules.control import existsPath, addondata, makeDirs, log, transPath
    if not existsPath(addondata):
        makeDirs(addondata)
    if not existsPath(TRAKTFOLD):
        makeDirs(TRAKTFOLD)
    if who == 'all':
        plg_list = get_video_plugins()
        for plg_i in plg_list:
            log('[Trakt Data] do: %s Addon installed: plugin.video.%s' % (do, plg_i))
            plufin_path = transPath(joinPath(ADDOND, 'plugin.video.%s' % plg_i))
            if existsPath(plufin_path):
                if do == 'clearaddon':
                    updateTrakt(do, plg_i)
                elif do == 'restore':
                    updateTrakt(do, plg_i)
                elif do == 'update':
                    updateTrakt(do, plg_i)
            else:
                log('[Trakt Data] plugin.video.%s is not installed path: %s' % (plg_i, plufin_path))  # setSetting('autonextacleannsave', str(nextsave))  #refresh()
    else:
        if who:
            if existsPath(joinPath(ADDOND, 'plugin.video.%s' % who)):
                updateTrakt(do, who)
        else:
            log('[Trakt Data] Invalid Entry: %s' % who)


def updateTrakt(do, who):
    from modules.control import taddonid, log, transPath, AddonID, infoDialog, color1, color3, existsPath, read_file
    settings = joinPath(ADDOND, 'plugin.video.%s' % who, 'settings.xml')
    filei = joinPath(TRAKTFOLD, '%s_trakt' % who)
    pathi = joinPath(ADDONS, 'plugin.video.%s' % who)
    set_ck = seting_id(who)
    log("[Trakt Data] who: %s set_ck: (%s)" % (who, set_ck))
    iconi = ''
    expires_at = str(time.time() + 60 * 60 * 24 * 365)  #modify expires at in 365 days!.
    for ipath in glob.glob(joinPath(pathi, '*icon.*')):
        iconi = ipath
    if iconi == '':
        iconi = transPath(joinPath('special://home/addons/%s' % AddonID, 'icon.png'))
    if do == 'update':
        filet = False
        try:
            if len(set_ck) > 1:
                with open(filei, 'w') as f:
                    for s_id in datai:
                        if taddonid.getSetting(s_id) != '':
                            f.write('<trakt>\n\t<id>%s</id>\n\t<value>%s</value>\n</trakt>\n' % (s_id, taddonid.getSetting(s_id)))
                infoDialog("[COLOR %s]%s[/COLOR][CR][COLOR %s]Trakt Data: Saved![/COLOR]" % (color1, who, color3), time=2000)
        except Exception as e:
            log("[Trakt Data] Unable to Update %s (%s)" % (who, str(e)))
    elif do == 'restore':
        if existsPath(filei):
            f = read_file(filei)
            g = f.replace('\n', '').replace('\r', '').replace('\t', '')
            match = re.compile('<trakt><id>(.+?)</id><value>(.+?)</value></trakt>').findall(g)
            try:
                if len(match) > 0:
                    for s_id, value in match:
                        if s_id == 'trakt_expires_at':
                            value = expires_at
                        taddonid.setSetting(s_id, value)
                        log("[Trakt Data] ### %s (%s)" % (s_id, value))
                infoDialog("[COLOR %s]%s[/COLOR][CR][COLOR %s]Trakt: Restored![/COLOR]" % (color1, who, color3), time=2000)
            except Exception as e:
                log(traceback.format_exc())
                log("[Trakt Data] Unable to Restore %s (%s)" % (who, str(e)))
        else:
            infoDialog('%s[CR]Trakt Data: [COLOR red]Not Found![/COLOR]' % who, time=2000)
    elif do == 'clearaddon':
        try:
            if existsPath(settings):
                if existsPath(filei):
                    f = read_file(filei)
                    g = f.replace('\n', '').replace('\r', '').replace('\t', '')
                    match = re.compile('<trakt><id>(.+?)</id><value>(.+?)</value></trakt>').findall(g)
                    try:
                        if len(match) > 0:
                            for s_id, value in match:
                                if taddonid.getSetting(s_id) != '':
                                    taddonid.setSetting(s_id, '')
                    except Exception as e:
                        log(traceback.format_exc())
        except Exception as e:
            log(traceback.format_exc())
            log("[Trakt Data] Unable to Clear Addon %s (%s)" % (who, str(e)))
        infoDialog("[COLOR %s]%s[/COLOR][CR][COLOR red]Addon Data: Cleared![/COLOR]" % (color1, who), time=2000)


def activateTrakt(who):
    from modules.control import transPath, existsPath, log, execute, dialog, AddonTitle, refresh
    if who:
        plufin_path = transPath(joinPath(ADDOND, 'plugin.video.%s' % who))
        if existsPath(plufin_path):
            if 'openmeta' in who:
                act = 'RunPlugin(plugin://plugin.video.openmeta/authenticate_trakt)'
            elif '' in who:
                act = 'PlayMedia(plugin://plugin.video.seren/?action=authTrakt,return,return)'
            else:
                act = activatet % who
            taddonid = 'plugin.video.%s' % who
            log('@@@ \n addon name == %s \n action == %s\n' % (taddonid, act))
            if act == '':
                taddonid.openSettings()
            else:
                url = execute(act)
        else:
            dialog.ok(AddonTitle, '%s is not currently installed.' % who)
    else:
        refresh()
        return
    check = 0
    while who == None:
        if check == 30:
            break
        check += 1
        time.sleep(10)
    refresh()


def clearSaved(who, over=False):
    from modules.control import existsPath, deleteFile, infoDialog, setSetting, color1, color2, refresh
    if who == 'all':
        for plg_i in TRAKTFOLD:
            if existsPath(plg_i):
                ad_n = basename(plg_i)
                acnm = ad_n.split("_")[0]
                clearSaved(acnm, True)
    elif who:
        file = joinPath(TRAKTFOLD, '%s_trakt' % who)
        if existsPath(file):
            deleteFile(file)
            infoDialog('[COLOR %s]%s[/COLOR][CR][COLOR %s]Trakt Data: Removed![/COLOR]' % (color1, who, color2), time=2000)
        setSetting(who, '')
    if not over:
        refresh()


def myinstall(name, url):
    from modules.control import existsPath, packages, makeDirs, AddonTitle, dp, color1, color2, deleteFile, sleep
    from modules.utilz import workingURL
    from modules.wiz import downloader, ExtractZip
    if not workingURL(url):
        return
    zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
    if not existsPath(packages):
        makeDirs(packages)
    dp.create(AddonTitle, '[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (color2, color1, name))
    zipname = zipname.replace(' ', '')
    urlsplit = url.split('/')
    lib = joinPath(packages, urlsplit[-1])
    try:
        deleteFile(lib)
    except:
        pass
    #log('@@@ %s == \n%s  \n==  %s '%(name,url,lib))
    downloader(url, lib, dp)
    sleep(500)
    title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (color2, color1, name)
    dp.update(0, 'Please Wait:[CR]%s' % title)
    if "trakt" in zipname.lower() or "script" in zipname.lower():
        dp.close()
        return
    else:
        dp.create("Extracting Zip", "In Progress...")
        dp.update(0, "Extracting Zip Please Wait")
        percent = ExtractZip(lib, homepath, dp)  # try: deleteFile(lib)  # except: pass
        time.sleep(2)
        dp.close()
        # if 'sourcexml' in zipname.lower():
            # trakt('restore', 'all')

    dp.close()  # dialog.ok(AddonTitle, '[COLOR %s]File has been successfully Updated .[/COLOR]' % color2)


def zipextr():
    from modules.control import existsPath, packages, makeDirs, transPath, infoDialog, dialog, AddonTitle, color1, color2, log, yesnoDialog
    from modules.wiz import ExtractNOProgress
    if not existsPath(packages):
        makeDirs(packages)
    mybuilds = transPath(packages)
    filelist = []
    for item in listdir(mybuilds):
        # base = joinPath(mybuilds, item)
        # if existsPath(base):
        # list.append('%s' % item)
        filelist.append(item)
    if len(filelist) == 0:
        infoDialog('Nothing in Packages Folder[CR]Zip Extractor: [COLOR red]Not Found![/COLOR]', time=2000)
        return
    # log('[unZip package file: ] filelist: %s' % filelist)
    selected = dialog.select("%s: Select the items to Extract 'package'." % AddonTitle, filelist)

    if selected == -1:
        infoDialog("[COLOR %s]Extract Item Canceled![/COLOR]" % (color2))
    else:
        item = filelist[selected]
        path = transPath(joinPath(mybuilds, item))
        log('[unZip File] selected-1: %s' % path)
        if yesnoDialog("[COLOR %s]Would you like to Extract Item [COLOR %s]%s[/COLOR] from 'package' folder?[/COLOR]" % (color2, color1, filelist[selected]), "[COLOR %s]%s[/COLOR]" % (color1, path), yeslabel="[B][COLOR green]Extract Item[/COLOR][/B]", nolabel="[B][COLOR red]No Cancel[/COLOR][/B]"):
            try:
                # deleteFile(path)
                ExtractNOProgress(path, mybuilds)
                msg = "[COLOR %s]Extract Item successful![/COLOR]" % (color2)
            except:
                msg = "[COLOR %s]Extract Item unsuccessful![/COLOR]" % (color2)
                log("[unZip File] Unable to extract: %s\n%s" % (path, traceback.format_exc()))
            infoDialog(msg, time=2000)


def clen_wiz_file():
    from modules.control import existsPath, wizlog, log, read_file
    try:
        if not existsPath(wizlog):
            f = open(wizlog, 'w');
            f.close();
            return
        a = read_file(wizlog)
        lines = a.split('\n')
        if len(lines) > maxlines:
            log(" ### found line lenght %s need to reduce to : %s" % (len(lines), maxlines / 3))
            start = len(lines) - int(maxlines / 3)
            newfile = lines[start:]
            writing = '\n'.join(newfile)
            with open(wizlog, 'w', encoding="utf8") as logf:
                logf.write(str(writing))
    except Exception as e:
        log("clen_wiz_file Error: %s" % str(e))

def errorlist(logtext):
    errors = []
    b = logtext.replace('\n', '[CR]').replace('\r', '')
    match = re.compile("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall(b)
    for item in match:
        errors.append(item)
    return errors


def errorChecking():
    # from api import TextViewer
    from modules.control import TextBox, logpath, existsPath, log, read_file, infoDialog, color1

    log_file = joinPath(logpath, 'kodi.log')
    if existsPath(log_file):
        log('[@@@ errorChecking: ] logsfound:\n %s' % log_file)
        contents = read_file(log_file)
        error1 = errorlist(contents)
        if len(error1) > 0:
            string = ''
            i = 0
            for item in error1:
                i += 1
                string += "[B][COLOR red]ERROR NUMBER %s:[/B][/COLOR]%s\n" % (str(i), item.replace(homepath, '/').replace('                                        ', ''))
            if i > 0:
                # TextViewer.text_view("%s: Errors in Log" % AddonTitle, string)
                TextBox('--[ JP Tools Log Viewer ]--', string)
        if len(error1) == 0 or i == 0:
            infoDialog("[COLOR %s]There is : %s Error[/COLOR][CR][COLOR red]In Kodi Log![/COLOR]" % (color1, len(error1)), time=2000)


def viewlog():
    from api import TextViewer
    from modules.utilz import get_log_data
    contents = get_log_data()
    TextViewer.text_view(data=contents)


def clane_adondata():
    from modules.control import dialog, AddonTitle, color1, color2, color3, existsPath, infoDialog, log
    from modules.wiz import REMOVE_EMPTY_FOLDERS
    if dialog.yesno(AddonTitle, '[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]' % (color2, color1), yeslabel='[B][COLOR %s]Remove Data[/COLOR][/B]' % color3, nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
        import shutil
        total = 0
        for folder in glob.glob(joinPath(ADDOND, '*')):
            foldername = folder.replace(ADDOND, '').replace('\\', '').replace('/', '')
            if existsPath(joinPath(ADDONS, foldername)):
                pass
            else:
                REMOVE_EMPTY_FOLDERS(folder);
                total += 1;
                log(folder);
                shutil.rmtree(folder)
        infoDialog('[COLOR %s]Clean up Uninstalled[/COLOR][CR][COLOR %s]%s Folders(s) Removed[/COLOR]' % (color1, color2, total))
    else:
        infoDialog('[COLOR %s]Remove Addon Data[/COLOR][CR][COLOR %s]Cancelled![/COLOR]' % (color1, color2))


def get_file_older_then_hrs(path, time_in_hrs=168):
    """ time_in_hrs = 168 = 24* 7 for 7days """

    st = xbmcvfs.Stat(path)
    file_time = st.st_mtime()
    time_now = datetime.datetime.now()
    time_diff = (datetime.timedelta(hours=time_in_hrs))
    past_time = time_now - time_diff
    comp_time = _get_timestamp(past_time)

    if file_time > comp_time:
        #log('old file then time_in_hrs :%s' % time_in_hrs)
        return True
    else:
        return False


def _get_timestamp(date_time):
    return int(time.mktime(date_time.timetuple()))


def dl_zip_enet(srs_f, dest_f=None):
    #xbmcvfs.copy(f_enet,packages)
    # we don't use xbmcvfs.copy because we want to wait for the action to complete
    if not dest_f:
        from modules.control import packages, log
        file = srs_f.split("/")[-1]
        # log("enet_files: %s" % str(file))
        dest_f = joinPath(packages, file)
        # log("dest_f: %s" % str(dest_f))
    srs_ = xbmcvfs.File(srs_f)
    srs__data = srs_.readBytes()
    srs_.close()
    dest_ = xbmcvfs.File(dest_f, 'w')
    dest_.write(srs__data)
    dest_.close()


def check_version_numbers(current, new):  # Compares version numbers and return True if github version is newer
    current = remov_a_z(current).split('.')
    new = remov_a_z(new).split('.')
    step = 0
    # log("current: %s new: %s" % (current, new))
    for i in current:
        if int(new[step]) > int(i):
            return True
        if int(i) > int(new[step]):
            return False
        if int(i) == int(new[step]):
            step += 1
            continue
    return False


# def compare_strings(a,b):
# result = True
# if len(a) != len(b): print('string lengths do not match!')
# for i,(x,y) in enumerate(zip(a,b)):
# if x != y:
# print(f'char miss-match {x,y} in element {i}')
# result = False
# if result: print('strings match!')
# return result


def unzip_instal_addon(install_list):
    from modules.control import transPath, execute, jsonrpc, infoLabel, log, infoDialog
    from modules.wiz import ExtractNOProgress
    from xbmc import executeJSONRPC
    HOME_ADDONS = transPath('special://home/addons')
    for addon in install_list:
        try:
            # deleteFile(path)
            ExtractNOProgress(addon['dir_'], HOME_ADDONS)  # log("install Addon: %s" % (addon['name']))
        except:
            log("[unZip File] Unable to extract: %s\n%s" % (addon,
                                                            traceback.format_exc()))  # try:  # # query = {"jsonrpc":"2.0", "method":"Addons.SetAddonEnabled","params":{"addonid":"%s" % addon['name'],"enabled": True}, "id":1}  # # log("install_list query: %s" % (query))  # # jsonrpc(query)  # value = 'true'  # query = '{{"jsonrpc":"2.0", "method":"Addons.SetAddonEnabled","params":{{"addonid":"{0}","enabled":{1}}},
            # "id":1}}'.format(addon['name'], value)  # # log("install_list query: %s" % (query))  # response = executeJSONRPC(query)  # # log("response jsonrpc: {}".format(response))  # except:  # log("Error jsonrpc: %s" % (traceback.format_exc()))
    log("Total Nos of Addon Updated: {}".format(len(install_list)))
    try:
        current_profile = infoLabel('system.profilename')
        execute('LoadProfile(%s)' % current_profile)  # infoDialog('Addons Updated Total: %s' % (len(install_list)))
    except:
        log("Error LoadProfile: %s" % (traceback.format_exc()))
        infoDialog('Error While Addons Update')


def remov_a_z(vers_str):
    vers_str = re.sub(r'[a-z]+', '', vers_str.lower())
    # vers_str = re.sub(r"(\.zip|convert|\+matrix|a|b|c|d)", "", vers_str)
    return vers_str


def intersect(List1, List2, not_match_vers=True):
    # partial match before - list for values that match from List2
    from modules.control import log
    newfiles = []
    samefiles = []
    for i in List2:
        for j in List1:
            if i.split("-")[0] == j.split("-")[0]:  # match name
                if i == j:  # match version
                    samefiles.append(i)
                if i in j:
                    continue
                p = re.findall('-', j)
                if len(p) > 1:
                    continue
                # log("current: %s p: %s len(p): %s" % (j, p, len(p)))
                current = j.split("-")[1].replace('.zip', '').replace('convert', '').replace('+matrix', '').replace('~', '')
                new = i.split("-")[1].replace('.zip', '').replace('convert', '').replace('+matrix', '').replace('~', '')
                # current = remov_a_z(j.split("-")[1])
                # new = remov_a_z(i.split("-")[1])
                # log("current: %s new: %s" % (j, i))
                # log("not_match_vers: %s current: %s new: %s" % (not_match_vers, current, new))
                try:
                    if check_version_numbers(current, new):
                        log(">>> Will install Addon: %s Current Vers: %s New Vers: %s" % (i, current, new))
                        newfiles.append(i)
                except:
                    log("Error to Check vers of Addon: %s Current Vers: %s New Vers: %s" % (i, current, new))  # if not not_match_vers: ret.append(i)
    return newfiles, samefiles


def get_adon_frm_enet():
    from modules.control import jsonrpc, getKodiVersion, platform, transPath, setting, packages, log
    query = {"jsonrpc": "2.0", "id": "1", "method": "Addons.GetAddons", "params": {"properties": ["version"]}}
    json_response = jsonrpc(query)
    # log('json_response >>> json_response: %s' % json_response)
    has_addons = []
    addonItems = json_response[0]['result']['addons']
    # log("URepo: addonItems: %s" % json_response[0]['result']['addons'])
    for addonItem in addonItems:
        # log("addonItem: %s" % addonItem)
        has_addons.append("{}-{}.zip".format(addonItem['addonid'], addonItem['version']))
    # log("Installed has_addons: %s" % has_addons)
    myplatform = platform()
    if myplatform == 'android':
        dst_dir2 = r'smb://cp:srusty@ENET/Media/Data/addons/alladdons_19/'
    else:
        dst_dir2 = r'smb://ENET/Media/Data/addons/alladdons_19/'
    # log("Installed for myplatform: %s dst_dir2: %s" % (myplatform, dst_dir2))
    enet_dir = transPath(dst_dir2)
    enet_files = xbmcvfs.listdir(enet_dir)
    from modules import maintenance
    maintenance.purgePackages()
    # log("enet_files: %s" % str(enet_files))
    # intersect_list = [l1 for l1 in has_addons if any([l2 in l1 for l2 in files[1]])]
    newfiles, samefiles = intersect(has_addons, enet_files[1])
    # log("newfiles: {}\nsamefiles: {}".format(newfiles, samefiles))
    get_newest_file = False
    age = int(setting('file_age'))
    if not newfiles and age == 24:
        intersect_list = samefiles
        # log("rescrape intersect_list: %s" % str(intersect_list))
        get_newest_file = True
    else:
        intersect_list = newfiles
    install_list = []
    for file in intersect_list:
        # log("enet file: %s" % file)
        # addn_list.append(file.split("-")[0])
        f_enet = joinPath(enet_dir, file)
        # log("need to install enet file: %s" % file)
        dl_enet = joinPath(packages, file)
        if get_newest_file:
            if get_file_older_then_hrs(f_enet, age) is True:
                # log("need to Update From f_enet: %s To dl_enet : %s" % (f_enet, dl_enet))
                dl_zip_enet(f_enet, dl_enet)
                install_list.append({"name": file.split("-")[0], "dir_": dl_enet})
        else:
            dl_zip_enet(f_enet, dl_enet)
            install_list.append({"name": file.split("-")[0], "dir_": dl_enet})  # log("need to install Addon: %s" % (file))
    log("Total addon Got: %s install_list get_adon_frm_enet: %s" % (len(install_list), install_list))
    if install_list:
        unzip_instal_addon(install_list)


def send_kodi_log_enet():
    from modules.control import condVisibility, platform, transPath, log, joinPath, logpath, infoDialog
    dst_dir = r'smb://ENET/Media/Data/'
    myplatform = platform()
    if myplatform == 'android':
        dst_dir = r'smb://cp:srusty@ENET/Media/Data/'
    enet_dir = transPath(dst_dir)
    dl_zip_enet(joinPath(logpath, 'kodi.log'), joinPath(dst_dir, 'kodi.log'))
    infoDialog('send kodi.log file to ENET.')


def get_kodi_frm_enet():
    from modules.control import condVisibility, platform, setting, transPath, log, packages
    from modules import maintenance

    maintenance.purgePackages()
    dst_dir2 = r'smb://ENET/Media/Data/Apps/'
    myplatform = platform()
    if myplatform == 'android':
        dst_dir2 = r'smb://cp:srusty@ENET/Media/Data/Apps/'
    enet_dir = transPath(dst_dir2)
    enet_files = xbmcvfs.listdir(enet_dir)
    # log(f'enet_files: {enet_files}')
    kodiapp_list = []
    for j in enet_files[1]:
        if 'kodi' in j and j.endswith('.apk'):
            # log(f'j: {j}')
            enet_file_path = joinPath(dst_dir2, j)
            kodiapp_list.append({'name': j,
                                'version': '',
                                'url': enet_file_path,
                                'icon': 'https://i.imgur.com/DH7rRx6.png',
                                'fanart': '',
                                'mode' : 'dl_apk_file',
                                'description': j})
    return kodiapp_list


def get_id(settings_file):
    from modules.control import read_file
    xmlData = None

    xmlData = read_file(settings_file)
    soup = BeautifulSoup(xmlData, 'html.parser')
    id_list = []
    for tag in soup.find_all("setting"):
        repElemID = tag.get('id')
        id_list.append(repElemID)
    return id_list


def reset_provider(video_adon, settings_xml_data, settings_xml_default):
    from modules.control import log, sleep, read_file
    #settings_xml_data = settingsFile
    #settings_xml_default = joinPath(addonPath,'resources', 'settings.xml')
    # get default id values
    try:
        default_id = get_id(settings_xml_default)

        xmlData = None
        xmlData = read_file(settings_xml_data)
        soup = BeautifulSoup(xmlData, 'html.parser')
        #log('soup: \n%s'%soup)
        item_clean = False
        for tag in soup.find_all("setting"):
            repElemID = tag.get('id')
            if repElemID not in default_id:
                log('not in use setting ID removed : %s' % repElemID)
                tag.decompose()
                item_clean = True  # if 'provider.' in repElemID:  # log('%s'%repElemID)  # tag.decompose()  #tag.replace_with(soup.new_tag("somenewtag"))
        #log(soup)
        if item_clean:
            log('\nsetting file clened for: %s' % video_adon)
            #new_f = joinPath(dataPath, 'Nsettings.xml')
            with open(settings_xml_data, 'w') as xmlFile:
                xmlFile.seek(0)
                #xmlFile.write("<settings version=\"2\">")
                xmlFile.write(str(soup).replace('\n\n', ''))  #xmlFile.write(str(soup.prettify(formatter="minimal")))
            sleep(500)  # log('@#@#@# setting file clened.')
    except: pass


def reset_upd_setting():
    #all_video_adon = get_video_plugins()
    import platform
    from modules.control import getSetting, log, setSetting, condVisibility, dp, AddonTitle, userdatapath, existsPath
    plgn_list = []
    platform_type = getSetting('platform')
    build = platform.machine()
    log('platform_type: %s' % platform_type)
    if platform_type == build:
        setSetting("platform", build)
    for adn_dir in glob.glob(joinPath(ADDOND, '*.*')):
        ad_n = basename(adn_dir)
        if condVisibility('System.HasAddon(%s)' % ad_n):
            #acnm = ad_n.split(".")[2]
            plgn_list.append(ad_n)

    dp.create(AddonTitle, '')
    for video_adon in plgn_list:
        settings_xml_data = joinPath(userdatapath, 'addon_data', video_adon, 'settings.xml')
        settings_xml_default = joinPath(homepath, 'addons', video_adon, 'resources', 'settings.xml')
        if existsPath(settings_xml_default) and existsPath(settings_xml_data):
            dp.update(0, 'cleaning setting file: %s' % video_adon)
            #log('settings_xml_default: %s\nsettings_xml_data: %s'% (settings_xml_default, settings_xml_data))
            # log('setting file clened for: %s'%video_adon)
            reset_provider(video_adon, settings_xml_data, settings_xml_default)
    dp.close()


def appinstaller(name, url):
    from modules.utilz import workingURL
    from modules.control import platform, execute, infoDialog, log, packages, dp, AddonTitle, color1, color2, sleep
    from modules.wiz import downloader
    if not workingURL(url):
        infoDialog('Error to get App file ...')
        return
    SETTINGS_LOC = '/storage/emulated/0/download'
    # if not existsPath(packages): makeDirs(packages)
    appname = url.split('/')[-1]
    log('@@@ appname: %s == \nurl: %s  \nappname:%s ' % (appname, url, appname))

    # apk = lib if lib.endswith('.apk') else '{}.apk'.format(lib)
    # try: deleteFile(lib)
    # except: pass
    log('platform(): %s' % (platform()))
    use_manager = {0: 'com.android.documentsui', 1: packages}[1]
    log('use_manager(): %s' % (use_manager))
    if platform() in ['android', 'atv2', 'arm']:
        try:
            dp.create(AddonTitle, '[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (color2, color1, name))
            # file_manager = int(updater.getSetting('File_Manager'))
            # custom_manager = updater.getSetting('Custom_Manager')
            # custom_manager = packages
            lib = joinPath(packages, appname)
            # use_manager = {0: 'com.android.documentsui', 1: custom_manager}[file_manager]
            # use_manager = {0: 'com.android.documentsui', 1: packages}[1]
            downloader(url, lib, dp)
            sleep(500)
            title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (color2, color1, name)
            dp.update(0, 'Please Wait:[CR]%s' % title)
            dp.close()
            log('Opening {} with {}'.format(lib, use_manager))
            execute('StartAndroidActivity({},,,"content://{}")'.format(use_manager, lib))
            # execute('StartAndroidActivity("","android.intent.action.INSTALL_PACKAGE ","application/vnd.android.package-archive","content://%s")'%apkfile)
            infoDialog("App {} has been install...".format(appname))
        except:
            log("Error appinstaller: %s" % (traceback.format_exc()))
    else:
        infoDialog("It's not android so can not install {} App file ...".format(appname))
    return
