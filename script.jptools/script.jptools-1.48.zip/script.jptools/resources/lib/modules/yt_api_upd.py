# -*- coding: utf-8 -*-

'''
        inspired from : https://github.com/rrosajp/plugin.program.yt-setup
        License summary below, for more details please read license.txt file

        This program is free software: you can redistribute it and/or modify
        it under the terms of the GNU General Public License as published by
        the Free Software Foundation, either version 2 of the License, or
        (at your option) any later version.
        This program is distributed in the hope that it will be useful,
        but WITHOUT ANY WARRANTY; without even the implied warranty of
        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
        GNU General Public License for more details.
        You should have received a copy of the GNU General Public License
        along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from urllib.parse import quote

import re, json

from modules.control import infoLabel, log

YT_VERSION = infoLabel('System.AddonVersion(plugin.video.youtube)').partition('~')[0].replace('.', '')
if "+" in YT_VERSION:
    YT_VERSION = YT_VERSION.split('+')[0]


def local(path):
    from modules.control import OkDialog, inputDialog
    with open(path) as txtfile:
        f = txtfile.read()

    if not f:
        return

    f = f.strip('\r\n')
    if path.endswith('.txt') or len(f.splitlines()) in (3, 4):
        keys = f.splitlines()
    elif path.endswith('.xml') or f.startswith('<?xml'):
        c_id = re.compile('<id>(.+?)</id>').findall(f)[0]
        api_key = re.compile('<api_key>(.+?)</api_key>').findall(f)[0]
        secret = re.compile('<secret>(.+?)</secret>').findall(f)[0]
        keys = [c_id, api_key, secret]
    elif path.endswith('.json'):
        payload = json.loads(f)
        if 'installed' in payload:
            payload = payload['installed']
            if 'api_key' not in payload:
                OkDialog("Youtube Setup", "API key was not found in the client.json file, please enter it manually")
                api_key = inputDialog('Enter Youtube API key')
                if not api_key:
                    return
            else:
                api_key = payload['api_key']
            keys = [payload['client_id'], api_key, payload['client_secret']]
        else:
            keys = None
    else:
        keys = None
    return keys


def setup(credentials, YT_VERSION):
    from modules.control import execute, addon, infoDialog, setting
    def call():
        plugin_call = 'plugin://plugin.video.youtube/api/update/?enable=true'
        route = '{0}&client_id={1}&client_secret={2}&api_key={3}'.format(plugin_call, quote(credentials[0]), quote(credentials[2]), quote(credentials[1]))
        execute('RunPlugin({0})'.format(route))

    if int(YT_VERSION) >= 543 and setting('route543') == 'true':
        call()
    else:
        if int(YT_VERSION) < 670:
            addon('plugin.video.youtube').setSetting('youtube.api.enable', 'true')
        addon('plugin.video.youtube').setSetting('youtube.api.id', credentials[0])
        addon('plugin.video.youtube').setSetting('youtube.api.key', credentials[1])
        addon('plugin.video.youtube').setSetting('youtube.api.secret', credentials[2])
        infoDialog(message="Success!", time=3000)


def seq(f_path, YT_VERSION):
    from modules.control import OkDialog, addon, addonInfo, yesnoDialog, setting, infoDialog
    log("YT_VERSION: %s" % YT_VERSION)
    conditions = [bool(addon('plugin.video.youtube').getSetting('youtube.api.id')), bool(addon('plugin.video.youtube').getSetting('youtube.api.key')), bool(addon('plugin.video.youtube').getSetting('youtube.api.secret'))]

    if int(YT_VERSION) <= 670:
        conditions.insert(0, addon('plugin.video.youtube').getSetting('youtube.api.enable') == 'true')

    if any(conditions) and (setting('local') or setting('remote')):
        OkDialog(addonInfo('name'), "Current settings will be overwritten!")

    result = local(f_path)

    if not result:
        OkDialog("Something's wrong", "Incorrect settings or files detected")
    else:
        if yesnoDialog(line1="Youtube Setup addon is now ready to store your keys", line2='', line3='', yeslabel="Proceed", nolabel="Cancel"):
            setup(result, YT_VERSION)
        else:
            infoDialog("Cancel")


def start():
    import os
    from modules.control import transPath, addon, getAddonInfo, infoDialog, yesnoDialog, lang, openSettings, SelectDialog
    # log(">>>>>>>> %s" % YT_VERSION)
    addon_dir = transPath(addon().getAddonInfo('path'))
    f_path = os.path.join(addon_dir, "resources", "lib", "api", "yt.xml")

    if not os.path.exists(f_path):
        if yesnoDialog(heading=lang('Path or Address have not been set'), line1=lang('Open settings window?')):
            openSettings()
        else:
            infoDialog(lang('Cancel'))
    else:
        choices = ["Execute setup", "Open settings window", "Open Youtube settings window"]
        selection = SelectDialog("Select Option", choices)
        if selection == 0:
            seq(f_path, YT_VERSION)
        elif selection == 1:
            openSettings()
        elif selection == 2:
            openSettings(id='plugin.video.youtube')
