# -*- coding: UTF-8 -*-

import glob
import os
import random
import re
import shutil
import sys
import time
import traceback

import requests


def OPEN_URL(url, headers=None, output='', timeout='30'):
    lheaders = {"x-requested-with": "XMLHttpRequest", "Accept-Language": "en-US,en;q=0.5", "User-Agent": u_agent(), "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9", "sec-fetch-site": "none", "sec-fetch-mode": "navigate", "sec-fetch-user": "?1",
                "Connection": "Close", }

    if headers:
        lheaders.update(headers)

    try:
        try:
            response = requests.get(url, headers=lheaders, timeout=int(timeout))  # print(response.headers)  # print("")  # print(response.request.headers)
        except requests.exceptions.SSLError:
            response = requests.get(url, headers=lheaders, verify=False)
    except requests.exceptions.ConnectionError:
        print(traceback.print_exc())
        return
    if '200' in str(response):
        return response
    elif 'Retry-After' in response.headers:
        timeout = response.headers['Retry-After']
        time.sleep(int(timeout) + 1)
        return OPEN_URL(url, lheaders)
    else:
        return


def u_agent():
    return random.choice(["Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36", "Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36", "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36",
                          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36",
                          "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36",
                          "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36", "Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36",
                          "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36",
                          "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36",
                          "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36",
                          "Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36", "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36",
                          "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36",
                          "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36"])


def workingURL(url):
    if url == 'http://':
        return False
    response = OPEN_URL(url)
    if '200' in str(response):
        return True
    else:
        return False


def Delete_Crash_Logs(mode='verbose'):
    from modules.control import infoDialog, joinPath, logpath, dialog, AddonTitle, log, deleteFile
    crashfiles = []
    tracefiles = []
    for file in glob.glob(joinPath(logpath, '*crashlog*.*')):
        crashfiles.append(file)
    for file in glob.glob(joinPath(logpath, '*stacktrace*.*')):
        tracefiles.append(file)
    totalfiles = len(crashfiles) + len(tracefiles)
    if totalfiles > 0:
        if mode == 'verbose':
            if dialog.yesno(AddonTitle, 'Would you like to delete the Crash logs? Files Found: %s' % (totalfiles)):
                pass
            else:
                return
        if len(crashfiles) > 0 or len(tracefiles) > 0:
            for f in crashfiles:
                try:
                    deleteFile(f)
                except:
                    remove(f)
            for f in tracefiles:
                try:
                    deleteFile(f)
                except:
                    remove(f)
        else:
            if mode == 'verbose': infoDialog('Clear Crash Logs: Clear Crash Logs Cancelled')
    else:
        if mode == 'verbose': infoDialog('Clear Crash Logs: No Crash Logs Found')


def Delete_DebugLogs():
    from modules.control import joinPath, infoDialog, logpath, dialog, AddonTitle, log
    debuglogfiles = []
    for file in glob.glob(joinPath(logpath, '*.*log*')):
        debuglogfiles.append(file)
    totalfiles = len(debuglogfiles)
    if totalfiles > 0:
        yes = dialog.yesno(AddonTitle, 'Would you like to delete the Debug Logs?\n%s Files Found' % (totalfiles))
        if yes:
            if len(debuglogfiles) > 0:
                for f in debuglogfiles:
                    if "kodi.log" not in f:
                        os.remove(f)
            infoDialog('Clear Debug Logs: %s Removed.' % totalfiles)
            log('Clear Debug Logs: %s Removed.' % totalfiles)
        else:
            infoDialog('Clear Debug Logs: Cancelled.')
            log('Clear Debug Logs: Cancelled.')
    else:
        infoDialog('Clear Debug Logs: No Debug Logs Found.')
        log('Clear Debug Logs: No Debug Logs Found.')


def log_clean_reader(lfile, only_error):
    # lfile = 'kodi.log'
    with open(lfile, 'r', encoding='utf-8') as f:
        Lines = f.readlines()

    result = ''
    regex = re.compile(r"Users\\(?<!\w)(.+?)[\\|\/]", re.IGNORECASE)
    for line in Lines:
        line = regex.sub(r'special://', line)
        if only_error:
            if not any(re.findall(r'INFO|NOTICE', line)):
                line = line.replace('ERROR', '[COLOR red]ERROR[/COLOR]:').replace('WARNING', '[COLOR gold]WARNING[/COLOR]:')
                result += line
        else: result += line
    # print(result)
    return result


def get_logfilepath():
    from os import listdir
    from modules.control import joinPath, logpath, log
    logPaths, logNames = [], []

    for item in listdir(logpath):
        if item.endswith('.log'):
            logNames.append(item)
            logPaths.append(joinPath(logpath, item))
    return logPaths, logNames


def get_log_data(only_error=False):
    # from os import listdir
    from modules.control import SelectDialog, log
    logPaths, logNames = get_logfilepath()
    
    selectLog = SelectDialog("Select log file to View", logNames)
    if selectLog == -1:
        return
    selectedLog = logPaths[selectLog]
    # log("selectLog %s  selectedLog %s logPaths: %s" % (selectLog, selectedLog, logPaths))
    return log_clean_reader(selectedLog, only_error)


def clean_log_file(all_logs=False):
    # from os import listdir
    from modules.control import SelectDialog, log, infoDialog
    logPaths, logNames = get_logfilepath()
    if not all_logs:
        selectLog = SelectDialog("Select log file to View", logNames)
        if selectLog == -1:
            return
        selectedLog = logPaths[selectLog]
        with open(selectedLog, 'w') as logFile:
            logFile.write('')
        infoDialog(f'Clear Log File: {logNames[selectLog]}')
    else:
        for selectedLog in logPaths:
            with open(selectedLog, 'w') as logFile:
                logFile.write('')
        infoDialog(f'Clear Log File: {logNames}')
    return


def upload_log():
    from modules.control import infoDialog, TextBox, dialog, log, AddonTitle
    data = get_log_data()

    if data == '':
        infoDialog('Log File is Emtpy.')
    else:
        session = requests.Session()
        UserAgent = 'JP Tools'
        try:
            url = 'https://paste.kodi.tv/'
            response = session.post(url + 'documents', data=data.encode('utf-8', errors='ignore'), headers={'User-Agent': UserAgent})
            # log('log_response: %s' % str(response))
            if 'key' in response.json():
                result = url + response.json()['key']
                msg = "Your log file was uploaded to:[CR][CR]    [B]%s[/B]" % str(result)
                log('log_upload_url: ' + result)
                dialog.ok(AddonTitle, msg)
            elif 'message' in response.json():
                infoDialog('Log upload failed: %s' % str(response.json()['message']))
                log('log_upload_msg: %s' % str(response.json()['message']))
            else:
                infoDialog('Log upload failed')
                log('log_error: %s' % response.text)
        except:
            infoDialog('Unable to retrieve the paste url')
            log('log_upload_fail: %s' % traceback.print_exc())


def logView():
    from modules.control import SelectDialog, TextBox, dialog, AddonTitle, log
    modes = ['View Log', 'Upload Log (Pastebin)', 'Upload Log (paste.kodi.tv)']
    select = SelectDialog("Select log file Option...", modes)
    try:
        if select == -1:
            raise Exception()
        if select == 0:
            # from api import TextViewer
            # TextViewer.text_view("%s" % selectedLog)
            contents = get_log_data()
            # contents = contents.replace(' ERROR: ', ' [COLOR red]ERROR[/COLOR]: ').replace(' WARNING: ', ' [COLOR gold]WARNING[/COLOR]: ')
            TextBox('--[ JP Tools Log Viewer ]--', contents)
        elif select == 1:
            contents = get_log_data()
            from api import PasteBin
            upload_Link = PasteBin.api().paste(contents)
            log("LOGVIEW UPLOADED LINK: %s" % upload_Link)
            if upload_Link is not None:
                if not "Error" in upload_Link:
                    label = "Log Link: [COLOR %s][B] %s [/B][/COLOR]" % ('purple', upload_Link)
                    dialog.ok(AddonTitle, "Log Uploaded to Pastebin:\n%s" % label)
                else:
                    dialog.ok(AddonTitle, "Cannot Upload Log to Pastebin", "Reason %s" % upload_Link)
            else:
                dialog.ok(AddonTitle, "Cannot Upload Log to Pastebin", "")
        elif select == 2:
            upload_log()
    except:
        log("logView Error: %s" % traceback.print_exc())
        pass


def Broken_Sources():
    from modules.control import transPath, dp, dialog, AddonTitle, log, yesnoDialog
    SOURCES_FILE = transPath('special://home/userdata/sources.xml')
    if not os.path.isfile(SOURCES_FILE):
        dialog.ok(AddonTitle, 'Error: It appears you do not currently have a sources.xml file on your system. We are unable to perform this test.')
        sys.exit(0)
    dp.create(AddonTitle, "Testing Internet Connection...")
    try:
        requests.get("http://www.google.com")
    except:
        dialog.ok(AddonTitle, 'Error: It appears you do not currently have an active internet connection. This will cause false positives in the test. Please try again with an active internet connection.')
        sys.exit(0)
    found = 0
    passed = 0
    dp.update(0, "Checking Sources...")
    a = open(SOURCES_FILE).read()
    b = a.replace('\n', 'U').replace('\r', 'F')
    match = re.compile('<source>(.+?)</source>').findall(str(b))
    counter = 0
    line = "Checking: %s Alive: %s Dead: %s"
    for item in match:
        name = re.compile('<name>(.+?)</name>').findall(item)[0]
        checker = re.compile('<path pathversion="1">(.+?)</path>').findall(item)[0]
        if "http" in str(checker):
            # dp.update(0, "", "Checking: "+name, "")
            try:
                checkme = requests.get(checker, timeout=30)
            except:
                checkme = "null"
                pass
            try:
                error_out = 0
                if not "this does not matter its just a test" in ("%s" % checkme.text):
                    error_out = 0
            except:
                error_out = 1
            if error_out == 0:
                if not ".zip" in ("%s" % checkme.text):
                    if not "repo" in ("%s" % checkme.text):
                        choice = yesnoDialog("Error conecting to the following: ", "Source Name: %s \nSource URL: %s\nWould you like to remove this source now?" % (name, checker))
                        counter += 1
                        if choice == 1:
                            found = 1
                            h = open(SOURCES_FILE).read()
                            i = h.replace('\n', 'U').replace('\r', 'F')
                            j = i.replace(str(item), '')
                            k = j.replace('U', '\n').replace('F', '\r')
                            l = k.replace('<source></source>', '').replace('        \n', '')
                            f = open(SOURCES_FILE, mode='w')
                            f.write(l)
                            f.close()
                    else:
                        passed += 1
                else:
                    passed += 1
            else:
                choice = yesnoDialog("Error conecting to the following: ", "Source Name: %s \nSource URL: %s \nWould you like to remove this source now?" % (name, checker))
                counter += 1
                if choice == 1:
                    found = 1
                    h = open(SOURCES_FILE).read()
                    i = h.replace('\n', 'U').replace('\r', 'F')
                    j = i.replace(str(item), '')
                    k = j.replace('U', '\n').replace('F', '\r')
                    l = k.replace('<source></source>', '').replace('        \n', '')
                    f = open(SOURCES_FILE, mode='w')
                    f.write(l)
                    f.close()
                else:
                    passed += 1
            if dp.iscanceled():
                dialog.ok(AddonTitle, 'The source check was cancelled')
                dp.close()
                sys.exit()
            # dp.update(0, "", "", "Alive: "+str(passed)+"        Dead: "+str(counter))
            dp.update(0, line % (name, str(passed), str(counter)))
            dp.close()
    dialog.ok(AddonTitle, 'We have checked your sources and found:\nWORKING SOURCES: %s \nDEAD SOURCES: %s' % (str(passed), str(counter)))


def Broken_Repos():
    from modules.control import joinPath, transPath, dp, dialog, AddonTitle, yesnoDialog
    dp.create(AddonTitle, "Testing Internet Connection...")
    try:
        requests.get("http://www.google.com")
    except:
        dialog.ok(AddonTitle, 'Error: It appears you do not currently have an active internet connection. This will cause false positives in the test. Please try again with an active internet connection.')
        sys.exit(0)
    passed = 0
    failed = 0
    HOMEPATH = transPath('special://home/addons/')
    line = "We are currently checking: %s Alive: %s Dead: %s"
    dp.update(0, "")
    url = HOMEPATH
    for root, dirs, files in os.walk(url):
        for file in files:
            if file == "addon.xml":
                try:
                    with open((joinPath(root, file))) as f:
                        a = f.read()
                except:
                    with open(joinPath(root, file), encoding='utf8') as f:
                        a = f.read()
                if "info compressed=" in str(a):
                    match = re.compile('<info compressed="false">(.+?)</info>').findall(a)
                    for checker in match:
                        # dp.update(0, "", checker, "")
                        try:
                            OPEN_URL(checker, timeout='30')
                            passed += 1
                        except:
                            try:
                                checkme = requests.get(checker, timeout=30)
                            except:
                                pass
                            try:
                                error_out = 0
                                if not "this does not matter its just a test" in ("%s" % checkme.text):
                                    error_out = 0
                            except:
                                error_out = 1
                            if error_out == 0:
                                if not "addon id=" in ("%s" % checkme.text):
                                    failed += 1
                                    match = re.compile('<addon id="(.+?)".+?ame="(.+?)" version').findall(a)
                                    for repo_id, repo_name in match:
                                        default_path = transPath("special://home/addons/")
                                        file_path = transPath(file)
                                        full_path = default_path + repo_id
                                        choice = yesnoDialog("The %s appears to be broken. We attempted to connect to the repo but it was unsuccessful.\nTo remove this repository please click YES" % (repo_name))
                                        if choice == 1:
                                            try:
                                                shutil.rmtree(full_path)
                                            except:
                                                dialog.ok(AddonTitle, "Sorry we were unable to remove " + repo_name)
                                else:
                                    passed += 1
                            else:
                                failed += 1
                                match = re.compile('<addon id="(.+?)".+?ame="(.+?)" version').findall(a)
                                for repo_id, repo_name in match:
                                    default_path = transPath("special://home/addons/")
                                    file_path = transPath(file)
                                    full_path = default_path + repo_id
                                    choice = dialog.yesno(AddonTitle, "The %s appears to be broken. We attempted to connect to the repo but it was unsuccessful.\nTo remove this repository please click YES" % (repo_name))
                                    if choice == 1:
                                        try:
                                            shutil.rmtree(full_path)
                                        except:
                                            dialog.ok(AddonTitle, "Sorry we were unable to remove " + repo_name)
                        if dp.iscanceled():
                            dialog.ok(AddonTitle, 'The repository check was cancelled')
                            dp.close()
                            sys.exit()
                        # dp.update(0, "", "", "Alive: "+str(passed)+"       Dead: "+str(failed))
                        dp.update(0, line % (checker, str(passed), str(failed)))
                        dp.close()
    dialog.ok(AddonTitle, 'We have checked your repositories and found:\nWorking Repositories: %s\nDead Repositories: %s' % (str(passed), str(failed)))


# Checks if a directory exists (Do not use for files)
def dir_exists(dirpath):
    directoryPath = dirpath
    # The xbmcvfs exists interface require that directories end in a slash
    # It used to be OK not to have the slash in Gotham, but it is now required
    if (not directoryPath.endswith("/")) and (not directoryPath.endswith("\\")):
        dirSep = "/"
        if "\\" in directoryPath:
            dirSep = "\\"
        directoryPath = "%s%s" % (directoryPath, dirSep)
    return xbmcvfs.exists(directoryPath)


# Splits a path the same way as os.path.split but supports paths of a different
# OS than that being run on
def os_path_split(fullpath):
    # Check if it ends in a slash
    if fullpath.endswith("/") or fullpath.endswith("\\"):
        # Remove the slash character
        fullpath = fullpath[:-1]

    try:
        slash1 = fullpath.rindex("/")
    except:
        slash1 = -1

    try:
        slash2 = fullpath.rindex("\\")
    except:
        slash2 = -1

    # Parse based on the last type of slash in the string
    if slash1 > slash2:
        return fullpath.rsplit("/", 1)

    return fullpath.rsplit("\\", 1)


# There has been problems with calling join with non ascii characters,
# so we have this method to try and do the conversion for us
def os_path_join(dir, file):
    # Check if it ends in a slash
    if dir.endswith("/") or dir.endswith("\\"):
        # Remove the slash character
        dir = dir[:-1]

    # Convert each argument - if an error, then it will use the default value
    # that was passed in
    try:
        dir = dir.decode("utf-8")
    except:
        pass
    try:
        file = file.decode("utf-8")
    except:
        pass
    return os.path.join(dir, file)


# Performs a nested copy of one directory to another
def nestedCopy(rootSourceDir, rootTargetDir):
    log("nestedCopy: Copy %s to %s" % (rootSourceDir, rootTargetDir))

    # Make sure the target directory exists
    xbmcvfs.mkdirs(rootTargetDir)

    dirs, files = xbmcvfs.listdir(rootSourceDir)

    for file in files:
        try:
            file = file.decode("utf-8")
        except:
            pass
        sourceFile = "%s%s" % (rootSourceDir, file)
        targetFile = "%s%s" % (rootTargetDir, file)
        log("nestedCopy: Copy file %s to %s" % (sourceFile, targetFile))
        xbmcvfs.copy(sourceFile, targetFile)

    for adir in dirs:
        try:
            adir = adir.decode("utf-8")
        except:
            pass
        sourceDir = "%s%s/" % (rootSourceDir, adir)
        targetDir = "%s%s/" % (rootTargetDir, adir)
        log("nestedCopy: Copy directory %s to %s" % (sourceDir, targetDir))
        nestedCopy(sourceDir, targetDir)


def nestedDelete(rootDir):
    # If the file already exists, delete it
    if dir_exists(rootDir):
        # Remove the png files in the directory first
        dirs, files = xbmcvfs.listdir(rootDir)
        # Remove nested directories first
        for adir in dirs:
            nestedDelete(os_path_join(rootDir, adir))
        # If there are any nested files remove them
        for aFile in files:
            xbmcvfs.delete(os_path_join(rootDir, aFile))
        # Now remove the actual directory
        xbmcvfs.rmdir(rootDir)
    else:
        log("nestedDelete: Directory %s does not exist" % rootDir)
