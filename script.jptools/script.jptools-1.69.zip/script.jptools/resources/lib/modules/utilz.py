# -*- coding: UTF-8 -*-

import glob
import re
import shutil
import sys
import time
import sqlite3
from os import remove, unlink, walk
from random import choice
from traceback import print_exc, print_stack
import requests
from modules.pastebin import pastebinapi
from modules.textviewer import text_view
from modules.control import addontitle, databasepath, selectdialog, textbox, delete_file, dialog, dp, existspath, infodialog, joinpath, listdir, log, logpath, transpath, yesnodialog


def db_connect(db_file):
    try:
        dbcon = sqlite3.connect(db_file, isolation_level=None, check_same_thread=False)
        dbcon.execute('''PRAGMA synchronous = OFF''')
        dbcon.execute('''PRAGMA journal_mode = OFF''')
        return dbcon
    except:
        log(f'Error clean_myvideos_db:  {print_stack()}')
        return False

def db_close(dbcon):
    try:
        dbcon.commit()
        dbcon.execute('VACUUM')
    except:
        log(f'Error db_close:  {print_stack()}')
        dbcon.execute('VACUUM')
        dbcon.commit()
        dbcon.execute('VACUUM')
    finally:
        try: dbcon.close()
        except: pass
    return

def find_new_db(pattern):
    result = []
    for root, dirs, files in walk(databasepath):
        for name in files:
            if pattern in name and name.endswith('.db'):
                result.append(joinpath(root, name))
    return result

def open_url(url, headers=None, output='', timeout='30'):
    lheaders = {'User-Agent': u_agent(), 'Accept': '*/*', 'Accept-Encoding': 'identity;q=1, *;q=0', 'Accept-Language': 'en-US,en;q=0.5', 'Connection': 'keep-alive', 'Pragma': 'no-cache', 'Cache-Control': 'no-cache', 'DNT': '1'}

    if headers: lheaders |= headers
    try:
        try: response = requests.get(url, headers=lheaders, timeout=int(timeout))  # log(f'{response.headers}\n {response.request.headers}')
        except requests.exceptions.SSLError: response = requests.get(url, headers=lheaders, verify=False)
    except requests.exceptions.ConnectionError:
        log(f'open_url url: {url} Error: {print_exc()}')
        return
    if '200' in str(response.status_code): return response
    elif 'Retry-After' in response.headers:
        timeout = response.headers['Retry-After']
        time.sleep(int(timeout) + 1)
        return open_url(url, lheaders)


def u_agent():
    return choice(['Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36',
                   'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36',
                   'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36',
                   'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36'])


def workingurl(url):
    if url == 'http://': return False
    try: response = requests.get(url, timeout=30)
    except: log(f'open_url url: {url} Error: {print_exc()}')
    # log(f'open_url url: {url} response: {response}')
    return '200' in str(response)


def delete_crash_logs(mode='verbose'):
    crashfiles = list(glob.glob(joinpath(logpath, '*crashlog*.*')))
    tracefiles = list(glob.glob(joinpath(logpath, '*stacktrace*.*')))
    totalfiles = len(crashfiles) + len(tracefiles)
    if totalfiles > 0:
        if mode == 'verbose' and not dialog.yesno(addontitle, f'Would you like to delete the Crash logs? Files Found: {totalfiles}', ):
            return
        if not crashfiles and not tracefiles and mode == 'verbose': infodialog('Clear Crash Logs: Clear Crash Logs Cancelled')
        elif crashfiles or tracefiles:
            for f in crashfiles:
                delete_file(f)
            for f in tracefiles:
                delete_file(f)
    elif mode == 'verbose': infodialog('Clear Crash Logs: No Crash Logs Found')


def delete_debuglogs():
    debuglogfiles = list(glob.glob(joinpath(logpath, '*.*log*')))
    totalfiles = len(debuglogfiles)
    if totalfiles > 0:
        if yes := dialog.yesno(addontitle, f'Would you like to delete the Debug Logs?\n{totalfiles} Files Found', ):
            if debuglogfiles:
                for f in debuglogfiles:
                    if 'kodi.log' not in f: remove(f)
            infodialog(f'Clear Debug Logs: {totalfiles} Removed.')
            log(f'Clear Debug Logs: {totalfiles} Removed.')
        else:
            infodialog('Clear Debug Logs: Cancelled.')
            log('Clear Debug Logs: Cancelled.')
    else:
        infodialog('Clear Debug Logs: No Debug Logs Found.')
        log('Clear Debug Logs: No Debug Logs Found.')


def log_clean_reader(lfile, only_error):
    with open(lfile, 'r', encoding='utf-8', errors='ignore') as f:
        Lines = f.readlines()

    result = ''
    # log(f'{type(Lines)} :: Lines: {len(Lines)} :: {Lines}')
    if len(Lines) >= 300:
        last_lines = len(Lines) // 2
        Lines = Lines[last_lines:]
    # log(f'{type(Lines)} :: Lines: {len(Lines)} :: {Lines}')
    regex = re.compile(r'Users\\(?<!\w)(.+?)[\\|\/]', re.IGNORECASE)
    for line in Lines:
        line = regex.sub(r'special://', line)
        if only_error:
            if not any(re.findall(r'INFO|NOTICE', line)):
                line = line.replace('ERROR', '[COLOR red]ERROR[/COLOR]:').replace('WARNING', '[COLOR gold]WARNING[/COLOR]:')
                result += line
        else: result += line
    if only_error:
        with open(lfile, 'w', encoding='utf-8', errors='ignore') as r: r.writelines(result)
    return result


def get_logfilepath():
    logPaths, logNames = [], []
    dirs, files = listdir(logpath)
    for item in files:
        if item.endswith('.log'):
            logNames.append(item)
            logPaths.append(joinpath(logpath, item))
    return logPaths, logNames


def get_log_data(only_error=False):
    logPaths, logNames = get_logfilepath()
    selectLog = selectdialog('Select log file to View', logNames)
    if selectLog == -1: return
    selectedLog = logPaths[selectLog]
    # log(f'selectLog {selectLog}  selectedLog {selectedLog} logPaths: {logPaths}')
    return log_clean_reader(selectedLog, only_error)


def clean_log_file(all_logs=False):
    logPaths, logNames = get_logfilepath()
    if not all_logs:
        selectLog = selectdialog('Select log file to View', logNames)
        if selectLog == -1: return
        selectedLog = logPaths[selectLog]
        with open(selectedLog, 'w', errors='ignore') as logFile:
            logFile.write('')
        infodialog(f'Clear Log File: {logNames[selectLog]}')
    else:
        for selectedLog in logPaths:
            with open(selectedLog, 'w', errors='ignore') as logFile:
                logFile.write('')
        infodialog(f'Clear Log File: {logNames}')
    return


def upload_log():
    data = get_log_data()
    if data == '': infodialog('Log File is Emtpy.')
    else:
        session = requests.Session()
        UserAgent = 'JP Tools'
        try:
            url = 'https://paste.kodi.tv/'
            response = session.post(f'{url}documents', data=data.encode('utf-8', errors='ignore'), headers={'User-Agent': UserAgent})
            # log(f'log_response: {response}')
            if 'key' in response.json():
                result = url + response.json()['key']
                msg = f'Your log file was uploaded to:[CR][CR]    {result}'
                log(f'log_upload_url: {result}')
                dialog.ok(addontitle, msg)
            elif 'message' in response.json():
                infodialog(f'Log upload failed: {response.json()["message"]}')
                log(f'log_upload_msg: {response.json()["message"]}')
            else:
                infodialog('Log upload failed')
                log(f'log_error: {response.text}')
        except:
            infodialog('Unable to retrieve the paste url')
            log(f'log_upload_fail: {print_exc()}')


def logview():
    modes = ['View Log', 'Upload Log (Pastebin)', 'Upload Log (paste.kodi.tv)']
    select = selectdialog('Select log file Option...', modes)
    try:
        if select == -1: raise Exception()
        if select == 0:
            contents = get_log_data()
            # contents = contents.replace(' ERROR: ', ' [COLOR red]ERROR[/COLOR]: ').replace(' WARNING: ', ' [COLOR gold]WARNING[/COLOR]: ')
            textbox('--[ JP Tools Log Viewer ]--', contents)
        elif select == 1:
            contents = get_log_data()
            upload_Link = pastebinapi().paste(contents)
            log(f'LOGVIEW UPLOADED LINK: {upload_Link}')
            if upload_Link is None: dialog.ok(addontitle, 'Cannot Upload Log to Pastebin', '')
            elif 'Error' not in upload_Link:
                label = f'Log Link: [COLOR purple] {upload_Link} [/COLOR]'
                dialog.ok(addontitle, f'Log Uploaded to Pastebin:\n{label}')
            else: dialog.ok(addontitle, 'Cannot Upload Log to Pastebin', f'Reason {upload_Link}')
        elif select == 2: upload_log()
    except: log(f'logView Error: {print_exc()}')


def viewlog():
    contents = get_log_data()
    text_view(data=contents)


def broken_sources():
    SOURCES_FILE = transpath('special://home/userdata/sources.xml')
    if not existspath(SOURCES_FILE):
        dialog.ok(addontitle, 'Error: It appears you do not currently have a sources.xml file on your system. We are unable to perform this test.')
        sys.exit(0)
    dp.create(addontitle, 'Testing Internet Connection...')
    try: requests.get('http://www.google.com')
    except:
        dialog.ok(addontitle, 'Error: It appears you do not currently have an active internet connection. This will cause false positives in the test. Please try again with an active internet connection.')
        sys.exit(0)
    found = 0
    passed = 0
    dp.update(0, 'Checking Sources...')
    a = open(SOURCES_FILE, errors='ignore').read()
    b = a.replace('\n', 'U').replace('\r', 'F')
    match = re.compile('<source>(.+?)</source>').findall(str(b))
    counter = 0
    line = 'Checking: %s Alive: %s Dead: %s'
    for item in match:
        name = re.compile('<name>(.+?)</name>').findall(item)[0]
        checker = re.compile('<path pathversion="1">(.+?)</path>').findall(item)[0]
        if 'http' in str(checker):
            # dp.update(0, '', 'Checking: '+name, '')
            try: checkme = requests.get(checker, timeout=30)
            except: checkme = 'null'
            try:
                error_out = 0
                if 'this does not matter its just a test' not in f'{checkme.text}': error_out = 0
            except: error_out = 1
            if error_out == 0:
                if '.zip' not in f'{checkme.text}' and 'repo' not in f'{checkme.text}':
                    choice = yesnodialog('Error conecting to the following: ', f'Source Name: {name} \nSource URL: {checker}\nWould you like to remove this source now?')
                    counter += 1
                    if choice == 1:
                        found = 1
                        h = open(SOURCES_FILE, errors='ignore').read()
                        i = h.replace('\n', 'U').replace('\r', 'F')
                        j = i.replace(str(item), '')
                        k = j.replace('U', '\n').replace('F', '\r')
                        l = k.replace('<source></source>', '').replace('        \n', '')
                        with open(SOURCES_FILE, mode='w', errors='ignore') as f:
                            f.write(l)
                else: passed += 1
            else:
                choice = yesnodialog('Error conecting to the following: ', f'Source Name: {name} \nSource URL: {checker} \nWould you like to remove this source now?')
                counter += 1
                if choice == 1:
                    found = 1
                    h = open(SOURCES_FILE, errors='ignore').read()
                    i = h.replace('\n', 'U').replace('\r', 'F')
                    j = i.replace(str(item), '')
                    k = j.replace('U', '\n').replace('F', '\r')
                    l = k.replace('<source></source>', '').replace('        \n', '')
                    with open(SOURCES_FILE, mode='w', errors='ignore') as f:
                        f.write(l)
                else: passed += 1
            if dp.iscanceled():
                dialog.ok(addontitle, 'The source check was cancelled')
                dp.close()
                sys.exit()
            dp.update(0, line % (name, str(passed), str(counter)))
            dp.close()
    dialog.ok(addontitle, f'We have checked your sources and found:\nWORKING SOURCES: {passed} \nDEAD SOURCES: {counter}')


def broken_repos():
    dp.create(addontitle, 'Testing Internet Connection...')
    try: requests.get('http://www.google.com')
    except:
        dialog.ok(addontitle, 'Error: It appears you do not currently have an active internet connection. This will cause false positives in the test. Please try again with an active internet connection.')
        sys.exit(0)
    passed = 0
    failed = 0
    HOMEPATH = transpath('special://home/addons/')
    line = 'We are currently checking: %s Alive: %s Dead: %s'
    dp.update(0, '')
    url = HOMEPATH
    for root, dirs, files in walk(url):
        for file in files:
            if file == 'addon.xml':
                with open(joinpath(root, file), encoding='utf8', errors='ignore') as f:
                    a = f.read()
                if 'info compressed=' in str(a):
                    match = re.compile('<info compressed="false">(.+?)</info>').findall(a)
                    for checker in match:
                        # dp.update(0, '', checker, '')
                        try:
                            open_url(checker, timeout='30')
                            passed += 1
                        except:
                            try: checkme = requests.get(checker, timeout=30)
                            except: pass
                            try:
                                error_out = 0
                                if 'this does not matter its just a test' not in f'{checkme.text}':
                                    error_out = 0
                            except: error_out = 1
                            if error_out == 0:
                                if 'addon id=' not in f'{checkme.text}':
                                    failed += 1
                                    match = re.compile('<addon id="(.+?)".+?ame="(.+?)" version').findall(a)
                                    for repo_id, repo_name in match:
                                        default_path = transpath('special://home/addons/')
                                        file_path = transpath(file)
                                        full_path = default_path + repo_id
                                        choice = yesnodialog(f'The {repo_name} appears to be broken. We attempted to connect to the repo but it was unsuccessful.\nTo remove this repository please click YES')
                                        if choice == 1:
                                            try: shutil.rmtree(full_path)
                                            except: dialog.ok(addontitle, f'Sorry we were unable to remove {repo_name}')
                                else: passed += 1
                            else:
                                failed += 1
                                match = re.compile('<addon id="(.+?)".+?ame="(.+?)" version').findall(a)
                                for repo_id, repo_name in match:
                                    default_path = transpath('special://home/addons/')
                                    file_path = transpath(file)
                                    full_path = default_path + repo_id
                                    choice = dialog.yesno(addontitle, f'The {repo_name} appears to be broken. We attempted to connect to the repo but it was unsuccessful.\nTo remove this repository please click YES')
                                    if choice == 1:
                                        try: shutil.rmtree(full_path)
                                        except: dialog.ok(addontitle, f'Sorry we were unable to remove {repo_name}')
                        if dp.iscanceled():
                            dialog.ok(addontitle, 'The repository check was cancelled')
                            dp.close()
                            sys.exit()
                        dp.update(0, line % (checker, str(passed), str(failed)))
                        dp.close()
    dialog.ok(addontitle, f'We have checked your repositories and found:\nWorking Repositories: {passed}\nDead Repositories: {failed}')


# Checks if a directory exists (Do not use for files)
def dir_exists(dirpath):
    import xbmcvfs
    directoryPath = dirpath
    # The xbmcvfs exists interface require that directories end in a slash
    # It used to be OK not to have the slash in Gotham, but it is now required
    if (not directoryPath.endswith('/')) and (not directoryPath.endswith('\\')):
        dirSep = '\\' if '\\' in directoryPath else '/'
        directoryPath = f'{directoryPath}{dirSep}'
    return xbmcvfs.exists(directoryPath)


# Splits a path the same way as os.path.split but supports paths of a different
# OS than that being run on
def os_path_split(fullpath):
    # Check if it ends in a slash
    if fullpath.endswith('/') or fullpath.endswith('\\'): fullpath = fullpath[:-1]  # Remove the slash character

    try: slash1 = fullpath.rindex('/')
    except: slash1 = -1

    try: slash2 = fullpath.rindex('\\')
    except: slash2 = -1

    # Parse based on the last type of slash in the string
    return fullpath.rsplit('/', 1) if slash1 > slash2 else fullpath.rsplit('\\', 1)


# There has been problems with calling join with non ascii characters,
# so we have this method to try and do the conversion for us
def os_path_join(dir, file):
    # Check if it ends in a slash
    if dir.endswith('/') or dir.endswith('\\'): dir = dir[:-1]  # Remove the slash character

    # Convert each argument - if an error, then it will use the default value
    # that was passed in
    try: dir = dir.decode('utf-8')
    except: pass
    try: file = file.decode('utf-8')
    except: pass
    return joinpath(dir, file)


# Performs a nested copy of one directory to another
def nestedcopy(rootSourceDir, rootTargetDir):
    import xbmcvfs
    log(f'nestedCopy: Copy {rootSourceDir} to {rootTargetDir}')

    # Make sure the target directory exists
    xbmcvfs.mkdirs(rootTargetDir)

    dirs, files = xbmcvfs.listdir(rootSourceDir)

    for file in files:
        try: file = file.decode('utf-8')
        except: pass
        sourceFile = f'{rootSourceDir}{file}'
        targetFile = f'{rootTargetDir}{file}'
        log(f'nestedCopy: Copy file {sourceFile} to {targetFile}')
        xbmcvfs.copy(sourceFile, targetFile)

    for adir in dirs:
        try: adir = adir.decode('utf-8')
        except: pass
        sourceDir = f'{rootSourceDir}{adir}/'
        targetDir = f'{rootTargetDir}{adir}/'
        log(f'nestedCopy: Copy directory {sourceDir} to {targetDir}')
        nestedcopy(sourceDir, targetDir)


def nesteddelete(rootDir):
    import xbmcvfs
    # If the file already exists, delete it
    if dir_exists(rootDir):
        # Remove the png files in the directory first
        dirs, files = xbmcvfs.listdir(rootDir)
        # Remove nested directories first
        for adir in dirs:
            nesteddelete(os_path_join(rootDir, adir))
        # If there are any nested files remove them
        for aFile in files:
            xbmcvfs.delete(os_path_join(rootDir, aFile))
        # Now remove the actual directory
        xbmcvfs.rmdir(rootDir)
    else: log(f'nestedDelete: Directory {rootDir} does not exist')


def nested_file_delete(purgePath=None):
    # If the file already exists, delete it
    if not purgePath: purgePath = transpath('special://home/addons/')
    if (not purgePath.endswith('/')) and (not purgePath.endswith('\\')):
        dirSep = '\\' if '\\' in purgePath else '/'
        purgePath = f'{purgePath}{dirSep}'
    if existspath(purgePath):
        # log(f'purgePath: {purgePath}')
        total_files = 0
        for root, dirs, files in walk(purgePath):
            files = [file for file in files if file.endswith('.pyc')]
            # log(f'files: {len(files)} : {files}')
            for aFile in files:
                remove_file = joinpath(root, aFile)
                delete_file(remove_file)
                total_files += 1
                # log(f'aFile: {remove_file}')
        infodialog(f'total files removed: {total_files}')
    else: log(f'nestedDelete: Directory {purgePath} does not exist')