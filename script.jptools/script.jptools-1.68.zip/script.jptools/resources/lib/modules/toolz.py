# -*- coding: utf-8 -*-
import re
from platform import machine
from traceback import format_exc, print_exc

from modules.control import addon, auto_click_yes, textbox, busy, condvisibility, databasepath, execute, homepath, idle, infodialog, infolabel, joinpath, jsonrpc, log, sleep, transpath, listdir, get_soup, excludes_addons, existspath, packages, addontitle, dp, color1, color2, forceclose, platform, yesnodialog
from modules.utilz import open_url, workingurl, db_connect
from modules.control import addonid, selectdialog, mymonitor, addonicon as icon, platform as mplatform, item as litem

build_opt = {'nightlies': 'Unstable (Daily builds).', 'releases': 'Stable (Final releases).', 'snapshots': 'Semi-stable (Monthly builds).', 'test-builds': 'Experimental (Debugging builds).'}
base_url = 'http://mirrors.kodi.tv/'


def folder_size(dirname=None, filesize='b'):
    import os
    if not dirname: dirname = homepath
    finalsize = 0
    for dirpath, dirnames, filenames in os.walk(dirname):
        for f in filenames:
            fp = joinpath(dirpath, f)
            finalsize += os.path.getsize(fp)
    return human_size(finalsize)


def human_size(byte_s, units=None):
    """ Returns a human-readable reprentation of bytes and unit """
    if units is None: units = [' bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB']
    return (byte_s, units[0]) if byte_s < 1024 else human_size(byte_s >> 10, units[1:])


def dialogwatch():
    x = 0
    while not condvisibility('Window.isVisible(yesnodialog)') and x < 100:
        x += 1
        sleep(100)
    if condvisibility('Window.isVisible(yesnodialog)'): execute('SendClick(11)')


def swapus():
    new = '"addons.unknownsources"'
    query = {"jsonrpc": "2.0", "method": "Settings.GetSettingValue", "params": {"setting": new}, "id": 1}
    response = jsonrpc(query)
    if 'true' in response: infodialog('Unknown Sources: Already Enabled.')
    if 'false' in response:
        sleep(200)
        value = 'true'
        query = {"jsonrpc": "2.0", "method": "Settings.SetSettingValue", "params": {"setting": new, "value": value}, "id": 1}
        response = jsonrpc(query)
        infodialog('Unknown Sources: Enabled.')


def autoupdatetoggle_system():
    #Sets system-wide auto-update.  Change the "value" number for desired action
    # 0-auto-update, 1 -notify of updates, 2-disable auto updates.
    jsonrpc({"method": "Settings.SetSettingValue", "params": {"setting": "general.addonupdates", "value": 1}, "jsonrpc": "2.0", "id": 1})
    jsonrpc({"method": "Settings.SetSettingValue", "params": {"setting": "general.addonnotifications", "value": True}, "jsonrpc": "2.0", "id": 1})
    jsonrpc({"method": "Settings.SetSettingValue", "params": {"setting": "addons.updatemode", "value": 1}, "jsonrpc": "2.0", "id": 1})
    jsonrpc({"method": "Settings.SetSettingValue", "params": {"setting": "filelists.showhidden", "value": True}, "jsonrpc": "2.0", "id": 1})
    jsonrpc({"method": "Settings.SetSettingValue", "params": {"setting": "filelists.allowfiledeletion", "value": True}, "jsonrpc": "2.0", "id": 1})
    if condvisibility('System.HasAddon(skin.aeon.nox.silvo)'):
        jsonrpc({"method": "Settings.SetSettingValue", "params": {"setting": "lookandfeel.skin", "value": "skin.aeon.nox.silvo"}, "jsonrpc": "2.0", "id": 1})
        auto_click_yes()
        try:
            addon('skin.aeon.nox.silvo').setSetting('centermainmenu', 'true')
            addon('skin.aeon.nox.silvo').setSetting('centeredinfoline', 'true')
            addon('skin.aeon.nox.silvo').setSetting('enable.visiblesubmenu', 'true')
        except: log(f'Error autoupdatetoggle_system: {print_exc()}')
    data =jsonrpc({"method": "Settings.GetSettingValue", "params": {"setting": "addons.unknownsources"}, "jsonrpc": "2.0", "id": 1})
    if data and not data[0].get('result').get('value'):
        log(f'addons.unknownsources data: {data}')
        data =jsonrpc({"method": "Settings.SetSettingValue", "params": {"setting": "addons.unknownsources", "value": True}, "jsonrpc": "2.0", "id": 1})
        log(f'addons.unknownsources data: {data}')
        # auto_click_yes()
    return

def autoupdatetoggle_addon():
    #The Addons33.db has a table called blacklist.  These are the addonIDs that you won't get auto-updated.
    #Couldn't figure out how to automatically set a unique ID for the table, so I just set I set the first value(ID) to 100
    addons_dbfile = joinpath(databasepath, 'Addons33.db')
    dbcon = db_connect(addons_dbfile)
    ##Enable disable toggle could go below instead of (un)commenting below code.
    ##To Add to do not auto update list
    dbcon.execute('INSERT INTO blacklist Values (?,?)', ('100', 'plugin.video.exodusredux'))
    dbcon.commit()  ##To Remove from do not auto update list  # dbcur.execute("DELETE FROM blacklist WHERE addonID = 'plugin.video.exodusredux'")  #dbcon.commit()
    dbcon.close()

def forceupdatecheck():
    busy()
    execute('UpdateAddonRepos')
    execute('UpdateLocalAddons')
    idle()
    infodialog('Checking for Updates...')


def enable_addon(addon_name=addonid):
    try: jsonrpc({"jsonrpc": "2.0", "method": "Addons.SetAddonEnabled", "params": {"addonid": f"{addon_name}", "enabled": True}, "id": 1})
    except: log(f'Error: {format_exc()}')


def enable_addons():
    home_addons = transpath('special://home/addons')
    if addons_list := listdir(home_addons):
        for addon_name in addons_list[0]:
            if all(value not in addon_name for value in excludes_addons):
                # log("enabled addon_name: %s" % (addon_name))
                enable_addon(addon_name)


def resetresolverscache():
    try:
        if condvisibility('System.HasAddon(script.module.resolveurl)'):
            execute('runplugin(plugin://script.module.resolveurl/?mode=reset_cache)')
    except Exception as e: log(f'resetresolverscache error: {e}')


def reloadmyskin():
    execute('ReloadSkin()')


def current_profile():
    return infolabel('System.ProfileName')


def reloadprofile(profile=None):
    if profile is None: execute('LoadProfile(Master user)')
    else: execute(f'LoadProfile({profile})')


def getinfo(label):
    try: return infolabel(label)
    except: return False


def net_info():
    infolabel = ['Network.IPAddress', 'Network.MacAddress', 'Network.IsDHCP', 'Network.GatewayAddress', 'Network.DNS1Address']
    data = []
    for info in infolabel:
        temp = getinfo(info)
        y = 0
        while temp == 'Busy' and y < 10:
            temp = getinfo(info)
            y += 1
            # log(f'{info} sleep {str(y)}')
            sleep(200)
        data.append(temp)
    # log(f'[trakt data] data: {data}')
    netinfo = {'internal ip': data[0], 'MacAddress': data[1], 'IsDHCP': str(data[2]), 'gatewayaddress': data[3], 'dns1address': data[4], 'external ip': '', 'isp': '', 'city': '', 'country': '', 'state': ''}
    try:
        # url = f'http://ipwhois.app/json/{inter_ip}'
        # url = random.choice(['http://extreme-ip-lookup.com/json/', 'http://ip-api.com/json'])
        url = 'https://ipapi.co/json/'
        if req := open_url(url):
            geo = req.json()
            log(f'url: {url}\n geo: {geo} ')
            # netinfo.update({"external ip": geo['ip']})
            netinfo['isp'] = geo['org']
            netinfo['city'] = geo['city']
            netinfo['country'] = geo['country']
            netinfo['state'] = geo['region_code']
        # else:
        url = 'https://whatismyip.host/ip4'
        ip = open_url(url)
        # log(f'from whatismyip.host geo["ip"]: {ip.text}')
        netinfo['external ip'] = ip.text
    except:
        log(f'[trakt data] error: {format_exc()} ')
    return netinfo


def netinfo():
    netinfo = net_info()
    # log(f'[trakt data] netinfo: {netinfo}')
    string = '\n'.join(f'{i:02d}: {item:<15}: {netinfo.get(f"{item}")}' for i, item in enumerate(netinfo, start=1))
    textbox('--[ net info ]--', string)


def get_platform_data():
    branchs = {20: 'nexus', 21: 'omega', 22: 'pegasus', }
    ver_query = {"jsonrpc": "2.0", "method": "Application.GetProperties", "params": {"properties": ["version"]}, "id": 1}
    machine_type = machine()
    myplatform = mplatform()
    build = jsonrpc(ver_query)[0]
    build = build.get('result', {}).get('version', {})
    branch = branchs[int(build.get('major', ''))]
    current_kodi_branch = '(%s.%s-%s)' % (build.get('major', ''), build.get('minor', ''), build.get('revision', ''))
    if myplatform == 'android':
        _url = base_url + '%s/android/%s/'
        if '64' in machine_type: thisplatform = 'arm64-v8a'
        elif '86' in machine_type: thisplatform = 'x86'
        else: thisplatform = 'arm'
        app_endswith = '.apk'
    elif myplatform == 'windows':
        _url = base_url + '%s/windows/%s/'
        if '64' in machine_type: thisplatform = 'win64'
        elif '86' in machine_type: thisplatform = 'win32'
        else: thisplatform = ''
        app_endswith = '.exe'
    return {'url': _url, 'branch': branch, 'current_kodi_branch': current_kodi_branch, 'thisplatform': thisplatform, 'app_endswith': app_endswith, 'myplatform': myplatform}


def get_soup_items(soup):
    try:  #folders
        items = (soup.find_all('tr'))
        del items[0]
    except:  #files
        items = (soup.find_all('a'))
    return [x.get_text() for x in items if x.get_text() is not None]


def appinstaller(name, url):
    if not workingurl(url):
        infodialog('Error to get App file ...')
        return
    appname = url.split('/')[-1]
    thisplatform = platform()
    lib = joinpath(packages, appname)
    log(f'platform(): {thisplatform}\n appname: {appname} \nurl: {url}\nlib: {lib}')

    def download_apk():
        try:
            from modules.wiz import downloader
            dp.create(addontitle, f'[COLOR {color2}]Downloading:[/COLOR] [COLOR {color1}]{name}[/COLOR]')
            downloader(url, lib, dp)
            sleep(500)
            title = f'[COLOR {color2}]Installing:[/COLOR] [COLOR {color1}]{name}[/COLOR]'
            dp.update(0, f'Please Wait:[CR]{title}')
            dp.close()
        except: log(f'Error download_apk: {print_exc()}')

    if not existspath(lib): download_apk()
    if thisplatform in ['android', 'atv2', 'arm']:
        try:
            # log(f'ok i am android: {url} lib: {lib}')
            # SETTINGS_LOC = '/storage/emulated/0/download'
            use_manager = {0: 'com.android.documentsui', 1: packages}[1]
            log(f'Opening {lib} with {use_manager}')
            execute(f'StartAndroidActivity({use_manager},,,"content://{lib}")')
            infodialog(f'App {appname} has been install...')
        except: log(f'Error appinstaller: {print_exc()}')
    elif thisplatform in ['windows']:
        try:
            from subprocess import call
            # log(f'ok i am window: {url} lib: {lib}')
            execute('AlarmClock(shutdowntimer,XBMC.Quit(),2.0,true)')
            forceclose()
            call(lib, shell=True)
        except: log(f'Error appinstaller: {print_exc()}')
    else: infodialog(f'Its not android so can not install {appname} App file ...')
    return


def builditems():
    platform_data = get_platform_data()
    # log(f'platform_data: {platform_data}')
    # platform_data = {'url': 'http://mirrors.kodi.tv/%s/windows/%s/', 'branch': 'omega', 'current_kodi_branch': '(21.0-20230911-327fd81962)', 'thisplatform': 'win64', 'app_endswith': '.exe', 'myplatform': 'windows'}
    burl = platform_data['url']
    thisplatform = platform_data['thisplatform']
    branch = platform_data['branch']
    current_kodi_branch = platform_data['current_kodi_branch']
    app_endswith = platform_data['app_endswith']
    myplatform = platform_data['myplatform']

    def build_main():
        tmplst = []
        for label in sorted(build_opt.keys()):
            liz = litem(label.title(), build_opt[label], path=burl % (label, thisplatform))
            liz.setArt({'poster': 'DefaultAddonProgram.png', 'icon': icon, 'thumb': icon})
            tmplst.append(liz)
        # select = selectdialog(addontitle, tmplst)
        select = selectdialog('select build to install...', tmplst)
        if select is None: return
        return tmplst[select].getPath()
        # url = tmplst[select].getPath()

    def builditems(url):
        cacheresponce = open_url(url).text
        # log(f'url: {url} \ncacheresponce: {cacheresponce}')
        soup = get_soup(cacheresponce)
        if soup is None: return
        for item in get_soup_items(soup):
            # log(f'item: {item}')
            try:  #folders
                label, label2 = re.compile("(.*?)/-(.*)").match(item).groups()
                # log(f'folders label: {label} label2: {label2}')
                if label == thisplatform: label2 = 'current platform (%s)' % thisplatform
                elif label.lower() == branch.lower(): label2 = 'current kodi branch %s' % current_kodi_branch
                else: label2 = ''  #don't use time-stamp for folders
                # log(f'folders label2: {label2}')
                liz = litem(label.title(), label2, path=(url + label))
                liz.setArt({'icon': icon, 'thumb': icon})
                yield liz
            except:  #files
                label, label2 = re.compile("(.*?)\s(.*)").match(item).groups()
                if app_endswith in label:
                    # log(f'files label: {label} label2: {label2}')
                    labels = label.split(app_endswith)
                    title = labels[0]
                    title1 = labels[1]
                    # log(f'files label title: {title} title1: {title1}')
                    liz = litem(f'{title}{app_endswith}', '%s %s' % (title1, label2.replace('MiB', 'MB ').strip()), path=f'{url}{title}{app_endswith}')
                    liz.setArt({'icon': icon, 'thumb': icon})
                    yield liz

    def selectedpath(url, bypass=False):
        while not mymonitor.abortRequested():
            items = list(builditems(url))
            if len(items) == 0: break
            elif len(items) == 2 and not bypass and items[0].getLabel().lower() == 'parent directory' and not items[1].getLabel().startswith(app_endswith): select = 1  #if one folder bypass selection.
            else: select = selectdialog(url.replace(base_url, './').replace('//', '/'), items)
            if select is None: return  #return on cancel.
            label = items[select].getLabel()
            newurl = items[select].getPath()
            preurl = url.rsplit('/', 2)[0] + '/'
            if newurl.endswith(app_endswith):
                log(f'setlastpath label: {label}')
                if yesnodialog('Kodi install?', f'You are about to install Kodi[CR]{label}[CR]Would you like to continue?', yes='Yes, Close', no='No, Cancel'): return appinstaller(label, newurl)
                break
            elif label.lower() == 'parent directory' and myplatform in preurl.lower():
                return selectedpath(preurl, True)
            elif label.lower() == 'parent directory' and myplatform not in preurl.lower():
                return selectedpath(build_main(), False)
            url = newurl + '/'

    url = build_main()
    # log(f'url form build_main: {url}')
    # url = 'http://mirrors.kodi.tv/nightlies/windows/win64/'
    # url = 'http://mirrors.kodi.tv/nightlies/windows/win64/Omega/'
    # url = 'http://mirrors.kodi.tv/nightlies/windows/win64/master/'
    selectedpath(url)