# -*- coding: UTF-8 -*-

from datetime import date

from modules.control import addonid, addonversion, check_backup_dir, getfuture_date, getsetting, infodialog, log, packages, setsetting, thumbs
from modules.maintenance import clean_myvideos_db, clean_oldlog, clearcache, purgepackages, thumb_cleaner
from modules.toolz import autoupdatetoggle_system, folder_size, forceupdatecheck, resetresolverscache
from modules.traktit import reset_upd_setting, skin_backup_restore
from modules.upd_yt_api import set_api


class AutoRun:
    def run(self):
        if getsetting('skin_restore'): autoupdatetoggle_system()
        notify_mode = getsetting('notify_mode')
        auto_checkup = getsetting('auto_check4updates')

        if notify_mode == 'true':
            packagesdir_size, unit1 = folder_size(packages)
            thumbnails_size, unit2 = folder_size(thumbs)
            infodialog(f'Packages: [B]{packagesdir_size} {unit1}[/B] thumbnails: [B]{thumbnails_size} {unit2} [/B] ')
            log(f'Packages: {packagesdir_size} {unit1} | Thumbnails: {thumbnails_size} {unit2}')
        # else: log('[notify mode] Not Enabled')

        if auto_checkup == 'true': forceupdatecheck()

        autoclean = getsetting('autoclean')
        autonext = getsetting('autonextacleannsave')
        atoday = date.today()
        current_date = atoday.strftime('%Y-%m-%d')
        log(f'autoclean : {repr(autoclean)} current_date : {repr(current_date)} autonext : {repr(autonext)}')
        log(f'autoclean: {autoclean == "true"} autonext <= current_date : {autonext.replace("-", "") <= current_date.replace("-", "")}')
        check_backup_dir()
        clean_oldlog()
        if getsetting('skin_backup') == 'true': skin_backup_restore()

        if autoclean == 'true' and autonext.replace('-', '') <= current_date.replace('-', ''):
            log(f'[ {addonid} Startup ] [ v.{addonversion} ]')
            # clen_wiz_file()
            filesize = int(getsetting('filesize_alert'))
            filesize_thumb = int(getsetting('filesizethumb_alert'))
            autocleanfeq = getsetting('autocleanfeq')
            autocleanfeq = int(autocleanfeq) if autocleanfeq.isdigit() else 0
            autosetting = getsetting('autosetting')
            autocache = getsetting('clearcache')
            autopackages = getsetting('clearpackages')
            autothumbs = getsetting('clearthumbs')
            keeptrakt = getsetting('keeptrakt')
            next_run = getfuture_date(autocleanfeq)

            if autocache == 'true':
                clearcache('noverbose')
                resetresolverscache()
                clean_myvideos_db()
                log('[Auto Clean Up] Cache: is Done')
            else: log('[Auto Clean Up] Cache: Off')
            if autothumbs == 'true':
                thumbnails_size, unit2 = folder_size(thumbs)
                if int(thumbnails_size) > filesize_thumb and unit2 == 'MB':
                    thumb_cleaner()
                    log('[Auto Clean Up] Old Thumbs: is Done')
            else: log('[Auto Clean Up] Old Thumbs: Off')
            if autopackages == 'true':
                packagesdir_size, unit1 = folder_size(packages)
                if int(packagesdir_size) > filesize and unit1 == 'MB':
                    purgepackages('noverbose')
                    log('[Auto Clean Up] Packages: is Done')
            if autosetting:
                reset_upd_setting()
                # Delete_Crash_Logs('noverbose')
                log('[Auto Clean Up] Setting files: is Done')
                try:
                    set_api('noverbose')
                    log('[Auto Clean Up] Youtube API upd: is Done')
                except: pass
            else: log('[Auto Clean Up] setting: Off')
            # if keeptrakt == 'true':
            # trakt('update', 'all')
            # log('[Trakt Data] Saved all Trakt Data')
            # else:
            # log('[Trakt Data] Not Enabled')
            log(f'[Auto Clean Up] Next Clean Up will be on : {next_run}  Today is : {current_date}')
            try:
                setsetting('autonextacleannsave', f'{next_run}')
                setsetting('autolastacleannsave', f'{current_date}')
            except: pass
        return