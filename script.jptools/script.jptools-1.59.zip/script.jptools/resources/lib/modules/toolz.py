# -*- coding: UTF-8 -*-
import sqlite3 as database
from traceback import format_exc

from modules.control import TextBox, busy, condVisibility, databasepath, execute, homepath, idle, infoDialog, infoLabel, joinPath, jsonrpc, log, sleep, transPath, listDir
from modules.utilz import OPEN_URL


def Folder_Size(dirname=None, filesize='b'):
    import os
    if not dirname: dirname = homepath
    finalsize = 0
    for dirpath, dirnames, filenames in os.walk(dirname):
        for f in filenames:
            fp = joinPath(dirpath, f)
            finalsize += os.path.getsize(fp)
    return human_size(finalsize)


def human_size(byte_s, units=None):
    """ Returns a human-readable reprentation of bytes and unit """
    if units is None: units = [' bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB']
    return (byte_s, units[0]) if byte_s < 1024 else human_size(byte_s >> 10, units[1:])


def dialogWatch():
    x = 0
    while not condVisibility('Window.isVisible(yesnodialog)') and x < 100:
        x += 1
        sleep(100)
    if condVisibility('Window.isVisible(yesnodialog)'): execute('SendClick(11)')


def swapUS():
    new = '"addons.unknownsources"'
    query = {"jsonrpc": "2.0", "method": "Settings.GetSettingValue", "params": {"setting": new}, "id": 1}
    response = jsonrpc(query)
    if 'true' in response: infoDialog('Unknown Sources: Already Enabled.')
    if 'false' in response:
        #thread.start_new_thread(dialogWatch, ())
        sleep(200)
        value = 'true'
        query = {"jsonrpc": "2.0", "method": "Settings.SetSettingValue", "params": {"setting": new, "value": value}, "id": 1}
        response = jsonrpc(query)
        infoDialog('Unknown Sources: Enabled.')


def AutoUpdateToggle_System():
    #Sets system-wide auto-update.  Change the "value" number for desired action
    # 0-auto-update, 1 -notify of updates, 2-disable auto updates.
    jsonrpc({"jsonrpc": "2.0", "method": "Settings.SetSettingValue", "id": 1, "params": {"setting": "general.addonupdates", "value": 1}})
    #execute('xbmc.ActivateWindow(systemsettings)')
    execute('xbmc.ActivateWindow(AddonBrowser)')
    execute('SendClick(10125, 5)')


def AutoUpdateToggle_Addon():
    #The Addons27.db has a table called blacklist.  These are the addonIDs that you won't get auto-updated.
    #Couldn't figure out how to automatically set a unique ID for the table, so I just set I set the first value(ID) to 100
    addonsFile = joinPath(databasepath, 'Addons27.db')
    sourceFile = addonsFile
    dbcon = database.connect(sourceFile)
    dbcur = dbcon.cursor()
    ##Enable disable toggle could go below instead of (un)commenting below code.
    ##To Add to do not auto update list
    dbcur.execute('INSERT INTO blacklist Values (?,?)', ('100', 'plugin.video.exodusredux'))
    dbcon.commit()  ##To Remove from do not auto update list  # dbcur.execute("DELETE FROM blacklist WHERE addonID = 'plugin.video.exodusredux'")  #dbcon.commit()


def ForceUpdateCheck():
    busy()
    execute('UpdateAddonRepos')
    execute('UpdateLocalAddons')
    idle()
    infoDialog('Checking for Updates...')


def ENABLE_ADDONS():

    HOME_ADDONS = transPath('special://home/addons')
    if addons_list := listDir(HOME_ADDONS):
        EXCLUDES_ADDONS = ['notification', 'packages', '__pycache__', 'temp']
        for addon_name in addons_list[0]:
            if all(value not in addon_name for value in EXCLUDES_ADDONS):
                # log("Enabled addon_name: %s" % (addon_name))
                try: jsonrpc({"jsonrpc": "2.0", "method": "Addons.SetAddonEnabled", "params": {"addonid": f"{addon_name}", "enabled": True}, "id": 1})
                except: log(f'Error: {format_exc()}')


def resetResolversCache():
    try:
        if condVisibility('System.HasAddon(script.module.resolveurl)'):
            execute('RunPlugin(plugin://script.module.resolveurl/?mode=reset_cache)')
    except Exception as e: log(f'resetResolversCache Error: {str(e)}')


def ReloadMySkin():
    execute('ReloadSkin()')


def Current_Profile():
    return infoLabel('System.ProfileName')


def reloadProfile(profile=None):
    if profile is None: execute('LoadProfile(Master user)')
    else: execute(f'LoadProfile({profile})')


def getInfo(label):
    try: return infoLabel(label)
    except: return False


def net_info():
    # import random
    infoLabel = ['Network.IPAddress', 'Network.MacAddress', 'Network.LinkState', 'Network.GatewayAddress', 'Network.DNS1Address']
    data = []
    # x = 0
    for info in infoLabel:
        temp = getInfo(info)
        y = 0
        while temp == 'Busy' and y < 10:
            temp = getInfo(info)
            y += 1
            # log(f"{info} sleep {str(y)}")
            sleep(200)
        data.append(temp)  # x += 1
    # log(f"[Trakt Data] data: {data} ")
    netinfo = {"Internal IP": data[0], "Mac": data[1], "LinkState": data[2], "GatewayAddress": data[3], "DNS1Address": data[4], "External IP": "", "ISP": "", "City": "", "Country": "", "State": ""}
    try:
        # url = f"http://ipwhois.app/json/{inter_ip}"
        # url = random.choice(['http://extreme-ip-lookup.com/json/', 'http://ip-api.com/json'])
        url = 'https://ipapi.co/json/'
        if req := OPEN_URL(url):
            geo = req.json()
            log(f'url: {url}\n geo: {geo} ')
            # netinfo.update({"External IP": geo['ip']})
            netinfo['ISP'] = geo['org']
            netinfo['City'] = geo['city']
            netinfo['Country'] = geo['country']
            netinfo['State'] = geo['region_code']
        # else:
        url = 'https://whatismyip.host/ip4'
        ip = OPEN_URL(url)
        # log(f"from whatismyip.host geo['ip']: {ip.text} ")
        netinfo['External IP'] = ip.text

        return netinfo
    except:
        log(f'[Trakt Data] Error: {format_exc()} ')
        return netinfo


def NETINFO():
    netinfo = net_info()
    log(f'[Trakt Data] netinfo: {netinfo}')
    string = "".join(
        f'[B][COLOR red]{i:02d}:[/B][/COLOR] {item:15}: {netinfo.get(f"{item}")}[CR]'
        for i, item in enumerate(netinfo, start=1)
    )
    TextBox('--[ JP Tools Net Info ]--', string)
