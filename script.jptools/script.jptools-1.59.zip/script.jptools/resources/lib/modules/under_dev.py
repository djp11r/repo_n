#!/bin/python
import json
import os
import re
# import urllib2
import sys
from traceback import format_exc, print_exc
import xbmc, xbmcgui

from modules.control import Addon, addonInfo, jsonrpc, log, kodiVersion
from modules.utilz import os_path_join, os_path_split, OPEN_URL
# file = os.path.realpath(__file__)
# sys.path.append(os.path.join(os.path.dirname(file)))
# from utilz import OPEN_URL

# from modules.utilz import OPEN_URL
# Written by: Phantom Raspberry Blower
# Date: 21-02-2018
# Description: Module for downloading information about ip address

URL = 'https://ipinfo.io/%s'
API_KEY = 'AIzaSyDIJ9XX2ZvRKCJcFRrl-lRanEtFUow4piM'
IMG_SIZE = '480x390'

class IPInfo:

    def __init__(self, ipaddr='0.0.0.0'):
        self.clear()
        if ipaddr == '0.0.0.0':
            ipaddr = self._wan_ip_addr()
        if ipaddr != 'Error getting WAN IP Address!':
            self.__ip_addr = ipaddr
            self.get_ip_info(ipaddr)

    @property
    def ip_addr(self):
        return self.__ip_addr

    @property
    def city(self):
        return self.__city

    @property
    def region(self):
        return self.__region

    @property
    def postcode(self):
        return self.__postcode

    @property
    def coordinates(self):
        return self.__coordinates

    @property
    def country(self):
        return self.__country

    @property
    def hostname(self):
        return self.__hostname

    @property
    def addrtype(self):
        return self.__addr_type

    @property
    def asn(self):
        return self.__asn

    @property
    def organization(self):
        return self.__organization

    @property
    def route(self):
        return self.__route

    @property
    def description(self):
        return self.__description

    @property
    def mapimage(self):
        return self.__map_image

    def clear(self):
        self.__ip_addr = '0.0.0.0'
        self.__city = None
        self.__region = None
        self.__postcode = None
        self.__coordinates = None
        self.__country = None
        self.__hostname = None
        self.__addr_type = None
        self.__asn = None
        self.__organization = None
        self.__route = None
        self.__description = None
        self.__map_image = None

    def _regex_from_to(self, text, from_string, to_string, excluding=True):
        r = (
            re.search(f"(?i){from_string}" + "([\S\s]+?)" + to_string, text)
            if excluding
            else re.search(
                f"(?i)({from_string}" + "[\S\s]+?" + to_string + ")", text
            )
        )
        r = r[1] if r else ''
        return r

    def _get_url(self, url):
        """
        Download url and remove carriage return
        and tab spaces from page
        """
        return req.text if (req := OPEN_URL(url)) else 'Error! Unable to download url!'

    def _wan_ip_addr(self):
    # Get the WAN IP address
        try:
            return self._get_url('http://ip.42.pl/raw')
        except:
            return 'Error getting WAN IP Address!'

    def _ip_info(self, ipaddr=None):
        text = ''
        """
        Show Location
        """
        try:
            # ipaddr = '159.89.116.119'
            # response = self._get_url(URL % ipaddr)
            if ipaddr == 'Error getting WAN IP Address!':
                response = json.loads(self._get_url('https://ipapi.co/json/'))
                log(f'from: https://ipapi.co/json/ response: {response}')
            else:
                response = json.loads(self._get_url(URL % ipaddr))
                log(f'from: {URL % ipaddr} response: {response}')
            # address = response.replace('\t', '').replace('\n', '').replace('  ', '')
            # matchrows = re.compile('<dl class="row">(.+?)</dl>').findall(address)
            # for item in matchrows:
            #     matchitems = re.compile('<dt class="col-sm-4 mb-md-3">(.+?)</dt>'
            #                             '<dd class="col-sm-8 mb-md-9">(.+?)</dd>').findall(item)
            #     log('matchitems: %s' % matchitems)
            #     for key, value in matchitems:
            #         if '<a' in value:
            #             value = self._regex_from_to(value, '">', '</a>')
            #         text += ('%s: %s\n') % (key, value)
            self.__ip_addr = response.get('ip', 'Not Found')
            self.__coordinates = response.get('loc', 'Not Found')
            self.__country = response.get('country', 'Not Found')
            self.__hostname = response.get('org', 'Not Found')
            self.__asn = response.get('ip', 'Not Found')
            self.__organization = response.get('org', 'Not Found')
            self.__route = response.get('ip', 'Not Found')
            self.__addr_type = response.get('ip', 'Not Found')
            self.__region = response.get('timezone', 'Not Found')
            self.__postcode = response.get('postal', 'Not Found')
            self.__city = response.get('city', 'Not Found')
            try:
                # self.__map_image = 'https://www.google.com/maps/embed/v1/view?zoom=10&center=%s&key=%s' % (self.__coordinates, API_KEY)
                # self.__map_image = f'https://maps.googleapis.com/maps/api/staticmap?center={lat_lon}&zoom=11&&size={IMG_SIZE}&key={API_KEY}'
                url = f'https://en.wikipedia.org/w/api.php?action=query&prop=extracts&titles={self.__city}&exintro=&exsentences=2&explaintext=&redirects=&formatversion=2&format=json'
                response = self._get_url(url)
                self.__description = self._regex_from_to(response, ',"extract":"', '"}]}')
            except:
                log(f'__description Error: {print_exc()}')
                self.__description = 'description Not Found on wiki'

            return {'ip_addr': self.__ip_addr,
                    'city': self.__city,
                    'region': self.__region,
                    'postcode': self.__postcode,
                    'coordinates': self.__coordinates,
                    'country': self.__country,
                    'hostname': self.__hostname,
                    'addr_type': self.__addr_type,
                    'asn': self.__asn,
                    'organization': self.__organization,
                    'route': self.__route,
                    'description': self.__description,
                    'map_image': self.__map_image}
        except:
            log(f'_ip_info Error: {print_exc()}')
            return 'Error getting IP address info!'

    def get_ip_info(self, ipaddr):
        """
        Return artist information as dictionary. If no result try either
        removing or prefixing the 'the' word.
        """
        self.clear()
        ipi = self._ip_info(ipaddr)
        # ipi = {'ip_addr': '14.1.120.0', 'description': '', 'postcode': '400703', 'map_image': 'https://www.google.com/maps/embed/v1/view?zoom=10&center=19.0323,73.0428&key=AIzaSyDIJ9XX2ZvRKCJcFRrl-lRanEtFUow4piM', 'asn': '14.1.120.0', 'city': 'Artist Village', 'country': 'IN', 'region': 'Asia/Kolkata', 'hostname': 'AS134881 JLINK INDIA', 'coordinates': '19.0323,73.0428', 'addr_type': '14.1.120.0', 'organization': 'AS134881 JLINK INDIA', 'route': '14.1.120.0'}
        # ipi: {'ip_addr': '206.189.68.216', 'description': 'Santa Clara (Portuguese and Spanish for Saint Clare or Saint Clair) may refer to:', 'postcode': '95051', 'map_image': 'https://www.google.com/maps/embed/v1/view?zoom=10&center=37.3483,-121.9844&key=AIzaSyDIJ9XX2ZvRKCJcFRrl-lRanEtFUow4piM', 'asn': '206.189.68.216', 'city': 'Santa Clara', 'country': 'US', 'region': 'America/Los_Angeles', 'hostname': 'AS14061 DigitalOcean, LLC', 'coordinates': '37.3483,-121.9844', 'addr_type': '206.189.68.216', 'organization': 'AS14061 DigitalOcean, LLC', 'route': '206.189.68.216'}
        log(f'ipi: {ipi}')
        return ipi

window = xbmcgui.Window(10147)

def set_property(prop, value):
    return window.setProperty(prop, value)

def test_WindowXMLDialog(win='nextep_win'):
    """
    Show ip info including location
    """

    # log('>>> test_WindowXMLDialog: {}'.format(addonInfo('path')))
    meta = {'tmdb_id': 96488, 'tvdb_id': 371242, 'imdb_id': 'tt9310136', 'rating': 6.7, 'plot': 'Based on a true story that spanned more than 30 years in which a young man was charged and convicted of brutally murdering his mother. Each episode is structured around an interrogation taken directly from the real police case files, with the goal of turning the viewer into a detective.', 'tagline': 'Justice is a matter of perspective.', 'votes': 20, 'premiered': '2020-02-05', 'year': '2020', 'poster': 'https://image.tmdb.org/t/p/w185/oJAvkzejtQzqwsDjkd8Y0m2oDL9.jpg', 'fanart': 'https://image.tmdb.org/t/p/w300/mvUvM6MLriYmmzAuuOznpPjbVSO.jpg', 'genre': ['Drama', 'Crime'], 'title': 'Interrogation', 'original_title': 'Interrogation', 'english_title': '', 'season_data': [{'air_date': '2020-02-05', 'episode_count': 10, 'id': 138202, 'name': 'Season 1', 'overview': '', 'poster_path': '/rC9T7UGmRKPK0C0BRcQUywVE6ZU.jpg', 'season_number': 1}], 'alternative_titles': [], 'duration': 2700, 'rootname': 'Interrogation (2020)', 'imdbnumber': 'tt9310136', 'country': ['United States of America'], 'mpaa': 'TV-MA', 'trailer': 'plugin://plugin.video.youtube/play/?video_id=bIGBrzjbtks', 'country_codes': ['US'], 'writer': [], 'director': [], 'all_trailers': [{'iso_639_1': 'en', 'iso_3166_1': 'US', 'name': 'Official Trailer', 'key': 'bIGBrzjbtks', 'site': 'YouTube', 'size': 1080, 'type': 'Trailer', 'official': True, 'published_at': '2020-01-12T23:38:05.000Z', 'id': '5e63b121459ad60018570747'}], 'cast': [{'name': 'Peter Sarsgaard', 'role': 'David Russell', 'thumbnail': 'https://image.tmdb.org/t/p/w185/jOc4VjxPaOkWOqnLCxd8BJy9g5i.jpg'}, {'name': 'Kyle Gallner', 'role': 'Eric Fisher', 'thumbnail': 'https://image.tmdb.org/t/p/w185/xY40mgzeGCJrV6P5Vlh2TgIOmkR.jpg'}, {'name': 'David Strathairn', 'role': 'Henry Fisher', 'thumbnail': 'https://image.tmdb.org/t/p/w185/fhkvTcrCDPTAclTnE7sqQS1NZKq.jpg'}, {'name': 'Kodi Smit-McPhee', 'role': 'Chris Keller', 'thumbnail': 'https://image.tmdb.org/t/p/w185/sesCWba9NwPDYDZzbVLs7OgLOti.jpg'}], 'studio': ['CBS All Access'], 'extra_info': {'status': 'Canceled', 'type': 'Scripted', 'homepage': 'https://www.paramountplus.com/shows/interrogation/', 'created_by': 'John Mankiewicz, Anders Weidemann', 'next_episode_to_air': None, 'last_episode_to_air': {'air_date': '2020-02-05', 'episode_number': 10, 'id': 2071848, 'name': 'I.A. Sgt. Ian Lynch & Det. Brian Chen vs Trey Carano 2003', 'overview': 'Twenty years after Mary Fisher s death, Internal Affairs Sgt. Lynch and Det. Chen fly to Texas to interview Trey Carano, a former friend of Eric s, who shares his account of Eric s whereabouts in the days and hours leading up to the murder.', 'production_code': '', 'runtime': 45, 'season_number': 1, 'show_id': 96488, 'still_path': '/yGgL588X4eF6vuAaMeDMiyRxAKQ.jpg', 'vote_average': 8.0, 'vote_count': 1}}, 'total_aired_eps': 10, 'mediatype': 'tvshow', 'total_seasons': 1, 'tvshowtitle': 'Interrogation', 'status': 'Canceled', 'poster2': 'https://assets.fanart.tv/fanart/tv/371242/tvposter/interrogation-5e3f0a6ff1c62.jpg', 'fanart2': 'https://assets.fanart.tv/fanart/tv/371242/showbackground/interrogation-5eb26359e9234.jpg', 'banner': 'https://assets.fanart.tv/fanart/tv/371242/tvbanner/interrogation-5edcd09889554.jpg', 'clearart': '', 'clearlogo': '', 'landscape': 'https://assets.fanart.tv/fanart/tv/371242/tvthumb/interrogation-5e3f0a8a0bb17.jpg', 'discart': '', 'keyart': '', 'fanart_added': True, 'clearlogo2': 'https://assets.fanart.tv/fanart/tv/371242/hdtvlogo/interrogation-5eb265b6c946e.png', 'ep_name': None, 'media_type': 'episode', 'season': 1, 'episode': 5, 'background': False, 'skip_option': {'title': 'Interrogation', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '60'}, 'skip_style': 'netflix'}
    _get = meta.get
    if win == 'nextep_win':
        window = xbmcgui.WindowXMLDialog('next_episode.xml', addonInfo('path'))
        # window = xbmcgui.WindowXMLDialog('confirm_progress_media.xml', addonInfo('path'), meta=meta)
    elif win == 'ip_win':
        window = xbmcgui.WindowXMLDialog('script-ip-2-location.xml', addonInfo('path'))
        netinfo = {'Internal IP': '10.0.0.55', 'Mac': '88:51:FB:7B:A9:CA', 'LinkState': 'Link: Connected', 'GatewayAddress': '10.0.0.1', 'DNS1Address': 'fec0:0:0:ffff::1', 'External IP': '73.54.225.198', 'ISP': 'COMCAST-7922', 'City': 'Conyers', 'Country': 'US', 'State': 'GA'}
        _get = netinfo.get
        # log(f'string: {window}')
        wid = xbmcgui.getCurrentWindowDialogId()
        log(f'winDialogid: {wid}')
        set_property('HeadingLabel', 'I.P. Info')
        set_property('City', _get('City', 'i c'))
        set_property('State', _get('State', 'i c'))
        set_property('Country', _get('Country', 'i c'))
        set_property('ISP', _get('ISP', 'i c'))
        set_property('Mac', _get('Mac', 'i c'))
        set_property('Internal IP', _get('Internal IP', 'i c'))
        set_property('External IP', _get('External IP', 'i c'))
        set_property('GatewayAddress', _get('GatewayAddress', 'i c'))
        set_property('LinkState', _get('LinkState', 'i c'))
        set_property('MapImage', 'https://i.imgur.com/onBTdVr.png')
    elif win == 'infopop':
        
        window = xbmcgui.WindowXMLDialog('infopopup.xml', addonInfo('path'))
        # wid = xbmcgui.getCurrentWindowId()
        # log(f'winid: {wid}')
    wid = xbmcgui.getCurrentWindowDialogId()
    log(f'winDialogid: {wid}')
    # window = xbmcgui.Window(wid)
    try:
        # window.set_property('media_type', 'tvshow')
        window.set_property('poster', _get('poster', ''))
        window.set_property('fanart', _get('fanart', ''))
        window.set_property('clearlogo', _get('clearlogo', ''))
        window.set_property('title', _get('title', 'i c'))
        window.set_property('plot', _get('plot', 'i c'))
        window.set_property('year', _get('year', '2000'))
        window.set_property('rating', str(_get('rating', '5')))
        window.set_property('mpaa', _get('mpaa', 'MA'))
        window.set_property('status', _get('status', 'Running'))
        window.set_property('genre', str(_get('genre', 'i c')))
        window.set_property('network', _get('network', 'CBS All Access'))
        window.set_property('duration', str(_get('duration', '1500')))
        window.set_property('progress', '2500')
        window.set_property('finish_watching', 'false')
        window.set_property('last_aired_episode', '10/10/2022')
        window.set_property('next_aired_episode', '11/12/2022')
        window.set_property('next_episode', '12')
        window.set_property('text_color', 'FF656565')
        window.set_property('maincolor_hex', 'FFCCCCCC')
        # window.set_property('enable_scrollbars', _get('enable_scrollbars', 'i c'))
        # window.set_property('enable_animation', _get('enable_animation', 'i c'))
    except: log(f'error: {print_exc()}')
    window.doModal()
    del window

    # from api import TextViewer
    # from modules.control import TextBox
    # i=0
    # string = ''
    # for item in netinfo:
        # i += 1
        # string += f'[B][COLOR red]{i:02d}:[/B][/COLOR] {item:15}: {netinfo.get('%s' % item)}[CR]'
    # log(f'string: {string}')
    # TextBox('--[ JP Tools Net Info ]--', string)



def ip2location():
    """
    Show ip info including location
    """
    from modules.ipinfo import IPInfo
    ip_info = IPInfo()
    ip_info = ip_info._ip_info()
    log(f'ip2location >>> ip_info: {ip_info}')
    # ip_info = {'ip_addr': '206.189.68.216', 'description': 'Santa Clara (Portuguese and Spanish for Saint Clare or Saint Clair) may refer to:', 'postcode': '95051', 'map_image': 'https://www.google.com/maps/embed/v1/view?zoom=10&center=37.3483,-121.9844&key=AIzaSyDIJ9XX2ZvRKCJcFRrl-lRanEtFUow4piM', 'asn': '206.189.68.216', 'city': 'Santa Clara', 'country': 'US', 'region': 'America/Los_Angeles', 'hostname': 'AS14061 DigitalOcean, LLC', 'coordinates': '37.3483,-121.9844', 'addr_type': '206.189.68.216', 'organization': 'AS14061 DigitalOcean, LLC', 'route': '206.189.68.216'}
    window = xbmcgui.WindowXMLDialog('script-ip-2-location.xml', addonInfo('path'))
    win = xbmcgui.Window(10147)
    win.setProperty('HeadingLabel', '[COLOR blue]Location for IP Address:[/COLOR] ' + ip_info.get('ip_addr'))
    win.setProperty('MapImage', ip_info.get('mapimage'))
    win.setProperty('Region', ip_info.get('region'))
    win.setProperty('City', ip_info.get('city'))
    win.setProperty('PostCode', ip_info.get('postcode'))
    win.setProperty('Coordinates', ip_info.get('coordinates'))
    win.setProperty('Country', ip_info.get('country'))
    win.setProperty('Hostname', ip_info.get('hostname'))
    win.setProperty('AddressType', ip_info.get('addrtype'))
    win.setProperty('ASN', ip_info.get('asn'))
    win.setProperty('Organization', ip_info.get('organization'))
    win.setProperty('Route', ip_info.get('route'))
    win.setProperty('Description', ip_info.get('description'))
    window.doModal()
    del window
    # this work
    # from modules.ipinfo import IPInfo
    # ip_info = IPInfo()
    # if ip_info == 'Error getting IP address info!':
        # infoDialog(ip_info, 'IP 2 Location')
    # else:
        # window = xbmcgui.WindowXMLDialog('script-ip-2-location.xml', addonInfo('path'))
        # win = xbmcgui.Window(10147)
        # win.setProperty('HeadingLabel', '[COLOR blue]Location for IP Address:[/COLOR] ' + ip_info.ip_addr)
        # win.setProperty('MapImage', ip_info.mapimage)
        # win.setProperty('Region', ip_info.region)
        # win.setProperty('City', ip_info.city)
        # win.setProperty('PostCode', ip_info.postcode)
        # win.setProperty('Coordinates', ip_info.coordinates)
        # win.setProperty('Country', ip_info.country)
        # win.setProperty('Hostname', ip_info.hostname)
        # win.setProperty('AddressType', ip_info.addrtype)
        # win.setProperty('ASN', ip_info.asn)
        # win.setProperty('Organization', ip_info.organization)
        # win.setProperty('Route', ip_info.route)
        # win.setProperty('Description', ip_info.description)
        # window.doModal()
        # del window


# Class to handle the creation of dummy addons
class AddonTemplate():
    def __init__(self):
        # Record where the root of all the addons should be
        self.addonRoot = xbmc.translatePath('special://masterprofile').decode('utf-8')
        # This will have got the user data, now get the parent directory of that
        self.addonRoot = os_path_join(os_path_split(self.addonRoot)[0], 'addons')
        # Make sure the directory ends in a slash
        self.addonRoot = os_path_join(self.addonRoot, '')
        self.addonTemplate = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<addon id="%s" name="%s" version="0.0.1" provider-name="robwebset">
    <requires>
        <import addon="xbmc.python" version="2.14.0"/>
    </requires>
    <extension point="xbmc.python.script" library="default.py"/>
    <extension point="xbmc.addon.metadata">
        <summary lang="en"></summary>
        <language></language>
        <platform>all</platform>
    </extension>
</addon>
'''

    # Create a dummy entry on disk for a given addon
    def createTemplateAddon(self, addonId, addonName):
        log(f'AddonTemplate: Creating template for id={addonId}, name={addonName}')

        # Create the correct directory in the addons section on disk
        if not xbmcvfs.exists(self.addonRoot):
            log(f'AddonTemplate: Addons directory does not exist: {self.addonRoot}')
            return False

        # Check if the addon directory already exists
        addonDir = os_path_join(self.addonRoot, addonId)
        addonDir = os_path_join(addonDir, '')
        if xbmcvfs.exists(addonDir):
            log(f'AddonTemplate: Addon directory already exists: {addonDir}')
            return False

        # Create the addon directory
        if not xbmcvfs.mkdir(addonDir):
            log(f'AddonTemplate: Failed to create addon directory {addonDir}')
            return False

        # Create the addon.xml file contents
        addonXml = self.addonTemplate % (addonId, addonName)
        addonXmlLocation = os_path_join(addonDir, 'addon.xml')

        # Create the addon.xml file on disk
        try:
            f = xbmcvfs.File(addonXmlLocation, 'wb')
            f.write(str(addonXml))
            f.close()
        except:
            log(f'AddonTemplate: Failed to create addon.xml file {addonXmlLocation} (error = {format_exc()})')
            return False

        return True


# Class to retrieve data from URepo
class URepo():
    def __init__(self, defaultUsername):
        self.url_prefix = 'https://github.com/robwebset/script.urepo.helper/blob/master/default.py'#base64.b64decode('aHR0cDovL3d3dy51cmVwby5vcmcvYXBpL3YxL2pzb24vMjU4OS8=')
        self.username = defaultUsername

    def getAddonCollection(self):
        collectionUrl = f'{self.url_prefix}?user={self.username}'

        collection = []

        # Make the call to theaudiodb.com
        xml_details = self._makeCall(collectionUrl)

        if xml_details not in [None, '']:
            repo_version = re.findall(r'<addon id=\"(.+?)\".+version=\"(\d*.\d*.\d*)\"', xml_details.text)#[0]
            log(f'get_addonupd_list >>> repo_version: {repo_version}')

            # The results of the search come back as an array of entries
            for addon in repo_version:
                # Skip the URepo helper addon, we don't want to install ourself
                if addon[0] in [None, '', 'script.urepo.helper']:
                    continue
                log(f'URepo: Addon collection: {addon[0]}')
                addonDetails = {'id': addon[0], 'vers': addon[1], 'zipname': f'{addon[0]}.{addon[1]}.zip'}
                collection.append(addonDetails)

        return collection

    # Perform the API call
    def _makeCall(self, url):
        log(f'makeCall: Making query using {url}')
        repo_xml = None
        try:
            import requests
            repo_xml = requests.get('https://bitbucket.org/jai_s/repojp/raw/HEAD/addons.xml')
            # repo_xml = requests.get('https://bitbucket.org/jai_s/repojp/raw/HEAD/plugin.video.infinity/addon.xml')
            if repo_xml.status_code != 200:
                log(f'status code = {repo_xml.status_code} >>> Could not connect to remote repo XML: {repo_xml}')

            # req = urllib2.Request(url)
            # req.add_header('Accept', 'application/json')
            # req.add_header('User-Agent', 'Kodi Browser')
            # response = urllib2.urlopen(req)
            # repo_xml = response.read()
            # try:
                # response.close()
                # log('makeCall: Request returned %s' % repo_xml)
            # except:
                # pass
        except:
            log(f'makeCall: Failed to retrieve details from {url}: {format_exc()}')

        return repo_xml


def get_addonupd_list():
    query = {"jsonrpc": "2.0", "id": "1", "method": "Addons.GetAddons", "params": {"properties": ["version"]}}
    json_response = jsonrpc(query)
    # log('json_response >>> json_response: %s' % json_response)
    has_addons = []
    addonItems = json_response[0]['result']['addons']
    # log('URepo: addonItems: %s' % json_response[0]['result']['addons'])
    for addonItem in addonItems:
        log(f'addonItem: {addonItem}')
        has_addons.append(f'{addonItem["addonid"]}-{addonItem["version"]}.zip')
    log(f'URepo: Detected Installed has_addons: {has_addons}')


def get_addonupd_list_test():
    query = {"jsonrpc": "2.0", "id": "1", "method": "Application.GetProperties", "params": {"properties": ["version", "name"]}}
    # query = {"jsonrpc": "2.0", "id": "1", "method": "Addons.GetAddonDetails", "params": {"addonid": "plugin.video.infinite", "properties": ["enabled"]}}
    # query = {"jsonrpc": "2.0", "id": "1", "method": "Addons.OutDated", "params": {}}
    # query = {"jsonrpc": "2.0", "id": "1", "method": "Addons.GetAddons", "params": {"type": "xbmc.player.musicviz"}}
    # query = {"jsonrpc": "2.0", "id": "1", "method": "Addons.GetAddons", "params": {"type": "xbmc.addon.video", "enabled": "all"}}
    query = {"jsonrpc": "2.0", "id": "1", "method": "Addons.GetAddons", "params": {"properties": ["enabled", "version", "broken", "name", "extrainfo", "dependencies"]}}
    # query = {"jsonrpc": "2.0", "id": "1", "method": "Addons.GetAddons", "params": {"type": "xbmc.addon.video", "properties": ["version", "name", "broken", "dependencies"]}}
    query = {"jsonrpc": "2.0", "id": "1", "method": "Addons.GetAddons", "params": {"properties": ["version"]}}
    json_response = jsonrpc(query)
    # log('json_response >>> json_response: %s' % json_response)
    has_addons = []
    addonItems = json_response[0]['result']['addons']
    # log('URepo: addonItems: %s' % json_response[0]['result']['addons'])
    for addonItem in addonItems:
        log(f'addonItem: {addonItem}')
        has_addons.append(f'{addonItem["addonid"]}.{addonItem["version"]}.zip')
    log(f'URepo: Detected Installed has_addons: {has_addons}')
    # sys.exit(0)
    if ('result' in json_response) and ('addons' in json_response['result']):
        addonItems = json_response['result']['addons']
        log(f'URepo: addonItems: {addonItems}')
        for addonItem in addonItems:
            log(f'URepo: Detected Installed addonItem: {addonItem}')
            has_addons.append(f'{addonItem["addonid"]}.{addonItem["version"]}.zip')
            if addonItem['enabled'] is True and addonItem['broken'] is False:
                has_addons.append(f'{addonItem["addonid"]}.{addonItem["version"]}.zip')
                if (
                    addonItem['type'] == 'xbmc.addon.repository'
                    and addonItem['addonid'] == 'repository.JPB'
                ):
                    urepoInstalled = True
    log(f'URepo: Detected Installed has_addons: {has_addons}')
    # sys.exit(0)

    if urepoInstalled:
        try:
            xbmc.executebuiltin('ActivateWindow(busydialog)')

            # Make a call to the URepo repository to get the list of addons
            # selected for this user
            urepo = URepo('iamhear')
            urepoAddons = urepo.getAddonCollection()
            del urepo
            log(f'get_addonupd_list >>> urepoAddons: {urepoAddons}')

            requiredAddons = []

            if len(urepoAddons) > 0:
                existingAddons = []

                # Make the call to find out all the addons that are currently installed
                json_query = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Addons.GetAddons", "params": { "properties": ["enabled"] }, "id": 1}')
                json_response = json.loads(json_query)
                log(f'URepo: Detected Installed json_response: {json_response}')

                if ('result' in json_response) and ('addons' in json_response['result']):
                    # Check each of the addons that are installed on the system
                    for addonItem in json_response['result']['addons']:
                        addonId = addonItem['addonid']
                        log(f'URepo: Detected Installed Addon: {addonId}')
                        existingAddons.append(addonId)

                # Remove any addon that is already installed
                for urepoAddon in urepoAddons:
                    if urepoAddon['id'] in existingAddons:
                        log(f'URepo: Skipping {urepoAddon["id"]} as already installed')
                    else:
                        requiredAddons.append(urepoAddon)
        finally:
            xbmc.executebuiltin('Dialog.Close(busydialog)')
        log(f'get_addonupd_list >>> requiredAddons: {requiredAddons}')
        if requiredAddons:
            selected = []
            displayList = [anAddon['name'] for anAddon in requiredAddons]
            # Display a list of addons that will be installed
            # From Kodi v17 onwards there is an option to pre-select the items in the list
            if kodiVersion > 16:
                preselectIdxs = list(range(len(requiredAddons)))
                selected = xbmcgui.Dialog().multiselect(ADDON.getLocalizedString('Select Addons To Install'), displayList, preselect=preselectIdxs)
            else:
                selected = xbmcgui.Dialog().multiselect(ADDON.getLocalizedString('Select Addons To Install'), displayList)

            if (selected in [None, '']) or (len(selected) < 1):
                log('URepo: Install operation cancelled, no addons to install')
            else:
                addonsToInstall = [requiredAddons[i] for i in selected]

    # Perform the installation for the required addons
    # if len(addonsToInstall) > 0:
        # successCountDisplay = ''
        # failedCountDisplay = ''
        # # Now create a template for each addon
        # addonTemplate = AddonTemplate()
        # for addon in addonsToInstall:
            # addonTemplate.createTemplateAddon(addon['id'], addon['name'])
        # # The following call will read in the template addons that were created
        # # into the Kodi installation, however they will be marked as disabled
        # xbmc.executebuiltin('UpdateLocalAddons', True)
        # xbmc.sleep(1000)
        # # Make a call for each addon to enable it as it will have been added as disabled originally
        # for addonToInstall in addonsToInstall:
            # log("URepo: Enabling addon %s" % addonToInstall['id'])
            # xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Addons.SetAddonEnabled", "params": { "addonid": "%s", "enabled": "toggle" }, "id": 1}' % addonToInstall['id'])
        # xbmc.sleep(1000)
        # # Now force a refresh of all the addons so that we get the templates that
        # # were created replaced with the real addons
        # xbmc.executebuiltin('UpdateAddonRepos', True)


# if __name__ == '__main__':
#     ip_info = IPInfo()
#     log(ip_info)
