
from modules.service import jpmain
from modules.control import log


if __name__ == '__main__':
	log('Main Monitor Service Starting')

	with jpmain() as jmain:
		jmain.startUpServices()
		jmain.waitForAbort()

	log('Main Monitor Service Stopped')