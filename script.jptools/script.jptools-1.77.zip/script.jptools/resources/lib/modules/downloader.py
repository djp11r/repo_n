import os
import time
import threading
import asyncio
from concurrent.futures import ThreadPoolExecutor
import urllib.request
from modules.control import log

# Try to import httpx; if unavailable, fall back to urllib
try:
    import httpx
    HAS_HTTPX = True
except Exception as err:
    # log(f"Download Exception: {err}")
    httpx = None
    HAS_HTTPX = False


class _NullDP:
    def update(self, *args, **kwargs):
        pass

    def create(self, *args, **kwargs):
        pass

    def close(self):
        pass

    def iscanceled(self):
        return False


class Downloader:
    """
    Async-capable downloader with automatic resume and httpx -> urllib fallback.

    Public API:
      - await download_async(url, dest, dp=None)
      - download(url, dest, dp=None)  # sync wrapper (returns coroutine if called inside running loop)
    """

    def __init__(self, headers=None, timeout=10, retries=3, backoff=2, threads=4, logger=None, quiet=False):
        self.headers = headers or {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"}
        self.timeout = timeout
        self.retries = retries
        self.backoff = backoff
        self.threads = max(1, threads)
        self.quiet = quiet

        # Logging
        self.log = (lambda msg: None) if quiet else (logger or (lambda msg: None))

        # Progress tracking
        self.downloaded_lock = threading.Lock()
        self.total_downloaded = 0
        self.displayed_downloaded = 0
        self.smoothing_factor = 0.15  # lower = smoother, higher = snappier

        # Executor for blocking fallback
        self._executor = ThreadPoolExecutor(max_workers=self.threads)

    # ----------------- Progress helper -----------------

    def _smooth_progress(self, actual, total, dp, start_time):
        if self.quiet: return
        with self.downloaded_lock:
            self.displayed_downloaded += (actual - self.displayed_downloaded) * self.smoothing_factor
            downloaded = self.displayed_downloaded

        if total <= 0:
            percent = 0
            total_mb = 0
        else:
            percent = min(downloaded * 100 / total, 100)
            total_mb = total / (1024 * 1024)

        downloaded_mb = downloaded / (1024 * 1024)
        elapsed = time.time() - start_time
        speed = downloaded / elapsed if elapsed > 0 else 0
        speed_kb = speed / 1024

        if speed > 0 and percent < 100 and total > 0: eta = (total - downloaded) / speed
        else: eta = 0

        eta_m = int(eta // 60)
        eta_s = int(eta % 60)

        dp.update(
            int(percent),
            f"{downloaded_mb:.02f} MB of {total_mb:.02f} MB"
            f"[CR]Speed: {speed_kb:.02f} KB/s  ETA: {eta_m:02d}:{eta_s:02d}"
            f"[CR]Downloading... Please Wait..."
        )

        if dp.iscanceled():
            dp.close()
            raise Exception("Canceled")

    # ----------------- urllib blocking helpers (used in executor) -----------------

    def _build_urllib_request(self, url, range_header=None, method=None):
        req = urllib.request.Request(url)
        if method:
            try:
                req.get_method = lambda: method
            except Exception:
                pass
        for k, v in self.headers.items():
            req.add_header(k, v)
        if range_header:
            req.add_header("Range", range_header)
        return req

    def _single_thread_download_blocking(self, url, dest, dp, total_size):
        """Blocking single-thread download using urllib (runs in executor). Supports resume."""
        self.log("Starting single-thread streaming download (urllib)")
        dp.update(0)
        start_time = time.time()

        existing = 0
        if os.path.exists(dest):
            existing = os.path.getsize(dest)
            if existing >= total_size > 0:
                self.log("Destination already complete (urllib single-thread).")
                with self.downloaded_lock:
                    self.total_downloaded = existing
                dp.update(100)
                dp.close()
                return True

        # Request remaining bytes
        range_header = f"bytes={existing}-" if existing > 0 else None
        req = self._build_urllib_request(url, range_header, method="GET")
        with urllib.request.urlopen(req, timeout=self.timeout) as response:
            # If server doesn't support range, it will return full content; handle accordingly
            content_length = int(response.headers.get("Content-Length", 0) or 0)
            # If we requested a range, content_length is remaining bytes
            mode = "ab" if existing > 0 else "wb"
            downloaded = existing
            with open(dest, mode, buffering=256 * 1024) as f:
                while True:
                    chunk = response.read(64 * 1024)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)
                    with self.downloaded_lock:
                        self.total_downloaded = downloaded
                    self._smooth_progress(downloaded, total_size, dp, start_time)

        dp.update(100)
        dp.close()
        self.log("Single-thread download complete (urllib)")
        return True

    def _download_chunk_blocking(self, url, dest, start, end, thread_id):
        """Blocking chunk download using urllib (runs in executor). Supports resume per-part."""
        temp_file = f"{dest}.part{thread_id}"
        attempt = 0
        chunk_size = 64 * 1024          # 64 KB starting point
        min_chunk = 16 * 1024           # 16 KB
        max_chunk = 1024 * 1024         # 1 MB

        # Determine already downloaded bytes for this part
        existing = os.path.getsize(temp_file) if os.path.exists(temp_file) else 0
        part_total = end - start + 1
        if existing >= part_total:
            self.log(f"Part {thread_id} already complete (urllib).")
            with self.downloaded_lock:
                self.total_downloaded += part_total
            return True

        while attempt <= self.retries:
            try:
                # Start from existing offset within the part
                part_start = start + existing
                range_header = f"bytes={part_start}-{end}"
                req = self._build_urllib_request(url, range_header, method="GET")
                self.log(f"Thread {thread_id} downloading {range_header} (attempt {attempt+1})")
                with urllib.request.urlopen(req, timeout=self.timeout) as response:
                    # append to temp file
                    with open(temp_file, "ab", buffering=256 * 1024) as f:
                        pos = part_start
                        while pos <= end:
                            t0 = time.time()
                            chunk = response.read(chunk_size)
                            dt = time.time() - t0
                            if not chunk: break
                            f.write(chunk)
                            pos += len(chunk)
                            
                            # Atomic progress update
                            with self.downloaded_lock:
                                self.total_downloaded += len(chunk)
                            
                            # Adaptive chunk sizing
                            if dt < 0.05: chunk_size = min(chunk_size * 2, max_chunk)
                            elif dt > 0.25: chunk_size = max(chunk_size // 2, min_chunk)
                self.log(f"Thread {thread_id} finished successfully (urllib)")
                return True

            except Exception as e:
                attempt += 1
                self.log(f"Thread {thread_id} error (urllib): {e} (retry {attempt}/{self.retries})")
                if attempt > self.retries:
                    self.log(f"Thread {thread_id} failed permanently (urllib)")
                    raise
                time.sleep(self.backoff ** attempt)
        return False

    # ----------------- httpx async helpers (guarded) -----------------

    async def _single_thread_download_httpx(self, url, dest, dp, total_size):
        """Async single-thread download with resume support."""
        if not HAS_HTTPX:
            raise RuntimeError("httpx is not installed; install httpx or use the urllib fallback")
        self.log("Starting single-thread streaming download (httpx async)")
        dp.update(0)
        start_time = time.time()

        existing = 0
        if os.path.exists(dest):
            existing = os.path.getsize(dest)
            if existing >= total_size > 0:
                self.log("Destination already complete (httpx single-thread).")
                with self.downloaded_lock:
                    self.total_downloaded = existing
                dp.update(100)
                dp.close()
                return True

        range_header = f"bytes={existing}-" if existing > 0 else None
        headers = {**self.headers, **({"Range": range_header} if range_header else {})}
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            async with client.stream("GET", url, headers=headers) as response:
                mode = "ab" if existing > 0 else "wb"
                downloaded = existing
                with open(dest, mode, buffering=256 * 1024) as f:
                    async for chunk in response.aiter_bytes(chunk_size=64 * 1024):
                        if not chunk:
                            break
                        f.write(chunk)
                        downloaded += len(chunk)
                        with self.downloaded_lock:
                            self.total_downloaded = downloaded
                        self._smooth_progress(downloaded, total_size, dp, start_time)

        dp.update(100)
        dp.close()
        self.log("Single-thread download complete (httpx async)")
        return True

    async def _download_chunk_httpx(self, url, dest, start, end, thread_id):
        """Async chunk download with resume support per-part."""
        if not HAS_HTTPX:
            raise RuntimeError("httpx is not installed; install httpx or use the urllib fallback")
        temp_file = f"{dest}.part{thread_id}"
        attempt = 0
        chunk_size = 64 * 1024
        min_chunk = 16 * 1024
        max_chunk = 1024 * 1024

        existing = os.path.getsize(temp_file) if os.path.exists(temp_file) else 0
        part_total = end - start + 1
        if existing >= part_total:
            self.log(f"Part {thread_id} already complete (httpx).")
            with self.downloaded_lock:
                self.total_downloaded += part_total
            return True

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            while attempt <= self.retries:
                try:
                    part_start = start + existing
                    range_header = f"bytes={part_start}-{end}"
                    headers = {**self.headers, "Range": range_header}
                    self.log(f"Async chunk {thread_id} downloading {range_header} (attempt {attempt+1})")
                    async with client.stream("GET", url, headers=headers) as response:
                        with open(temp_file, "ab", buffering=256 * 1024) as f:
                            pos = part_start
                            async for chunk in response.aiter_bytes(chunk_size=chunk_size):
                                t0 = time.time()
                                if not chunk:
                                    break
                                f.write(chunk)
                                pos += len(chunk)
                                with self.downloaded_lock:
                                    self.total_downloaded += len(chunk)
                                dt = time.time() - t0
                                if dt < 0.05:
                                    chunk_size = min(chunk_size * 2, max_chunk)
                                elif dt > 0.25:
                                    chunk_size = max(chunk_size // 2, min_chunk)
                    self.log(f"Async chunk {thread_id} finished successfully")
                    return True
                except Exception as e:
                    attempt += 1
                    self.log(f"Async chunk {thread_id} error: {e} (retry {attempt}/{self.retries})")
                    if attempt > self.retries:
                        self.log(f"Async chunk {thread_id} failed permanently")
                        raise
                    await asyncio.sleep(self.backoff ** attempt)
        return False

    # ----------------- Merge helper -----------------

    def _merge_chunks(self, dest):
        """Merge chunks with larger buffer for efficiency"""
        self.log("Merging chunk files")
        with open(dest, "wb", buffering=512 * 1024) as outfile:  # 512KB buffer
            part = 0
            while True:
                part_file = f"{dest}.part{part}"
                if not os.path.exists(part_file): break
                with open(part_file, "rb", buffering=512 * 1024) as pf:  # 512KB buffer
                    while True:
                        chunk = pf.read(1024 * 1024)  # 1MB chunks
                        if not chunk: break
                        outfile.write(chunk)
                os.remove(part_file)
                part += 1
        self.log("Merge complete")

    # ----------------- Public async API -----------------

    async def download_async(self, url, dest, dp=None):
        if self.quiet or dp is None: dp = _NullDP()
        else: dp.create("Downloader", "")

        dp.update(0)
        self.displayed_downloaded = 0
        self.total_downloaded = 0

        # Determine total size and range support
        total_size = 0
        range_supported = False

        if HAS_HTTPX:
            try:
                async with httpx.AsyncClient(timeout=self.timeout) as client:
                    resp = await client.head(url, headers=self.headers)
                    total_size = int(resp.headers.get("Content-Length", 0) or 0)
                    range_supported = resp.headers.get("Accept-Ranges", "").lower() != "none"
            except Exception as e:
                self.log(f"HEAD (httpx) failed: {e}")
                total_size = 0
                range_supported = False
        else:
            # Blocking HEAD in executor
            def _head_blocking():
                try:
                    req = self._build_urllib_request(url, method="HEAD")
                    with urllib.request.urlopen(req, timeout=self.timeout) as r:
                        return r.headers.get("Content-Length", 0), r.headers.get("Accept-Ranges", "")
                except Exception as e:
                    self.log(f"HEAD (urllib) failed: {e}")
                    return 0, ""
            content_length, accept_ranges = await asyncio.get_running_loop().run_in_executor(self._executor, _head_blocking)
            total_size = int(content_length or 0)
            range_supported = (accept_ranges or "").lower() != "none"

        # If server doesn't provide total_size, try to continue anyway (resume may be limited)
        if total_size <= 0:
            self.log("Total size unknown; resume may be limited.")

        # Single-thread fallback or server doesn't support ranges
        if not range_supported or self.threads == 1 or total_size <= 0:
            self.log("Falling back to single-thread mode")
            if HAS_HTTPX:
                return await self._single_thread_download_httpx(url, dest, dp, total_size)
            else:
                return await asyncio.get_running_loop().run_in_executor(self._executor, self._single_thread_download_blocking, url, dest, dp, total_size)

        # Multi-chunk download with resume: compute per-part ranges and existing bytes
        self.log(f"Starting multi-chunk download with {self.threads} workers")
        start_time = time.time()
        chunk_size = total_size // self.threads
        tasks = []

        # Seed total_downloaded from existing parts Pre-calc existing bytes from part files to seed total_downloaded
        existing_total = 0
        for i in range(self.threads):
            part_file = f"{dest}.part{i}"
            if os.path.exists(part_file):
                existing_total += os.path.getsize(part_file)
        # Also include dest if it exists and appears to be a merged file (rare)
        if os.path.exists(dest):
            existing_total += os.path.getsize(dest)
        with self.downloaded_lock:
            self.total_downloaded = existing_total

        if HAS_HTTPX:
            for i in range(self.threads):
                start = i * chunk_size
                end = (i + 1) * chunk_size - 1 if i < self.threads - 1 else total_size - 1
                tasks.append(asyncio.create_task(self._download_chunk_httpx(url, dest, start, end, i)))
        else:
            loop = asyncio.get_running_loop()
            for i in range(self.threads):
                start = i * chunk_size
                end = (i + 1) * chunk_size - 1 if i < self.threads - 1 else total_size - 1
                tasks.append(loop.run_in_executor(self._executor, self._download_chunk_blocking, url, dest, start, end, i))

        # Progress loop: update until all tasks complete
        while True:
            done, pending = await asyncio.wait(tasks, timeout=0.2, return_when=asyncio.FIRST_COMPLETED)
            with self.downloaded_lock:
                downloaded = self.total_downloaded
            self._smooth_progress(downloaded, total_size, dp, start_time)
            if not pending:
                break

        # Ensure all tasks finished Gather results and propagate exceptions
        results = await asyncio.gather(*tasks, return_exceptions=True)
        for r in results:
            if isinstance(r, Exception):
                raise r

        # Merge parts into final file
        self._merge_chunks(dest)

        dp.update(100)
        dp.close()
        self.log("Download complete")
        return True

    # ----------------- Sync wrapper -----------------

    def download(self, url, dest, dp=None):
        """
        Synchronous wrapper. If called inside an existing event loop, returns coroutine.
        Otherwise runs the async download to completion.
        """
        try:
            loop = asyncio.get_running_loop()
            # Running loop exists: return coroutine for caller to await
            return self.download_async(url, dest, dp)
        except RuntimeError:
            # No running loop; run to completion
            return asyncio.run(self.download_async(url, dest, dp))


# Optional: default instance (remove if you prefer explicit instantiation)
#downloader = Downloader(headers={"User-Agent": "MyAddon/1.0"}, timeout=10, retries=3, backoff=2, threads=4, logger=log, quiet=False)

def make_downloader():
    return Downloader(
        headers={"User-Agent": "MyCLI/1.0"},
        timeout=20,
        retries=3,
        backoff=2,
        threads=4,
        logger=log,
        quiet=False
    )

async def run_async(url, dest, dp):
    dl = make_downloader()
    await dl.download_async(url, dest, dp)

def run_sync(url, dest, dp):
    dl = make_downloader()
    # download() will run the async flow to completion when called from sync code
    dl.download(url, dest, dp)

def dl_call(url, dest, mode="sync", dp=None):
    # dp can be your progress object; using None will use the internal _NullDP

    # p = argparse.ArgumentParser(description="Simple downloader CLI (resume-capable)")
    # p.add_argument("mode", choices=["sync", "async"], help="run mode")
    # p.add_argument("url", help="URL to download")
    # p.add_argument("dest", help="Destination file path")
    # args = p.parse_args()

    if mode == "sync":
        run_sync(url, dest, dp)
    else:
        # If already inside an event loop, this returns a coroutine; handle both cases
        try:
            loop = asyncio.get_running_loop()
            # running loop exists — schedule and wait
            coro = run_async(url, dest, dp)
            loop.run_until_complete(coro)
        except RuntimeError:
            # no running loop — safe to use asyncio.run
            asyncio.run(run_async(url, dest, dp))


# if __name__ == "__main__":
    # main()

"""
downloader.py — simple CLI for Downloader

Usage examples:
  # synchronous (runs to completion)
  python downloader.py sync https://example.com/file.zip /tmp/file.zip

  # asynchronous (await inside an event loop)
  python downloader.py async https://example.com/file.zip /tmp/file.zip

  # show resume behavior: run the same command again after interruption
"""