from __future__ import annotations

import asyncio
import hashlib
import random
import re
import time
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Iterable, Sequence

import xbmcvfs
import xbmcgui

from modules.wiz import extractzip
from modules.control import (
    dp,
    addons_path,
    infodialog,
    kodi_open,
    transpath,
    existspath,
    getsetting,
    joinpath,
    jsonrpc,
    listdir,
    log,
    packages,
    platform,
)
from modules.maintenance import purgepackages

dont_install = ('inputstream.ffmpegdirect', 'inputstream.adaptive', 'inputstream.rtmp')
os_sys = platform()
#  SETTINGS 

def is_silent_service() -> bool:
    """Return True if service should run without UI."""
    return getsetting("service.silent_update") == "true"

def use_background_dialog() -> bool:
    """Return True if user prefers background progress."""
    return getsetting("service.background_progress") == "true"


@dataclass(frozen=True)
class AddonFile:
    name: str
    filename: str
    path: str

#  VERSION PARSING 

VersionTuple = Tuple[int, int, int, int, int]

PRERELEASE_ORDER: Dict[Optional[str], int] = {
    None: 3,
    "alpha": 0, "a": 0,
    "beta": 1, "b": 1,
    "rc": 2, "pre": 2,
    "matrix": 3,
}

_PRE_RE = re.compile(r"(alpha|beta|rc|a|b|pre|matrix)[\.\-]?(\d*)", re.IGNORECASE)
_NUM_RE = re.compile(r"\d+")
_CLEAN_RE = re.compile(r"[+~ ]")


def normalize_version(vers_str: str) -> VersionTuple:
    try:
        s = vers_str.split("-", 1)[1].lower()
    except IndexError:
        return 0, 0, 0, PRERELEASE_ORDER[None], 0

    s = _CLEAN_RE.sub("", s)
    if s.endswith(".zip"):
        s = s[:-4]

    pre = _PRE_RE.search(s)
    if pre:
        tag = pre.group(1).lower()
        num = int(pre.group(2) or 0)
        rank = PRERELEASE_ORDER.get(tag, PRERELEASE_ORDER[None])
        s = s.replace(pre.group(0), "")
    else:
        rank = PRERELEASE_ORDER[None]
        num = 0

    nums = _NUM_RE.findall(s)
    major = int(nums[0]) if len(nums) > 0 else 0
    minor = int(nums[1]) if len(nums) > 1 else 0
    patch = int(nums[2]) if len(nums) > 2 else 0

    return major, minor, patch, rank, num


#  SYNC HELPERS 


def dl_zip_smb(src: str, dest: Optional[str] = None, chunk: int = 256 * 1024) -> None:
    """
    Synchronous SMB copy using chunked reads.
    """
    if dest is None:
        filename = src.rsplit("/", 1)[-1]
        dest = transpath(joinpath(packages, filename))

    if not existspath(src):
        log(f'Source missing: src: {src}')
        return

    if not dest.endswith((".zip", ".log")):
        log(f'Destination extension invalid: dest: {dest}')
        return

    try:
        with kodi_open(src, 'r') as s, kodi_open(dest, "w") as d:
            while True:
                buf = s.readBytes(chunk)
                if not buf:
                    break
                d.write(buf)
        log(f'SMB copy complete: src: {src}, dest: {dest}')
    except Exception as exc:
        log(f'SMB copy failed: src: {src}, dest: {dest}, error: {str(exc)}')

def get_file_older_then_hrs(path: str, hours: int = 168) -> bool:
    try:
        f = xbmcvfs.Stat(path)
        file_time = f.st_mtime()
    except Exception as exc:
        log(f'Stat failed: path: {path}, error: {str(exc)}')
        return False

    cutoff = time.time() - (hours * 3600)
    return file_time > cutoff


def intersect(installed: List[str], available: List[str], age: int = 0, smb_dir: Optional[str] = None) -> Tuple[List[str], List[str]]:
    """Find newer and same versions of installed packages in available list."""
    inst_map: Dict[str, List[str]] = {}
    for inst in installed:
        base = inst.split("-", 1)[0]
        inst_map.setdefault(base, []).append(inst)

    newfiles_dict: Dict[str, str] = {}
    samefiles: List[str] = []

    for avail in available:
        base = avail.split("-", 1)[0]
        if base in dont_install and os_sys == 'windows':
            continue
        if base not in inst_map:
            continue

        for inst in inst_map[base]:
            if inst.count("-") > 1:
                continue

            avail_ver = normalize_version(avail)
            inst_ver = normalize_version(inst)

            if avail_ver > inst_ver:
                if base not in newfiles_dict or avail_ver > newfiles_dict[base]:
                    newfiles_dict[base] = (avail)
            elif avail_ver == inst_ver:
                # Only add to samefiles if NO newer version exists for this base
                if base not in newfiles_dict:
                    smb_file = joinpath(smb_dir, avail)
                    if get_file_older_then_hrs(smb_file, age):
                        samefiles.append(avail)

    newfiles = [v for v in newfiles_dict.values()]
    return newfiles, samefiles


def get_install(path):
    query = {
        "jsonrpc": "2.0",
        "id": "1",
        "method": "Addons.GetAddons",
        "params": {"properties": ["version"]},
    }
    resp = jsonrpc(query)
    addons = resp[0]["result"]["addons"]

    installed = [f'{a["addonid"]}-{a["version"]}.zip' for a in addons]
    return installed

#  ASYNC WRAPPERS 

async def _to_thread(func, *args, **kwargs):
    return await asyncio.to_thread(func, *args, **kwargs)


async def async_listdir(path: str):
    return await _to_thread(listdir, path)


async def async_install_listdir(path: str):
    return await _to_thread(get_install, path)


async def async_extractzip_atomic(zip_path: str, dest_root: str):
    """
    Atomic-ish install: extract from a fully written zip.
    (You can extend this to extract into a temp dir then move.)
    """
    try:
        await _to_thread(extractzip, zip_path, dest_root)
    except Exception:
        log(f'[unZip File] Unable to extract: {zip_path}')


#  PROGRESS CONTROLLER 

class ProgressController:
    def __init__(self):
        self.silent = is_silent_service()
        self.bg = use_background_dialog()
        self.dialog = None

    def create(self, title, msg):
        if self.silent:
            return
        if self.bg:
            self.dialog = xbmcgui.DialogProgressBG()
            self.dialog.create(title, msg)
        else:
            dp.create(title, msg)

    def update(self, percent, line1=""):
        if self.silent:
            return
        if self.bg and self.dialog:
            self.dialog.update(percent, line1)
        else:
            dp.update(percent, line1)

    def close(self):
        if self.silent:
            return
        if self.bg and self.dialog:
            self.dialog.close()
        else:
            dp.close()


#  SMB DOWNLOAD: ADAPTIVE + RETRY + HASH 

async def async_dl_zip_smb_with_retry(
    src: str,
    dest_temp: str,
    retries: int = 3,
    backoff_base: float = 0.5,
    fallback_src: Optional[str] = None,
    expected_hash: Optional[str] = None,
    hash_algo: str = "sha256",
):
    """
    Adaptive chunk SMB copy with retry, fallback, and optional hash verification.
    Writes to dest_temp (caller does atomic rename).
    """
    if not existspath(src):
        log(f'[smb] source missing: {src}')
        return False

    hasher = hashlib.new(hash_algo) if expected_hash else None

    async def _copy_once(path) -> bool:
        chunk_size = 64 * 1024
        max_chunk = 1024 * 1024
        min_chunk = 32 * 1024
        bytes_this_window = 0
        window_start = time.time()

        def _copy_body():
            nonlocal chunk_size, bytes_this_window, window_start
            with kodi_open(path, 'r') as s, kodi_open(dest_temp, "w") as d:
                while True:
                    buf = s.readBytes(chunk_size)
                    if not buf:
                        break
                    d.write(buf)
                    if hasher:
                        hasher.update(buf)
                    bytes_this_window += len(buf)
                    now = time.time()
                    if now - window_start >= 1.0:
                        speed = bytes_this_window / (now - window_start)
                        if speed > 5 * 1024 * 1024 and chunk_size < max_chunk:
                            chunk_size = min(max_chunk, chunk_size * 2)
                        elif speed < 1 * 1024 * 1024 and chunk_size > min_chunk:
                            chunk_size = max(min_chunk, chunk_size // 2)
                        bytes_this_window = 0
                        window_start = now

        await _to_thread(_copy_body)
        return True

    # primary
    for attempt in range(1, retries + 1):
        try:
            # log(f"[smb] attempt {attempt}/{retries}: {src}")
            ok = await _copy_once(src)
            if ok:
                break
        except Exception as exc:
            wait = backoff_base * (2 ** (attempt - 1)) + random.uniform(0, 0.3)
            log(f"[smb] failed attempt {attempt}: {exc}, retrying in {wait:.2f}s")
            await asyncio.sleep(wait)
    else:
        # fallback
        if fallback_src:
            log(f"[smb] switching to fallback: {fallback_src}")
            try:
                ok = await _copy_once(fallback_src)
                if not ok:
                    log(f"[smb] fallback failed: {fallback_src}")
                    return False
            except Exception as exc:
                log(f"[smb] fallback exception: {exc}")
                return False
        else:
            log(f"[smb] giving up: {src}")
            return False

    if expected_hash and hasher:
        actual = hasher.hexdigest()
        if actual.lower() != expected_hash.lower():
            log(f"[hash] mismatch for {src}: expected {expected_hash}, got {actual}")
            return False
        log(f"[hash] verified {src} ({hash_algo})")

    return True


#  ASYNC FULL PIPELINE (PARALLEL, ATOMIC) 

async def async_run_full_update_pipeline(
    smb_dir: str,
    age: int = 168,
    fallback_dir: Optional[str] = None,
    expected_hashes: Optional[Dict[str, str]] = None,  # filename -> hash
):
    pc = ProgressController()
    stage_times = {}
    addon_times: Dict[str, Dict[str, Dict[str, float]]] = {}

    def stage_start(name):
        stage_times[name] = {"start": time.time()}

    def stage_end(name):
        duration = time.time() - stage_times[name]["start"]
        log(f"[stage] {name:.<18}: duration {duration:.2f}")

    # Stage 1: installed
    stage_start("async_run_full")
    stage_start("scan_installed")
    pc.create("Addon Updater", "Scanning installed addons...")
    pc.update(0, "Scanning installed addons")
    try:
        installed = (await async_install_listdir(f'{addons_path}/'))#[1]
    except Exception as err:
        log(f"async_listdir {addons_path}: err: {err}")
        installed = []
    await asyncio.sleep(0.05)
    stage_end("scan_installed")

    # Stage 2: smb
    stage_start("scan_smb")
    pc.update(10, "Scanning available updates...")
    try:
        available = (await async_listdir(smb_dir))[1]
    except Exception as err:
        log(f"async_listdir {smb_dir}: err: {err}")
        available = []
    await asyncio.sleep(0.05)
    stage_end("scan_smb")

    # Stage 3: compare
    stage_start("compare_versions")
    pc.update(25, "Comparing versions...")
    # log(f"Async pipeline . installed= {installed}\navailable= {available}\n = {age}\nsmb_dir = {smb_dir}")
    newfiles, samefiles = intersect(installed, available, age, smb_dir)
    files = newfiles + samefiles
    total_updates = len(files)
    await asyncio.sleep(0.05)
    stage_end("compare_versions")

    # Stage 4: download+install (parallel)
    stage_start("download_install")

    if total_updates == 0:
        pc.update(100, "No updates available")
        await asyncio.sleep(0.2)
        pc.close()
        log("Async pipeline complete. No updates found.")
        stage_end("download_install")
        stage_end("async_run_full")
        infodialog('SMB DL files No updates found..')
        return

    purgepackages()
    pc.update(40, f"Preparing to update {total_updates} addons...")
    # log(f"Preparing to update {total_updates} addons...")

    progress = {"done": 0}

    async def worker(fname: str):
        addon_name = fname.split("-", 1)[0]
        addon_times[addon_name] = {}

        src = joinpath(smb_dir, fname)
        fb_src = joinpath(fallback_dir, fname) if fallback_dir else None

        temp_dest = transpath(joinpath(packages, fname + ".part"))
        final_dest = transpath(joinpath(packages, fname))

        # download timing
        stage_start(f"{fname} download")

        expected_hash = expected_hashes.get(fname) if expected_hashes else None
        ok = await async_dl_zip_smb_with_retry(
            src,
            temp_dest,
            retries=3,
            fallback_src=fb_src,
            expected_hash=expected_hash,
            hash_algo="sha256",
        )
        stage_end(f"{fname} download")

        if not ok:
            log(f"[addon] download failed, skipping install: {addon_name}")
            return

        # atomic rename
        try:
            xbmcvfs.delete(final_dest)
        except Exception:
            pass
        xbmcvfs.rename(temp_dest, final_dest)

        # install timing
        stage_start(f"{fname} install")
        await async_extractzip_atomic(final_dest, addons_path)
        # log(f"Async pipeline Updated addon: {addon_name}")
        stage_end(f"{fname} install")

        # progress update
        progress["done"] += 1
        percent = 40 + int((progress["done"] / total_updates) * 60)
        pc.update(
            percent,
            f"Updated: {addon_name}[CR]{progress['done']} of {total_updates}",
        )

    async with asyncio.TaskGroup() as tg:
        for fname in files:
            tg.create_task(worker(fname))

    pc.update(100, "Completed")
    await asyncio.sleep(0.1)
    pc.close()

    stage_end("download_install")

    log(f"Async pipeline complete. Updated: {total_updates} for {os_sys}")
    stage_end("async_run_full")
    infodialog('SMB DL files Completed.')


#  SERVICE ENTRY POINT

def run_update_service(
    smb_dir: Optional[str] = None,
    age: Optional[int] = None,
    fallback_dir: Optional[str] = None,
    expected_hashes: Optional[Dict[str, str]] = None,
):
    """
    Sync entry for Kodi service.
    """
    smb_path = getsetting("smb_path")
    if not smb_path:
        infodialog("Cannot find SMB path")
        return
    smb_dir = transpath(f"{smb_path}/addons/alladdons_/")
    age = age if age is not None else int(getsetting("file_age"))
    try:
        asyncio.run(
            async_run_full_update_pipeline(
                smb_dir,
                age=age,
                fallback_dir=fallback_dir,
                expected_hashes=expected_hashes,
            )
        )
    except RuntimeError:
        loop = asyncio.get_event_loop()
        loop.create_task(
            async_run_full_update_pipeline(
                smb_dir,
                age=age,
                fallback_dir=fallback_dir,
                expected_hashes=expected_hashes,
            )
        )
