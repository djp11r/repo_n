# -*- coding: UTF-8 -*-

import concurrent.futures
import os
import re
import shutil
import sys
import time
import zipfile as zfile
from zipfile import ZipFile
from datetime import datetime
from os import listdir, rmdir, walk
from os.path import abspath, basename, normpath, sep
from pathlib import Path
from urllib.parse import quote_plus

from modules.control import addondata, addontitle, color1, color2, condvisibility, current_skin, delete_file, dialog, dp, excludes, execute, existspath, forceclose, get_keyboard, homepath, infodialog, joinpath, kodi_version, log, makedirs, okdialog, opensettings, read_file, selectdialog, setting, sleep, transpath, userdata, userdatapath, yesnodialog
from modules.skinz import swapskins
from modules.toolz import enable_addon
from modules.control import forceclose
from modules.downloader import dl_call


def remove_empty_folders(folder=None):
    if folder is None: folder = homepath
    total = 0
    for root, dirs, files in walk(folder, topdown=True):
        if len(dirs) == 0 and len(files) == 0 and 'backupdir' not in dirs:
            shutil.rmtree(joinpath(root))
            total += 1
            log(f'Empty Folder: {root}')
    log(f'Total folders Removed : {total}')
    infodialog(f'[COLOR {color2}]Total folders Removed : {total}[/COLOR]')


def fix_special():
    homepath.replace(r'\\', '/')
    encodedpath = quote_plus(homepath)
    file_extensions = ('.xml', '.hash', '.properies')
    encodedpath2 = quote_plus(homepath).replace('%3A', '%3a').replace('%5C', '%5c')
    dp.create(addontitle, 'Renaming paths...')
    for root, dirs, files in walk(userdata):
        for file in files:
            if file.endswith(file_extensions):
                # log(f'FIX_SPECIAL file: {root} {file}')
                dp.update(0, f'[COLOR {color2}]Scanning: [COLOR {color1}]{root.replace(homepath, "")}[/COLOR][CR][COLOR {color1}]{file}[/COLOR][CR]Please Wait[/COLOR]')
                a = read_file(joinpath(root, file))
                b = a.replace(homepath, 'special://home/').replace(encodedpath, 'special://home/').replace(encodedpath2, 'special://home/').replace(r'\\', '/')
                with open(joinpath(root, file), 'w', encoding='utf8') as logf:
                    logf.write(str(b))
                if dp.iscanceled():
                    dp.close()
                    infodialog(f'[COLOR {color2}]Convert Path Cancelled[/COLOR]')
                    sys.exit()
    log('[Convert Paths to Special] Complete')
    dp.close()
    infodialog(f'[COLOR {color2}]Convert Path to Special is done.[/COLOR]')


def restorefav():
    FAVdest = joinpath(addondata, 'favs')  # (Favs stuff)
    FAVfile = joinpath(FAVdest, 'favourites.xml')  # (Favs stuff)
    if existspath(FAVfile):
        yes_pressed = yesnodialog('Do you want to Restore your favorites?', 'Click Yes if you want?')
        if yes_pressed == 0: return
        elif yes_pressed == 1:
            dp.create(addontitle, 'Restoring')
            shutil.copy(FAVfile, userdatapath)
            sleep(5)
            dp.close()
            infodialog('Your favorites are Restored!')
    else: infodialog('No Backup found!')


def backupfav():
    FAVOURITES = joinpath(userdatapath, 'favourites.xml')  # (Favs stuff)
    FAVdest = joinpath(addondata, 'favs')  # (Favs stuff)
    FAVfile = joinpath(FAVdest, 'favourites.xml')  # (Favs stuff)
    if not existspath(FAVdest): makedirs(FAVdest)
    if existspath(FAVOURITES):
        yes_pressed = yesnodialog('Do you want to Back-up your favorites?', 'Click Yes if you want?')
        if yes_pressed == 0: return
        elif yes_pressed == 1:
            dp.create(addontitle, 'Backing Up Favourites')
            shutil.copy(FAVOURITES, FAVdest)
            sleep(10)
            dp.close()
            infodialog('Your favorites are Backed up.!')
    else: infodialog('You have no Favourites!')


def delfav():
    FAVdest = joinpath(addondata, 'favs')  # (Favs stuff)
    FAVfile = joinpath(FAVdest, 'favourites.xml')  # (Favs stuff)
    if existspath(FAVfile):
        yes_pressed = yesnodialog('Do you want to Delete your favorites?', 'Click Yes if you want?')
        if yes_pressed == 0: return
        elif yes_pressed == 1:
            shutil.rmtree(joinpath(FAVdest))  #(FAVdest)
            infodialog('COMPLETE[CR]Backed up deleted.')
    else: infodialog('No Backups to remove!')


def freshstart(mode='verbose'):
    if not yesnodialog(addontitle, 'Are you sure you want to perform a Fresh Start?'): infodialog('freshstart cancel'); return
    okdialog(addontitle, 'First gotta switch the skin to the default... Confluence or Estuary...')
    skinswap()
    exclude_files = ['sources.xml', 'passwords.xml', 'mediasources.xml', 'advancedsettings.xml', 'favourites.xml']
    if mode != 'silent': yes_pressed = yesnodialog('Are you absolutely certain you want to wipe this install?', 'All addons EXCLUDING THIS WIZARD will be completely wiped!')
    else: yes_pressed = 1
    if yes_pressed == 0: return
    elif yes_pressed == 1:
        dp.create(addontitle, 'Wiping Install')
        try:
            for root, dirs, files in walk(homepath, topdown=True):
                dirs[:] = [d for d in dirs if d not in excludes]
                files[:] = [f for f in files if f not in exclude_files]
                for name in files:
                    try:
                        delete_file(joinpath(root, name))
                        rmdir(joinpath(root, name))
                    except: pass
                for name in dirs:
                    try:
                        rmdir(joinpath(root, name))
                        rmdir(root)
                    except: pass
        except: pass
    remove_empty_folders()
    remove_empty_folders()
    remove_empty_folders()
    remove_empty_folders()
    remove_empty_folders()
    remove_empty_folders()
    remove_empty_folders()
    # RESTOREFAV()
    enable_addon()
    if mode != 'silent': okdialog(addontitle, 'Wipe Successful, The interface will now be reset...')
    # execute('Mastermode')
    if mode != 'silent': execute('LoadProfile(Master user)')


def skinswap():
    skinswapped = 0
    #switch the skin if the current skin is not skin.estuary
    cur_skin = current_skin()
    log(f'skin: {cur_skin}')
    skin = 'skin.estuary'
    # sys.exit(1)
    if cur_skin not in ['skin.estuary']:
        choice = yesnodialog(addontitle, f'Swap to the default Kodi Skin...[CR]From: {cur_skin}[CR]To: {skin} [CR]Do you want to Proceed?')
        if choice == 1:
            swapskins(skin)
            skinswapped = 1
            time.sleep(1)
    #if a skin swap has happened check if an ok dialog (skin.estuary info screen) is present, press ok if it is present
    # sys.exit()
    if skinswapped == 1 and not condvisibility('Window.isVisible(yesnodialog)'):
        execute('Action(Select)')
        #if there is not a yes no dialog (the screen asking you to switch to skin.estuary) then sleep until it appears
        # while not condvisibility('Window.isVisible(yesnodialog)'): time.sleep(1)
        #while the yes no dialog is present press left and then select to confirm the switch to skin.estuary.
        # while condvisibility('Window.isVisible(yesnodialog)'):
            # execute('Action(Left)')
            # execute('Action(Select)')
            # time.sleep(1)
        # skin = current_skin()
        #check if the skin is not skin.estuary
        # if skin not in ['skin.estuary']:
            # choice = yesnodialog(addontitle, 'ERROR: maybe autoswitch was not succesful[CR]click yes to manually switch to confluence now.[CR]OR you can press no and attempt the auto switch again if you wish.')
            # if choice == 1:
                # execute('ActivateWindow(appearancesettings)')
                # return
            # else: okdialog(addontitle, 'autoswitch skin not complete')  # sys.exit(1)


def extract_worker(zip_path, item, out_path):
    """Worker to extract a single file using its own ZipFile handle."""
    try:
        with ZipFile(zip_path, 'r') as zin:
            zin.extract(item, out_path)
        return True
    except:
        return False

def extractzip(_in, _out, dp=None):
    _in = transpath(_in)
    _out = transpath(_out)
    if not _out.endswith(os.sep): _out += os.sep
    
    if dp is None:
        try:
            with ZipFile(_in) as zf:
                zf.extractall(_out)
            return True
        except Exception as e:
            log(f'Error: {e}')
            return False

    # Progress bar version
    try:
        with ZipFile(_in, 'r') as zin:
            items = zin.infolist()
            n_files = len(items)
            errors = 0

            # Use ThreadPool to take advantage of Python 3.14's better concurrency
            with concurrent.futures.ThreadPoolExecutor() as executor:
                # Map extraction tasks
                futures = [executor.submit(extract_worker, _in, item, _out) for item in items]
                for count, future in enumerate(concurrent.futures.as_completed(futures), 1):
                    if not future.result():
                        errors += 1
                    # 1. THROTTLE UI UPDATES: Only update every 20 files
                    if count % 20 == 0 or count == n_files:
                        progress = int((count / n_files) * 100)
                        # Use a simpler name check to avoid basename overhead
                        name = items[count-1].filename.split('/')[-1]
                        dp.update(progress, f'Extracting... Errors: {errors}[CR]{name}')
                    if dp.iscanceled():
                        executor.shutdown(wait=False, cancel_futures=True)
                        break
        dp.close()
        return True
    except Exception as e:
        log(f'Error: {e}')
        return False


def get_filtered_files(folder, exclude_dirs, exclude_files, exclude_pattern, file_extensions, zip_filename):
    abs_src = Path(folder).resolve()
    files_to_zip = []
    exclude_set = set(exclude_files)

    for dirpath, dirnames, filenames in os.walk(folder):
        # 1. Immediate directory exclusion
        dirnames[:] = [d for d in dirnames if d not in exclude_dirs]
        p_dirpath = Path(dirpath)

        for file in filenames:
            # 2. Fast string and regex checks
            if any(ex in file for ex in exclude_set) or exclude_pattern.search(file):
                continue
            # 3. Context-specific logic (Addon data/Elementum)
            if '_backup' in zip_filename and 'addon_data' in dirpath and file.endswith(file_extensions):
                continue
            if 'plugin.video.elementum' in dirpath and (file.endswith(file_extensions) or file == 'elementum'):
                continue
            # 4. Add valid files to the queue
            full_path = p_dirpath / file
            arcname = full_path.relative_to(abs_src)
            files_to_zip.append((str(full_path), str(arcname)))
    return files_to_zip


def prepare_file_data_safe(file_path, arcname, max_mem_size=52428800):  # 50MB limit
    """Attempt to read and compress file data; handle locked files gracefully."""
    try:
        file_size = os.path.getsize(file_path)

        # If file is too big, tell the main thread to stream it instead
        if file_size > max_mem_size:
            return arcname, "STREAM_FROM_DISK", None

        with open(file_path, 'rb') as f:
            data = f.read()
        return arcname, data, None  # Success
    except (PermissionError, OSError) as e:
        # Log the specific error (e.g., [Errno 13] Permission denied)
        return arcname, None, str(e)


def createzip_multithreaded(folder, zip_filename, exclude_dirs, exclude_files):
    # Prepare filters
    file_extensions = ('.db', '.log', '.sqlite')
    exclude_pattern = re.compile(r'\.(pyo|pyc|log|csv|mp4|mkv|flv|srt|vtt|ttml|exe|dll|so)$', re.I)

    # Get ONLY the files we want
    files_to_zip = get_filtered_files(folder, exclude_dirs, exclude_files, exclude_pattern, file_extensions, zip_filename)
    total_files = len(files_to_zip)
    if os.path.exists(zip_filename):
        os.remove(zip_filename)

    dp.create("Backup", "Filtering & Compressing...")

    with zfile.ZipFile(zip_filename, 'w', zfile.ZIP_DEFLATED, allowZip64=True) as zip_f:
        with concurrent.futures.ThreadPoolExecutor() as executor:
            future_to_file = {executor.submit(prepare_file_data_safe, f, a): (f, a) for f, a in files_to_zip}

            for count, future in enumerate(concurrent.futures.as_completed(future_to_file), 1):
                if dp.iscanceled():
                    executor.shutdown(wait=False, cancel_futures=True)
                    break

                # Get original paths in case we need to stream from disk
                original_full_path, _ = future_to_file[future]
                arcname, result, error = future.result()

                if error:
                    log(f"Skipping {arcname} (Locked): {error}")
                    continue

                if result == "STREAM_FROM_DISK":
                    # SINGLE-THREADED STREAMING: Bypasses RAM, writes direct from disk
                    try:
                        zip_f.write(original_full_path, arcname)
                    except Exception as e:
                        log(f"Error streaming {arcname}: {e}")
                else:
                    # MEMORY WRITE: Fast write of data already compressed in thread
                    zip_f.writestr(arcname, result)

                # UI Update logic here...
                if count % 10 == 0 or count == total_files:
                    progress = int((count / total_files) * 100)
                    dp.update(progress, f"Backing up: {count}/{total_files}\n{arcname}")
    dp.close()


def restore(zipF):
    if yesDialog := yesnodialog(addontitle, 'This will overwrite all your current settings ... Are you sure?'):
        try:
            dp.create('Restoring File In Progress...')
            dp.update(0, '[CR]In Progress...[CR]Extracting Zip Please Wait')
            if 'backup_' in zipF: out_dic = joinpath(homepath, 'addons')
            else: out_dic = joinpath(homepath, 'userdata')
            extractzip(zipF, out_dic, dp)
            okdialog(addontitle, 'Restore Complete')
            log(f'[Restore Build: ] Complete out_dic: {repr(out_dic)}')
            forceclose()
        except Exception as err: log(f'restore err: {repr(err)}')


def buildinstaller(params):
    if not yesnodialog(addontitle, 'Are you sure you want to Install this Build?'): infodialog('Install this Build cancel'); return
    skinswap()
    if yesnodialog(addontitle, 'Do you want to perform a Fresh Start before Installing your Build?'):
        freshstart(params.get('silent'))
    url = params.get('url')
    if destination := dialog.browse(type=0, heading='Select Download Directory', shares='files', useThumbs=True, treatAsFolder=True, enableMultiple=False, ):
        dest = transpath(joinpath(destination, 'custom_build.zip'))
        dp.create('Installing Build')
        dl_call(url, dest, dp)
        time.sleep(2)
        dp.create('Installing Build')
        dp.update(0, '[CR]In Progress...[CR]Extracting Zip Please Wait')
        extractzip(dest, homepath, dp)
        time.sleep(2)
        dp.close()
        okdialog(addontitle, 'Installation Complete...[CR]Your interface will now be reset[CR]Click ok to Start...')
        log('[Installing Build: ] Complete')
        execute('LoadProfile(Master user)')


def backup(mode='full'):
    backupdir = setting('download.path')
    if backupdir == '' or backupdir is None:
        infodialog('Please Setup a Path for Downlads first')
        opensettings(query='1.3')
        return
    if mode == 'full':
        from modules.control import addons_path
        defaultName = f'kodi_{str(kodi_version).replace(".", "_")}_backup'
        backuppath = addons_path
        # log(f'{mode} backuppath {repr(backuppath)}')
        fix_special()
    elif mode == 'userdata':
        defaultName = f'kodi_{str(kodi_version).replace(".", "_")}_userdata'
        backuppath = userdata
    else: return
    if backupdir != '':
        from modules.maintenance import clearcache
        name = get_keyboard(default=defaultName, heading='Name your Backup')
        today = datetime.now().strftime('%Y%m%d%H%M')
        zipDATE = f'_{today}.zip'
        name = re.sub(' ', '_', name) + zipDATE
        backup_zip = transpath(joinpath(backupdir, name))
        try: clearcache(mode='silent')  #maintenance.deleteThumbnails(mode = 'silent')  #maintenance.purgePackages(mode = 'silent')
        except: pass
        exclude_files = (name, 'Textures13.db', '.DS_Store', 'advancedsettings.xml', 'Thumbs.db', '.gitignore', 'gencache.tdb', 'smb.conf', 'kodi_crashlog', 'kodi_stacktrace')
        exclude_dirs = ['bin', 'script.module.inputstreamhelper', 'color_palette2', 'color_palette', '.git', '.idea', 'packages', 'backupdir', 'cache', 'system', 'Thumbnails', 'peripheral_data', 'temp', 'My_Builds', 'keymaps', 'cdm', '.smb', 'inputstream.adaptive', 'inputstream.ffmpegdirect', 'inputstream.rtmp', 'vfs.sftp']
        createzip_multithreaded(backuppath, backup_zip, exclude_dirs, exclude_files)
        okdialog(addontitle, 'Backup complete')
        log(f'[{mode} Backup: ] Complete')
    else: okdialog(addontitle, 'No backup location found. Please setup your Backup location')


def backup_restore():
    typeofbackup = ['BACKUP', 'RESTORE']
    s_type = selectdialog('Select Option', typeofbackup)
    if s_type == 0:
        modes = ['Full Backup', 'UserData Backup']
        select = selectdialog('Select Option', modes)
        if select == 0:
            backup(mode='full')
        elif select == 1:
            backup(mode='userdata')
    elif s_type == 1:
        names = []
        links = []
        zipFolder = transpath(setting('restore.path'))
        if zipFolder == '' or zipFolder is None:
            infodialog('Please Setup a Zip Files Location first')
            opensettings(query='2.0')
            return
        for zipF in listdir(zipFolder):
            if zipF.endswith('.zip'):
                url = transpath(joinpath(zipFolder, zipF))
                names.append(zipF)
                links.append(url)
        if names:
            select = selectdialog('Select zip file to restore', names)
            if select != -1: restore(links[select])
        else: infodialog('No zip file to restore!')
    return