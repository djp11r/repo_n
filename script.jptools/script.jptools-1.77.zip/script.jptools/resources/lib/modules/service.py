# -*- coding: utf-8 -*-
# GNU General Public License v2.0 (see COPYING or https://www.gnu.org/licenses/gpl-2.0.txt)
import os
from time import time
from datetime import date, timedelta
from threading import Thread

from modules.control import log, addonid, addonversion, thumbs, packages, getsetting, setsetting, get_property, clear_property, set_property, get_timestamp, comper_time_with_current, getsetting, get_active_source, makedirs, transpath, xbmc_monitor, xbmc_player


def essentialrun():
    log('EssentialRun Service Starting')
    from modules.toolz import autoupdatetoggle_system
    autoupdatetoggle_system()
    backupdir = transpath(os.path.join('special://home/backupdir', ''))
    if not os.path.exists(backupdir): makedirs(backupdir)
    return log('EssentialRun Service Finished')


def updatecheck():
    get_adon_file_due = getsetting('get_adon_file_due')
    log(f'Auto DL get_adon_file_due: {get_adon_file_due} :: {comper_time_with_current(get_adon_file_due)}')
    if getsetting('get_adon_file') == 'true' and comper_time_with_current(get_adon_file_due):
        from modules.get_smb_service import run_update_service
        run_update_service()
        setsetting('get_adon_file_due', f'{get_timestamp(12, humanread=True)}')
        log('Auto DL addon from enet done')
    else: log('Auto DL addon from enet not doing')
    return log('Auto DL Addons UpdateCheck Service Finished')


class Maintenance:
    def run(self):
        if get_property('jp_firstrun_update') == 'true': return
        log('Maintenance Service Starting')
        end_pause = int(time()) + int(getsetting('update_delay')) or 15
        monitor, player = xbmc_monitor(), xbmc_player()
        wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
        while not monitor.abortRequested():
            while time() < end_pause: wait_for_abort(1)
            while is_playing(): wait_for_abort(1)
            get_active_source()
            autoclean = getsetting('autoclean')
            autonext = getsetting('autonextacleannsave')
            atoday = date.today()
            current_date = atoday.strftime('%Y-%m-%d')
            log(f'\nautonext <= current_date : {autonext.replace("-", "") <= current_date.replace("-", "")}\nautoclean : {repr(autoclean)} current_date : {repr(current_date)} autonext : {repr(autonext)}')

            from modules.maintenance import clean_oldlog
            clean_oldlog()

            if autoclean == 'true' and autonext.replace('-', '') <= current_date.replace('-', ''):
                from modules.maintenance import clearcache, clean_myvideos_db, thumb_cleaner, purgepackages
                log(f'Startup [{addonid}] [v.{addonversion}]')
                filesize = int(getsetting('filesize_alert'))
                filesize_thumb = int(getsetting('filesizethumb_alert'))
                autocleanfeq = getsetting('autocleanfeq')
                autocleanfeq = int(autocleanfeq) if autocleanfeq.isdigit() else 0
                autosetting = getsetting('autosetting')
                autocache = getsetting('clearcache')
                autopackages = getsetting('clearpackages')
                autothumbs = getsetting('clearthumbs')
                next_run = atoday + timedelta(autocleanfeq)

                if autocache == 'true':
                    from modules.control import resetresolverscache
                    clearcache('noverbose')
                    resetresolverscache()
                    clean_myvideos_db()
                    log('[Auto Clean Up] Cache: is Done')
                else: log('[Auto Clean Up] Cache: Off')
                from modules.toolz import folder_size
                if autothumbs == 'true':
                    thumbnails_size, unit2 = folder_size(thumbs)
                    if int(thumbnails_size) > filesize_thumb and unit2 == 'MB':
                        thumb_cleaner()
                        log('[Auto Clean Up] Old Thumbs: is Done')
                else: log('[Auto Clean Up] Old Thumbs: Off')
                if autopackages == 'true':
                    packagesdir_size, unit1 = folder_size(packages)
                    if int(packagesdir_size) > filesize and unit1 == 'MB':
                        purgepackages('noverbose')
                        log('[Auto Clean Up] Packages: is Done')
                if autosetting:
                    from modules.traktit import reset_upd_setting
                    from modules.upd_yt_api import set_api
                    reset_upd_setting()
                    log('[Auto Clean Up] Setting files: is Done')
                    try:
                        set_api('noverbose')
                        log('[Auto Clean Up] Youtube API upd: is Done')
                    except: pass
                else: log('[Auto Clean Up] setting: Off')
                log(f'[Auto Clean Up] Next Clean Up will be on : {next_run}  Today is : {current_date}')
                try:
                    setsetting('autonextacleannsave', f'{next_run}')
                    setsetting('autolastacleannsave', f'{current_date}')
                except: pass
            break
        set_property('jp_firstrun_update', 'true')
        try: del monitor
        except: pass
        try: del player
        except: pass
        return log('Maintenance Service Finished')


class jpmain(xbmc_monitor):
    def __enter__(self):
        # self.threads = (Thread(target=SettingsMonitor().run()), Thread(target=premAccntNotification))
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        try: 
            for i in self.threads: i.join()
        except: pass

    def startUpServices(self):
        # Start the EssentialRun
        try: essentialrun()
        except: pass
        try: Thread(target=Maintenance().run).start()
        except: pass
        try: updatecheck()
        except: pass

    def onNotification(self, sender, method, data):
        if method == 'System.OnSleep': set_property('jp_pause_services', 'true')
        elif method == 'System.OnWake': clear_property('jp_pause_services')
