# -*- coding: utf-8 -*-
import sys
from urllib.parse import parse_qsl

from modules.control import log


def routing():
    # params = dict(parse_qsl(sys.argv[2].replace('?','')))
    params = dict(parse_qsl(sys.argv[2][1:], keep_blank_values=True))
    # log(f'routing params>>>> {params}')
    _get = params.get
    action = _get('action')

    if action is None:
        from modules.default import main_menu
        return main_menu()
    elif action == 'maintenance':
        from modules.default import maintenance
        return maintenance()
    elif action == 'tools':
        from modules.default import tools
        return tools()
    elif action == 'builds':
        from modules.default import builds
        return builds()
    elif action == 'local_menu':
        from modules.default import local_menu
        return local_menu()
    elif action == 'applist_m':
        from modules.default import applist
        return applist()
    elif action == 'log_tools':
        from modules.default import actlogmenu
        return actlogmenu()
    elif action == 'advancedsettings':
        from modules.default import advancedsettingsmenu
        return advancedsettingsmenu()
    elif action == 'kodishortz':
        from modules.default import kodimenu
        return kodimenu()
    elif action == 'kodidbshortz':
        from modules.default import kodidbmenu
        return kodidbmenu()
    elif action == 'extra_menu':
        from modules.default import extra_menu
        return extra_menu()
    elif action == 'settings':
        from modules.control import opensettings
        return opensettings()
    elif action == 'colorchoice':
        from modules.control import colorchoice
        return colorchoice()
    elif action == 'viewtypes':
        from modules.control import getviewtype
        return getviewtype()
    elif action == 'changelog':
        from modules.control import getchangelog
        return getchangelog()
    elif action == 'reset_resolverscache':
        from modules.control import resetresolverscache
        return resetresolverscache()
    elif action == 'force_close':
        from modules.control import forceclose
        return forceclose()
    elif action == 'reloadprofile':
        from modules.control import reloadprofile
        return reloadprofile()
    elif action == 'resolveurl_link_tester':
        from modules.control import resolveurl_link_tester
        return resolveurl_link_tester()
    elif action == 'dl_apk_file':
        from modules.traktit import dl_zip_smb
        return dl_zip_smb(_get('url'))
    elif 'setting_smb' in action:
        from modules.traktit import get_send_files_smb
        if action == 'send_setting_smb': return get_send_files_smb(True)
        elif action == 'get_setting_smb': return get_send_files_smb()
    elif action == 'send_kodi_log_smb':
        from modules.traktit import send_kodi_log_smb
        return send_kodi_log_smb()
    elif action == 'myinstall':
        from modules.traktit import myinstall
        return myinstall(_get('name'), _get('url'))
    elif action == 'ytdl':
        from modules.traktit import ytdl
        # log(f'url:{url}')
        return ytdl()
    elif action == 'get_adon_frm_smb':
        from modules.get_smb_service import run_update_service
        return run_update_service()
    elif action == 'reset_upd_setting':
        from modules.traktit import reset_upd_setting
        return reset_upd_setting()
    elif action == 'errorchecking':
        from modules.traktit import errorchecking
        return errorchecking()
    elif action == 'zipextr':
        from modules.traktit import zipextr
        return zipextr()
    elif action == 'get_userdata':
        from modules.traktit import get_userdata
        return get_userdata()
    elif action == 'clane_adondata':
        from modules.traktit import clane_adondata
        return clane_adondata()
    elif action == 'testtingd':
        from modules.testing_mod import test
        return test()
    elif 'clear_' in action:
        from modules.maintenance import clearcache, purgepackages, thumb_cleaner, clean_myvideos_db
        if action == 'clear_all':
            clearcache()
            purgepackages()
            thumb_cleaner()
            return
        elif action == 'clear_cache': return clearcache()
        elif action == 'clear_packages': return purgepackages()
        elif action == 'clear_thumb': return thumb_cleaner()
        elif action == 'clear_myvideos_db': return clean_myvideos_db()
    elif action == 'clean_bineryfile':
        from modules.utilz import nested_file_delete
        return nested_file_delete()
    elif action == 'checksources':
        from modules.utilz import broken_sources
        return broken_sources()
    elif action == 'checkrepos':
        from modules.utilz import broken_repos
        return broken_repos()
    elif 'clean_log_file' in action:
        from modules.utilz import clean_log_file
        if action == 'clean_log_file': return clean_log_file()
        elif action == 'clean_log_file_all': return clean_log_file(True)
    elif action == 'viewlog':
        from modules.utilz import viewlog
        return viewlog()
    elif action == 'forceupdate':
        from modules.toolz import forceupdatecheck
        return forceupdatecheck()
    elif action == 'enableaddons':
        from modules.toolz import enable_addons
        return enable_addons()
    elif action == 'enableunknownsources':
        from modules.toolz import swapus
        return swapus()
    elif action == 'reloadmyskin':
        from modules.toolz import reloadmyskin
        return reloadmyskin()
    elif action == 'disableautoupdates':
        from modules.toolz import autoupdatetoggle_system
        return autoupdatetoggle_system(True)
    elif action == 'netinfo':
        from modules.toolz import netinfo
        return netinfo()
    elif action == 'appinstall':
        from modules.toolz import appinstaller
        return appinstaller(_get('name'), _get('url'))
    elif action == 'kodiappinstall':
        from modules.toolz import builditems
        return builditems()
    elif action == 'speedtest':
        from modules.speedtest import fast_com
        return fast_com()
    elif action == 'clearemptyfolders':
        from modules.wiz import remove_empty_folders
        return remove_empty_folders()
    elif action == 'skinswap':
        from modules.wiz import skinswap
        return skinswap()
    elif action == 'fix_special':
        from modules.wiz import fix_special
        return fix_special()
    elif action == 'backup_restore':
        from modules.wiz import backup_restore
        return backup_restore()
    elif action == 'fresh_start':
        from modules.wiz import freshstart
        return freshstart()
    elif action == 'install_build':
        from modules.wiz import buildinstaller
        return buildinstaller(params)
    elif action == 'dns_leak_test':
        from modules.dns_leak_test import dns_leak_test
        return dns_leak_test()
    elif action == 'set_api':
        from modules.upd_yt_api import set_api
        return set_api()
