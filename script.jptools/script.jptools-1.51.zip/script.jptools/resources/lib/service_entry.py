# -*- coding: utf-8 -*-
# GNU General Public License v2.0 (see COPYING or https://www.gnu.org/licenses/gpl-2.0.txt)

from modules.service import AutoRun

# Start the AutoRun
try: AutoRun().run()
except: pass
