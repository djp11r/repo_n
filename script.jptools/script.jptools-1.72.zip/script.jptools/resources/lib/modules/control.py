# -*- coding: UTF-8 -*-

import os
import sys
from traceback import print_exc
from datetime import date, datetime, timedelta
from json import dumps, loads
from urllib.parse import urlencode
from xml.dom.minidom import parse as mdParse

import unicodedata
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
from xbmcaddon import Addon
import _strptime

_addon_object = Addon()
getlocalizedstring = _addon_object.getLocalizedString
get_infolabel = xbmc.getInfoLabel

kodi_version = int(get_infolabel('System.BuildVersion')[0:2])


def addon(addon_id='script.jptools'):
    return Addon(id=addon_id)


def external():
    return 'jptools' not in get_infolabel('Container.PluginName')


addoninfo = addon().getAddonInfo

transpath = xbmcvfs.translatePath
deletefe = xbmcvfs.delete
makedirs = xbmcvfs.mkdirs

listdir = xbmcvfs.listdir
existspath = xbmcvfs.exists
joinpath = os.path.join

execute = xbmc.executebuiltin
lang = addon().getLocalizedString
lang2 = xbmc.getLocalizedString
mymonitor = xbmc.Monitor()
xbmc_monitor = xbmc.Monitor
setting = addon().getSetting

additem = xbmcplugin.addDirectoryItem
endofdirectory = xbmcplugin.endOfDirectory

dialog = xbmcgui.Dialog()
dp = xbmcgui.DialogProgress()
homewindow = xbmcgui.Window(10000)
item = xbmcgui.ListItem
content = xbmcplugin.setContent
infolabel = xbmc.getInfoLabel
condvisibility = xbmc.getCondVisibility
sleep = xbmc.sleep

addonid = addoninfo('id')  # ie: 'script.jptools'
addontitle = addoninfo('name')  # ie: 'JP Tools'
addonversion = addoninfo('version')  # old label  VERSION
addonicon = addoninfo('icon')
addonfanart = addoninfo('fanart')
addonpath = addoninfo('path')
addonprofile = transpath(addoninfo('profile'))

homepath = transpath('special://home/')
logpath = transpath('special://logpath/')
userdata = transpath('special://profile/')
thumbs = transpath('special://thumbnails/')
skinPath = transpath('special://skin/')

datapath = transpath(addoninfo('profile'))
settingsfile = joinpath(datapath, 'settings.xml')
viewsfile = joinpath(datapath, 'views.db')
mediapath = transpath(joinpath(addonpath, 'media'))
userdatapath = joinpath(homepath, 'userdata')
databasepath = joinpath(userdatapath, 'Database')
thumbspath = joinpath(userdatapath, 'Thumbnails')
addondata = joinpath(userdatapath, 'addon_data', addonid)
wizlog = joinpath(logpath, 'jptools.log')
backupdir = transpath(joinpath('special://home/backupdir', ''))
iconmaint = joinpath(mediapath, 'maintenance.png')
iconsettings = joinpath(mediapath, 'settings.png')

packages = joinpath(homepath, 'addons', 'packages')
excludes = [addonid, 'backupdir', 'backup', 'script.module.requests', 'script.module.urllib3', 'script.module.chardet', 'script.module.idna', 'script.module.certifi', 'repository.JPB', 'metadata.common.fanart.tv', 'metadata.common.imdb.com', 'metadata.common.theaudiodb.com', 'metadata.common.themoviedb.org', 'metadata.tvshows.themoviedb.org', 'service.xbmc.versioncheck', 'script.module.youtube.dl', 'script.module.soupsieve', 'script.module.kodi-six', 'script.module.addon.signals']
excludes_addons = ['notification', 'packages', '__pycache__', 'temp']

atoday = date.today()
oldthumb = atoday - timedelta(days=int(setting('thumb_age')))
color1 = 'skyblue'  # 'blue'#'red'
color2 = 'white'
color3 = 'springgreen'
sysaddon = sys.argv[0]
customcolor = setting('my_ColorChoice')
if customcolor == '': customcolor = None


def build_url(url_params):
    return f'plugin://script.jptools/?{urlencode(url_params)}'


def getfuture_date(days=1):
    return atoday + timedelta(days)


def getcurrentviewid():
    win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    return str(win.getFocusId())


def getsettingenabled(item):
    is_enabled = setting(item).strip()
    return is_enabled not in ['', 'false']


def getsetting(id):
    return addon().getSetting(id)


def to_unicode(text, encoding='utf-8', errors='strict'):
    """Force text to unicode"""
    return text.decode(encoding, errors) if isinstance(text, bytes) else text


def from_unicode(text, encoding='utf-8', errors='strict'):
    """Force unicode to text"""
    import sys
    if sys.version_info.major == 2 and isinstance(text, unicode):  # noqa: F821; pylint: disable=undefined-variable,useless-suppression
        return text.encode(encoding, errors)
    return text


def get_setting(key, default=None):
    """Get an add-on setting as string"""
    # We use Addon() here to ensure changes in settings are reflected instantly
    try:
        value = to_unicode(addon().getSetting(key))
    except RuntimeError:  # Occurs when the add-on is disabled
        return default
    return default if value == '' and default is not None else value


def get_setting_bool(key, default=None):
    """Get an add-on setting as boolean"""
    try:
        return addon().getSettingBool(key)
    except (AttributeError, TypeError):  # On Krypton or older, or when not a boolean
        value = get_setting(key, default)
        if value not in ('false', 'true'):
            return default
        return bool(value == 'true')
    except RuntimeError:  # Occurs when the add-on is disabled
        return default


def get_setting_int(key, default=None):
    """Get an add-on setting as integer"""
    try:
        return addon().getSettingInt(key)
    except (AttributeError, TypeError):  # On Krypton or older, or when not an integer
        value = get_setting(key, default)
        try:
            return int(value)
        except ValueError:
            return default
    except RuntimeError:  # Occurs when the add-on is disabled
        return default


def setsetting(id, value):
    addon().setSetting(id, value)


def make_settings_dict():  # service runs upon a setting change
    try:
        root = mdParse(settingsfile)
        curSettings = root.getElementsByTagName('setting')
        settings_dict = {}
        for item in curSettings:
            setting_id = item.getAttribute('id')
            try: setting_value = item.firstChild.data
            except: setting_value = None
            if setting_value is None: setting_value = ''
            dict_item = {setting_id: setting_value}
            settings_dict.update(dict_item)
        homewindow.setProperty('infinity_settings', dumps(settings_dict))
        return settings_dict
    except: return None


def opensettings(query=None, id=addoninfo('id')):
    try:
        hide()
        execute(f'Addon.OpenSettings({id})')
        if query is None: return
        c, f = query.split('.')
        execute(f'SetFocus({int(c) - 100:d})')
        execute(f'SetFocus({int(f) - 80:d})')
    except: return


def get_keyboard(default='', heading='', hidden=False):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    try:
        if keyboard.isConfirmed():
            return keyboard.getText()
    except: pass
    return default


def current_skin():
    return xbmc.getSkinDir()


def version():
    num = ''
    try: version = addon('xbmc.addon').getAddonInfo('version')
    except: version = '999'
    for i in version:
        if i.isdigit(): num += i
        else: break
    return int(num)


def make_listitem():
    return xbmcgui.ListItem(offscreen=True)


def normalize(msg):
    try: return ''.join(c for c in unicodedata.normalize('NFKD', msg) if unicodedata.category(c) != 'Mn')
    except: return msg


def log(msg, level=xbmc.LOGDEBUG):
    if setting('addon_debug') == 'true' and level == xbmc.LOGDEBUG: level = xbmc.LOGINFO
    try:
        # ex. "\n" is not a printable character so returns False on those cases
        if not msg.isprintable():  msg = f'{normalize(msg)} (NORMALIZED by log())'
        if isinstance(msg, bytes): msg = f'{msg.decode("utf-8", errors="replace")} (ENCODED by log())'
        if setting('addon_debug') == 'true':
            if setting('debug.location') != '0':
                if not os.path.exists(wizlog): f = open(wizlog, 'w'); f.close()
                # for new line on bottom
                # with open(wizlog, 'a') as f:
                # line = f'[{datetime.now().date()} {str(datetime.now().time())[:8]}] {msg}'
                # f.write(line.rstrip('\r\n')+'\n')
                # for new line on top
                with open(wizlog, 'r+', encoding='utf-8', errors='ignore') as f:
                    line = f'[{datetime.now().date()} {str(datetime.now().time())[:8]}]: {msg}'
                    log_file = f.read()
                    f.seek(0, 0)
                    f.write(line.rstrip('\r\n') + '\n' + log_file)
            else: xbmc.log(f'{addontitle}: {msg}', level)
    except: xbmc.log(f'{addontitle}: {msg} \nError: {print_exc()}', level)


def infodialog(message, heading=addoninfo('name'), icon='', time=None, sound=False):
    time = 3000 if time is None else int(time)
    if icon == '': icon = addonicon
    elif icon == 'INFO': icon = xbmcgui.NOTIFICATION_INFO
    elif icon == 'WARNING': icon = xbmcgui.NOTIFICATION_WARNING
    elif icon == 'ERROR': icon = xbmcgui.NOTIFICATION_ERROR
    dialog.notification(heading, message, icon, time, sound=sound)


def textbox(header, message):
    execute('ActivateWindow(10147)')
    controller = xbmcgui.Window(10147)
    sleep(100)
    controller.getControl(1).setLabel(header)
    controller.getControl(5).setText(str(message))


def okdialog(title, message):
    dialog.ok(title, message)


def yesnodialog(title, message, yes='Yes', no='No'):
    yesf = f'[B][COLOR darkgreen]{yes}[/COLOR][/B]'
    nof = f'[B][COLOR coral]{no}[/COLOR][/B]'
    return dialog.yesno(title, message, yeslabel=yesf, nolabel=nof)


def selectdialog(title, options, key=True):
    # list_choice = dialog.select(string, dialog_list)
    # if list_choice >= 0: return function_list[list_choice]
    # else: return None
    mychoice = dialog.select(str(title), options)
    return mychoice if key else options[mychoice]


def inputdialog(heading=None):
    heading = f'{addontitle}\n{heading}' if heading else addontitle
    return dialog.input(heading=heading, type=xbmcgui.INPUT_ALPHANUM)


def busy():
    return execute('ActivateWindow(busydialognocancel)')


def hide():
    execute('Dialog.Close(busydialog)')
    execute('Dialog.Close(busydialognocancel)')


def closeall():
    return execute('Dialog.Close(all,true)')


def closeokdialog():
    return execute('Dialog.Close(okdialog, true)')


def refresh():
    return execute('Container.Refresh')


def idle():
    return execute('Dialog.Close(busydialognocancel)')


def getchangelog():
    changelogfile = transpath(joinpath(addonpath, 'changelog.txt'))
    text = read_file(changelogfile)
    id = 10147
    execute(f'ActivateWindow({id:d})')
    sleep(500)
    win = xbmcgui.Window(id)
    retry = 50
    while retry > 0:
        try:
            sleep(10)
            retry -= 1
            win.getControl(1).setLabel(f'--[ v{addonversion} ChangeLog ]--')
            win.getControl(5).setText(text)
            return
        except: pass


def platform():  # used in ForceClose()
    if condvisibility('system.platform.android'): return 'android'
    elif condvisibility('system.platform.linux'): return 'linux'
    elif condvisibility('system.platform.windows'): return 'windows'
    elif condvisibility('system.platform.osx'): return 'osx'
    elif condvisibility('system.platform.atv2'): return 'atv2'
    elif condvisibility('system.platform.ios'): return 'ios'


def executejsonrpc(request):
    raw_response = xbmc.executeJSONRPC(request)
    # log(f'JSONRPC-sucucces {raw_response} request: {request}')
    if 'error' in str(raw_response): log(f'JSONRPC-Error {raw_response} request: {request}')
    # else: log(f'JSONRPC-sucucces {raw_response}')
    return loads(raw_response)


def jsonrpc(*args, **kwargs):
    """Perform JSONRPC calls"""
    # We do not accept both args and kwargs
    if args and kwargs:
        log('ERROR: Wrong use of jsonrpc()')
        return None

    # Process a list of actions
    if args:
        for (idx, cmd) in enumerate(args):
            if cmd.get('id') is None: cmd.update(id=idx)
            if cmd.get('jsonrpc') is None: cmd.update(jsonrpc='2.0')
        return executejsonrpc(dumps(args))

    # Process a single action
    if kwargs:
        if kwargs.get('id') is None: kwargs.update(id=0)
        if kwargs.get('jsonrpc') is None: kwargs.update(jsonrpc='2.0')
        return executejsonrpc(dumps(args))


def json_rpc_multi(method, list_params=None):
    """
    Executes multiple JSON-RPC with the same method in Kodi

    :param method: The JSON-RPC method to call
    :type method: string
    :param list_params: Multiple list of parameters of the method call
    :type list_params: a list of dict
    :returns: dict -- Method call result
    """
    request_data = [{'jsonrpc': '2.0', 'method': method, 'id': 1, 'params': params or {}} for params in list_params]
    request = dumps(request_data)
    # log(f'Executing JSON-RPC: {request}')
    return executejsonrpc(request)


def taddonid(add):
    try: return addon(add)
    except: return False


def read_file(path):
    with open(path, 'r', encoding='utf8', errors='ignore') as logf:
        contents = logf.read()
    return contents


def check_backup_dir():
    try:
        if not os.path.exists(backupdir): makedirs(backupdir)
    except Exception as e:
        infodialog(f'[COLOR red]Backup Dir Not Found: Create one First![CR]{e}[/COLOR]')


def getviewtype():
    mychoice = 'Default'
    my_options = ['Default', 'Info Wall', 'Landscape', 'ShowCase', 'ShowCase2', 'Wide List', 'Shift', 'Icons', 'Banner', 'Fanart', 'Wall', '[ [B] Close [/B] ]']
    mychoice = selectdialog(addontitle, my_options, key=False)
    viewType2 = '50'
    if mychoice == 'Default': viewType2 = '50'
    elif mychoice == 'Info Wall': viewType2 = '51'  # Poster
    elif mychoice == 'Landscape': viewType2 = '52'  # Icon Wall
    elif mychoice == 'ShowCase': viewType2 = '53'  # Shift
    elif mychoice == 'ShowCase2': viewType2 = '54'  # Info Wall
    elif mychoice == 'Wide List': viewType2 = '55'
    elif mychoice == 'Shift': viewType2 = '57'
    elif mychoice == 'Icons': viewType2 = '500'  # Wall
    elif mychoice == 'Banner': viewType2 = '501'
    elif mychoice == 'Fanart': viewType2 = '502'
    elif mychoice == 'Wall': viewType2 = '503'
    elif mychoice == '[ [B] Close [/B] ]': return
    setsetting('viewType', mychoice)
    setsetting('viewType2', str(viewType2))
    execute(f'Container.SetViewMode({int(viewType2)})')
    return


def setview(content, viewType):
    if content: content(int(sys.argv[1]), content)
    if getsetting('auto-view') == 'true':
        views = getsetting('viewType2')
        if views == '50' and kodi_version >= 17 and current_skin() == 'skin.estuary': views = '55'
        if views == '500' and kodi_version >= 17 and current_skin() == 'skin.estuary': views = '50'
        log(f'@@@@@@@@@  views {views}')
        return execute(f'Container.SetViewMode({views})')
    else:
        views = getcurrentviewid()
        log(f'@@@@@@@@@ get  views {views}')
        return execute(f'Container.SetViewMode({views})')


def colorchoice():
    chosen_color = color_chooser(no_color=True)
    setsetting('my_ColorChoice', chosen_color)
    execute('Container.Refresh')


def color_chooser(no_color=False):
    color_chart = ['black', 'white', 'whitesmoke', 'gainsboro', 'lightgray', 'silver', 'darkgray', 'gray', 'dimgray', 'snow', 'floralwhite', 'ivory', 'beige', 'cornsilk', 'antiquewhite', 'bisque', 'blanchedalmond', 'burlywood', 'darkgoldenrod', 'ghostwhite', 'azure', 'lightsaltegray', 'lightsteelblue', 'powderblue', 'lightblue', 'skyblue', 'lightskyblue', 'deepskyblue', 'dodgerblue', 'royalblue', 'blue',
                   'mediumblue', 'midnightblue', 'navy', 'darkblue', 'cornflowerblue', 'slateblue', 'slategray', 'yellowgreen', 'springgreen', 'seagreen', 'steelblue', 'teal', 'fuchsia', 'deeppink', 'darkmagenta', 'blueviolet', 'darkviolet', 'darkorchid', 'darkslateblue', 'darkslategray', 'indigo', 'cadetblue', 'darkcyan', 'darkturquoise', 'turquoise', 'cyan', 'paleturquoise', 'lightcyan', 'mintcream', 'honeydew', 'aqua',
                   'aquamarine', 'chartreuse', 'greenyellow', 'palegreen', 'lawngreen', 'lightgreen', 'lime', 'mediumspringgreen', 'mediumturquoise', 'lightseagreen', 'mediumaquamarine', 'mediumseagreen', 'limegreen', 'darkseagreen', 'forestgreen', 'green', 'darkgreen', 'darkolivegreen', 'olive', 'olivedab', 'darkkhaki', 'khaki', 'gold', 'goldenrod', 'lightyellow', 'lightgoldenrodyellow', 'lemonchiffon', 'yellow', 'seashell',
                   'lavenderblush', 'lavender', 'lightcoral', 'indianred', 'darksalmon', 'lightsalmon', 'pink', 'lightpink', 'hotpink', 'magenta', 'plum', 'violet', 'orchid', 'palevioletred', 'mediumvioletred', 'purple', 'maroon', 'mediumorchid', 'mediumpurple', 'mediumslateblue', 'thistle', 'linen', 'mistyrose', 'palegoldenrod', 'oldlace', 'papayawhip', 'moccasin', 'navajowhite', 'peachpuff', 'sandybrown', 'peru', 'chocolate',
                   'orange', 'darkorange', 'tomato', 'orangered', 'red', 'crimson', 'salmon', 'coral', 'firebrick', 'brown', 'darkred', 'tan', 'rosybrown', 'sienna', 'saddlebrown']
    color_display = [f'[COLOR={i}]{i.capitalize()}[/COLOR]' for i in color_chart]
    if no_color:
        color_chart.insert(0, 'No Color')
        color_display.insert(0, 'No Color')
    choice = selectdialog('Select Color scheme...', color_display, False)
    if not choice: return
    return choice.split(']')[0].replace('[COLOR=', '')


def colorstring(text, color=customcolor):
    return f'[COLOR {color}]{text}[/COLOR]'


def forceclose():
    choice = yesnodialog('Force Close Kodi', 'You are about to close Kodi[CR]Would you like to continue?', yes='Yes, Close', no='No, Cancel')
    if choice == 0: return
    myplatform = platform()
    log(f'Platform: {str(myplatform)}')
    # log('Force close failed!  Trying alternate methods.')
    if myplatform == 'osx':  # OSX
        _forceclose('############ try osx force close #################', 'killall -9 XBMC', 'killall -9 Kodi', )
        okdialog('[B]WARNING !!![/B]', 'If you are seeing this message it means the force close[CR]was unsuccessful. Please force close XBMC/Kodi DO NOT exit cleanly via the menu.')
    elif myplatform == 'linux':  # Linux
        _forceclose('############ try linux force close #################', 'killall XBMC', 'killall Kodi', )
        _forceclose('############ try linux force close #################''killall -9 xbmc.bin', 'killall -9 kodi.bin', )
        okdialog('[B]WARNING !!![/B]', 'If you are seeing this message it means the force close[CR]was unsuccessful. Please force close XBMC/Kodi DO NOT exit cleanly via the menu.')
    elif myplatform == 'android':  # Android
        _forceclose('############ try android force close #################', 'adb shell am force-stop org.xbmc.kodi', 'adb shell am force-stop org.kodi', )
        _forceclose('############ try android force close #################', 'adb shell am force-stop org.xbmc.xbmc', 'adb shell am force-stop org.xbmc', )
        _forceclose('############ try android force close #################', 'adb shell kill org.xbmc.kodi', 'adb shell kill org.kodi', )
        _forceclose('############ try android force close #################', 'adb shell kill org.xbmc.xbmc', 'adb shell kill org.xbmc', )
        _forceclose('############ try android force close #################', 'Process.killProcess(android.os.Process.org.xbmc,kodi());', 'Process.killProcess(android.os.Process.org.kodi());', )
        _forceclose('############ try android force close #################', 'Process.killProcess(android.os.Process.org.xbmc.xbmc());', 'Process.killProcess(android.os.Process.org.xbmc());', )
        okdialog(addontitle, 'Press the HOME button on your remote and [CR][B]FORCE STOP[/B] KODI via the Manage Installed Applications menu in settings[CR]on your Amazon home page then re-launch KODI')
    elif myplatform == 'windows':  # Windows
        _forceclose('############ try windows force close #################', '@ECHO off', 'tskill XBMC.exe', )
        _forceclose('############ try windows force close #################', '@ECHO off', 'tskill Kodi.exe', )
        _forceclose('############ try windows force close #################', '@ECHO off', 'TASKKILL /im Kodi.exe /f', )
        _forceclose('############ try windows force close #################', '@ECHO off', 'TASKKILL /im XBMC.exe /f', )
        okdialog('[B]WARNING !!![/B]', 'If you are seeing this message it means the force close[CR]was unsuccessful. Please force close XBMC/Kodi[CR]DO NOT exit cleanly via the menu.', )
    else:  #ATV
        log('############ try atv force close #################')
        try: os.system('killall AppleTV')
        except: pass
        _forceclose('############ try raspbmc force close #################', 'sudo initctl stop kodi', 'sudo initctl stop xbmc', )
        okdialog('[B]WARNING !!![/B]', 'If you are seeing this message it means the force close[CR]was unsuccessful. Please force close XBMC/Kodi DO NOT exit via the menu.[CR]iOS detected. Press and hold both the Sleep/Wake and Home button for at least 10 seconds, until you see the Apple logo.')


def _forceclose(arg1, arg2, arg3):
    log(arg1)
    try: os.system(arg2)
    except: pass
    try: os.system(arg3)
    except: pass


def resolveurl_link_tester(link):
    import resolveurl
    log(f'Playing Link: |{link}|')
    if link.endswith('$$all'): hmf = resolveurl.HostedMediaFile(url=link[:-5], return_all=True)
    else: hmf = resolveurl.HostedMediaFile(url=link)
    if not hmf:
        log(f'Indirect hoster_url not supported by smr: {link}')
        infodialog(f'Link Not Supported: {link}')
        return False
    resolvers = [item.name for item in hmf.get_resolvers(validated=True)]
    log(f'Link Supported: |{link}| Resolvers: {", ".join(resolvers)}')

    try:
        if link.endswith('$$all'):
            allfiles = hmf.resolve()
            names = [x.get('name') for x in allfiles]
            item = xbmcgui.Dialog().select('Select file to play', names, preselect=0)
            if item == -1: return False
            stream_url = allfiles[item].get('link')
            if resolveurl.HostedMediaFile(stream_url): stream_url = resolveurl.resolve(stream_url)
        else: stream_url = hmf.resolve()
        if not stream_url or not isinstance(stream_url, str):
            try: msg = stream_url.msg
            except: raise Exception(link)
    except Exception as e:
        msg = f'error: {str(e)}\nlink: {link}'
        infodialog(f'Resolve Failed: {msg}')
        return False
    log(f'Link Resolved: |{link} >>> {stream_url}|')
    listitem = xbmcgui.ListItem(path=stream_url)
    # listitem.setContentLookup(False)
    listitem.setProperty("Video", "true")
    listitem.setProperty('IsPlayable', 'true')
    if '.mpd' in stream_url:
        listitem.setProperty('inputstream', 'inputstream.adaptive')
        listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        listitem.setMimeType('application/dash+xml')
        listitem.setContentLookup(False)
        if '|' in stream_url:
            stream_url, strhdr = stream_url.split('|')
            listitem.setProperty('inputstream.adaptive.stream_headers', strhdr)
            listitem.setPath(stream_url)
    player = xbmc.Player()
    player.play(stream_url, listitem)
    # xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)


def get_soup(Data):
    from bs4 import BeautifulSoup
    return BeautifulSoup(Data, 'html.parser')

def delete_file(_file):
    if not existspath(_file): return
    try: deletefe(_file)
    except Exception as e:
        log(f'Error: {repr(e)} Deleting file: {_file}')
        from os import unlink, remove
        try:
            unlink(_file)
            remove(_file)
        except Exception as e: log(f'Error: {repr(e)} unlink file: {_file}')


def auto_click_yes():
    x = 0
    sleep(200)
    # if condvisibility('System.HasActiveModalDialog'):
    dialog_id = xbmcgui.getCurrentWindowDialogId()
    log(f'dialog id: {dialog_id}')
    if dialog_id in (10100, 12002, 10138): #( WINDOW_DIALOG_YES_NO, WINDOW_DIALOG_OK, WINDOW_DIALOG_BUSY)
        log(f'2dialog id: {dialog_id}')
        execute('SendClick(11)')
    while not condvisibility('Window.isVisible(yesnodialog)') and x < 100:
        x += 1
        sleep(20)
    # execute('SetFocus(9000,0)')
    if condvisibility('Window.isVisible(yesnodialog)'):
        execute('SendClick(11)')
    else:
        # log(f'dialog id: {xbmcgui.getCurrentWindowDialogId()}')
        execute('SendClick(11)')
    return


def get_active_source():
    xml_file = transpath('special://profile/mediasources.xml')
    if not existspath(xml_file):
        log(f'not exist xml_file: {xml_file}')
        setsetting('smb_path', 'smb://')
        return
    root = mdParse(xml_file) #minidom instead of element tree
    sources = root.getElementsByTagName("location")
    # log(f'sources: {sources}')
    for item in sources:
        source_dir = item.firstChild.data
        path_acces = xbmcvfs.listdir(source_dir)
        log(f'source_dir: {source_dir}\n item: {path_acces}')
        if 'Data' in str(path_acces): break
    setsetting('smb_path', source_dir)
    return source_dir