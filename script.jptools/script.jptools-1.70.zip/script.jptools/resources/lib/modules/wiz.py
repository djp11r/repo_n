# -*- coding: UTF-8 -*-

import re
import shutil
import sys
import time
import zipfile as zfile
from datetime import datetime
from os import listdir, rmdir, walk
from os.path import abspath, basename, normpath, sep
from urllib.parse import quote_plus
from urllib.request import FancyURLopener

from modules.control import addondata, addontitle, current_skin, color1, color2, condvisibility, delete_file, dialog, dp, excludes, \
    execute, existspath, get_keyboard, homepath, infodialog, joinpath, kodi_version, log, makedirs, opensettings, \
    read_file, selectdialog, setting, sleep, transpath, userdata, userdatapath, yesnodialog, okdialog

from modules.skinz import swapskins
from modules.toolz import enable_addon
from modules.control import forceclose


def remove_empty_folders(folder=None):
    if folder is None: folder = homepath
    total = 0
    for root, dirs, files in walk(folder, topdown=True):
        if len(dirs) == 0 and len(files) == 0 and 'backupdir' not in dirs:
            shutil.rmtree(joinpath(root))
            total += 1
            log(f'Empty Folder: {root}')
    log(f'Total folders Removed : {total}')
    infodialog(f'[COLOR {color2}]Total folders Removed : {total}[/COLOR]')


def fix_special():
    homepath.replace(r'\\', '/')
    encodedpath = quote_plus(homepath)
    file_extensions = ('.xml', '.hash', '.properies')
    encodedpath2 = quote_plus(homepath).replace('%3A', '%3a').replace('%5C', '%5c')
    dp.create(addontitle, 'Renaming paths...')
    for root, dirs, files in walk(userdata):
        for file in files:
            if file.endswith(file_extensions):
                # log(f'FIX_SPECIAL file: {root} {file}')
                dp.update(0, f'[COLOR {color2}]Scanning: [COLOR {color1}]{root.replace(homepath, "")}[/COLOR][CR][COLOR {color1}]{file}[/COLOR][CR]Please Wait[/COLOR]')
                a = read_file(joinpath(root, file))
                b = a.replace(homepath, 'special://home/').replace(encodedpath, 'special://home/').replace(encodedpath2, 'special://home/').replace(r'\\', '/')
                with open(joinpath(root, file), 'w', encoding='utf8') as logf:
                    logf.write(str(b))
                if dp.iscanceled():
                    dp.close()
                    infodialog(f'[COLOR {color2}]Convert Path Cancelled[/COLOR]')
                    sys.exit()
    log('[Convert Paths to Special] Complete')
    dp.close()
    infodialog(f'[COLOR {color2}]Convert Path to Special is done.[/COLOR]')


def restorefav():
    FAVdest = joinpath(addondata, 'favs')  # (Favs stuff)
    FAVfile = joinpath(FAVdest, 'favourites.xml')  # (Favs stuff)
    if existspath(FAVfile):
        yes_pressed = yesnodialog('Do you want to Restore your favorites?', 'Click Yes if you want?')
        if yes_pressed == 0: return
        elif yes_pressed == 1:
            dp.create(addontitle, 'Restoring')
            shutil.copy(FAVfile, userdatapath)
            sleep(5)
            dp.close()
            infodialog('Your favorites are Restored!')
    else: infodialog('No Backup found!')


def backupfav():
    FAVOURITES = joinpath(userdatapath, 'favourites.xml')  # (Favs stuff)
    FAVdest = joinpath(addondata, 'favs')  # (Favs stuff)
    FAVfile = joinpath(FAVdest, 'favourites.xml')  # (Favs stuff)
    if not existspath(FAVdest): makedirs(FAVdest)
    if existspath(FAVOURITES):
        yes_pressed = yesnodialog('Do you want to Back-up your favorites?', 'Click Yes if you want?')
        if yes_pressed == 0: return
        elif yes_pressed == 1:
            dp.create(addontitle, 'Backing Up Favourites')
            shutil.copy(FAVOURITES, FAVdest)
            sleep(10)
            dp.close()
            infodialog('Your favorites are Backed up.!')
    else: infodialog('You have no Favourites!')


def delfav():
    FAVdest = joinpath(addondata, 'favs')  # (Favs stuff)
    FAVfile = joinpath(FAVdest, 'favourites.xml')  # (Favs stuff)
    if existspath(FAVfile):
        yes_pressed = yesnodialog('Do you want to Delete your favorites?', 'Click Yes if you want?')
        if yes_pressed == 0: return
        elif yes_pressed == 1:
            shutil.rmtree(joinpath(FAVdest))  #(FAVdest)
            infodialog('COMPLETE[CR]Backed up deleted.')
    else: infodialog('No Backups to remove!')


def freshstart(mode='verbose'):
    exclude_files = ['sources.xml', 'passwords.xml', 'mediasources.xml', 'advancedsettings.xml', 'favourites.xml']
    if mode != 'silent': yes_pressed = yesnodialog('Are you absolutely certain you want to wipe this install?', 'All addons EXCLUDING THIS WIZARD will be completely wiped!')
    else: yes_pressed = 1
    if yes_pressed == 0: return
    elif yes_pressed == 1:
        dp.create(addontitle, 'Wiping Install')
        try:
            for root, dirs, files in walk(homepath, topdown=True):
                dirs[:] = [d for d in dirs if d not in excludes]
                files[:] = [f for f in files if f not in exclude_files]
                for name in files:
                    try:
                        delete_file(joinpath(root, name))
                        rmdir(joinpath(root, name))
                    except: pass
                for name in dirs:
                    try:
                        rmdir(joinpath(root, name))
                        rmdir(root)
                    except: pass
        except: pass
    remove_empty_folders()
    remove_empty_folders()
    remove_empty_folders()
    remove_empty_folders()
    remove_empty_folders()
    remove_empty_folders()
    remove_empty_folders()
    # RESTOREFAV()
    enable_addon()
    if mode != 'silent': okdialog(addontitle, 'Wipe Successful, The interface will now be reset...')
    # execute('Mastermode')
    if mode != 'silent': execute('LoadProfile(Master user)')


def skinswap():
    skinswapped = 0
    #SWITCH THE SKIN IF THE CURRENT SKIN IS NOT CONFLUENCE
    cur_skin = current_skin()
    log(f'skin: {cur_skin}')
    # sys.exit(1)
    if cur_skin not in ['skin.estuary']:
        choice = yesnodialog(addontitle, 'Swap to the default Kodi Skin...[CR]Do you want to Proceed?')
        if choice == 1:
            skin = 'skin.estuary'
            swapskins(skin)
            skinswapped = 1
            time.sleep(1)
    #IF A SKIN SWAP HAS HAPPENED CHECK IF AN OK DIALOG (CONFLUENCE INFO SCREEN) IS PRESENT, PRESS OK IF IT IS PRESENT
    # sys.exit()
    if skinswapped == 1 and not condvisibility('Window.isVisible(yesnodialog)'):
        execute('Action(Select)')
    #IF THERE IS NOT A YES NO DIALOG (THE SCREEN ASKING YOU TO SWITCH TO CONFLUENCE) THEN SLEEP UNTIL IT APPEARS
    if skinswapped == 1:
        while not condvisibility('Window.isVisible(yesnodialog)'): time.sleep(1)
    #WHILE THE YES NO DIALOG IS PRESENT PRESS LEFT AND THEN SELECT TO CONFIRM THE SWITCH TO CONFLUENCE.
    if skinswapped == 1:
        while condvisibility('Window.isVisible(yesnodialog)'):
            execute('Action(Left)')
            execute('Action(Select)')
            time.sleep(1)
    if skinswapped == 1:
        skin = skin
        #CHECK IF THE SKIN IS NOT CONFLUENCE
        if skin not in ['skin.estuary']:
            choice = yesnodialog(addontitle, 'ERROR: maybe autoswitch was not succesful[CR]click yes to manually switch to confluence now.[CR]OR you can press no and attempt the auto switch again if you wish.')
            if choice == 1:
                execute('ActivateWindow(appearancesettings)')
                return
            else: okdialog(addontitle, 'autoswitch skin not complete')  # sys.exit(1)


def _pbhook(numblocks, blocksize, filesize, dp, start_time):
    try:
        percent = min(numblocks * blocksize * 100 / filesize, 100)
        currently_downloaded = float(numblocks) * blocksize / (1024 * 1024)
        kbps_speed = numblocks * blocksize / (time.time() - start_time)
        if kbps_speed > 0 and percent != 100: eta = (filesize - numblocks * blocksize) / kbps_speed
        else: eta = 0
        kbps_speed /= 1024
        total = float(filesize) / (1024 * 1024)
        mbs = f'{currently_downloaded:.02f} MB of {total:.02f} MB'
        e = f'Speed: {kbps_speed:.02f} Kb/s '
        e += 'ETA: {:02d}'.format(divmod(eta, 60))
        string = 'Downloading... Please Wait...'
        dp.update(percent, f'{mbs}[CR]{e}[CR]{string}')
    except:
        dp.update(100)
        dp.close()
        return
    if dp.iscanceled():
        dp.close()
        raise Exception('Canceled')


class customdownload(FancyURLopener):
    version = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11'


def downloader(url, dest, dp=None):
    if not dp: dp.create(addontitle, '')
    dp.update(0)
    start_time = time.time()
    try: customdownload().retrieve(url, dest, lambda nb, bs, fs,: _pbhook(nb, bs, fs, dp, start_time))
    except Exception as e:
        log(f'downloader Error url: {url} e: {e}')
        dp.close()


def extractnoprogress(_in, _out):
    try:
        if not _out.endswith(sep):
            _out += sep
        _in = transpath(_in)
        _out = transpath(_out)
        # log(f'_in:: : {_in}\n_out:: : {_out}')
        with zfile.ZipFile(_in) as zf:
            zf.extractall(_out)
    except Exception as e: log(f'Error:: : {e}')
    return True


def extractwithprogress(_in, _out, dp):
    zin = zfile.ZipFile(_in, 'r')
    nFiles = float(len(zin.infolist()))
    errors = 0
    for count, item in enumerate(zin.infolist(), start=1):
        update = count / nFiles * 100
        try: name = basename(item.filename)
        except: name = item.filename
        dp.update(int(update), f'Extracting... Errors:  {errors}[CR]{name}', )
        zin.extract(item, _out)
    return True


def extractzip(_in, _out, dp=None):
    if dp is not None: return extractwithprogress(_in, _out, dp)
    return extractnoprogress(_in, _out)


def createzip(folder, zip_filename, message_header, message1, exclude_dirs, exclude_files):
    abs_src = abspath(folder)
    for_progress = []
    ITEM = []
    dp.create(message_header, message1)
    delete_file(zip_filename)
    for base, dirs, files in walk(folder):
        ITEM.extend(iter(files))
    N_ITEM = len(ITEM)
    count = 0
    line = 'Backing Up[CR]FILES: %s/%s [CR]File: %s[CR]Folder: %s[CR]Please Wait...'
    zip_file = zfile.ZipFile(zip_filename, 'w', zfile.ZIP_DEFLATED, allowZip64=True)
    # log(f'folder: {folder}')
    # List of file extensions to check
    file_extensions = ('.db', '.log', '.sqlite')
    # Use a compiled regular expression for efficiency
    exclude_pattern = re.compile(r'\.(pyo|pyc|log|csv|mp4|mkv|flv|srt|vtt|ttml|exe|dll|so)', re.I)
    for dirpath, dirnames, filenames in walk(folder):
        try:
            dirnames[:] = [d for d in dirnames if d not in exclude_dirs]
            filenames[:] = [f for f in filenames if any(x not in str(f) for x in exclude_files) and not exclude_pattern.search(str(f))]
            for file in filenames:
                if '_backup' in zip_filename and 'addon_data' in dirpath and file.endswith(file_extensions): continue
                if 'plugin.video.elementum' in dirpath and file.endswith(file_extensions) or file == 'elementum': continue
                count += 1
                try:
                    dir_name = dirpath.replace(folder, '').replace('addons', '').replace('userdata', '').replace('addon_data', '').strip()
                    # dir_name = dir_name.split('/')[0]
                    # dir_name = f'{dirname[0]} _ {dirname[1]}'
                except: dir_name = 'None'
                # log(f'dir_name: {dir_name}')
                for_progress.append(file)
                progress = len(for_progress) / float(N_ITEM) * 100
                dp.update(int(progress), line % (str(count), str(N_ITEM), str(file), dir_name))
                file = joinpath(dirpath, file)
                file = normpath(file)
                arcname = file[len(abs_src) + 1:]
                zip_file.write(file, arcname)
                if dp.iscanceled():
                    dp.close()
                    raise Exception('Canceled')
        except Exception as e: log(f'Error:: : {e}')
    zip_file.close()
    if dp.iscanceled():
        dp.close()


def restorefolder():
    names = []
    links = []
    zipFolder = transpath(setting('restore.path'))
    if zipFolder == '' or zipFolder is None:
        infodialog('Please Setup a Zip Files Location first')
        opensettings(query='2.0')
        return
    for zipF in listdir(zipFolder):
        if zipF.endswith('.zip'):
            url = transpath(joinpath(zipFolder, zipF))
            names.append(zipF)
            links.append(url)
    select = selectdialog('Select zip file to restore', names)
    if select != -1: restore(links[select])


def restore(zipF):
    if yesDialog := yesnodialog(addontitle, 'This will overwrite all your current settings ... Are you sure?'):
        try:
            dp.create('Restoring File In Progress...')
            dp.update(0, '[CR]In Progress...[CR]Extracting Zip Please Wait')
            extractzip(zipF, homepath, dp)
            okdialog(addontitle, 'Restore Complete')
            log('[Restore Build: ] Complete')
            forceclose()  #execute('ShutDown') #Testing with ForceClose()
        except: pass


def buildinstaller(url):
    if destination := dialog.browse(type=0, heading='Select Download Directory', shares='files', useThumbs=True, treatAsFolder=True, enableMultiple=False, ):
        dest = transpath(joinpath(destination, 'custom_build.zip'))
        downloader(url, dest)
        time.sleep(2)
        dp.create('Installing Build')
        dp.update(0, '[CR]In Progress...[CR]Extracting Zip Please Wait')
        extractzip(dest, homepath, dp)
        time.sleep(2)
        dp.close()
        okdialog(addontitle, 'Installation Complete...[CR]Your interface will now be reset[CR]Click ok to Start...')
        log('[Installing Build: ] Complete')
        execute('LoadProfile(Master user)')


def backup(mode='full'):
    backupdir = setting('download.path')
    if backupdir == '' or backupdir is None:
        infodialog('Please Setup a Path for Downlads first')
        opensettings(query='1.3')
        return
    if mode == 'full':
        defaultName = f'kodi_{str(kodi_version).replace(".", "_")}_backup'
        backuppath = homepath
        fix_special()
    elif mode == 'userdata':
        defaultName = f'kodi_{str(kodi_version).replace(".", "_")}_userdata'
        backuppath = userdata
    else: return
    if existspath(backuppath):
        if backupdir != '':
            from modules.maintenance import clearcache
            name = get_keyboard(default=defaultName, heading='Name your Backup')
            today = datetime.now().strftime('%Y%m%d%H%M')
            zipDATE = f'_{today}.zip'
            name = re.sub(' ', '_', name) + zipDATE
            backup_zip = transpath(joinpath(backupdir, name))
            try: clearcache(mode='silent')  #maintenance.deleteThumbnails(mode = 'silent')  #maintenance.purgePackages(mode = 'silent')
            except: pass
            exclude_files = (name, 'Textures13.db', '.DS_Store', 'advancedsettings.xml', 'Thumbs.db', '.gitignore', 'gencache.tdb', 'smb.conf', 'kodi_crashlog', 'kodi_stacktrace')
            exclude_dirs = ['bin', 'script.module.inputstreamhelper', 'color_palette2', 'color_palette', '.git', '.idea', 'packages', 'backupdir', 'cache', 'system', 'Thumbnails', 'peripheral_data', 'temp', 'My_Builds', 'keymaps', 'cdm', '.smb', 'inputstream.adaptive', 'inputstream.ffmpegdirect', 'inputstream.rtmp', 'vfs.sftp']
            createzip(backuppath, backup_zip, 'Creating Backup', 'Backing up files', exclude_dirs, exclude_files)
            okdialog(addontitle, 'Backup complete')
            log(f'[{mode} Backup: ] Complete')
        else: okdialog(addontitle, 'No backup location found. Please setup your Backup location')