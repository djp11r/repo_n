# -*- coding: utf-8 -*-
# GNU General Public License v2.0 (see COPYING or https://www.gnu.org/licenses/gpl-2.0.txt)
from modules.control import xbmc_monitor


class main(xbmc_monitor):
    def __init__(self):
        xbmc_monitor.__init__(self)
        super().__init__()
        self.startServices()

    def startServices(self):
        # Start the AutoRun
        from modules.service import AutoRun
        AutoRun().run()

main().waitForAbort()