# -*- coding: utf-8 -*-

import shutil
import sqlite3 as database
from os import listdir, remove, walk
from os.path import getsize
from traceback import print_exc

from modules.control import condvisibility, databasepath, deletefile, existspath, getsettingenabled, homepath, \
    infodialog, joinpath, listdir, log, logpath, oldthumb, transpath
from modules.traktit import get_file_older_then_hrs
from modules.utilz import file_path_remove


def clean_oldlog(clean=False):
    dirs, files = listdir(logpath)
    # log(f'logpath: {logpath} files: {files}')
    try:
        for item in files:
            # log(f'item to clean: {item}')
            if clean and item.endswith('.log') and item not in ['kodi.log', 'kodi.old.log']:
                l_file = joinpath(logpath, item)
                # log(f'item to clean: {l_file}')
                with open(l_file, 'w') as logFile:
                    logFile.write('')
            if 'kodi_crashlog' in item or 'kodi_stacktrace' in item:
                item_path = joinpath(logpath, item)
                log(f'file delete path: {item_path}')
                try: deletefile(item_path)
                except: remove(item_path)
        if clean: infodialog('Clean Old log files Completed.')
    except Exception as e: log(f'clean_oldlog Error: {e}')


class cacheentry(object):
    def __init__(self, namei, pathi):
        self.name = namei
        self.path = pathi

    def setupCacheEntries(self):
        entries = 5  #make sure this refelcts the amount of entries you have
        dialogName = ['WTF', '4oD', 'BBC iPlayer', 'Simple Downloader', 'ITV']
        pathName = ['special://profile/addon_data/plugin.video.whatthefurk/cache', 'special://profile/addon_data/plugin.video.4od/cache', 'special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache', 'special://profile/addon_data/script.module.simple.downloader', 'special://profile/addon_data/plugin.video.itv/Images']
        return [cacheentry(dialogName[x], pathName[x]) for x in range(entries)]


def clearcache(mode='verbose'):
    tempPaths = [transpath('special://temp'), transpath(joinpath(homepath, 'addons', 'temp'))]
    cachePath = joinpath(homepath, 'cache')
    file_count = 0
    if existspath(cachePath) is True and getsettingenabled('tune.cachePath') is True:
        total_files, total_folds = cleanfolder(cachePath)
        file_count = total_files + total_folds
        if mode == 'verbose': infodialog(f'Clean cache Completed [ {file_count:d} ]')

    for path in tempPaths:
        if (not path.endswith('/')) and (not path.endswith('\\')):
            dirSep = '\\' if '\\' in path else '/'
            path = f'{path}{dirSep}'
        if existspath(path):
            total_files, total_folds = cleanfolder(path)
            file_count = total_files + total_folds
    if mode == 'verbose': infodialog(f'Clean temp Completed [ {file_count:d} ]')

    if condvisibility('system.platform.ATV2'):
        atv2_cache_a = joinpath('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        total_files, total_folds = cleanfolder(atv2_cache_a)
        file_count = total_files + total_folds

        atv2_cache_b = joinpath('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        total_files, total_folds = cleanfolder(atv2_cache_b)
        file_count += total_files + total_folds

        if mode == 'verbose': infodialog(f'Clean Caches Completed [ {file_count:d} ]')

    cacheEntries = []
    file_count = 0
    for entry in cacheEntries:
        clear_cache_path = transpath(entry.path)
        if existspath(clear_cache_path) == True and getsettingenabled('tune.cacheEntries') == True:
            total_files, total_folds = cleanfolder(clear_cache_path)
            file_count += total_files + total_folds
            if mode == 'verbose': infodialog(f'Clean Caches Completed [ {file_count:d} ]')
    home_clean = listdir(homepath)
    for item in home_clean:
        if 'kodi_crashlog' in item or 'kodi_stacktrace' in item:
            item_path = joinpath(homepath, item)
            log(f'item_path: {item_path}')
            try: deletefile(item_path)
            except: remove(item_path)
    if mode == 'verbose': infodialog('Clean Cache Completed.')


def clean_myvideos_db(modify=False):
    def find(pattern, path):
        result = []
        for root, dirs, files in walk(path):
            for name in files:
                if 'MyVideos' in name and name.endswith('.db'):
                    result.append(joinpath(root, name))
        return result

    def clean_table(table, total_entry):
        data_row_delete = None
        if 'files' == table:
            data_row_select = f'SELECT strFilename FROM {table} WHERE strFilename NOT LIKE "{keep_items}" OR strFilename IS NULL OR strFilename = "" OR playCount IS NULL'
            data_row_delete = f'DELETE FROM {table} WHERE strFilename NOT LIKE "{keep_items}%" OR strFilename IS NULL OR strFilename = "" OR playCount IS NULL'
        elif 'path' == table:
            # data_row_delete = f'DELETE FROM {table} WHERE idParentPath IS NULL OR idParentPath = '
            data_row_select = f'SELECT strPath FROM {table} WHERE strPath NOT LIKE "{keep_items}"'
            data_row_delete = f'DELETE FROM {table} WHERE strPath NOT LIKE "{keep_items}"'
        if not data_row_delete: return total_entry
        log(f'data_row_delete: {data_row_delete}')
        try:
            cursor.execute(data_row_select)
            data = cursor.fetchall()
            j = len(data)
            if j > 0:
                total_entry += j
                log(f'from Table {table} Total rows : {j} total_entry: {total_entry}')
                data_row_limit = f'DELETE FROM {table} WHERE ROWID IN (SELECT ROWID FROM {table} ORDER BY ROWID DESC LIMIT -1 OFFSET 200)'
                cursor.execute(data_row_delete)
                cursor.execute(data_row_limit)
                dbcon.commit()
        except: log(f'Error clean_table: {print_exc()}')
        return total_entry

    try:
        db_file = find('MyVideos*.db', databasepath)[0]
        try:
            dbcon = database.connect(db_file)
            cursor = dbcon.cursor()
            cursor.execute('''PRAGMA synchronous = OFF''')
            cursor.execute('''PRAGMA journal_mode = OFF''')
        except:
            log(f'Error clean_myvideos_db: {print_exc()}')
            return False
        query = 'SELECT name FROM sqlite_master WHERE type="table"'
        # query = 'SELECT name from sqlite_master where type= 'table' AND name NOT LIKE 'sqlite_%''
        find_deletes = ('%ENet%', 'https:%', 'http:%')
        keep_items = '%infinit%'
        cursor.execute(query)
        tables_in_db = cursor.fetchall()
        total_entry = 0
        for i in tables_in_db:
            if i[0] in ('files', 'path'):
                total_entry = clean_table(i[0], total_entry)
        dbcon.commit()
        dbcon.execute('VACUUM')
    except: log(f'Error clean_myvideos_db: {print_exc()}')
    finally: dbcon.close()
    return infodialog(f'total entry removed: {total_entry}')


def thumb_cleaner():
    thumbs_folder = transpath('special://thumbnails')
    # log(f'thumbs_folder: {repr(thumbs_folder)}')
    dbfile = transpath(joinpath('special://database', 'Textures13.db'))
    minimum_uses = 30
    size = images = 0
    if not existspath(dbfile):
        return infodialog('there is no Database file: Failed')
    dbcon = database.connect(dbfile, isolation_level=None)
    dbcur = dbcon.cursor()
    dbcur.execute('''PRAGMA synchronous = OFF''')
    dbcur.execute('''PRAGMA journal_mode = OFF''')
    dbcur.execute('SELECT cachedurl FROM texture', )
    lasthashcheck_result = dbcur.fetchall()
    not_to_delete = []
    for item in lasthashcheck_result:
        # log(f'item: {repr(item)}')
        try:
            item = item[0].split('/')[1]
            not_to_delete.append(item)
        except: pass

    # # log(f'FROM texture DELETE lasthashcheck IS NULL Total: {len(lasthashcheck_result)} results: {repr(lasthashcheck_result)}')
    # dbcur.execute('DELETE FROM texture WHERE lasthashcheck IS NULL OR lasthashcheck = ''', )
    # lasthashcheck_result = dbcur.fetchall()
    # log(f'FROM texture DELETE lasthashcheck IS NULL Total: {len(lasthashcheck_result)} results: {repr(lasthashcheck_result)}')
    dbcur.execute('SELECT idtexture FROM sizes WHERE usecount < ? AND lastusetime < ?', (minimum_uses, str(oldthumb)))
    result = dbcur.fetchall()
    log(f'Old Thumbnails than {oldthumb}, or have not been accessed at least {minimum_uses} times Total: {len(result)}')
    if len(result) <= 0: infodialog('No Thumbnails to Clear')
    else:
        item_list = []
        for item in result:
            _id = item[0]
            dbcur.execute('SELECT cachedurl FROM texture WHERE id = ?', (_id,))
            url = dbcur.fetchall()[0][0]
            path = joinpath(thumbs_folder, url)
            try:
                item_list.append((_id,))
                imagesize = getsize(path)
                deletefile(path)
                size += imagesize
                images += 1
            except: pass
        dbcur.executemany('DELETE FROM sizes WHERE idtexture = ?', item_list)
        dbcur.executemany('DELETE FROM texture WHERE id=?', item_list)
    dbcur.execute('VACUUM')
    dbcon.commit()
    dbcon.close()
    # # if existspath(thumbs_folder):
    # log(f'total: {len(not_to_delete)} : {repr(not_to_delete)}')
    if len(lasthashcheck_result) > 0:
        for root, dirs, files in walk(thumbs_folder):
            file_count = len(files)
            if file_count > 0:
                # log(f'len(files): {len(files)} {repr(files)}')
                for f in files:
                    if f not in not_to_delete:
                        # log(f'f: {f}')
                        remove_file = joinpath(root, f)
                        file_path_remove(remove_file)
    removed = f'{size / 1024000.0:.0f}'
    msg = f'[COLOR red]Clear Thumbs: {images} Files / {removed} MB[/COLOR]!'
    log(msg)
    clean_myvideos_db()
    return infodialog(msg)


def purgepackages(mode='verbose'):
    purgePath = transpath('special://home/addons/packages')
    total_files, total_folds = cleanfolder(purgePath)
    file_count = total_files + total_folds
    if mode == 'verbose': infodialog(f'Clean Packages Completed [ {file_count:d} ]')


def cleanfolder(folder):
    file_tokeep = ('commoncache.db', 'kodi.log', 'kodi.old.log', 'xbmc.log', 'xbmc.old.log', 'spmc.log', 'spmc.old.log')
    # log(folder)
    total_files = 0
    total_folds = 0
    try:
        for root, dirs, files in walk(folder):
            if len(files) >= 0:
                for f in files:
                    if f in file_tokeep: continue
                    remove_file = joinpath(root, f)
                    file_path_remove(remove_file)
                    total_files += 1
            if len(dirs) >= 0:
                for d in dirs:
                    try:
                        shutil.rmtree(joinpath(root, d))
                        total_folds += 1
                    except: log(f'Error Deleting Folder: {d}')
    except Exception as e: log(f'cleanfolder Error: {e}')
    return total_files, total_folds