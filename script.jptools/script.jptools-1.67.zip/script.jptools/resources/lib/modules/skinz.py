# -*- coding: UTF-8 -*-
import glob
import json
import re

from modules.control import addontitle, color1, color2, condvisibility, deletefile, yesnodialog, selectdialog, execute, existspath, homepath, infodialog, joinpath, jsonrpc, log, setsetting, setting, sleep, userdata


def getold(old):
    try:
        old = f'"{old}"'
        query = f'{{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{{"setting":{old}}}, "id":1}}'
        response = jsonrpc(query)
        response = json.loads(response)
        if response.has_key('result') and response['result'].has_key('value'):
            return response['result']['value']
    except: pass
    return None


def setnew(new):
    try:
        new = f'"{new}"'
        query = {"jsonrpc": "2.0", "method": "Settings.SetSettingValue", "id": 1, "params": {"setting": "lookandfeel.skin", "value": new}}
        response = jsonrpc(query)
    except: pass
    return None


def swapskins(skin):
    setnew(skin)


def lookandfeeldata(do='save'):
    scan = ['lookandfeel.enablerssfeeds', 'lookandfeel.font', 'lookandfeel.rssedit', 'lookandfeel.skincolors', 'lookandfeel.skintheme', 'lookandfeel.skinzoom', 'lookandfeel.soundskin', 'lookandfeel.startupwindow', 'lookandfeel.stereostrength']
    if do == 'save':
        for item in scan:
            query = {"jsonrpc": "2.0", "method": "Settings.GetSettingValue", "params": {{"setting": f'"{item}"'}}, "id": 1}
            response = jsonrpc(query)
            if 'error' not in response:
                match = re.compile('{"value":(.+?)}').findall(str(response))
                setsetting(item.replace('lookandfeel', 'default'), match[0])
                log(f'{item} saved to {match[0]}')
    else:
        for item in scan:
            value = setting(item.replace('lookandfeel', 'default'))
            query = {"jsonrpc": "2.0", "method": "Settings.setsettingValue", "params": {{"setting": f'"{item}"', "value": value}}, "id": 1}
            response = jsonrpc(query)
            log(f'{item} restored to {value}')


def defaultskin():
    log('[Default Skin Check]')
    ADDONS = joinpath(homepath, 'addons')
    GUISETTINGS = joinpath(userdata, 'guisettings.xml')
    tempgui = joinpath(userdata, 'guitemp.xml')
    gui = tempgui if existspath(tempgui) else GUISETTINGS
    if not existspath(gui): return False
    log(f'Reading gui file: {gui}')
    with open(gui, 'r+') as guif:
        msg = guif.read().replace('\n', '').replace('\r', '').replace('\t', '').replace('    ', '')
    log('Opening gui settings')
    match = re.compile('<lookandfeel>.+?<ski.+?>(.+?)</skin>.+?</lookandfeel>').findall(msg)
    log(f'Matches: {match}')
    if len(match) > 0:
        skinid = match[0]
        addonxml = joinpath(ADDONS, match[0], 'addon.xml')
        if existspath(addonxml):
            with open(addonxml, 'r+') as addf:
                msg2 = addf.read().replace('\n', '').replace('\r', '').replace('\t', '')
            match2 = re.compile('<addon.+?ame="(.+?)".+?>').findall(msg2)
            skinname = match2[0] if len(match2) > 0 else 'no match'
        else: skinname = 'no file'
        log(f'[Default Skin Check] Skin name: {skinname} Skin id: {skinid}')
        setsetting('defaultskin', skinid)
        setsetting('defaultskinname', skinname)
        setsetting('defaultskinignore', 'false')
    if existspath(tempgui):
        log('Deleting Temp Gui File.')
        deletefile(tempgui)
    log('[Default Skin Check] End')


def checkskin():
    ADDONS = joinpath(homepath, 'addons')
    log('Invalid Skin Check Start')
    DEFAULTSKIN = setting('defaultskin')
    DEFAULTNAME = setting('defaultskinname')
    DEFAULTIGNORE = setting('defaultskinignore')
    gotoskin = False
    if DEFAULTSKIN != '':
        if existspath(joinpath(ADDONS, DEFAULTSKIN)):
            if yesnodialog(addontitle, f'[COLOR {color2}]It seems that the skin has been set back to [COLOR {color1}]{DEFAULTNAME.title()}[/COLOR][CR]Would you like to set the skin back to:[CR][COLOR {color1}]{DEFAULTNAME}[/COLOR]'):
                gotoskin = DEFAULTSKIN
                gotoname = DEFAULTNAME
            else:
                gotoskin = _set_defaultskinignore('Skin was not reset')
        else:
            setsetting('defaultskin', '')
            setsetting('defaultskinname', '')
            DEFAULTSKIN = ''
            DEFAULTNAME = ''
    if DEFAULTSKIN == '':
        skinname = []
        skinlist = []
        for folder in glob.glob(joinpath(ADDONS, 'skin.*/')):
            xml = f'{folder}/addon.xml'
            if existspath(xml):
                with open(xml, mode='r') as f:
                    g = f.read().replace('\n', '').replace('\r', '').replace('\t', '')
                match = re.compile('<addon.+?id="(.+?)".+?>').findall(g)
                match2 = re.compile('<addon.+?name="(.+?)".+?>').findall(g)
                log(f'{folder}: {match[0]}')
                if len(match) > 0:
                    skinlist.append(str(match[0]))
                    skinname.append(str(match2[0]))
                else: log(f'ID not found for {folder}')
            else: log(f'ID not found for {folder}')
        if skinlist:
            if len(skinlist) > 1:
                if yesnodialog(addontitle, f'[COLOR {color2}]It seems that the skin has been set back to [COLOR {color1}]{skinlist[5:]}[/COLOR][CR]Would you like to view a list of avaliable skins?[/COLOR]'):
                    choice = selectdialog('Select skin to switch to!', skinname)
                    if choice == -1:
                        log('Skin was not reset')
                        setsetting('defaultskinignore', 'true')
                    else:
                        gotoskin = skinlist[choice]
                        gotoname = skinname[choice]
                else:
                    log('Skin was not reset')
                    setsetting('defaultskinignore', 'true')
            elif yesnodialog(addontitle, f'It seems that the skin has been set back to {skinlist[5:]}[CR]Would you like to set the skin back to: [CR] {skinname[0]} '):
                gotoskin = skinlist[0]
                gotoname = skinname[0]
            else:
                log('Skin was not reset')
                setsetting('defaultskinignore', 'true')
        else:
            gotoskin = _set_defaultskinignore('No skins found in addons folder.')
    if gotoskin:
        swapskins(gotoskin)
        x = 0
        sleep(1000)
        while not condvisibility('Window.isVisible(yesnodialog)') and x < 150:
            x += 1
            sleep(200)
        if condvisibility('Window.isVisible(yesnodialog)'):
            execute('SendClick(11)')
            lookandfeeldata('restore')
        else: infodialog('Skin Swap Timed Out!')
    log('Invalid Skin Check End')


def _set_defaultskinignore(msg):
    log(msg)
    setsetting('defaultskinignore', 'true')
    return False