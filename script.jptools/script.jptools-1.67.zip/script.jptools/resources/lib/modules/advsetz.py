# -*- coding: UTF-8 -*-


import re
import sys

from modules.textviewer import text_view
from modules.control import addontitle, deletefile, yesnodialog, okdialog, get_keyboard, infolabel, joinpath, kodi_version, transpath

advancedsettingsfile = transpath(joinpath('special://profile/', 'advancedsettings.xml'))


def xml_data_advsettings_old(size):
    return f"""<advancedsettings>
      <network>
        <curlclienttimeout>10</curlclienttimeout>
        <curllowspeedtime>20</curllowspeedtime>
        <curlretries>2</curlretries>
        <cachemembuffersize>{size}</cachemembuffersize>
        <buffermode>2</buffermode>
        <readbufferfactor>20</readbufferfactor>
      </network>
</advancedsettings>"""


def xml_data_advsettings_new(size):
    return f"""<advancedsettings>
      <network>
        <disablehttp2>true</disablehttp2>
        <curlclienttimeout>10</curlclienttimeout>
        <curllowspeedtime>20</curllowspeedtime>
        <curlretries>2</curlretries>
      </network>
      <cache>
        <memorysize>{size}</memorysize>
        <buffermode>2</buffermode>
        <readfactor>20</readfactor>
      </cache>
</advancedsettings>"""


def xml_data_advsettings_pathsubstitution(size):
    return """<advancedsettings>
    <pathsubstitution>
        <substitute>
            <from>special://profile/Thumbnails/</from>
            <to>smb://SERVER/Kodi Thumbnails/STICK1</to>
        </substitute>
    </pathsubstitution>
</advancedsettings>"""


def advancedsettings():
    MEM = infolabel('System.Memory(total)')
    FREEMEM = infolabel('System.FreeMemory')
    BUFFER_F = re.sub('[^0-9]', '', FREEMEM)
    BUFFER_F = int(BUFFER_F) // 3
    BUFFERSIZE = BUFFER_F * 1024 * 1024
    # log(MEM)
    choice = yesnodialog(addontitle, f'Free Memory: {str(FREEMEM)}\nOptimal BufferSize is: {str(BUFFER_F)} MB\nChoose an Option below...', 'Use Optimal', 'Input a Value')
    if choice == 1:
        with open(advancedsettingsfile, 'w') as f:
            if kodi_version >= 17: xml_data = xml_data_advsettings_new(str(BUFFERSIZE))
            else: xml_data = xml_data_advsettings_old(str(BUFFERSIZE))
            f.write(xml_data)
            okdialog(addontitle, f'Buffer Size Set to: {int(BUFFERSIZE)}  aka  {int(BUFFER_F)} MB\nPlease restart Kodi for the settings to apply.')
    elif choice == 0:
        BUFFERSIZE = get_keyboard(default=str(BUFFERSIZE), heading='INPUT BUFFER SIZE')
        with open(advancedsettingsfile, 'w') as f:
            if kodi_version >= 17: xml_data = xml_data_advsettings_new(str(BUFFERSIZE))
            else: xml_data = xml_data_advsettings_old(str(BUFFERSIZE))
            f.write(xml_data)
            okdialog(addontitle, f'Buffer Size Set to: {int(BUFFERSIZE)}  aka  {(int(BUFFERSIZE) // (1024 * 1024))} MB\nPlease restart Kodi for the settings to apply.')


def viewadvancedsettings():
    try:
        text_view(advancedsettingsfile)
    except:
        okdialog(addontitle, 'Error\nUnable to view the advancedsettings.xml file.\nMight not have one yet.')
        sys.exit(0)


def clearadvancedsettings():
    try:
        deletefile(advancedsettingsfile)
        okdialog(addontitle, 'Success', 'The advancedsettings.xml has been removed.')
    except:
        okdialog(addontitle, 'Error\nUnable to remove the advancedsettings.xml file.\nMight not have one yet.')
        sys.exit(0)