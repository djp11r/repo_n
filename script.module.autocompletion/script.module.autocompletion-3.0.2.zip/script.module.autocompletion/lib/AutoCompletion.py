# -*- coding: utf8 -*-

# Copyright (C) 2015 - Philipp Temminghoff <phil65@kodi.tv>
# This program is Free Software see LICENSE file for details

import sys
import codecs
import os
import time
import hashlib
import requests
import json
from urllib.parse import quote_plus

import xbmcaddon
import xbmcvfs
import xbmc

HEADERS = {'User-agent': 'Mozilla/5.0'}

ADDON = xbmcaddon.Addon()
SETTING = ADDON.getSetting
ADDON_PATH = os.path.join(os.path.dirname(__file__), '..')
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_DATA_PATH = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}')

MONITOR = xbmc.Monitor()


def get_autocomplete_items(search_str, limit=10, provider=None):
    """
    get dict list with autocomplete
    """
    if xbmc.getCondVisibility('System.HasHiddenInput'): return []

    setting = SETTING('autocomplete_provider').lower()

    if setting == 'youtube': provider = GoogleProvider(youtube=True, limit=limit)
    elif setting == 'google': provider = GoogleProvider(limit=limit)
    elif setting == 'imdb': provider = IMDBProvider(limit=limit)
    elif setting == 'bing': provider = BingProvider(limit=limit)
    elif setting == 'tmdb': provider = TmdbProvider(limit=limit)
    else: provider = LocalDictProvider(limit=limit)
    provider.limit = limit
    return provider.get_predictions(search_str)


def prep_search_str(text):
    for char in text:
        if 1488 <= ord(char) <= 1514: return text[::-1]
    return text


class BaseProvider(object):

    def __init__(self, *args, **kwargs):
        self.limit = int(kwargs.get('limit', 10))
        self.language = SETTING('autocomplete_lang_local') or 'en'

    def get_predictions(self, search_str):
        if not search_str: return []
        items = []
        result = self.fetch_data(search_str)
        for i, item in enumerate(result):
            li = {"label": item, "search_string": prep_search_str(item)}
            items.append(li)
            if i > int(self.limit): break
        return items

    def get_prediction_listitems(self, search_str):
        for item in self.get_predictions(search_str):
            li = {"label": item, "search_string": search_str}
            yield li

    def fetch_data(self, search_str):
        pass

class GoogleProvider(BaseProvider):

    BASE_URL = 'http://clients1.google.com/complete/'

    def __init__(self, *args, **kwargs):
        super(GoogleProvider, self).__init__(*args, **kwargs)
        self.youtube = kwargs.get('youtube', False)

    def fetch_data(self, search_str):
        url = f'search?hl={self.language}&q={quote_plus(search_str)}&json=t&client=serp'
        if self.youtube: url += '&ds=yt'
        result = get_JSON_response(url=self.BASE_URL + url, headers=HEADERS, folder='Google')
        if not result or len(result) <= 1: return []
        else: return result[1]


class BingProvider(BaseProvider):

    BASE_URL = 'http://api.bing.com/osjson.aspx?'

    def __init__(self, *args, **kwargs):
        super(BingProvider, self).__init__(*args, **kwargs)

    def fetch_data(self, search_str):
        url = f'query={quote_plus(search_str)}'
        result = get_JSON_response(url=self.BASE_URL + url, headers=HEADERS, folder='Bing')
        if not result: return []
        else: return result[1]

class IMDBProvider(BaseProvider):

    BASE_URL = 'https://v2.sg.media-imdb.com/'

    def __init__(self, *args, **kwargs):
        super(IMDBProvider, self).__init__(*args, **kwargs)

    def fetch_data(self, search_str):
        url = f'suggests/{search_str[0]}/{quote_plus(search_str)}.json'
        result = get_JSON_response(url=self.BASE_URL + url, headers=HEADERS, folder='IMDB')
        imdb_response = result
        result = [search_str, []]
        try:
            for i in imdb_response['d']:
                if 'trailers' in str(i).lower() and 'Trailers' not in result[1]:
                    result[1].append('Trailers')
                if i.get('q') in ('feature', 'TV series', 'tvSeries', 'movie') and i.get('qid') in ('feature', 'TV series', 'tvSeries', 'movie'):
                    result[1].append(i['l'])
            if not result: return []
            else: return result[1]
        except TypeError: return []

class TmdbProvider(BaseProvider):

    BASE_URL = 'https://www.themoviedb.org/search/multi?'

    def __init__(self, *args, **kwargs):
        super(TmdbProvider, self).__init__(*args, **kwargs)

    def fetch_data(self, search_str):
        url = f'language={self.language}&query={search_str}'
        result = get_JSON_response(url=self.BASE_URL + url, headers=HEADERS, folder='TMDB')
        if not result or not result.get('results'): return []
        out = []
        results = result.get('results')
        for i in results:
            try:
                media_type = i.get('media_type')
                if media_type == 'movie': title = i['title']
                elif media_type in ['tv', 'person']: title = i['name']
                else: title = i
                out.append(title)
            except TypeError: pass
        return out


class LocalDictProvider(BaseProvider):

    def __init__(self, *args, **kwargs):
        super(LocalDictProvider, self).__init__(*args, **kwargs)

    def get_predictions(self, search_str):
        """
        get dict list with autocomplete labels from locally saved lists
        """
        listitems = []
        k = search_str.rfind(' ')
        if k >= 0:
            search_str = search_str[k + 1:]
        path = os.path.join(ADDON_PATH, 'resources', 'data', f'common_{self.language}.txt')
        with codecs.open(path, encoding='utf8') as f:
            for line in f.readlines():
                if not line.startswith(search_str) or len(line) <= 2: continue
                li = {"label": line, "search_string": line}
                listitems.append(li)
                if len(listitems) > int(self.limit): break
        return listitems


def get_JSON_response(url='', cache_days=7.0, folder=False, headers=False):
    """
    get JSON response for *url, makes use of file cache.
    """
    now = time.time()
    hashed_url = hashlib.md5(url.encode()).hexdigest()
    if folder: cache_path = xbmcvfs.translatePath(os.path.join(ADDON_DATA_PATH, folder))
    else: cache_path = xbmcvfs.translatePath(os.path.join(ADDON_DATA_PATH))
    path = os.path.join(cache_path, f'{hashed_url}.txt')
    cache_seconds = int(cache_days * 86400.0)
    if xbmcvfs.exists(path) and ((now - os.path.getmtime(path)) < cache_seconds):
        results = read_from_file(path)
        log(f'loaded file for {url}. time: {time.time() - now:f}')
    else:
        if folder == 'IMDB': response = get_imdb_http(url, headers)
        else: response = get_http(url, headers)
        try:
            if folder == 'IMDB': results = response
            else: results = json.loads(response)
            log(f'download {url}. time: {time.time() - now:f}')
            save_to_file(results, hashed_url, cache_path)
        except Exception:
            log(f'Exception: Could not get new JSON data from {url}. Tryin to fallback to cache')
            log(response)
            if xbmcvfs.exists(path): results = read_from_file(path)
            else: results = []
    if results: return results
    else: return []

def get_imdb_http(url=None, headers=False):
    """
    fetches data from *url, returns it as a string
    """
    succeed = 0
    if not headers: headers = HEADERS
    while succeed < 2 and not MONITOR.abortRequested():
        try:
            r = requests.get(url, headers=headers)
            if r.status_code != 200: raise Exception
            r = json.loads(r.text[r.text.index('(')+1:-1])
            return r
        except Exception:
            log(f'get_http: could not get data from {url}')
            xbmc.sleep(1000)
            succeed += 1
    return None

def get_http(url=None, headers=False):
    """
    fetches data from *url, returns it as a string
    """
    succeed = 0
    if not headers: headers = HEADERS
    while succeed < 2 and not MONITOR.abortRequested():
        try:
            r = requests.get(url, headers=headers)
            if r.status_code != 200: raise Exception
            return r.text
        except Exception:
            log(f'get_http: could not get data from {url}')
            xbmc.sleep(1000)
            succeed += 1
    return None


def read_from_file(path='', raw=False):
    """
    return data from file with *path
    """
    if not xbmcvfs.exists(path): return False
    try:
        with open(path) as f:
            log(f'opened textfile {path}.')
            if raw: return f.read()
            else: return json.load(f)
    except Exception:
        log(f'failed to load textfile: {path}')
        return False


def log(txt):
    message = f'{ADDON_ID}: {txt}'
    xbmc.log(msg=message, level=xbmc.LOGDEBUG)


def save_to_file(content, filename, path=''):
    """
    dump json and save to *filename in *path
    """
    if not xbmcvfs.exists(path): xbmcvfs.mkdirs(path)

    text_file_path = os.path.join(path, f'{filename}.txt')
    now = time.time()

    with open(text_file_path, 'w') as f:
        json.dump(content, f)

    log(f'saved textfile {text_file_path}. Time: {time.time() - now:f}')
    return True
