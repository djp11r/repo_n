# -*- coding: utf-8 -*-
#------------------------------------------------------------
# http://www.youtube.com/user/BAPSChannel
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys

try: from urllib import unquote_plus, quote_plus
except: from urllib.parse import unquote_plus, quote_plus

import xbmc,xbmcaddon,xbmcgui,xbmcplugin


addon = xbmcaddon.Addon
addonID = xbmcaddon.Addon().getAddonInfo('id')
addonInfo = xbmcaddon.Addon().getAddonInfo
addonName = addonInfo('name')
icon = addonInfo('icon')
fanart = addonInfo('fanart')
path_ = addonInfo('path')

art = os.path.join(path_, 'resources', 'art')
isub = os.path.join(art, 'sub.png')
iibn7 = os.path.join(art, 'ibn7.png')
isony = os.path.join(art, 'sony.png')


# yt_chn_ids = ["BAPSChannel","sabtv","ibn7","setindia"]
# yt_chn_ids = [("BAPS Channel", "BAPSChannel"),("Sab Tv", "sabtv"),("Ibn7", "ibn7"),("Set India", "setindia")]
module_log_enabled = True#False


def getS(name):
    try: return addon.getSetting(name)
    except: return False

def setS(name, value):
    try: addon.setSetting(name, value)
    except: return False

def openS(name=""):
    addon.openSettings()


# Write this module messages on XBMC log
def _log(message):
    if module_log_enabled: xbmc.log("%s ~~ %s" %(addonID , message))


# Entry point
def run():
    # Get params
    params = get_params()
    # _log("bapsyt.run %s" % params)
    if params is None:
        main_list(params)
    else: pass
    close_item_list()


# Main menu
def main_list(params):
    yt_url = "plugin://plugin.video.youtube/user/%s/"
    # _log("bapsyt.main_list: %s" % repr(params))
    add_item(title="BAPS Channel", url=yt_url % "BAPSChannel", thumbnail=icon, fanart=fanart, folder=True )
    add_item(title="Sab Tv", url=yt_url % "sabtv", thumbnail=isub, fanart=fanart, folder=True )
    add_item(title="Ibn7", url=yt_url % "ibn7", thumbnail=iibn7, fanart=fanart, folder=True )
    add_item(title="Set India", url=yt_url % "setindia", thumbnail=isony, fanart=fanart, folder=True )

def add_item(title="", url="", action="", plot="", thumbnail="", fanart="", show="", episode="", extra="", page="", info_labels=None, isPlayable=False, folder=True):
    # _log("add_item action=[%s] title=[%s] url=[%s] thumbnail=[%s] fanart=[%s] show=[%s] episode=[%s] extra=[%s] page=[%s] isPlayable=[%s] folder=[%s]" % (action, title, url, thumbnail, fanart, show, episode, extra, page, str(isPlayable), str(folder)))
    try: listitem = xbmcgui.ListItem(offscreen=True)
    except: listitem = xbmcgui.ListItem()
    if info_labels is None: info_labels = { "Title": str(title), "Plot": str(plot)}
    listitem.setInfo( "video", info_labels )
    listitem.setLabel(str(title))
    listitem.setArt({'poster': thumbnail, 'icon': thumbnail, 'thumb': thumbnail, 'fanart': fanart})

    if fanart!="":
        listitem.setProperty('fanart_image',fanart)
        xbmcplugin.setPluginFanart(int(sys.argv[1]), fanart)

    if url.startswith("plugin://"):
        # _log("1 action: %s title: %s" % (action, title))
        itemurl = url
        listitem.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem( handle=int(sys.argv[1]), url=itemurl, listitem=listitem, isFolder=folder)
    elif isPlayable:
        listitem.setProperty("Video", "true")
        listitem.setProperty('IsPlayable', 'true')
        # print('>>>>>>>>>>>> '+str(url))
        itemurl = '%s?action=%s&title=%s&url=%s&thumbnail=%s&plot=%s&extra=%s&page=%s' % ( sys.argv[0] , action , quote_plus(title) , quote_plus(url) , quote_plus(thumbnail) , quote_plus(plot) , quote_plus(extra) , quote_plus(page))
        xbmcplugin.addDirectoryItem( handle=int(sys.argv[1]), url=itemurl, listitem=listitem, isFolder=folder)
    else:
        itemurl = '%s?action=%s&title=%s&url=%s&thumbnail=%s&plot=%s&extra=%s&page=%s' % ( sys.argv[0] , action , quote_plus(title) , quote_plus(url) , quote_plus(thumbnail) , quote_plus(plot) , quote_plus(extra) , quote_plus(page))
        xbmcplugin.addDirectoryItem( handle=int(sys.argv[1]), url=itemurl, listitem=listitem, isFolder=folder)


def close_item_list():
    # _log("close_item_list")
    xbmcplugin.endOfDirectory(handle=int(sys.argv[1]))#, cacheToDisc=True)


# Parse XBMC params - based on script.module.parsedom addon
def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
        return param


run()
