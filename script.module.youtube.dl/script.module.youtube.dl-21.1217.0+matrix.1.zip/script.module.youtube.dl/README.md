USAGE

Add this to your addon.xml to use the latest version. You will need to update this for new versions of the addon because I'm not sure module addons will update otherwise.
This was the newest version at the time of this post, you will need to change the version in the future if you want to ensure the latest version is used.

<import addon="script.module.youtube.dl" version="14.810.0"/>

Getting playable streams:

import YDStreamExtractor
YDStreamExtractor.disableDASHVideo(True) #Kodi (XBMC) only plays the video for DASH streams, so you don't want these normally. Of course these are the only 1080p streams on YouTube

url = "http://www.youtube.com/watch?v=_yVv9dx88x0" #a youtube ID will work as well and of course you could pass the url of another site
vid = YDStreamExtractor.getVideoInfo(url,quality=1) #quality is 0=SD, 1=720p, 2=1080p and is a maximum
stream_url = vid.streamURL() #This is what Kodi (XBMC) will play

For sites that can have multiple streams (ie different trailers for the same video URL) you would use:

choices = []
if vid.hasMultipleStreams():
    for s in vid.streams():
        title = s['title']
        choices.append(title)
    index = some_function_asking_the_user_to_choose(choices)
    vid.selectStream(index) #You can also pass in the the dict for the chosen stream
stream_url = vid.streamURL()

Also, the following is useful if you need to verify whether multiple URLs represent a playable video. It basically checks whether the the URL is a valid type for one of the supported sites without actually accessing anything:

#This will return True if the URL points (probably) to a video without actually fetching all the stream info.
YDStreamExtractor.mightHaveVideo(url)

For some sites and URLs the module will fail to detect a valid URL because of redirects. For those sites you can set the keyword argument "resolve_redirects=True" for mightHaveVideo() and getVideoInfo().


And to download a video:

import YDStreamUtils
import YDStreamExtractor
YDStreamExtractor.disableDASHVideo(True)

url = "http://www.youtube.com/watch?v=_yVv9dx88x0"
vid = YDStreamExtractor.getVideoInfo(url,quality=1)
path = "/directory/where/we/want/the/video"

with YDStreamUtils.DownloadProgress() as prog: #This gives a progress dialog interface ready to use
    try:
        YDStreamExtractor.setOutputCallback(prog)
        result = YDStreamExtractor.downloadVideo(vid,path)
        if result:
            #success
            full_path_to_file = result.filepath
        elif result.status != 'canceled':
            #download failed
            error_message = result.message
    finally:
        YDStreamExtractor.setOutputCallback(None)

YDStreamExtractor.py has some documentation for the functions if you need more detail.