# CloudRequest

**Version:** 1.0.2  
**Developed by:** oneplay team

---

## Sobre

CloudRequest is a lightweight and powerful HTTP library for Kodi that provides a **CloudScraper** session with automatic Cloudflare bypass (including the IUAM challenge - &quot;I'm Under Attack Mode&quot;).

Allows Kodi addons to access Cloudflare-protected sites transparently, without interruptions or blocks.

---

## Recursos

- Automatic bypass of Cloudflare IUAM, v2, v3, and Turnstile challenges
- Compatible with the `requests` API
- **Own JavaScript interpreter** — no external JS runtime dependencies
- Implemented 100% in Python
- Lightweight and optimized for Kodi

---

## Como usar

```python
from cloudrequest import CloudRequest

# Create a session with Cloudflare bypass
session = CloudRequest().get_session()

# Make requests normally, as if it were requests
response = session.get("https://site-protegido.com")
print(response.text)
```

The returned session is fully compatible with the `requests` API:

```python
session = CloudRequest().get_session()

# GET with parameters
response = session.get("https://site-protegido.com/api", params={"q": "busca"})

# POST with data
response = session.post("https://site-protegido.com/login", data={"user": "x", "pass": "y"})

# Accessing cookies and response headers
print(response.status_code)
print(response.cookies)
```

---

## Internal architecture

```
cloudscraper/
├── __init__.py                  # Cloudscraper Core
├── cloudflare.py                # Handler IUAM v1
├── cloudflare_v2.py             # Handler IUAM v2
├── cloudflare_v3.py             # Handler JS VM v3
├── turnstile.py                 # Handler Turnstile
├── stealth.py                   # Anti-detection techniques
├── http_inspector.py            # HTTP Inspector (replaces requests-toolbelt)
├── help.py                      # Environmental diagnosis
└── interpreters/
    ├── __init__.py              # JavaScriptInterpreter + NativeInterpreter
    └── js_engine.py             # Pure JS engine in Python
```

O `js_engine.py` implements the ES5/ES6 subset required to solve Cloudflare challenges:

- JS type coercion (`+[]`, `!+[]`, `[]+{}`, etc.)
- Escopos léxicos, closures, arrow functions
- Operators bitwise, `typeof`, `instanceof`
- Built-ins: `Math`, `JSON`, `Array`, `String`, `Object`, `Number`, `atob/btoa`, `parseInt`, `console`, `Date.now`

---

## 🏆 Special Credits

---

### 🕷️ cloudscraper — VeNoMouS

> **Repository:** [github.com/VeNoMouS/cloudscraper](https://github.com/VeNoMouS/cloudscraper)

O **cloudscraper** is the backbone of this module. Built on top of `requests`, it implements all of the Cloudflare protection detection and bypass logic — from classic IUAM to modern Turnstile.

Without **VeNoMouS**, Cloudflare bypass in Python would be a nightmare. 🎩

---

### 🧠 js2py — Piotr Dabkowski *(inspiration)*

> **Repository:** [github.com/PiotrDabkowski/Js2Py](https://github.com/PiotrDabkowski/Js2Py)

O **js2py** was the original inspiration for the approach of interpreting JavaScript directly in Python. As of v1.0.2, CloudRequest no longer depends on js2py as an installed library — the engine is its own and built-in. 🙌

---

## 📄 Dependency Licenses

| Library | Author | License | Link |
|---|---|---|---|
| [cloudscraper](https://github.com/VeNoMouS/cloudscraper) | VeNoMouS | MIT | [View license](https://opensource.org/licenses/MIT) |

---

*Made with ❤️ by **oneplay team***
