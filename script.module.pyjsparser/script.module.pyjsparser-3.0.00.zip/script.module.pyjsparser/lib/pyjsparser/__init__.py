__all__ = ['PyJsParser', 'parse', 'JsSyntaxError', 'pyjsparserdata']
__author__ = 'Piotr Dabkowski'
__version__ = '2.5.2'
from .parser import PyJsParser, parse, JsSyntaxError
from . import pyjsparserdata