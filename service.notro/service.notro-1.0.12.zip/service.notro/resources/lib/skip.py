# -*- coding: utf-8 -*-

import time
from traceback import print_exc
from xbmcgui import WindowXMLDialog
from xbmc import sleep, getInfoLabel
from resources.lib.kodiutils import logger


class Skip(WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super(Skip, self).__init__(self, args)
        self.isVisible = False
        self.player = kwargs['player']
        self.window_style, self.skip_option = kwargs.get('window_style', '0'), kwargs.get('skip_option')
        self.media_type = 'movie'
        try: self.a_skip_t = int(self.skip_option.get('skip')) + int(self.skip_option.get('start'))
        except: self.a_skip_t = 60
        self.skipLabel = 'Skip: '
        self.skip_win_no = 0
        self.set_properties()

    def onInit(self):
        """"""

    def show_with_callback(self, callback, intro=True):
        self.callback = callback
        # logger(f'Skip self.isButtonVisible: {self.isButtonVisible}')
        if self.isButtonVisible is False:
            episode = getInfoLabel('VideoPlayer.Episode')
            if episode: self.setProperty('media_type', 'episode')
            self.skip_option = self.player.skip_option
            # logger(f'Skip episode: {repr(episode)} skip_option: {self.skip_option}')
            if intro:
                self.setProperty('window_style', str(self.window_style))
                self.skipLabel = f'Skip: {self.skip_option.get("skip", "")} ~ {self.skip_win_no}'
            else: self.setProperty('window_style', '2')
            self.setProperty('skip_title', self.skipLabel)
            self.show()
            self.setVisibility()
            try: self.setFocusId(201)
            except: pass
            self.skip_win_no += 1
            # logger(f'self.isVisible: {self.isVisible} self.window_style: {self.window_style} Skip skipLabel: {self.skipLabel}')

    def onClick(self, controlid):
        # logger(f'onClick controlid: {controlid}')
        if controlid == 201:
            self.callback()
        elif controlid in (10, 92, 9, 13): # closing_actions
            self.skip_close_dialogs()

    @property
    def isButtonVisible(self):
        return self.isVisible


    @property
    def getButtonno(self):
        return self.skip_win_no

    def setVisibility(self):
        self.isVisible = not self.isVisible

    def skip_close_dialogs(self):
        self.close()
        self.setVisibility()


    def onAction(self, action):
        if action in (10, 92, 9, 13):
            self.skip_close_dialogs()

    def set_properties(self):
        self.setProperty('window_style', str(self.window_style))
        self.setProperty('skip_title', self.skipLabel)
        self.setProperty('update_skip', '')
        self.setProperty('media_type', self.media_type)
