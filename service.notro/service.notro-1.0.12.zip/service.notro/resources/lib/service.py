# -*- coding: utf-8 -*-

import time
from traceback import print_exc, TracebackException
from resources.lib.kodiutils import addonInfo, get_skip_option, make_settings_dict, homeWindow, logger
from resources.lib.skip import Skip

import xbmc
import xbmcgui
import xbmcaddon


class PlayerDialogs(xbmc.Player):

    def __init__(self):
        super(PlayerDialogs, self).__init__()
        logger('NotroPlayer init...')
        self._initialState()

    def onAVStarted(self):
        if self.isPlayingVideo() and not self.playing:
            try:
                # logger('Kodi actually started playing a media item/displaying frames')
                try: self.total_time, self.start_time, self.playing = self.getTotalTime(), self.getTime(), True
                except: self.playing = False
                if 'pvr://' in str(xbmc.getInfoLabel('Player.Filenameandpath')): return
                self.Title = xbmc.getInfoLabel('VideoPlayer.Title')
                if not self.Title: self.Title = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
                # logger(f'Kodi xbmc.getInfoLabel Player.Filenameandpath: {xbmc.getInfoLabel('Player.Filenameandpath')}')
                # if '.m3u8' in xbmc.getInfoLabel('Player.Filenameandpath'): return
                # logger(f'Kodi actually started playing Title: {self.Title}\n self.__dict__: {repr(self.__dict__)}')
                if not self.skip_option: self.skip_option = get_skip_option()
                # logger(f'Kodi actually started playing playing.skip_option: {repr(self.skip_option)}')
                self.intro_start_time = int(self.skip_option.get('start'))
                self.intro_end_time = int(self.skip_option.get('skip'))
                self.a_skip_t = self.intro_start_time + self.intro_end_time
                # logger(f'self.a_skip_t: {self.a_skip_t} intro_start_time: {self.intro_start_time} self.intro_end_time : {self.intro_end_time} ')
            except Exception as exc:
                # tb = traceback.TracebackException.from_exception(exc)
                # error_tb = ''.join(tb.stack.format())
                logger(f'onAVStarted error : \n {print_exc()}')#self.skip_close_dialogs()

    def onPlayBackEnded(self):
        # logger('Playback has ended')
        self._initialState()

    def onPlayBackStopped(self):
        if not self.isPlayingVideo() and self.playing:
            # logger('Playback has been stopped')
            self._initialState()

    def _initialState(self):
        self.playing = False
        self.skip_option = {}
        self.Title = None
        self.intro_start_time = 10
        self.intro_end_time = 70
        self.outro_start_time = 260
        self.outro_end_time = 5

    @property
    def hasIntro(self):
        try:
            currentTime = self.getTime()
            if not currentTime: currentTime = 0
            self.intro_start_time = int(self.skip_option.get('start'))
            self.t_intro_end_time = self.intro_start_time + int(self.skip_option.get('skip')) + int(self.skip_option.get('duration'))
            # logger(f'currentTime: {currentTime} self.a_skip_t: {self.a_skip_t} intro_start_time: {self.intro_start_time} self.intro_end_time : {self.intro_end_time} self.t_intro_end_time: {self.t_intro_end_time}')
            return self.intro_start_time < currentTime < self.t_intro_end_time
        except: pass #logger(f'hasIntro error : \n {repr(print_exc())}')

    def skipIntro(self):
        try:
            skipTime = self.a_skip_t - self.getTime()
            # logger(f'skipTime: {skipTime} self.getTime():{self.getTime()}')
            if skipTime < 0: skipTime = 15
            skipTime += self.getTime()
            # logger(f'skipTime: {skipTime} self.getTime():{self.getTime()}')
            self.seekTime(skipTime)
        except: logger(f'skipIntro error : \n {repr(print_exc())}')

    @property
    def hasOutro(self):
        try:
            currentTime = self.getTime()
            if not currentTime: currentTime = 0
            self.outro_end_time = self.getTotalTime() - 1
            self.outro_start_time = self.outro_end_time - int(self.skip_option.get('duration')) - int(self.skip_option.get('eskip'))
            return self.outro_start_time < currentTime < self.outro_end_time
        except: pass #logger(f'hasOutro error : \n {repr(print_exc())}')

    def skipOutro(self):
        try:
            # xbmc.executebuiltin('PlayerControl(BigSkipForward)') # skip to end of current
            self.outro_end_time = self.getTotalTime() - 1
            logger(f'skipOutro self.outro_end_time: {self.outro_end_time}')
            self.seekTime(self.outro_end_time) # OR use this line
        except Exception as exc:
            logger(f'Failed to seekTime(): {exc}')
            self.stop() # if skip to end error then stop player


class NotroMonitor(xbmc.Monitor):

    def __init__(self):
        logger('NotroMonitor init...')

    def onSettingsChanged(self):
        logger('You can use this event to change any variables that depend on the addon settings')
        homeWindow.clearProperty('notro_settings')
        xbmc.sleep(50)
        refreshed = make_settings_dict()


def run():

    # logger('service started...')

    #Instantiate the skip_option
    skip_option = get_skip_option()
    service = skip_option.get('service') == 'true'
    if not service: return
    logger(f'service started... {service}')

    # Instantiate player event listener
    player = PlayerDialogs()

    # Instantiate your monitor
    monitor = NotroMonitor()

    #Instantiate the button
    dialog_type = skip_option.get('dialog_type')
    dialog_inst = skip_option.get('dialog_inst')
    window_style = 0
    if dialog_type != 'Netflix': window_style = 1
    buttonskip = Skip('skipmulti.xml', addonInfo('path'), 'default', "1080i", player=player, window_style=window_style, skip_option=skip_option)
    while not monitor.abortRequested():
        # Sleep/wait for abort for 1 second
        if monitor.waitForAbort(1):
            # Abort was requested while waiting. We should exit
            break

        # logger(f'player.isPlayingVideo(): {player.isPlayingVideo()} player.skip_option: {player.skip_option}')
        if player.isPlayingVideo() and player.playing:
            # if player.hasIntro or player.hasOutro:
                # logger(f'SERVICE player.hasIntro: {player.hasIntro} player.hasOutro: {player.hasOutro} player.skip_option: {player.skip_option} skip_option: {skip_option}')
            # logger(f'player.skip_option.get(service): {repr(player.skip_option)}')
            if player.hasIntro:# and buttonskip.getButtonno < int(dialog_inst):
                # logger(f'player.hasIntro: {player.hasIntro} buttonskip.isButtonVisible: {buttonskip.isButtonVisible} getButtonno: {type(buttonskip.getButtonno)}  {buttonskip.getButtonno}')
                if buttonskip.getButtonno > int(dialog_inst):
                    buttonskip.close()
                    buttonskip.setVisibility()
                else: buttonskip.show_with_callback(player.skipIntro)
                # buttonskip.show_with_callback(player.skipUpdate)
            elif player.hasOutro:# and buttonskip.getButtonno < int(dialog_inst)* 2:
                # logger(f'player.hasOutro: {player.hasOutro}')
                buttonskip.show_with_callback(player.skipOutro, False)
                # buttonskip.show_with_callback(player.skipUpdate)
            else:
                # logger(f'buttonskip.isButtonVisible: {buttonskip.isButtonVisible}')
                if (not player.hasIntro or not player.hasOutro):
                    buttonskip.skip_win_no = 0
                    # if buttonskip.skip_win_no == int(dialog_inst) + 1: buttonskip.skip_win_no = 0
                if buttonskip.isButtonVisible is True:
                    buttonskip.close()
                    buttonskip.setVisibility()
        else:
            buttonskip.skip_win_no = 0
            if buttonskip.isButtonVisible is True:
                buttonskip.close()
                buttonskip.setVisibility()
