# -*- coding: utf-8 -*-

import os
import re
from json import dumps as jsdumps, loads as jsloads

from xbmcvfs import translatePath
from xbmc import executeJSONRPC, log
from xbmcaddon import Addon
from xbmcgui import Window, Dialog


addonObject = Addon('service.notro')
addonInfo = addonObject.getAddonInfo
profilePath = translatePath(addonInfo('profile'))
if not os.path.exists(profilePath): os.mkdir(profilePath)

settingsFile = os.path.join(profilePath, 'settings.xml')
LOGPATH = translatePath('special://logpath/')
log_file = os.path.join(LOGPATH, 'notro.log')

homeWindow = Window(10000)


def show_settings():
    addonObject.openSettings()


def get_setting(id, fallback=None):
    try: settings_dict = jsloads(homeWindow.getProperty('notro_settings'))
    except: settings_dict = make_settings_dict()
    if settings_dict is None: settings_dict = settings_fallback(id)
    value = settings_dict.get(id, '')
    if fallback is None: return value
    if value == '': return fallback
    return value
    # return addonObject.getSettings(id).strip().decode('utf-8')


def settings_fallback(id):
    return {id: Addon().getSetting(id)}


def set_setting(setting, value):
    addonObject.setSetting(setting, str(value))


def make_settings_dict(): # service runs upon a setting change
    try:
        from xml.dom.minidom import parse as mdParse
        root = mdParse(settingsFile) 
        curSettings = root.getElementsByTagName("setting") #minidom instead of element tree
        settings_dict = {}
        for item in curSettings:
            dict_item = {}
            setting_id = item.getAttribute('id')
            try: setting_value = item.firstChild.data
            except: setting_value = None
            if setting_value is None: setting_value = ''
            dict_item = {setting_id: setting_value}
            settings_dict.update(dict_item)
        homeWindow.setProperty('notro_settings', jsdumps(settings_dict))
        # logger(f'settings_dict = {settings_dict}')
        return settings_dict
    except: return None



def get_skip_option():
    skip = get_setting('skip') or '50'
    start = get_setting('skip_start') or '10'
    eskip = get_setting('eskip') or '360'
    duration = get_setting('dialog_duration') or '360'
    dialog_type = get_setting('skip.dialog') or 'Netflix'
    dialog_inst = get_setting('dialog_inst') or '4'
    skip_service = get_setting('skip_service') or False
    return {'dialog_inst': dialog_inst,'dialog_type': dialog_type,'duration': duration, 'service': skip_service, 'skip': skip, 'start': start, 'eskip': eskip}


loging = get_setting('debug')
debug_location = get_setting('debug_location')


def logger(msg):
    if loging:
        if debug_location == 'notro':
            with open(log_file, 'a') as f:
                line = f'###Notro###:\n {msg}'
                f.write(line.rstrip('\r\n')+'\n')
        else: log(f'###Notro###: {msg}', 1)
