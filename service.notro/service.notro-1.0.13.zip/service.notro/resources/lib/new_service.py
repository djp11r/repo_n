import os
import json
from dataclasses import dataclass
from traceback import print_exc
from xbmcgui import WindowXMLDialog
from xbmc import getInfoLabel, Monitor, Player, log
from xbmcaddon import Addon
from xbmcvfs import translatePath, exists, mkdir

addonObject = Addon('service.notro')
addonInfo = addonObject.getAddonInfo
profilePath = translatePath(addonInfo('profile'))
if not exists(profilePath): mkdir(profilePath)


LOGPATH = translatePath('special://logpath/')
log_file = os.path.join(LOGPATH, 'notro.log')


def get_setting(id):
    return addonObject.getSetting(id)

loging = get_setting('debug') == 'true'
debug_location = get_setting('debug_location')

_LOG_BUFFER = []


def _flush_logs():
    if not _LOG_BUFFER: return
    try:
        with open(log_file, 'a') as f:
            f.write('\n'.join(_LOG_BUFFER) + '\n')
    except: pass
    _LOG_BUFFER[:] = []


def logger(msg):
    if not loging: return
    msg = f'~~~Notro~~~: {msg}'
    if debug_location == '1':
        _LOG_BUFFER.append(msg)
        if len(_LOG_BUFFER) >= 20:
            _flush_logs()
    else: log(msg, 1)


@dataclass(frozen=True)
class SkipConfig:
    window_style: int
    nos_of_window: int
    window_first_minutes: int
    window_last_minutes: int
    intro_length: int
    intro_start: int
    intro_end: int
    outro_length: int
    outro_start: int
    outro_end: int


_SETTINGS_CACHE = None

def load_settings_cache() -> SkipConfig:
    """
    Load addon settings once and return a SkipConfig directly.
    Fastest possible design.
    """
    global _SETTINGS_CACHE
    if _SETTINGS_CACHE is not None:
        return _SETTINGS_CACHE

    def fetch(key: str, default: int) -> int:
        try:
            val = get_setting(key)
            return int(val) if val not in ("", None) else default
        except (ValueError, TypeError):
            return default

    # Load raw values
    style = fetch('window_style', 0)
    count = fetch('nos_of_window', 6)
    first_min = fetch('window_first_minutes', 5) * 60  # Default 300s
    last_min = fetch('window_last_minutes', 5) * 60  # Default 300s
    i_len = fetch('intro_length', 50)
    i_start = fetch('intro_start', 10)
    o_len = fetch('outro_length', 40)

    # Build SkipConfig directly
    _SETTINGS_CACHE = SkipConfig(
        window_style=style,
        nos_of_window=count,
        window_first_minutes=first_min,
        window_last_minutes=last_min,
        intro_length=i_len,
        intro_start=i_start,
        intro_end=i_start + i_len + first_min,
        outro_length=o_len,
        outro_start=300,
        outro_end=1200,
    )

    return _SETTINGS_CACHE


class SkipDialog(WindowXMLDialog):
    """The Netflix-style popup button."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        logger("SkipDialog initialized")
        self.player = kwargs.get('player')

    def onInit(self):
        self.setFocusId(201)  # Focus the Skip button

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (7, 77, 115):  # Enter, S-key, Select
            if self.player: self.player.perform_skip()
            self.close()
        elif action_id in (10, 92, 13, 9):  # Back, PreviousMenu, CloseDialog, ESC
            # logger(f"SkipDialog: User closed dialog with BACK: {action_id}")
            if self.player: self.player.is_showing_ui = False

    def onClick(self, controlId):
        if controlId == 201 and self.player:
            self.player.perform_skip()

    def onClosed(self):
        # Notify player that this dialog is fully gone
        if self.player:
            self.player.on_dialog_closed()


class PlayerDialogs(Player):
    def __init__(self):
        super().__init__()
        logger("PlayerDialogs initialized")
        self.addon = addonObject
        # self.cache = SkipCache(self.addon.getAddonInfo('id'))
        self.dialog = None
        self._reset_state()

    def _reset_state(self):
        # Playback state
        self.playback_active = False
        self.pvr_mode = False
        self.active_config = None
        self.total_time = 0

        # Dialog state
        self.dialog = None
        self.is_showing_ui = False
        self.dialog_show_count = 0
        self.dialog_show_limit = 6

        # Intro/outro state
        self.in_intro = False
        self.in_outro = False
        self.intro_done = False
        self.outro_started = False

        # UI diff cache
        self._last_label = None
        self._last_number = None
        self._last_progress = None
        self._last_style = None
        self._last_media_type = None

    def onPlayBackStarted(self):
        self._reset_state()
        self.playback_active = True
        filename = getInfoLabel("Player.Filenameandpath").lower()
        if filename.startswith("pvr://"):
            self.pvr_mode = True
            logger("PVR stream detected — entering low-CPU mode")
            return
        # logger(f"Playback started: Monitoring for skip windows... self.total_time: {self.total_time} self.active_config: {self.active_config}")

    def onPlayBackEnded(self):
        self.onPlayBackStopped()

    def onPlayBackStopped(self):
        """Clean up the dialog object entirely when the video ends."""
        self.playback_active = False
        self.pvr_mode = False
        if self.dialog:
            try: self.dialog.close()
            except: pass
            self.dialog = None
        self.is_showing_ui = False
        self._reset_state()

    # CHAPTER DETECTION
    def _detect_recap_from_chapters(self, file_id):
        chapters_json = getInfoLabel('VideoPlayer.AvailableChapters')
        if not chapters_json: return False
        lower = chapters_json.lower()
        if "recap" not in lower and "intro" not in lower and "opening" not in lower:
            return False

        try:
            chaps = json.loads(chapters_json)
            for i, c in enumerate(chaps):
                name = c.get('name', '').lower()
                if any(k in name for k in ('recap', 'intro', 'opening')):
                    start = int(c.get('time', 0))
                    end = int(chaps[i + 1].get('time')) if i + 1 < len(chaps) else start + 90
                    # Merge detected points with user settings (style/window sizes)
                    settings = load_settings_cache()
                    self.active_config = SkipConfig(
                        window_style=settings.window_style,
                        nos_of_window=settings.nos_of_window,
                        window_first_minutes=settings.window_first_minutes,
                        window_last_minutes=settings.window_last_minutes,
                        intro_length=end - start,
                        intro_start=start,
                        intro_end=end,
                        outro_length=settings.outro_length,
                        outro_start=int(self.total_time - settings.outro_length),
                        outro_end=int(self.total_time)
                    )

                    # if self.addon.getSettingBool('use_cache'):
                        # self.cache.set(file_id, asdict(self.active_config))
                    return True
        except: pass
        return False

    def _load_skip_options(self):
        file_id = os.path.basename(self.getPlayingFile())
        self.total_time = self.getTotalTime()

        # 1. Try Cache
        # if self.addon.getSettingBool('use_cache'):
            # cached = self.cache.get(file_id)
            # if cached:
                # self.active_config = SkipConfig(**cached)
                # return

        # 2. Try Chapter Detection (Dynamic Detection)
        if self._detect_recap_from_chapters(file_id):
            return
        # 3. Final Fallback: Use the structured settings logic
        defaults = load_settings_cache()
        self.dialog_show_limit = defaults.nos_of_window
        # Adjust outro based on actual file duration
        outro_start = int(self.total_time - (defaults.outro_length + defaults.window_last_minutes))
        outro_end = int(self.total_time) - 1

        self.active_config = SkipConfig(
            window_style=defaults.window_style,
            nos_of_window=defaults.nos_of_window,
            window_first_minutes=defaults.window_first_minutes,
            window_last_minutes=defaults.window_last_minutes,
            intro_length=defaults.intro_length,
            intro_start=defaults.intro_start,
            intro_end=defaults.intro_end,
            outro_length=defaults.outro_length,
            outro_start=outro_start,
            outro_end=outro_end
        )

    # ZONE DETECTION
    def is_in_skip_zone(self, _time):
        """
        self.in_intro or self.in_outro True if _time is within Intro or Outro boundaries.
        Add a 1-second buffer to the end to prevent flickering
        """
        cfg = self.active_config
        # Intro zone check
        self.in_intro = cfg.intro_start <= _time <= cfg.intro_end + 1
        # Outro zone check
        self.in_outro = cfg.outro_start <= _time <= cfg.outro_end

        # Determine which zone we are in
        if self.in_intro:
            zone_start = cfg.intro_start
            zone_end = cfg.intro_end
        elif self.in_outro:
            zone_start = cfg.outro_start
            zone_end = cfg.outro_end
        else: return 0, 0
        # Compute zone metrics
        remaining = max(0, zone_end - _time)
        countdown_val = int(remaining)
        return countdown_val

    # MIDDLE ZONE CPU OPTIMIZATION
    def is_middle_zone(self, _time):
        cfg = self.active_config
        if not cfg: return True

        # Before intro → must wake every 1s
        if _time <= cfg.intro_start:
            return False
        # Intro zone → NOT middle
        if cfg.intro_start <= _time <= cfg.intro_end:
            return False
        # Outro zone → NOT middle
        if cfg.outro_start <= _time <= cfg.outro_end:
            return False
        # Near intro end (±3 seconds) → NOT middle
        if cfg.intro_end - 3 <= _time <= cfg.intro_end + 3:
            return False
        # Otherwise → middle zone
        return True

    # MAIN PROGRESS LOOP
    def onPlaybackProgress(self, _time):
        # Wait until Kodi reports a valid duration
        if not self.playback_active: return
        if self.pvr_mode: return
        self._load_skip_options()
        if not self.active_config: return

        # Check if we are in a skip zone
        countdown_val = self.is_in_skip_zone(_time)
        # Intro finished?
        if not self.intro_done and not self.in_intro and _time > self.active_config.intro_end:
            self.intro_done = True
            # logger("Intro finished — intro_done=True")
        # Detect start of outro
        if self.intro_done and self.in_outro and not self.outro_started:
            self.outro_started = True
            self.dialog_show_count = 0  # reset limit for outro
            # logger("Outro started — dialog_show_count reset to 0")
        if self.in_intro or self.in_outro:
            # logger(f"Playback onPlaybackProgress countdown_val: _time: {_time}")
            label = "Skip Recap" if self.in_intro else "Skip Credits"
            # Detect when intro has ended
            # Auto-skip logic
            # if self.addon.getSettingBool('auto_skip') and in_intro:
                # self.auto_skip_timer += 1
                # if self.auto_skip_timer >= 3:
                    # self.perform_skip()
                    # return
                # label += f" ({3 - self.auto_skip_timer}s)"
            # logger(f"send to _show_ui: label : {label} ~ {self.dialog_show_count} :: {countdown_val}")
            self._show_ui(f"{label} ~ {self.dialog_show_count}", countdown_val)
            # OPTIONAL: Auto-hide after 10 seconds if user ignores it
            # if self.show_counter > 10:
                # self._hide_ui()
        else: self._hide_ui()

    # DIALOG LIFECYCLE
    def _ensure_dialog(self):
        if not self.playback_active: return

        if self.dialog is None:
            # logger(f"Creating new SkipDialog instance self.dialog_show_count: {self.dialog_show_count} self.dialog_show_limit: {self.dialog_show_limit}")
            # Check limit BEFORE creating
            if self.dialog_show_count >= self.dialog_show_limit: return  # Do not show anymore
            self.dialog = SkipDialog('skipmulti.xml', self.addon.getAddonInfo('path'), 'default', "1080i", player=self)
            self.dialog.show()
            self.is_showing_ui = True
            # Count this as a new instance
            self.dialog_show_count += 1
            self._last_label = None
            self._last_number = None
            self._last_style = None
        elif not self.is_showing_ui:
            self.dialog.show()
            self.is_showing_ui = True
            self.dialog_show_count += 1

    def _show_ui(self, label, number):
        # logger(f"_show_ui self.dialog_show_count: {self.dialog_show_count} self.dialog_show_limit: {self.dialog_show_limit}")
        if not self.playback_active: return
        if self.dialog_show_count >= self.dialog_show_limit + 1:
            self._force_close_dialog()
            return
        self._ensure_dialog()
        dlg = self.dialog
        if not dlg: return

        if label != self._last_label:
            dlg.setProperty('skip_title', label)
            self._last_label = label

        if number != self._last_number:
            dlg.setProperty('CountdownNumber', str(number))
            self._last_number = number

        style = '2' if self.in_outro else str(self.active_config.window_style)
        if style != self._last_style:
            dlg.setProperty('window_style', style)
            self._last_style = style

    def _hide_ui(self):
        """Hides the UI but keeps the object in memory for reuse."""
        if self.is_showing_ui:
            self.is_showing_ui = False
            #self.auto_skip_timer = 0
            # We keep dialog instance; it will be reused by _ensure_dialog()
            if self.dialog:
                try: self.dialog.close()  # hide dialog
                except: pass

    def _force_close_dialog(self):
        if self.dialog:
            try: self.dialog.close()
            except: pass
            self.dialog = None
        self.is_showing_ui = False

    def on_dialog_closed(self):
        # Called from SkipDialog.onWindowClosed()
        self.is_showing_ui = False
        self.dialog = None

    # SKIP ACTION
    def perform_skip(self):
        if not self.playback_active:
            logger("perform_skip aborted — no video playing")
            return
        if not self.active_config: return

        # If in intro, jump to end of intro. If in outro, jump to end.
        if self.in_intro:
            target = (self.active_config.intro_length + self.active_config.intro_start) - self.getTime()
            if target < 0: target = 20
            target = self.getTime() + target
        elif self.in_outro:
            try:
                if self.dialog_show_count >= (self.dialog_show_limit): target = max(self.getTotalTime() - 1, 0)
                else: target = self.getTime() + self.active_config.outro_length
            except: return
        else: return
        logger(f"perform_skip → for self.in_intro: {self.in_intro} :: {self.active_config.intro_end} or self.in_outro: {self.in_outro} seeking to {target} self.dialog_show_count: {self.dialog_show_count} self.total_time: {self.total_time}")

        self.seekTime(target)
        self._hide_ui()

# SERVICE LOOP (run)
def run():
    # 1. Initialize the monitor and player classes
    monitor = Monitor()
    player = PlayerDialogs()
    logger("Service: Started background monitor")

    # 2. Keep the script running as long as Kodi is open
    while not monitor.abortRequested():
        # 1. Check if a video is actually playing
        if player.isPlayingVideo():
            # If PVR mode is active → sleep and skip everything
            if player.pvr_mode:
                if monitor.waitForAbort(3):
                    break
                continue
            try:
                # 2. Get current time and trigger the callback manually
                curr_time = player.getTime()
                if curr_time != 0:
                    player.playback_active = True
                    # 3 check If we are in the middle of the video → sleep longer
                    if player.active_config and player.is_middle_zone(curr_time):
                        # Far from outro? Sleep even longer
                        if curr_time < player.active_config.outro_start - 120:
                            if monitor.waitForAbort(30):
                                break
                        else:
                            if monitor.waitForAbort(10):
                                break
                        continue

                    # Otherwise (intro/outro) → normal 1-second updates
                    player.onPlaybackProgress(curr_time)
            except Exception:
                logger(f'run Error: {print_exc()}')
        else: player.playback_active = False
        # 3. Wait 1 second before checking again # This prevents the CPU from spiking
        if monitor.waitForAbort(1):
            break

    _flush_logs()
    logger("Service: Stopped")
