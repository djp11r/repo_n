# -*- coding: utf-8 -*-

from resources.lib.new_service import run

if __name__ == '__main__':
    run()
