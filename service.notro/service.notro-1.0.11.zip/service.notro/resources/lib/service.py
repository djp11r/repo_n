# -*- coding: utf-8 -*-

import os

from resources.lib.kodiutils import get_setting, make_settings_dict, homeWindow, logger, clean_title
from resources.lib.notroparser import NotroParser
from resources.lib.skip import Skip

import xbmc
import xbmcgui
import xbmcaddon

ADDON = xbmcaddon.Addon()
DIALOG = xbmcgui.Dialog()
window = homeWindow


class PlayerDialogs(xbmc.Player):

    def __init__(self):
        super(PlayerDialogs, self).__init__()
        logger("NotroPlayer init...")
        self._initialState()

    def onAVStarted(self):
        if self.isPlayingVideo() and not self.playing:
            # logger("Kodi actually started playing a media item/displaying frames")
            self.playing = True
            self.Title = xbmc.getInfoLabel("VideoPlayer.TVShowTitle")
            if not self.Title: self.Title = xbmc.getInfoLabel("VideoPlayer.Title")
            # logger("Kodi xbmc.getInfoLabel Player.Filenameandpath: %s" % xbmc.getInfoLabel("Player.Filenameandpath"))
            # if '.m3u8' in xbmc.getInfoLabel("Player.Filenameandpath"): return
            logger("Kodi actually started playing Title: %s" % self.Title)
            self.Title = clean_title(self.Title)
            self.desplay_time = get_setting('default.duration')
            self.skip_option = NotroParser(self.Title, logger)
            # logger("self.skip_option.data: %s" % self.skip_option.data)
            self.intro_start_time = 5 + int(self.skip_option.data.get('start'))
            self.intro_end_time = int(self.desplay_time) + int(self.skip_option.data.get('skip'))
            self.outro_start_time = self.getTotalTime() - int(self.desplay_time)
            self.outro_end_time = self.getTotalTime() - 1
            # logger("self.intro_start_time : %s, self.intro_end_time : %s, self.outro_start_time : %s, self.outro_end_time: %s" % (self.intro_start_time, self.intro_end_time, self.outro_start_time, self.outro_end_time))
            # self.intro_start_time, self.intro_end_time = self.skip_option.intro
            # self.outro_start_time, self.outro_end_time = self.skip_option.outro

    def onPlayBackEnded(self):
        # logger("Playback has ended")
        self._initialState()

    def onPlayBackStopped(self):
        if not self.isPlayingVideo() and self.playing:
            # logger("Playback has been stopped")
            self._initialState()

    def _initialState(self):
        self.playing = False
        self.skip_option = None
        self.Title = None
        self.intro_start_time = None
        self.intro_end_time = None
        self.outro_start_time = None
        self.outro_end_time = None

    @property
    def hasIntro(self):
        currentTime = self.getTime()
        if not currentTime: currentTime = 0
        # logger("intro_start_time: %s self.intro_end_time : %s " % (self.intro_start_time, self.intro_end_time))
        return self.intro_start_time < currentTime < self.intro_end_time

    def skipIntro(self):
        skipTime = self.getTime() + int(self.skip_option.data.get('skip'))
        # logger("skipTime: %s" % skipTime)
        self.seekTime(skipTime)

    @property
    def hasOutro(self):
        currentTime = self.getTime()
        if not currentTime: currentTime = 0
        self.outro_end_time = self.getTotalTime() - 5
        self.outro_start_time = self.outro_end_time - 180
        return self.outro_start_time < currentTime < self.outro_end_time

    def skipOutro(self):
        try:
            # xbmc.executebuiltin('PlayerControl(BigSkipForward)') # skip to end of current
            self.seekTime(self.outro_end_time) # OR use this line
        except Exception as exc:
            logger('Failed to seekTime(): %s' % exc)
            self.stop() # if skip to end error then stop player


class NotroMonitor(xbmc.Monitor):

    def __init__(self):
        logger("NotroMonitor init...")

    def onSettingsChanged(self):
        logger("You can use this event to change any variables that depend on the addon settings")
        window.clearProperty('notro_settings')
        xbmc.sleep(50)
        refreshed = make_settings_dict()


def run():

    logger("Notro service started...")

    # Instantiate player event listener
    player = PlayerDialogs()

    # Instantiate your monitor
    monitor = NotroMonitor()

    #Instantiate the button
    Dialog_type = get_setting('skip.dialog')
    if Dialog_type == "Regular": buttonskip = Skip("script-dialog.xml", ADDON.getAddonInfo('path'), "default", "1080i", player=player)
    else: buttonskip = Skip("Skip.xml", ADDON.getAddonInfo('path'), "default", "1080i", player=player)
    while not monitor.abortRequested():
        # Sleep/wait for abort for 1 second
        if monitor.waitForAbort(1):
            # Abort was requested while waiting. We should exit
            break

        if player.isPlayingVideo() and player.skip_option:
            service = player.skip_option.data.get('service', False)
            # logger("player.skip_option.data.get(service): %s" % service)
            if service and player.hasIntro:
                # logger("player.hasIntro: %s" % player.hasIntro)
                buttonskip.show_with_callback(player.skipIntro)
                # buttonskip.show_with_callback(player.skipUpdate)
            elif service and player.hasOutro:
                # logger("player.hasOutro: %s" % player.hasOutro)
                buttonskip.show_with_callback(player.skipOutro, False)
                # buttonskip.show_with_callback(player.skipUpdate)
            else:
                # logger("buttonskip.isButtonVisible: %s" % buttonskip.isButtonVisible)
                if buttonskip.isButtonVisible is True:
                    buttonskip.close()
                    buttonskip.setVisibility()
        else:
            if buttonskip.isButtonVisible is True:
                buttonskip.close()
                buttonskip.setVisibility()
