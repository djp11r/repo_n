# -*- coding: utf-8 -*-

import traceback
import xbmcaddon
from xbmcgui import WindowXMLDialog, Dialog, INPUT_NUMERIC
from resources.lib.kodiutils import logger
from resources.lib.notroparser import enable_show, updateSkip
ADDON = xbmcaddon.Addon()

BACK_ACTIONS = 92
PREVIOUS_MENU = 10


class Skip(WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super(Skip, self).__init__(self, args)
        self.isVisible = False
        self.player = kwargs['player']

    def onInit(self):
        """"""

    def show_with_callback(self, callback, intro=True):
        self.callback = callback
        # logger('Skip self.isButtonVisible: %s' % (self.isButtonVisible))
        if self.isButtonVisible is False:
            self.show()
            self.skip_option = self.player.skip_option.data
            if intro: self.skipLabel = 'SKIP INTRO: %s' % self.skip_option.get('skip', '')
            else: self.skipLabel = 'SKIP EXTRO: %s' % self.skip_option.get('eskip', '')
            # logger('Skip skipLabel: %s' % (self.skipLabel))
            # self.getControl(202).setLabel("Update Skip")
            # self.getControl(210).setLabel("Disable Skip for This Show")
            self.getControl(201).setLabel("%s" % str(self.skipLabel))
            self.setVisibility()

    def onClick(self, controlID):
        # logger('Skip onclick: %s' % (controlID))
        if controlID == 201:
            self.callback()
        elif controlID == 202:
            try:
                self.player.pause()
                updateskip_data(self.skip_option)
                # self.title = self.player.skip_option.data.get('title', '')
                # dialog = Dialog()
                # d = dialog.input('Skip Value Intro (seconds)', type=INPUT_NUMERIC)
                # d2 = 0
                # d2 = dialog.input('Prompt At (seconds)', type=INPUT_NUMERIC)
                # if d2 == '' or d2 is None: d2 = 0
                # d3 = dialog.input('Skip Value EXTRO (seconds)', type=INPUT_NUMERIC)
                # if str(d) != '' and str(d) != '0':
                    # self.player.skip_option.updateSkip(self.title, seconds=str(d), eseconds=str(d3), start=str(d2), service=True)
                self.player.pause()
            except Exception as ex: logger('onClick 202 error : %s' % (ex))
            self.close()
        # elif controlID == 210:
            # try:
                # self.title = self.player.skip_option.data.get('title', '')
                # self.player.skip_option.updateSkip(self.title, service=False)
            # except Exception as ex: logger('onClick 210 error : %s' % (ex))
            # self.close()

    @property
    def isButtonVisible(self):
        return self.isVisible

    def setVisibility(self):
        self.isVisible = not self.isVisible


class UpdateSkip(WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super(UpdateSkip, self).__init__(self, args)
        """"""
        # self.player = kwargs['player']
        self.skip_option = kwargs['skip_option'] # self.player.skip_option.data

    def onInit(self):
        self.show_dialog()


    def show_dialog(self):
        tvshow = self.skip_option.get('title')
        skip = int(self.skip_option.get('skip'))
        start = int(self.skip_option.get('start'))
        eskip = int(self.skip_option.get('eskip'))
        # logger("skip: %s" % skip)
        # self.getControl(101).setLabel(AddonTitle)
        self.getControl(111).setLabel("Title: [COLOR green]%s[/COLOR]" % tvshow)
        if int(self.skip_option.get('service')) == 1: self.getControl(112).setSelected(True)
        else: self.getControl(112).setSelected(False)
        self.setFocus(self.getControl(114))
        self.getControl(113).setLabel("Skip old value   : [COLOR green]%s[/COLOR]" % skip)
        self.getControl(114).setLabel("%s" % skip)
        self.getControl(115).setLabel("Skip start value : [COLOR green]%s[/COLOR]" % start)
        self.getControl(116).setLabel("%s" % start)
        self.getControl(117).setLabel("Exit Skip value  : [COLOR green]%s[/COLOR]" % eskip)
        self.getControl(118).setLabel("%s" % eskip)

    def onClick(self, controlid):
        if controlid == 121:
            try:
                # logger("slider_305: %s" % self.getControl(115).getInt())
                self.skip_option.update({'service': bool(self.getControl(112).isSelected()), 'skip': '%s' % self.getControl(114).getLabel(), 'start': '%s' % self.getControl(116).getLabel(), 'eskip': '%s' % self.getControl(118).getLabel()})
                # logger("spincontrolex_302: %s" % self.getControl(114).getLabel())
                # logger("slider_305: %s" % self.skip_option)
                updateSkip(self.skip_option)
                # logger("radiobutton_301: %s" % self.getControl(301).isSelected())
            except: logger("Error: %s" % (traceback.format_exc()))
            self.close()
        elif controlid in [114, 116, 118]:
            text = self.InputNos()
            if text != None:
                self.getControl(controlid).setLabel('%s' % (str(text)))
        elif controlid == 122:
            enable_show()
            self.close()

    def onAction(self, action):
        if action.getId() in [BACK_ACTIONS, PREVIOUS_MENU]:
            self.close()

    def InputNos(self):
        text = None
        dialog = Dialog()
        text = dialog.input('Value in (seconds)', type=INPUT_NUMERIC)
        return text


def updateskip_data(skip_option=None):
    try:
        # skip_option = {'title': 'Punyashlok Ahilya Bai', 'service': True, 'skip': '50', 'start': '0', 'eskip': '120'}
        fr = UpdateSkip("skipupdate.xml", ADDON.getAddonInfo('path'), skip_option=skip_option)
        fr.doModal()
        del fr
    except:
        logger("Error: %s" % (traceback.format_exc()))
