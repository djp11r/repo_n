# -*- coding: utf-8 -*-
import os
import re

import xbmc
import xbmcaddon
import xbmcgui
import sys
from json import dumps as jsdumps, loads as jsloads

if sys.version_info.major == 2: isPY2 = True
else: isPY2 =False

if isPY2:from xbmc import translatePath
else: from xbmcvfs import translatePath

ADDON = xbmcaddon.Addon()
addonInfo = ADDON.getAddonInfo
profilePath = translatePath(addonInfo('profile'))
if not os.path.exists(profilePath): os.mkdir(profilePath)
skipFile = os.path.join(profilePath, 'skipintro.json')
settingsFile = os.path.join(profilePath, 'settings.xml')
LOGPATH = translatePath('special://logpath/')
log_file = os.path.join(LOGPATH, '%s.log' % 'Infinite')
# read settings
homeWindow = xbmcgui.Window(10000)
# logger = logging.getLogger(__name__)


def clean_title(title):
    if title is None: return
    exctract_date = re.compile(r'(\d{1,2}[th|st|nd|rd]* [Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|August|Sep|September|Oct|October|Nov|November|Dec|December]* \d{2,4})')
    episode_data = re.compile(r'[Ee]pisode.+?(\d+)|[Ee]p (\d+)|[Ee](\d+)|[sS]eason.+?(\d+)|[sS]eason(\d+)|[sS](\d+)|[Cc]hapter (\d+)')
     # ansi_pattern = re.compile(r"(\x9B|\x1B\[)[0-?]*[ -\/]*[@-~]")
    ansi_pattern = re.compile(r'[^\x00-\x7f]')
    color_data = re.compile(r'\[COLOR.+?\].+?\[\/COLOR\]|\(.*?\)+')
    try:
        title = re.sub(color_data, '', title)  # remove date like [COLOR yellow]1x1[/COLOR] OR [COLOR cyan]July 10, 2017[/COLOR] or ( any thing( #)
        title = re.sub(exctract_date, '', title) # remove date like 18th April 2021
        title = re.sub(episode_data, '', title) # remove episod 12 or season 1 etc
        title = re.sub(ansi_pattern, '', title)  # remove ansi_pattern
        title = re.sub(r'&#(\d+);', '', title)
        title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
        title = title.replace('&quot;', '\"').replace('&amp;', '&')
        title = re.sub(r'([:;\-"\',!_.?~$@])', '', title) # remove all characters in bracket
        title = re.sub(r'\<[^>]*\>|\([^)]*\)', '', title) # remove like this <any thing> or (any thing)
        # title = re.sub(r'\([^>]*\)', '', title) # remove in bracket like (any thing) etcx
        # title = re.sub(r'\n|([[].+?[]])|([(].+?[)])|\s(vs|v[.])\s|(:|;|-|"|,|\'|\_|\.|\?)|\(|\)|\[|\]|\{|\}|\s', '', title).lower()
        # title = re.sub(r'\n|([\[({].+?[})\]])|([:;\-"\',!_.?~$@])|\s', '', title)
        title = re.sub(r"\s+", " ", title, flags=re.I) # Removing Multiple Spaces
        return title.strip()
    except: return title


def open_file_wrapper(file, mode='r', encoding='utf-8'):
    """
    use:
    json_path = os.path.join(path, filename)
    with open_file_wrapper(json_path)() as json_result:
        return json.load(json_result)
    """
    if isPY2:
        return lambda: open(file, mode)
    return lambda: open(file, mode, encoding=encoding)


def notification(header, message, time=5000, icon=addonInfo('icon'), sound=True):
    xbmcgui.Dialog().notification(header, message, icon, time, sound)


def show_settings():
    ADDON.openSettings()


def get_setting(id, fallback=None):
    try: settings_dict = jsloads(homeWindow.getProperty('notro_settings'))
    except: settings_dict = make_settings_dict()
    if settings_dict is None: settings_dict = settings_fallback(id)
    value = settings_dict.get(id, '')
    if fallback is None: return value
    if value == '': return fallback
    return value
    # return ADDON.getSetting(setting).strip().decode('utf-8')


def settings_fallback(id):
    return {id: xbmcaddon.Addon().getSetting(id)}


def set_setting(setting, value):
    ADDON.setSetting(setting, str(value))


def get_setting_as_bool(setting):
    return get_setting(setting).lower() == "true"


def get_setting_as_float(setting):
    try:
        return float(get_setting(setting))
    except ValueError:
        return 0


def get_setting_as_int(setting):
    try:
        return int(get_setting_as_float(setting))
    except ValueError:
        return 0


def get_string(string_id):
    return ADDON.getLocalizedString(string_id).encode('utf-8', 'ignore')


def kodi_json_request(params):
    data = jsdumps(params)
    request = xbmc.executeJSONRPC(data)

    try:
        response = jsloads(request)
    except UnicodeDecodeError:
        response = jsloads(request.decode('utf-8', 'ignore'))

    try:
        if 'result' in response:
            return response['result']
        return None
    except KeyError:
        logger("[%s] %s" % (params['method'], response['error']['message']))
        return None


def make_settings_dict(): # service runs upon a setting change
    try:
        import xml.etree.ElementTree as ET
        root = ET.parse(settingsFile).getroot()
        settings_dict = {}
        for item in root:
            dict_item = {}
            setting_id = item.get('id')
            if getKodiVersion() >= 18: setting_value = item.text
            else: setting_value = item.get('value')
            if setting_value is None: setting_value = ''
            dict_item = {setting_id: setting_value}
            settings_dict.update(dict_item)
        homeWindow.setProperty('notro_settings', jsdumps(settings_dict))
        # log('settings_dict = %s' % settings_dict, 2)
        return settings_dict
    except:
        return None


loging = get_setting('debug')


def logger(heading, function=None):
    if loging:
        with open(log_file, 'a') as f:
            line = '###%s###:\n %s' % (heading, function)
            f.write(line.rstrip('\r\n')+'\n')