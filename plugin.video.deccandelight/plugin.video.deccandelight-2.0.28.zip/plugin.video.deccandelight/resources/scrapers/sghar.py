"""
DeccanDelight scraper plugin
Copyright (C) 2016 gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
"""
from resources.lib.base import Scraper
from bs4 import BeautifulSoup, SoupStrainer
from six.moves import urllib_parse
import re
from resources.lib import client


class sghar(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'https://serialghar.me/'
        self.icon = self.ipath + 'sghar.png'
        self.videos = []
        self.list = {'01Star Plus': self.bu + 'category/star-plus/',
                     '02Colors': self.bu + 'category/colors-tv/',
                     '03Zee TV': self.bu + 'category/zee-tv/',
                     '04Sony TV': self.bu + 'category/sony-tv/',
                     '05SAB TV': self.bu + 'category/sab-tv/',
                     '06Star Bharat': self.bu + 'category/star-bharat/',
                     '07Mtv India': self.bu + 'category/mtv-india/',
                     '09And Tv': self.bu + 'category/and-tv/',
                     '10Awards Shows': self.bu + 'category/awards-shows/',
                     '99[COLOR yellow]** Search **[/COLOR]': self.bu + '?s=MMMM7'}

    def get_menu(self):
        return (self.list, 5, self.icon)
        html = client.request(self.bu)
        mlink = SoupStrainer('ul', {'id': 'menu-main-menu'})
        mdiv = BeautifulSoup(html, "html.parser", parse_only=mlink)
        items = mdiv.find_all('li')
        mlist = {}
        ino = 1
        for item in items:
            title = item.find('a').text
            if 'Home' not in title and 'Bigg' not in title:
                mlist.update({'{0:02d}{1}'.format(ino, title): item.find('a').get('href')})
                ino += 1
        mlist.update({'99[COLOR yellow]** Search **[/COLOR]': '{0}?s=MMMM7'.format(self.bu)})
        return (mlist, 5, self.icon)

    def get_second(self, iurl):
        """
        Get the list of shows.
        """
        shows = []
        ch_name = iurl.split('/')[-2]
        # self.log(f'iurl: {iurl}\nch_name: {ch_name}')
        html = client.request(self.bu)
        mlink = SoupStrainer('div', {'class': f'menu-{ch_name}-container'})
        mdiv = BeautifulSoup(html, "html.parser", parse_only=mlink)
        items = mdiv.findAll('li')
        for source in items:
            url = source.find('a')['href']
            title = self.unescape(source.text).strip()
            # self.log(f'title: {title}\nurl: {url}')
            if ch_name in url.lower():
                shows.append((title.strip(), self.icon, url))
        return (shows, 7)

    def get_items(self, iurl):
        episodes = []
        if iurl[-3:] == '?s=':
            search_text = self.get_SearchQuery('Serial Ghar')
            search_text = urllib_parse.quote_plus(search_text)
            iurl += search_text
        html = client.request(iurl)
        mlink = SoupStrainer('article', {'class': 'item-list'})
        mdiv = BeautifulSoup(html, "html.parser", parse_only=mlink)
        # items = mdiv.find_all('div', {'class': 'item_content'})
        for item in mdiv:
            itemurl = item.find('h2', {'class': 'post-box-title'})
            url = itemurl.find('a')['href']
            title = self.unescape(itemurl.text)
            # self.log(f'title: {title.strip()} url: {url}')
            try: icon = item.find('img')['src']
            except: icon = self.icon
            episodes.append((title.strip(), icon, url))

        plink = SoupStrainer('div', {'class': 'pagination'})
        Paginator = BeautifulSoup(html, "html.parser", parse_only=plink)

        if str(Paginator):
            itemurl = Paginator.find('a')
            # self.log(f"next iurl: {iurl.get('href')}")
            nitemurl = itemurl.get('href')
            if itemurl:
                currpg = Paginator.find('span', {'class': 'current'}).text
                title = '(Current Page {0} Next Page: {1})'.format(currpg, itemurl.text)
                episodes.append((title, self.nicon, nitemurl))
        return (episodes, 8)

    def get_videos(self, iurl):
        def process_item(item):
            vidlink = item.get('href')
            vidtxt = self.unescape(item.text)
            vidtxt = re.search(r'(Part\s*\d*)', vidtxt)
            vidtxt = vidtxt.group(1) if vidtxt else ''
            self.resolve_media(vidlink, self.videos, vidtxt)

        html = client.request(iurl)
        mlink = SoupStrainer('div', {'class': 'entry'})
        videoclass = BeautifulSoup(html, "html.parser", parse_only=mlink)
        itemdiv = videoclass.find('p')
        items = itemdiv.find_all('a')
        if not items:
            itemdiv = videoclass.find_all('p')
            items = [x.find('a') for x in itemdiv if x.find('a')]
        threads = []
        for item in items:
            # self.log(f"items: :: {item}")
            threads.append(self.Thread(process_item, item))

        [i.start() for i in threads]
        [i.join() for i in threads]

        return sorted(self.videos)
