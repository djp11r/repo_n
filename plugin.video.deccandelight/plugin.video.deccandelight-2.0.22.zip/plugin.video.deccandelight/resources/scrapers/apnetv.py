'''
DeccanDelight scraper plugin
Copyright (C) 2018 gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib.base import Scraper
from bs4 import BeautifulSoup, SoupStrainer
from six.moves import html_parser
import re
from resources.lib import client
from kodi_six import xbmcgui


class apnetv(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.videos = []
        self.bu = 'https://apnetv.me/Hindi-Serials'
        self.icon = self.ipath + 'apnetv.png'
        self.list = {'01Sony-TV': 'Sony-TV',
                     '02Colors': 'Colors',
                     '03Sab-TV': 'Sab-TV',
                     '04StarPlus': 'StarPlus',
                     '05Zee-TV': 'Zee-TV'}

    def get_menu(self):
        return (self.list, 5, self.icon)

    def get_second(self, iurl):
        """
        Get the list of shows.
        :return: list
        """
        shows = []
        h = html_parser.HTMLParser()

        html = client.request(url=self.bu, headers=self.hdr)
        # mlink = SoupStrainer('div', {'id': iurl})
        mlink = SoupStrainer('li', {'class': re.compile('|active')})
        # self.log(f'apnetv >>> get_second iurl: mlink : {mlink}')
        mdiv = BeautifulSoup(html, "html.parser", parse_only=mlink)
        # self.log(f'apnetv >>> get_second mdiv : {mdiv}')
        for item in mdiv:
            if iurl in str(item):
                mlink = SoupStrainer('ul', {'class': 'link-list'})
                mdiv = BeautifulSoup(html, "html.parser", parse_only=mlink)
                items = item.find_all('li')
                for item in items:
                    title = h.unescape(item.find('a').text)
                    url = item.find('a').get('href')
                    url = url.replace('https://apnetv.me/Hindi-Serial/', 'https://apnetv.me/Hindi-Serial/episode/')
                    shows.append((title, self.icon, url))

        return (shows, 7)

    def get_items(self, iurl):
        # self.log('apnetv >>> iurl : {}'.format(iurl))
        episodes = []
        html = client.request(url=iurl, headers=self.hdr)
        mlink = SoupStrainer('div', {'class': 'episodes'})
        mdiv = BeautifulSoup(html, "html.parser", parse_only=mlink)
        # items = mdiv.find_all('div', {'class': re.compile('^s-epidode')})
        items = mdiv.find_all('li')
        for item in items:
            # self.log(f'apnetv >>> item : {item}')
            try:
                title = item.find('div', {'class': 'date'}).text
                try: thumb = item.find('img')['src']
                except: thumb = self.icon
                # url = item.a['href']
                url = item.find('a')['href']
                episodes.append((title, thumb, url))
            except:
                pass

        plink = SoupStrainer('div', {'class': 'pagination_btns'})
        # self.log(f'apnetv >>> html : {html}')
        Paginator = BeautifulSoup(html, "html.parser", parse_only=plink)
        # self.log(f'apnetv >>> Paginator : {Paginator}')
        if 'Next' in str(Paginator):
            nlinks = Paginator.find_all('a', {'class': 'prev_next_btns'})
            iurl = nlinks[-2].get('href')
            # self.log(f'apnetv >>> iurl : {iurl}')
            currpg = Paginator.find('a', {'class': re.compile('^page_active')}).text
            lastpg = nlinks[-1].get('href').split('/')[-1]
            # self.log(f'apnetv >>> lastpg : {lastpg}')
            title = 'Next Page.. (Currently in Page {0} of {1})'.format(currpg, lastpg)
            episodes.append((title, self.nicon, iurl))

        return (episodes, 8)


    def get_videos(self, iurl):
        def process_item(item):
            vidurl = item.find('a')['href'] + '|Referer=' + self.bu
            try:
                vidtxt = self.unescape(item.text)
                vidtxt = re.search(r'(\d.*)', vidtxt)
                vidtxt = vidtxt.group(1) if vidtxt else ''
            except: vidtxt = ''
            self.resolve_media(vidurl, self.videos, vidtxt)
        # self.log(f'apnetv >>> iurl : {iurl}')
        html = client.request(url=iurl, headers=self.hdr)
        mlink = SoupStrainer('div', {'class': 'bottom_episode_list'})
        mdiv = BeautifulSoup(html, "html.parser", parse_only=mlink)
        # self.log(f'apnetv >>> total: {len(mdiv)} mdiv : {mdiv}')
        links = mdiv.find_all('li')
        # self.log(f'apnetv >>> total: {len(links)} links : {links}')

        threads = []
        for link in links:
            threads.append(self.Thread(process_item, link))
        [i.start() for i in threads]
        [i.join() for i in threads]
        return sorted(self.videos)
