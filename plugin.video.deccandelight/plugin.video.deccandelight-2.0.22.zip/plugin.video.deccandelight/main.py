"""
    Deccan Delight Kodi Addon
    Copyright (C) 2016 gujal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from sys import argv
from resources.lib.router import routing
# from modules.kodi_utils import logger
# logger(f'repr(argv): {repr(argv)}')
# logger(f'repr(argv[2]): {repr(argv[2])}')
routing(argv[2])

# import sys
# from resources.lib import deccandelight

# if __name__ == '__main__':
    # # Call the router function and pass the plugin call parameters to it.
    # # We use string slicing to trim the leading '?' from the plugin call paramstring
    # deccandelight.router(sys.argv[2][1:])
