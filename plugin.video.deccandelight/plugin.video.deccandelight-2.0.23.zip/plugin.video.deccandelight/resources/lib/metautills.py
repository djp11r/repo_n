
import re

from resources.lib import access
from metahandler import metahandlers

metaget = metahandlers.MetaData(tmdb_api_key=access.tk, omdb_api_key=access.ok)

def get_meta(title):
    year = ''
    name = title
    r = re.search(r'[([](\d+)[)\]]', name)
    if r:
        year = r.group(1)
    name = re.sub(r"[([].+", "", name).strip()
    meta = metaget.get_meta('movie', name=name, year=year)
    if meta.get('tmdb_id'):
        meta.pop('tmdb_id')
        if meta.get('imdb_id'):
            meta.update({'imdbnumber': meta.get('imdb_id')})
        if not meta.get('trailer') and meta.get('imdb_id'):
            meta.update({
                'trailer': 'plugin://plugin.video.imdb.trailers/?action=play_id&imdb={0}'.format(meta.get('imdb_id'))
            })
        meta.pop('imdb_id')
        meta.pop('thumb_url')
        if 'imgs_prepacked' in meta.keys():
            meta.pop('imgs_prepacked')
        meta.pop('trailer_url')
    return meta