"""
DeccanDelight scraper plugin
Copyright (C) 2016 gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
"""
import re

from bs4 import BeautifulSoup, SoupStrainer
from resources.lib import client
from resources.lib.base import Scraper
from six.moves import urllib_parse


class desit(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        bu = self.settings('u_desit')
        self.bu = f'{bu}/'
        self.icon = f'{self.ipath}desit.png'
        self.videos = []
        self.list = {
            '01Star Plus': f'{self.bu}star-plus/',
            '02Colors': f'{self.bu}colors-tv/',
            '03Zee TV': f'{self.bu}zee-tv/',
            '04Sony TV': f'{self.bu}sony-tv/',
            '05SAB TV': f'{self.bu}sab-tv/',
            '99[COLOR yellow]** Search **[/COLOR]': f'{self.bu}?s=MMMM7',
        }

    def get_menu(self):
        # return (self.list, 5, self.icon)
        html = client.request(self.bu)
        mlink = SoupStrainer('li', {'id': re.compile('menu-item')})
        items = BeautifulSoup(html, "html.parser", parse_only=mlink)
        mlist = {
            f'{ino:02d}{item.text}': item.text
            for ino, item in enumerate(items, start=1)
        }
        mlist['99[COLOR yellow]** Search **[/COLOR]'] = f'{self.bu}?s=MMMM7'
        return (mlist, 5, self.icon)

    def get_second(self, iurl):
        """
        Get the list of shows.
        """
        shows = []

        html = client.request(self.bu)
        mlink = SoupStrainer('div', {'class': 'vc_column-inner'})
        mdiv = BeautifulSoup(html, "html.parser", parse_only=mlink)
        sources = mdiv.find_all('div', {'class': 'td-fix-index'})
        for source in sources:
            if source.text != '\n':
                if source.strong.text.lower() == iurl.lower():
                    items = source.find_all('li')
                    thumb = self.bu[:-1] + source.find('img')['src']
                    for item in items:
                        title = self.unescape(item.text)
                        url = item.find('a')['href']
                        if 'completed shows' not in title.lower():
                            shows.append((title, thumb, url))
        return (shows, 7)

    def get_items(self, iurl):
        episodes = []
        if iurl[-3:] == '?s=':
            search_text = self.get_SearchQuery('Desi Tashan')
            search_text = urllib_parse.quote_plus(search_text)
            iurl += search_text

        html = client.request(iurl)
        mlink = SoupStrainer('div', {'class': 'td-ss-main-content'})
        mdiv = BeautifulSoup(html, "html.parser", parse_only=mlink)
        items = mdiv.find_all('div', {'class': 'td-block-row'})
        for item in items:
            title = self.unescape(item.h3.text)
            if ' online' in title.lower():
                title = self.clean_title(title)
                url = item.h3.find('a')['href']
                episodes.append((title, self.icon, url))

        plink = SoupStrainer('div', {'class': re.compile('^page-nav')})
        Paginator = BeautifulSoup(html, "html.parser", parse_only=plink)
        try:
            currpg = int(Paginator.find('span', {'class': 'current'}).text)
            ldiv = Paginator.find('a', {'class': 'last'})
            if ldiv:
                lastpg = int(ldiv.text)
            else:
                lastpg = int(Paginator.find_all('a', {'class': 'page'})[-1].text)
            if currpg < lastpg:
                iurl = Paginator.find('a', {'title': str(currpg + 1)}).get('href')
                title = 'Next Page.. (Currently in Page {0} of {1})'.format(currpg, lastpg)
                episodes.append((title, self.nicon, iurl))
        except:
            import traceback
            traceback.print_exc()
            pass

        return (episodes, 8)

    def get_videos(self, iurl):
        def process_item(item):
            vid_link = item.get('href')
            vidtxt = self.unescape(item.text)
            vidtxt = re.search(r'(Part\s*\d*)', vidtxt)
            vidtxt = vidtxt.group(1) if vidtxt else ''
            self.resolve_media(vid_link, self.videos, vidtxt)

        html = client.request(iurl)
        mlink = SoupStrainer('center')
        videoclass = BeautifulSoup(html, "html.parser", parse_only=mlink)
        items = videoclass.find_all('a', {'class': None})
        threads = []
        for item in items:
            threads.append(self.Thread(process_item, item))

        [i.start() for i in threads]
        [i.join() for i in threads]

        return sorted(self.videos)
