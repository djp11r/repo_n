"""
Base deccandelight Scraper class
Copyright (C) 2016 Gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
"""


import base64
import json
import re
import threading
from traceback import print_exc

import six
from bs4 import BeautifulSoup, SoupStrainer
from resources.lib import client, control, jsunpack, unjuice, unjuice2
from six.moves import urllib_parse
from kodi_six import xbmcvfs

from resources.lib.control import PY2, get_setting, TRANSLATEPATH, _ppath, log, keyboard, pathExists, check_hosted_media

if PY2:
    import HTMLParser
    _html_parser = HTMLParser.HTMLParser()
else:
    import html
    _html_parser = html



class Scraper(object):

    def __init__(self):
        self.ipath = control._ipath
        self.hdr = control.mozhdr
        self.dhdr = control.droidhdr
        self.jhdr = control.jiohdr
        self.ihdr = control.ioshdr
        self.chdr = control.chromehdr
        self.PY2 = control.PY2
        self.parser = _html_parser
        self.settings = get_setting
        self.adult = get_setting('adult') == 'true'
        self.mirror = get_setting('mirror') == 'true'
        self.nicon = f'{self.ipath}next.png'
        self.hmf = check_hosted_media
        self.log = log

    class Thread(threading.Thread):
        def __init__(self, target, *args):
            threading.Thread.__init__(self)
            self._target = target
            self._args = args

        def run(self):
            self._target(*self._args)

        def terminate(self):
            pass

    def get_nicon(self):
        return self.nicon

    def store(self, ftext, fname):
        fpath = TRANSLATEPATH(_ppath) + fname
        if self.PY2:
            with open(fpath, 'w') as f:
                f.write(ftext)
        else:
            with open(fpath, 'w', encoding='utf-8') as f:
                f.write(ftext)

    def retrieve(self, fname):
        fpath = TRANSLATEPATH(_ppath) + fname
        if pathExists(fpath):
            if self.PY2:
                with open(fpath) as f:
                    ftext = f.readlines()
            else:
                with open(fpath, encoding='utf-8') as f:
                    ftext = f.readlines()
            return '\n'.join(ftext)
        else:
            return None

    def get_SearchQuery(self, sitename):
        keyboard = keyboard()
        keyboard.setHeading(f'Search {sitename}')
        keyboard.doModal()
        if keyboard.isConfirmed():
            return keyboard.getText()
        return

    def get_vidhost(self, url):
        """
        Trim the url to get the video hoster
        :return vidhost
        """
        parts = url.split('/')[2].split('.')
        return f'{parts[len(parts) - 2]}.{parts[len(parts) - 1]}'

    def getVideoID(self, url):
        try: return re.compile('(id|url|v|si|sin|sim|data-config|file|dm|wat|vid)=(.+?)##').findall(f'{url}##')[0][1]
        except: return

    def get_mod_url(self, url):
        url_id = self.getVideoID(url)
        if not url_id: return
        if 'vkprime.php' in url: return f'http://vkprime.com/embed-{url_id}.html'
        elif 'vkspeed.php' in url: return f'http://vkspeed.com/embed-{url_id}.html'
        elif 'speed.php' in url: return f'http://vkspeed.com/embed-{url_id}-600x380.html'

    def apne_twostop(self, url, headers):
        headers.update(self.hdr)
        # url = url.replace('www.hindistoponline.com', 'hindigostop.com')
        html = client.request(url, headers=headers)
        try:
            urltopost = re.search(r'''<form.*action=["'](.+?)["']''', html)
            urltopost = urltopost[1]
            inputNameValue = re.compile(r'''input.*?name=["'](.+?)["'].+?value=["'](.+?)["']''', re.M)
            formFields = inputNameValue.findall(html)
            postFields = {
                field[0].encode("ascii"): field[1].encode("ascii")
                for field in formFields
            }
            self.log(f'0 postFields: {postFields}')
            html = client.request(urltopost, post=postFields, headers=headers)
            return html
        except Exception as e:
            self.log(f'apne_twostop Error: {e} traceback: {print_exc()}', 'error')
            return

    def refresh_redirect(self, url, headers):
        refresh = True
        html = ''
        refresh_retry = 0
        while refresh:
            r = client.request(url, headers=headers, output='extended')
            html = r[0]
            response_headers = r[2]
            if response_headers.get('Refresh'): url = response_headers.get('Refresh').split(' ')[-1]
            elif 'http-equiv="refresh"' in html: url = _html_parser.unescape(re.findall(r'http-equiv="refresh".+?url=([^"]+)', html)[0])
            else: refresh = False
        return url, str(html)

    def form_action(self, url, headers, bhtml):
        try:
            if r := re.findall(r'''<form.+?action="([^"]+)''', bhtml, re.DOTALL):
                purl = r[-1]
                headers.update({'Referer': url, 'Origin': urllib_parse.urljoin(url, '/')[:-1]})
                pd = (dict(r1) if (r1 := re.findall(r"type='hidden'\s*name='([^']+)'\s*value='([^']+)", bhtml,)) else ' ')
                bhtml2 = client.request(purl, post=pd, headers=headers)
                s = re.findall(r'''<iframe.+?src=['"]([^"']+)''', bhtml2, re.I)
                if s: return s
                r = re.findall(r'''<form.+?action="([^"]+)''', bhtml2, re.DOTALL)
                if r:
                    purl = r[-1]
                    headers.update({'Referer': url, 'Origin': urllib_parse.urljoin(url, '/')[:-1]})
                    r1 = re.findall(r"type='hidden'\s*name='([^']+)'\s*value='([^']+)", bhtml2)
                    if r1: pd = {x: y for x, y in r1}
                    else: pd = ' '
                    ehtml = client.request(purl, post=pd, headers=headers)
                    s = re.findall(r'''<iframe.+?src=['"]([^"']+)''', ehtml, re.I)
                    if s: return s
                    else: self.log(f'form_action no purl: {purl} ehtml\n{ehtml}')
            else:
                s = re.findall(r'''<iframe.+?src=['"]([^"']+)''', bhtml, re.DOTALL)
                if s: return s
                else: self.log(f'form_action no purl: {url} bhtml2\n{bhtml}')
        except Exception as e:
            self.log(f'form_action Error: {e} traceback: {print_exc()}', 'error')
            return

    def resolve_media(self, url, videos, vidtxt=''):
        non_str_list = ['olangal.', 'desihome.', 'thiruttuvcd', '.filmlinks4u', '#', '/t.me/',
                        'cineview', 'bollyheaven', 'videolinkz', 'moviefk.co', 'goo.gl', '/ads/',
                        'imdb.', 'mgid.', 'atemda.', 'movierulz.ht', 'facebook.', 'twitter.',
                        'm2pub', 'abcmalayalam', 'india4movie.co', 'embedupload.', 'bit.ly',
                        'tamilraja.', 'multiup.', 'filesupload.', 'fileorbs.', 'tamil.ws',
                        'insurance-donate.', '.blogspot.', 'yodesi.net', 'desi-tashan.',
                        'yomasti.co/ads', 'ads.yodesi', 'mylifeads.', 'yaartv.', '/cdn-cgi/'
                        'steepto.', '/movierulztv', '/email-protection', 'oneload.xyz', 'about:',
                        'google.com', 'whatsapp.com', 'linkedin.com']

        dhoolembed = ['thiraione.com', 'thiraitwo.com', 'thiraithree.com', 'thiraifour.com',
                      'thiraifive.com', 'thiraisix.com', 'tamilalpha.com', 'tamilbeta.com',
                      'tamilbliss.com', 'thirailight.com', 'malarnaal.com']

        apneembed = ['newstalks.co', 'newstrendz.co', 'newscurrent.co', 'newsdeskroom.co',
                     'newsapne.co', 'newshook.co', 'newsbaba.co', 'articlesnewz.com',
                     'articlesnew.com', 'webnewsarticles.com', 'htnews.me']

        embed_list = ['cineview', 'bollyheaven', 'videolinkz', 'vidzcode', 'escr.',
                      'embedzone', 'embedsr', 'fullmovie-hd', 'links4.pw', 'esr.',
                      'embedscr', 'embedrip', 'movembed', 'power4link.us', 'adly.biz',
                      'watchmoviesonline4u', 'nobuffer.info', 'yomasti.co', 'hd-rulez.',
                      'techking.me', 'onlinemoviesworld.xyz', 'cinebix.com', 'vids.xyz',
                      'desihome.', 'loan-', 'filmshowonline.', 'hinditwostop.', 'media.php',
                      'hindistoponline', 'telly-news.', 'tellytimes.', 'tellynews.', 'tvcine.',
                      'business-', 'businessvoip.', 'toptencar.', 'serialinsurance.',
                      'youpdates', 'loanadvisor.', 'tamilray.', 'embedrip.', 'xpressvids.',
                      'beststopapne.', 'bestinforoom.', '?trembed=', 'tamilserene.',
                      'tvnation.', 'techking.', 'etcscrs.', 'etcsr1.', 'etcrips.', 'etcsrs.',
                      'tvpost.cc', 'tellygossips.', 'tvarticles.', 'insurancehubportal.',
                      'directlinktx.', 'filmstream2x.com', 'watchlinksinfo.com',
                      'videoemx2.com', 'movierulz.io', 'coinztechnews.', 'thegadgetsreviewer.']

        go_cloc_list = ['go.clockks.com', 'go.tellynewsarticles.com', 'go.articlewebnews.com', 'go.newsdeskroom.co']
        headers = {}
        self.log(f'>>>> resolve_media In url: {url}')
        if re.search(r'facebook|twitter|pinterest|protection|tumblr|reddit', str(url), re.IGNORECASE): return
        if '|' in url:
            url, hdrs = url.split('|')
            hitems = hdrs.split('&')
            for hitem in hitems:
                hdr, value = hitem.split('=')
                headers.update({hdr: value})

        if url.startswith('magnet:') and self.hmf(url):
            vidhost = '[COLOR red]Magnet[/COLOR]'
            r = re.findall(r'([\d\.\s]+\d(?:p|mb|gb))', url.replace('%20', ' '), re.I)
            if r:
                vidhost = '{0} [COLOR gold]{1}[/COLOR]'.format(vidhost, ' | '.join(r))
            if vidtxt != '':
                vidhost += ' | %s' % vidtxt
            if (vidhost, url) not in videos:
                videos.append((vidhost, url))
        if not url.startswith('http'): return
        elif 'xdownex.xyz/' in url:
            headers.update(self.hdr)
            ehtml = client.request(url, headers=headers)
            s = re.findall(r'''<strong.+\n<a\s*href="([^"]+)''', ehtml, re.IGNORECASE)
            if s:
                for surl in s:
                    if check_hosted_media(surl):
                        vidhost = self.get_vidhost(surl)
                        if vidtxt != '':
                            vidhost += ' | %s' % vidtxt
                        if (vidhost, surl) not in videos:
                            videos.append((vidhost, surl))
                    else:
                        self.log(f'ResolveUrl cannot resolve 1 surl: {surl}')

        elif 'streamnetu.xyz/' in url:
            html = client.request(url, headers=self.hdr)
            mlink = SoupStrainer('div', {'class': re.compile('^entry-content')})
            videoclass = BeautifulSoup(html, "html.parser", parse_only=mlink)
            links = videoclass.find_all('a')
            for link in links:
                surl = link.get('href')
                if check_hosted_media(surl):
                    vidhost = self.get_vidhost(surl)
                    if vidtxt != '':
                        vidhost += ' | %s' % vidtxt
                    if (vidhost, surl) not in videos:
                        videos.append((vidhost, surl))
                else:
                    self.log(f'ResolveUrl cannot resolve 2 : {surl}')

        elif 'okmalayalam.' in url:
            mid = url.split('/')[-1]
            params = {'data': mid, 'do': 'getVideo'}
            data = {'hash': mid, 'r': ''}
            jd = client.request(
                'https://v.okmalayalam.org/player/index.php',
                XHR=True, referer=url, post=data, params=params)
            if jd:
                jd = json.loads(jd)
                # surl = jd.get('videoSource')
                surl = jd.get('securedLink')
                vidhost = self.get_vidhost(surl)
                if vidtxt != '':
                    vidhost += ' | %s' % vidtxt
                if (vidhost, surl) not in videos:
                    videos.append((vidhost, surl))
            else:
                self.log(f'Cannot resolve: {url}')

        elif 'watchlinkx.xyz/' in url:
            html = client.request(url, headers=self.hdr)
            r = re.search(r'class="main-button[^>]+?href="([^"]+)', html)
            if r:
                surl = r.group(1)
                if check_hosted_media(surl):
                    vidhost = self.get_vidhost(surl)
                    if vidtxt != '':
                        vidhost += ' | %s' % vidtxt
                    if (vidhost, surl) not in videos:
                        videos.append((vidhost, surl))
                else:
                    self.log(f'ResolveUrl cannot resolve 3 surl: {surl}')

        elif 'filelinkzr.com/' in url:
            html = client.request(url, headers=self.hdr)
            r = re.search(r'<a\s*class="mb-ton\s*ndton"\s+href="([^"]+)', html)
            if r:
                surl = r.group(1)
                surl = re.sub(r'\s', '', surl)
                if 'videoemx2.com/' in surl:
                    html = client.request(surl, headers=self.hdr)
                    r = re.search(r'<iframe.+?src="([^"]+)', html)
                    if r:
                        surl = r.group(1)
                if check_hosted_media(surl):
                    vidhost = self.get_vidhost(surl)
                    if vidtxt != '':
                        vidhost += ' | %s' % vidtxt
                    if (vidhost, surl) not in videos:
                        videos.append((vidhost, surl))
                else:
                    self.log('ResolveUrl cannot resolve 3a : {}'.format(surl), 'info')

        elif 'filmshowonline.net/media/' in url:
            try:
                headers.update(self.hdr)
                r = client.request(url, headers=headers, output='extended')
                clink = r[0]
                cookie = r[4]
                eurl = re.findall(r"var\s*height.+?url:\s*'([^']+)", clink, re.DOTALL)[0]
                if not eurl.startswith('http'):
                    eurl = f'https:{eurl}'
                enonce = re.findall(r"var\s*height.+?nonce.+?'([^']+)", clink, re.DOTALL)[0]
                evid = re.findall(r"var\s*height.+?link_id:\s*([^\s]+)", clink, re.DOTALL)[0]
                values = {'echo': 'true',
                          'nonce': enonce,
                          'width': '848',
                          'height': '480',
                          'link_id': evid}
                headers = self.hdr
                headers.update({'Referer': url, 'X-Requested-With': 'XMLHttpRequest'})
                emdiv = client.request(eurl, post=values, headers=headers, cookie=cookie)
                emdiv = json.loads(emdiv).get('embed')
                strurl = re.findall('(http[^"]+)', emdiv)[0]
                if self.hmf(strurl):
                    vidhost = self.get_vidhost(strurl)
                    if vidtxt != '':
                        vidhost += f' | {vidtxt}'
                    if (vidhost, strurl) not in videos:
                        videos.append((vidhost, strurl))
            except:
                pass

        elif 'cdn.jwplayer.com' in url:
            headers.update(self.hdr)
            media_id = url.split('/')[-1].split('-')[0]
            jurl = 'https://content.jwplatform.com/v2/media/{0}'.format(media_id)
            r = client.request(jurl, headers=headers, output='extended')
            if int(r[1]) < 400:
                vlink = json.loads(r[0]).get('playlist')[0].get('sources')[0].get('file')
                if vlink:
                    vidhost = self.get_vidhost(vlink)
                    if (vidhost, vlink) not in videos:
                        videos.append((vidhost, vlink))
                else:
                    self.log(f'Cannot resolve: {url}')

        elif any([x in url for x in dhoolembed]):
            strurl = url.replace('/p/', '/v/') + '.m3u8|Referer={0}&User-Agent=iPad'.format(url)
            vidhost = self.get_vidhost(strurl)
            if vidtxt != '':
                vidhost += ' | %s' % vidtxt
            if (vidhost, strurl) not in videos:
                videos.append((vidhost, strurl))

        elif 'thrfive.io' in url:
            headers.update(self.jhdr)
            headers.update({'Referer': 'https://www.tamildhool.net/'})
            res = client.request(url, headers=headers)
            if unjuice2.test(res):
                res = unjuice2.run(res)
            jd = json.loads(re.findall(r'config\s*=\s*([^;]+)', res)[0])
            headers.update({'Origin': 'https://thrfive.io', 'Referer': 'https://thrfive.io/'})
            m3u8 = client.request(jd.get('sources').get('file'), headers=headers)
            strurl = re.findall(r'http.*', m3u8)[-1] + '|' + urllib_parse.urlencode(headers)
            vidhost = self.get_vidhost(strurl)
            if vidtxt != '':
                vidhost += ' | %s' % vidtxt
            if (vidhost, strurl) not in videos:
                videos.append((vidhost, strurl))

        elif 'justmoviesonline.com' in url:
            headers.update(self.hdr)
            html = client.request(url, headers=headers)
            src = re.search(r"atob\('(.*?)'", html)
            if src:
                src = src.group(1)
                src = base64.b64decode(src).decode('utf-8')
                try:
                    strurl = re.findall('file":"(.*?)"', src)[0]
                    vidhost = 'GVideo'
                    strurl = urllib_parse.quote_plus(strurl)
                    if (vidhost, strurl) not in videos:
                        videos.append((vidhost, strurl))
                except:
                    pass
                try:
                    strurl = re.findall('''source src=["'](.*?)['"]''', src)[0]
                    vidhost = self.get_vidhost(strurl)
                    if (vidhost, strurl) not in videos:
                        videos.append((vidhost, strurl))
                except:
                    pass
            elif '?id=' in url:
                src = eval(re.findall('Loading.+?var.+?=([^;]+)', html, re.DOTALL)[0])
                for item in src:
                    if 'http' in item and 'justmovies' not in item:
                        strurl = item
                strurl += url.split('?id=')[1]
                strurl += '.mp4|User-Agent={}'.format(self.hdr['User-Agent'])
                vidhost = 'GVideo'
                strurl = urllib_parse.quote_plus(strurl)
                if (vidhost, strurl) not in videos:
                    videos.append((vidhost, strurl))

        elif 'videohost.site' in url or 'videohost1.com' in url:
            try:
                headers.update(self.hdr)
                html = client.request(url, headers=headers)
                pdata = eval(re.findall(r'Run\((.*?)\)', html)[0])
                pdata = base64.b64decode(pdata).decode('utf-8')
                linkcode = jsunpack.get_2packed_data(pdata).replace('\\', '')
                sources = json.loads(re.findall(r'sources:(.*?\}\])', linkcode)[0])
                for source in sources:
                    strurl = source['file'] + '|Referer={}'.format(url)
                    vidhost = self.get_vidhost(url) + ' | GVideo | {}'.format(source['label'])
                    strurl = urllib_parse.quote_plus(strurl)
                    if (vidhost, strurl) not in videos:
                        videos.append((vidhost, strurl))
            except:
                pass

        elif 'akamaihd.' in url:
            vidhost = self.get_vidhost(url)
            if (vidhost, url) not in videos:
                videos.append((vidhost, url))

        elif 'videohost2.com' in url:
            headers.update(self.hdr)
            html = client.request(url, headers=headers)

            try:
                pdata = eval(re.findall(r'Loading video.+?(\[.+?\]);', html, re.DOTALL)[0])
                if 'id=' in url:
                    strurl = pdata[7] + url.split('=')[1] + pdata[9]
                else:
                    strurl = pdata[7]
                vidhost = self.get_vidhost(url) + ' | GVideo'
                strurl = urllib_parse.quote_plus(strurl + '|Referer={}'.format(url))
                if (vidhost, strurl) not in videos:
                    videos.append((vidhost, strurl))
            except:
                pass

            try:
                pdata = re.findall(r"atob\('([^']+)", html)[0]
                pdata = base64.b64decode(pdata).decode('utf-8')
                strurl = re.findall(r"source\ssrc='([^']+)", pdata)[0] + '|Referer={}'.format(url)
                vidhost = self.get_vidhost(url)
                strurl = urllib_parse.quote_plus(strurl)
                if (vidhost, strurl) not in videos:
                    videos.append((vidhost, strurl))
            except:
                pass

        elif 'hindistoponline' in url or 'hindigostop' in url:
            headers.update(self.hdr)
            url = url.replace('www.hindistoponline.com', 'hindigostop.com')
            html = client.request(url, headers=headers)

            try:
                strurl = re.findall(r'source:\s*"([^"]+)', html)[0]
                vidhost = self.get_vidhost(strurl)
                strurl = urllib_parse.quote_plus(strurl + '|User-Agent={}&Referer={}'.format(self.mozhdr['User-Agent'], url))
                if (vidhost, strurl) not in videos:
                    videos.append((vidhost, strurl))
            except:
                pass

            try:
                strurl = re.findall('''(?i)<iframe.+?src=["']([^'"]+)''', html)[0]
                if self.hmf(strurl):
                    vidhost = self.get_vidhost(strurl)
                    if (vidhost, strurl) not in videos:
                        videos.append((vidhost, strurl))
                else:
                    self.log(f'ResolveUrl cannot resolve 4: {url}')
            except:
                pass

        elif 'arivakam.' in url:
            headers.update(self.hdr)
            if '$$' in url:
                url, ref = url.split('$$')
                headers.update({'Referer': ref})
            html = client.request(url, headers=headers, verify=False)
            rurl = urllib_parse.urljoin(url, '/')
            strurl = re.search(r'"file":"([^"]+)', html)
            if strurl:
                embedurl = strurl.group(1)
                if 'playallu' in embedurl:
                    vidhost, strurl = self.playallu(embedurl, rurl)
                    if (vidhost, strurl) not in videos:
                        videos.append((vidhost, strurl))
                else:
                    vidhost = self.get_vidhost(embedurl)
                    embedurl += '|Referer={0}'.format(rurl)
                    if (vidhost, embedurl) not in videos:
                        videos.append((vidhost, embedurl))
            else:
                embedurl = re.search(r'<iframe.+?src="([^"]+)', html)
                if embedurl:
                    embedurl = embedurl.group(1)
                    if 'playallu' in embedurl:
                        vidhost, strurl = self.playallu(embedurl, rurl)
                        if (vidhost, strurl) not in videos:
                            videos.append((vidhost, strurl))
                    else:
                        vidhost = self.get_vidhost(embedurl)
                        embedurl += '|Referer={0}'.format(rurl)
                        if (vidhost, embedurl) not in videos:
                            videos.append((vidhost, embedurl))
            sources = re.findall(r'"linkserver".+?video="([^"]+)', html)
            if sources:
                for embedurl in sources:
                    headers.update({'Referer': url})
                    if 'playallu' in embedurl:
                        vidhost, strurl = self.playallu(embedurl, rurl)
                        if (vidhost, strurl) not in videos:
                            videos.append((vidhost, strurl))
                    elif embedurl.startswith('api_player') and 'type=default' not in embedurl:
                        ehtml = client.request(rurl + 'player/' + embedurl, headers=headers, verify=False)
                        linkcode = jsunpack.get_2packed_data(ehtml).replace('\\', '')
                        elink = re.findall(r'''file"\s*:\s*"([^"]+)''', linkcode)
                        if elink:
                            strurl = elink[0]
                            vidhost = self.get_vidhost(strurl)
                            strurl += '|Referer={0}'.format(rurl)
                            if (vidhost, strurl) not in videos:
                                videos.append((vidhost, strurl))
            mid = url.split('/')[-1]
            aurl = urllib_parse.urljoin(url, '/api/movie')
            headers.update({'Referer': url})
            ehtml = client.request(aurl, headers=headers, params={'id': mid})
            if ehtml:
                sources = json.loads(ehtml).get('movieInfo')
                for iid, src in six.iteritems(sources):
                    strurl = src.get('urlStream')
                    vidhost = self.get_vidhost(strurl)
                    if 'playallu' in strurl:
                        vidhost, strurl = self.playallu(strurl, url)
                    if (vidhost, strurl) not in videos:
                        videos.append((vidhost, strurl))

        elif 'tamildbox' in url or 'tamilhdbox' in url:
            if 'embed' in url:
                thdr = self.hdr
                thdr['Referer'] = url
                r = client.request(url, headers=thdr)
                match = re.search(r"domainStream\s*=\s*([^;]+)", r)
                if match:
                    surl = re.findall('file":"([^"]+)', match.group(1))[0]
                    if 'vidyard' in surl:
                        surl += '|Referer=https://play.vidyard.com/'
                    else:
                        surl = surl.replace('/hls/', '/own1hls/2020/')
                        surl += '|Referer=https://embed1.tamildbox.tips/'
                    surl += '&User-Agent={}'.format(self.hdr['User-Agent'])
                else:
                    surl = url.replace('hls_vast', 'hls').replace('.tamildbox.tips', '.tamilgun.tv')
                    if '.m3u8' not in surl:
                        surl += '/playlist.m3u8'
                vidhost = self.get_vidhost(surl)
                if (vidhost, surl) not in videos:
                    videos.append((vidhost, surl))
            else:
                link = client.request(url)

                try:
                    mlink = SoupStrainer('div', {'class': re.compile('^video-player-content')})
                    videoclass = BeautifulSoup(link, "html.parser", parse_only=mlink)
                    vlinks = videoclass.find_all('iframe')
                    for vlink in vlinks:
                        iurl = vlink.get('src')
                        if iurl.startswith('//'):
                            iurl = 'https:' + iurl
                        if 'playallu.' in iurl:
                            vidhost, strlink = self.playallu(iurl, url)
                            if (vidhost, strlink) not in videos:
                                videos.append((vidhost, strlink))
                        else:
                            if self.hmf(iurl):
                                vidhost = self.get_vidhost(iurl)
                                if (vidhost, iurl) not in videos:
                                    videos.append((vidhost, iurl))
                except:
                    self.log(f'Error:  {print_exc()}', 'error')
                    pass

                try:
                    mlink = SoupStrainer('div', {'class': 'player-api'})
                    videoclass = BeautifulSoup(link, "html.parser", parse_only=mlink)
                    vlinks = videoclass.find_all('iframe')
                    for item in vlinks:
                        blink = item.get('src')
                        if 'cdn.jwplayer.com' in blink:
                            headers.update(self.hdr)
                            media_id = blink.split('/')[-1].split('-')[0]
                            jurl = 'https://content.jwplatform.com/v2/media/{0}'.format(media_id)
                            jd = json.loads(client.request(jurl, headers=headers))
                            vlink = jd.get('playlist')[0].get('sources')[0].get('file')
                            if vlink:
                                vidhost = self.get_vidhost(vlink)
                                if (vidhost, vlink) not in videos:
                                    videos.append((vidhost, vlink))
                        else:
                            self.log(f'Cannot resolve: {blink}')
                except:
                    pass

                try:
                    etext = re.search(r'var\s*vidorev_jav_js_object\s*=\s*([^;]+)', link, re.DOTALL)
                    if etext:
                        glink = json.loads(etext.group(1)).get('single_video_url')
                        vidhost = self.get_vidhost(glink)
                        if (vidhost, glink) not in videos:
                            videos.append((vidhost, glink))
                except:
                    pass

                try:
                    etext = re.search(r'file:\s*"([^"]+).+?type:\s*"([^"]+)', link, re.DOTALL)
                    if etext:
                        glink = etext.group(1)
                        vidhost = self.get_vidhost(glink) + ' | {}'.format(etext.group(2))
                        if 'http' not in glink:
                            glink = 'http:' + glink
                        if (vidhost, glink) not in videos:
                            videos.append((vidhost, glink))
                    etext = re.search(r'file":\s*"([^"]+).+?label":\s*"([^"]+)', link, re.DOTALL)
                    if etext:
                        glink = etext.group(1)
                        vidhost = self.get_vidhost(glink) + ' | {}'.format(etext.group(2))
                        if 'http' not in glink:
                            glink = 'http:' + glink
                        if (vidhost, glink) not in videos:
                            videos.append((vidhost, glink))
                except:
                    pass

                try:
                    mlink = SoupStrainer('div', {'id': 'player-embed'})
                    dclass = BeautifulSoup(link, "html.parser", parse_only=mlink)
                    if 'unescape' in str(dclass):
                        etext = re.findall("unescape.'[^']*", str(dclass))[0]
                        etext = urllib_parse.unquote(etext)
                        dclass = BeautifulSoup(etext, "html.parser")
                    glink = dclass.iframe.get('src')
                    if self.hmf(glink):
                        vidhost = self.get_vidhost(glink)
                        if (vidhost, glink) not in videos:
                            videos.append((vidhost, glink))
                except:
                    pass

                try:
                    mlink = SoupStrainer('div', {'class': re.compile('^item-content')})
                    dclass = BeautifulSoup(link, "html.parser", parse_only=mlink)
                    glink = dclass.p.iframe.get('src')
                    if self.hmf(glink):
                        vidhost = self.get_vidhost(glink)
                        if (vidhost, glink) not in videos:
                            videos.append((vidhost, glink))
                except:
                    pass

                try:
                    if 'p,a,c,k,e,d' in link:
                        linkcode = jsunpack.get_2packed_data(link).replace('\\', '')
                        glink = re.findall(r"file\s*:\s*'(.*?)'", linkcode)[0]
                    if 'youtu.be' in glink:
                        glink = 'https://docs.google.com/vt?id=' + glink[16:]
                    if self.hmf(glink):
                        vidhost = self.get_vidhost(glink)
                        if (vidhost, glink) not in videos:
                            videos.append((vidhost, glink))
                except:
                    pass

                try:
                    codes = re.findall(r'"return loadEP.([^,]*),(\d*)', link)
                    for ep_id, server_id in codes:
                        burl = 'https://{}/actions.php?case=loadEP&ep_id={}&server_id={}'.format(url.split('/')[2], ep_id, server_id)
                        bhtml = client.request(burl)
                        blink = re.findall('<iframe.+?src="([^"]+)', bhtml, re.I)[0]
                        if blink.startswith('//'):
                            blink = 'https:' + blink
                        if 'googleapis' in blink:
                            blink = 'https://drive.google.com/open?id=' + re.findall('docid=([^&]*)', blink)[0]
                            vidhost = 'GVideo'
                            if (vidhost, blink) not in videos:
                                videos.append((vidhost, blink))
                        elif 'cdn.jwplayer.com' in blink:
                            headers.update(self.hdr)
                            media_id = blink.split('/')[-1].split('-')[0]
                            jurl = 'https://content.jwplatform.com/v2/media/{0}'.format(media_id)
                            jd = json.loads(client.request(jurl, headers=headers))
                            vlink = jd.get('playlist')[0].get('sources')[0].get('file')
                            if vlink:
                                vidhost = self.get_vidhost(vlink)
                                if (vidhost, vlink) not in videos:
                                    videos.append((vidhost, vlink))
                            else:
                                self.log(f'Cannot resolve: {blink}')
                        elif 'tamildbox.' in blink:
                            if 'embed' in blink:
                                thdr = self.hdr
                                thdr['Referer'] = blink
                                r = client.request(blink, headers=thdr)
                                match = re.search(r"domainStream\s*=\s*'([^']+)", r)
                                if match:
                                    surl = match.group(1)
                                    if 'vidyard' in surl:
                                        surl += '|Referer=https://play.vidyard.com/'
                                    else:
                                        if '.php' not in surl and '.m3u8' not in surl:
                                            surl += '/playlist.m3u8'
                                        surl = surl.replace('/hls/', '/hls1mp4/2020/')
                                        surl += '|Referer=https://embed1.tamildbox.tips/'
                                    surl += '&User-Agent={}'.format(self.hdr['User-Agent'])
                                else:
                                    surl = blink.replace('hls_vast', 'hls')
                                    surl = surl.replace('.tamildbox.tips', '.tamilgun.tv')
                                    if '.m3u8' not in surl:
                                        surl += '/playlist.m3u8'
                                vidhost = self.get_vidhost(surl)
                                if (vidhost, surl) not in videos:
                                    videos.append((vidhost, surl))
                            else:
                                link = client.request(blink)
                                etext = re.search(r'file:\s*"([^"]+).+?type:\s*"([^"]+)', link, re.DOTALL)
                                if etext:
                                    glink = etext.group(1)
                                    vidhost = self.get_vidhost(glink) + ' | {}'.format(etext.group(2))
                                    if glink.startswith('//'):
                                        glink = 'https:' + glink
                                    if (vidhost, glink) not in videos:
                                        videos.append((vidhost, glink))
                                etext = re.search(r'file":\s*"([^"]+).+?label":\s*"([^"]+)', link, re.DOTALL)
                                if etext:
                                    glink = etext.group(1)
                                    vidhost = self.get_vidhost(glink) + ' | {}'.format(etext.group(2))
                                    if glink.startswith('//'):
                                        glink = 'https:' + glink
                                    if (vidhost, glink) not in videos:
                                        videos.append((vidhost, glink))
                        else:
                            if self.hmf(blink):
                                vidhost = self.get_vidhost(blink)
                                if (vidhost, blink) not in videos:
                                    videos.append((vidhost, blink))
                            else:
                                self.log(f'Resolveurl cannot resolve 5: {blink}')
                except:
                    pass

        elif 'tamilthee.' in url:
            vidhost = self.get_vidhost(url)
            vidurl = url.replace('/p/', '/v/') + '.m3u8'
            if (vidhost, vidurl) not in videos:
                videos.append((vidhost, vidurl))

        elif 'vidnext.net' in url:
            if 'streaming.php' in url:
                headers.update(self.hdr)
                url = 'https:' + url if url.startswith('//') else url
                chtml = client.request(url, headers=headers)
                clink = SoupStrainer('ul', {'class': 'list-server-items'})
                csoup = BeautifulSoup(chtml, "html.parser", parse_only=clink)
                citems = csoup.find_all('li')
                for citem in citems:
                    link = citem.get('data-video')
                    if link and 'vidnext.net' not in link:
                        if self.hmf(link):
                            vidhost = self.get_vidhost(link)
                            if vidtxt != '':
                                vidhost += ' | %s' % vidtxt
                            if (vidhost, link) not in videos:
                                videos.append((vidhost, link))
                        else:
                            self.log(f'ResolveUrl cannot resolve 6: {link}')

        elif 'bollyfunmaza.' in url or 'articleweb.me' in url: # serialghar
            if '/vid/' in url and 'multiup' not in url:
                ourl = self.get_mod_url(url)
                if not ourl:
                    headers.update(self.hdr)
                    bhtml = client.request(url, headers=headers)
                    s = self.form_action(url, headers, bhtml)
                    if s:
                        try: ourl = s[0]
                        except: ourl = None
                if ourl and self.hmf(ourl):
                    vidhost = self.get_vidhost(ourl)
                    if vidtxt != '':
                        vidhost += ' | %s' % vidtxt
                    if (vidhost, ourl) not in videos:
                        videos.append((vidhost, ourl))
                else:
                    self.log(f'bollyfunmaza ResolveUrl cannot resolve url: {ourl}')

        elif 'viralnews.' in url:
            headers.update(self.hdr)
            r = client.request(url, headers=headers, output='extended')
            url = r[2].get('Refresh').split(' ')[-1]
            ehtml = client.request(url, headers=headers)
            s = re.search(r'''<iframe.+?src=['"]([^'"]+)''', ehtml, re.I)
            if s:
                if self.hmf(s.group(1)):
                    vidhost = self.get_vidhost(s.group(1))
                    if vidtxt != '':
                        vidhost += ' | %s' % vidtxt
                    if (vidhost, s.group(1)) not in videos:
                        videos.append((vidhost, s.group(1)))
                else:
                    self.log(f'ResolveUrl cannot resolve 8: {s.group(1)}')

        elif 'gomovies.top' in url:
            headers.update(self.hdr)
            chtml = client.request(url, headers=headers)
            clink = SoupStrainer('ul', {'class': 'list-server-items'})
            csoup = BeautifulSoup(chtml, "html.parser", parse_only=clink)
            citems = csoup.find_all('li')
            for citem in citems:
                link = citem.get('data-video')
                if 'gomovies.to' in link:
                    ghtml = client.request(link, headers=headers)
                    glink = re.search(r'file:\s*"([^"]+)', ghtml)
                    if glink:
                        glink = glink.group(1) + '|User-Agent=iPad'
                        vidhost = self.get_vidhost(glink)
                        if vidtxt != '':
                            vidhost += ' | %s' % vidtxt
                        if (vidhost, link) not in videos:
                            videos.append((vidhost, glink))
                else:
                    if self.hmf(link):
                        vidhost = self.get_vidhost(link)
                        if vidtxt != '':
                            vidhost += ' | %s' % vidtxt
                        if (vidhost, link) not in videos:
                            videos.append((vidhost, link))

        elif any([x in url for x in apneembed]):
            headers.update(self.hdr)
            # self.log(f'>>>> apneembed In url: {url}')
            rurl, bhtml = self.refresh_redirect(url, headers=headers)
            s = self.form_action(url, headers, bhtml)
            if s:
                strurl = s[0]
                self.log(f'>>>> apneembed In strurl: {strurl}')
                if 'url=' in strurl:
                    strurl = strurl.split('url=')[-1]
                vidhost = self.get_vidhost(strurl)
                if 'hls' in strurl and 'videoapne' in strurl:
                    strurl = strurl.replace('hls/,', '')
                    strurl = strurl.replace(',.urlset/master.m3u8', '/v.mp4')
                    vidhost = self.get_vidhost(strurl)
                elif self.hmf(strurl):
                    vidhost = self.get_vidhost(strurl)
                if (vidhost, strurl) not in videos:
                    # self.log(f'>>>> apneembed In strurl: {strurl}')
                    videos.append((vidhost, strurl))
            else: self.log(f'>>>> apneembed no s: {s} url: {url}')

        elif '.box.' in url and '.mp4' in url:
            vidhost = self.get_vidhost(url)
            if (vidhost, url) not in videos:
                videos.append((vidhost, url))

        elif 'files.' in url and url.endswith('.mp4'):
            vidhost = self.get_vidhost(url)
            if (vidhost, url) not in videos:
                videos.append((vidhost, url))

        elif 'hinditwostop' in url:
            headers.update(self.hdr)
            html = client.request(url, headers=headers)
            try:
                csoup = BeautifulSoup(html, "html.parser")
                links = csoup.findAll('iframe')
                for link in links:
                    strurl = link.get('src')
                    self.log(f'-------> hinditwostop iframe link: {strurl}')
                    vhdr = {'Origin': 'https://apnevideo.co'}
                    if strurl.endswith('.m3u8'):
                        vhdr.update({'Range': 'bytes=0-'})
                    vidurl = f'{strurl}|{urllib_parse.urlencode(vhdr)}'
                    vidhost = self.get_vidhost(strurl)
                    if (vidhost, vidurl) not in videos:
                        videos.append((vidhost, vidurl))
            except Exception as e:
                self.log(f'hinditwostop Error: {e} {print_exc()}', 'error')
                pass

        elif any([x in url for x in go_cloc_list]):
            html = self.apne_twostop(url, headers)
            try:
                strurl = re.findall(r'''(?i)<iframe.+?src=["']([^'"]+)''', html)
                if strurl:
                    strurl = strurl[0]
                    self.log(f'go.* strurl: {strurl}')
                    # self.log(f'go.* strurl.split: {strurl.split("?url=")}')
                    if '?url=' in strurl:
                        strurl = strurl.split('?url=')[1]
                    vhdr = {'Origin': 'https://apnevideo.co'}
                    if strurl.endswith('.m3u8'):
                        vhdr.update({'Range': 'bytes=0-'})

                    vidurl = '{0}|{1}'.format(strurl, urllib_parse.urlencode(vhdr))
                    vidhost = self.get_vidhost(strurl)
                    if (vidhost, vidurl) not in videos:
                        # self.log(f'go. vidurl: {vidurl}')
                        videos.append((vidhost, vidurl))
            except Exception as e:
                self.log(f'go_cloc_list Error: {e} {print_exc()}', 'error')
                pass

        elif any([x in url for x in embed_list]):
            url = url.replace('hd-rulez.info/', 'business-mortgage.biz/')
            vidcount = 0
            headers.update(self.hdr)
            clink = client.request(url, headers=headers)
            csoup = BeautifulSoup(clink, "html.parser")
            # self.log(f'apnetv >>> csoup: {csoup}')
            try:
                url2 = csoup.find('meta', {'http-equiv': 'refresh'}).get('content').split('URL=')[-1]
                if any([x in url2 for x in embed_list]):
                    self.log(f'-------> from embed_list link: {url2}')
                    clink = client.request(url2, headers=headers)
                    csoup = BeautifulSoup(clink, "html.parser")
                # else:
                    # self.log(f'Cannot Process: {url2}')
            except Exception as e:
                self.log(f'1 meta Error: {e} {print_exc()}', 'error')
                pass

            try:
                links = csoup.find_all('iframe')
                headers.update({'Referer': url})
                for link in links:
                    strurl = link.get('src')
                    if 'about:' in strurl:
                        strurl = link.get('data-phast-src')
                    self.log(f'-------> from iframe link: {strurl}')
                    if any([x in strurl for x in ['apnevideotwo', 'player.business']]):
                        self.log(f'-------> from iframe player.business link: {strurl}')
                        vidhost = 'CDN Direct'
                        if vidtxt:
                            vidhost += ' | %s' % vidtxt
                        if (vidhost, strurl) not in videos:
                            videos.append((vidhost, strurl))
                        vidcount += 1
                    elif 'apnevideoone' in strurl:
                        self.log(f'-------> from iframe apnevideoone link: {strurl}')
                        shtml = client.request(strurl, headers=headers)
                        vidurl = re.findall(r'link_play\s*=\s*\[{"file":"([^"]+)', shtml)[0]
                        vidurl = vidurl.encode('utf8') if self.PY2 else vidurl
                        vhdr = {'Origin': 'https://apnevideoone.co'}
                        vidurl = '{0}|{1}'.format(vidurl, urllib_parse.urlencode(vhdr))
                        vidhost = 'CDN Apne'
                        if vidtxt:
                            vidhost += ' | %s' % vidtxt
                        if (vidhost, vidurl) not in videos:
                            videos.append((vidhost, vidurl))
                        vidcount += 1
                    elif 'flow.' in strurl:
                        self.log(f'-------> from iframe flow. link: {strurl}')
                        shtml = client.request(strurl, headers=headers)
                        if unjuice.test(shtml):
                            shtml = unjuice.run(shtml)
                        if jsunpack.detect(shtml):
                            shtml = jsunpack.get_2packed_data(shtml)
                        vidurl = re.findall(r'"(?:file|src)"\s*:\s*"([^"]+m3u8)', shtml, re.I)[0]
                        if 'tvlogy' not in vidurl:
                            vidurl = vidurl.encode('utf8') if self.PY2 else vidurl
                            vidhost = self.get_vidhost(vidurl) + ' Direct'
                            refr = urllib_parse.urljoin(strurl, '/')
                            vhdr = {'Referer': refr, 'Origin': refr[:-1], 'User-Agent': 'iPad'}
                            vidurl += '|{}'.format(urllib_parse.urlencode(vhdr))
                            if vidtxt:
                                vidhost += ' | %s' % vidtxt
                            if (vidhost, vidurl) not in videos:
                                videos.append((vidhost, vidurl))
                            vidcount += 1
                    elif 'drivewire.' in strurl:
                        self.log(f'-------> from iframe drivewire. link: {strurl}')
                        vid = strurl.split('id=')[-1]
                        parts = urllib_parse.urlparse(strurl)
                        vidurl = '{0}://{1}/hls/{2}/{2}.m3u8'.format(parts.scheme, parts.netloc, vid)
                        vidhost = 'DriveWire'
                        if vidtxt:
                            vidhost += ' | %s' % vidtxt
                        if (vidhost, vidurl) not in videos:
                            videos.append((vidhost, vidurl))
                        vidcount += 1
                    elif not any([x in strurl for x in non_str_list]) and not any([x in strurl for x in embed_list]):
                        self.log(f'-------> sending to resolveurl for checking: {strurl}')
                        if self.hmf(strurl):
                            vidhost = self.get_vidhost(strurl)
                            if vidtxt != '':
                                vidhost += ' | %s' % vidtxt
                            if (vidhost, strurl) not in videos:
                                videos.append((vidhost, strurl))
                            vidcount += 1
                        else:
                            self.log(f'from iframe not from non_str_list & Resolveurl cannot resolve 9: {strurl}')
            except Exception as e:
                self.log(f'2 iframe Error: {e} {print_exc()}', 'error')
                pass

            try:
                sources = re.findall(r'sources:\s*([^\]]+)', clink, re.DOTALL)[0]
                links = re.findall(r'''src:\s*['"]([^"']+)''', sources)
                for strurl in links:
                    self.log(f'-------> from sources link: {strurl}')
                    vidhost = self.get_vidhost(strurl)
                    if vidtxt != '':
                        vidhost += ' | %s' % vidtxt
                    if (vidhost, strurl) not in videos:
                        videos.append((vidhost, strurl))
                    vidcount += 1
            except Exception as e:
                self.log(f'3 sources Error: {e} {print_exc()}', 'error')
                pass

            try:
                r = re.search(r'jwplayer\("container"\).setup\({\s*\n\s*file:\s*"([^"]+)', clink)
                if r:
                    self.log(f'-------> from jwplayer r: {r}')
                    strurl = r.group(1)
                    vidhost = self.get_vidhost(strurl)
                    if vidtxt != '':
                        vidhost += ' | %s' % vidtxt
                    if (vidhost, strurl) not in videos:
                        videos.append((vidhost, strurl))
                    vidcount += 1
            except Exception as e:
                self.log(f'4 jwplayer Error: {e} {print_exc()}', 'error')
                pass

            try:
                plink = csoup.find('a', {'class': 'main-button dlbutton'})
                strurl = plink.get('href')
                if 'videoemx2.com' in strurl:
                    dlink = client.request(strurl, headers=headers)
                    dlinks = SoupStrainer('div', {'class': 'entry-content'})
                    dsoup = BeautifulSoup(dlink, 'html.parser', parse_only=dlinks)
                    strurl = dsoup.find('iframe').get('src')

                if not any([x in strurl for x in non_str_list]):
                    self.log(f'-------> from main-button dlbutton link: {strurl}')
                    if self.hmf(strurl):
                        vidhost = self.get_vidhost(strurl)
                        if vidtxt != '':
                            vidhost += ' | %s' % vidtxt
                        if (vidhost, strurl) not in videos:
                            videos.append((vidhost, strurl))
                        vidcount += 1
                    else:
                        self.log(f'from main-button dlbutton Resolveurl cannot resolve 10: {strurl}')
            except Exception as e:
                self.log(f'5 main-button Error: {e} {print_exc()}', 'error')
                pass

            try:
                plink = csoup.find('div', {'class': 'aio-pulse'})
                strurl = plink.find('a')['href']
                if not any([x in strurl for x in non_str_list]) and not any([x in strurl for x in embed_list]):
                    self.log(f'-------> from aio-pulse link: {strurl}')
                    if self.hmf(strurl):
                        vidhost = self.get_vidhost(strurl)
                        if vidtxt != '':
                            vidhost += ' | {}'.format(vidtxt)
                        if (vidhost, strurl) not in videos:
                            videos.append((vidhost, strurl))
                        vidcount += 1
                    else:
                        self.log(f'from aio-pulse Resolveurl cannot resolve 11: {strurl}')
            except Exception as e:
                self.log(f'6 aio-pulse Error: {e} {print_exc()}', 'error')
                pass

            try:
                plink = csoup.find('div', {'class': re.compile('entry-content')})
                strurl = plink.find('a')['href']
                if not any([x in strurl for x in non_str_list]) and not any([x in strurl for x in embed_list]):
                    self.log(f'-------> from entry-content link: {strurl}')
                    if self.hmf(strurl):
                        vidhost = self.get_vidhost(strurl)
                        if vidtxt != '':
                            vidhost += ' | %s' % vidtxt
                        if (vidhost, strurl) not in videos:
                            videos.append((vidhost, strurl))
                        vidcount += 1
                    else:
                        self.log(f'from entry-content Resolveurl cannot resolve 12: {strurl}')
            except Exception as e:
                self.log(f'7 entry-content Error: {e} {print_exc()}', 'error')
                pass

            try:
                for linksSection in csoup.find_all('embed'):
                    strurl = linksSection.get('src')
                    if not any([x in strurl for x in non_str_list]) and not any([x in strurl for x in embed_list]):
                        self.log(f'-------> from embed link: {strurl}')
                        if self.hmf(strurl):
                            vidhost = self.get_vidhost(strurl)
                            if vidtxt != '':
                                vidhost += ' | %s' % vidtxt
                            if (vidhost, strurl) not in videos:
                                videos.append((vidhost, strurl))
                            vidcount += 1
                    else:
                        self.log(f'from embed Resolveurl cannot resolve 13: {strurl}')
            except Exception as e:
                self.log(f'8 embed Error: {e} {print_exc()}', 'error')
                pass

            try:
                plink = csoup.find('div', {'id': 'Proceed'})
                strurl = plink.find('a')['href']
                if not any([x in strurl for x in non_str_list]) and not any([x in strurl for x in embed_list]):
                    self.log(f'-------> from Proceed link: {strurl}')
                    if self.hmf(strurl):
                        vidhost = self.get_vidhost(strurl)
                        if vidtxt != '':
                            vidhost += ' | %s' % vidtxt
                        if (vidhost, strurl) not in videos:
                            videos.append((vidhost, strurl))
                        vidcount += 1
                    else:
                        self.log(f'from Proceed Resolveurl cannot resolve 14: {strurl}')
            except Exception as e:
                self.log(f'9 Proceed Error: {e} {print_exc()}', 'error')
                pass

            try:
                vid = re.findall(r'tune\.pk[^?]+\?vid=([^&]+)', clink)[0]
                strurl = 'https://tune.pk/video/{vid}/'.format(vid=vid)
                if self.hmf(strurl):
                    self.log(f'-------> from tune link: {strurl}')
                    vidhost = self.get_vidhost(strurl)
                    if vidtxt != '':
                        vidhost += ' | %s' % vidtxt
                    if (vidhost, strurl) not in videos:
                        videos.append((vidhost, strurl))
                    vidcount += 1
                else:
                    self.log(f'from tune Resolveurl cannot resolve 15: {strurl}')
            except Exception as e:
                self.log(f'10 tune Error: {e} {print_exc()}', 'error')
                pass

            try:
                vidurl = re.search(r'file\s*:\s*"([^"]+)', clink)
                if vidurl:
                    self.log(f'-------> from file link: {vidurl}')
                    vidurl = vidurl.group(1)
                    vidhost = self.get_vidhost(vidurl)
                    if (vidhost, vidurl) not in videos:
                        videos.append((vidhost, vidurl))
                    vidcount += 1
            except Exception as e:
                self.log(f'11 file Error: {e} {print_exc()}', 'error')
                pass
            try:
                vidurl = re.findall(r'"(?:file|src)"\s*:\s*"([^"]+m3u8)', clink, re.I)[0]
                self.log(f'-------> from file link: {vidurl}')
                if vidurl:
                    vidhost = self.get_vidhost(vidurl)
                    if (vidhost, vidurl) not in videos:
                        videos.append((vidhost, vidurl))
                    vidcount += 1
            except Exception as e:
                self.log(f'12 file|src Error: {e} {print_exc()}', 'error')
                pass

            if vidcount == 0:
                self.log(f'Could not process link: {url}')

        elif not any([x in url for x in non_str_list]):
            if self.hmf(url):
                self.log(f'-------> from non_str_list link: {url}')
                vidhost = self.get_vidhost(url)
                if 'Referer' in headers.keys():
                    url = '{0}$${1}'.format(url, headers.get('Referer'))
                if vidtxt != '':
                    vidhost += ' | %s' % vidtxt
                if (vidhost, url) not in videos:
                    videos.append((vidhost, url))
            else:
                self.log(f'from non_str_list ResolveUrl cannot resolve 16: {url}')
        self.log(f'>>>> resolve_media In url: {url}\ngives video: {videos}')
        return

    def clean_title(self, title):
        items = 'watch|online|movie|onilne|tamil|dubbed|free|full|length|latest|telugu|rip|dvdrip|dvdscr|uncensored|hd|downlaod|bluray|malayalam|movies|wach|songs|hindi|korean|hilarious|comedy|scenes|super|ultimate|bdrip|todaypk|sun|tv|show|vijay|film|download|starring|horror|hdrip|audio|pdvdrip|hq|brrip|pre hdrip|predvdrip|webrip|punjabi|tcrip|hdtvrip|hd|tc|hdtv|tvrip|720p|dvd|uncut|clear|dthrip|line|kannada|hollywood|ts|cam|streaming|permalink|english|bengali|bhojpuri|print|amzn|scr|web|gujarati|webdl|esubs'
        title = re.sub(r'([:;\-"\',!_.?~$@])', '', title)
        title = title.encode('utf8') if PY2 else title
        title = re.sub(items, ' ', title, flags=re.I)
        title = re.sub(r'\s+', ' ', title, flags=re.I)
        title = title.strip()
        return title.title()

    def unescape(self, title):
        return self.parser.unescape(title)

    def playallu(self, eurl, referer):
        from resources.lib import jscrypto
        import binascii
        import hashlib

        def pencode(c, m):
            i = jscrypto.encode(c, m)
            f = base64.b64decode(i)
            i = binascii.hexlify(f)
            return six.ensure_str(i)

        def pdecode(i, f):
            y = binascii.unhexlify(i)
            b = base64.b64encode(y)
            k = jscrypto.decode(b, f)
            return k

        headers = self.hdr
        refurl = urllib_parse.urljoin(referer, '/')
        pref = urllib_parse.urljoin(eurl, '/')
        headers.update({'Referer': refurl})
        epage = client.request(eurl, headers=headers)
        if isinstance(epage, six.binary_type) and six.PY3:
            epage = epage.decode('latin-1')

        idfile_enc = re.findall(r'''idfile_enc\s*=\s*["']([^"']+)''', epage)[0]
        iduser_enc = re.findall(r'''idUser_enc\s*=\s*["']([^"']+)''', epage)[0]
        curl = re.findall(r'''DOMAIN_API_Info\s*=\s*["']([^"']+)''', epage)[0]
        apiurl = re.findall(r'''DOMAIN_API\s*=\s*["']([^"']+)''', epage)[0]

        headers.update({'Referer': pref, 'Origin': pref[:-1]})
        c = json.loads(client.request(curl, headers=headers))

        idfile_dec = pdecode(idfile_enc, 'jcLycoRJT6OWjoWspgLMOZwS3aSS0lEn')
        iduser_dec = pdecode(iduser_enc, 'PZZ3J3LDbLT0GY7qSA5wW5vchqgpO36O')
        ctime_dec = pdecode(c.get('time'), 'vp0DGD9E5rp6X0a3QYZ1qbDpilL83FO7')
        cip_dec = pdecode(c.get('ip'), 'vp0DGD9E5rp6X0a3QYZ1qbDpilL83FO7')
        pdata = {
            "idfile": idfile_dec,
            "iduser": iduser_dec,
            "domain_play": refurl[:-1],
            "platform": "Win32",
            "ip_clien": cip_dec,
            "time_request": ctime_dec,
            "hlsSupport": True
        }
        z = pencode(json.dumps(pdata), 'vlVbUQhkOhoSfyteyzGeeDzU0BHoeTyZ')
        w = binascii.hexlify(hashlib.md5(six.ensure_binary(z + 'KRWN3AdgmxEMcd2vLN1ju9qKe8Feco5h')).digest())
        data = {'data': z + '|' + six.ensure_str(w)}
        jd = json.loads(client.request(apiurl, headers=headers, post=data))
        mfile = pdecode(jd.get('data'), 'oJwmvmVBajMaRCTklxbfjavpQO7SZpsL')
        return 'Playallu', mfile + '|' + urllib_parse.urlencode(headers)

    def b64decode(self, text):
        return six.ensure_str(base64.b64decode(text))
