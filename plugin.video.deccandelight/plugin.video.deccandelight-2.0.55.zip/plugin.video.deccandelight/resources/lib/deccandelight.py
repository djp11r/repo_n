"""
    Deccan Delight Kodi Addon
    Copyright (C) 2016 gujal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import hashlib
import json
import os
import re
import shutil
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
import six
# from resources.scrapers import *  # NoQA
from six.moves import urllib_parse, urllib_request

from resources.lib import cache, client
from resources.lib.control import Dialog, TRANSLATEPATH, _addon, _addonID, _changelog, _fanart, _handle, _ipath, _listitem, _url, _version, addDir, cache_duration, check_hosted_media, color1, eod, get_setting, kodiver, log, makeFilename, makecast, manual_function_import, mozhdr, notify, ok, pathExists, setContent, setResolvedUrl, set_default

msites = [
    'tgun', 'tamilian', 'tyogi', 'torm', 'hlinks',
    'moviehax', 'ibomma', 'einthusan', 'mrulz', 'mghar',
    'b2t', 'wompk', 'gomovies', 'cinevez', 'todaypk',
    'flinks', 'dcine', 'hflinks', 'awatch'
]


def clear_cache():
    """
    Clear the cache database.
    """
    msg = 'Cached Data has been cleared'
    cache.cache_clear()
    notify(msg)

# try:
    # platform = re.findall(r'\(([^)]+)', control.xbmcua)[0]
# except:
    # platform = 'Linux; Android 4.4.4; MI 5 Build/KTU84P'

def check_vers():
    if get_setting('version') != _version:
        _addon.setSetting('version', _version)
        # headers = {'User-Agent': scontrol.safhdr.format(platform),
                   # 'Referer': '{0} {1}'.format(control._addonname, control._version)}
        # r = client.request('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x73\x2e\x67\x64\x2f\x36\x59\x6f\x64\x55\x50',
                           # headers=headers)
        clear_cache()
        set_default()
        heading = '[B][COLOR gold]Deccan Delight[/COLOR] - [COLOR white]Changelog[/COLOR][/B]'
        with open(_changelog) as f:
            announce = f.read()
        dialog = Dialog()
        dialog.textviewer(heading, announce)
    return


sites = {
    '01tgun': 'Tamil Gun : [COLOR yellow]Tamil[/COLOR]',
    # '02tamilian': 'Tamilian : [COLOR yellow]Tamil[/COLOR]',
    '03tyogi': 'Tamil Yogi : [COLOR yellow]Tamil[/COLOR]',
    # '21ibomma': 'iBOMMA : [COLOR yellow]Telugu[/COLOR]',
    # '22torm': 'TOR Malayalam : [COLOR yellow]Malayalam[/COLOR]',
    '31hlinks': 'Hindi Links 4U : [COLOR %s]Hindi[/COLOR]' % color1,
    '32moviehax': 'Movie Hax : [COLOR %s]Hindi[/COLOR]' % color1,
    '42einthusan': 'Einthusan : [COLOR %s]Various[/COLOR]' % color1,
    '43mrulz': 'Movie Rulz : [COLOR %s]Various[/COLOR]' % color1,
    # '44mghar': 'Movies Ghar : [COLOR %s]Various[/COLOR]' % color1,
    # '45b2t': 'Bolly 2 Tolly : [COLOR %s]Various[/COLOR]' % color1,
    '47wompk': 'Online Movies PK : [COLOR %s]Various[/COLOR]' % color1,
    '48gomovies': 'Go Movies : [COLOR %s]Various[/COLOR]' % color1,
    # '49cinevez': 'Cine Vez : [COLOR %s]Various[/COLOR]' % color1,
    '50todaypk': 'TodayPk : [COLOR %s]Various[/COLOR]' % color1,
    '51flinks': 'Film Links 4U : [COLOR %s]Various[/COLOR]' % color1,
    '52dcine': 'Desi Cinemas : [COLOR %s]Various[/COLOR]' % color1,
    '53hflinks': 'Film Links 4U Pro : [COLOR %s]Various[/COLOR]' % color1,
    # '71ttvshow': 'Tamil TV Show: [COLOR yellow]Tamil Catchup TV[/COLOR]',
    # '72skytamil': 'sky Tamil: [COLOR yellow]Tamil Catchup TV[/COLOR]',
    '73tdhool': 'Tamil Dhool : [COLOR yellow]Tamil Catchup TV[/COLOR]',
    # '77manatv': 'Mana Telugu : [COLOR yellow]Telugu Catchup TV[/COLOR]',
    # '81apnetv': 'Apne TV : [COLOR %s]Hindi Catchup TV[/COLOR]' % color1,
    '82desiseri': 'Desi Serials : [COLOR %s]Hindi Catchup TV[/COLOR]' % color1,
    '83desit': 'Desi tellybox : [COLOR %s]Hindi Catchup TV[/COLOR]' % color1,
    '84pdesi': 'Play Desi : [COLOR %s]Hindi Catchup TV[/COLOR]' % color1,
    # '85sghar': 'Serial Ghar : [COLOR %s]Hindi Catchup TV[/COLOR]' % color1,
    # '86wapne': 'Watch Apne : [COLOR %s]Hindi Catchup TV[/COLOR]' % color1,
    '87yodesi': 'Yo Desi : [COLOR %s]Hindi Catchup TV[/COLOR]' % color1,
    '91ary': 'Ary Digital : [COLOR yellow]Urdu Catchup TV[/COLOR]',
    '92geo': 'Geo TV : [COLOR yellow]Urdu Catchup TV[/COLOR]',
    '93hum': 'Hum TV : [COLOR yellow]Urdu Catchup TV[/COLOR]',
    '99gmala': 'Hindi Geetmala : [COLOR %s]Hindi Songs[/COLOR]' % color1
}


def make_listitem(*args, **kwargs):
    return _listitem(*args, offscreen=True, **kwargs)


def update_listitem(li, labels):
    cast2 = labels.pop('cast2') if 'cast2' in labels.keys() else []
    unique_ids = {}
    tmdb_id = labels.get('tmdb_id')
    imdb_id = labels.get('imdb_id')
    if tmdb_id:
        unique_ids.update({'tmdb': tmdb_id})
        labels.pop('tmdb_id')
    if imdb_id:
        unique_ids.update({'imdb': imdb_id})
        labels.pop('imdb_id')
    if kodiver > 19.8 and isinstance(labels, dict):
        vtag = li.getVideoInfoTag(True)
        if labels.get('title'):
            vtag.setTitle(labels['title'])
        if labels.get('tag'):
            vtag.setTagLine(labels['tag'])
        if labels.get('plot'):
            vtag.setPlot(labels['plot'])
        if labels.get('year'):
            vtag.setYear(int(labels['year']))
        if labels.get('premiered'):
            vtag.setPremiered(labels['premiered'])
        if labels.get('duration'):
            vtag.setDuration(labels['duration'])
        if labels.get('country'):
            vtag.setCountries(labels['country'])
        if labels.get('genre'):
            vtag.setGenres(labels['genre'])
        if labels.get('director'):
            vtag.setDirectors(labels['director'])
        if labels.get('writer'):
            vtag.setWriters(labels['writer'])
        if labels.get('studio'):
            vtag.setStudios(labels['studio'])
        if labels.get('rating'):
            vtag.setRating(labels['rating'])
        if labels.get('trailer'):
            vtag.setTrailer(labels['trailer'])
        if labels.get('mediatype'):
            vtag.setMediaType(labels['mediatype'])
        if unique_ids:
            vtag.setUniqueIDs(unique_ids)
        if cast2:
            vtag.setCast(makecast(cast2))

    else:
        li.setInfo(type='Video', infoLabels=labels)
        if unique_ids:
            li.setUniqueIDs(unique_ids)
        if cast2:
            li.setCast(cast2)
    return li


def list_sites():
    """
    Create the Sites menu in the Kodi interface.
    """
    listing = []
    for site, title in sorted(six.iteritems(sites)):
        if get_setting(site[2:]) == 'true':
            item_icon = f'{_ipath}{site[2:]}.png'
            list_item = make_listitem(label=title)
            list_item.setArt({'thumb': item_icon,
                              'icon': item_icon,
                              'poster': item_icon,
                              'fanart': _fanart})
            url = '{0}?action=1&site={1}'.format(_url, site[2:])
            is_folder = True
            listing.append((url, list_item, is_folder))

    list_item = make_listitem(label=f'[COLOR {color1}][B]Clear Cache[/B][/COLOR]')
    item_icon = f'{_ipath}ccache.png'
    list_item.setArt({'thumb': item_icon,
                      'icon': item_icon,
                      'poster': item_icon,
                      'fanart': _fanart})
    url = '{0}?action=0'.format(_url)
    is_folder = False
    listing.append((url, list_item, is_folder))
    list_item = make_listitem(label=f'[COLOR {color1}][B]Clear MetaCache[/B][/COLOR]')
    list_item.setArt({'thumb': item_icon, 'icon': item_icon, 'poster': item_icon, 'fanart': _fanart})
    url = '{0}?action=11'.format(_url)
    is_folder = False
    listing.append((url, list_item, is_folder))

    log(f'list_sites itmes: {len(listing)} {listing}', 'debug')
    addDir(_handle, listing, len(listing))
    setContent(_handle, 'addons')
    eod(_handle)


def list_menu(site):
    """
    Create the Site menu in the Kodi interface.
    """
    # scraper = eval('{}.{}()'.format(site, site))
    scraper = manual_function_import(f'resources.scrapers.{site}', f'{site}')
    menu, mode, icon = cache.get(scraper.get_menu, cache_duration)
    log(f'list_top mode: {mode} menu: {menu} scraper: {scraper}', 'debug')
    listing = []
    for title, iurl in sorted(six.iteritems(menu)):
        digits = len(re.findall(r'^(\d*)', title)[0])
        next_mode = mode

        if 'MMMM' in iurl:
            iurl, next_mode = iurl.split('MMMM')

        if 'Adult' not in title:
            list_item = make_listitem(label=title[digits:])
            list_item.setArt({'thumb': icon,
                              'icon': icon,
                              'poster': icon,
                              'fanart': _fanart})
            url = '{0}?action={1}&site={2}&iurl={3}'.format(_url, next_mode, site, urllib_parse.quote(iurl))
            if next_mode == 9:
                is_folder = False
                list_item.setProperty('IsPlayable', 'true')
            else:
                is_folder = True
            listing.append((url, list_item, is_folder))
        elif get_setting('adult') == 'true':
            list_item = make_listitem(label=title[digits:])
            list_item.setArt({'thumb': icon,
                              'icon': icon,
                              'poster': icon,
                              'fanart': _fanart})
            url = '{0}?action={1}&site={2}&iurl={3}'.format(_url, next_mode, site, urllib_parse.quote(iurl))
            is_folder = True
            listing.append((url, list_item, is_folder))
    log(f'list_menu {site}\nitmes: {len(listing)} {listing}', 'debug')
    addDir(_handle, listing, len(listing))
    setContent(_handle, 'videos')
    eod(_handle)


def list_top(site, iurl):
    """
    Create the Site menu in the Kodi interface.
    """
    # scraper = eval('{}.{}()'.format(site, site))
    scraper = manual_function_import(f'resources.scrapers.{site}', f'{site}')
    menu, mode = cache.get(scraper.get_top, cache_duration, iurl)
    log(f'list_top mode: {mode} menu: {menu} scraper: {scraper} ', 'debug')
    is_folder = True
    listing = []
    for title, icon, iurl in menu:
        if 'MMMM' in iurl:
            nurl, nmode = iurl.split('MMMM')
            list_item = make_listitem(label=title)
            list_item.setArt({'thumb': icon,
                              'icon': icon,
                              'fanart': _fanart})
            url = '{0}?action={1}&site={2}&iurl={3}'.format(_url, nmode, site, urllib_parse.quote(nurl))
        else:
            list_item = make_listitem(label=title)
            list_item.setArt({'thumb': icon,
                              'icon': icon,
                              'poster': icon,
                              'fanart': _fanart})
            url = '{0}?action={1}&site={2}&iurl={3}'.format(_url, mode, site, urllib_parse.quote(iurl))
        listing.append((url, list_item, is_folder))
    log(f'list_top {site}, {iurl}\nitems: {len(listing)} {listing}', 'debug')
    addDir(_handle, listing, len(listing))
    setContent(_handle, 'videos')
    eod(_handle)


def list_second(site, iurl):
    """
    Create the Site menu in the Kodi interface.
    """
    # scraper = eval('{}.{}()'.format(site, site))
    scraper = manual_function_import(f'resources.scrapers.{site}', f'{site}')
    menu, mode = cache.get(scraper.get_second, cache_duration, iurl)
    listing = []
    for title, icon, iurl in menu:
        list_item = make_listitem(label=title)
        list_item.setArt({'thumb': icon,
                          'icon': icon,
                          'poster': icon,
                          'fanart': _fanart})
        nextmode = mode
        if 'MMMM' in iurl:
            iurl, nextmode = iurl.split('MMMM')
        if 'Next Page' in title:
            nextmode = 5
        url = '{0}?action={1}&site={2}&iurl={3}'.format(_url, nextmode, site, urllib_parse.quote(iurl))
        is_folder = True
        if mode == 9 and 'Next Page' not in title:
            is_folder = False
            list_item.setProperty('IsPlayable', 'true')
        listing.append((url, list_item, is_folder))
    log(f'list_second {site}, {iurl}\nitems: {len(listing)} {listing}', 'debug')
    addDir(_handle, listing, len(listing))
    setContent(_handle, 'tvshows')
    eod(_handle)


def list_third(site, iurl):
    """
    Create the Site menu in the Kodi interface.
    """
    # scraper = eval('{}.{}()'.format(site, site))
    scraper = manual_function_import(f'resources.scrapers.{site}', f'{site}')
    menu, mode = cache.get(scraper.get_third, cache_duration, iurl)
    listing = []
    for title, icon, iurl in menu:
        list_item = make_listitem(label=title)
        list_item.setArt({'thumb': icon,
                          'icon': icon,
                          'poster': icon,
                          'fanart': _fanart})
        nextmode = mode
        if 'Next Page' in title:
            nextmode = 6
        url = '{0}?action={1}&site={2}&iurl={3}'.format(_url, nextmode, site, urllib_parse.quote(iurl))
        is_folder = True
        if mode == 8 and 'Next Page' not in title:
            url = '{0}?action={1}&site={2}&title={3}&thumb={4}&iurl={5}'.format(_url, mode, site, urllib_parse.quote(title), urllib_parse.quote(icon), iurl)
        if mode == 9 and 'Next Page' not in title:
            is_folder = False
            list_item.setProperty('IsPlayable', 'true')
        listing.append((url, list_item, is_folder))
    log(f'list_third {site}, {iurl}\nitems: {len(listing)} {listing}', 'debug')
    addDir(_handle, listing, len(listing))
    setContent(_handle, 'tvshows')
    eod(_handle)


def list_items(site, iurl):
    """
    Create the list of movies/episodes in the Kodi interface.
    """
    # scraper = eval('{}.{}()'.format(site, site))
    scraper = manual_function_import(f'resources.scrapers.{site}', f'{site}')
    if iurl.endswith('='):
        movies, mode = scraper.get_items(iurl)
    else:
        movies, mode = cache.get(scraper.get_items, cache_duration, iurl)
    listing = []
    for movie in movies:
        title = movie[0]
        if title == '':
            title = 'Unknown'
        list_item = make_listitem(label=title)
        if 'Next Page' in title:
            nextmode = 7
            url = '{0}?action={1}&site={2}&iurl={3}'.format(_url, nextmode, site, urllib_parse.quote(movie[2]))
            update_listitem(list_item, {'title': title})
            list_item.setArt({'thumb': movie[1],
                              'icon': movie[1],
                              'poster': movie[1],
                              'fanart': _fanart})
        else:
            nextmode = mode
            iurl = movie[2]
            if 'MMMM' in iurl:
                iurl, nextmode = iurl.split('MMMM')
            qtitle = urllib_parse.quote(title)
            mthumb = movie[1].encode('utf8') if six.PY2 else movie[1]
            url = '{0}?action={1}&site={2}&title={3}&thumb={4}&iurl={5}'.format(
                _url, nextmode, site, qtitle, urllib_parse.quote(mthumb), urllib_parse.quote(iurl)
            )
            fanart = _fanart
            poster = movie[1]
            if get_setting('meta') == 'true' and site in msites:
                from resources.lib.metautils import get_meta
                meta = get_meta(title)
                if meta and 'tmdb_id' in meta:
                    if meta.get('art'):
                        art = meta.pop('art')
                        fanart = art.get('fanart')
                        poster = art.get('poster')
                    update_listitem(list_item, meta)
                else:
                    update_listitem(list_item, {'title': title, 'mediatype': 'video'})

            list_item.setArt({
                'thumb': movie[1],
                'icon': movie[1],
                'poster': poster,
                'fanart': fanart
            })
        if mode == 9 and 'Next Page' not in title:
            is_folder = False
            list_item.setProperty('IsPlayable', 'true')
            list_item.addContextMenuItems([('Download Video', 'RunPlugin(plugin://{0}/?action=10&iurl={1}ZZZZ{2})'.format(_addonID, urllib_parse.quote_plus(iurl), title),)])
        else:
            is_folder = True
        listing.append((url, list_item, is_folder))
    log(f'list_items {site}, {iurl}\nitems: {len(listing)} {listing}', 'debug')
    addDir(_handle, listing, len(listing))
    setContent(_handle, 'movies')
    eod(_handle)


def list_videos(site, title, iurl, thumb):
    """
    Create the list of playable videos in the Kodi interface.
    """
    # scraper = eval('{}.{}()'.format(site, site))
    scraper = manual_function_import(f'resources.scrapers.{site}', f'{site}')
    videos = cache.get(scraper.get_videos, cache_duration, iurl)
    log(f'list_videos items: {repr(videos)}', 'debug')
    listing = []
    if videos:
        for name, video in videos:
            list_item = make_listitem(label=name)
            list_item.setArt({'thumb': thumb,
                              'icon': thumb,
                              'poster': thumb,
                              'fanart': thumb})
            update_listitem(list_item, {'title': title})
            list_item.setProperty('IsPlayable', 'true')
            url = '{0}?action=9&iurl={1}'.format(_url, urllib_parse.quote_plus(video))
            if 'm3u8' not in video:
                list_item.addContextMenuItems([('Download Video', 'RunPlugin(plugin://{0}/?action=10&iurl={1}ZZZZ{2})'.format(_addonID, urllib_parse.quote_plus(video), title),)])
            is_folder = False
            listing.append((url, list_item, is_folder))

    log(f'list_videos items: {len(listing)} {repr(listing)}', 'debug')
    if listing: addDir(_handle, listing, len(listing))
    else: notify('videos list:', 'Not found!')
    setContent(_handle, 'videos')
    eod(_handle)


def resolve_url(url, subs=False):
    hmf = check_hosted_media(url, subs)
    if not hmf:
        ok('Indirect hoster_url not supported by smr: {0}'.format(url), 'Resolve URL')
        return False
    resp = None
    try:
        if subs:
            resp = hmf.resolve()
            stream_url = resp.get('url')
        else:
            stream_url = hmf.resolve()
        # If resolveurl returns false then the video url was not resolved.
        if not stream_url or not isinstance(stream_url, six.string_types):
            msg = str(stream_url) if stream_url else 'File removed'
            notify(msg, 'Resolve URL', 5000)
            return '', ''
    except Exception as e:
        try: msg = str(e)
        except: msg = url
        notify(msg, 'Resolve URL', 5000)
        return  '', ''

    if subs: return stream_url , ''
    return stream_url, ''

headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', 'Accept-Language': 'en-US,en;q=0.5', 'Accept-Encoding': 'gzip, deflate', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8', 'Connection': 'keep-alive', 'DNT': '1', 'Sec-Gpc': '1', 'Upgrade-Insecure-Requests': '1', 'Sec-Fetch-Dest': 'document', 'Sec-Fetch-Mode': 'navigate', 'Sec-Fetch-User': '?1', 'x-requested-with': 'XMLHttpRequest', }

class DownloadStats:
    def __init__(self, total_size, name):
        self.total_size = total_size
        self.name = name
        self.downloaded = 0
        self.last_reported_percent = 0  # Track the last milestone
        self.start_time = time.perf_counter()
        self.notify = get_setting('dl_notify') == 'true'
        self.lock = threading.Lock()

    def format_time(self, seconds):
        """Converts seconds into MM:SS format."""
        if seconds <= 0: return "00:00"
        mins, secs = divmod(int(seconds), 60)
        return f"{mins:02d}:{secs:02d}"

    def report_progress(self, bytes_received):
        with self.lock:
            self.downloaded += bytes_received
            percent = (self.downloaded / self.total_size) * 100
            # Check if we've crossed the next 25% milestone
            if percent >= self.last_reported_percent + 25 or self.downloaded >= self.total_size:
                self.display_bar(percent)
                # Update the milestone (e.g., 15, 30, 45...)
                self.last_reported_percent = (percent // 25) * 25

    def display_bar(self, percent):
        elapsed = time.perf_counter() - self.start_time
        # Aggregate speed: total MB downloaded / total elapsed time
        # Calculate Speed (Bytes per second)
        speed = self.downloaded / elapsed if elapsed > 0 else 0
        speed_mb = speed / (1024 * 1024)
        # Calculate ETA based on remaining bytes
        remaining_bytes = self.total_size - self.downloaded
        eta_seconds = remaining_bytes / speed if speed > 0 else 0
        eta_str = self.format_time(eta_seconds)
        # Build the visual bar
        # bar_len = 40
        # filled = int(bar_len * self.downloaded // self.total_size)
        # bar = '█' * filled + '-' * (bar_len - filled)
        # \r brings the cursor back to the start of the line to overwrite it
        # sys.stdout.write(f'\r|{bar}| {percent:.1f}% - Total Speed: {speed_mb:.2f} MB/s')
        # sys.stdout.flush()
        msg = f'download progress: {self.name} - ETA: {eta_str} percent: {percent:.1f}% - Total Speed: {speed_mb:.2f} MB/s'
        log(msg, 'error')
        if self.notify: notify(msg)

def download_range_with_stats(url, start, end, filename, stats, base_headers, max_retries=5):
    """Downloads a specific byte range and writes it to the file."""
    # FIX 1: Create a LOCAL copy of headers so threads don't overwrite each other
    local_headers = base_headers.copy()
    local_headers['Range'] = f'bytes={start}-{end}'
    for attempt in range(max_retries):
        try:
            # stream=True allows us to process data piece by piece  Setting a timeout is critical for identifying "hung" connections
            with requests.get(url, headers=local_headers, stream=True, timeout=15) as r:
                # If server doesn't support ranges, it returns 200 instead of 206
                if r.status_code not in [200, 206]:
                    r.raise_for_status()
                with open(filename, "r+b") as f:
                    f.seek(start)
                    for chunk in r.iter_content(chunk_size=256 * 1024):
                        if chunk:
                            f.write(chunk)
                            stats.report_progress(len(chunk))
                return  # Success! Exit the retry loop
        except (requests.exceptions.RequestException, IOError) as e:
            # Notify the user of the failure and the upcoming retry
            wait_time = 2 ** attempt  # Exponential backoff: 1, 2, 4, 8, 16 seconds
            log(f"[!] Error in range {start}-{end}: {e}. Retrying in {wait_time}s...")
            if attempt == max_retries - 1:
                log(f"\n[X] Permanent failure for range {start}-{end} after {max_retries} attempts.")
                raise e  # Re-raise if all retries are exhausted
            time.sleep(wait_time)


def clean_filename(s):
    if not s: return ''
    # Remove Kodi formatting tags safely
    s = re.sub(r'\[/?(?:COLOR|I|CR|B)[^\]]*]', '', s)
    # Remove illegal filesystem characters
    badchars = '.\\/:*?"<>|\''
    for c in badchars:
        s = s.replace(c, '')
    # Collapse multiple spaces
    s = re.sub(r'\s+', ' ', s)
    return s.strip()

def download_video_resilient(url, name, num_threads=4):
    # 1. Get total size using a local header instanceSetup metadata and stats tracker Get total file size
    try:
        head = requests.head(url, headers=headers, allow_redirects=True, timeout=10)
    except Exception as e:
        msg = f'download_video_resilient HEAD failed: {e}'
        log(msg)
        return notify(msg)

    total_size = int(head.headers.get('Content-Length', 0))
    if not total_size:
        msg = 'download_video_resilient failed to get file size (no Content-Length).'
        log(msg)
        return notify(msg)
    # 2. Resolve download path (Kodi setting + translatePath)
    download_path = get_setting('dlfolder')
    while not download_path:
        notify('Choose download directory in Settings!', 'Download:', 5000)
        _addon.openSettings()
        download_path = get_setting('dlfolder')
    # Ensure trailing separator and real filesystem path
    download_path = TRANSLATEPATH(download_path)
    if not download_path.endswith(os.sep):
        download_path += os.sep

    # 3. Sanitize name and build paths
    name = clean_filename(name)
    # Final destination name
    final_filename = f'{download_path}{name}.mp4'
    # Temporary name while downloading
    temp_filename = f'{download_path}{name}.mp4.part'
    state_file = f'{download_path}{name}.json'
    # log(f'>>> final_filename: {repr(final_filename)}')
    # 4. Check free space in the download directory we have enough space for the *entire* file before starting
    try:
        _, _, free_bytes = shutil.disk_usage(download_path)
        # Add a buffer (e.g., 100MB) to prevent filling the disk to 100%
        safety_buffer = 100 * 1024 * 1024
        # If the file doesn't exist yet, we need 'total_size' space. If it *does* exist, we technically already allocated it, so we skip the check (unless you want to be super safe, but usually existing .part files are already truncated).
        if (not os.path.exists(temp_filename)) and free_bytes < (total_size + safety_buffer):
            msg = f"Not enough disk space! Need: {total_size / (1024 ** 3):.2f} GB, Free: {free_bytes / (1024 ** 3):.2f} GB"
            log(msg)
            return notify(msg)
    except Exception as e:
        log(f"Warning: Could not verify disk space: {e}")
    # 5. Create empty .part file if missing (NO truncate)
    if not os.path.exists(temp_filename):
        try:
            # Ensure directory exists
            os.makedirs(os.path.dirname(temp_filename), exist_ok=True)
            with open(temp_filename, "wb") as f:
                pass  # just create the file
        except Exception as e:
            msg = f"Failed to create temp file: {e}"
            log(msg)
            return notify(msg)

    # 6. Load or create progress state
    if os.path.exists(state_file):
        try:
            with open(state_file, "r") as f:
                completed_ranges = json.load(f)
        except Exception as e:
            log(f"State file corrupt, resetting: {e}")
            completed_ranges = []
    else:
        completed_ranges = []
    # 7.Parallel Download Define Ranges Divide work into byte ranges/ Calculate ranges for each thread
    chunk_size = total_size // num_threads
    ranges = []
    for i in range(num_threads):
        if i in completed_ranges: continue  # SKIP already finished ranges
        start = i * chunk_size
        # The last thread takes everything remaining
        end = total_size - 1 if i == num_threads - 1 else (start + chunk_size - 1)
        ranges.append((i, start, end))
    if not ranges: return notify('Download:', 'File already exists and complete.!')
    stats = DownloadStats(total_size, name) # Initialize your progress tracker
    # Call the function with all required parameters Run threads
    log(f"Starting download: {name} ({total_size / (1024 ** 2):.2f} MB)")
    # 8. Parallel download (VFS‑safe: we use temp_filename path)
    try:
        with ThreadPoolExecutor(max_workers=num_threads) as executor:
            # We pass the index 'i' to track which range finishesand Pass the 'headers' as a base_headers argument
            futures = {executor.submit(download_range_with_stats, url, start, end, temp_filename, stats, headers): i for i, start, end in ranges}
            for future in as_completed(futures): # Use as_completed to catch finishes in real-time
                range_index = futures[future]
                try:
                    future.result()
                    completed_ranges.append(range_index)
                    # Persist state Save state frequently in case of crash
                    with open(state_file, "w") as f:
                        json.dump(completed_ranges, f)
                except Exception as e:
                    log(f"[!] Range {range_index} failed. It will be retried next time: {e}")
    finally:
        # 9. Finalize: rename .part -> .mp4 only if all ranges done
        if len(set(completed_ranges)) >= num_threads:
            if os.path.exists(state_file): os.remove(state_file)
            try:
                # If a file with the final name already exists, remove it first
                if os.path.exists(final_filename):
                    os.remove(final_filename)
                os.rename(temp_filename, final_filename)
                log(f"✔ Download finalized: {final_filename}")
            except Exception as e:
                log(f"Error renaming file: {e}")
        else:
            log("Download interrupted. Resume later via the .part file.")
    return final_filename



def use_inputstream(play_item, stream_url):
    play_item.setContentLookup(False)
    play_item.setProperty('inputstream', 'inputstream.adaptive')
    play_item.setProperty('inputstream.adaptive.max_bandwidth', '100000000000')
    play_item.setProperty('http-reconnect', 'true')
    if 'hls' in stream_url: play_item.setMimeType('application/vnd.apple.mpegurl') #and inputstreamhelper.Helper('hls').check_inputstream():
    elif '.ism' in stream_url: play_item.setMimeType('application/vnd.ms-sstr+xml')
    elif '.mpd' in stream_url: play_item.setMimeType('application/dash+xml')
    if '|' in stream_url:
        _, strhdr = stream_url.split('|')
        play_item.setProperty('inputstream.adaptive.stream_headers', strhdr)
        play_item.setProperty('inputstream.adaptive.common_headers', strhdr)
        #play_item.setProperty('inputstream.adaptive.manifest_headers', strhdr)
        play_item.setPath(stream_url)
    return play_item

def set_inputstream(litem, url, is_type=''):
    if is_type == '1': # adaptive
        litem.setContentLookup(False)
        adaptive_plugin = TRANSLATEPATH('special://home/addons/inputstream.adaptive')
        if not pathExists(adaptive_plugin): return litem
            # try:
                # executebuiltin('InstallAddon(script.module.inputstreamhelper)', True)
                # executebuiltin('InstallAddon(inputstream.adaptive)', True)
            # except: return litem
        litem.setProperty('inputstream', 'inputstream.adaptive')
        litem.setProperty('inputstream.adaptive.max_bandwidth', '100000000000')
        litem.setProperty('http-reconnect', 'true')
        if '.m3u8' in url.lower(): litem.setMimeType('application/vnd.apple.mpegurl') #and inputstreamhelper.Helper('hls').check_inputstream():
        elif '.ism' in url.lower(): litem.setMimeType('application/vnd.ms-sstr+xml')
        elif '.mpd' in url.lower(): litem.setMimeType('application/dash+xml')
        if '|' in url:
            url, strhdr = url.split('|')
            litem.setProperty('inputstream.adaptive.stream_headers', strhdr)
            litem.setProperty('inputstream.adaptive.common_headers', strhdr)
            # litem.setProperty('inputstream.adaptive.manifest_headers', strhdr)
    elif is_type == '2': # ffmpeg
        ffmpeg_plugin = TRANSLATEPATH('special://home/addons/inputstream.ffmpegdirect')
        if not pathExists(ffmpeg_plugin): return litem
            # try: executebuiltin('InstallAddon(inputstream.ffmpegdirect)', True)
            # except: return litem
        litem.setProperty('inputstream', 'inputstream.ffmpegdirect')
        litem.setMimeType('application/x-mpegURL')
        litem.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        litem.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift')
        litem.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
    return litem


def play_video(vid_url, dl=False):
    """
    Play a video by the provided path.
    """
    streamer_list = ['tamilgun', 'mersalaayitten', 'mhdtvworld.', '/hls/', 'poovee.',
        'watchtamiltv.', 'cloudspro.', 'abroadindia.', 'nextvnow.', 'harpalgeo.',
        'hindilyrics4u.', '.mp4', 'googlevideo.', 'playembed.', 'akamaihd.',
        'tamilhdtv.', 'andhrawatch.', 'tamiltv.', 'athavantv', 'cinemalayalam',
        'justmoviesonline.', '.mp3', 'googleapis.', '.m3u8', 'telugunxt.',
        'playallu.', 'bharat-movies.', 'googleusercontent.', 'arydigital.',
        'space-cdn.', 'einthusan.', 'd0stream.', 'telugugold.', '.xdiv.',
        'hum.tv', 'apnevideotwo.', 'player.business', 'tamilian.']
    # Create a playable item with a path to play.
    title = 'unknown'
    vid_url = urllib_parse.unquote_plus(vid_url)
    if 'ZZZZ' in vid_url:
        vid_url, title = vid_url.split('ZZZZ')

    play_item = make_listitem(path=vid_url)
    log(f'-------> from play_video IN vid_url: {vid_url}')

    if any([x in vid_url for x in streamer_list]):
        if 'einthusan.' in vid_url:
            site = 'einthusan'
            scraper = manual_function_import(f'resources.scrapers.{site}', f'{site}')
            stream_url = scraper.get_video(vid_url)
            play_item.setPath(stream_url)
        elif '.xdiv.' in vid_url:
            site = 'ibomma'
            scraper = manual_function_import(f'resources.scrapers.{site}', f'{site}')
            #scraper = ibomma.ibomma()  # NoQA
            stream_url = scraper.get_video(vid_url)
            play_item.setPath(stream_url)
        elif 'apnevideotwo.' in vid_url:
            stream_url = urllib_parse.quote(vid_url, ':/|=?')
            play_item.setPath(stream_url)
        elif 'player.business' in vid_url:
            headers = mozhdr
            spage = client.request(vid_url, headers=headers)
            matches = re.findall(r'"src":"([^"]+)","label":"([^"]+)', spage)
            if len(matches) > 1:
                sources = []
                for match in matches:
                    sources.append(match[1])
                dialog = Dialog()
                ret = dialog.select('Choose a Source', sources)
                match = matches[ret]
            else:
                match = matches[0]
            stream_url = match[0] + '|User-Agent={}'.format(headers['User-Agent'])
            play_item.setPath(stream_url)
        elif ('tamilyogi.' in vid_url or 'tamilvip.' in vid_url) and '.m3u8' not in vid_url:
            site = 'tyogi'
            scraper = manual_function_import(f'resources.scrapers.{site}', f'{site}')
            stream_url = scraper.get_video(vid_url)
            if stream_url:
                stream_url, _ = resolve_url(stream_url)
                if stream_url:
                    play_item.setPath(stream_url)
                else:
                    play_item.setPath(None)
        elif 'hindilyrics4u.' in vid_url:
            site = 'gmala'
            scraper = manual_function_import(f'resources.scrapers.{site}', f'{site}')
            stream_url = scraper.get_video(vid_url)
            if stream_url:
                log(f'-------> from play_video In without resolver stream_url: {stream_url}', 'debug')
                if 'youtube.' in stream_url:
                    stream_url, _ = resolve_url(stream_url)
                log(f'-------> from play_video Out resolver stream_url: {stream_url}', 'debug')
                play_item.setPath(stream_url)
        elif 'tamilgun.' in vid_url:
            if '.m3u8' in vid_url:
                stream_url = vid_url
            else:
                site = 'tgun'
                scraper = manual_function_import(f'resources.scrapers.{site}', f'{site}')
                stream_url = scraper.get_video(vid_url)
            if stream_url:
                play_item.setPath(stream_url)
        elif 'arydigital.' in vid_url:
            site = 'ary'
            scraper = manual_function_import(f'resources.scrapers.{site}', f'{site}')
            stream_url = scraper.get_video(vid_url)
            if check_hosted_media(stream_url):
                stream_url, _ = resolve_url(stream_url)
            if stream_url:
                play_item.setPath(stream_url)
            else:
                play_item.setPath(None)
        elif 'harpalgeo.' in vid_url:
            site = 'geo'
            scraper = manual_function_import(f'resources.scrapers.{site}', f'{site}')
            stream_url = scraper.get_video(vid_url)
            play_item.setPath(stream_url)
        elif 'hum.tv' in vid_url:
            site = 'hum'
            scraper = manual_function_import(f'resources.scrapers.{site}', f'{site}')
            stream_url = scraper.get_video(vid_url)
            if stream_url:
                embeds = ['youtube.', 'dailymotion', 'youtu.be']
                if any(x for x in embeds if x in stream_url):
                    stream_url, _ = resolve_url(stream_url)
                if stream_url:
                    play_item.setPath(stream_url)
                else:
                    play_item.setPath(None)
            else:
                play_item.setPath(None)
        elif 'playembed.' in vid_url or 'videoapne.' in vid_url or '.m3u8' in vid_url:
            stream_url = vid_url
            play_item.setPath(stream_url)
        elif 'load.' in vid_url:
            stream_url, _ = resolve_url(vid_url)
            if stream_url:
                play_item.setPath(stream_url)
            else:
                play_item.setPath(None)
        elif '.mp4' in vid_url:
            if '|' not in vid_url and check_hosted_media(vid_url):
                stream_url, _ = resolve_url(vid_url)
            else:
                stream_url = vid_url
            if stream_url:
                play_item.setPath(stream_url)
            else:
                play_item.setPath(None)
        else:
            stream_url = vid_url
            play_item.setPath(stream_url)
    else:
        stream_url, subtitles = resolve_url(vid_url, subs=True)
        log(f'-------> from play_video from resolver {type(stream_url)} stream_url: {repr(stream_url)}', 'debug')
        if stream_url:
            play_item.setPath(stream_url)
            if subtitles:
                play_item.setSubtitles(list(subtitles.values()))
        else:
            # play_item.setPath(None)
            return

    if dl and stream_url:
        log(f'-------> from play_video IN downloadVideo: {title} stream_url: {stream_url}', 'debug')
        download_video_resilient(stream_url, title)

    elif stream_url:
        # non_ia = ['yupp', 'SUNNXT', 'tamilgun', 'vidmojo', 'serafim', '__temp_', 'cloud', 'gomovies', 'proxysite', 'dailymotion']
        log(f'-------> from play_video Out stream_url: {stream_url}', 'debug')
        stream_plugin = get_setting('stream_plugin')
        if stream_plugin and any(x in stream_url for x in ['master', 'adaptive', 'tamilray', 'index', 'playallu', 'thrfive', 'video', 'v1lst', 'turbovi', 'hls-vod', 'cdn', 'm3u8', 'mpd', 'ism', 'hls']):
            play_item = set_inputstream(play_item, stream_url, stream_plugin)
        setResolvedUrl(_handle, True, listitem=play_item)
    return
