"""
VodProxy
based on XBMCLocalProxy by
Copyright 2011 Torben Gerkensmeyer

Modified by jairoxyz 2021

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
MA 02110-1301, USA.
"""

import sys
import traceback
import errno
import threading
import socket
import requests
import base64

from six import PY3
from kodi_six import xbmc, xbmcgui
from six.moves import urllib_parse
from six.moves.BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
from six.moves.socketserver import ThreadingMixIn

import ssl
from urllib3.poolmanager import PoolManager
from requests.adapters import HTTPAdapter

# HTTPServer errors
ACCEPTABLE_ERRNO = (
    errno.ECONNABORTED,
    errno.ECONNRESET,
    errno.EINVAL,
    errno.EPIPE,
)
try:
    ACCEPTABLE_ERRNO += (errno.WSAECONNABORTED,)
except AttributeError:
    pass  # Not windows


# TLS 1.2 adapter for CF sites that don't accept TLS 1.3
class TLS12HttpAdapter(HTTPAdapter):
    """Transport adapter that forces the use of TLS v1.2."""
    def init_poolmanager(self, connections, maxsize, block=False):
        tls = ssl.PROTOCOL_TLSv1_2 if PY3 else ssl.PROTOCOL_TLSv1
        self.poolmanager = PoolManager(
            num_pools=connections, maxsize=maxsize,
            block=block, ssl_version=tls)


class MyHandler(BaseHTTPRequestHandler):
    handlerStop = threading.Event()
    handlerStop.clear()

    def log_message(self, format, *args):
        pass

    """
    Serves a HEAD request
    """
    def do_HEAD(self):
        # ccurl detects mime type via head
        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.apple.mpegurl")
        self.end_headers()
        return

    """
    Serves a GET request.
    """
    def do_GET(self):
        try:
            # request_path = self.path[1:]
            parsed_path = urllib_parse.urlparse(urllib_parse.unquote(self.path))
            path = parsed_path.path[1:]
            hdrs = None

            try:
                params = dict(urllib_parse.parse_qsl(parsed_path.query))
            except:
                self.send_response(404)
                self.end_headers()
                self.wfile.write('URL malformed or stream not found!')
                return

            if path == "servevod/":
                vod = params.get('vod')
                isPNG = params.get('png')
                isLocal = params.get('local')
                isTS = params.get('isTS')
                hdrs = params.get('hdrs')
                try:
                    hdrs = base64.b64decode(hdrs.encode("Utf-8")).decode("Utf-8")
                except:
                    pass
                if not isPNG or isPNG != 'true':
                    self.serveVOD(vod)
                else:
                    self.restreamVOD(vod, isLocal, isTS, hdrs)
                return

            else:
                self.send_response(404)
                self.end_headers()
        except:
            traceback.print_exc()
            self.send_response(500)
            self.end_headers()
        finally:
            return

    def serveVOD(self, vodfile):
        try:
            vodfile = vodfile.replace("vod://", "")
            vod = open(vodfile, "r").read()
            vod = vod.encode() if PY3 else vod
            self.send_response(200)
            self.send_header("Content-Type", "application/vnd.apple.mpegurl")
            self.end_headers()
            self.wfile.write(vod)
            self.wfile.flush()
            # self.wfile.close()

        except socket.error:
            pass

        except Exception as err:
            # traceback.print_exc()
            self.handlerStop.set()
            xbmc.log('[VODProxy] could not open playlist: {0}'.format(err))

    def restreamVOD(self, link, local, isTS, headers):
        try:
            isTS = isTS is not None and isTS == "true"
            prx = f'http://{VODProxy.HOST_NAME}:{VODProxy.PORT_NUMBER}/servevod/?vod='
            base = f'{urllib_parse.urlparse(link)[0]}://{urllib_parse.urlparse(link)[1]}'

            link = link.replace("vod://", "")
            scode = 0
            s = requests.Session()

            if headers is None: headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36"}
            else:
                try:
                    headers_ = headers.split("&")
                    headers__ = {header_.split("=")[0].strip(): header_.split("=")[1].strip() for header_ in headers_}
                    headers = headers__
                except:
                    pass

            if local is not None and local == 'true':
                txt = open(link, "r").read()
                # headers = None
                local = True
            else:
                r = s.get(link, stream=isTS, headers=headers, allow_redirects=True)
                scode = r.status_code

                # force TLS 1.2 connection for older CF sites
                if scode == 403 and "cloudflare" in r.headers.get('Server').lower():
                    s.mount("https://", TLS12HttpAdapter())  # force TLS1.2
                    r = s.get(link, stream=isTS, headers=headers, allow_redirects=True)
                    scode = r.status_code

                # headers = {header.lower(): r.headers[header] for header in r.headers}
                local = False

            # print("[VODPROXY]    " + repr(headers))
            if scode >= 400:
                self.send_response(scode)
                self.end_headers()
                self.wfile.flush()
            elif isTS:
                ct = 'video/mp2t'
                headers = {header.lower(): r.headers[header] for header in r.headers}
                self.send_response(200)
                self.send_header('Content-Type', ct)
                try: self.send_header("Content-Length", headers['content-length'])
                except: pass
                self.end_headers()
                rmhead = 1
                # for line in r.iter_lines():
                for chunk in r.iter_content(chunk_size=102400):
                    # print("[VODPROXY]    " + repr(chunk[:50]))
                    if rmhead == 1:
                        self.wfile.write(chunk.lstrip(b'\x89\x50\x4E\x47\x0D\x0A\x1A\x0A'))
                        rmhead = 0
                    else: self.wfile.write(chunk)
                    self.wfile.flush()
            else:
                ct = "application/vnd.apple.mpegurl"
                if not local: txt = r.text
                data = txt.splitlines()
                lines = ""

                self.send_response(200)
                self.send_header("Content-Type", ct)
                # self.send_header("Content-Length", cl)
                # self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                hdrs_ = base64.b64encode(urllib_parse.urlencode(headers).encode("Utf-8")).decode("Utf-8")
                for line in data:
                    if line.startswith("#EXT"): pass
                    elif line.startswith("/"):
                        # print(prx + base + line)
                        line = prx + base + line
                        line += (
                            f"&png=true&local=false&isTS=true&hdrs={hdrs_}"
                            if "#EXTINF:" in txt
                            else ""
                        )
                    elif line.startswith("http"):
                        # print(prx + line)
                        line = prx + line
                        line += (
                            f"&png=true&local=false&isTS=true&hdrs={hdrs_}"
                            if "#EXTINF:" in txt
                            else ""
                        )
                    line += "\n"
                    lines += line
                self.wfile.write(lines.encode() if PY3 else lines)
                self.wfile.flush()

        except socket.error:
            pass

        except Exception as err:
            traceback.print_exc()
            self.handlerStop.set()
            xbmc.log('[VODProxy] could not open playlist: {0}'.format(err))



class Server(HTTPServer):
    """HTTPServer class with timeout."""
    timeout = 5

    def finish_request(self, request, client_address):
        """Finish one request by instantiating RequestHandlerClass."""
        try:
            self.RequestHandlerClass(request, client_address, self)
        except socket.error as err:
            if err.errno not in ACCEPTABLE_ERRNO:
                raise


class ThreadedHTTPServer(ThreadingMixIn, Server):
    """Handle requests in a separate thread."""
    allow_reuse_address = True
    daemon_threads = True


class VODProxy():
    HOST_NAME = '127.0.0.1'
    PORT_NUMBER = 45678
    ready = threading.Event()

    def start(self, stopEvent):
        self.ready.clear()
        sys.stderr = sys.stdout
        server_class = ThreadedHTTPServer
        MyHandler.handlerStop = stopEvent
        httpd = server_class((self.HOST_NAME, self.PORT_NUMBER), MyHandler)
        xbmc.log(f"[VODProxy] Service started - {self.HOST_NAME}:{self.PORT_NUMBER}.")

        while not stopEvent.isSet():
            httpd.handle_request()
            self.ready.set()

        httpd.server_close()
        self.ready.clear()
        xbmc.log('[VODProxy] Service stopped.')

    def stop(self):
        pass

    def status(self):
        pass


class VODProxy_Helper():

    def getKodiVersion(self):
        return xbmc.getInfoLabel("System.BuildVersion").split(".")[0]

    def playVOD(self, vod, listitem):
        print(f'VOD {vod}')
        stopPlaying = threading.Event()
        stopPlaying.clear()
        progress = xbmcgui.DialogProgress()
        progress.create('Starting VODProxy')
        progress.update(10, 'Loading VOD playlist')

        vod_proxy = VODProxy()
        hdrs = "|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36"
        qhdrs = ""
        try:
            vod, hdrs = vod.split("|")
            qhdrs = f'&hdrs={base64.b64encode(hdrs.encode("Utf-8")).decode("Utf-8")}'
            hdrs = f'|{hdrs}'
        except:
            # traceback.print_exc()
            pass

        url_to_play = 'http://{0}:{1}/{2}/?vod={3}'.format(
            vod_proxy.HOST_NAME,
            vod_proxy.PORT_NUMBER,
            "servevod",
            urllib_parse.quote(vod + qhdrs) + hdrs
        )
        threading.Thread(target=vod_proxy.start, args=(stopPlaying,)).start()
        proxyReady = vod_proxy.ready

        progress.update(20)
        xbmc.sleep(200)
        p = 30
        while p < 100:
            if proxyReady.isSet():
                progress.update(90)
                break
            progress.update(p)
            xbmc.sleep(200)
            p += 10

        listitem.setPath(url_to_play)
        mplayer = MyPlayer()
        mplayer.stopPlaying = stopPlaying
        mplayer.play(url_to_play, listitem)
        progress.update(100)
        progress.close()
        played = False

        while not stopPlaying.isSet():
            if xbmc.Player().isPlaying():
                played = True
            xbmc.log('[VODProxy] busy working ...')
            xbmc.sleep(1000)

        return played


class MyPlayer (xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)

    def play(self, url, listitem):
        # print 'Now im playing... %s' % url
        self.stopPlaying.clear()
        xbmc.Player().play(url, listitem)

    def onPlayBackEnded(self):
        # Will be called when xbmc stops playing a file
        # print "seting event in onPlayBackEnded "
        self.stopPlaying.set()
        # print "stop Event is SET"

    def onPlayBackStopped(self):
        # Will be called when user stops xbmc playing a file
        # print "seting event in onPlayBackStopped "
        self.stopPlaying.set()
        # print "stop Event is SET"

    def onPlayBackError(self):
        self.stopPlaying.set()

    def onPlayBackStarted(self):
        # xbmc.executebuiltin("Dialog.Close(busydialog)")
        pass
