'''
thiruttuvcd deccandelight plugin
Copyright (C) 2016 Gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
from resources.lib.base import Scraper
from bs4 import BeautifulSoup, SoupStrainer
import re
import requests


class tvcd(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'https://thiruttuvcd.info/genre/'
        self.icon = self.ipath + 'tvcd.png'
        self.list = {'01Tamil Movies': self.bu + 'tamil-movies/',
                     '02Telugu Movies': self.bu + 'telugu-movies/',
                     '03Malayalam Movies': self.bu + 'malayalam-movies/',
                     '04Kannada Movies': self.bu + 'kannada-movies/',
                     '05Hindi Movies': self.bu + 'hindi-movies/',
                     '09English Movies': self.bu + 'english-movies/',
                     '99[COLOR yellow]** Search **[/COLOR]': self.bu[:-6] + '?s='}

    def get_menu(self):
        return (self.list, 7, self.icon)

    def get_items(self, url):
        h = HTMLParser.HTMLParser()
        movies = []
        if url[-3:] == '?s=':
            search_text = self.get_SearchQuery('Thiruttu VCD')
            search_text = urllib.quote_plus(search_text)
            url = url + search_text

        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('div', {'class': 'item_1 items'})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        plink = SoupStrainer('div', {'class': 'pag_b'})
        Paginator = BeautifulSoup(html, parseOnlyThese=plink)
        items = mdiv.findAll('div', {'class': 'item'})

        for item in items:
            title = h.unescape(item.find('span', {'class': 'tt'}).text).encode('utf8')
            url = item.find('a')['href']
            try:
                thumb = item.find('img')['src']
            except:
                thumb = self.icon
            movies.append((title, thumb, url))

        if 'next' in Paginator.text.lower():
            purl = Paginator.find('a').get('href')
            plink = SoupStrainer('div', {'class': 'paginado'})
            pages = BeautifulSoup(html, parseOnlyThese=plink)
            currpg = pages.find('a', {'class': 'current'}).text
            lastli = pages.findAll('li')[-1]
            lastpg = lastli.find('a').get('href').split('/')[-2]
            title = 'Next Page.. (Currently in Page {0} of {1})'.format(currpg, lastpg)
            movies.append((title, self.nicon, purl))

        return (movies, 8)

    def get_videos(self, url):
        videos = []

        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('div', {'id': 'player2'})
        videoclass = BeautifulSoup(html, parseOnlyThese=mlink)

        try:
            links = videoclass.findAll('iframe')
            for link in links:
                vidurl = link.get('src')
                self.resolve_media(vidurl, videos)
        except:
            pass

        return videos
