"""
rajtamil deccandelight plugin
Copyright (C) 2016 Gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
"""
from resources.lib.base import Scraper
from bs4 import BeautifulSoup, SoupStrainer
import requests
import re


class rajt(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.icon = self.ipath + 'rajt.png'
        self.bu = 'https://www.rajtamil.me/category/'
        self.list = {'01Recent Movies': self.bu + 'new-movies/',
                     '02HD Movies': self.bu + 'hd-movies/',
                     '03Dubbed Movies': self.bu + 'dubbed-movies/',
                     '04Malayalam Movies': self.bu + 'malayalam-movies/',
                     '05Telugu Movies': self.bu + 'telugu-movies/',
                     '06Hindi Movies': self.bu + 'hindi-movies/',
                     '07Trailers': self.bu + 'trailers/',
                     '98[COLOR cyan]Adult Movies[/COLOR]': self.bu + 'hot-masala/',
                     '99[COLOR yellow]** Search **[/COLOR]': self.bu[:-9] + '?s='}

    def get_menu(self):
        return (self.list, 7, self.icon)

    def get_items(self, url):
        movies = []
        if url[-3:] == '?s=':
            search_text = self.get_SearchQuery('Raj Tamil')
            search_text = urllib.quote_plus(search_text)
            url = url + search_text

        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('ul', {'class': re.compile('^listing-videos')})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        plink = SoupStrainer('div', {'class': 'pagination'})
        Paginator = BeautifulSoup(html, parseOnlyThese=plink)
        items = mdiv.findAll('li')
        for item in items:
            title = item.find('a')['title']
            title = self.clean_title(title)
            url = item.find('a')['href']
            try:
                thumb = item.img.get('src')
            except:
                thumb = self.icon
            movies.append((title, thumb, url))

        if 'next' in Paginator.text.lower():
            pdivs = Paginator.findAll('a', {'class': None})
            for pdiv in pdivs:
                if 'next' in pdiv.text.lower():
                    purl = pdiv.get('href')
            pgtxt = Paginator.find('span', {'class': None}).text
            title = 'Next Page.. (Currently in {})'.format(pgtxt)
            movies.append((title, self.nicon, purl))

        return (movies, 8)

    def get_videos(self, url):
        videos = []

        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('div', {'class': 'video-embed'})
        videoclass = BeautifulSoup(html, parseOnlyThese=mlink)

        try:
            links = videoclass.findAll('iframe')
            for link in links:
                url = link.get('src').strip()
                self.resolve_media(url, videos)
        except:
            pass

        return videos
