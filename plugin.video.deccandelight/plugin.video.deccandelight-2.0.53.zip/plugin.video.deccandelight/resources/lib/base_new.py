# -*- coding: utf-8 -*-
"""
Base deccandelight Scraper class (modernized core)
"""

import ast
import base64
import html as _html_parser
import json
import re
import threading
import time
from functools import lru_cache
from traceback import print_exc
from urllib.parse import quote_plus, unquote, urlencode, urljoin, urlparse

from bs4 import BeautifulSoup, SoupStrainer
import xbmcvfs

from resources.lib import client, control, jsunpack, unjuice
from resources.lib.control import TRANSLATEPATH, _ppath, check_hosted_media, get_setting, keyboard as kboard, log, pathExists


# Precompiled regex registry

def R(pattern, flags=0):
    return re.compile(pattern, flags)

I = re.I
D = re.DOTALL
ID = re.I | re.DOTALL

REGEX = {
    "add_url": R(r"facebook|twitter|pinterest|protection|tumblr|reddit"),
    "video_id": R(r"(id|url|v|si|sin|sim|data-config|file|dm|wat|vid)=(.+?)##"),
    "form_action": R(r'<form.+?action="([^"]+)', ID),
    "hidden_inputs": R(r"type='hidden'\s*name='([^']+)'\s*value='([^']+)", ID),
    "_inputs": R(r'''input.*?name=["'](.+?)["'].+?value=["'](.+?)["']''', ID),
    "refresh_meta": R(r'http-equiv="refresh".+?url=([^"]+)', ID),
    "iframe_src": R(r'<iframe[^>]+?src=["\']([^"\']+)', ID),
    "atob": R(r"atob\(['\"]([^'\"]+)", I),
    "magnet_quality": R(r"([\d\.\s]+\d(?:p|mb|gb))", I),

    "groundbanks_button": R(r"<a\s*href='([^']+)'\s*class='button", I),

    "xdownex_links": R(r'<strong.+\n<a\s*href="([^"]+)', I),
    "watchlinkx_button": R(r'class="main-button[^>]+?href="([^"]+)', I),

    "filelinkzr_button": R(r'<a\s*class="mb-ton\s*ndton"\s+href="([^"]+)', ID),

    "filmshow_embed_url": R(r"var\s*height.+?url:\s*'([^']+)", D),
    "filmshow_nonce": R(r"var\s*height.+?nonce.+?'([^']+)", D),
    "filmshow_link_id": R(r"var\s*height.+?link_id:\s*([^\s]+)", D),
    "filmshow_http": R(r"(http[^\"]+)", I),

    "jw_media_id": R(r"/([^/]+?)(?:-[^/]*)?$"),
    "jw_config": R(r"config\s*=\s*([^;]+)", I),

    "justmovies_file": R(r'file":"(.*?)"', I),
    "justmovies_source": R(r'source src=["\'](.*?)["\']', I),

    "videohost_run": R(r"Run\((.*?)\)", ID),
    "videohost_sources": R(r"sources:(.*?\}\])", ID),

    "videohost2_array": R(r"Loading video.+?(\[.+?\]);", ID),

    "videohost2_source": R(r"source\ssrc='([^']+)", I),

    "hindistop_source": R(r'source:\s*"([^"]+)', I),

    "arivakam_file": R(r'"file":"([^"]+)', I),
    "arivakam_linkserver": R(r'"linkserver".+?video="([^"]+)', I),
    "arivakam_api_movie": R(r"/([^/]+)$"),

    "thrfive_config": R(r"config\s*=\s*([^;]+)", I),
    "tamildbox_domain_stream": R(r"domainStream\s*=\s*([^;]+)", I),
}


# Helpers: caching, parsing, normalization

def get_findall(pattern, shtml):
    return re.findall(pattern, shtml, re.I|re.DOTALL)

# Cached network layer (simple in‑memory)

@lru_cache(maxsize=256)
def _cached_request(url, headers_key, output=None, **kwargs):
    headers = dict(headers_key)
    return client.request(url, headers=headers, output=output, **kwargs)

def cached_request(url, headers, output=None, **kwargs):
    key = tuple(sorted(headers.items()))
    return _cached_request(url, key, output=output, **kwargs)


def parse_html(html, tag=None, attrs=None):
    if tag:
        return BeautifulSoup(html, "html.parser", parse_only=SoupStrainer(tag, attrs))
    return BeautifulSoup(html, "html.parser")


def normalize_url(url: str) -> str:
    if url.startswith("//"):
        url = "https:" + url
    url = url.replace("www.hindistoponline.com", "hindigostop.com")
    return url


# Handler registry / dispatcher

HANDLERS = []  # list[(pattern: str, func)]


def handler(pattern):
    def decorator(func):
        HANDLERS.append((pattern, func))
        return func
    return decorator


def handler_list(patterns):
    def decorator(func):
        for p in patterns:
            HANDLERS.append((p, func))
        return func
    return decorator


def dispatch(url):
    for pattern, func in HANDLERS:
        if pattern in url:
            return func
    return None


STRAINERS = {
    # Generic patterns
    "entry_content":      ("div", {"class": re.compile(r"^entry-content")}),
    "video_player":       ("div", {"class": re.compile(r"^video-player-content")}),
    "player_api":         ("div", {"class": "player-api"}),
    "player_embed":       ("div", {"id": "player-embed"}),
    "item_content":       ("div", {"class": re.compile(r"^item-content")}),
    "aio_pulse":          ("div", {"class": "aio-pulse"}),
    "entry_content_link": ("div", {"class": re.compile("entry-content")}),
    "proceed":            ("div", {"id": "Proceed"}),
    "entry_content_div":  ("div", {"class": "entry-content"}),

    # You can add more as you discover patterns
}

def strained_key(html, key):
    '''usages: videoclass = strained_key(html, 'entry_content')
    '''
    tag, attrs = STRAINERS[key]
    return BeautifulSoup(html, "html.parser", parse_only=SoupStrainer(tag, attrs))

def strained(scraper, html, key=None, tag=None, attrs=None, pattern=None):
    """
    Unified SoupStrainer loader with registry + debug logging.
    Priority:
        1. key from STRAINERS registry
        2. tag + attrs
        3. tag + pattern (regex)
    useges:
    videoclass = strained(self, html, key="entry_content")
    dclass = strained(self, link, key="player_embed")
    dclass = strained(self, link, key="item_content")

    """
    if key:
        tag, attrs = STRAINERS[key]
        if getattr(scraper, "debug_strainers", False):
            scraper.log(f"[DEBUG] strained fired key='{key}' tag='{tag}' attrs='{attrs}'")
        return BeautifulSoup(html, "html.parser", parse_only=SoupStrainer(tag, attrs))

    if pattern:
        attrs = attrs or {}
        attrs["class"] = re.compile(pattern)

    if getattr(scraper, "debug_strainers", False):
        scraper.log(f"[DEBUG] strained fired tag='{tag}' attrs='{attrs}'")

    return BeautifulSoup(html, "html.parser", parse_only=SoupStrainer(tag, attrs))

def convert_to_string(value):
    # Case 1 & 3: Already a string (or a string representation of bytes)
    if isinstance(value, str):
        # Quick check for "b'...' " or 'b"..." '
        if value.startswith(("b'", 'b"')) and value.endswith(value[1]):
            try:
                # Slicing and decoding is much faster than ast.literal_eval
                return value[2:-1].encode('latin-1').decode('unicode_escape')
            except (UnicodeEncodeError, UnicodeDecodeError):
                return str(value)
        return str(value)

    # Case 2: Actual bytes/byte-like or bytearray
    if isinstance(value, (bytes, bytearray)):
        try:
            return value.decode('utf-8')
        except UnicodeDecodeError as e:
            log(f'convert_to_string decode error: {e}', 'debug')
            return str(value)

    # Fallback for all other types (int, list, None, etc.) unexpected types
    log(f'convert_to_string Unsupported type: {type(value)}', 'debug')
    return str(value)


# Debug / timing helpers

def log_timing(scraper, handler_name, start_ts, url):
    elapsed = (time.time() - start_ts) * 1000.0
    scraper.log(f'resolve_media handler="{handler_name}" url="{url}" elapsed_ms={elapsed:.2f}')

def debug_handler_log(scraper, handler_name, url, before_count, after_count, elapsed_ms):
    if not getattr(scraper, "debug_handlers", False):
        return
    scraper.log(
        f'[DEBUG] handler="{handler_name}" url="{url}" '
        f'links_added={after_count - before_count} elapsed_ms={elapsed_ms:.2f}'
    )


# Static lists (used by multiple handlers)

NON_STREAM_HOSTS = [
    'olangal.', 'desihome.', 'thiruttuvcd', '.filmlinks4u', '#', '/t.me/',
    'cineview', 'bollyheaven', 'videolinkz', 'moviefk.co', 'goo.gl', '/ads/',
    'imdb.', 'mgid.', 'atemda.', 'movierulz.ht', 'facebook.', 'twitter.',
    'm2pub', 'abcmalayalam', 'india4movie.co', 'embedupload.', 'bit.ly',
    'tamilraja.', 'multiup.', 'filesupload.', 'fileorbs.', 'tamil.ws',
    'insurance-donate.', '.blogspot.', 'yodesi.net', 'desi-tashan.',
    'yomasti.co/ads', 'ads.yodesi', 'mylifeads.', 'yaartv.', '/cdn-cgi/',
    'steepto.', '/movierulztv', '/email-protection', 'oneload.xyz', 'about:',
    'google.com', 'whatsapp.com', 'linkedin.com',
]

APNEEMBED = [
    'newstalks.co', 'newstrendz.co', 'newscurrent.co', 'newsdeskroom.co',
    'newsapne.co', 'newshook.co', 'newsbaba.co', 'articlesnewz.com',
    'articlesnew.com', 'webnewsarticles.com', 'htnews.me', 'gamewisetalks.com',
]

EMBED_LIST = [
    'cineview', 'bollyheaven', 'videolinkz', 'vidzcode', 'factualestates.',
    'embedzone', 'embedsr', 'fullmovie-hd', 'links4.pw', 'esr.', 'escr.',
    'embedscr', 'embedrip', 'movembed', 'power4link.us', 'adly.biz', 'kedne.',
    'watchmoviesonline4u', 'nobuffer.info', 'yomasti.co', 'myminiaturez.',
    'techking.me', 'onlinemoviesworld.xyz', 'cinebix.com', 'vids.xyz',
    'desihome.', 'loan-', 'filmshowonline.', 'hinditwostop.', 'media.php',
    'hindistoponline', 'telly-news.', 'tellytimes.', 'tellynews.', 'tvcine.',
    'business-', 'businessvoip.', 'toptencar.', 'serialinsurance.', 'bestarticles.',
    'youpdates', 'loanadvisor.', 'tamilray.', 'embedrip.', 'xpressvids.',
    'beststopapne.', 'bestinforoom.', '?trembed=', 'tamilserene.', 'articleweb.',
    'tvnation.', 'techking.', 'etcscrs.', 'etcsr1.', 'etcrips.', ' etcsrs.',
    'tvpost.cc', 'tellygossips.', 'tvarticles.', 'insurancehubportal.', 'hd-rulez.',
    'directlinktx.', 'filmstream2x.com', 'watchlinksinfo.com', 'esportarenahub.',
    'videoemx2.com', 'movierulz.io', 'coinztechnews.', 'thegadgetsreviewer.',
    'starscopsinsider.', 'dailyeduhub.', 'post.php?id=',
]

GO_CLOC_LIST = [
    'go.clockks.com', 'go.tellynewsarticles.com',
    'go.articlewebnews.com', 'go.newsdeskroom.co',
]


# Scraper class (core + resolve_media dispatcher wrapper)

class Scraper(object):

    def __init__(self):
        self.ipath = control._ipath
        self.hdr = control.mozhdr
        self.dhdr = control.droidhdr
        self.jhdr = control.jiohdr
        self.ihdr = control.ioshdr
        self.chdr = control.chromehdr
        self.PY2 = control.PY2
        self.parser = _html_parser
        self.settings = get_setting
        self.adult = get_setting('adult') == 'true'
        self.mirror = get_setting('mirror') == 'true'
        self.nicon = f'{self.ipath}next.png'
        self.hmf = check_hosted_media
        self.log = log

        # debug flags
        self.debug_handlers = get_setting('debug_enabled') == 'true'
        self.debug_strainers = get_setting('debug_strainers') == 'true'

    class Thread(threading.Thread):
        def __init__(self, target, *args):
            threading.Thread.__init__(self)
            self._target = target
            self._args = args

        def run(self):
            self._target(*self._args)

        def terminate(self):
            pass

    def get_nicon(self):
        return self.nicon

    @staticmethod
    def store(ftext, fname):
        fpath = TRANSLATEPATH(_ppath) + fname
        with open(fpath, 'w', encoding='utf-8') as f:
            f.write(ftext)

    @staticmethod
    def retrieve(fname):
        fpath = TRANSLATEPATH(_ppath) + fname
        if pathExists(fpath):
            with open(fpath, encoding='utf-8') as f:
                ftext = f.readlines()
            return '\n'.join(ftext)
        else:
            return None

    @staticmethod
    def get_SearchQuery(sitename):
        keyboard = kboard()
        keyboard.setHeading(f'Search {sitename}')
        keyboard.doModal()
        if keyboard.isConfirmed():
            return keyboard.getText()
        return

    @staticmethod
    def get_vidhost(url):
        parts = url.split('/')[2].split('.')
        return f'{parts[len(parts) - 2]}.{parts[len(parts) - 1]}'

    @staticmethod
    def b64decode(text):
        return convert_to_string(base64.b64decode(text))

    @staticmethod
    def b64encode(text):
        return convert_to_string(base64.b64encode(bytes(text)))

    @staticmethod
    def clean_title(title):
        items = 'watch|online|movie|onilne|tamil|dubbed|free|full|length|latest|telugu|rip|dvdrip|dvdscr|uncensored|hd|downlaod|bluray|malayalam|movies|wach|songs|hindi|korean|hilarious|comedy|scenes|super|ultimate|bdrip|todaypk|sun|tv|show|vijay|film|download|starring|horror|hdrip|audio|pdvdrip|hq|brrip|pre hdrip|predvdrip|webrip|punjabi|tcrip|hdtvrip|hd|tc|hdtv|tvrip|720p|dvd|uncut|clear|dthrip|line|kannada|hollywood|ts|cam|streaming|permalink|english|bengali|bhojpuri|print|amzn|scr|web|gujarati|webdl|esubs'
        title = re.sub(r'([:;\-"\',!_.?~$@])', '', title)
        title = re.sub(items, ' ', title, flags=re.I)
        title = re.sub(r'\s+', ' ', title, flags=re.I)
        title = title.strip()
        return title.title()

    @staticmethod
    def unescape(title):
        return _html_parser.unescape(title)

    @staticmethod
    def playallu(eurl, referer):
        from resources.lib.jscrypto import jscrypto
        import binascii
        import hashlib

        def pencode(c, m):
            i = jscrypto.encode(c, m)
            f = base64.b64decode(i)
            i = binascii.hexlify(f)
            return convert_to_string(i)

        def pdecode(i, f):
            y = binascii.unhexlify(i)
            b = base64.b64encode(y)
            k = jscrypto.decode(b, f)
            return k

        headers = control.mozhdr
        refurl = urljoin(referer, '/')
        pref = urljoin(eurl, '/')
        headers.update({'Referer': refurl})
        epage = client.request(eurl, headers=headers)
        if isinstance(epage, bytes):
            epage = epage.decode('latin-1')

        try:
            idfile_enc = re.findall(r'''idfile_enc\s*=\s*["']([^"']+)''', epage)[0]
            iduser_enc = re.findall(r'''idUser_enc\s*=\s*["']([^"']+)''', epage)[0]
            dev_play = re.findall(r'''DEV_PLAY\s*=\s*["']([^"']*)''', epage)[0]
            apiurl = re.findall(r'''DOMAIN_API\s*=\s*["']([^"']+)''', epage)[0]

            idfile_dec = pdecode(idfile_enc, 'jcLycoRJT6OWjoWspgLMOZwS3aSS0lEn')
            iduser_dec = pdecode(iduser_enc, 'PZZ3J3LDbLT0GY7qSA5wW5vchqgpO36O')

            pdata = {
                "idfile": idfile_dec,
                "iduser": iduser_dec,
                "domain_play": "https://my.9stream.net" if dev_play == "thang" else refurl[:-1],
                "platform": "Win32",
                "hlsSupport": True
            }
            z = pencode(json.dumps(pdata), 'vlVbUQhkOhoSfyteyzGeeDzU0BHoeTyZ')
            w = binascii.hexlify(hashlib.md5(bytes(z + b'KRWN3AdgmxEMcd2vLN1ju9qKe8Feco5h')).digest())
            data = {'data': z + '|' + convert_to_string(w)}
            headers.update({'Referer': pref, 'Origin': pref[:-1]})
            jd = json.loads(client.request(apiurl + '/playiframe', headers=headers, post=data))
            mfile = pdecode(jd.get('data'), 'oJwmvmVBajMaRCTklxbfjavpQO7SZpsL')
            return 'Playallu', mfile + '|' + urlencode(headers)
        except:
            log(f'>>>>  In url: {eurl}\ngives epage: {epage}')
            return None, None

    def getVideoID(self, url):
        try:
            return REGEX["video_id"].findall(f'{url}##')[0][1]
        except Exception:
            return

    def get_mod_url(self, url):
        url_id = self.getVideoID(url)
        if not url_id: return None
        if 'vkprime.php' in url: return f'http://vkprime.com/embed-{url_id}.html'
        elif 'vkspeed.php' in url: return f'http://vkspeed.com/embed-{url_id}.html'
        elif 'speed.php' in url: return f'http://vkspeed.com/embed-{url_id}-600x380.html'
        return None

    def apne_twostop(self, url, headers):
        headers = {**self.hdr, **headers}
        html = client.request(url, headers=headers)
        try:
            # urltopost = re.search(r'''<form.*action=["'](.+?)["']''', html)[1]
            urltopost = REGEX["form_action"].findall(html)[-1]
            # inputNameValue = re.compile(r'''input.*?name=["'](.+?)["'].+?value=["'](.+?)["']''', re.M)
            # formFields = inputNameValue.findall(html)
            formFields = REGEX["_inputs"].findall(html)
            postFields = {
                field[0].encode("ascii"): field[1].encode("ascii")
                for field in formFields
            }
            self.log(f'0 postFields: {postFields}', 'debug')
            html = client.request(urltopost, post=postFields, headers=headers)
            return html
        except Exception as e:
            self.log(f'apne_twostop Error: {e} traceback: {print_exc()}', 'error')
            return

    def refresh_redirect(self, url, headers):
        refresh = True
        html = ''
        while refresh:
            r = client.request(url, headers=headers, output='extended')
            html = r[0]
            response_headers = r[2]
            if response_headers.get('Refresh'):
                url = response_headers.get('Refresh').split(' ')[-1]
            elif 'http-equiv="refresh"' in html:
                url = self.parser.unescape(
                    REGEX["refresh_meta"].findall(html)[0]
                )
            else:
                refresh = False
        return url, str(html)

    def form_action(self, url, headers, bhtml):
        try:
            r = REGEX["form_action"].findall(bhtml)
            if r:
                purl = r[-1]
                headers = {**headers, 'Referer': url, 'Origin': urljoin(url, '/')[:-1],}
                r1 = REGEX["hidden_inputs"].findall(bhtml)
                pd = dict(r1) if r1 else ' '
                bhtml2 = client.request(purl, post=pd, headers=headers)
                s = REGEX["iframe_src"].findall(bhtml2)
                if s:
                    return s
                r = REGEX["form_action"].findall(bhtml2)
                if r:
                    purl = r[-1]
                    headers.update({'Referer': url, 'Origin': urljoin(url, '/')[:-1],})
                    r1 = REGEX["hidden_inputs"].findall(bhtml2)
                    pd = {x: y for x, y in r1} if r1 else ' '
                    ehtml = client.request(purl, post=pd, headers=headers)
                    s = REGEX["iframe_src"].findall(ehtml)
                    if s:
                        return s
                    else:
                        self.log(f'form_action no purl: {purl} ehtml\n{ehtml}')
            else:
                s = REGEX["iframe_src"].findall(bhtml)
                if s:
                    return s
                else:
                    self.log(f'form_action no purl: {url} bhtml2\n{bhtml}')
        except Exception as e:
            self.log(f'form_action Error: {e} traceback: {print_exc()}', 'error')
        return

    def _build_headers(self, url):
        headers = {}
        if '|' in url:
            url, hdrs = url.split('|', 1)
            for hitem in hdrs.split('&'):
                if '=' in hitem:
                    hdr, value = hitem.split('=', 1)
                    headers[hdr] = value
        return url, headers

    # New resolve_media wrapper using dispatcher

    def resolve_media(self, url, videos, vidtxt=''):
        self.log(f'>>>> base_new.py resolve_media In url: {url}')
        if REGEX["add_url"].search(url): return
        # if re.search(r'facebook|twitter|pinterest|protection|tumblr|reddit', str(url), re.IGNORECASE):
            # return

        # magnet handling stays inline (no HTTP)
        if url.startswith('magnet:') and self.hmf(url):
            vidhost = '[COLOR red]Magnet[/COLOR]'
            r = REGEX["magnet_quality"].findall(url.replace('%20', ' '))
            if r:
                vidhost = f'{vidhost} [COLOR gold]{" | ".join(r)}[/COLOR]'
            if vidtxt:
                vidhost += f' | {vidtxt}'
            if (vidhost, url) not in videos:
                videos.append((vidhost, url))
            return

        if not url.startswith('http'):
            return

        if any(x in url for x in NON_STREAM_HOSTS):
            return
        # ... existing early returns ...

        url = normalize_url(url)
        url, headers = self._build_headers(url)
        headers = {**self.hdr, **headers}

        handler_func = dispatch(url)
        if handler_func:
            before = len(videos)
            start = time.time()
            try:
                handler_func(self, url, videos, vidtxt, headers)
            finally:
                elapsed = (time.time() - start) * 1000.0
                debug_handler_log(self, handler_func.__name__, url, before, len(videos), elapsed)
            return

        # Fallback: generic iframe extraction (kept minimal; can be extended)
        try:
            html = cached_request(url, headers, output=None)
            for surl in REGEX["iframe_src"].findall(html):
                if self.hmf(surl):
                    vidhost = self.get_vidhost(surl)
                    if vidtxt:
                        vidhost += f' | {vidtxt}'
                    if (vidhost, surl) not in videos:
                        videos.append((vidhost, surl))
        except Exception as e:
            self.log(f'Generic resolve_media fallback error: {e}', 'error')
            if self.debug_handlers: self.log(f'[DEBUG] fallback_iframe url="{url}"', 'debug')


# Handlers (examples for the hosts visible in your snippet)
# Simple handlers
@handler('something.com')
def handle_something(scraper, url, videos, vidtxt, headers):
    headers = {**scraper.hdr, **headers}
    html = cached_request(url, headers, output=None)

    # paste original logic here, replacing:
    #   self -> scraper
    #   headers.update(...) -> headers = {**headers, ...} or new dict
    #   client.request(...) -> cached_request(...) where safe
    #   check_hosted_media(...) -> scraper.hmf(...)
    #   self.get_vidhost(...) -> scraper.get_vidhost(...)
    #   self.log(...) -> scraper.log(...)

@handler('groundbanks.net')
def handle_groundbanks(scraper, url, videos, vidtxt, headers):
    headers = {**scraper.hdr, **headers, "te": "trailers"}
    ehtml = cached_request(url, headers)
    ref = urljoin(url, '/')
    s = REGEX["groundbanks_button"].search(ehtml)
    if s:
        headers = {**headers, 'Referer': ref}
        shtml = client.request(s.group(1), headers=headers, close=False)
        v = REGEX["iframe_src"].search(shtml)
        if v:
            surl = v.group(1)
            if scraper.hmf(surl):
                vidhost = scraper.get_vidhost(surl)
                if vidtxt:
                    vidhost += f' | {vidtxt}'
                if (vidhost, surl) not in videos:
                    videos.append((vidhost, surl))
            else:
                scraper.log(f'ResolveUrl cannot resolve groundbanks : {surl}', 'info')
    else:
        v = REGEX["iframe_src"].search(ehtml)
        if v:
            surl = v.group(1)
            if scraper.hmf(surl):
                vidhost = scraper.get_vidhost(surl)
                if vidtxt:
                    vidhost += f' | {vidtxt}'
                if (vidhost, surl) not in videos:
                    videos.append((vidhost, surl))
            else:
                scraper.log(f'ResolveUrl cannot resolve groundbanks : {surl}', 'info')

@handler('xdownex.xyz/')
def handle_xdownex(scraper, url, videos, vidtxt, headers):
    headers = {**scraper.hdr, **headers}
    ehtml = cached_request(url, headers)
    s = REGEX["xdownex_links"].findall(ehtml)
    if not s:
        return
    for surl in s:
        if scraper.hmf(surl):
            vidhost = scraper.get_vidhost(surl)
            if vidtxt:
                vidhost += f' | {vidtxt}'
            if (vidhost, surl) not in videos:
                videos.append((vidhost, surl))
        else:
            scraper.log(f'ResolveUrl cannot resolve 1 surl: {surl}')

@handler('streamnetu.xyz/')
def handle_streamnetu(scraper, url, videos, vidtxt, headers):
    html = cached_request(url, headers)
    videoclass = strained(scraper, html, key="entry_content")
    links = videoclass.find_all('a')
    for link in links:
        surl = link.get('href')
        if not surl:
            continue
        if scraper.hmf(surl):
            vidhost = scraper.get_vidhost(surl)
            if vidtxt:
                vidhost += f' | {vidtxt}'
            if (vidhost, surl) not in videos:
                videos.append((vidhost, surl))
        else:
            scraper.log(f'ResolveUrl cannot resolve 2 : {surl}')

@handler('okmalayalam.')
def handle_okmalayalam(scraper, url, videos, vidtxt, headers):
    mid = url.split('/')[-1]
    params = {'data': mid, 'do': 'getVideo'}
    data = {'hash': mid, 'r': ''}
    jd = client.request('https://v.okmalayalam.org/player/index.php', XHR=True, referer=url, post=data, params=params)
    if not jd:
        scraper.log(f"Cannot resolve: {url}")
        return

    jd = json.loads(jd)
    surl = jd.get('securedLink')
    if not surl:
        scraper.log(f"Cannot resolve: {url}")
        return
    vidhost = scraper.get_vidhost(surl)
    if vidtxt:
        vidhost += f' | {vidtxt}'
    if (vidhost, surl) not in videos:
        videos.append((vidhost, surl))

@handler('watchlinkx.xyz/')
def handle_watchlinkx(scraper, url, videos, vidtxt, headers):
    html = cached_request(url, headers=scraper.hdr)
    r = REGEX["watchlinkx_button"].search(html)
    if not r:
        return
    surl = r.group(1)
    if scraper.hmf(surl):
        vidhost = scraper.get_vidhost(surl)
        if vidtxt:
            vidhost += f' | {vidtxt}'
        if (vidhost, surl) not in videos:
            videos.append((vidhost, surl))
    else:
        scraper.log(f'ResolveUrl cannot resolve 3 surl: {surl}')

@handler('filelinkzr.com/')
def handle_filelinkzr(scraper, url, videos, vidtxt, headers):
    html = cached_request(url, headers, output=None)
    r = REGEX["filelinkzr_button"].search(html)
    if r:
        surl = re.sub(r'\s', '', r.group(1))
        if 'videoemx2.com/' in surl:
            html2 = client.request(surl, headers=scraper.hdr)
            r2 = REGEX["iframe_src"].search(html2)
            if r2:
                surl = r2.group(1)
        if scraper.hmf(surl):
            vidhost = scraper.get_vidhost(surl)
            if vidtxt:
                vidhost += f' | {vidtxt}'
            if (vidhost, surl) not in videos:
                videos.append((vidhost, surl))
        else:
            scraper.log(f'ResolveUrl cannot resolve 3a : {surl}', 'info')

    r = REGEX["iframe_src"].search(html)
    if r:
        surl = re.sub(r'\s', '', r.group(1))
        if scraper.hmf(surl):
            vidhost = scraper.get_vidhost(surl)
            if vidtxt:
                vidhost += f' | {vidtxt}'
            if (vidhost, surl) not in videos:
                videos.append((vidhost, surl))
        else:
            scraper.log(f'ResolveUrl cannot resolve 3aa : {surl}', 'info')

@handler('filmshowonline.net/media/')
def handle_filmshowonline(scraper, url, videos, vidtxt, headers):
    try:
        headers = {**scraper.hdr, **headers}
        r = client.request(url, headers=headers, output='extended')
        clink = r[0]
        cookie = r[4]
        eurl = REGEX["filmshow_embed_url"].findall(clink)[0]
        if not eurl.startswith('http'):
            eurl = f'https:{eurl}'
        enonce = REGEX["filmshow_nonce"].findall(clink)[0]
        evid = REGEX["filmshow_link_id"].findall(clink)[0]
        values = {
            'echo': 'true',
            'nonce': enonce,
            'width': '848',
            'height': '480',
            'link_id': evid,
        }
        headers2 = {**scraper.hdr, 'Referer': url, 'X-Requested-With': 'XMLHttpRequest'}
        emdiv = client.request(eurl, post=values, headers=headers2, cookie=cookie)
        emdiv = json.loads(emdiv).get('embed')
        strurl = REGEX["filmshow_http"].findall(emdiv)[0]
        if scraper.hmf(strurl):
            vidhost = scraper.get_vidhost(strurl)
            if vidtxt:
                vidhost += f' | {vidtxt}'
            if (vidhost, strurl) not in videos:
                videos.append((vidhost, strurl))
    except Exception:
        pass

@handler('cdn.jwplayer.com')
def handle_jwplayer(scraper, url, videos, vidtxt, headers):
    headers = {**scraper.hdr, **headers}
    media_id = url.split('/')[-1].split('-')[0]
    jurl = f'https://content.jwplatform.com/v2/media/{media_id}'
    r = client.request(jurl, headers=headers, output='extended')
    if int(r[1]) >= 400:
        scraper.log(f"Cannot resolve: {url}")
        return

    vitem = json.loads(r[0]).get('playlist')[0]
    vlink = vitem.get('sources')[0].get('file')
    if not vlink:
        scraper.log(f"Cannot resolve: {url}")
        return

    vidhost = scraper.get_vidhost(vlink)
    title = vitem.get('title') or ''
    if 'part' in title.lower():
        vidhost += f' | {title}'
    if (vidhost, vlink) not in videos:
        videos.append((vidhost, vlink))

@handler('thrfive.io')
def handle_thrfive(scraper, url, videos, vidtxt, headers):
    headers = {**scraper.hdr, **headers}
    res = client.request(url, referer='https://www.tamildhool.net/', headers=headers)
    if unjuice.test(res):
        res = unjuice.run(res)
    jd = json.loads(REGEX["thrfive_config"].findall(res)[0])
    headers.update({
        'Origin': 'https://thrfive.io',
        'Referer': 'https://thrfive.io/',
        'Accept-Language': 'en-US,en;q=0.5',
    })
    strurl = jd.get('sources').get('file') + '|' + urlencode(headers)
    vidhost = scraper.get_vidhost(strurl)
    if vidtxt:
        vidhost += f' | {vidtxt}'
    if (vidhost, strurl) not in videos:
        videos.append((vidhost, strurl))

@handler('justmoviesonline.com')
def handle_justmovies(scraper, url, videos, vidtxt, headers):
    headers = {**scraper.hdr, **headers}
    html = client.request(url, headers=headers)
    src = REGEX["atob"].search(html)
    if src:
        src = base64.b64decode(src.group(1)).decode('utf-8')
        try:
            strurl = REGEX["justmovies_file"].findall(src)[0]
            vidhost = 'GVideo'
            strurl = quote_plus(strurl)
            if (vidhost, strurl) not in videos:
                videos.append((vidhost, strurl))
        except Exception:
            pass
        try:
            strurl = REGEX["justmovies_source"].findall(src)[0]
            vidhost = scraper.get_vidhost(strurl)
            if (vidhost, strurl) not in videos:
                videos.append((vidhost, strurl))
        except Exception:
            pass
        return
    elif '?id=' in url:
        src = eval(re.findall('Loading.+?var.+?=([^;]+)', html, re.DOTALL)[0])
        strurl = ''
        for item in src:
            if 'http' in item and 'justmovies' not in item:
                strurl = item
        strurl += url.split('?id=')[1]
        strurl += f'.mp4|User-Agent={scraper.hdr["User-Agent"]}'
        vidhost = 'GVideo'
        strurl = quote_plus(strurl)
        if (vidhost, strurl) not in videos:
            videos.append((vidhost, strurl))

@handler_list(['videohost.site', 'videohost1.com'])
def handle_videohost(scraper, url, videos, vidtxt, headers):
    try:
        headers = {**scraper.hdr, **headers}
        html = client.request(url, headers=headers)
        pdata = eval(REGEX["videohost_run"].findall(html)[0])
        pdata = base64.b64decode(pdata).decode('utf-8')
        linkcode = jsunpack.get_2packed_data(pdata).replace('\\', '')
        sources = json.loads(REGEX["videohost_sources"].findall(linkcode)[0])
        for source in sources:
            strurl = source['file'] + f'|Referer={url}'
            vidhost = f'{scraper.get_vidhost(url)} | GVideo | {source["label"]}'
            strurl = quote_plus(strurl)
            if (vidhost, strurl) not in videos:
                videos.append((vidhost, strurl))
    except Exception:
        pass

@handler('videohost2.com')
def handle_videohost2(scraper, url, videos, vidtxt, headers):
    headers = {**scraper.hdr, **headers}
    html = client.request(url, headers=headers)

    # packed array
    try:
        pdata = eval(REGEX["videohost2_array"].findall(html)[0])
        if 'id=' in url:
            strurl = pdata[7] + url.split('=')[1] + pdata[9]
        else:
            strurl = pdata[7]
        vidhost = f'{scraper.get_vidhost(url)} | GVideo'
        strurl = quote_plus(strurl + f'|Referer={url}')
        if (vidhost, strurl) not in videos:
            videos.append((vidhost, strurl))
    except Exception:
        pass

    # atob block
    try:
        pdata = base64.b64decode(REGEX["atob"].findall(html)[0]).decode('utf-8')
        strurl = REGEX["videohost2_source"].findall(pdata)[0] + f'|Referer={url}'
        vidhost = scraper.get_vidhost(url)
        strurl = quote_plus(strurl)
        if (vidhost, strurl) not in videos:
            videos.append((vidhost, strurl))
    except Exception:
        pass

@handler_list(['hindistoponline', 'hindigostop'])
def handle_hindistop(scraper, url, videos, vidtxt, headers):
    headers = {**scraper.hdr, **headers}
    url = url.replace("www.hindistoponline.com", "hindigostop.com")
    html = client.request(url, headers=headers)

    # direct source:
    try:
        strurl = REGEX["hindistop_source"].findall(html)[0]
        vidhost = scraper.get_vidhost(strurl)
        strurl = quote_plus(f'{strurl}|User-Agent={scraper.hdr["User-Agent"]}&Referer={url}')
        if (vidhost, strurl) not in videos:
            videos.append((vidhost, strurl))
    except Exception:
        pass

    # iframe fallback
    try:
        strurl = REGEX["iframe_src"].findall(html)[0]
        if scraper.hmf(strurl):
            vidhost = scraper.get_vidhost(strurl)
            if (vidhost, strurl) not in videos:
                videos.append((vidhost, strurl))
        else:
            scraper.log(f'ResolveUrl cannot resolve 4: {url}')
    except Exception:
        pass

# Complex handlers

# 1. arivakam.*
@handler('arivakam.')
def handle_arivakam(scraper, url, videos, vidtxt, headers):
    headers = {**scraper.hdr, **headers}
    if '$$' in url:
        url, ref = url.split('$$', 1)
        headers = {**headers, 'Referer': ref}

    html = client.request(url, headers=headers, verify=False)
    rurl = urljoin(url, '/')

    # primary "file" JSON
    # strurl_match = re.search(r'"file":"([^"]+)', html)
    strurl_match = REGEX["arivakam_file"].search(html)
    if strurl_match:
        embedurl = strurl_match.group(1)
        if 'playallu' in embedurl:
            vidhost, strurl = scraper.playallu(embedurl, rurl)
            if vidhost is not None and (vidhost, strurl) not in videos:
                videos.append((vidhost, strurl))
        else:
            vidhost = scraper.get_vidhost(embedurl)
            embedurl = f'{embedurl}|Referer={rurl}'
            if (vidhost, embedurl) not in videos:
                videos.append((vidhost, embedurl))
    else:
        # iframe fallback
        # iframe = re.search(r'<iframe.+?src="([^"]+)', html)
        iframe = REGEX["iframe_src"].search(html)
        if iframe:
            embedurl = iframe.group(1)
            if 'playallu' in embedurl:
                vidhost, strurl = scraper.playallu(embedurl, rurl)
                if vidhost is not None and (vidhost, strurl) not in videos:
                    videos.append((vidhost, strurl))
            else:
                vidhost = scraper.get_vidhost(embedurl)
                embedurl = f'{embedurl}|Referer={rurl}'
                if (vidhost, embedurl) not in videos:
                    videos.append((vidhost, embedurl))

    # "linkserver" sources
    # sources = re.findall(r'"linkserver".+?video="([^"]+)', html)
    sources = REGEX["arivakam_linkserver"].findall(html)
    for embedurl in sources:
        headers2 = {**headers, 'Referer': url}
        if 'playallu' in embedurl:
            vidhost, strurl = scraper.playallu(embedurl, rurl)
            if vidhost is not None and (vidhost, strurl) not in videos:
                videos.append((vidhost, strurl))
        elif embedurl.startswith('api_player') and 'type=default' not in embedurl:
            ehtml = client.request(rurl + 'player/' + embedurl, headers=headers2, verify=False)
            linkcode = jsunpack.get_2packed_data(ehtml).replace('\\', '')
            # elink = re.findall(r'''file"\s*:\s*"([^"]+)''', linkcode)
            elink = REGEX["arivakam_file"].findall(linkcode)
            if elink:
                strurl = elink[0]
                vidhost = scraper.get_vidhost(strurl)
                strurl = f'{strurl}|Referer={rurl}'
                if (vidhost, strurl) not in videos:
                    videos.append((vidhost, strurl))

    # /api/movie JSON
    mid = url.split('/')[-1]
    aurl = urljoin(url, '/api/movie')
    headers3 = {**headers, 'Referer': url}
    ehtml = client.request(aurl, headers=headers3, params={'id': mid})
    if ehtml:
        sources = json.loads(ehtml).get('movieInfo') or {}
        for _, src in iter(sources):
            strurl = src.get('urlStream')
            if not strurl:
                continue
            vidhost = scraper.get_vidhost(strurl)
            if 'playallu' in strurl:
                vidhost, strurl = scraper.playallu(strurl, url)
            if vidhost is not None and (vidhost, strurl) not in videos:
                videos.append((vidhost, strurl))

# 2. tamildbox / tamilhdbox
@handler_list(['tamildbox', 'tamilhdbox'])
def handle_tamildbox(scraper, url, videos, vidtxt, headers):
    # embed variant
    if 'embed' in url:
        thdr = dict(scraper.hdr)
        thdr['Referer'] = url
        r = client.request(url, headers=thdr)
        match = re.search(r"domainStream\s*=\s*([^;]+)", r)
        if match:
            surl = re.findall(r'file":"([^"]+)', match.group(1))[0]
            if 'vidyard' in surl:
                surl += '|Referer=https://play.vidyard.com/'
            else:
                surl = surl.replace('/hls/', '/own1hls/2020/')
                surl += '|Referer=https://embed1.tamildbox.tips/'
            surl += f'&User-Agent={scraper.hdr["User-Agent"]}'
        else:
            surl = url.replace('hls_vast', 'hls').replace('.tamildbox.tips', '.tamilgun.tv')
            if '.m3u8' not in surl:
                surl += '/playlist.m3u8'
        vidhost = scraper.get_vidhost(surl)
        if (vidhost, surl) not in videos:
            videos.append((vidhost, surl))
        return

    # non-embed page
    link = client.request(url)

    # 1) video-player-content iframes
    try:
        # mlink = SoupStrainer('div', {'class': re.compile('^video-player-content')})
        # videoclass = BeautifulSoup(link, "html.parser", parse_only=mlink)
        videoclass = strained(scraper, link, key="video_player")

        vlinks = videoclass.find_all('iframe')
        for vlink in vlinks:
            iurl = vlink.get('src')
            if not iurl:
                continue
            if iurl.startswith('//'):
                iurl = 'https:' + iurl
            if 'playallu.' in iurl:
                vidhost, strlink = scraper.playallu(iurl, url)
                if vidhost is not None and (vidhost, strlink) not in videos:
                    videos.append((vidhost, strlink))
            else:
                if scraper.hmf(iurl):
                    vidhost = scraper.get_vidhost(iurl)
                    if (vidhost, iurl) not in videos:
                        videos.append((vidhost, iurl))
    except Exception:
        scraper.log(f'Error:  {print_exc()}', 'error')

    # 2) player-api jwplayer embeds
    try:
        videoclass = strained(scraper, link, key="player_api")
        vlinks = videoclass.find_all('iframe')
        for item in vlinks:
            blink = item.get('src')
            if not blink:
                continue
            if 'cdn.jwplayer.com' in blink:
                h2 = dict(scraper.hdr)
                media_id = blink.split('/')[-1].split('-')[0]
                jurl = f'https://content.jwplatform.com/v2/media/{media_id}'
                jd = json.loads(client.request(jurl, headers=h2))
                vlink = jd.get('playlist')[0].get('sources')[0].get('file')
                if vlink:
                    vidhost = scraper.get_vidhost(vlink)
                    if (vidhost, vlink) not in videos:
                        videos.append((vidhost, vlink))
            else:
                scraper.log(f'Cannot resolve: {blink}')
    except Exception:
        pass

    # 3) vidorev_jav_js_object single_video_url
    try:
        etext = re.search(r'var\s*vidorev_jav_js_object\s*=\s*([^;]+)', link, re.DOTALL)
        if etext:
            glink = json.loads(etext.group(1)).get('single_video_url')
            if glink:
                vidhost = scraper.get_vidhost(glink)
                if (vidhost, glink) not in videos:
                    videos.append((vidhost, glink))
    except Exception:
        pass

    # 4) file / label pairs
    try:
        etext = re.search(r'file:\s*"([^"]+).+?type:\s*"([^"]+)', link, re.DOTALL)
        if etext:
            glink = etext.group(1)
            vtype = etext.group(2)
            vidhost = f'{scraper.get_vidhost(glink)} | {vtype}'
            if 'http' not in glink:
                glink = 'http:' + glink
            if (vidhost, glink) not in videos:
                videos.append((vidhost, glink))

        etext = re.search(r'file":\s*"([^"]+).+?label":\s*"([^"]+)', link, re.DOTALL)
        if etext:
            glink = etext.group(1)
            label = etext.group(2)
            vidhost = f'{scraper.get_vidhost(glink)} | {label}'
            if 'http' not in glink:
                glink = 'http:' + glink
            if (vidhost, glink) not in videos:
                videos.append((vidhost, glink))
    except Exception:
        pass

    # 5) player-embed div
    try:
        # mlink = SoupStrainer('div', {'id': 'player-embed'})
        # dclass = BeautifulSoup(link, "html.parser", parse_only=mlink)
        dclass = strained(scraper, link, key="player_embed")

        if 'unescape' in str(dclass):
            etext = re.findall("unescape.'[^']*", str(dclass))[0]
            etext = unquote(etext)
            dclass = BeautifulSoup(etext, "html.parser")
        glink = dclass.iframe.get('src')
        if glink and scraper.hmf(glink):
            vidhost = scraper.get_vidhost(glink)
            if (vidhost, glink) not in videos:
                videos.append((vidhost, glink))
    except Exception:
        pass

    # 6) item-content iframe
    try:
        # mlink = SoupStrainer('div', {'class': re.compile('^item-content')})
        # dclass = BeautifulSoup(link, "html.parser", parse_only=mlink)
        dclass = strained(scraper, link, key="item_content")

        if dclass and dclass.p and dclass.p.iframe:
            glink = dclass.p.iframe.get('src')
            if glink and scraper.hmf(glink):
                vidhost = scraper.get_vidhost(glink)
                if (vidhost, glink) not in videos:
                    videos.append((vidhost, glink))
    except Exception:
        pass

    # 7) packed code / youtube → docs
    try:
        glink = ''
        if 'p,a,c,k,e,d' in link:
            linkcode = jsunpack.get_2packed_data(link).replace('\\', '')
            glink = re.findall(r"file\s*:\s*'(.*?)'", linkcode)[0]
        if 'youtu.be' in glink:
            glink = 'https://docs.google.com/vt?id=' + glink[16:]
        if glink and scraper.hmf(glink):
            vidhost = scraper.get_vidhost(glink)
            if (vidhost, glink) not in videos:
                videos.append((vidhost, glink))
    except Exception:
        pass

    # 8) loadEP actions.php
    try:
        codes = re.findall(r'"return loadEP.([^,]*),(\d*)', link)
        for ep_id, server_id in codes:
            burl = f'https://{url.split("/")[2]}/actions.php?case=loadEP&ep_id={ep_id}&server_id={server_id}'
            bhtml = client.request(burl)
            blink = re.findall('<iframe.+?src="([^"]+)', bhtml, re.I)[0]
            if blink.startswith('//'):
                blink = 'https:' + blink
            if 'googleapis' in blink:
                blink = 'https://drive.google.com/open?id=' + re.findall('docid=([^&]*)', blink)[0]
                vidhost = 'GVideo'
                if (vidhost, blink) not in videos:
                    videos.append((vidhost, blink))
            elif 'cdn.jwplayer.com' in blink:
                h2 = dict(scraper.hdr)
                media_id = blink.split('/')[-1].split('-')[0]
                jurl = f'https://content.jwplatform.com/v2/media/{media_id}'
                jd = json.loads(client.request(jurl, headers=h2))
                vlink = jd.get('playlist')[0].get('sources')[0].get('file')
                if vlink:
                    vidhost = scraper.get_vidhost(vlink)
                    if (vidhost, vlink) not in videos:
                        videos.append((vidhost, vlink))
    except Exception:
        pass

# 3. apneembed
@handler_list(APNEEMBED)
def handle_apneembed(scraper, url, videos, vidtxt, headers):
    headers = {**scraper.hdr, **headers}

    rurl, bhtml = scraper.refresh_redirect(url, headers=headers)
    s = scraper.form_action(url, headers, bhtml)

    if not s:
        scraper.log(f'[apneembed] no form_action result for {url}')
        return

    strurl = s[0]
    if 'url=' in strurl:
        strurl = strurl.split('url=')[-1]

    # special HLS → MP4 rewrite
    if 'hls' in strurl and 'videoapne' in strurl:
        strurl = strurl.replace('hls/,', '').replace(',.urlset/master.m3u8', '/v.mp4')

    vidhost = scraper.get_vidhost(strurl)

    if (vidhost, strurl) not in videos:
        videos.append((vidhost, strurl))


# 4. go_cloc_list
@handler_list(GO_CLOC_LIST)
def handle_go_cloc(scraper, url, videos, vidtxt, headers):
    headers = {**scraper.hdr, **headers}

    html = scraper.apne_twostop(url, headers)
    if not html:
        return

    try:
        # matches = re.findall(r'''(?i)<iframe.+?src=["']([^'"]+)''', html)
        matches = REGEX["iframe_src"].findall(html)
        if not matches:
            return

        strurl = matches[0]
        if '?url=' in strurl:
            strurl = strurl.split('?url=')[1]

        vhdr = {'Origin': 'https://apnevideo.co'}
        if strurl.endswith('.m3u8'):
            vhdr['Range'] = 'bytes=0-'

        vidurl = f'{strurl}|{urlencode(vhdr)}'
        vidhost = scraper.get_vidhost(strurl)

        if (vidhost, vidurl) not in videos:
            videos.append((vidhost, vidurl))

    except Exception as e:
        scraper.log(f'[go_cloc] Error: {e}', 'error')


# 5. embed_list (the monster)
@handler_list(EMBED_LIST)
def handle_embed_list(scraper, url, videos, vidtxt, headers):
    headers = {**scraper.hdr, **headers}

    # hd-rulez rewrite
    url = url.replace('hd-rulez.info/', 'business-mortgage.biz/')

    clink = client.request(url, headers=headers)
    csoup = BeautifulSoup(clink, "html.parser")

    # meta refresh
    try:
        meta = csoup.find('meta', {'http-equiv': 'refresh'})
        if meta:
            url2 = meta.get('content').split('URL=')[-1]
            if any(x in url2 for x in EMBED_LIST):  # optional helper
                clink = client.request(url2, headers=headers)
                csoup = BeautifulSoup(clink, "html.parser")
    except:
        pass

    # iframe extraction (your huge block)
    try:
        headers2 = {**headers, 'Referer': urljoin(url, '/')}
        for link in csoup.find_all('iframe'):
            strurl = link.get('src') or link.get('data-phast-src')
            if not strurl:
                continue

            # apnevideoone
            if 'apnevideoone' in strurl:
                shtml = client.request(strurl, headers=headers2)
                vidurl = re.findall(r'link_play\s*=\s*\[{"file":"([^"]+)', shtml)[0]
                vhdr = {'Origin': 'https://apnevideoone.co'}
                vidurl = f'{vidurl}|{urlencode(vhdr)}'
                vidhost = 'CDN Apne'
                videos.append((vidhost, vidurl))
                continue

            # flow.
            if 'flow.' in strurl:
                shtml = client.request(strurl, headers=headers2, verify=False)
                if unjuice.test(shtml):
                    shtml = unjuice.run(shtml)
                if jsunpack.detect(shtml):
                    shtml = jsunpack.get_2packed_data(shtml)
                vidurl = re.findall(r'sources\s*:\s*\[\{\s*"(?:file|src)"\s*:\s*"([^"]+)', shtml, re.I)[0]
                refr = urljoin(strurl, '/')
                vhdr = {
                    'Referer': refr,
                    'Origin': refr[:-1],
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0'
                }
                vidurl = f'{vidurl}|{urlencode(vhdr)}'
                vidhost = scraper.get_vidhost(vidurl) + ' Direct'
                videos.append((vidhost, vidurl))
                continue

            # drivewire
            if 'drivewire.' in strurl:
                vid = strurl.split('id=')[-1]
                parts = urlparse(strurl)
                vidurl = f'{parts.scheme}://{parts.netloc}/hls/{vid}/{vid}.m3u8'
                vidhost = 'DriveWire'
                videos.append((vidhost, vidurl))
                continue

            # generic
            if scraper.hmf(strurl):
                vidhost = scraper.get_vidhost(strurl)
                videos.append((vidhost, strurl))
    except Exception as e:
        scraper.log(f'[embed_list] iframe error: {e}', 'error')

    # sources: [...]
    try:
        sources = re.findall(r'sources:\s*([^\]]+)', clink, re.DOTALL)[0]
        links = re.findall(r'''src:\s*['"]([^"']+)''', sources)
        for strurl in links:
            vidhost = scraper.get_vidhost(strurl)
            videos.append((vidhost, strurl))
    except:
        pass

    # jwplayer
        # jwplayer("container").setup({ file: "..." })
    try:
        r = re.search(r'jwplayer\("container"\).setup\({\s*\n\s*file:\s*"([^"]+)', clink)
        if r:
            strurl = r.group(1)
            vidhost = scraper.get_vidhost(strurl)
            if vidtxt:
                vidhost += f" | {vidtxt}"
            if (vidhost, strurl) not in videos:
                videos.append((vidhost, strurl))
    except Exception as e:
        scraper.log(f"[embed_list] jwplayer Error: {e} {print_exc()}", "error")

    # main-button dlbutton
    try:
        plink = csoup.find('a', {'class': 'main-button dlbutton'})
        if plink:
            strurl = plink.get("href")
            if strurl and "videoemx2.com" in strurl:
                dlink = client.request(strurl, headers=headers)
                dsoup = strained(scraper, dlink, key="entry_content_div")
                iframe = dsoup.find("iframe") if dsoup else None
                if iframe:
                    strurl = iframe.get("src")

            if strurl and not any(x in strurl for x in NON_STREAM_HOSTS):
                if scraper.hmf(strurl):
                    vidhost = scraper.get_vidhost(strurl)
                    if vidtxt:
                        vidhost += f" | {vidtxt}"
                    if (vidhost, strurl) not in videos:
                        videos.append((vidhost, strurl))
                else:
                    scraper.log(f"[embed_list] dlbutton cannot resolve: {strurl}")
    except Exception as e:
        scraper.log(f"[embed_list] main-button Error: {e} {print_exc()}", "error")

    # aio-pulse
    try:
        plink = strained(scraper, clink, key="aio_pulse")
        if plink and plink.a:
            strurl = plink.a.get("href")
            if strurl and not any(x in strurl for x in NON_STREAM_HOSTS) and not any(
                x in strurl for x in EMBED_LIST
            ):
                if scraper.hmf(strurl):
                    vidhost = scraper.get_vidhost(strurl)
                    if vidtxt:
                        vidhost += f" | {vidtxt}"
                    if (vidhost, strurl) not in videos:
                        videos.append((vidhost, strurl))
                else:
                    scraper.log(f"[embed_list] aio-pulse cannot resolve: {strurl}")
    except Exception as e:
        scraper.log(f"[embed_list] aio-pulse Error: {e} {print_exc()}", "error")

    # entry-content single link
    try:
        plink = strained(scraper, clink, key="entry_content_link")
        if plink and plink.a:
            strurl = plink.a.get("href")
            if strurl and not any(x in strurl for x in NON_STREAM_HOSTS) and not any(
                x in strurl for x in EMBED_LIST
            ):
                if scraper.hmf(strurl):
                    vidhost = scraper.get_vidhost(strurl)
                    if vidtxt:
                        vidhost += f" | {vidtxt}"
                    if (vidhost, strurl) not in videos:
                        videos.append((vidhost, strurl))
                else:
                    scraper.log(f"[embed_list] entry-content cannot resolve: {strurl}")
    except Exception as e:
        scraper.log(f"[embed_list] entry-content Error: {e} {print_exc()}", "error")

    # <embed src="...">
    try:
        for emb in csoup.find_all("embed"):
            strurl = emb.get("src")
            if not strurl:
                continue
            if not any(x in strurl for x in NON_STREAM_HOSTS) and not any(
                x in strurl for x in EMBED_LIST
            ):
                if scraper.hmf(strurl):
                    vidhost = scraper.get_vidhost(strurl)
                    if vidtxt:
                        vidhost += f" | {vidtxt}"
                    if (vidhost, strurl) not in videos:
                        videos.append((vidhost, strurl))
                else:
                    scraper.log(f"[embed_list] <embed> cannot resolve: {strurl}")
    except Exception as e:
        scraper.log(f"[embed_list] embed Error: {e} {print_exc()}", "error")

    # Proceed div
    try:
        plink = strained(scraper, clink, key="proceed")
        if plink and plink.a:
            strurl = plink.a.get("href")
            if strurl and not any(x in strurl for x in NON_STREAM_HOSTS) and not any(
                x in strurl for x in EMBED_LIST
            ):
                if scraper.hmf(strurl):
                    vidhost = scraper.get_vidhost(strurl)
                    if vidtxt:
                        vidhost += f" | {vidtxt}"
                    if (vidhost, strurl) not in videos:
                        videos.append((vidhost, strurl))
                else:
                    scraper.log(f"[embed_list] Proceed cannot resolve: {strurl}")
    except Exception as e:
        scraper.log(f"[embed_list] Proceed Error: {e} {print_exc()}", "error")

    # tune.pk
    try:
        vid = re.findall(r'tune\.pk[^?]+\?vid=([^&]+)', clink)[0]
        strurl = f'https://tune.pk/video/{vid}/'
        if scraper.hmf(strurl):
            vidhost = scraper.get_vidhost(strurl)
            if vidtxt:
                vidhost += f" | {vidtxt}"
            if (vidhost, strurl) not in videos:
                videos.append((vidhost, strurl))
        else:
            scraper.log(f"[embed_list] tune.pk cannot resolve: {strurl}")
    except Exception as e:
        scraper.log(f"[embed_list] tune Error: {e} {print_exc()}", "error")

    # generic file:
    try:
        vidurl = re.search(r'file\s*:\s*"([^"]+)', clink)
        if vidurl:
            strurl = vidurl.group(1)
            vidhost = scraper.get_vidhost(strurl)
            videos.append((vidhost, strurl))
    except Exception as e:
        scraper.log(f"[embed_list] file Error: {e} {print_exc()}", "error")

    # file|src m3u8
    try:
        vidurl = get_findall(r'"(?:file|src)"\s*:\s*"([^"]+m3u8)', clink)[0]
        vidhost = scraper.get_vidhost(vidurl)
        videos.append((vidhost, vidurl))
    except Exception as e:
        scraper.log(f"[embed_list] file|src m3u8 Error: {e} {print_exc()}", "error")


# Part 4 — Debug Summary / Sanity‑Check Helpers
def debug_summary(scraper, results):
    """
    Pretty‑print a summary of handler activity.
    `results` is a list of dicts produced by debug_test_urls().
    """
    scraper.log("========== DEBUG SUMMARY ==========")
    for item in results:
        scraper.log(
            f"[SUMMARY] url='{item['url']}' "
            f"handler='{item['handler']}' "
            f"links={item['links']} "
            f"elapsed_ms={item['elapsed_ms']:.2f}"
        )
    scraper.log("===================================")

def debug_test_urls(scraper, url_list):
    """
    Run resolve_media() on a batch of URLs and collect:
      - which handler fired
      - how many links were extracted
      - how long it took
    Returns a list of dicts suitable for debug_summary().
    """
    results = []

    for url in url_list:
        videos = []
        before = len(videos)
        start = time.time()

        # Find handler
        handler_func = dispatch(url)
        handler_name = handler_func.__name__ if handler_func else "fallback"

        # Run handler
        scraper.resolve_media(url, videos)

        elapsed = (time.time() - start) * 1000.0
        after = len(videos)

        results.append({
            "url": url,
            "handler": handler_name,
            "links": after - before,
            "elapsed_ms": elapsed,
        })

    return results

'''
urls = [
    "https://tamildbox.tips/embed/12345",
    "https://newstalks.co/somepage",
    "https://go.clockks.com/redirect/abc",
    "https://videohost.site/embed/xyz",
    "https://arivakam.com/movie/123",
]

results = debug_test_urls(scraper, urls)
debug_summary(scraper, results)

'''

# NOTE: 
# original file can be ported in exactly the same pattern as above:
# - one @handler per host pattern
# - use cached_request
# - use REGEX entries
# - avoid mutating shared headers
