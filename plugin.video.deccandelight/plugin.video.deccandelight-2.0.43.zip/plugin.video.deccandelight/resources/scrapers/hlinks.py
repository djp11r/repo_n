'''
DeccanDelight scraper plugin
Copyright (C) 2016 gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
import re

from bs4 import BeautifulSoup, SoupStrainer
from resources.lib import client
from resources.lib.base import Scraper
from six.moves import urllib_parse


class hlinks(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'https://www.hindilinks4u.quest/category/'
        self.icon = self.ipath + 'hlinks.png'
        self.list = {'01Hindi Movies': self.bu + 'genre/bollywood/',
                     '02Dubbed Movies': self.bu + 'genre/dual-audio/',
                     # '03Documentary Movies': self.bu + 'documentaries/',
                     '11Amazon Prime Series': self.bu + "director/amazon-prime/",
                     '12Netflix Series': self.bu + "director/netflix/",
                     '13voot Series': self.bu + "director/voot-originals/",
                     '14MX Player': self.bu + "director/mx-player/",
                     '15Hotstar Series': self.bu + "director/hotstar/",
                     '16ALTBalaji Series': self.bu + "director/altbalaji/",
                     '17Sonyliv Series': self.bu + "director/sonyliv-original/",
                     '18Zee5 Series': self.bu + "director/zee5/",
                     '19Gujarati': self.bu + "genre/gujarati/",
                     '97English Series': self.bu + "series/",
                     # '98[COLOR cyan]Adult Movies[/COLOR]': self.bu + 'genre/erotic-movies/',
                     '99[COLOR yellow]** Search **[/COLOR]': self.bu + '?s='}

    def get_menu(self):
        return (self.list, 7, self.icon)

    def get_second(self, iurl):
        """
        Get the list of shows.
        :return: list
        """
        shows = []
        # self.log(f'iurl: {iurl}')
        html = client.request(iurl)
        # self.log(f'html: {html}')
        mlink = SoupStrainer('div', {'class': 'movies-list movies-list-full'})
        mdiv = BeautifulSoup(html, "html.parser", parse_only=mlink)
        plink = SoupStrainer('div', {'id': 'pagination'})
        Paginator = BeautifulSoup(html, "html.parser", parse_only=plink)
        # items = mdiv.find_all('div', {'id': re.compile('^post-')})
        items = mdiv.find_all('div', {'class': re.compile('^ml-item')})
        # self.log(f'items: {len(items)} :: {items}')

        for item in items:
            title = self.unescape(item.find('a')['title'])
            title = self.clean_title(title)
            url = item.find('a')['href']
            try:
                thumb = item.find('img')['src']
                if thumb.startswith('data'):
                    thumb = item.find('img')['data-src']
            except:
                thumb = self.icon
            if self.bu[:-6] in thumb: thumb += '|verifypeer=false'
            #shows.append((title, thumb, url))
            movdet = item.find('p', {'class': 'entry-summary'}).text.lower()
            if 'adult' not in movdet and 'short' not in movdet:
                shows.append((title, thumb, url))
            elif self.adult:
                shows.append((title, thumb, url))

        r = re.search('class="active".+?href="([^"]+)', str(Paginator))
        if r:
            try:
                currpg = Paginator.find('a').text
                lastpg = Paginator.find_all('li')[-1].find('a')['href'].split('/')[-2]
                title = 'Next Page.. (Currently in Page {} of {})'.format(currpg, lastpg)
                shows.append((title, self.nicon, r.group(1)))
            except: pass

        return (shows, 6)

    def get_third(self, iurl):
        """
        Get the list of episodes.
        :return: list
        """
        episodes = []
        html = client.request(iurl)
        try:
            thumb = re.findall(r'<img\s*src="([^"]+)', html, re.DOTALL)[0]
        except:
            thumb = self.icon

        mlink = SoupStrainer('div', {'id': 'content'})
        mdiv = BeautifulSoup(html, "html.parser", parse_only=mlink)
        table = mdiv.find('table')
        if table:
            items = table.find_all('tr')
            for item in items:
                if item.find('th'):
                    continue
                else:
                    tdiv = item.find('td', {'class': 'episode-title'})
                    url = item.find('a')['href']
                    eno = item.find('a').text.replace(' ', '')
                    if tdiv.find('small'):
                        edate = tdiv.find('small').text
                        tdiv.find('small').decompose()
                    else:
                        edate = ''
                    etitle = self.clean_title(tdiv.text)
                    title = '[COLOR yellow]{0}[/COLOR] {1} - [COLOR cyan]{2}[/COLOR]'.format(eno, etitle, edate)
                episodes.append((title, thumb, url))
            return (episodes, 8)
        else:
            mlink = SoupStrainer('div', {'id': 'content-embed'})
            videoclass = BeautifulSoup(html, "html.parser", parse_only=mlink)
            videos = []
            try:
                links = videoclass.find_all('iframe')
                for link in links:
                    vidurl = link.get('src')
                    self.resolve_media(vidurl, videos)
            except: pass
            return videos

        

    def get_items(self, url):
        movies = []
        if url[-3:] == '?s=':
            search_text = self.get_SearchQuery('Hindi Links 4U')
            search_text = urllib_parse.quote_plus(search_text)
            url = url + search_text

        html = client.request(url)
        # self.log(f'html: {html}')
        mlink = SoupStrainer('div', {'class': 'movies-list movies-list-full'})
        mdiv = BeautifulSoup(html, "html.parser", parse_only=mlink)
        plink = SoupStrainer('div', {'id': 'pagination'})
        Paginator = BeautifulSoup(html, "html.parser", parse_only=plink)
        # items = mdiv.find_all('div', {'id': re.compile('^post-')})
        items = mdiv.find_all('div', {'class': re.compile('^ml-item')})
        # self.log(f'items: {len(items)} :: {items}')

        for item in items:
            title = self.unescape(item.find('a')['oldtitle'])
            title = self.clean_title(title)
            url = item.find('a')['href']
            try:
                thumb = item.find('img')['data-original']
            except:
                thumb = self.icon
            if self.bu[:-6] in thumb:
                thumb += '|verifypeer=false'
            movies.append((title, thumb, url))
            # movdet = item.find('p', {'class': 'entry-summary'}).text.lower()
            # if 'adult' not in movdet and 'short' not in movdet:
                # movies.append((title, thumb, url))
            # elif self.adult:
                # movies.append((title, thumb, url))

        r = re.search('class="active".+?href="([^"]+)', str(Paginator))
        if r:
            try:
                currpg = Paginator.find('a').text
                lastpg = Paginator.find_all('li')[-1].find('a')['href'].split('/')[-2]
                title = 'Next Page.. (Currently in Page {} of {})'.format(currpg, lastpg)
                movies.append((title, self.nicon, r.group(1)))
            except: pass

        return (movies, 8)

    def get_videos(self, url):
        videos = []

        html = client.request(url)
        mlink = SoupStrainer('div', {'class': 'entry-content rich-content'})
        videoclass = BeautifulSoup(html, "html.parser", parse_only=mlink)

        try:
            vtabs = re.findall('data-href=."(.*?)."', html)
            for vtab in vtabs:
                self.resolve_media(vtab, videos)
        except:
            pass

        try:
            links = videoclass.find_all('a')
            for link in links:
                vidurl = link.get('href')
                self.resolve_media(vidurl, videos)
        except:
            pass
        mlink = SoupStrainer('div', {'id': 'content-embed'})
        videoclass = BeautifulSoup(html, "html.parser", parse_only=mlink)
        try:
            links = videoclass.find_all('iframe')
            for link in links:
                vidurl = link.get('src')
                self.resolve_media(vidurl, videos)
        except: pass
        return videos
