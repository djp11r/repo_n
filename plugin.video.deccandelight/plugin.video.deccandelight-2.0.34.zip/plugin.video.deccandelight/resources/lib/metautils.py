
import re

from metahandler import metahandlers

metaget = metahandlers.MetaData(tmdb_api_key='bc96b19479c7db6c8ae805744d0bdfe2', omdb_api_key='dd7e2fc7')


def get_meta(title):
    year = ''
    name = title
    r = re.search(r'[([](\d+)[)\]]', name)
    if r:
        year = r.group(1)
    name = re.sub(r"[([].+", "", name).strip()
    meta = metaget.get_meta('movie', name=name, year=year)
    if meta.get('tmdb_id'):
        meta.pop('tmdb_id')
        imdb_id = meta.get('imdb_id')
        if imdb_id:
            meta.update({'imdbnumber': imdb_id})
        if not meta.get('trailer') and imdb_id:
            meta.update({
                'trailer': 'plugin://plugin.video.imdb.trailers/?action=play_id&imdb={0}'.format(imdb_id)
            })
        meta.pop('imdb_id')
        meta.pop('thumb_url')
        if 'imgs_prepacked' in meta.keys():
            meta.pop('imgs_prepacked')
        meta.pop('trailer_url')
    return meta
