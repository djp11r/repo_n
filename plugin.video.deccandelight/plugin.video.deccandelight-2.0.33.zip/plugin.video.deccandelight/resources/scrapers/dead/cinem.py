"""
cinemalayalam deccandelight plugin
Copyright (C) 2019 gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
"""
from resources.lib.base import Scraper
from bs4 import BeautifulSoup, SoupStrainer
from six.moves import urllib_parse
import re
import requests
import time
import xbmc
import xbmcgui
import json

try:
    import StorageServer
except:
    import storageserverdummy as StorageServer
cache = StorageServer.StorageServer('deccandelight', 1)


class cinem(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'http://cinemalayalam.com'
        self.icon = self.ipath + 'cinem.png'
        self.list = {'01Movies': self.bu + '/movies/'}

    def get_menu(self):
        return (self.list, 7, self.icon)

    def get_items(self, iurl):
        movies = []
        h = HTMLParser.HTMLParser()
        mlink = SoupStrainer('article')
        plink = SoupStrainer('div', {'class': 'pagination'})
        html = requests.get(iurl, headers=self.hdr).text
        Paginator = BeautifulSoup(html, parseOnlyThese=plink)
        items = BeautifulSoup(html, parseOnlyThese=mlink)
        for item in items:
            title = h.unescape(item.h3.text).encode('utf8')
            url = item.find('a')['href']
            thumb = item.find('img')['src']
            movies.append((title, thumb, url))
        if 'nextpagination' in str(Paginator):
            nextli = Paginator.findAll('a', {'class': 'arrow_pag'})
            purl = nextli[-1].get('href')
            pgtxt = Paginator.span.text
            title = 'Next Page.. (Currently in {ptxt})'.format(ptxt=pgtxt)
            movies.append((title, self.nicon, purl))
        return (movies, 9)

    def get_video(self, url):
        ajaxurl = self.bu + '/wp-admin/admin-ajax.php'
        html = requests.get(url, headers=self.hdr).text
        matches = re.findall(r'''li\s*id=["']player-option-.+?post=["']([^"']+).+?nume=["']([^"']+).+?title'>([^<]+)''', html)
        if len(matches) > 0:
            if len(matches)>1:
                sources = []
                for match in matches:
                    sources.append(match[2])
                dialog = xbmcgui.Dialog()
                ret = dialog.select('Choose a Source', sources)
                match = matches[ret]
            else:
                match = matches[0]
            headers = self.hdr
            headers['Referer'] = url
            data = {'action': 'doo_player_ajax',
                    'post': match[0],
                    'nume': match[1],
                    'type': 'movie'}
            ahtml = requests.post(ajaxurl, data=data, headers=headers).text
            aurl = re.findall('''<iframe.+?src=['"]([^'"]+)''',ahtml)[0]
            if not aurl.startswith('http'):
                aurl = self.bu[:-1] + aurl
            if 'youtube.com' in aurl:
                return aurl
            jhtml = requests.get(aurl, headers=headers).text
            if 'Clappr.Player' in jhtml:
                stream_url = re.findall(r'source:\s*"([^"]+)',jhtml)[0]
            elif 'var jw =' in jhtml:
                jdata = json.loads(re.findall(r'var\s*jw\s*=\s*([^<]+)',jhtml)[0])
                stream_url = jdata['file']
            elif 'sources: [' in jhtml:
                stream_url = re.findall(r'file:\s*"([^"]+)',jhtml)[0]
                if not stream_url.startswith('http'):
                    stream_url = 'http:' + stream_url
            elif 'var url=' in jhtml:
                stream_url = re.findall(r'var\s*url\s*=\s*"([^"]+)',jhtml)[0]
                stream_url = re.findall('(http.+/)',aurl)[0] + stream_url
            elif 'playerInstance.setup(' in jhtml:
                stream_url = re.findall(r'file:\s*"([^"]+)',jhtml)[0]
            else:
                self.log('%s not resolvable.\n' % url)
                stream_url = 'http://content.jwplatform.com/videos/7RtXk3vl-52qL9xLP.mp4'
        else:
            self.log('%s not resolvable.\n' % url)
            stream_url = 'http://content.jwplatform.com/videos/7RtXk3vl-52qL9xLP.mp4'
        
        stream_url += '|User-Agent={}'.format(self.hdr['User-Agent'])
        # self.log('Stream_url is %s\n'%stream_url)
        return stream_url
