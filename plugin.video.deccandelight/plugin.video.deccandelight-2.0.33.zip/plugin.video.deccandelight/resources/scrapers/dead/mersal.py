'''
mersalaayitten deccandelight plugin
Copyright (C) 2016 gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
from resources.lib.base import Scraper
from bs4 import BeautifulSoup, SoupStrainer
import re, requests
from six.moves import urllib_parse
from six.moves import html_parser

class mersal(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'http://mersalaayitten.ooo/genre/'
        self.icon = self.ipath + 'mersal.png'
        self.list = {'01Tamil Movies': 'tamil',
                     '02Telugu Movies': 'telugu',
                     '03Malayalam Movies': 'malayalam',
                     '04Hindi Movies': 'hindi',
                     '07[COLOR yellow]** Search **[/COLOR]': self.bu[:-6] + '?s=MMMM7'}
   
    def get_menu(self):
        return (self.list,5,self.icon)
 
    def get_second(self, iurl):
        """
        Get the list of genres.
        :return: list
        """
        cats = {'tamil': {'01New Movies': self.bu + 'tamil-2/tamil-new/',
                          '02HD Movies': self.bu + 'tamil-2/tamil-hd/',
                          '03Dubbed Movies': self.bu + 'tamil-2/tamil-dubbed/'},
                'telugu': {'01New Movies': self.bu + 'telugu-2/telugu-new/',
                           '02HD Movies': self.bu + 'telugu-2/telugu-hd/',
                           '03Dubbed Movies': self.bu + 'telugu-2/telugu-dubbed/'},
                'hindi': {'01New Movies': self.bu + 'hindi-2/hindi-new/',
                          '02HD Movies': self.bu + 'hindi-2/hindi-hd/',
                          '03Dubbed Movies': self.bu + 'hindi-2/hindi-dubbed/'},
                'malayalam': {'01New Movies': self.bu + 'malayalam-2/malayalam-new/',
                              '02HD Movies': self.bu + 'malayalam-2/malayalam-hd/'}}

        categories = []

        for title, url in sorted(cats[iurl].iteritems()):
            categories.append((title[2:], self.icon, url))

        return (categories, 7)

    def get_items(self,url):
        movies = []
        h = html_parser.HTMLParser()
        if '%' in url:
            url = urllib.unquote(url)
        if url[-3:] == '?s=':
            search_text = self.get_SearchQuery('Mersalaayitten')
            search_text = urllib.quote_plus(search_text)
            url = url + search_text

        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('div', {'class': 'ml-item'})
        items = BeautifulSoup(html, parseOnlyThese=mlink)
        plink = SoupStrainer('div', {'id': 'pagination'})
        Paginator = BeautifulSoup(html, parseOnlyThese=plink)
        for item in items:
            title = h.unescape(item.h2.text).encode('utf8')
            # title = self.clean_title(title)
            url = item.a.get('href')
            try:
                thumb = item.find('img')['data-original']
            except:
                thumb = item.find('img')['src']
            movies.append((title, thumb, url))
        
        atag = Paginator.find('li', {'class': 'active'})
        if atag:
            ntag = atag.nextSibling
            if ntag:
                nxtag = ntag.find('a', {'class': 'page larger'})
                if nxtag:
                    purl = nxtag.get('href')
                    currpg = atag.text
                    lastpg = Paginator.findAll('a')[-1].get('href').split('/')[-2]
                    title = 'Next Page.. (Currently in Page {0} of {1})'.format(currpg, lastpg)
                    movies.append((title, self.nicon, purl))
        
        return (movies,8)
      
    def get_videos(self,url):
        videos = []
            
        html = requests.get(url, headers=self.hdr).text

        mlink = SoupStrainer('div', {'class':'movieplay'})
        videoclass = BeautifulSoup(html, parseOnlyThese=mlink)
        try:
            links = videoclass.findAll('iframe')
            for link in links:
                vidurl = link.get('src')
                self.resolve_media(vidurl,videos)
        except:
            pass
        
        mlink = SoupStrainer('div', {'itemprop': 'description'})
        videoclass = BeautifulSoup(html, parseOnlyThese=mlink)
        try:
            links = videoclass.findAll('iframe')
            for link in links:
                vidurl = link.get('src')
                self.resolve_media(vidurl,videos)
        except:
            pass

        return videos