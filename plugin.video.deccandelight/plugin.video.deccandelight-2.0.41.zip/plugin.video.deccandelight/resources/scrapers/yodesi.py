'''
DeccanDelight scraper plugin
Copyright (C) 2016 gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
import re

from bs4 import BeautifulSoup, SoupStrainer
from resources.lib import client
from resources.lib.base import Scraper
from six.moves import urllib_parse


class yodesi(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'https://www.yodesitv.info/'
        self.icon = f'{self.ipath}yodesi.png'
        self.videos = []
        self.list = {'01Star Plus': f'{self.bu}star-plus/',
            '02Colors': f'{self.bu}colors/',
            '03Zee TV': f'{self.bu}zee-tv/',
            '04Sony TV': f'{self.bu}sony-tv/',
            '05SAB TV': f'{self.bu}sab-tv/',
            '31Amazon': f'{self.bu}amazon/',
            '32Eros Now Web Series': f'{self.bu}eros-now-web-series/',
            '33Voot': f'{self.bu}voot/',
            '34ALTBalaji': f'{self.bu}alt-balaji/',
            '35Zee5': f'{self.bu}zee5/',
            '36Netflix': f'{self.bu}netflix/',
            '37Hotstar': f'{self.bu}hotstar/',
            '38MX Web Series': f'{self.bu}mx-web-series/',
            '39Vikram Bhatt Web Series': f'{self.bu}vikram-bhatt-web-series/',
            '99[COLOR yellow]** Search **[/COLOR]': f'{self.bu}?s=MMMM7'}

    def get_menu(self):
        return (self.list, 5, self.icon)

    def get_second(self, iurl):
        """
        Get the list of shows.
        :return: list
        """
        shows = []
        html = client.request(iurl)
        mlink = SoupStrainer('div', {'id': 'content_box'})
        mdiv = BeautifulSoup(html, "html.parser", parse_only=mlink)
        items = mdiv.find_all('div', {'class': re.compile('^one_')})
        # self.log(f'>>> items: {items}')
        old_shows = self.settings('old_shows')
        # self.log(f'>>> old_shows: {old_shows}')
        for item in items:
            # self.log(f'>>> item: {item}')
            title = self.unescape(item.text)
            title = title.replace('\n', '').strip()
            url = item.find('a')['href']
            try:
                icon = item.find('img')['src']
            except:
                icon = self.icon
            if old_shows == 'true': shows.append((title, icon, url))
            elif '-archive' not in url: shows.append((title, icon, url))

        return (shows, 7)

    def get_items(self, url):
        movies = []
        if url[-3:] == '?s=':
            search_text = self.get_SearchQuery('Yo Desi!')
            search_text = urllib_parse.quote_plus(search_text)
            url = url + search_text
        html = client.request(url)
        mlink = SoupStrainer('div', {'class': 'main-container'})
        mdiv = BeautifulSoup(html, "html.parser", parse_only=mlink)
        # self.log(f'>>> mdiv: {mdiv}')
        plink = SoupStrainer('nav', {'class': 'navigation pagination'})
        Paginator = BeautifulSoup(html, "html.parser", parse_only=plink)
        items = mdiv.find_all('div', {'class': 'latestPost-content'})
        # self.log(f'>>> items: {items}')
        for item in items:
            title = self.unescape(item.h2.text)
            title = self.clean_title(title)
            url = item.find('a')['href']
            try:
                thumb = item.find('img')['src']
            except:
                thumb = self.icon
            movies.append((title, thumb, url))

        if 'next' in str(Paginator):
            nextli = Paginator.find('a', {'class': 'next page-numbers'})
            purl = nextli.get('href')
            currpg = Paginator.find('span', {'class': re.compile('current')}).text
            pages = Paginator.find_all('a', {'class': 'page-numbers'})
            lastpg = pages[-1].text
            title = 'Next Page.. (Currently in Page {0} of {1})'.format(currpg, lastpg)
            movies.append((title, self.nicon, purl))

        return (movies, 8)

    def get_videos(self, url):
        def process_item(item):
            vidurl = item.get('href')
            vidtxt = self.unescape(item.text)
            vidtxt = re.search(r'(\d.*)', vidtxt)
            vidtxt = vidtxt[1] if vidtxt else ''
            self.resolve_media(vidurl, self.videos, vidtxt)

        html = client.request(url)
        mlink = SoupStrainer('div', {'class': re.compile('entry-content')})
        videoclass = BeautifulSoup(html, "html.parser", parse_only=mlink)

        links = videoclass.find_all('iframe')
        for link in links:
            # self.log(f'>>> link: {link}')
            vidurl = link.get('src')
            self.resolve_media(vidurl, self.videos)

        links = videoclass.find_all('a', {'target': '_blank'})
        threads = []
        for link in links:
            threads.append(self.Thread(process_item, link))
        [i.start() for i in threads]
        [i.join() for i in threads]

        return sorted(self.videos)
