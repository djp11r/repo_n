
import re

from resources.lib import tmdb

metaget = tmdb.TMDB()


def get_meta(title):
    name = title
    year = r[1] if (r := re.search(r'[([](\d+)[)\]]', name)) else ''
    name = re.sub(r'[([].+', '', name).strip()
    meta = metaget.get_meta(name=name, year=year)
    if meta.get('tmdb_id'):
        imdb_id = meta.get('imdb_id')
        if not meta.get('trailer') and imdb_id:
            meta.update({
                'trailer': 'plugin://plugin.video.imdb.trailers/?action=play_id&imdb={0}'.format(imdb_id)
            })

    return meta
