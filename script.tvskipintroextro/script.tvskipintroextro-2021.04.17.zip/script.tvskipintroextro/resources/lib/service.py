# -*- coding: utf-8 -*-

""""""

from __future__ import absolute_import, division, unicode_literals

import traceback

from xbmc import sleep, Player, Monitor, getInfoLabel

from statichelper import logger

monitor = Monitor()


class SkipService():

	def __init__(self, *args):
		self.skipped = False
		self.Skip_dialog = None
		self.eskipped = False
		self.player = Player()

	def run(self):

		while not monitor.abortRequested():
			# check every 5 sec
			# Abort was requested while waiting. We should exit
			if monitor.waitForAbort(5): break
			try: total_time = self.player.getTotalTime()
			except RuntimeError:
				# logger('tracking stopped, failed player.getTotalTime()')
				self.skipped = False
				self.eskipped = False
				continue
			try: play_time = self.player.getTime()
			except RuntimeError: continue


			try:
				while self.player.isPlaying() and (play_time > 1):
					try:
						play_time = self.player.getTime()
						total_time = self.player.getTotalTime()
						currentShow = getInfoLabel("VideoPlayer.TVShowTitle")
						exit_time = total_time - 180
					except RuntimeError as e:
						logger("service run isPlaying RuntimeError: %s" % e)
						break
					if currentShow and play_time < 250 or play_time >= exit_time:
						# logger("currentShow: %s play_time: %s exit_time: %s" % (currentShow, play_time, exit_time))
						# logger("VideoPlayer.Duration: %s" % (getInfoLabel("VideoPlayer.Duration")))
						if play_time >= 250: self.skipped = True
						# logger("self.skipped: %s play_time: %s" % (self.skipped, play_time))
						if not self.skipped and play_time < 250:
							from tvskipintroextro import SkipIntro
							# logger("self.skipped: %s play_time: %s" % (self.skipped, play_time))
							self.skipped, self.eskipped = SkipIntro(self.player, currentShow, self.skipped, self.eskipped, True)
							self.eskipped = False
						# else: self.eskipped = False
						if not self.eskipped and play_time >= exit_time:
							self.skipped = False
							from tvskipintroextro import SkipIntro
							# logger("self.eskipped: %s play_time: %s" % (self.eskipped, play_time))
							self.skipped, self.eskipped = SkipIntro(self.player, currentShow, self.skipped, self.eskipped, False)
							# if play_time >= total_time: self.eskipped = True
			except: logger("SkipService run Error: %s" % traceback.format_exc())
