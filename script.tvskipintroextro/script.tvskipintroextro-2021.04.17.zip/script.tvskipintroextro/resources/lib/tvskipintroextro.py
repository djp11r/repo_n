# -*- coding: utf-8 -*-

""""""

from __future__ import absolute_import, division, unicode_literals

import traceback

from statichelper import logger, get_setting, addonPath, get_skip_option, \
	updateSkip, get_machine, show_modal_dialog

from xbmc import Player, sleep, executebuiltin, getInfoLabel
from xbmcgui import WindowXMLDialog, Dialog, INPUT_NUMERIC


OK_BUTTON = 201
NEW_BUTTON = 202
DISABLE_BUTTON = 210
ACTION_PREVIOUS_MENU = 10
ACTION_PLAYER_STOP = 13
ACTION_NAV_BACK = 92
ACTION_NOOP = 999
INSTRUCTION_LABEL = 203
AUTHCODE_LABEL = 204
WARNING_LABEL = 205
CENTER_Y = 6
CENTER_X = 2


class Skip(WindowXMLDialog):
	"""
	Dialog for skipping video parts (intro, recap, ...)
	"""

	def __init__(self, *args, **kwargs):
		self.skip_option = kwargs['skip_option']
		self.intro = kwargs['intro']
		self.tvshow = self.skip_option.get('title')
		if self.intro:
			self.skipValue = self.skip_option.get('skip')
			self.skipLabel = 'SKIP INTRO: %s' % self.skipValue
		else:
			self.skipValue = self.skip_option.get('eskip')
			self.skipLabel = 'SKIP EXTRO: %s' % self.skipValue
		self.action_exitkeys_id = [10, 13, 92, 999]
		# logger("get_machine(): %s" % get_machine())
		if get_machine()[0:5] == 'armv7':
			WindowXMLDialog.__init__(self)
		else:
			# logger("get_machine Error: %s" % traceback.format_exc())
			try:
				WindowXMLDialog.__init__(self, *args, **kwargs)
			except Exception:  # pylint: disable=broad-except
				logger("WindowXMLDialog Error: %s" % traceback.format_exc())
				WindowXMLDialog.__init__(self)
		# self.window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
		# self.window.setProperty('MyAddonIsRunning', 'true')

	def onInit(self):
		self.getControl(202).setLabel("Update Skip")
		self.getControl(210).setLabel("Disable Skip for This Show")
		self.getControl(201).setLabel("%s" % str(self.skipLabel))

	def onControl(self, control):
		pass

	def onFocus(self, control):
		pass

	def doAction(self):	 # pylint: disable=invalid-name
		pass

	def closeDialog(self):	# pylint: disable=invalid-name
		self.close()

	def onClick(self, control):
		# logger('onClick control: %s' % (control))
		if control == 201:
			play_time = Player().getTime()
			if self.intro:
				skip_time = int(play_time) + int(self.skipValue)
				Player().seekTime(skip_time)
			else:
				total_time = Player().getTotalTime() - 1
				skip_time = int(play_time) + int(total_time - play_time)
				Player().seekTime(skip_time)
			self.close()

		if control == 202:
			dialog = Dialog()
			d = dialog.input('Skip Value Intro (seconds)', type=INPUT_NUMERIC)
			d2 = 0
			d2 = dialog.input('Prompt At (seconds)', type=INPUT_NUMERIC)
			if d2 == '' or d2 is None: d2 = 0
			d3 = dialog.input('Skip Value EXTRO (seconds)', type=INPUT_NUMERIC)
			if str(d) != '' and str(d) != '0': updateSkip(self.tvshow, seconds=str(d), eseconds=str(d3), start=str(d2))
			self.close()

		if control == 210:
			updateSkip(self.tvshow, seconds=self.skipValue, service=False)
			self.close()
		if control in [201, 202, 210]:
			self.close()

	def onAction(self, action):
		if action.getId() in self.action_exitkeys_id:
			self.close()
		if action == ACTION_PLAYER_STOP:
			self.close()
		elif action == ACTION_NAV_BACK:
			self.close()


def SkipIntro(player, currentShow, skipped, eskipped, intro=True):
	try:
		if not player.isPlayingVideo(): raise Exception()

		sleep(2)
		try:
			play_time = player.getTime()
			total_time = player.getTotalTime()
			# currentShow = getInfoLabel("VideoPlayer.TVShowTitle")
			exit_time = total_time - 180
		except RuntimeError as e:
			logger("SkipIntro isPlaying RuntimeError: %s" % e)
			raise Exception()

		if play_time < 250 or play_time >= exit_time and (not skipped or not eskipped):
			# logger("intro: %s exit_time: %s play_time: %s" % (intro, exit_time, play_time))
			skipped, eskipped = show_skip_dlg(player, currentShow, intro)
	except: pass # logger("SkipIntro Error: %s" % traceback.format_exc())
	return skipped, eskipped


def show_skip_dlg(player, tvshow, intro):
	"""Show a dialog for ESN and Widevine settings"""
	# logger("{}	:: {}  :: {} :: {}".format(path, dialog_duration, skip_option, intro))
	try:
		skipped, eskipped = False, False
		try:
			play_time = player.getTime()
			total_time = player.getTotalTime()
		except RuntimeError as e:
			logger("SkipIntro isPlaying RuntimeError: %s" % e)
		skip_option = get_skip_option(tvshow)
		status = skip_option.get('service')	 # checkService(tvshow)
		# logger("skip_option: %s" % skip_option)

		if not status:
			skipped = True
			raise Exception()

		if intro:
			startTime = skip_option.get('start')  # checkStartTime(tvshow)
			# logger("startTime: %s play_time: %s" % (startTime, play_time))
			if int(startTime) >= int(play_time): raise Exception()
		# show_skip_dlg(addonPath, 120, skip_option, intro)
		import time
		Dialog_type = get_setting('skip.dialog')
		dialog_duration = float(get_setting('default.duration'))
		exit_time = total_time - 180
		# logger("Dialog_type: %s dialog_duration: %s" % (Dialog_type, dialog_duration))
		if intro and play_time < 250: 
			skipped = True
			eskipped = False
		elif play_time >= exit_time:
			eskipped = True
			skipped = False
			dialog_duration = total_time - play_time - 2
		logger("intro: %s eskipped: %s skipped: %s exit_time: %s play_time: %s" % (intro, eskipped, skipped, exit_time, play_time))
		if Dialog_type == "Regular": Skip_dialog = Skip('script-dialog.xml', addonPath, skip_option=skip_option, intro=intro)
		else: Skip_dialog = Skip('Skip.xml', addonPath, skip_option=skip_option, intro=intro)
		if dialog_duration > 0:
			# dialog_duration in seconds
			alarm_time = time.strftime('%M:%S', time.gmtime(dialog_duration))
			logger("dialog display time: %s" % alarm_time)
			executebuiltin('AlarmClock(closedialog,Action(noop),{},silent)'.format(alarm_time))
		Skip_dialog.doModal()
		try: del Skip_dialog
		except: logger("del Skip_dialog Error: %s" % traceback.format_exc())
		# logger("Skip_dialog: %s, skipped: %s, eskipped: %s" % (Skip_dialog, skipped, eskipped))
	except: logger("show_skip_dialog Error: %s" % traceback.format_exc())
	return skipped, eskipped


class Player_Instance(Player):
	"""
	call it like 
	self.Player = Player_Instance(function_to_run = self._a_function)
	"""
	def __init__(self, *args, **kwargs):
		Player.__init__(self)
		self.function_to_run = kwargs['function_to_run']

	def onPlayBackEnded(self):
		self.onPlayBackStopped()

	def onPlayBackStopped(self):
		self.function_to_run()


def show_skip_dialog(path, dialog_duration, skip_option, intro):
	"""Show a dialog for ESN and Widevine settings"""
	# logger("{}	:: {}  :: {} :: {}".format(path, dialog_duration, skip_option, intro))
	try:
		Dialog_type = get_setting('skip.dialog')
		logger("Dialog_type: %s" % Dialog_type)
		if Dialog_type == "Regular": show_modal_dialog(False, Skip, "script-dialog.xml", path, seconds=dialog_duration, skip_option=skip_option, intro=intro)
		else: show_modal_dialog(False, Skip, "Skip.xml", path, seconds=dialog_duration, skip_option=skip_option, intro=intro)
	except: logger("show_skip_dialog Error: %s" % traceback.format_exc())
