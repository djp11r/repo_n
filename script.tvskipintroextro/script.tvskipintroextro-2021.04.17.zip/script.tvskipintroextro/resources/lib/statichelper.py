# -*- coding: utf-8 -*-
# GNU General Public License v2.0 (see COPYING or https://www.gnu.org/licenses/gpl-2.0.txt)
"""Implements static functions used elsewhere in the add-on"""

from __future__ import absolute_import, division, unicode_literals

import json
import os
import re
import sys

if sys.version_info.major == 2: isPY2 = True
else: isPY2 =False

from xbmc import getInfoLabel, executebuiltin, Player
from xbmcvfs import mkdir
from xbmcaddon import Addon
if isPY2:from xbmc import translatePath
else: from xbmcvfs import translatePath

addonInfo = Addon().getAddonInfo
get_setting = Addon().getSetting
profilePath = translatePath(addonInfo('profile'))
addonPath = translatePath(addonInfo('path'))
skipFile = os.path.join(profilePath, 'skipintro.json')
if not os.path.exists(profilePath): mkdir(profilePath)


def to_unicode(text, encoding='utf-8', errors='strict'):
	"""Force text to unicode"""
	if isinstance(text, bytes):
		return text.decode(encoding, errors)
	return text


def from_unicode(text, encoding='utf-8', errors='strict'):
	"""Force unicode to text"""
	if isPY2 and isinstance(text, unicode):	 # noqa: F821; pylint: disable=undefined-variable,useless-suppression
		return text.encode(encoding, errors)
	return text


def logger(heading, function=None):
	import os
	log_file = os.path.join(translatePath('special://logpath/'), '%s.log' % 'Infinite')
	with open(log_file, 'a') as f:
		line = 'Skip Player: %s\n %s' % (heading, function)
		f.write(line.rstrip('\r\n') + '\n')


def clean_title(title):
	if title is None: return
	try:
		title = title.lower()
		title = re.sub(r'&#(\d+);', '', title)
		title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
		title = title.replace('&quot;', '\"').replace('&amp;', '&')
		title = re.sub(r'\<[^>]*\>', '', title)
		# title = re.sub(r'\n|([[].+?[]])|([(].+?[)])|\s(vs|v[.])\s|(:|;|-|"|,|\'|\_|\.|\?)|\(|\)|\[|\]|\{|\}|\s', '', title).lower()
		title = re.sub(r'\n|([\[({].+?[})\]])|([:;\-"\',!_.?~$@])|\s', '', title)
		return title.lower()
	except: return title

def open_file_wrapper(file, mode='r', encoding='utf-8'):
	"""
	use:
	json_path = os.path.join(path, filename)
	with open_file_wrapper(json_path)() as json_result:
		return json.load(json_result)
	"""
	if isPY2:
		return lambda: open(file, mode)
	return lambda: open(file, mode, encoding=encoding)


def updateSkip(title, seconds="50", eseconds="120", start="0", service=True):
	with open_file_wrapper(skipFile, mode='r')() as file:
		json_data = json.load(file)
	for item in json_data:
		if clean_title(item['title']) == clean_title(title):
			item['service'] = service
			item['skip'] = seconds
			item['eskip'] = eseconds
			item['start'] = start
	with open_file_wrapper(skipFile, mode='w')() as file:
		json.dump(json_data, file, indent=2)


def newskip(title, seconds=None, eseconds=None, start="0"):
	if not seconds: seconds = get_setting('default.skip')
	if not eseconds: eseconds = get_setting('default.eskip')
	newIntro = {'title': title, 'service': True, 'skip': seconds, 'start': start, 'eskip': eseconds}
	try:
		with open_file_wrapper(skipFile, mode='r')() as f:
			data = json.load(f)
	except:
		data = []
	data.append(newIntro)
	with open_file_wrapper(skipFile, mode='w')() as f:
		json.dump(data, f, indent=2)
	return newIntro


def get_skip_option(title):
	try:
		with open_file_wrapper(skipFile, mode='r')() as f: data = json.load(f)
		start = [i for i in data if clean_title(i['title']) == clean_title(title)][0]
	except: start = newskip(title)
	return start


def get_machine():
	"""Get machine architecture"""
	from platform import machine
	try:
		return machine()
	except Exception:  # pylint: disable=broad-except
		# Due to OS restrictions on 'ios' and 'tvos' this generate an exception
		# See python limits in the wiki development page
		# Fallback with a generic arm
		return 'arm'


def run_threaded(non_blocking, target_func, *args, **kwargs):
	"""Call a function in a thread, when specified"""
	if not non_blocking:
		return target_func(*args, **kwargs)
	from threading import Thread
	Thread(target=target_func, args=args, kwargs=kwargs).start()
	return None


# @time_execution(immediate=True)
def show_modal_dialog(non_blocking, dlg_class, xml, path, **kwargs):
	"""
	Show a modal Dialog in the UI.
	Pass kwargs minutes and/or seconds to have the dialog automatically
	close after the specified time.

	:return if exists return self.return_value value of dlg_class (if non_blocking=True return always None)
	"""
	# logger("**kwargs: %s" % kwargs)
	# WARNING: doModal when invoked does not release the function immediately!
	# it seems that doModal waiting for all window operations to be completed before return,
	# for example the "Skip" dialog takes about 30 seconds to release the function (test on Kodi 19.x)
	# To be taken into account because it can do very big delays in the execution of the invoking code
	return run_threaded(non_blocking, _show_modal_dialog, dlg_class, xml, path, **kwargs)


def _show_modal_dialog(dlg_class, xml, path, **kwargs):
	import time
	dlg = dlg_class(xml, path, 'default', '1080i', **kwargs)
	minutes = kwargs.get('minutes', 0)
	seconds = kwargs.get('seconds', 0)
	if minutes > 0 or seconds > 0:
		# Bug in Kodi AlarmClock function, if only the seconds are passed
		# the time conversion inside the function multiply the seconds by 60
		if seconds > 59 and minutes == 0:
			alarm_time = time.strftime('%M:%S', time.gmtime(seconds))
		else:
			alarm_time = '{:02d}:{:02d}'.format(minutes, seconds)
		# logger("alarm_time: %s" % alarm_time)
		executebuiltin('AlarmClock(closedialog,Action(noop),{},silent)'.format(alarm_time))
	dlg.doModal()
	# if Player().stop():
		# del dlg
	# if hasattr(dlg, 'return_value'):
		# del dlg
		# return #dlg.return_value
	return None

