# -*- coding: utf-8 -*-


try: from urlparse import parse_qsl
except: from urllib.parse import parse_qsl


def routing(argv):
	params = dict(parse_qsl(argv.replace('?', '')))
	mode = params.get('mode', None)
	if mode is None:
		print("TODO MAIN ADDON SECTION")
