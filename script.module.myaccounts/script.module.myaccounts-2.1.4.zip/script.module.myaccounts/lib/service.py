# -*- coding: utf-8 -*-
'''
	My Accounts
'''

from myaccounts.modules import control
from myaccounts.modules import log_utils
import _strptime
import xbmc
xbmc_monitor = xbmc.Monitor
LOGINFO = 1 # (LOGNOTICE(2) deprecated in 19, use LOGINFO(1))

class AddonCheckUpdate:
	def run(self):
		xbmc.log('[ script.module.myaccounts ]  Addon checking available updates', LOGINFO)
		try:
			import re
			import requests
			repo_xml = requests.get('https://raw.githubusercontent.com/djp11r/repo_n/mayb/script.module.myaccounts/addon.xml')
			if repo_xml.status_code != 200:
				return xbmc.log(f'[ script.module.myaccounts ]  Could not connect to remote repo XML: status code = {repo_xml.status_code}', LOGINFO)
			repo_version = re.search(r'<addon id=\"script.module.myaccounts\".*version=\"(\d*.\d*.\d*)\"', repo_xml.text, re.I).group(1)
			local_version = control.addonVersion()[:5] # 5 char max so pre-releases do try to compare more chars than github version
			def check_version_numbers(current, new): # Compares version numbers and return True if github version is newer
				current = current.split('.')
				new = new.split('.')
				step = 0
				for i in current:
					if int(new[step]) > int(i): return True
					if int(i) > int(new[step]): return False
					if int(i) == int(new[step]):
						step += 1
						continue
				return False
			if check_version_numbers(local_version, repo_version):
				while control.condVisibility('Library.IsScanningVideo'):
					control.sleep(10000)
				xbmc.log(f'[ script.module.myaccounts ]  A newer version is available. Installed Version: v{local_version}, Repo Version: v{repo_version}', LOGINFO)
				control.notification(message=control.lang(32072) % repo_version, time=5000)
			return xbmc.log('[ script.module.myaccounts ]  Addon update check complete', LOGINFO)
		except:
			import traceback
			traceback.print_exc()

class PremAccntNotification:
	def run(self):
		from datetime import datetime
		from myaccounts.modules import alldebrid
		from myaccounts.modules import premiumize
		from myaccounts.modules import realdebrid
		xbmc.log('[ script.module.myaccounts ]  Debrid Account Expiry Notification Service Starting...', LOGINFO)
		self.duration = [(15, 10), (11, 7), (8, 4), (5, 2), (3, 0)]
		if control.setting('trakt.client.id') in ['', None]:
			SetOrUpdateApi().run()
		if control.setting('alldebrid.username') != '' and control.setting('alldebrid.expiry.notice') == 'true':
			if account_info := alldebrid.AllDebrid().account_info()['user']:
				if not account_info['isSubscribed']:
					# log_utils.log('AD account_info = %s' % account_info, log_utils.LOGINFO)
					expires = datetime.fromtimestamp(account_info['premiumUntil'])
					days_remaining = (expires - datetime.today()).days # int
					if self.withinRangeCheck('alldebrid', days_remaining):
						control.notification(message=f'AllDebrid Account expires in {days_remaining} days', icon=control.joinPath(control.artPath(), 'alldebrid.png'))

		if control.setting('premiumize.username') != '' and control.setting('premiumize.expiry.notice') == 'true':
			if account_info := premiumize.Premiumize().account_info():
				# log_utils.log('PM account_info = %s' % account_info, log_utils.LOGINFO)
				expires = datetime.fromtimestamp(account_info['premium_until'])
				days_remaining = (expires - datetime.today()).days # int
				if self.withinRangeCheck('premiumize', days_remaining):
					control.notification(message=f'Premiumize.me Account expires in {days_remaining} days', icon=control.joinPath(control.artPath(), 'premiumize.png'))

		if control.setting('realdebrid.username') != '' and control.setting('realdebrid.expiry.notice') == 'true':
			if account_info := realdebrid.RealDebrid().account_info():
				import time
				# log_utils.log('RD account_info = %s' % account_info, log_utils.LOGINFO)
				FormatDateTime = "%Y-%m-%dT%H:%M:%S.%fZ"
				try: expires = datetime.strptime(account_info['expiration'], FormatDateTime)
				except: expires = datetime(*(time.strptime(account_info['expiration'], FormatDateTime)[:6]))
				days_remaining = (expires - datetime.today()).days # int
				if self.withinRangeCheck('realdebrid', days_remaining):
					control.notification(message=f'Real-Debrid Account expires in {days_remaining} days', icon=control.joinPath(control.artPath(), 'realdebrid.png'))

	def withinRangeCheck(self, debrid_provider, days_remaining):
		if days_remaining < 15:
			try: current_notification_range = int(control.setting(f'{debrid_provider}.notification.range'))
			except: current_notification_range = 5
			for index, day_range in enumerate(self.duration):
				if day_range[0] > days_remaining > day_range[1] and current_notification_range != index:
					control.setSetting(f'{debrid_provider}.notification.range', str(index))
					return True
		else:
			control.setSetting(f'{debrid_provider}.notification.range', '')

		return False

class SetOrUpdateApi:
	def run(self):
		xbmc.log('[ script.module.myaccounts ] set_or_update_api...', LOGINFO)
		from myaccounts.modules.trakt import client_id, client_secret
		tmdb_api_key = '05a454b451f2f9003fbca293744e4a85' # '1fab5f2129742be63561c063075a1535'
		# tmdb.username">aaaas<
		# tmdb.password">6666<
		tvdb_api_key = ''
		fanart_tv_api_key = 'a7ad21743fd710fccb738232f2fbdcfc' # 'fe073550acf157bdb8a4217f215c0882' # 'cf3429b06e1bbccc9d1e1b86b32fc51a'
		imdb_user = '56044779'
		# filepursuit.api.key "e1235ccc65msh9c6da42a2ff1797p199cefjsnaa4033afc078"
		# gdrive.cloudflare_url "https://wandering-river-0edc.rrosajp4.workers.dev"
		if control.setting('trakt.client.id') == '':
			control.setSetting('trakt.client.id', client_id)
			control.setSetting('trakt.client.secret', client_secret)
		if control.setting('tmdb.api.key') == '':
			control.setSetting('tmdb.api.key', tmdb_api_key)
			control.setSetting('tvdb.api.key', tvdb_api_key)
			control.setSetting('fanart.tv.api.key', fanart_tv_api_key)
			control.setSetting('imdb.user', imdb_user)
		xbmc.log('[ script.module.myaccounts ] set_or_update_api Complete', LOGINFO)



# PremAccntNotification().run()
class main(xbmc_monitor):
	def __init__(self):
		xbmc_monitor.__init__(self)
		self.startServices()

	def startServices(self):
		if control.setting('checkAddonUpdates') == 'true':
			AddonCheckUpdate().run()
			xbmc.log('[script.module.myaccounts] Addon update check complete', LOGINFO)

main().waitForAbort()
xbmc.log('[script.module.myaccounts] service stopped', LOGINFO)