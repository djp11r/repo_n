# -*- coding: utf-8 -*-
"""
	My Accounts
"""

from myaccounts.modules.control import addonPath, addonVersion, joinPath
from myaccounts.windows.textviewer import TextViewerXML


def get():
	myaccounts_path = addonPath()
	myaccounts_version = addonVersion()
	changelogfile = joinPath(myaccounts_path, 'changelog.txt')
	with open(changelogfile, 'r', encoding='utf-8', errors='ignore') as r:
		text = r.read()
	heading = f'[B]My Accounts -  v{myaccounts_version} - ChangeLog[/B]'
	windows = TextViewerXML('textviewer.xml', myaccounts_path, heading=heading, text=text)
	windows.run()
	del windows