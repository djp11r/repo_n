# -*- coding: utf-8 -*-
import os
from caches.main_cache import main_cache
from modules import source_utils
from modules.kodi_utils import list_dirs, open_file, urlparse
from modules.utils import clean_file_name, normalize
from modules.settings import filter_by_name
# from modules.kodi_utils import logger
from traceback import print_exc

extensions = source_utils.supported_video_extensions()
internal_results, check_title, clean_title, get_aliases_titles = source_utils.internal_results, source_utils.check_title, source_utils.clean_title, source_utils.get_aliases_titles
get_file_info, release_info_format, seas_ep_filter = source_utils.get_file_info, source_utils.release_info_format, source_utils.seas_ep_filter
gather_assigned_content, test_assigned_content = source_utils.gather_assigned_content, source_utils.test_assigned_content
command = 'SELECT id, data from maincache where id LIKE %s'

class source:
	def __init__(self, scrape_provider, scraper_name, folder_path):
		self.scrape_provider = scrape_provider
		self.scraper_name = scraper_name
		self.folder_path = folder_path
		self.sources, self.scrape_results = [], []

	def results(self, info):
		try:
			# from modules.kodi_utils import logger
			if not self.folder_path: return internal_results(self.scraper_name, self.sources)
			filter_title = filter_by_name('folders')
			self.media_type, title, self.year = info.get('media_type'), info.get('title'), int(info.get('year'))
			self.season, self.episode = info.get('season'), info.get('episode')
			self.tmdb_id = info.get('tmdb_id')
			self.title_query = clean_title(normalize(title))
			self.folder_query = self._season_query_list() if self.media_type == 'episode' else self._year_query_list()
			# self.pre_assigned_content = self._gather_assigned_content()
			self._scrape_directory(self.folder_path)
			if not self.scrape_results: return internal_results(self.scraper_name, self.sources)
			aliases = get_aliases_titles(info.get('aliases', []))
			def _process():
				for item in self.scrape_results:
					try:
						file_name = item[0]
						item_name = item[5]
						# logger(f'self.title_query: {self.title_query} item_name: {item_name}')
						if self.title_query not in item_name: continue
						if filter_title and not item[2] and not check_title(title, file_name, aliases, self.year, self.season, self.episode): continue
						display_name = clean_file_name(file_name).replace('html', ' ').replace('+', ' ').replace('-', ' ')
						#logger(f'display_name: {display_name} filter_title: {filter_title}')
						video_quality, details = get_file_info(name_info=release_info_format(file_name))
						yield {'name': file_name, 'display_name': display_name, 'quality': video_quality, 'size': item[3], 'size_label': '%.2f GB' % item[3],
									'extraInfo': details, 'url_dl': item[2], 'id': item[2], self.scrape_provider : True, 'direct': True, 'source': self.scraper_name,
									'scrape_provider': 'folders'}
					except: pass
			self.sources = list(_process())
		except Exception as e:
			from modules.kodi_utils import logger
			logger(f'infinite folders scraper Exception: {e} {print_exc()}')
		internal_results(self.scraper_name, self.sources)
		return self.sources

	def _year_query_list(self):
		return (str(self.year), str(self.year+1), str(self.year-1))

	def _season_query_list(self):
		return (f'season{int(self.season):02d}', f'season{self.season}')

	def _make_dirs(self, folder_info):
		def _get_url_path(folder, file):
			return os.path.join(folder, file)

		def _get_size(file):
			if file.endswith('.strm'): return 'strm'
			with open_file(file) as f: s = f.size()
			size = round(float(s)/1073741824, 2)
			return size
		folder_files = []
		folder_files_append = folder_files.append
		folder_name, assigned_content = folder_info[0], folder_info[1]
		dirs, files =  list_dirs(folder_name)
		# logger(f'dirs: {dirs}\nfiles: {files}')
		for i in dirs: folder_files_append((i, 'folder', _get_url_path(folder_name, i), 0, assigned_content, clean_title(normalize(i))))
		for file in files:
			ext = os.path.splitext(urlparse(file).path)[-1].lower()
			if ext in extensions:
				url_path = _get_url_path(folder_name, file)
				size = _get_size(url_path)
				folder_files_append((file, 'file', url_path, size, assigned_content, clean_title(normalize(file))))
		return folder_files

	def _scrape_directory(self, folder_path):
		string = f'infinite_FOLDERS_from_{folder_path}'
		self.scrape_results = main_cache.get(string)
		# logger(f'string: {string}\ndata {data}')
		if not self.scrape_results:
			self.scrape_results = self._make_dirs((folder_path, False))
			main_cache.set(string, self.scrape_results, expiration=5)
