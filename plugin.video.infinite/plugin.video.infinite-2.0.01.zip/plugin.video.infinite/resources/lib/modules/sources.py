# -*- coding: utf-8 -*-
import json
import time
from traceback import print_exc, print_stack
from threading import Thread
from windows.base_window import open_window, create_window
from caches.episode_groups_cache import episode_groups_cache
from caches.settings_cache import get_setting
from scrapers import external, folders

from modules.player import infinitePlayer
from modules.utils import string_to_float, safe_string, remove_accents, get_datetime, append_module_to_syspath, manual_function_import, manual_module_import
from modules.source_utils import get_cache_expiry, make_alias_dict, external_sources, check_hosted_media, providerstats, get_skip_option
from modules.kodi_utils import get_icon, notification, sleep, xbmc_monitor, select_dialog, confirm_dialog, close_all_dialog, show_busy_dialog, hide_busy_dialog, xbmc_player, get_property, set_property, clear_property, logger
from modules.settings import get_source_sorting_list, get_folderscraper_info, get_source_filter_by_size, auto_play, active_internal_scrapers, provider_sort_ranks, audio_filters, check_prescrape_sources, external_scraper_info, auto_resume, source_folders_directory, watched_indicators, quality_filter, sort_to_top, tmdb_api_key, mpaa_region, scraping_settings, include_prerelease_results, auto_rescrape_with_all, ignore_results_filter, results_sort_order, results_format, filter_status, autoplay_next_episode, autoscrape_next_episode, limit_resolve, auto_episode_group, preferred_autoplay
from modules.watched_status import get_progress_status_movie, get_bookmarks_movie, erase_bookmark, get_progress_status_episode, get_bookmarks_episode
from modules.metadata import tvshow_meta, episodes_meta, movie_meta, group_episode_data, group_details, episode_groups
sd_check = ('SD', 'CAM', 'TELE', 'SYNC')
quality_ranks = {'4K': 1, '1080p': 2, '720p': 3, 'SD': 4, 'SCR': 5, 'CAM': 5, 'TELE': 5}
folder_scrapers = ('folder1', 'folder2', 'folder3', 'folder4', 'folder5')
default_internal_scrapers = ('folders', 'easynews')
main_line = '%s[CR]%s[CR]%s'
int_window_prop = 'infinite.internal_results.%s'
scraper_timeout = int(get_setting('infinite.results.timeout', '20'))
filter_keys = {'hevc': '[B]HEVC[/B]', '3d': '[B]3D[/B]', 'hdr': '[B]HDR[/B]', 'dv': '[B]D/VISION[/B]', 'av1': '[B]AV1[/B]', 'enhanced_upscaled': '[B]AI ENHANCED/UPSCALED[/B]'}
preference_values = {0:100, 1:50, 2:20, 3:10, 4:5, 5:2}

class Sources():
	def __init__(self):
		self.params = {}
		self.prescrape_scrapers, self.prescrape_threads, self.prescrape_sources = [], [], []
		self.threads, self.providers, self.sources, self.internal_scraper_names, self.remove_scrapers = [], [], [], [], ['external']
		self.rescrape_with_all, self.rescrape_with_episode_group = False, False
		self.clear_properties, self.filters_ignored, self.active_folders, self.resolve_dialog_made, self.episode_group_used = True, False, False, False, False
		self.sources_total = self.sources_4k = self.sources_1080p = self.sources_720p = self.sources_sd = 0
		self.prescrape, self.disabled_ext_ignored, self.default_ext_only = 'true', 'false', 'false'
		self.ext_name, self.ext_folder, self.provider_defaults, self.ext_sources = '', '', [], None
		self.progress_dialog, self.progress_thread = None, None
		self.playing_filename = ''
		self.count_tuple = (('sources_4k', '4K', self._quality_length), ('sources_1080p', '1080p', self._quality_length), ('sources_720p', '720p', self._quality_length),
							('sources_sd', '', self._quality_length_sd), ('sources_total', '', self._quality_length_final))

	def playback_prep(self, params=None):
		hide_busy_dialog()
		if params: self.params = params
		# logger(f'>>>>> playback_prep params: {params}\nformat_stack: {print_stack(limit=15)}')
		params_get = self.params.get
		self.play_type, self.background, self.prescrape = params_get('play_type', ''), params_get('background', 'false') == 'true', params_get('prescrape', self.prescrape) == 'true'
		self.random, self.random_continual = params_get('random', 'false') == 'true', params_get('random_continual', 'false') == 'true'
		if self.play_type:
			if self.play_type == 'autoplay_nextep': self.autoplay_nextep, self.autoscrape_nextep = True, False
			elif self.play_type == 'random_continual': self.autoplay_nextep, self.autoscrape_nextep = False, False
			else: self.autoplay_nextep, self.autoscrape_nextep = False, True
		else: self.autoplay_nextep, self.autoscrape_nextep = autoplay_next_episode(), autoscrape_next_episode()
		self.autoscrape = self.autoscrape_nextep and self.background
		self.h_scrape = params_get('hindi_')
		if self.h_scrape: self.autoplay_nextep, self.autoscrape = False, False
		self.auto_rescrape_with_all, self.auto_episode_group = auto_rescrape_with_all(), auto_episode_group()
		self.nextep_settings, self.disable_autoplay_next_episode = params_get('nextep_settings', {}), params_get('disable_autoplay_next_episode', 'false') == 'true'
		self.ignore_scrape_filters = params_get('ignore_scrape_filters', 'false') == 'true'
		self.disabled_ext_ignored = params_get('disabled_ext_ignored', self.disabled_ext_ignored) == 'true'
		self.default_ext_only = params_get('default_ext_only', self.default_ext_only) == 'true'
		self.folders_ignore_filters = get_setting('infinite.results.folders_ignore_filters', 'false') == 'true'
		self.filter_size_method = int(get_setting('infinite.results.filter_size_method', '0'))
		self.media_type, self.tmdb_id, self.ep_name, self.plot = params_get('media_type') or params_get('mediatype'), params_get('tmdb_id'), params_get('ep_name'), params_get('plot')
		self.custom_title, self.custom_year = params_get('custom_title', None), params_get('custom_year', None)
		self.episode_group_label = params_get('episode_group_label', '')
		if self.media_type == 'episode':
			self.season, self.episode = int(params_get('season')), int(params_get('episode'))
			self.custom_season, self.custom_episode = params_get('custom_season', None), params_get('custom_episode', None)
			self.check_episode_group()
		else: self.season, self.episode, self.custom_season, self.custom_episode = '', '', '', ''
		if 'autoplay' in self.params: self.autoplay = params_get('autoplay', 'false') == 'true'
		else: self.autoplay = auto_play(self.media_type)
		self.title, self.year = params_get('title') or params_get('tvshowtitle', None), params_get('year', 2024)
		self.tvdb_id = params_get('tvdb_id')
		self.get_meta()
		self.determine_scrapers_status()
		self.sleep_time, self.provider_sort_ranks, self.scraper_settings = 100, provider_sort_ranks(), scraping_settings()
		self.include_prerelease_results, self.ignore_results_filter, self.limit_resolve = include_prerelease_results(), ignore_results_filter(), limit_resolve()
		self.sort_function, self.quality_filter = results_sort_order(), self._quality_filter()
		self.include_unknown_size = get_setting('infinite.results.size_unknown', 'false') == 'true'
		# logger(f'playback_prep self.title: {self.title} self.meta: {self.meta}')
		self.make_search_info()
		# logger(f'playback_prep self.search_info: {self.search_info}')
		if self.autoscrape: self.autoscrape_nextep_handler()
		else: return self.get_sources()

	def check_episode_group(self):
		try:
			if any([self.custom_season, self.custom_episode]) or 'skip_episode_group_check' in self.params: return
			group_info = episode_groups_cache.get(self.tmdb_id)
			if not group_info: return
			g_details = group_episode_data(group_details(group_info['id']), None, self.season, self.episode)
			if g_details:
				self.custom_season, self.custom_episode, self.episode_group_used = g_details['season'], g_details['episode'], True
				self.episode_group_label = '[B]CUSTOM GROUP: S%02dE%02d[/B]' % (self.custom_season, self.custom_episode)
		except: self.custom_season, self.custom_episode = None, None

	def determine_scrapers_status(self):
		self.active_internal_scrapers = active_internal_scrapers()
		if not 'external' in self.active_internal_scrapers and (self.disabled_ext_ignored or self.default_ext_only): self.active_internal_scrapers.append('external')
		self.active_external = 'external' in self.active_internal_scrapers

	def get_sources(self):
		if not self.progress_dialog and not self.background: self._make_progress_dialog()
		results = []
		if self.prescrape and any(x in self.active_internal_scrapers for x in default_internal_scrapers):
			if self.prepare_internal_scrapers():
				results = self.collect_prescrape_results()
				if results: results = self.process_results(results)
		# logger(f'1 get_sources self.prescrape: {self.prescrape} results: {results}')
		if not results:
			self.prescrape = False
			self.prepare_internal_scrapers()
			if self.active_external: self.activate_external_providers()
			elif not self.active_internal_scrapers: self._kill_progress_dialog()
			self.orig_results = self.collect_results()
			# logger(f'Sources().get_sources Total: {len(self.orig_results)} self.orig_results: {self.orig_results}')
			if not self.orig_results and not self.active_external: self._kill_progress_dialog()
			results = self.process_results(self.orig_results)
		if not results: return self._process_post_results()
		# logger(f'Sources().get_sources {len(results)} results: {results}')
		if self.autoscrape: return results
		else: return self.play_source(results)

	def collect_results(self):
		self.sources.extend(self.prescrape_sources)
		threads_append = self.threads.append
		if self.active_folders: self.append_folder_scrapers(self.providers)
		# logger(f'collect_results Total: {len(self.providers)} self.providers: {self.providers}')
		self.providers.extend(self.internal_sources())
		if self.providers:
			for i in self.providers: threads_append(Thread(target=self.activate_providers, args=(i[0], i[1], False), name=i[2]))
			[i.start() for i in self.threads]
		if self.active_external or self.background:
			if self.active_external:
				self.external_args = (self.meta, self.external_providers, self.internal_scraper_names,
										self.prescrape_sources, self.progress_dialog, self.disabled_ext_ignored)
				self.activate_providers('external', external, False)
			if self.background: [i.join() for i in self.threads]
		elif self.active_internal_scrapers: self.scrapers_dialog()
		# logger(f'collect_results self.sources: {self.sources}')
		return self.sources

	def collect_prescrape_results(self):
		threads_append = self.prescrape_threads.append
		if self.active_folders and (self.autoplay or check_prescrape_sources('folders', self.media_type)):
			self.append_folder_scrapers(self.prescrape_scrapers)
			self.remove_scrapers.append('folders')
		if not self.prescrape_scrapers: return []
		for i in self.prescrape_scrapers: threads_append(Thread(target=self.activate_providers, args=(i[0], i[1], True), name=i[2]))
		[i.start() for i in self.prescrape_threads]
		self.remove_scrapers.extend(i[2] for i in self.prescrape_scrapers)
		# logger(f'collect_prescrape_results self.prescrape: {self.prescrape}\nscraper_list prescrape_scrapers: {self.prescrape_scrapers}\n total prescrape_threads: {len(self.prescrape_threads)}')
		if self.background: [i.join() for i in self.prescrape_threads]
		else: self.scrapers_dialog()
		return self.prescrape_sources

	def process_results(self, results):
		if self.prescrape: self.all_scrapers = self.active_internal_scrapers
		else:
			self.all_scrapers = list(set(self.active_internal_scrapers + self.remove_scrapers))
			clear_property('fs_filterless_search')
		# logger(f'B4 sort_first: {len(results)} results: {results}')
		if self.ignore_scrape_filters:
			self.filters_ignored = True
			results = self.sort_results(results)
		else:
			results = self.sort_results(results)
			results = self.filter_results(results)
			results = self.filter_audio(results)
			for file_type in filter_keys: results = self.special_filter(results, file_type)
		results = self.sort_preferred_autoplay(results)
		results = self.sort_first(results)
		# logger(f'6 sort_first: {len(results)} results: {results}')
		return results

	def sort_results(self, results):
		for item in results:
			provider = item['scrape_provider']
			account_type = 'external' if provider == 'external' else provider.lower()
			item['provider_rank'] = self._get_provider_rank(account_type)
			item['quality_rank'] = self._get_quality_rank(item.get('quality', 'SD'))
		results.sort(key=self.sort_function)
		return results

	def filter_results(self, results):
		if self.folders_ignore_filters:
			folder_results = [i for i in results if i['scrape_provider'] == 'folders']
			results = [i for i in results if i not in folder_results]
		else: folder_results = []
		results = [i for i in results if i['quality'] in self.quality_filter]
		if self.filter_size_method:
			min_size = string_to_float(get_setting('infinite.results.%s_size_min' % self.media_type, '0'), '0') / 1000
			if min_size == 0.0 and not self.include_unknown_size: min_size = 0.02
			duration = self.meta['duration'] or (5400 if self.media_type == 'movie' else 2400)
			if self.filter_size_method == 1:
				max_size = ((0.125 * (0.90 * string_to_float(get_setting('results.line_speed', '25'), '25'))) * duration)/1000
			else: max_size = get_source_filter_by_size(self.media_type, duration)
			results = [i for i in results if i['scrape_provider'] == 'folders' or min_size <= i['size'] <= max_size]
		results += folder_results
		return results

	def filter_audio(self, results):
		return [i for i in results if not any(x in i['extraInfo'] for x in audio_filters())]

	def special_filter(self, results, file_type):
		enable_setting, key = filter_status(file_type), filter_keys[file_type]
		if key == '[B]HEVC[/B]' and enable_setting == 0:
			hevc_max_quality = self._get_quality_rank(get_setting('infinite.filter.hevc.%s' % ('max_autoplay_quality' if self.autoplay else 'max_quality'), '4K'))
			results = [i for i in results if not key in i['extraInfo'] or i['quality_rank'] >= hevc_max_quality]
		if enable_setting == 1:
			if key == '[B]D/VISION[/B]' and filter_status('hdr') == 0:
				results = [i for i in results if all(x in i['extraInfo'] for x in (key, '[B]HDR[/B]')) or not key in i['extraInfo']]
			else: results = [i for i in results if not key in i['extraInfo']]
		return results

	def sort_first(self, results):
		try:
			# logger(f'sort_first: {len(results)} results: {results}')
			sort_first_scrapers = []
			if 'folders' in self.all_scrapers: sort_first_scrapers.append('folders')
			if not sort_first_scrapers: return results
			sources_workmost = get_source_sorting_list()
			sort_first = [i for i in results if i['scrape_provider'] in sort_first_scrapers]
			sort_first += [b for b in results if b['source'].lower() == 'gdrive']
			sort_first.sort(key=lambda k: (self._sort_folder_to_top(k['scrape_provider']), k['quality_rank']))
			if not self.h_scrape: sort_first += list(filter(lambda x: any(y in x['source'].lower() for y in sources_workmost), results))
			else: sort_first += list(filter(lambda x: any(y in x['source'].lower() and 'All' in x['extraInfo'] for y in sources_workmost), results))
			sort_last = [i for i in results if i not in sort_first]
			results = sort_first + sort_last
			# logger(f'sort_first Total: {len(sort_first)} sort_first: {sort_first}\nsort_last   Total: {len(sort_last)} sort_last: {sort_last}')
		except: pass
		return results

	def sort_preferred_autoplay(self, results):
		if not self.autoplay: return results
		try:
			preferences = preferred_autoplay()
			if not preferences: return results
			preference_results = [i for i in results if any(x in i['extraInfo'] for x in preferences)]
			if not preference_results: return results
			results = [i for i in results if not i in preference_results]
			preference_results = sorted([dict(item, **{'pref_includes': sum([preference_values[preferences.index(x)] for x in [i for i in preferences if i in item['extraInfo']]])}) \
						for item in preference_results], key=lambda k: k['pref_includes'], reverse=True)
			return preference_results + results
		except Exception as e: logger(f'sort_preferred error: {str(e)}')
		return results

	def prepare_internal_scrapers(self):
		# if self.active_external and len(self.active_internal_scrapers) == 1: return
		active_internal_scrapers = [i for i in self.active_internal_scrapers if i not in self.remove_scrapers]
		# logger(f'1 prepare_internal_scrapers self.prescrape: {self.prescrape} self.active_internal_scrapers: {self.active_internal_scrapers} default_internal_scrapers: {default_internal_scrapers} self.remove_scrapers: {self.remove_scrapers}')
		if self.prescrape and not self.active_external and all(check_prescrape_sources(i, self.media_type) for i in active_internal_scrapers): return False
		if 'folders' in active_internal_scrapers:
			self.folder_info, self.internal_scraper_names = get_folderscraper_info(self.media_type)
			if self.folder_info:
				self.active_folders = True
		else:
			self.folder_info = []
			self.internal_scraper_names = active_internal_scrapers[:]
		# logger(f'self.folder_info: {self.folder_info} self.internal_scraper_names: {self.internal_scraper_names}')
		self.active_internal_scrapers = active_internal_scrapers
		if self.clear_properties: self._clear_properties()
		return True

	def activate_providers(self, module_type, function, prescrape):
		# logger(f'activate_providers module_type: {module_type} prescrape: {prescrape} function: {function}')# self.search_info : {self.search_info}')
		sources = self._get_module(module_type, function).results(self.search_info)
		if not sources: return
		if prescrape: self.prescrape_sources.extend(sources)
		else: self.sources.extend(sources)

	def activate_external_providers(self):
		# logger(f'ret_all=self.disabled_ext_ignored: {self.disabled_ext_ignored} media_type=self.media_type: {self.media_type} media_type=self.h_scrape: {self.h_scrape}')
		self.external_providers = external_sources(ret_all=self.disabled_ext_ignored, media_type=self.media_type, vid_type=self.h_scrape)

	def internal_sources(self, prescrape=False):
		try:
			sourceDict = [('internal', manual_function_import('scrapers.%s' % i, 'source'), i) for i in self.active_internal_scrapers if not (prescrape and not check_prescrape_sources(i, self.media_type))]
		except: sourceDict = []
		return sourceDict

	def folder_sources(self):
		def import_info():
			for item in self.folder_info:
				scraper_name = item[0]
				module = manual_function_import('scrapers.folders', 'source')
				yield 'folders', (module, (item[1], scraper_name, item[2])), scraper_name
		try: sourceDict = list(import_info())
		except: sourceDict = []
		return sourceDict

	def play_source(self, results):
		if self.background or self.autoplay: return self.play_file(results)
		return self.display_results(results)

	def append_folder_scrapers(self, current_list):
		current_list.extend(self.folder_sources())

	def scrapers_dialog(self):
		def _scraperDialog():
			monitor = xbmc_monitor()
			start_time = time.time()
			while not self.progress_dialog.iscanceled() and not monitor.abortRequested():
				try:
					remaining_providers = [x.getName() for x in _threads if x.is_alive() is True]
					self._process_internal_results()
					current_progress = max((time.time() - start_time), 0)
					line1 = ', '.join(remaining_providers).upper()
					percent = int((current_progress/float(scraper_timeout))*100)
					self.progress_dialog.update_scraper(self.sources_sd, self.sources_720p, self.sources_1080p, self.sources_4k, self.sources_total, line1, percent)
					sleep(self.sleep_time)
					if len(remaining_providers) == 0: break
					if percent >= 100: break
				except: return self._kill_progress_dialog()
		if self.prescrape: scraper_list, _threads = self.prescrape_scrapers, self.prescrape_threads
		else: scraper_list, _threads = self.providers, self.threads
		self.internal_scrapers = self._get_active_scraper_names(scraper_list)
		# logger(f'scrapers_dialog self.prescrape: {self.prescrape}\nscraper_list: {scraper_list}\n total _threads: {len(_threads)}\nself.internal_scrapers: {self.internal_scrapers}')
		if not self.internal_scrapers: return
		_scraperDialog()
		if self.prescrape: [i.join() for i in _threads]
		try: del monitor
		except: pass

	def display_results(self, results):
		window_format, window_number = results_format()
		action, chosen_item = open_window(('windows.sources', 'SourcesResults'), 'sources_results.xml',
				window_format=window_format, window_id=window_number, results=results, meta=self.meta, episode_group_label=self.episode_group_label,
				scraper_settings=self.scraper_settings, prescrape=self.prescrape, filters_ignored=self.filters_ignored)
		if not action: self._kill_progress_dialog()
		elif action == 'play': return self.play_file(results, chosen_item)
		elif self.prescrape and action == 'perform_full_search':
			self.prescrape, self.clear_properties = False, False
			return self.get_sources()

	def _get_active_scraper_names(self, scraper_list):
		return [i[2] for i in scraper_list]

	def _process_post_results(self):
		if self.auto_rescrape_with_all in (1, 2) and self.active_external and not self.rescrape_with_all:
			self.rescrape_with_all = True
			if self.auto_rescrape_with_all == 1 or confirm_dialog(heading=self.meta.get('rootname', ''), text='No results.[CR]Retry With All Scrapers?'):
				self.threads, self.disabled_ext_ignored, self.prescrape = [], True, False
				return self.get_sources()
		if self.media_type == 'episode' and self.auto_episode_group in (1, 2) and not self.rescrape_with_episode_group:
			self.rescrape_with_episode_group = True
			if self.auto_episode_group == 1 or confirm_dialog(heading=self.meta.get('rootname', ''), text='No results.[CR]Retry With Custom Episode Group if Possible?'):
				if self.episode_group_used:
					self.params.update({'custom_season': None, 'custom_episode': None, 'episode_group_label': '[B]CUSTOM GROUP: S%02dE%02d[/B]' % (self.season, self.episode),
										'skip_episode_group_check': True})
					self.threads, self.rescrape_with_all, self.disabled_ext_ignored, self.prescrape = [], True, True, False
					return self.playback_prep()
				if self.auto_episode_group == 2:
					from indexers.dialogs import episode_groups_choice
					try: group_id = episode_groups_choice({'meta': self.meta, 'poster': self.meta['poster']})
					except: group_id = None
				else:
					try: group_id = episode_groups(self.tmdb_id)[0]['id']
					except: group_id = None
				if group_id:
					try: g_details = group_episode_data(group_details(group_id), None, self.season, self.episode)
					except: g_details = None
					if g_details:
						season, episode = g_details['season'], g_details['episode']
						self.params.update({'custom_season': season, 'custom_episode': episode, 'episode_group_label': '[B]CUSTOM GROUP: S%02dE%02d[/B]' % (season, episode)})
						self.threads, self.rescrape_with_episode_group, self.rescrape_with_all, self.disabled_ext_ignored, self.prescrape = [], True, True, True, False
						return self.playback_prep()
		if self.orig_results and not self.background:
			if self.ignore_results_filter == 0: return self._no_results()
			if self.ignore_results_filter == 1 or confirm_dialog(heading=self.meta.get('rootname', ''), text='No results. Access Filtered Results?'):
				return self._process_ignore_filters()
		return self._no_results()

	def _process_ignore_filters(self):
		if self.autoplay: notification('Filters Ignored & Autoplay Disabled')
		self.filters_ignored, self.autoplay = True, False
		results = self.sort_results(self.orig_results)
		results = self.sort_preferred_autoplay(results)
		results = self.sort_first(results)
		return self.play_source(results)

	def _no_results(self):
		self._kill_progress_dialog()
		hide_busy_dialog()
		if self.background: return notification('[B]Next Up:[/B] No Results', 5000)
		notification('No Results', 2000)

	def get_search_title(self):
		search_title = self.meta.get('custom_title', None) or self.meta.get('english_title') or self.title
		return search_title

	def get_search_year(self):
		year = self.meta.get('custom_year', None) or self.meta.get('year')
		return year

	def get_season(self):
		season = self.meta.get('custom_season', None) or self.meta.get('season')
		try: season = int(season)
		except: season = None
		return season

	def get_episode(self):
		episode = self.meta.get('custom_episode', None) or self.meta.get('episode')
		try: episode = int(episode)
		except: episode = None
		return episode

	def get_ep_name(self):
		ep_name = None
		if self.meta['media_type'] == 'episode':
			ep_name = self.meta.get('ep_name')
			try: ep_name = safe_string(remove_accents(ep_name))
			except: ep_name = safe_string(ep_name)
		return ep_name

	def _process_internal_results(self):
		for i in self.internal_scrapers:
			win_property = get_property(int_window_prop % i)
			if win_property in ('checked', '', None): continue
			try: sources = json.loads(win_property)
			except: continue
			set_property(int_window_prop % i, 'checked')
			self._sources_quality_count(sources)

	def _sources_quality_count(self, sources):
		for item in self.count_tuple: setattr(self, item[0], getattr(self, item[0]) + item[2](sources, item[1]))

	def _quality_filter(self):
		setting = f'autoplay_quality_{self.media_type}' if self.autoplay else f'results_quality_{self.media_type}'
		filter_list = quality_filter(setting)
		if self.include_prerelease_results and 'SD' in filter_list: filter_list += ['SCR', 'CAM', 'TELE']
		return filter_list

	def _get_quality_rank(self, quality):
		return quality_ranks[quality]

	def _get_provider_rank(self, account_type):
		return self.provider_sort_ranks[account_type] or 11

	def _sort_folder_to_top(self, provider):
		return 0 if provider == 'folders' else 1

	def get_meta(self):
		function = movie_meta if self.media_type == 'movie' else tvshow_meta
		self.meta = function('tmdb_id', self.tmdb_id, tmdb_api_key(), mpaa_region(), get_datetime())
		skip_style = get_setting('infinite.skip.dialog')
		if not self.title: self.title = self.meta.get('title')
		if self.tvdb_id: self.meta.update({'tvdb_id': self.tvdb_id})
		if self.meta.get('blank_entry') and '|' in str(self.tvdb_id): self.meta = {'title': self.title, 'tmdb_id': self.tmdb_id, 'tvdb_id': self.tvdb_id, 'season': self.season, 'episode': self.episode, 'ep_name': self.ep_name, 'year': self.year, 'plot': self.plot, 'premiered': '2024-01-01', 'duration': 5400}
		if self.media_type == 'movie':
			self.skip_option = get_skip_option(self.title)
			self.display_name = f'{self.title} {self.meta.get("year")}'
		else:
			try:
				episodes_data = episodes_meta(self.season, self.meta)
				episode_data = [i for i in episodes_data if i['episode'] == self.episode][0]
				ep_thumb = episode_data.get('thumb') or self.meta.get('fanart') or ''
				episode_type = episode_data.get('episode_type', '')
				self.meta.update({'season': episode_data['season'], 'episode': episode_data['episode'], 'premiered': episode_data['premiered'], 'episode_type': episode_type,
								'ep_name': episode_data['title'], 'ep_thumb': ep_thumb, 'plot': episode_data['plot'], 'tvshow_plot': self.meta['plot'],
								'custom_season': self.custom_season, 'custom_episode': self.custom_episode})
			except: self.meta.update({'season': self.season, 'episode': self.episode, 'ep_name': self.ep_name, 'premiered': self.meta.get('premiered', ''), 'plot': self.meta.get('plot', ''), 'duration': self.meta.get('duration', 1320)})
			self.skip_option = get_skip_option(self.title)
			self.display_name = f'{self.title} S{self.season}E{self.episode}'
		self.meta.update({'media_type': self.media_type, 'background': self.background, 'custom_title': self.custom_title, 'custom_year': self.custom_year})
		self.meta.update({'skip_option': self.skip_option, 'skip_style' : skip_style, 'display_name': self.display_name})

	def make_search_info(self):
		title, year, ep_name = self.get_search_title(), self.get_search_year(), self.get_ep_name()
		if not self.h_scrape: aliases = make_alias_dict(self.meta, title)
		else: aliases = [{'title': title, 'country': '', 'url': self.meta.get('url', '')}]
		expiry_times = get_cache_expiry(self.media_type, self.meta, self.season)
		self.search_info = {'media_type': self.media_type, 'title': title, 'year': year, 'tmdb_id': self.tmdb_id, 'imdb_id': self.meta.get('imdb_id') or self.tvdb_id, 'aliases': aliases,
							'season': self.get_season(), 'episode': self.get_episode(), 'tvdb_id': self.tvdb_id, 'ep_name': ep_name, 'expiry_times': expiry_times,
							'total_seasons': self.meta.get('total_seasons') or self.meta.get('seasons', 1)}

	def _get_module(self, module_type, function):
		if module_type == 'external': return function.source(*self.external_args)
		elif module_type == 'folders': return function[0](*function[1])
		else: return function()

	def _clear_properties(self):
		for item in default_internal_scrapers: clear_property(int_window_prop % item)
		if self.active_folders:
			for item in self.folder_info: clear_property(int_window_prop % item[0])

	def _make_progress_dialog(self):
		self.progress_dialog = create_window(('windows.sources', 'SourcesPlayback'), 'sources_playback.xml', meta=self.meta)
		self.progress_thread = Thread(target=self.progress_dialog.run)
		self.progress_thread.start()

	def _make_resolve_dialog(self):
		self.resolve_dialog_made = True
		if not self.progress_dialog: self._make_progress_dialog()
		self.progress_dialog.enable_resolver()

	def _make_resume_dialog(self, percent):
		if not self.progress_dialog: self._make_progress_dialog()
		self.progress_dialog.enable_resume(percent)
		return self.progress_dialog.resume_choice

	def _make_nextep_dialog(self, default_action='cancel'):
		try: action = open_window(('windows.next_episode', 'NextEpisode'), 'next_episode.xml', meta=self.meta, default_action=default_action)
		except: action = 'cancel'
		return action

	def _make_intro_skip(self, total_time):
		notification(f'Next Episodes Cancelled', 3000)
		try: open_window(('windows.skip', 'Skip'), 'skipmulti.xml', skip_win_time=total_time, skip_option=self.skip_option, media_type=self.media_type, window_style='end_skip')
		except: logger(f'_make_intro_skip Error: {print_exc()}')
		return False

	def _kill_progress_dialog(self):
		success = 0
		try:
			self.progress_dialog.close()
			success += 1
			del self.progress_dialog
		except: pass
		try:
			self.progress_thread.join()
			success += 1
			del self.progress_thread
		except: pass
		if not success == 2: close_all_dialog()
		self.progress_dialog, self.progress_thread = None, None

	def play_file(self, results, source={}):
		self.playback_successful, self.cancel_all_playback, url = None, None, False
		try:
			hide_busy_dialog()
			url = None
			total_items = len(results)
			if not source: source = results[0]
			items = [source]
			if not self.limit_resolve:
				source_index = results.index(source)
				results.remove(source)
				items_prev = results[:source_index]
				items_prev.reverse()
				items_next = results[source_index:]
				items = items + items_next + items_prev
			processed_items = []
			processed_items_append = processed_items.append
			for count, item in enumerate(items, 1):
				resolve_item = dict(item)
				provider = item['scrape_provider']
				if provider == 'external': provider = f'From: {item.get("provider_site", "")} | {item.get("source", "")}'
				elif provider == 'folders': provider = item['source']
				provider_text = provider.upper()
				extra_info = f'[B]{item["quality"]}[/B] | [B]{item["size_label"]}[/B] | {item["extraInfo"]}'
				resolve_item['resolve_display'] = f'••••  {"%02d/%02d of %02d [B]%s[/B]" % (count, len(items), total_items, provider_text)}  ••••[CR]••••  {extra_info}  ••••'
				processed_items_append(resolve_item)
			items = list(processed_items)
			if not self.continue_resolve_check(): return self._kill_progress_dialog()
			hide_busy_dialog()
			self.playback_percent = self.get_playback_percent()
			if self.playback_percent is None: return self._kill_progress_dialog()
			if not self.resolve_dialog_made: self._make_resolve_dialog()
			if self.background: sleep(1000)
			monitor = xbmc_monitor()
			for count, item in enumerate(items, 1):
				try:
					hide_busy_dialog()
					if not self.progress_dialog: break
					self.progress_dialog.reset_is_cancelled()
					self.progress_dialog.update_resolver(text=item['resolve_display'])
					self.progress_dialog.busy_spinner()
					if count > 1:
						sleep(200)
						try: del player
						except: pass
					url, self.playback_successful, self.cancel_all_playback = None, None, False
					self.playing_filename = item['name']
					self.playing_item = item
					player = infinitePlayer()
					try:
						if self.progress_dialog.iscanceled() or monitor.abortRequested(): break
						url = self.resolve_sources(item)
						if url:
							try: providerstats(item['source'])
							except: pass
							resolve_percent = 0
							self.progress_dialog.busy_spinner('false')
							self.progress_dialog.update_resolver(percent=resolve_percent)
							sleep(200)
							player.run(url, self)
						else: continue
						if self.playback_successful or self.cancel_all_playback: break
						if self.playback_successful is False: continue
						if count == len(items):
							self.cancel_all_playback = True
							player.stop()
							break
					except: logger(f'2play_file Error item: {item}: {print_exc()}')
				except: logger(f'3play_file Error item: {item}: {print_exc()}')
		except:
			logger(f'1play_file Error item: {items}: {print_exc()}')
			self._kill_progress_dialog()
		if self.cancel_all_playback: return self._kill_progress_dialog()
		if not self.playback_successful or not url: self.playback_failed_action()
		try: del monitor
		except: pass

	def get_playback_percent(self):
		if self.h_scrape: media_id = self.tvdb_id
		else: media_id = self.tmdb_id
		if self.media_type == 'movie':
			if self.h_scrape: percent = get_progress_status_movie(get_bookmarks_movie(media_id), str(media_id))
			else: percent = get_progress_status_movie(get_bookmarks_movie(), str(media_id))
		elif any((self.random, self.random_continual)): return 0.0
		else: percent = get_progress_status_episode(get_bookmarks_episode(media_id, self.season), self.episode)
		if not percent: return 0.0
		action = self.get_resume_status(percent)
		if action == 'cancel': return None
		if action == 'start_over':
			erase_bookmark(self.media_type, self.tmdb_id, self.season, self.episode)
			return 0.0
		return float(percent)

	def get_resume_status(self, percent):
		if auto_resume(self.media_type): return float(percent)
		return self._make_resume_dialog(percent)

	def playback_failed_action(self):
		self._kill_progress_dialog()
		if self.prescrape and self.autoplay:
			self.resolve_dialog_made, self.prescrape, self.prescrape_sources = False, False, []
			self.get_sources()

	def continue_resolve_check(self):
		try:
			if not self.background or self.autoscrape_nextep: return True
			if self.autoplay_nextep: return self.autoplay_nextep_handler()
			return self.random_continual_handler()
		except: return False

	def random_continual_handler(self):
		notification('[B]Next Up:[/B] %s S%02dE%02d' % (self.meta.get('title'), self.meta.get('season'), self.meta.get('episode')), 6500, self.meta.get('poster'))
		player = xbmc_player()
		while player.isPlayingVideo(): sleep(100)
		self._make_resolve_dialog()
		return True

	def autoplay_nextep_handler(self):
		if not self.nextep_settings: return False
		player = xbmc_player()
		if player.isPlayingVideo():
			total_time = player.getTotalTime()
			use_window, window_time, default_action = self.nextep_settings['use_window'], self.nextep_settings['window_time'], self.nextep_settings['default_action']
			action = None if use_window else 'close'
			continue_nextep = False
			while player.isPlayingVideo():
				try:
					if round(total_time - player.getTime()) <= window_time:
						continue_nextep = True
						break
					sleep(100)
				except: pass
			if continue_nextep:
				if use_window: action = self._make_nextep_dialog(default_action=default_action)
				else: notification('[B]Next Up:[/B] %s S%02dE%02d' % (self.meta.get('title'), self.meta.get('season'), self.meta.get('episode')), 6500, self.meta.get('poster'))
				if not action: action = default_action
				if action in ('cancel', 'close'): return self._make_intro_skip(total_time)
				elif action == 'pause':
					player.stop()
					return False
				elif action == 'play':
					self._make_resolve_dialog()
					player.stop()
					return True
				else:
					while player.isPlayingVideo(): sleep(100)
					self._make_resolve_dialog()
					return True
			else: return False
		else: return False

	def autoscrape_nextep_handler(self):
		player = xbmc_player()
		if player.isPlayingVideo():
			results = self.get_sources()
			if not results: return notification('No Auto Scrape Sources Found', 3000)
			else:
				notification('[B]Next Episode Ready:[/B] %s S%02dE%02d' % (self.meta.get('title'), self.meta.get('season'), self.meta.get('episode')), 6500, self.meta.get('poster'))
				while player.isPlayingVideo(): sleep(100)
			self.display_results(results)
		else: return

	def resolve_sources(self, item, meta=None):
		try:
			if item.get('scrape_provider', None) == 'folders': return item['url_dl']
			else: return self.resolve_free_links(item)
		except: return

	def _quality_length(self, items, quality):
		return len([i for i in items if i['quality'] == quality])

	def _quality_length_sd(self, items, dummy):
		return len([i for i in items if i['quality'] in sd_check])

	def _quality_length_final(self, items, dummy):
		return len(items)

	def resolve_free_links(self, item):
		try:
			url, direct = item['url'], item.get('direct')
			# logger(f'resolv url b4 call.resolve: {repr(url)}')
			if 'plugin.video.youtube' in url or url.startswith('Direct_'): return url
			if direct:
				urls = url.split(' , ')
				url = f'stack://{" , ".join(urls)}' if len(urls) > 1 else urls[0]
				return url
			module_path = f'openscrapers.sources_openscrapers.en.{item["provider_site"]}'
			call = manual_module_import(module_path).source()
			url = call.resolve(url)
			# logger(f'call.resolve(url) return from: {module_path} url: {repr(url)}')
			if url is None or ('://' not in str(url)): raise Exception(item)# and not local and 'magnet:' not in str(url)):
			url = url[8:] if url.startswith('stack:') else url
			urls = []
			# logger(f'resolv url scrape_provider : {url}')
			for part in url.split(' , '):
				if '.videoapne.co' in part and part.endswith('v.mp4'): urls.append(part)
				else:
					# logger(f'resolv url part : {part}')
					rpart = check_hosted_media(part) #, include_disabled=True, include_universal=False)
					# logger(f'resolv urls after hmf : {hmf}')
					if rpart: urls.append(rpart)
					# logger(f'resolv urls after r_part : {part}')
			# logger(f'resolve_free_links after hmf.resolve() total urls: {len(urls)} urls: {urls}')
			if not urls: return None
			url = 'stack://' + ' , '.join(urls) if len(urls) > 1 else urls[0]
			if url is False or url is None or 'com/ads' in url: return None
			ext = url.split('?')[0].split('&')[0].split('|')[0].rsplit('.')[-1].replace('/', '').lower()
			# logger(f'resolve_free_links return url from hmf.resolve(): {url}\nitem: {item}')
			return None if ext == 'rar' else url
		except:
			logger(f'resolve_free_links Error with item: {item}')
			return None
