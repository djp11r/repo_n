# -*- coding: utf-8 -*-
import re
import sys
import time
import copy
import hashlib
import random
import _strptime
import unicodedata
from html import unescape
from queue import SimpleQueue
from threading import Thread, active_count
from zipfile import ZipFile
from importlib import import_module, reload as rel_module
from datetime import datetime, timedelta, date
from modules.settings import max_threads
from modules.kodi_utils import translate_path, sleep, show_busy_dialog, hide_busy_dialog, path_exists
from modules.kodi_utils import logger
from json import dumps


class TaskPool:
	@staticmethod
	def process(_threads):
		for index, i in enumerate(_threads, 1):
			try: i.start()
			except Exception as e: logger(f'thread error: {index}: {e}')
			else: yield i

	def __init__(self, maxsize=None):
		self.maxsize = maxsize or max_threads()
		self._queue = SimpleQueue()

	def _thread_target(self, queue, target):
		while not queue.empty():
			try: target(*queue.get())
			except Exception as e: logger(f'queue error {e}')

	def tasks(self, _target, _list, _thread):
		maxsize = min(len(_list), self.maxsize)
		[self._queue.put(tag) for tag in _list]
		threads = [_thread(target=self._thread_target, args=(self._queue, _target)) for i in range(maxsize)]
		return list(self.process(threads))

	def tasks_enumerate(self, _target, _list, _thread):
		maxsize = min(len(_list), self.maxsize)
		[self._queue.put((p, tag)) for p, tag in enumerate(_list, 1)]
		threads = [_thread(target=self._thread_target, args=(self._queue, _target)) for i in range(maxsize)]
		return list(self.process(threads))


def years_list(decades=None):
    interation = -10 if decades else -1
    year = datetime.today().year
    return list(range(year, 1899, interation))

def change_image_resolution(image, replace_res):
	return re.sub(r'(w185|w300|w342|w780|w1280|h632|original)', replace_res, image)

def append_module_to_syspath(location):
	sys.path.append(translate_path(location))

def manual_function_import(location, function_name):
	return getattr(import_module(location), function_name)

def reload_module(location):
	return rel_module(manual_module_import(location))

def manual_module_import(location):
	return import_module(location)

def make_thread_list(_target, _list):
	_max_threads = max_threads()
	for item in _list:
		while active_count() > _max_threads: sleep(1)
		threaded_object = Thread(target=_target, args=(item,))
		threaded_object.start()
		yield threaded_object

def make_thread_list_multi_arg(_target, _list):
	_max_threads = max_threads()
	for item in _list:
		while active_count() > _max_threads: sleep(1)
		threaded_object = Thread(target=_target, args=item)
		threaded_object.start()
		yield threaded_object

def make_thread_list_enumerate(_target, _list):
	_max_threads = max_threads()
	for count, item in enumerate(_list):
		while active_count() > _max_threads: sleep(1)
		threaded_object = Thread(target=_target, args=(count, item))
		threaded_object.start()
		yield threaded_object

def chunks(item_list, limit):
	"""
	Yield successive limit-sized chunks from item_list.
	"""
	for i in range(0, len(item_list), limit): yield item_list[i:i + limit]

def string_to_float(string, default_return):
	"""
	Remove all alpha from string and return a float.
	Returns float of "default_return" upon ValueError.
	"""
	try: return float(''.join(c for c in string if (c.isdigit() or c =='.')))
	except ValueError: return float(default_return)

def string_alphanum_to_num(string):
	"""
	Remove all alpha from string and return remaining string.
	Returns original string upon ValueError.
	"""
	try: return ''.join(c for c in string if c.isdigit())
	except ValueError: return string

def jsondate_to_datetime(jsondate_object, resformat, remove_time=False):
	if not jsondate_object: return None
	return (
		datetime_workaround(jsondate_object, resformat).date()
		if remove_time
		else datetime_workaround(jsondate_object, resformat)
	)

def get_datetime(string=False, dt=False):
	d = datetime.now()
	if dt: return d
	return d.strftime('%Y-%m-%d') if string else datetime.date(d)

def get_current_timestamp():
	return int(time.time())

def adjust_premiered_date(orig_date, adjust_hours):
	if not orig_date: return None, None
	orig_date += ' 20:00:00'
	datetime_object = jsondate_to_datetime(orig_date, '%Y-%m-%d %H:%M:%S')
	adjusted_datetime = datetime_object + timedelta(hours=adjust_hours)
	adjusted_string = adjusted_datetime.strftime('%Y-%m-%d')
	return adjusted_datetime.date(), adjusted_string

def make_day(today, date, date_format='%Y-%m-%d', use_words=True):
	if use_words:
		day_diff = (date - today).days
		if day_diff == -1: day = 'YESTERDAY'
		elif day_diff == 0: day = 'TODAY'
		elif day_diff == 1: day = 'TOMORROW'
		elif 1 < day_diff < 7: day = date.strftime('%a')
		else:
			try: day = date.strftime(date_format)
			except ValueError: day = date.strftime('%Y-%m-%d')
	else:
		try: day = date.strftime(date_format)
		except ValueError: day = date.strftime('%Y-%m-%d')
	return day

def subtract_dates(date1, date2):
	return (date1 - date2).days

def datetime_workaround(data, str_format):
	try: datetime_object = datetime.strptime(data, str_format)
	except: datetime_object = datetime(*(time.strptime(data, str_format)[:6]))
	return datetime_object

def date_difference(current_date, compare_date, difference_tolerance, allow_postive_difference=False):
	try:
		difference = subtract_dates(current_date, compare_date)
		if not allow_postive_difference and difference > 0: return False
		else: difference = abs(difference)
		return difference <= difference_tolerance
	except: return True

def calculate_age(born, str_format, died=None):
	''' born and died are str objects e.g. '1972-05-28' '''
	born = datetime_workaround(born, str_format)
	today = datetime_workaround(died, str_format) if died else date.today()
	return today.year - born.year - ((today.month, today.day) < (born.month, born.day))

def batch_replace(s, replace_info):
	for r in replace_info:
		s = str(s).replace(r[0], r[1])
	return s

def clean_file_name(s, use_encoding=False, use_blanks=True):
	try:
		hex_entities = [['&#x26;', '&'], ['&#x27;', '\''], ['&#xC6;', 'AE'], ['&#xC7;', 'C'],
					['&#xF4;', 'o'], ['&#xE9;', 'e'], ['&#xEB;', 'e'], ['&#xED;', 'i'],
					['&#xEE;', 'i'], ['&#xA2;', 'c'], ['&#xE2;', 'a'], ['&#xEF;', 'i'],
					['&#xE1;', 'a'], ['&#xE8;', 'e'], ['%2E', '.'], ['&frac12;', '%BD'],
					['&#xBD;', '%BD'], ['&#xB3;', '%B3'], ['&#xB0;', '%B0'], ['&amp;', '&'],
					['&#xB7;', '.'], ['&#xE4;', 'A'], ['\xe2\x80\x99', '']]
		special_encoded = [['"', '%22'], ['*', '%2A'], ['/', '%2F'], [':', ','], ['<', '%3C'],
							['>', '%3E'], ['?', '%3F'], ['\\', '%5C'], ['|', '%7C']]

		special_blanks = [['"', ' '], ['/', ' '], [':', ''], ['<', ' '],
							['>', ' '], ['?', ' '], ['\\', ' '], ['|', ' '], ['%BD;', ' '],
							['%B3;', ' '], ['%B0;', ' '], ["'", ""], [' - ', ' '], ['.', ' '],
							['!', ''], [';', ''], [',', '']]
		s = batch_replace(s, hex_entities)
		if use_encoding: s = batch_replace(s, special_encoded)
		if use_blanks: s = batch_replace(s, special_blanks)
		s = s.strip()
	except: pass
	return s


def clean_title(title): # 'Hit: The First Case (Hindi)' >> hit the first case
    if title is None: return
    exctract_date = re.compile(r'(\d{1,2}[th|st|nd|rd]* [Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|August|Sep|September|Oct|October|Nov|November|Dec|December]* \d{2,4})', flags=re.I)
    season_episode_data = re.compile(r'[Ee]pisode.+?(\d+)|[Ee]p (\d+)|[Ee](\d+)|[sS]eason.+?(\d+)|[sS]eason(\d+)|[sS](\d+)|[Cc]hapter (\d+)', flags=re.I)
    ascii_char = re.compile(r'(\x9B|\x1B\[)[0-?]*[ -\/]*[@-~]', flags=re.I)
    non_ascii_char = re.compile(r'[^\x00-\x7f]', flags=re.I)
    color_data = re.compile(r'\[COLOR.+?\].+?\[\/COLOR\]|\(.*?\)+', flags=re.I)
    try:
        title = title.lower()
        title = re.sub(color_data, '', title)  # remove date like [COLOR yellow]1x1[/COLOR] OR [COLOR cyan]July 10, 2017[/COLOR] or ( any thing( #)
        title = re.sub(exctract_date, '', title) # remove date like 18th April 2021
        title = re.sub(season_episode_data, '', title) # remove episode 12 or season 1 etc
        title = re.sub(ascii_char, '', title)  # remove ascii_char
        title = re.sub(non_ascii_char, '', title)  # remove non_ascii_char
        title = re.sub(r'&#(\d+);', '', title)
        title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
        title = title.replace('&quot;', '\"').replace('&amp;', '&')
        title = re.sub(r'([:;\-"\',!#`_.?~$@])', '', title) # remove all characters in bracket
        title = re.sub(r'\<[^>]*\>|\([^)]*\)', '', title) # remove in bracket like this <any thing> or (any thing)
        # title = re.sub(r'\n|([[].+?[]])|([(].+?[)])|\s(vs|v[.])\s|(:|;|-|"|,|\'|\_|\.|\?)|\(|\)|\[|\]|\{|\}|\s', '', title).lower()
        # title = re.sub(r'\n|([\[({].+?[})\]])|([:;\-"\',!_.?~$@])|\s', '', title)
        title = re.sub(r'\s+', ' ', title) # remove Multiple Spaces
        title = re.sub(r'\d{4}', ' ', title) # remove year Spaces
    except: pass
    return title.strip()


def byteify(data, ignore_dicts=False):
	try:
		if isinstance(data, str): return data.encode('utf-8', 'ignore')
		if isinstance(data, list): return [byteify(item, ignore_dicts=True) for item in data]
		if isinstance(data, dict) and not ignore_dicts: return dict([(byteify(key, ignore_dicts=True), byteify(value, ignore_dicts=True)) for key, value in data.items()])
		return data.encode('utf-8') if str(type(data)) == "<type 'unicode'>" else data
	except: pass
	return data

def normalize(txt):
	txt = re.sub(r'[^\x00-\x7f]', r'', txt)
	return txt

def safe_string(obj):
	try:
		try: return str(obj)
		except UnicodeEncodeError: return obj.encode('utf-8', 'ignore').decode('ascii', 'ignore')
		except: return ""
	except: return obj

def remove_accents(obj):
	try:
		try: obj = f'{obj}'
		except: pass
		obj = ''.join(c for c in unicodedata.normalize('NFD', obj) if unicodedata.category(c) != 'Mn')
	except: pass
	return obj

def regex_from_to(text, from_string, to_string, excluding=True):
	return (
		re.search(rf"(?i){from_string}" + r"([\S\s]+?)" + to_string, text)[1]
		if excluding
		else re.search(rf"(?i)({from_string}" + r"[\S\s]+?" + to_string + ")", text)[1]
	)

def regex_get_all(text, start_with, end_with):
	return re.findall(rf"(?i)({start_with}" + r"[\S\s]+?" + end_with + ")", text)

def replace_html_codes(txt):
	if not txt: return ''
	txt = re.sub(r"(&#[0-9]+)([^;^0-9]+)", "\\1;\\2", txt)
	txt = re.sub(r'[^\x00-\x7f]',r'', txt) # remove all non-ASCII characters
	txt = unescape(txt)
	txt = txt.replace("<ul>", "\n")
	txt = txt.replace("</ul>", "\n")
	txt = txt.replace("<li>", "\n* ")
	txt = txt.replace("</li>", "")
	txt = txt.replace("<br/><br/>", "\n")
	txt = txt.replace("&quot;", "\"")
	txt = txt.replace("&amp;", "&")
	txt = txt.replace('&Amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&#38;', '&').replace('&nbsp;', '').replace('&#8211;', '-').replace('&#8217;', '\'').replace('&#8230;', ' ')
	txt = txt.replace("[spoiler]", "").replace("[/spoiler]", "")
	txt = txt.strip()
	return txt

def gen_file_hash(file):
	try:
		md5_hash = hashlib.md5()
		with open(file, 'rb') as afile:
			buf = afile.read()
			md5_hash.update(buf)
			return md5_hash.hexdigest()
	except: pass

def sec2time(sec, n_msec=3):
	""" Convert seconds to 'D days, HH:MM:SS.FFF' """
	if hasattr(sec,'__len__'): return [sec2time(s) for s in sec]
	m, s = divmod(sec, 60)
	h, m = divmod(m, 60)
	d, h = divmod(h, 24)
	if n_msec > 0: pattern = '%%02d:%%02d:%%0%d.%df' % (n_msec+3, n_msec)
	else: pattern = '%02d:%02d:%02d'
	return pattern % (h, m, s) if d == 0 else f'{d:d} days, {h:02d}:{m:02d}:{s:02d}'

def released_key(item):
	if 'released' in item: return item['released'] or '2050-01-01'
	if 'first_aired' in item: return item['first_aired'] or '2050-01-01'
	return '2050-01-01'

def title_key(title):
	try:
		if title is None: title = ''
		articles = ['the', 'a', 'an']
		match = re.match(r'^((\w+)\s+)', title.lower())
		offset = len(match[1]) if match and match[2] in articles else 0
		return title[offset:]
	except: return title

def sort_for_article(_list, _key):
	_list.sort(key=lambda k: re.sub(r'(^the |^a |^an )', '', k[_key].lower()))
	return _list

def sort_list(sort_key, sort_direction, list_data):
	try:
		reverse = sort_direction != 'asc'
		if sort_key == 'rank': return sorted(list_data, key=lambda x: x['rank'], reverse=reverse)
		if sort_key == 'added': return sorted(list_data, key=lambda x: x['listed_at'], reverse=reverse)
		if sort_key == 'title': return sorted(list_data, key=lambda x: title_key(x[x['type']].get('title')), reverse=reverse)
		if sort_key == 'released': return sorted(list_data, key=lambda x: released_key(x[x['type']]), reverse=reverse)
		if sort_key == 'runtime': return sorted(list_data, key=lambda x: x[x['type']].get('runtime', 0), reverse=reverse)
		if sort_key == 'popularity': return sorted(list_data, key=lambda x: x[x['type']].get('votes', 0), reverse=reverse)
		if sort_key == 'percentage': return sorted(list_data, key=lambda x: x[x['type']].get('rating', 0), reverse=reverse)
		if sort_key == 'votes': return sorted(list_data, key=lambda x: x[x['type']].get('votes', 0), reverse=reverse)
		if sort_key == 'random': return sorted(list_data, key=lambda k: random.random())
		return list_data
	except: return list_data

def paginate_list(item_list, page, limit=20, paginate_start=0):
	if paginate_start:
		all_pages = dumps(list(chunks(item_list, limit)))
		item_list = item_list[paginate_start:]
		pages = list(chunks(item_list, limit))
		pages.insert(0, [])
	else:
		pages = list(chunks(item_list, limit))
		all_pages = dumps(pages)
	try: return (pages[page - 1], len(pages), all_pages)
	except: return (item_list, len(pages), all_pages)

def make_title_slug(name):
	name = name.strip()
	name = name.lower()
	name = re.sub('[^a-z0-9_]', '-', name)
	name = re.sub('--+', '-', name)
	return name

def unzip(zip_location, destination_location, destination_check, show_busy=True):
	if show_busy: show_busy_dialog()
	try:
		zipfile = ZipFile(zip_location)
		zipfile.extractall(path=destination_location)
		if path_exists(destination_check): status = True
		else: status = False
	except: status = False
	if show_busy: hide_busy_dialog()
	return status

def copy2clip(txt):
	if sys.platform == "win32":
		try:
			from subprocess import check_call
			cmd = 'echo ' + txt.replace('&', '^&').strip() + '|clip'
			return check_call(cmd, shell=True)
		except: return
	if sys.platform == "darwin":
		try:
			from subprocess import check_call
			cmd = f'echo {txt.strip()}|pbcopy'
			return check_call(cmd, shell=True)
		except: return
	if sys.platform == "linux":
		try:
			from subprocess import Popen, PIPE
			p = Popen(['xsel', '-pi'], stdin=PIPE)
			p.communicate(input=txt)
		except: return

def list_to_string(_list):
	if isinstance(_list, list):
		_list = ', '.join(list(_list))
	return _list

def try_parse_int(string):
	try: return int(string)
	except: return 0

def to_utf8(obj):
	try:
		if isinstance(obj, str):
			obj = obj.encode('utf-8', 'ignore')
		elif isinstance(obj, dict):
			obj = copy.deepcopy(obj)
			for key, val in obj.items():
				obj[key] = to_utf8(val)
		elif obj is not None and hasattr(obj, "__iter__"):
			obj = obj.__class__([to_utf8(x) for x in obj])
	except: pass
	return obj

def to_unicode(obj):
	try:
		if isinstance(obj, str):
			# try: obj = unicode(obj, 'utf-8')
			# except TypeError: pass
			pass
		elif isinstance(obj, dict):
			obj = copy.deepcopy(obj)
			for key, val in obj.items():
				obj[key] = to_unicode(val)
		elif obj is not None and hasattr(obj, "__iter__"):
			obj = obj.__class__([to_unicode(x) for x in obj])
	except: pass
	return obj

def merge_dicts(*dict_args):
	"""
	Given any number of dicts, shallow copy and merge into a new dict,
	precedence goes to key value pairs in latter dicts.
	"""
	result = {}
	for dictionary in dict_args:
		result.update(dictionary)
	return result

def _conv_json_to_string(value):
	return dumps(value, ensure_ascii=False)

def make_dicts_value_tuple(obj):
	"""
	Given any number of dicts, shallow copy and merge into a new dict,
	precedence goes to key value pairs in latter dicts.
	"""
	obj = copy.deepcopy(obj)
	for key, val in obj.items():
		if isinstance(val, dict):
			try: val = _conv_json_to_string(val) # val = ', '.join(x for x in val if x != '')
			except: pass#logger(f'error val: {val}') # val = _conv_json_to_string(val)
		elif isinstance(val, list): val = ', '.join(x for x in val if x != '')
		obj[key] = str(val)
	return obj
