# -*- coding: utf-8 -*-
import datetime

import requests
from caches.meta_cache import cache_function
from caches.lists_cache import lists_cache_object
from modules.meta_lists import oscar_winners
from modules.settings import get_meta_filter, tmdb_api_key

from modules.settings import lists_sort_order, show_unaired_watchlist, paginate, page_limit
from modules.utils import TaskPool, paginate_list, get_datetime, jsondate_to_datetime, chunks, Thread
from modules.kodi_utils import make_session, tmdb_dict_removals, remove_keys, notification
from modules.kodi_utils import logger, sleep, progressDialogBG, confirm_dialog
from caches.settings_cache import get_setting

list_obj = {'description': '', 'name': '', 'iso_3166_1': 'US', 'iso_639_1': 'en', 'public': True}
list_url = 'https://api.themoviedb.org/4'

EXPIRY_4_HOURS, EXPIRY_1_DAY, EXPIRY_1_WEEK = 4, 24, 168
base_url = 'https://api.themoviedb.org/3'
movies_append = 'external_ids,videos,credits,release_dates,alternative_titles,translations,images,keywords'
tvshows_append = 'external_ids,videos,credits,content_ratings,alternative_titles,translations,images,keywords'
empty_setting_check = (None, 'empty_setting', '')
session = make_session(base_url)
timeout = 20.0

def no_api_key():
	notification('Please set a valid TMDb API Key')
	return []

def movie_details(tmdb_id, api_key):
	try:
		url = '%s/movie/%s?api_key=%s&language=en&append_to_response=%s&include_image_language=en' % (base_url, tmdb_id, api_key, movies_append)
		return get_tmdb(url).json()
	except: return None

def tvshow_details(tmdb_id, api_key):
	try:
		url = '%s/tv/%s?api_key=%s&language=en&append_to_response=%s&include_image_language=en' % (base_url, tmdb_id, api_key, tvshows_append)
		return get_tmdb(url).json()
	except: return None

def episode_groups_data(tmdb_id):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'episode_groups_data_%s' % tmdb_id
	url = '%s/tv/%s/episode_groups?api_key=%s' % (base_url, tmdb_id, api_key)
	return cache_function(get_tmdb, string, url)

def episode_group_details(group_id):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'episode_groups_details_%s' % group_id
	url = '%s/tv/episode_group/%s?api_key=%s' % (base_url, group_id, api_key)
	return cache_function(get_tmdb, string, url)

def movie_set_details(collection_id, api_key):
	try:
		url = '%s/collection/%s?api_key=%s&language=en' % (base_url, collection_id, api_key)
		return get_tmdb(url).json()
	except: return None

def movie_external_id(external_source, external_id, api_key):
	try:
		string = 'movie_external_id_%s_%s' % (external_source, external_id)
		url = '%s/find/%s?api_key=%s&external_source=%s' % (base_url, external_id, api_key, external_source)
		result = cache_function(get_tmdb, string, url)
		result = result['movie_results']
		if result: return result[0]
		else: return None
	except: return None

def tvshow_external_id(external_source, external_id, api_key):
	try:
		string = 'tvshow_external_id_%s_%s' % (external_source, external_id)
		url = '%s/find/%s?api_key=%s&external_source=%s' % (base_url, external_id, api_key, external_source)
		result = cache_function(get_tmdb, string, url)
		result = result['tv_results']
		if result: return result[0]
		else: return None
	except: return None

def tmdb_movies_oscar_winners(page_no):
	return oscar_winners[page_no-1]

def tmdb_network_details(network_id):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_network_details_%s' % network_id
	url = '%s/network/%s?api_key=%s' % (base_url, network_id, api_key)
	return cache_function(get_tmdb, string, url)

def tmdb_keywords_by_query(query, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_keywords_by_query_%s_%s' % (query, page_no)
	url = '%s/search/keyword?api_key=%s&query=%s&page=%s' % (base_url, api_key, query, page_no)
	return cache_function(get_tmdb, string, url)

def tmdb_movie_keywords(tmdb_id):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_movie_keywords_%s' % tmdb_id
	url = '%s/movie/%s/keywords?api_key=%s' % (base_url, tmdb_id, api_key)
	return cache_function(get_tmdb, string, url)

def tmdb_tv_keywords(tmdb_id):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_tv_keywords_%s' % tmdb_id
	url = '%s/tv/%s/keywords?api_key=%s' % (base_url, tmdb_id, api_key)
	return cache_function(get_tmdb, string, url)

def tmdb_movie_keyword_results(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_movie_keyword_results_%s_%s' % (tmdb_id, page_no)
	url = '%s/discover/movie?api_key=%s&language=en-US&with_keywords=%s&page=%s' % (base_url, api_key, tmdb_id, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_keyword_results(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_tv_keyword_results_%s_%s' % (tmdb_id, page_no)
	url = '%s/discover/tv?api_key=%s&language=en-US&with_keywords=%s&page=%s' % (base_url, api_key, tmdb_id, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movie_keyword_results_direct(query, page_no):
	if tmdb_api_key() in empty_setting_check: return no_api_key()
	try:
		results = tmdb_movie_keyword_results(tmdb_keywords_by_query(query, page_no)['results'][0]['id'], page_no)
		results['total_pages'] = 1
		return results
	except: return None

def tmdb_tv_keyword_results_direct(query, page_no):
	if tmdb_api_key() in empty_setting_check: return no_api_key()
	try:
		results = tmdb_tv_keyword_results(tmdb_keywords_by_query(query, page_no)['results'][0]['id'], page_no)
		results['total_pages'] = 1
		return results
	except: return None

def tmdb_company_id(query):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_company_id_%s' % query
	url = '%s/search/company?api_key=%s&query=%s' % (base_url, api_key, query)
	return cache_function(get_tmdb, string, url)

def tmdb_media_images(media_type, tmdb_id):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	if media_type in ('movie', 'movies'): media_type = 'movie'
	else: media_type = 'tv'
	string = 'tmdb_media_images_%s_%s' % (media_type, tmdb_id)
	url = '%s/%s/%s/images?include_image_language=en,null&api_key=%s' % (base_url, media_type, tmdb_id, api_key)
	return cache_function(get_tmdb, string, url)

def tmdb_media_videos(media_type, tmdb_id):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	if media_type in ('movie', 'movies'): media_type = 'movie'
	else: media_type = 'tv'
	string = 'tmdb_media_videos_%s_%s' % (media_type, tmdb_id)
	url = '%s/%s/%s/videos?api_key=%s' % (base_url, media_type, tmdb_id, api_key)
	return cache_function(get_tmdb, string, url)

def tmdb_movies_discover(query, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	if '[current_date]' in query: query = query.replace('[current_date]', get_current_date())
	if '[random]' in query: query = query.replace('[random]', '')
	string = url = query + '&api_key=%s&page=%s' % (api_key, page_no)
	return lists_cache_object(get_tmdb, string, url, True)

def tmdb_movies_popular(page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_movies_popular_%s' % page_no
	url = '%s/movie/popular?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (base_url, api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_popular_today(page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_movies_popular_today_%s' % page_no
	url = '%s/trending/movie/day?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (base_url, api_key, page_no)
	return lists_cache_object(get_data, string, url, expiration= EXPIRY_1_DAY)

def tmdb_movies_blockbusters(page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_movies_blockbusters_%s' % page_no
	url = '%s/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en&sort_by=revenue.desc&page=%s' % (base_url, api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_in_theaters(page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_movies_in_theaters_%s' % page_no
	url = '%s/movie/now_playing?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (base_url, api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_upcoming(page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	current_date, future_date = get_dates(31, reverse=False)
	string = 'tmdb_movies_upcoming_%s' % page_no
	url = '%s/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en&release_date.gte=%s&release_date.lte=%s&with_release_type=3|2|1&page=%s' \
							% (base_url, api_key, current_date, future_date, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_latest_releases(page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	current_date, previous_date = get_dates(31, reverse=True)
	string = 'tmdb_movies_latest_releases_%s' % page_no
	url = '%s/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en&release_date.gte=%s&release_date.lte=%s&with_release_type=4|5|6&page=%s' \
							% (base_url, api_key, previous_date, current_date, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_premieres(page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	current_date, previous_date = get_dates(31, reverse=True)
	string = 'tmdb_movies_premieres_%s' % page_no
	url = '%s/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en&release_date.gte=%s&release_date.lte=%s&with_release_type=1|3|2&page=%s' \
							% (base_url, api_key, previous_date, current_date, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_genres(genre_id, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_movies_genres_%s_%s' % (genre_id, page_no)
	url = '%s/discover/movie?api_key=%s&with_genres=%s&language=en-US&region=US&with_original_language=en&release_date.lte=%s&page=%s' \
			% (base_url, api_key, genre_id, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_languages(language, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_movies_languages_%s_%s' % (language, page_no)
	url = '%s/discover/movie?api_key=%s&language=en-US&with_original_language=%s&release_date.lte=%s&page=%s' \
			% (base_url, api_key, language, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_certifications(certification, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_movies_certifications_%s_%s' % (certification, page_no)
	url = '%s/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en&certification_country=US&certification=%s&sort_by=%s&release_date.lte=%s&page=%s' \
							% (base_url, api_key, certification, 'popularity.desc', get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_year(year, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_movies_year_%s_%s' % (year, page_no)
	url = '%s/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en&certification_country=US&primary_release_year=%s&page=%s' \
							% (base_url, api_key, year, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_decade(decade, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_movies_decade_%s_%s' % (decade, page_no)
	start = '%s-01-01' % decade
	end = get_dates(2)[0] if decade == '2020' else '%s-12-31' % str(int(decade) + 9)
	url = '%s/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en&primary_release_date.gte=%s' \
			'&primary_release_date.lte=%s&page=%s' % (base_url, api_key, start, end, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_providers(provider, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_movies_providers_%s_%s' % (provider, page_no)
	url = '%s/discover/movie?api_key=%s&watch_region=US&with_watch_providers=%s&vote_count.gte=100&page=%s' % (base_url, api_key, provider, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_recommendations(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_movies_recommendations_%s_%s' % (tmdb_id, page_no)
	url = '%s/movie/%s/recommendations?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (base_url, tmdb_id, api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_search(query, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	meta_filter = get_meta_filter()
	string = 'tmdb_movies_search_%s_%s_%s' % (query, meta_filter, page_no)
	url = '%s/search/movie?api_key=%s&language=en-US&include_adult=%s&query=%s&page=%s' % (base_url, api_key, meta_filter, query, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_companies(company_id, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_movies_companies_%s_%s' % (company_id, page_no)
	url = '%s/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en&with_companies=%s&page=%s' \
							% (base_url, api_key, company_id, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_reviews(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	url = '%s/movie/%s/reviews?api_key=%s&page=%s' % (base_url, tmdb_id, api_key, page_no)
	return get_tmdb(url).json()

def tmdb_tv_discover(query, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	if '[current_date]' in query: query = query.replace('[current_date]', get_current_date())
	if '[random]' in query: query = query.replace('[random]', '')
	string = url = query + '&api_key=%s&page=%s' % (api_key, page_no)
	return lists_cache_object(get_tmdb, string, url, True)

def tmdb_tv_popular(page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_tv_popular_%s' % page_no
	url = '%s/tv/popular?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (base_url, api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_popular_today(page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_tv_popular_today_%s' % page_no
	url = '%s/trending/tv/day?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (base_url, api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_premieres(page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	current_date, previous_date = get_dates(31, reverse=True)
	string = 'tmdb_tv_premieres_%s' % page_no
	url = '%s/discover/tv?api_key=%s&language=en-US&region=US&with_original_language=en&include_null_first_air_dates=false&first_air_date.gte=%s&first_air_date.lte=%s&page=%s' \
							% (base_url, api_key, previous_date, current_date, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_airing_today(page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_tv_airing_today_%s' % page_no
	url = '%s/tv/airing_today?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (base_url, api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_on_the_air(page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_tv_on_the_air_%s' % page_no
	url = '%s/tv/on_the_air?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (base_url, api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_upcoming(page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	current_date, future_date = get_dates(31, reverse=False)
	string = 'tmdb_tv_upcoming_%s' % page_no
	url = '%s/discover/tv?api_key=%s&language=en-US&region=US&with_original_language=en&first_air_date.gte=%s&first_air_date.lte=%s&page=%s' \
							% (base_url, api_key, current_date, future_date, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_genres(genre_id, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_tv_genres_%s_%s' % (genre_id, page_no)
	url = '%s/discover/tv?api_key=%s&with_genres=%s&language=en-US&region=US&with_original_language=en&include_null_first_air_dates=false&first_air_date.lte=%s&page=%s' \
							% (base_url, api_key, genre_id, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_languages(language, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_tv_languages_%s_%s' % (language, page_no)
	url = '%s/discover/tv?api_key=%s&language=en-US&include_null_first_air_dates=false&with_original_language=%s&first_air_date.lte=%s&page=%s' \
							% (base_url, api_key, language, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_networks(network_id, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_tv_networks_%s_%s' % (network_id, page_no)
	url = '%s/discover/tv?api_key=%s&language=en-US&region=US&with_original_language=en&include_null_first_air_dates=false&with_networks=%s&first_air_date.lte=%s&page=%s' \
							% (base_url, api_key, network_id, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_providers(provider, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_tv_providers_%s_%s' % (provider, page_no)
	url = '%s/discover/tv?api_key=%s&watch_region=US&with_watch_providers=%s&include_null_first_air_dates=false&vote_count.gte=100&first_air_date.lte=%s&page=%s' \
				% (base_url, api_key, provider, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_year(year, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_tv_year_%s_%s' % (year, page_no)
	url = '%s/discover/tv?api_key=%s&language=en-US&region=US&with_original_language=en&include_null_first_air_dates=false&first_air_date_year=%s&page=%s' \
							% (base_url, api_key, year, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_decade(decade, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_tv_decade_%s_%s' % (decade, page_no)
	start = '%s-01-01' % decade
	end = get_dates(2)[0] if decade == '2020' else '%s-12-31' % str(int(decade) + 9)
	url = '%s/discover/tv?api_key=%s&language=en-US&region=US&with_original_language=en&include_null_first_air_dates=false&first_air_date.gte=%s' \
			'&first_air_date.lte=%s&page=%s' % (base_url, api_key, start, end, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_recommendations(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_tv_recommendations_%s_%s' % (tmdb_id, page_no)
	url = '%s/tv/%s/recommendations?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (base_url, tmdb_id, api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_search(query, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	meta_filter = get_meta_filter()
	string = 'tmdb_tv_search_%s_%s_%s' % (query, meta_filter, page_no)
	url = '%s/search/tv?api_key=%s&language=en-US&include_adult=%s&query=%s&page=%s' % (base_url, api_key, meta_filter, query, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_reviews(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	url = '%s/tv/%s/reviews?api_key=%s&page=%s' % (base_url, tmdb_id, api_key, page_no)
	return get_tmdb(url).json()

def tmdb_popular_people(page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_people_popular_%s' % page_no
	url = '%s/person/popular?api_key=%s&language=en&page=%s' % (base_url, api_key, page_no)
	return cache_function(get_tmdb, string, url)

def tmdb_trending_people_day(page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_people_trending_day_%s' % page_no
	url = '%s/trending/person/day?api_key=%s&page=%s' % (base_url, api_key, page_no)
	return cache_function(get_tmdb, string, url, EXPIRY_1_DAY)

def tmdb_trending_people_week(page_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_people_trending_week_%s' % page_no
	url = '%s/trending/person/week?api_key=%s&page=%s' % (base_url, api_key, page_no)
	return cache_function(get_tmdb, string, url)

def tmdb_people_full_info(actor_id):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	string = 'tmdb_people_full_info_%s' % actor_id
	url = '%s/person/%s?api_key=%s&language=en&append_to_response=external_ids,combined_credits,images,tagged_images' % (base_url, actor_id, api_key)
	return cache_function(get_tmdb, string, url)

def tmdb_people_info(query, page_no=1):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	meta_filter = get_meta_filter()
	string = 'tmdb_people_info_%s_%s_%s' % (query, meta_filter, page_no)
	url = '%s/search/person?api_key=%s&language=en&include_adult=%s&query=%s&page=%s' % (base_url, api_key, meta_filter, query, page_no)
	return cache_function(get_tmdb, string, url)

def season_episodes_details(tmdb_id, season_no):
	api_key = tmdb_api_key()
	if api_key in empty_setting_check: return no_api_key()
	try:
		url = '%s/tv/%s/season/%s?api_key=%s&language=en&append_to_response=credits' % (base_url, tmdb_id, season_no, api_key)
		return get_tmdb(url).json()
	except: return None

def get_dates(days, reverse=True):
	current_date = get_current_date(return_str=False)
	if reverse: new_date = (current_date - datetime.timedelta(days=days)).strftime('%Y-%m-%d')
	else: new_date = (current_date + datetime.timedelta(days=days)).strftime('%Y-%m-%d')
	return str(current_date), new_date

def get_current_date(return_str=True):
	if return_str: return str(datetime.date.today())
	else: return datetime.date.today()

def get_reviews_data(media_type, tmdb_id):
	def builder(media_type, tmdb_id):
		reviews_list, all_data = [], []
		template = '[B]%02d. %s%s[/B][CR][CR]%s'
		media_type = 'movie' if media_type in ('movie', 'movies') else 'tv'
		function = tmdb_movies_reviews if media_type == 'movie' else tmdb_tv_reviews
		next_page, total_pages = 1, 1
		while next_page <= total_pages:
			data = function(tmdb_id, next_page)
			all_data += data['results']
			total_pages = data['total_pages']
			next_page = data['page'] + 1
		if all_data:
			for count, item in enumerate(all_data, 1):
				try:
					user = item['author'].upper()
					rating = item['author_details'].get('rating')
					rating = f' - {str(rating).split(".")[0]}/10' if rating else ''
					content = template % (count, user, rating, item['content'])
					reviews_list.append(content)
				except: pass
		return reviews_list
	string, url = 'tmdb_%s_reviews_%s' % (media_type ,tmdb_id), [media_type, tmdb_id]
	return cache_function(builder, string, url, json=False)

def get_data(url):
	data = get_tmdb(url).json()
	data['results'] = [remove_keys(i, tmdb_dict_removals) for i in data['results']]
	return data

def get_tmdb(url, errors=True):
	response = ''
	try:
		response = session.get(url, timeout=timeout)
		response.raise_for_status()
	except requests.exceptions.RequestException as e:
		if errors: logger(f'tmdb error: {e}')
	response.encoding = 'utf-8'
	return response


def tmdb_watchlist(media_type, page, letter):
	title, premiered = ('name', 'first_air_date') if media_type == 'tv' else ('title', 'release_date')
	original_list = all_items(watchlist, media_type)
	if not show_unaired_watchlist():
		current_date = get_datetime()
		str_format = '%Y-%m-%d'
		original_list = [i for i in original_list if i.get(premiered) and jsondate_to_datetime(i.get(premiered), str_format, remove_time=True) <= current_date]
	sort_key = lists_sort_order('watchlist')
	if sort_key == 2: original_list.sort(key=lambda k: k[premiered], reverse=True)
	elif sort_key == 1: pass # api call for list specifies params created_at.desc
	# else: original_list = sort_for_article(original_list, title, ignore_articles())
	if paginate():
		limit = page_limit()
		final_list, total_pages = paginate_list(original_list, page, letter, limit)
	else: final_list, total_pages = original_list, 1
	return final_list, total_pages

def tmdb_favorite(media_type, page, letter):
	original_list = all_items(favorite, media_type)
	if paginate():
		limit = page_limit()
		final_list, total_pages = paginate_list(original_list, page, letter, limit)
	else: final_list, total_pages = original_list, 1
	return final_list, total_pages

def tmdb_recommendations(media_type, page, dummy):
	original_list = recommendations(media_type, page)
	final_list, total_pages = original_list['results'], original_list['total_pages']
	return final_list, total_pages

def add_to_watchlist_favorite(item, list_type):
	session_account_id = get_setting('tmdb.session_account_id')
	session_id = get_setting('tmdb.session_id')
	# if not (session_account_id and session_id):
	# 	try: session_account_id, session_id = convert_to_session_id()
	# 	except: pass
	if not (session_account_id and session_id): return {'success': False}
	params = {'session_id': session_id}
	url = '%s/account/%s/%s' % (base_url, session_account_id, list_type)
	return list_request(url, params=params, data=item, method='post')

def _account_id(func):
	def wrapper(*args, **kwargs):
		kwargs['account_id'] = kwargs.get('account_id') or get_setting('tmdb.account_id')
		result = func(*args, **kwargs)
		return result
	return wrapper

def all_items(func, *args):
	def _process(f, *a):
		r = f(*a)
		results[a[-1]] = r['results']
		return r['total_pages']
	results, page, total_pages = {}, 1, 1
	total_pages = _process(func, *args, page)
	threads = TaskPool(40).tasks(_process, [(func, *args, i) for i in range(page + 1, total_pages + 1)], Thread)
	[i.join() for i in threads]
	results = [item for items in sorted(results.items()) for item in items[1]]
	return results

def user_lists_all():
	sort = int(get_setting('tmdblist.sort_name', '0'))
	results = all_items(user_lists)
	try:
		if sort == 2: results.sort(key=lambda k: k['updated_at'], reverse=True)
		elif sort == 1: results.sort(key=lambda k: k['number_of_items'], reverse=True)
		else: results.sort(key=lambda k: k['name'].lower(), reverse=False)
	except: pass
	return results


def list_request(url, params=None, data=None, method=None):
	access_token = get_setting('tmdb.token')
	headers = {'Authorization': f"Bearer {access_token}"}
	try:
		response = session.request(method or 'get', url, params=params, json=data, headers=headers, timeout=timeout ** 2 if not method in ('get', None) else timeout)
		if not response.ok: response.raise_for_status()
		return response.json()
	except requests.exceptions.RequestException as e:
		logger(f'tmdb error: {e}')
	return

def list_details(list_id, page=1):
	string = 'tmdblist_detail_%s_%s' % (list_id, page)
	url = '%s/list/%s?page=%s' % (list_url, list_id, page)
	return lists_cache_object(list_request, string, url)

def list_add_items(list_id, items=None):
	url = '%s/list/%s/items' % (list_url, list_id)
	return list_request(url, data=items, method='post')

def list_remove_items(list_id, items=None):
	url = '%s/list/%s/items' % (list_url, list_id)
	return list_request(url, data=items, method='delete')

def list_update(list_id, data):
	url = '%s/list/%s' % (list_url, list_id)
	return list_request(url, data=data, method='put')

def list_status(list_id, media_type, media_id):
	params = {'media_type': media_type, 'media_id': int(media_id)}
	url = '%s/list/%s/item_status' % (list_url, list_id)
	return list_request(url, params=params)

def list_create(item):
	url = '%s/list' % list_url
	return list_request(url, data=item, method='post')

def list_clear(list_id):
	url = '%s/list/%s/clear' % (list_url, list_id)
	return list_request(url)

def list_delete(list_id):
	url = '%s/list/%s' % (list_url, list_id)
	return list_request(url, method='delete')

@_account_id
def user_lists(page=1, account_id=''):
	string = 'tmdblist_user_lists_%s' % page
	url = '%s/account/%s/lists?page=%s' % (list_url, account_id, page)
	return lists_cache_object(list_request, string, url)

@_account_id
def watchlist(media_type, page=1, account_id=''):
	string = 'tmdblist_watchlist_%s_%s_%s' % (account_id, media_type, page)
	url = '%s/account/%s/%s/watchlist' % (list_url, account_id, media_type)
	url += '?page=%slanguage=en-US&sort_by=created_at.desc' % page
	return lists_cache_object(list_request, string, url)

@_account_id
def favorite(media_type, page=1, account_id=''):
	string = 'tmdblist_favorite_%s_%s_%s' % (account_id, media_type, page)
	url = '%s/account/%s/%s/favorites' % (list_url, account_id, media_type)
	url += '?page=%slanguage=en-US&sort_by=created_at.desc' % page
	return lists_cache_object(list_request, string, url)

@_account_id
def recommendations(media_type, page=1, account_id=''):
	string = 'tmdblist_recommendations_%s_%s_%s' % (account_id, media_type, page)
	url = '%s/account/%s/%s/recommendations' % (list_url, account_id, media_type)
	url += '?page=%slanguage=en-US' % page
	return lists_cache_object(list_request, string, url)

def tmdb_clean_watchlist(silent=False):
	if not get_setting('tmdb.token'): return
	# if not silent and not confirm_dialog(): return
	try:
		from caches.watched_cache import get_watched_items, get_in_progress_tvshows
		watchlist_ids = []
		watchlist_ids += all_items(watchlist, 'movie')
		watchlist_ids += all_items(watchlist, 'tv')
		watchlist_ids = [str(i['id']) for i in watchlist_ids]
		m = get_watched_items('movie', 1, 'None', False)
		t = get_watched_items('tvshow', 1, 'None', False)
		p = get_in_progress_tvshows('tvshow', 1, 'None', False)
		items = []
		items += [
			{'watchlist': False, 'media_type': 'movie', 'media_id': i['media_id']}
			for i in m[0] if i['media_id'] in watchlist_ids
		]
		items += [
			{'watchlist': False, 'media_type': 'tv', 'media_id': i['media_id']}
			for i in t[0] + p[0] if i['media_id'] in watchlist_ids
		]
		if not items: return '0 items to remove.'
		threads = TaskPool(40).tasks(add_to_watchlist_favorite, [(i, 'watchlist') for i in items], Thread)
		[i.join() for i in threads]
		# clear_tmdbl_cache()
		if not silent: notification('Success')
		return '%d items removed.' % len(items)
	except: pass

def import_trakt_watchlist(dummy):
	if not confirm_dialog(): return
	def _process(group, count):
		add_to_watchlist_favorite(group, 'watchlist')
		progressBG.update(int(count / len_items * 100), send_str)
	from apis.trakt_api import trakt_fetch_collection_watchlist
	send_str = 'Sending items to TMDB Watchlist...'
	try:
		progressBG = progressDialogBG
		progressBG.create(send_str, 'TMDB Lists')
		items = []
		for i in (('movie', 'movie'), ('show', 'tv')):
			try: items += [
					{'collected_at': item['collected_at'], 'watchlist': True, 'media_type': i[1], 'media_id': item['media_ids']['tmdb']}
					for item in trakt_fetch_collection_watchlist('watchlist', i[0]) if 'tmdb' in item['media_ids']
				]
			except: pass
		if not items: return notification('No Results')
		try: items.sort(key=lambda k: k['collected_at'], reverse=False)
		except: pass
		len_items = len(items)
		threads = TaskPool(40).tasks(_process, [(i[1], i[0]) for i in enumerate(items, 1)], Thread)
		[i.join(3/4) for i in threads]
		# clear_tmdbl_cache()
		notification('List sent to TMDB')
	except: notification('Error')
	finally: progressBG.close()

def import_trakt_list(params):
	from apis.trakt_api import get_trakt_list_contents
	send_str = 'Sending items to TMDB Watchlist...'
	try:
		progressBG = progressDialogBG
		progressBG.create(send_str, 'TMDB Lists')
		list_id, user, slug = params['trakt_list_id'], params['user'], params['list_slug']
		items = get_trakt_list_contents(list_id, user, slug)
		len_items, wait = len(items), sum(1000 for i in chunks(items, 500))
		for count, item in enumerate(items, 1):
			sleep(int(wait / len_items))
			if (mtype := item['type']) in ('movie', 'show') and 'tmdb' in item[mtype]['ids']:
				if not item[mtype]['ids']['tmdb']: continue
				item['export'] = {'media_type': 'tv' if mtype == 'show' else mtype, 'media_id': item[mtype]['ids']['tmdb']}
			else: item['export'] = None
			progressBG.update(int(count / len_items * 100), send_str)
		items = {'items': [i['export'] for i in items if i['export']]}
		Thread(target=list_add_items, args=(params['list_id'], items)).start()
		# clear_tmdbl_cache()
		notification('List sent to TMDB')
	except: notification('Error')
	finally: progressBG.close()

def import_mdbl_list(params):
	from apis.mdblist_api import mdb_list_items
	send_str = 'Sending list to TMDB...'
	try:
		progressBG = progressDialogBG
		progressBG.create(send_str, 'TMDB Lists')
		items = mdb_list_items(params['mdbl_list_id'], None)
		len_items, wait = len(items), sum(1000 for i in chunks(items, 500))
		for count, item in enumerate(items, 1):
			sleep(int(wait / len_items))
			if (mtype := item['mediatype']) in ('movie', 'show') and item['id']:
				item['export'] = {'media_type': 'tv' if mtype == 'show' else mtype, 'media_id': item['id']}
			else: item['export'] = None
			progressBG.update(int(count / len_items * 100), send_str)
		items = {'items': [i['export'] for i in items if i['export']]}
		Thread(target=list_add_items, args=(params['list_id'], items)).start()
		# clear_tmdbl_cache()
		notification('List sent to TMDB')
	except: notification('Error')
	finally: progressBG.close()

