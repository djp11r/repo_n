# -*- coding: utf-8 -*-
import xbmc, xbmcgui
import json
from threading import Thread

pause_services_prop = 'infinite.pause_services'
firstrun_update_prop = 'infinite.firstrun_update'
current_skin_prop = 'infinite.current_skin'
trakt_service_string = 'TraktMonitor Service Update %s - %s'
trakt_success_line_dict = {'success': 'Trakt Update Performed', 'no account': '(Unauthorized) Trakt Update Performed'}
update_string = 'Next Update in %s minutes...'

def logger(function):
	xbmc.log(f'###Infinite###: {function}', 1)

class SetAddonConstants:
	def run(self):
		# logger('SetAddonConstants Service Starting')
		import xbmcgui, xbmcaddon
		from xbmcvfs import translatePath
		addon_object = xbmcaddon.Addon('plugin.video.infinite')
		self.window = xbmcgui.Window(10000)
		_info = addon_object.getAddonInfo
		addon_items = [('infinite.addon_version', _info('version')),
					('infinite.addon_path', _info('path')),
					('infinite.addon_profile', translatePath(_info('profile'))),
					('infinite.addon_icon', translatePath(_info('icon'))),
					('infinite.addon_fanart', translatePath(_info('fanart')))]
		for item in addon_items: self.set_property(*item)
		return logger('SetAddonConstants Service Finished')

	def set_property(self, prop, value):
		self.window.setProperty(prop, value)

class DatabaseMaintenance:
	def run(self):
		# logger('DatabaseMaintenance Service Starting')
		from caches.base_cache import make_databases, check_cache_location
		check_cache_location()
		make_databases()
		return logger('DatabaseMaintenance Service Finished')

class SyncSettings:
	def run(self):
		# logger('SyncSettings Service Starting')
		from caches.settings_cache import sync_settings
		sync_settings()
		logger('SyncSettings Service Finished')

class CustomFonts:
	def run(self):
		# logger('CustomFonts Service Starting')
		from windows.base_window import FontUtils
		monitor, player, window = xbmc.Monitor(), xbmc.Player(), xbmcgui.Window(10000)
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		window.clearProperty(current_skin_prop)
		font_utils = FontUtils()
		while not monitor.abortRequested():
			font_utils.execute_custom_fonts()
			if window.getProperty(pause_services_prop) == 'true' or is_playing(): sleep = 20
			else: sleep = 10
			wait_for_abort(sleep)
		try: del monitor
		except: pass
		try: del player
		except: pass
		return logger('CustomFonts Service Finished')

class TraktMonitor:
	def run(self):
		logger('TraktMonitor Service Starting')
		from apis.trakt_api import trakt_sync_activities
		from caches.settings_cache import get_setting
		from modules.kodi_utils import run_plugin
		from modules.settings import trakt_sync_interval
		monitor, player, window = xbmc.Monitor(), xbmc.Player(), xbmcgui.Window(10000)
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		while not monitor.abortRequested():
			while is_playing() or window.getProperty(pause_services_prop) == 'true': wait_for_abort(10)
			wait_time = 1800
			try:
				sync_interval, wait_time = trakt_sync_interval()
				next_update_string = update_string % sync_interval
				status = trakt_sync_activities()
				if status == 'failed': logger(trakt_service_string % ('Failed. Error from Trakt', next_update_string))
				else:
					if status in ('success', 'no account'): logger(trakt_service_string % ('Success. %s' % trakt_success_line_dict[status], next_update_string))
					else: logger(trakt_service_string % ('Success. No Changes Needed', next_update_string))# 'not needed'
					if status == 'success' and get_setting('infinite.trakt.refresh_widgets', 'false') == 'true': run_plugin({'mode': 'kodi_refresh'})
			except Exception as e: logger(trakt_service_string % ('Failed', f'The following Error Occured: {str(e)}'))
			wait_for_abort(wait_time)
		try: del monitor
		except: pass
		try: del player
		except: pass
		return logger('TraktMonitor Service Finished')

class UpdateCheck:
	def run(self):
		window = xbmcgui.Window(10000)
		if window.getProperty(firstrun_update_prop) == 'true': return
		logger('UpdateCheck Service Starting')
		from time import time
		from modules.updater import update_check
		from modules.settings import update_action, update_delay
		end_pause = time() + update_delay()
		monitor, player = xbmc.Monitor(), xbmc.Player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		while not monitor.abortRequested():
			while time() < end_pause: wait_for_abort(1)
			while window.getProperty(pause_services_prop) == 'true' or is_playing(): wait_for_abort(1)
			# update_check(update_action())
			Maintenance().run()
			break
		window.setProperty(firstrun_update_prop, 'true')
		try: del monitor
		except: pass
		try: del player
		except: pass
		return logger('UpdateCheck Service Finished')

class WidgetRefresher:
	def run(self):
		logger('WidgetRefresher Service Starting')
		from time import time
		from caches.settings_cache import get_setting
		from modules.kodi_utils import home, run_plugin
		monitor, player = xbmc.Monitor(), xbmc.Player()
		wait_for_abort, self.is_playing = monitor.waitForAbort, player.isPlayingVideo
		self.window = xbmcgui.Window(10000)
		self.get_setting = get_setting
		self.home = home
		self.window.setProperty('infinite.refresh_widgets', 'true')
		self.set_next_refresh(time())
		wait_for_abort(20)
		while not monitor.abortRequested():
			try:
				wait_for_abort(10)
				self.window.clearProperty('infinite.refresh_widgets')
				offset = int(self.get_setting('infinite.widget_refresh_timer', '60'))
				if offset != self.offset:
					self.set_next_refresh(time())
					continue
				if self.condition_check(): continue
				if self.next_refresh < time():
					run_plugin({'mode': 'refresh_widgets', 'show_notification': self.get_setting('infinite.widget_refresh_notification', 'false')}, block=True)
					logger('WidgetRefresher Service - Widgets Refreshed')
					self.set_next_refresh(time())
			except: pass
		try: del monitor
		except: pass
		try: del player
		except: pass
		return logger('WidgetRefresher Service Finished')

	def condition_check(self):
		if not self.home(): return True
		if self.next_refresh == None or self.is_playing() or self.window.getProperty(pause_services_prop) == 'true': return True
		if self.window.getProperty('infinite.window_loaded') == 'true': return True 
		try:
			window_stack = json.loads(self.window.getProperty('infinite.window_stack'))
			if window_stack or window_stack == []: return True
		except: pass
		return False

	def set_next_refresh(self, _time):
		self.offset = int(self.get_setting('infinite.widget_refresh_timer', '60'))
		if self.offset: self.next_refresh = _time + (self.offset*60)
		else: self.next_refresh = None


class Maintenance:
	def run(self):
		from caches.settings_cache import get_setting, set_setting
		from caches.base_cache import get_timestamp
		current_time = get_timestamp()
		due_clean = int(get_setting('infinite.database.maintenance.due', '0'))
		do_cleaning = current_time >= due_clean
		from modules.kodi_utils import sync_accounts
		sync_accounts()
		if do_cleaning:
			from caches.base_cache import clean_databases
			clean_databases()
			next_clean = str(int(get_timestamp(72))) # 72 for 3 days
			logger(f'Maintenance Service Run: {do_cleaning} current_time: {current_time} due_clean: {due_clean}')
			return set_setting('database.maintenance.due', next_clean)
		else: return logger(f'Maintenance Service Run: {do_cleaning}')


class AutoStart:
	def run(self):
		# logger('AutoStart Service Starting')
		from modules.settings import auto_start_infinite
		if auto_start_infinite():
			from modules.kodi_utils import run_addon
			run_addon()
		return logger('AutoStart Service Finished')

class ReuseLanguageInvokerCheck:
	def run(self):
		logger('ReuseLanguageInvokerCheck Service Starting')
		from caches.settings_cache import get_setting
		current_addon_setting = get_setting('infinite.reuse_language_invoker', None)
		if current_addon_setting is None: return logger('ReuseLanguageInvokerCheck Service Error. No current setting detected. Finished')
		import xbmcvfs
		from xml.dom.minidom import parse as mdParse
		addon_xml = xbmcvfs.translatePath('special://home/addons/plugin.video.infinite/addon.xml')
		root = mdParse(addon_xml)
		invoker_instance = root.getElementsByTagName('reuselanguageinvoker')[0].firstChild
		current_invoker_status = invoker_instance.data
		if current_invoker_status != current_addon_setting:
			from modules.kodi_utils import update_local_addons, disable_enable_addon, notification
			notification('Language Invoker Mismatch. Restarting Addons')
			invoker_instance.data = current_addon_setting
			new_xml = str(root.toxml()).replace('<?xml version="1.0" ?>', '')
			with open(addon_xml, 'w') as f: f.write(new_xml)
			xbmc.executebuiltin('ActivateWindow(Home)', True)
			update_local_addons()
			disable_enable_addon()
		return logger('ReuseLanguageInvokerCheck Service Finished')

class infiniteMonitor(xbmc.Monitor):
	def __init__(self):
		xbmc.Monitor.__init__(self)
		super().__init__()
		self.startServices()

	def startServices(self):
		SetAddonConstants().run()
		DatabaseMaintenance().run()
		SyncSettings().run()
		ReuseLanguageInvokerCheck().run()
		# Thread(target=CustomFonts().run).start()
		Thread(target=TraktMonitor().run).start()
		Thread(target=UpdateCheck().run).start()
		Thread(target=WidgetRefresher().run).start()
		AutoStart().run()
		xbmcgui.Dialog().notification('Infinite', 'runing', time=2000, sound=False)

	def onNotification(self, sender, method, data):
		if method in ('GUI.OnScreensaverActivated', 'System.OnSleep'):
			xbmcgui.Window(10000).setProperty(pause_services_prop, 'true')
			# logger('OnNotificationActions PAUSING infinite Services Due to Device Sleep')
		elif method in ('GUI.OnScreensaverDeactivated', 'System.OnWake'):
			xbmcgui.Window(10000).clearProperty(pause_services_prop)
			# logger('OnNotificationActions UNPAUSING infinite Services Due to Device Awake')


infiniteMonitor().waitForAbort()
logger('Main Monitor Service Finished')
