import json
import sys
from queue import SimpleQueue
from threading import Thread
from traceback import print_exc
from apis import tmdb_api
from indexers.movies import Movies
from indexers.tvshows import TVShows
from modules.settings import page_limit, paginate

from modules.kodi_utils import make_session, tmdb_dict_removals, remove_keys, notification
from modules.kodi_utils import logger, sleep, progressDialogBG, confirm_dialog
from modules.kodi_utils import build_url, make_listitem, add_dir, get_icon, translate_path, nextpage_landscape, add_items, end_directory, set_category, set_sort_method, set_content, set_view_mode, home, external, select_dialog, kodi_dialog, kodi_refresh
from modules.utils import TaskPool, paginate_list
from caches.settings_cache import get_setting

default_icon = get_icon('tmdb')
default_fanart = translate_path('special://home/addons/plugin.video.infinite/fanart.png')
tmdb_image_base = 'https://image.tmdb.org/t/p/%s%s'

def get_tmdb_lists(params):
	def _process():
		for item in lists:
			try:
				cm = []
				cm_append = cm.append
				poster_path, fanart_path = item['poster_path'], item['backdrop_path']
				poster = tmdb_image_base % ('w780', poster_path) if poster_path else default_icon
				fanart = tmdb_image_base % ('w780', fanart_path) if fanart_path else default_fanart
				name, user = item['name'], item['account_object_id']
				item_count, list_id = item['number_of_items'], item['id']
				display = '%s (x%s)' % (name, item_count) if item_count else name
				if not item['public']: display = '[COLOR cyan][I]%s[/I][/COLOR]' % display
				#plot = '[B]Updated[/B]: %s[CR]%s' % (item['updated_at'][:10], item['description'])
				edit_params = {'list_id': list_id, 'name': name, 'poster': poster_path, 'fanart': fanart_path, 'public': item['public']}
				url = build_url({'mode': 'build_tmdb_list', 'user': user, 'list_id': list_id, 'name': name})
				cm_append(('Add to a Menu', 'RunPlugin(%s)' % build_url({'mode': 'menu_editor.add', 'name': display, 'iconImage': 'tmdb'})))
				cm_append(('Add to a Shortcut Folder', 'RunPlugin(%s)' % build_url({'mode': 'menu_editor.shortcut_folder_add_item', 'name': display, 'iconImage': 'tmdb'})))
				cm_append(('Edit tmdb list', 'RunPlugin(%s)' % build_url({'mode': 'tmdb.edit_tmdb_list', **edit_params})))
				cm_append(('Clear List Cache', 'RunPlugin(%s)' % build_url({'mode': 'tmdb.update_tmdb_list'})))
				listitem = make_listitem()
				listitem.setLabel(display)
				listitem.setArt({'icon': poster, 'poster': poster, 'thumb': poster, 'fanart': fanart, 'banner': poster})
				#				listitem.setInfo('video', {'plot': plot}) if KODI_VERSION < 20 else listitem.getVideoInfoTag().setPlot(plot)
				listitem.addContextMenuItems(cm, replaceItems=False)
				yield url, listitem, True
			except: logger(f'get_tmdb_lists Error: {print_exc()}')

	lists = tmdb_api.user_lists_all()
	__handle__ = int(sys.argv[1])
	add_items(__handle__, list(_process()))
	set_category(__handle__, params.get('name'))
	set_sort_method(__handle__, 'label')
	set_content(__handle__, 'files')
	end_directory(__handle__)
	set_view_mode('view.main')

def build_tmdb_list(params):
	def _thread_target(q):
		while not q.empty():
			try: target, *args = q.get(); target(*args)
			except: pass

	__handle__, _queue, is_widget = int(sys.argv[1]), SimpleQueue(), external()
	max_threads = int(get_setting('infinite.max_threads', '75'))
	user, name, list_id = params.get('user'), params.get('name'), params.get('list_id')
	letter, page = params.get('new_letter', 20), int(params.get('new_page', 1))
	results, is_home = {}, home()
	results = tmdb_api.all_items(tmdb_api.list_details, list_id)
	# logger(f'params: {params}\n paginate(): {paginate(is_home)}\n results: {repr(results)}')
	if paginate(is_home) and results: process_list, total_pages, all_pages = paginate_list(results, page, int(letter))
	else: process_list, total_pages, all_pages = results, 1, ''
	movies, tvshows = Movies({'id_type': 'tmdb_id', 'fromtmbd': 'true'}), TVShows({'id_type': 'tmdb_id', 'fromtmbd': 'true'})
	# logger(f'process_list: {repr(process_list)}\nall_pages   : {repr(all_pages)}')
	for idx, tag in enumerate(process_list, 1):
		mtype = tag['media_type']
		if mtype == 'movie':
			_queue.put((movies.build_movie_content, idx, tag['id']))
		elif mtype == 'tv':
			_queue.put((tvshows.build_tvshow_content, idx, tag['id']))
	max_threads = min(_queue.qsize(), max_threads)
	threads = (Thread(target=_thread_target, args=(_queue,)) for i in range(max_threads))
	threads = list(TaskPool.process(threads))
	[i.join() for i in threads]
	# logger(f'movies.items: {repr(movies.items)}\ntvshows.items: {repr(tvshows.items)}')
	items = movies.items + tvshows.items
	# items.sort(key=lambda k: int(k[1].getProperty('infinite_sort_order')))
	content, total = max(('movies', movies), ('tvshows', tvshows), key=lambda k: len(k[1].items))
	add_items(__handle__, items)
	url = {'mode': 'build_tmdb_list', 'user': user, 'name': name, 'list_id': list_id, 'new_page': page + 1, 'new_letter': letter}
	if total_pages > page:
		add_dir(url, 'Next Page', __handle__, 'nextpage')
	if total_pages > 2 and not is_widget:
		new_page = dict({'category_name': 'TV Shows Watchlist', 'paginate_start': '0'}, **url)
		url = {'mode': 'navigate_to_page_choice', 'current_page': page, 'total_pages': total_pages, 'all_pages': all_pages, 'paginate_start': letter, 'url_params': json.dumps(new_page),}
		add_dir(url, 'Jump To...', __handle__, 'item_jump', isFolder=False)
	set_category(__handle__, name)
	set_content(__handle__, content)
	end_directory(__handle__, not is_widget)
	set_view_mode('view.%s' % content, content)

def update_tmdb_list():
	#tmdb_api.clear_tmdbl_cache()
	kodi_refresh()

def edit_tmdb_list(params):
	# image_resolution = get_resolution()
	heading = 'TMDB Lists'
	icon = get_icon('tmdb')# translate_path('special://home/addons/plugin.video.pov/resources/media/tmdb.png')
	choices = [
		('name', params['name']),
		('poster', params['poster']),
		('fanart', params['fanart']),
		('public', 'true' if params['public'] in ('true', '1') else 'false'),
		('save', 'Save and Exit'),
		('cancel', 'Cancel')
	]
	list_items = [
		{'line1': i[1], 'line2': i[0], 'icon':
		tmdb_image_base % ('w780', i[1])
		if i[0] in ('poster', 'fanart') and not i[1] in ('clear', 'None') else icon}
		for i in choices
	]
	kwargs = {'items': json.dumps(list_items), 'heading': heading, 'multi_line': 'true'}
	choice = select_dialog([i[0] for i in choices], **kwargs)
	if choice in ('cancel', None): return
	if 'name' in choice:
		name = kodi_dialog.input('New List Name', defaultt=params['name'])
		params['name'] = name.strip() or params['name']
	elif choice in ('poster', 'fanart'):
		art = artwork_choice_tmdb_list(params['list_id'], choice, params['name'], icon)
		params[choice] = params[choice] if art is None else art
	elif 'public' in choice:
		text = 'Make %s Private?' % params['name']
		params['public'] = 'true' if not confirm_dialog(text=text, top_space=True) else 'false'
	else:
		data = {
			'name': params['name'],
			'poster_path': '' if params['poster'] == 'clear' else params['poster'],
			'backdrop_path': '' if params['fanart'] == 'clear' else params['fanart'],
			'public': 'true' if params.get('public') in ('true', '1') else 'false',
		}
		data = {k: v for k, v in data.items() if not v in ('None', None)}
		if tmdb_api.list_update(params['list_id'], data)['success']:
			update_tmdb_list()
			kodi_refresh()
			return notification('Success')
		else: return notification('Error')
	return edit_tmdb_list(params)

def artwork_choice_tmdb_list(list_id, key, list_title, default_icon):
	path = 'poster_path' if key == 'poster' else 'backdrop_path'
	choices = [
		(item[path], item['title'] if item['media_type'] == 'movie' else item['name'],
		tmdb_image_base % ('w780', item[path]) if item[path] else default_icon)
		for item in tmdb_api.all_items(tmdb_api.list_details, list_id)
	]
	choices += [('clear', 'Clear', default_icon)]
	list_items = [{'line1': item[1], 'line2': item[0], 'icon': item[2]} for item in choices]
	kwargs = {'items': json.dumps(list_items), 'heading': list_title, 'enumerate': 'true', 'multi_line': 'true'}
	return select_dialog([i[0] for i in choices], **kwargs)

