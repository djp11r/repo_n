# -*- coding: utf-8 -*-

import json
import re
from traceback import print_exc, print_stack
from urllib.parse import urlencode, urljoin

from modules.kodi_utils import logger, build_url, nextpage, set_info, make_listitem, add_items, set_content, end_directory, set_view_mode, get_infolabel, notification, external, set_category, opensettings_params
from caches.main_cache import main_cache
from caches.meta_cache import meta_cache
from modules.watched_status import get_database, get_progress_status_movie, get_watched_status_movie, get_watched_status_episode, get_progress_status_episode, get_media_info
from caches.settings_cache import get_setting
from modules.source_utils import fetch_meta, gettmdb_id, request, get_int_epi, keepclean_title, get_episode_date, find_season_in_title, string_date_to_num, additional_title_cleaner
from modules.dom_parser import parseDOM

thumb = 'https://i.imgur.com/p18A3dF.png'
fanart = 'https://i.imgur.com/p18A3dF.png'  # 'https://i.imgur.com/aYEzi5o.jpg'
old_hindi_shows = get_setting('infinite.old.hindi_shows', 'false') == 'true'
dr_url = 'https://desirulez.net'
run_plugin = 'RunPlugin(%s)'


def movies(params):
    # logger(f'from : movies params: {params}')
    def _process():
        for item in movies_data:
            # logger(f'{__name__} _process item: {item}')
            try:
                listitem = make_listitem()
                set_properties = listitem.setProperties
                cm = []
                cm_append = cm.append
                title, year, meta = item['title'], item.get('year'), item['meta']
                meta_get = meta.get
                poster, tmdb_id = meta_get('poster'), str(meta_get('tvdb_id') or item.get('tmdb_id'))
                imdb_id = str(meta_get('imdb_id') or tmdb_id)
                playcount = get_watched_status_movie(watched_info, tmdb_id)
                progress = get_progress_status_movie(bookmarks, tmdb_id)
                # logger(f'from : _process tmdb_id: {tmdb_id} playcount: {playcount} progress: {progress}')
                meta.update({'mediatype': 'movie', 'premiered': str(year), 'original_title': title, 'playcount': playcount, 'url': item['url'], 'fanart': poster})
                meta_json = json.dumps(meta)
                setUniqueIDs = {'imdb': imdb_id, 'tmdb': tmdb_id}
                listitem.setLabel(title.title())
                if 'Next Page:' in title:
                    url = build_url({'mode': 'vod_movies_list', 'list_name': params['list_name'], 'url': item['url'], 'pg_no': item['pg_no'], 'rescrape': 'false', 'iconImage': params['iconImage']})
                    listitem.setArt({'icon': nextpage, 'fanart': fanart})
                    set_properties({'SpecialSort': 'bottom'})
                    listitem = set_info(listitem, meta, setUniqueIDs)
                    isfolder = True
                else:
                    data = {'mode': 'playback.media', 'media_type': 'movie', 'title': title, 'tmdb_id': tmdb_id, 'year': year, 'hindi_': 'true'}
                    url = build_url(data)
                    data['mode'] = 'scrape_select'
                    cm_append(('Select Source', run_plugin % build_url(data)))
                    data['mode'] = 'rescrape_select'
                    cm_append(('Rescrape & Select Source', run_plugin % build_url(data)))
                    if progress:
                        cm_append(('[B]Clear Progress[/B]', run_plugin % build_url({'mode': 'watched_status.erase_bookmark', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'refresh': 'true', 'watched_indicators': '0'})))
                        set_properties({'WatchedProgress': progress})
                    if playcount: cm_append(('[B]Mark Unwatched Infinite[/B]', run_plugin % build_url({'mode': 'watched_status.mark_movie', 'action': 'mark_as_unwatched', 'tmdb_id': tmdb_id, 'title': title, 'year': year})))
                    else: cm_append(('[B]Mark Watched Infinite[/B]', run_plugin % build_url({'mode': 'watched_status.mark_movie', 'action': 'mark_as_watched', 'tmdb_id': tmdb_id, 'title': title, 'year': year})))
                    extras_params = {'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'movie', 'meta': meta_json, 'is_external': is_external}
                    cm_append(('[B]Extras[/B]', run_plugin % build_url(extras_params)))
                    cm_append(('Open Settings', run_plugin % build_url(opensettings_params)))
                    listitem.addContextMenuItems(cm)
                    listitem.setArt({'poster': poster, 'icon': poster, 'thumb': poster, 'clearart': poster, 'fanart': fanart})
                    listitem = set_info(listitem, meta, setUniqueIDs, progress)
                    set_properties({'infinite.extras_params': json.dumps(extras_params), 'IsPlayable': 'false'})
                    isfolder = False
                yield url, listitem, isfolder
            except: logger(f'from: {__name__} item: {item}\n Error: {print_stack(limit=15)}')

    cache_name = f'movies_{urlencode(params)}'
    movies_data = main_cache.get(cache_name)
    if not movies_data:
        movies_data = get_movies(params)
        if movies_data:
            main_cache.set(cache_name, movies_data, expiration=336)  # 14 days cache
    from sys import argv  # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    if movies_data:
        watched_info, bookmarks = get_media_info(0, 'movie')
        # logger(f'from movies len(bookmarks): {len(bookmarks)} bookmarks: {bookmarks}\nlen(watched_info): {len(watched_info)} watched_info: {watched_info}')
        is_external = external()
        add_items(handle, list(_process()))
        set_content(handle, 'movies')
        set_category(handle, 'movies')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.movies', 'movies', is_external)
    else:
        notification(f'No movies Found for: :{params["list_name"]} Retry')
        end_directory(handle)
        return


def get_movies(params):
    non_str_list = ['+', 'season', 'episode']
    movies = results = next_p = []
    _links = eval(get_setting('infinite.h_urls'))
    _link = _links.get('desicinemas')
    url = params['url'] % _link
    if movies_page := request(url):
        # logger(f'movies_page: {movies_page}')
        # results = parseDOM(movies_page, 'div', attrs={'class': 'Main Container'})
        results = parseDOM(movies_page, 'li', attrs={'class': 'TPostMv post-.+?'})
        next_p = parseDOM(movies_page, 'div', attrs={'class': 'nav-links'})
    else:
        movies_page = request(params['url'])
        results = parseDOM(movies_page, 'h3', attrs={'class': 'threadtitle'})
        next_p = parseDOM(movies_page, 'span', attrs={'class': 'prev_next'})
    # logger(f'total movies: {len(results)} results: {results}')
    # r = [(parseDOM(i, 'a', ret='href'), parseDOM(i, 'a', ret='title'), parseDOM(i, 'a')[0]) for i in results]
    for i in results:
        try:
            url = parseDOM(i, 'a', ret='href') or parseDOM(i, 'a', attrs={'class': 'title'}, ret='href')
            if isinstance(url, list) and len(url) > 0: url = str(url[0])
            url = url if url.startswith(dr_url) else urljoin(dr_url, url)
            try:
                title = parseDOM(i, 'h2', attrs={'class': 'Title'})[0]
                year = parseDOM(i, 'span', attrs={'class': 'Qlty Yr'})[0] or parseDOM(i, 'span', attrs={'class': 'Date'})[0]
            except:
                try: title = parseDOM(i, 'a', attrs={'class': 'title threadtitle_unread'})[0]
                except:
                    title = parseDOM(i, 'a', attrs={'class': 'title'})
                    title = title[0] if title else parseDOM(i, 'a')[0]
                # logger(f'title: {title} type(title): {type(title)}')
                try: parsed = re.compile(r'(.+) [{(](\d+|\w+ \d+|\w+)[})]').findall(str(title))[0]
                except: parsed = '', ''
                # logger(f'type title: {type(parsed[0])} parsed[0]: {parsed[0]} parsed[1] {parsed[1]}')
                title = parsed[0]
                year = parsed[1]
                if not re.search(r'\d{4}', year):
                    try: year = re.search(r'\d{4}', title).group()
                    except: year = None
            if '(Punjabi)' in title or '(Marathi)' in title or all(x in title for x in non_str_list): continue
            title = keepclean_title(title)
            tmdb_id = gettmdb_id('movie', title, year)
            try:
                imgurl = parseDOM(i, 'img', ret='data-src')[0]
                Descri = parseDOM(i, 'div', attrs={'class': 'Description'})[0]
                plot = parseDOM(Descri, 'p')[0]
            except: imgurl, Descri, plot = '', '', ''
            genre = parseDOM(Descri, 'p', attrs={'class': 'Genre'})
            genre = parseDOM(genre, 'a')
            cast = parseDOM(Descri, 'p', attrs={'class': 'Cast'})
            cast = parseDOM(cast, 'a')
            meta = fetch_meta(meta_cache, 'movie', title, tmdb_id, url, poster=imgurl, plot=plot, genre=genre, year=year, cast=cast)
            movies.append({'year': meta.get('year'), 'list_name': params['list_name'], 'url': url, 'tmdb_id': tmdb_id, 'meta': meta, 'pg_no': params['pg_no'], 'title': title})
        except: logger(f'from: {__name__} item: {i}\n Error: {print_stack(limit=15)}')

    # logger(f'total movies: {len(movies)} next_p: {next_p}\nmovies: {movies}')
    if not movies: return
    if next_p:
        try:
            # next_p_u = parseDOM(next_p, 'a', attrs={'class': 'page-link'}, ret='href')[1]
            next_p_u = parseDOM(next_p, 'a', ret='href')[-1]
            pg_no = re.compile(r'/([0-9]+)/').findall(next_p_u)[0]
            title = f'Next Page: {pg_no}'
            movies.append({'list_name': params['list_name'], 'url': next_p_u, 'tmdb_id': '', 'meta': {'poster': nextpage, 'plot': f'For More: {params["list_name"]} Movies Go To: {title}', 'genre': ['-']}, 'pg_no': pg_no, 'title': title})
        except: logger(f'get_movies_desicinemas {print_exc()}')
    # logger(f'total movies: {len(movies)} movies: {movies}')
    return movies


def tv_shows(params):
    b_url, list_name, iconImage = params['url'], params['list_name'], params['iconImage']
    cache_name = f'shows_{b_url}'
    shows = main_cache.get(cache_name)
    # logger(f'tv_shows: {shows}\nparams: {params}')
    if not shows:
        shows = get_shows(params)
        if shows: main_cache.set(cache_name, shows, expiration=336)  # 14 days cache

    def _process():
        for item in shows:
            try:
                if old_hindi_shows == 'false' and '-archive' in item['url']:
                    # logger(f'meta For show old_hindi_shows: {old_hindi_shows} item[\'url\']: {item['url']}')
                    continue
                cm = []
                cm_append = cm.append
                title, meta = item['title'], item['meta']
                meta_get = meta.get
                # logger(f'meta For show title: {title} meta: {repr(meta)}')
                poster, tmdb_id, total_seasons, season, imdb_id, tvdb_id = meta_get('poster', iconImage), meta_get('tmdb_id'), meta_get('seasons', 1), meta_get('season', 1), meta_get('imdb_id'), meta_get('tmdb_id')
                playcount = item['playcount'] if item.get('playcount', None) else 0
                meta.update({'mediatype': 'tvshow', 'playcount': playcount, 'original_title': title, 'season': season, 'total_seasons': total_seasons, 'url': item['url'], 'fanart': poster, 'premiered': str(meta_get('year'))})
                # logger(f'meta For show title: {title} info: {meta}')
                meta_json = json.dumps(meta)
                data = {'mode': 'vod_episode', 'title': title, 'list_name': list_name, 'url': item['url'], 'iconImage': poster, 'season': season, 'imdb_id': imdb_id, 'tmdb_id': tmdb_id, 'meta': meta_json, 'pg_no': '1', 'rescrape': 'false'}
                url = build_url(data)
                listitem = make_listitem()
                set_properties = listitem.setProperties
                listitem.setLabel(title.title())
                listitem.setArt({'icon': poster, 'poster': poster, 'thumb': poster, 'fanart': fanart})
                data['rescrape'] = 'true'
                cm_append((f'[B]Reload[/B] {title.title()}', run_plugin % build_url(data)))
                extras_params = {'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'tvshow', 'meta': meta_json, 'is_external': is_external}
                cm_append(('[B]Extras[/B]', run_plugin % build_url(extras_params)))
                cm_append(('[B]Add to a Shortcut Folder[/B]', run_plugin % build_url({'mode': 'menu_editor.shortcut_folder_add_item', 'name': title, 'iconImage': poster})))
                cm_append(('Open Settings', run_plugin % build_url(opensettings_params)))
                listitem.addContextMenuItems(cm, replaceItems=False)
                listitem = set_info(listitem, meta, {'imdb': imdb_id, 'tmdb': tmdb_id, 'tvdb': tvdb_id})
                set_properties({'infinite.extras_params': json.dumps(extras_params), 'totalepisodes': str(meta_get('total_aired_eps') or 1), 'totalseasons': str(total_seasons), 'IsPlayable': 'false'})
                yield url, listitem, True
            except: logger(f'from: {__name__} item: {item}\n Error: {print_stack(limit=15)}')

    from sys import argv  # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    if shows:
        is_external = external()
        add_items(handle, list(_process()))
        set_content(handle, 'tvshows')
        set_category(handle, 'tvshows')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.main', 'tvshows', is_external)
    else:
        notification(f'No Shows Found for: {list_name} Retry or change the Hindi provider in setting.')
        end_directory(handle)
        return


def get_shows(params):
    b_url, list_name = params['url'], params['list_name']
    shows = results = []
    #logger(f'b_url: {type(b_url)} : {repr(b_url)}')
    if isinstance(b_url, str): b_url = eval(b_url)
    for s_url in b_url:
        list_name = s_url.split('/')[-1]
        #logger(f'list_name: {list_name} s_url: {s_url}')
        show_page = request(s_url)
        if show_page: break
    if show_page:
        if current := parseDOM(show_page, 'div', attrs={'id': 'tab-0-title-1'}):
            results = parseDOM(current[0], 'div', attrs={'class': 'one_.+?'})
            if old_hindi_shows == 'true':
                past = parseDOM(show_page, 'div', attrs={'id': 'tab-1-title-2'})
                if past: results += parseDOM(past[0], 'div', attrs={'class': 'one_.+?'})
        if not results:
            results += parseDOM(show_page, 'div', attrs={'class': 'vc_column_container col-md-3'})
            results += parseDOM(show_page, 'div', attrs={'class': 'vc_column_container col-md-4'})
        if not results: results += parseDOM(show_page, 'figure', attrs={'class': 'gallery-item'})
    # logger(f'items total: {len(results)} shows: {results}')
    for i in results:
        try:
            if not i: continue
            genre = ''
            try:
                title = parseDOM(i, 'p', attrs={'class': 'small-title'})[0]
                title = parseDOM(title, 'a')[0]
                if 'concert' in title.lower(): continue
            except:
                try:
                    if 'www.desi-serials.cc' in s_url:
                        try:
                            title = parseDOM(i, 'a', attrs={'class': 'porto-sicon-title-link'})[0]
                            title_overview = parseDOM(i, 'div', attrs={'class': 'porto-sicon-header'})[0]
                            genre = re.findall(r'<\/h5>\s+(.+?)$', title_overview)
                            # logger(f' 1 desi-serials: title: {title} genre: {genre}')
                        except:
                            title_overview = parseDOM(i, 'div', attrs={'class': 'porto-sicon-header'})[0]
                            title_overview = re.findall(r'porto-sicon-title-link.+>(.+?)<\/a><\/h5>(.+?)$', title_overview)[0]
                            title = title_overview[0]
                            genre = title_overview[1]
                            logger(f'2 desi-serials title: {title} genre: {genre} ')
                    else:
                        genre = parseDOM(i, 'p')  #[0]
                        title = parseDOM(i, 'h4', attrs={'class': 'porto-sicon-title'})[0]
                except:
                    try:
                        titem = parseDOM(i, 'figcaption')
                        # url = parseDOM(titem[0], 'a', ret='href')[0]
                        title = parseDOM(titem[0], 'a')
                        genre = titem[1]
                        if not title:
                            title = parseDOM(i, 'a', attrs={'class': 'title'})
                            title = title or parseDOM(i, 'a')
                    except: title = None
            if isinstance(title, list): title = title[0]
            if title is None: continue
            url = parseDOM(i, 'a', ret='href') or parseDOM(i, 'a', attrs={'class': 'title'}, ret='href')
            url = str(url[0])
            imgurl = parseDOM(i, 'img', ret='src')
            try: imgurl = imgurl[0]
            except: imgurl = params['iconImage']
            if 'desi-serials' in s_url and imgurl.startswith('/images'): imgurl = f'{s_url}{imgurl}'
            if 'playdesi' in s_url and imgurl.startswith('/images'): imgurl = f'{s_url}{imgurl}'

            title = keepclean_title(title, True)
            season = find_season_in_title(title)
            tmdb_id = gettmdb_id('tvshow', title, studio=list_name)
            meta = fetch_meta(meta_cache, 'tvshow', title, tmdb_id, url, season, list_name, imgurl, genre=genre)
            meta['season'] = season
            shows.append({'url': url, 'title': title, 'list_name': list_name, 'tmdb_id': tmdb_id, 'meta': meta})
        except: logger(f'from: {__name__} url: {s_url}\nitem: {i}\n Error: {print_stack(limit=15)}')
    # logger(f'len(shows): {len(shows)} shows:  {shows}')
    return shows


def tv_episo(params):
    # logger(f'from : tv_episo params: {params}')
    def _process():
        for item in episodes_data:
            try:
                # logger(f'{__name__} _process item: {item}')
                listitem = make_listitem()
                set_properties = listitem.setProperties
                cm = []
                cm_append = cm.append
                poster = params_get('iconImage', None)
                int_epi, year, ep_name, premiered = int(item['episode']), item['year'], item['title'], item['premiered']
                # logger(f'title: {title} int_epi: {int_epi} ep_name: {ep_name} tvdb_id: {tvdb_id}')
                meta.update({'mediatype': 'episode', 'trailer': '', 'premiered': premiered, 'episode': int_epi, 'year': year, 'ep_name': ep_name, 'url': item['url']})
                setUniqueIDs = {'imdb': imdb_id, 'tmdb': tmdb_id, 'tvdb': tvdb_id}
                listitem.setLabel(ep_name)
                if 'Next Page:' in ep_name:
                    url = build_url({'mode': 'vod_episode', 'title': title, 'list_name': list_name, 'url': item['url'], 'iconImage': poster, 'meta': json.dumps(meta), 'pg_no': item['pg_no'], 'rescrape': 'false'})
                    item.update({'plot': f'For More:[CR]{title} [CR]Go To: {ep_name}'})
                    listitem.setArt({'icon': nextpage, 'fanart': fanart})
                    set_properties({'SpecialSort': 'bottom'})
                    listitem = set_info(listitem, item, setUniqueIDs)
                    isfolder = True
                else:
                    # logger(f'tmdb_id: {repr(tmdb_id)} season: {repr(season)} , int_epi: {repr(int_epi)}')
                    playcount = get_watched_status_episode(watched_info, (int(season), int(int_epi)))
                    progress = get_progress_status_episode(bookmarks, int_epi)
                    # logger(f'tmdb_id: {tmdb_id} (season, int_epi): {repr((season, int_epi))} playcount: {playcount} progress: {progress}')
                    meta.update({'playcount': playcount})
                    data = {'mode': 'playback.media', 'media_type': 'episode', 'tmdb_id': tmdb_id, 'tvshowtitle': title, 'year': year, 'season': season, 'episode': int_epi, 'ep_name': ep_name, 'tvdb_id': tvdb_id, 'hindi_': 'true'}
                    url = build_url(data)
                    data['mode'] = 'scrape_select'
                    cm_append(('Select Source', run_plugin % build_url(data)))
                    data['mode'] = 'rescrape_select'
                    cm_append(('Rescrape & Select Source', run_plugin % build_url(data)))
                    cm_append(('Open Settings', run_plugin % build_url(opensettings_params)))
                    # logger(f'{__name__} _process progress: {repr(progress)} playcount: {repr(playcount)} ep_name: {ep_name}')
                    if progress:
                        cm_append(('[B]Clear Progress[/B]', run_plugin % build_url({'mode': 'watched_status.erase_bookmark', 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': int_epi, 'refresh': 'true', 'watched_indicators': '0'})))
                        set_properties({'WatchedProgress': progress})
                    if playcount: cm_append(('[B]Mark Unwatched Infinite[/B]', run_plugin % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_unwatched', 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season, 'episode': int_epi, 'title': title})))
                    else: cm_append(('[B]Mark Watched Infinite[/B]', run_plugin % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_watched', 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season, 'episode': int_epi, 'title': title})))
                    listitem.addContextMenuItems(cm)
                    listitem.setArt({'poster': poster, 'fanart': fanart, 'icon': poster, 'thumb': poster, 'clearart': poster})
                    listitem = set_info(listitem, meta, setUniqueIDs, progress)
                    isfolder = False
                set_properties({'IsPlayable': 'false'})
                list_items_append({'listitem': (url, listitem, isfolder), 'display': ep_name})
            except: logger(f'from: {__name__} item: {item}\n Error: {print_stack(limit=15)}')

    from sys import argv  # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    list_items = []
    list_items_append = list_items.append
    url, rescrape, meta, title, list_name = params['url'], params['rescrape'], params['meta'], params['title'], params['list_name']
    meta = json.loads(meta)
    # logger(f'{__name__} tv_episo meta: {meta}')
    params_get = params.get
    tvdb_id = meta.get('tvdb_id')
    season, tmdb_id, imdb_id = meta.get('season', 1), meta.get('tmdb_id') or tvdb_id, meta.get('imdb_id') or tvdb_id
    cache_name = f'episodes_{urlencode({"url": url, "pg_no": params["pg_no"]})}'
    if rescrape == 'true':
        main_cache.delete_like(cache_name)
        episodes_data = None
    else:
        episodes_data = main_cache.get(cache_name)
    if not episodes_data:
        episodes_data = get_episode(params)
        if episodes_data: main_cache.set(cache_name, episodes_data, expiration=18)  # 12 hrs cache
    # logger(f'len(episodes_data): {len(episodes_data)} episodes_data: {episodes_data}')
    if episodes_data:
        watched_info, bookmarks = get_media_info(0, 'episode', tvdb_id, season)
        # logger(f'from tv_episo len(bookmarks): {len(bookmarks)} bookmarks: {bookmarks}\nlen(watched_info): {len(watched_info)} watched_info: {watched_info}')
        _process()
        if 'Episode' in list_items[0]['display']: list_items.sort(key=lambda x: x['display'])
        # logger(f'len(list_items): {len(list_items)} list_items: {list_items}')
        item_list = [i['listitem'] for i in list_items]
        is_external = external()
        add_items(handle, item_list)
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.episode_lists', 'episodes', is_external)
    else:
        notification(f'No Episode Found for: {title} Retry or change the Hindi provider in setting.')
        end_directory(handle)
        return


def get_episode(params):
    try:
        url, title, list_name, pg_no = params['url'], params['title'], params['list_name'], params.get('pg_no', '1')
        # logger(f'title: {title} url: {url}')
        episodes = results = []
        episo_page = request(url)
        results = parseDOM(episo_page, 'div', attrs={'class': 'post-details'})
        # results += parseDOM(episo_page, 'h3', attrs={'class': 'threadtitle'})
        if not results:
            results += parseDOM(episo_page, 'article')
            results += parseDOM(episo_page, 'div', attrs={'class': 'main-content col-lg-9'}) or parseDOM(episo_page, 'div', attrs={'class': 'blog-posts posts-large posts-container'})
        if not results: results += parseDOM(results, 'h2', attrs={'class': 'entry-title'})
        # logger(f'total episodes: {len(results)} results: {results}')
        for i in results:
            if 'promo' in i or '(Day' in i: continue
            try:
                url = parseDOM(i, 'a', ret='href')[0]
                try:
                    h2 = parseDOM(i, 'h2')[0]
                    ep_name = parseDOM(h2, 'a', ret='title')
                except:
                    try: ep_name = parseDOM(i, 'a')[0]
                    except:
                        ep_name = parseDOM(i, 'a', attrs={'class': 'title'})
                        ep_name += parseDOM(i, 'a')
                if isinstance(ep_name, list): ep_name = ep_name[0]
                ep_name = additional_title_cleaner(ep_name)
                # ep_name = ep_name.lower().replace('watch online', '').replace('hd', '').replace('telecast', '')
                # ep_name = ep_name.title()
                #logger(f'ep_name: {ep_name}')
                if 'Episode' in ep_name or title != 'Awards': ep_name = get_episode_date(ep_name, title)
                #logger(f'2ep_name: {ep_name}')
                if '?' in url: url = url.split('?')[0]
                url = url if url.startswith(dr_url) else urljoin(dr_url, url)
                if ep_name:
                    int_epi, year = get_int_epi(ep_name)
                    premiered = string_date_to_num(ep_name)
                    episodes.append({'url': url, 'title': ep_name, 'list_name': list_name, 'episode': int_epi, 'premiered': premiered, 'year': year, 'pg_no': pg_no})
            except: logger(f'from: {__name__} url: {url}\nitem: {i}\n Error: {print_stack(limit=15)}')
        next_p = parseDOM(episo_page, 'div', attrs={'class': 'nav-links'}) or parseDOM(episo_page, 'div', attrs={'class': 'pagination-wrap'}) or parseDOM(episo_page, 'div', attrs={'class': 'pages-nav'})
        if next_p:
            if next_p_url := next_pagination_dict(next_p, title, list_name):
                episodes.append(next_p_url)
        # logger(f'len(episodes): {len(episodes)} episodes :  {episodes}')
        return episodes
    except: logger(f'from: {__name__} url: {url}\n Error: {print_stack(limit=15)}')


def next_pagination_dict(next_p, title, list_name):
    next_p_url = ''
    if next_p_u := parseDOM(next_p, 'a', attrs={'class': 'next page-numbers'}, ret='href'): next_p_url = next_p_u[0]
    elif next_p_u := parseDOM(next_p, 'li', attrs={'class': 'the-next-page'}):
        if next_p_u := parseDOM(next_p_u, 'a', ret='href'): next_p_url = next_p_u[0]
    elif next_p_u := parseDOM(next_p, 'a', attrs={'class': 'pages-nav-item'}, ret='href'): next_p_url = next_p_u[0]
    elif next_p_u := parseDOM(next_p, 'a', attrs={'class': 'next.+?'}, ret='href'): next_p_url = next_p_u[0]
    # logger(f'{repr(next_p_url)}')
    if next_p_url:
        pg_no = re.compile(r'/([0-9]+)/').findall(next_p_url)[0] or re.compile(r'page\d{1,2}').findall(next_p_url)[0]
        name = f'Next Page: {pg_no}'
        return {'url': next_p_url, 'title': name, 'list_name': list_name, 'premiered': '', 'plot': f'For More {title} Go To {name} ....', 'episode': pg_no, 'season': 0, 'year': 0, 'pg_no': pg_no, }
    else: return