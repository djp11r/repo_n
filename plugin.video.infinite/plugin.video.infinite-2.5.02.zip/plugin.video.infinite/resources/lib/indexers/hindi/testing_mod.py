# -*- coding: utf-8 -*-

import datetime
import time
from traceback import print_exc

from apis.trakt_api import trakt_sync_activities
from caches.base_cache import clean_databases, clrCache_version_update
from caches.main_cache import main_cache
from caches.settings_cache import get_setting
from indexers.hindi.lists import youtube_m3u
from modules.episode_tools import EpisodeTools
from modules.kodi_utils import Thread, close_all_dialog, confirm_dialog, logger, monitor, notification, ok_dialog, show_text, sleep, tmdb_default_api
from modules.metadata import tvshow_meta
from modules.watched_status import get_progress_percent, get_bookmarks
from modules.settings import auto_nextep_settings, get_folderscraper_info
from windows.base_window import create_window, open_window
from windows.skip import updateskip_data

from modules.source_utils import get_external_sources
from modules.utils import get_datetime
from scrapers import folders

meta = {'tmdb_id': 153657, 'tvdb_id': 414553, 'imdb_id': 'tt14168162', 'rating': 8.105, 'plot': 'The Screen Cutter attempts to bargain with Bosch and Chandler, who go to extremes to locate Maddie before it’s too late.', 'tagline': 'New crimes. New cases. Same Bosch.', 'votes': 110, 'premiered': '2023-10-19', 'year': '2022', 'poster': 'https://image.tmdb.org/t/p/w780/jaBQkpjXw0wtbAFLJ23SKFc6fa8.jpg', 'fanart': 'https://image.tmdb.org/t/p/w1280/77haG1Gy3A6T4t1pAQTiVY8pgWJ.jpg', 'genre': ['Crime, Drama'], 'title': 'Bosch: Legacy', 'original_title': 'Bosch: Legacy', 'english_title': '', 'season_data': [{'air_date': '2022-05-05', 'episode_count': 10, 'id': 236268, 'name': 'Season 1', 'overview': "Bosch's first job calls him to the estate of ailing billionaire Whitney Vance, where he is tasked with finding Vance’s only potential heir. Along the way, Bosch finds himself clashing with powerful figures who have a vested interest in the heir not being found. Bosch finds an invaluable resource in Maurice “Mo” Bassi, a tech-forward gadget whiz who also shares Bosch’s fondness for smooth jazz and commitment to justice.", 'poster_path': '/9Z7L7wSB6nLwWk7coUgm1ytQbOB.jpg', 'season_number': 1, 'vote_average': 8.0}, {'air_date': '2023-10-19', 'episode_count': 10, 'id': 339338, 'name': 'Season 2', 'overview': "Bosch and Chandler work together to seek out a killer who just might find them first. As a result of being kidnapped by a masked assailant, Maddie Bosch's law enforcement career hangs in the balance. While they hunt for Maddie, the FBI scrutinizes Carl Rogers' murder and places Bosch and Chandler under suspicion.", 'poster_path': '/jaBQkpjXw0wtbAFLJ23SKFc6fa8.jpg', 'season_number': 2, 'vote_average': 8.4}], 'alternative_titles': ['Bosch: Legacy', "Untitled 'Bosch' Spinoff"], 'duration': 1800, 'rootname': 'Bosch: Legacy (2022)', 'imdbnumber': 'tt14168162', 'country': ['United States of America'], 'mpaa': 'TV-MA', 'trailer': 'plugin://plugin.video.youtube/play/?video_id=6Wsp-o_o_6E', 'country_codes': ['US'], 'writer': [''], 'director': [], 'all_trailers': [{'iso_639_1': 'en', 'iso_3166_1': 'US', 'name': 'Bosch: Legacy S2 Teaser | Coming October 20', 'key': '6Wsp-o_o_6E', 'site': 'YouTube', 'size': 1080, 'type': 'Trailer', 'official': True, 'published_at': '2023-08-24T16:19:05.000Z', 'id': '6532c162efe37c011e74565d'}], 'cast': [{'name': 'Titus Welliver', 'role': 'Harry Bosch', 'thumbnail': 'https://image.tmdb.org/t/p/h632/3hTwn7Maktr6ONq1VvfqyRacjiv.jpg'}, {'name': 'Mimi Rogers', 'role': 'Honey Chandler', 'thumbnail': 'https://image.tmdb.org/t/p/h632/16p4H0rtA0AwLs3xyj56km75CMM.jpg'}, {'name': 'Madison Lintz', 'role': 'Maddie Bosch', 'thumbnail': 'https://image.tmdb.org/t/p/h632/rr6tpaVVdeYAmZKl509HCizYFwg.jpg'}, {'name': 'Stephen A. Chang', 'role': "Maurice 'Mo' Bassi", 'thumbnail': 'https://image.tmdb.org/t/p/h632/gZxyFXDPDrZBAHqBXyujoYaW6Hn.jpg'}, {'name': 'Denise G. Sanchez', 'role': 'Reina Vasquez', 'thumbnail': 'https://image.tmdb.org/t/p/h632/zK4onOonf2fDK4byvzNyWrBvXGZ.jpg'}], 'studio': ['Amazon Freevee'], 'extra_info': {'status': 'Returning Series', 'type': 'Scripted', 'homepage': 'https://www.amazon.com/dp/B09PQPSX34/', 'created_by': 'Michael Connelly, Eric Overmyer, Tom Bernardo', 'next_episode_to_air': None, 'last_episode_to_air': {'id': 4678458, 'name': 'A Step Ahead', 'overview': 'Bosch ensures the Lexi Parks case reaches its just conclusion. Chandler considers a big career change with the help of an old acquaintance. Maddie wrestles with the fallout of her first officer-involved shooting. Mo faces a serious ultimatum with the FBI.', 'vote_average': 9.0, 'vote_count': 4, 'air_date': '2023-11-09', 'episode_number': 10, 'episode_type': 'finale', 'production_code': '', 'runtime': 52, 'season_number': 2, 'show_id': 153657, 'still_path': '/tDRdECHy3hgRfo7TncBO0o3NTk.jpg'}}, 'total_aired_eps': 20, 'mediatype': 'tvshow', 'total_seasons': 2, 'tvshowtitle': 'Bosch: Legacy', 'status': 'Returning Series', 'clearlogo': 'https://image.tmdb.org/t/p/original/vZ8kgoVrmhrywTbGWs6uu4ZYL1Q.png', 'tvshow_plot': "Bosch is now making a living as a private investigator two years after he quit the LAPD and finds himself working with one time enemy and top-notch attorney Honey “Money” Chandler. Meanwhile, Bosch's daughter Maddie is venturing into the world of the LAPD.", 'media_type': 'episode', 'season': 2, 'episode': 2, 'ep_name': 'Zzyzx', 'ep_thumb': 'https://image.tmdb.org/t/p/original/4Vws4qF6TIsNkNDE6kM55gvGNNN.jpg', 'skip_option': {'title': 'Bosch Legacy', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '300'}, 'skip_style': '0', 'display_name': 'Bosch: Legacy S2E2', 'background': False, 'custom_title': None, 'custom_year': None, 'custom_season': None, 'custom_episode': None}
# meta = {'mediatype': 'episode', 'year': 2022, 'plot': 'The Kapil Sharma Show, also known as TKSS, is an Indian Hindi-language stand-up comedy and talk show broadcast by Sony Entertainment Television. Hosted by Kapil Sharma The series revolved around Sharma and his neighbours in the Shantivan Non Co-operative Housing Society.', 'title': 'The Kapil Sharma Show Season 4', 'studio': ['Sony'], 'poster': 'https://www.desi-serials.cc/wp-content/uploads/2022/08/The-Kapil-Sharma-Show-300x169.jpg', 'homepage': 'https://www.desi-serials.cc/watch-online/sony-tv/the-kapil-sharma-show-season-4/', 'genre': ['Saturday  Sunday.', 'Comedy', 'Talk-Show'], 'cast': [], 'tmdb_id': 'Sony|The Kapil Sharma Show Season 4', 'imdb_id': 'tt5747326', 'rating': 7.3, 'clearlogo': '', 'trailer': '', 'votes': 50, 'tagline': '', 'director': [], 'writer': [], 'episodes': 390, 'seasons': '1, 2, 3, 4', 'extra_info': {'status': '', 'collection_id': ''}, 'tvdb_id': 'Sony|the kapil sharma show', 'duration': 3600, 'mpaa': 'TV-MA', 'season': 4, 'episode': 910, 'tvshowtitle': 'The Kapil Sharma Show Season 4', 'playcount': 0, 'original_title': 'The Kapil Sharma Show Season 4', 'total_seasons': '4', 'url': 'https://www.desi-serials.cc/the-kapil-sharma-show-season-4-episode-10th-september-2022-watch-online/441968/', 'fanart': 'https://www.desi-serials.cc/wp-content/uploads/2022/08/The-Kapil-Sharma-Show-300x169.jpg', 'premiered': '2022-09-10', 'ep_name': '10th September 2022', 'overlay': 4, 'media_type': 'episode', 'background': False, 'skip_option': {'title': 'The Kapil Sharma Show', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '300'}, 'skip_style': 'netflix'}

def testting():
    get_next_ep()


def test_window(win='resolver'):
    if win == 'nextep_win': # windows.next_episode <<<<<<<<<
        action = open_window(('windows.next_episode', 'NextEpisode'), 'next_episode.xml', meta=meta, test=True, default_action='cancel', play_type='autoplay_nextep', focus_button=11)
        if action == 'cancel':
            action = open_window(('windows.skip', 'Skip'), 'skipmulti.xml', skip_option=meta.get('skip_option'), test=True, focus_button=201, window_style='end_skip')
        action = open_window(('windows.next_episode', 'NextEpisode'), 'next_episode.xml', meta=meta, test=True, default_action='cancel', play_type='autoscrape_nextep', focus_button=11)
    elif win == 'infopop': # windows.infopop <<<<<<<<<
        action = open_window(('windows.extras', 'Extras'), 'extras.xml', options_media_type=meta.get('media_type'), meta=meta, is_external='false')
    elif win in ('skip_win', 'updateskip'): # windows.skip <<<<<<<<<<
        skip_option = {'title': 'The Blacklist', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '300'}
        windowstyle = 'netflix'#'Regular'
        # logger(f'windowstyle: {windowstyle.lower()}')
        if win == 'updateskip': updateskip_data(skip_option)
        else: buttonskip = open_window(('windows.skip', 'Skip'), 'skipmulti.xml', test=True, skip_option=skip_option, focus_button=201, window_style=windowstyle.lower())
        # logger(f'buttonskip: {buttonskip}')
    elif win in ('playback', 'resolver', 'resume', 'progress'): # playback && resolver etc<<<<<<<
        # kwargs = {'meta': meta, 'text': 'ok i see', 'enable_buttons': True, 'true_button': 'Yes', 'false_button': 'No', 'focus_button': 11}
        kwargs = {'meta': meta, 'text': 'ok i see', 'enable_fullscreen': True}
        _threads = []
        start_time = time.time()
        scraper_timeout = int(get_setting('results.timeout', '30'))
        sleep_time = 100
        end_time = start_time + scraper_timeout
        from modules.kodi_utils import monitor
        if win in ('playback', 'resolver', 'resume'): progress_dialog = create_window(('windows.sources', 'SourcesPlayback'), 'sources_playback.xml', meta=meta)
        if win == 'progress': progress_dialog = create_window(('windows.progress', 'Progress'), 'progress.xml', heading='progress', icon=meta.get('poster'))
        Thread(target=progress_dialog.run).start()
        if win == 'resolver': progress_dialog.enable_resolver()
        if win == 'resume': progress_dialog.enable_resume(15)
        remaining_providers = ['freeworldnews.tv', 'playersb.com', 'vedshare.com', 'voeunblock8.com', 'youtu.be']
        try:
            while not progress_dialog.iscanceled() and not monitor.abortRequested():
                if progress_dialog.iscanceled(): break
                sources_total = sources_4k = sources_1080p = sources_720p = sources_sd = 5
                current_time = time.time()
                elapsed_time = current_time - start_time
                line1 = ', '.join(remaining_providers).upper()
                percent = int((elapsed_time / float(scraper_timeout)) * 100)
                try:
                    if win == 'playback': progress_dialog.update_scraper(sources_sd, sources_720p, sources_1080p, sources_4k, sources_total, line1, percent)
                    elif win == 'resolver': progress_dialog.update_resolver(percent=elapsed_time)
                    elif win == 'resume': progress_dialog.update_resumer()
                    elif win == 'progress': progress_dialog.update(percent=elapsed_time)
                except: pass
                sleep(10)
                # logger(f'percent: {percent} elapsed_time: {elapsed_time}')
                if percent >= 100: break
                if current_time >= end_time: break
        except: logger(f'error: {print_exc()}')
        progress_dialog.close()
        try: del monitor
        except: pass
    elif win == 'sources_results': # windows.select_ok <<<<<<<<<<<<
        results = [{'source': 'tvarticles', 'quality': 'SD', 'info': 'All part: Single', 'url': 'https://tvarticles.org/vidd.php?id=2239785', 'direct': False, 'name': 'The Kapil Sharma Show S1E226', 'name_info': '', 'display_name': 'The Kapil Sharma Show S1E226', 'provider_site': 'tvarticles', 'scrape_provider': 'external', 'extraInfo': 'All part: Single', 'module_path': 'openscrapers.sources_openscrapers.en.desiserials', 'size_label': None, 'size': 0, 'provider_rank': 2, 'quality_rank': 4 }, {'source': 'gdrive', 'name': 'Modern.Family.S11E08.720p.WEB-HD.x264-Pahe.in.mkv', 'name_info': '.720p.web.hd.x264.pahe.in.mkv.', 'quality': '720p', 'url': 'https://gd.djp97s.workers.dev/Modern.Family.S11E08.720p.WEB-HD.x264-Pahe.in.mkv', 'info': 'AVC | WEB | MKV', 'direct': True, 'size': 0.15, 'display_name': 'Modern Family S11E8', 'provider_site': 'gdrive', 'scrape_provider': 'external', 'extraInfo': 'AVC | WEB | MKV', 'module_path': 'openscrapers.sources_openscrapers.en.gdrive', 'size_label': '0.15 GB', 'provider_rank': 2, 'quality_rank': 3 }, {'source': 'mixdrop.co', 'quality': 'SD', 'info': 'MP4 | ', 'url': 'https://mixdrop.co/e/wn6dpeo6szdwlx', 'direct': False, 'name': 'Modern Family S11E8', 'name_info': '', 'display_name': 'Modern Family S11E8', 'provider_site': '123moviestv_me', 'scrape_provider': 'external', 'extraInfo': '', 'module_path': 'openscrapers.sources_openscrapers.en.123moviestv_me', 'size_label': None, 'size': 0, 'provider_rank': 2, 'quality_rank': 4 }]
        scraper_settings = {'highlight_type': 2, 'hoster_highlight': '', 'torrent_highlight': '', 'real-debrid': '', 'premiumize': '', 'alldebrid': '', 'rd_cloud': '', 'pm_cloud': '', 'ad_cloud': '', 'furk': '', 'easynews': '', 'folders': '', '4k': 'FFFF3334', '1080p': 'FFE6B800', '720p': 'FF3C9900', 'sd': 'FFCAFFFF'}
        action = open_window(('windows.sources', 'SourcesResults'), 'sources_results.xml',
				window_format='list', window_style='non_contrast', window_id=2000, results=results, meta=meta,
				scraper_settings=scraper_settings, prescrape=False, filters_ignored=False, uncached_torrents=[])
        if not action: close_all_dialog()
    elif win == 'select_ok_win': # windows.select_ok <<<<<<<<<<<<
        confirm_dialog()
        ok_dialog()
        show_text(heading='Infinite', text='ok i c')

def cache_test():
    ctime = datetime.datetime.now()
    current_time = int(time.mktime(ctime.timetuple()))
    clean_databases(current_time, database_check=False, silent=True)
    providers = sources('true', 'episode')
    youtube_m3u()
    main_cache.clean_hindi_lists()
    logger(providers)
    clrCache_version_update(clr_cache=True, clr_navigator=False)
    status = trakt_sync_activities()
    logger(f'status: {status}')

def get_meta():
    current_date = get_datetime
    ep_data_get = {'media_ids': {'tmdb': 93812}, 'season': 2}
    meta = tvshow_meta('trakt_dict', ep_data_get['media_ids'], tmdb_default_api, current_date)
    logger(f'meta: {meta}')

def get_folders():
    folder_info, internal_scraper_names = get_folderscraper_info()
    # logger(f'folder_info: {folder_info}\ninternal_scraper_names: {internal_scraper_names}')
    prescrape_scrapers = []
    info = {'media_type': 'movie', 'title': 'Star Wars: The Last Jedi', 'year': '2017', 'tmdb_id': 181808, 'imdb_id': 'tt2527336', 'aliases': [{'title': 'Star Wars: Episode VIII', 'country': ''}, {'title': 'Star Wars: Episode VIII – The Last Jedi', 'country': ''}, {'title': 'The Last Jedi', 'country': ''}, {'title': 'Star Wars - The Last Jedi - 3D', 'country': ''}, {'title': 'Star Wars: Episode VIII - The Last Jedi: Legendary', 'country': ''}, {'title': 'Star Wars: Episode 8 - The Last Jedi', 'country': ''}, {'title': 'Star Wars Episode VIII - The Last Jedi', 'country': ''}, {'title': 'Star Wars: Episode VIII - The Last Jedi 3D', 'country': ''}, {'title': 'Star Wars։ Episode VIII - The Last Jedi', 'country': ''}, {'title': 'Star Wars 8 - The Last Jedi', 'country': ''}, {'title': 'Star Wars: Episode VIII - The Last Jedi', 'country': ''}, {'title': 'Star Wars։ The Last Jedi (Episode VIII)', 'country': ''}, {'title': 'TLJ', 'country': ''}, {'title': 'Star Wars: The Last Jedi', 'country': ''}, {'title': 'Star Wars: The Last Jedi US', 'country': ''}], 'season': None, 'episode': None, 'tvdb_id': 'None', 'ep_name': None, 'expiry_times': (336, 0, 0), 'total_seasons': 1}
    scrape_provider, scraper_name, folder_path = 'folder1', 'English Enet', 'smb://cp:srusty@ENET/Media/ENet/English Movies/'
    info = {'media_type': 'episode', 'title': '24', 'year': '2001', 'tmdb_id': 1973, 'imdb_id': 'tt0285331', 'aliases': [{'title': 'Twenty Four', 'country': ''}, {'title': '24: Live Another Day', 'country': ''}, {'title': '24', 'country': ''}, {'title': '24 US', 'country': ''}], 'season': 8, 'episode': 6, 'tvdb_id': 76290, 'ep_name': 'Day 8: 12:00 A.M.-1:00 A.M.', 'expiry_times': (240, 720, 720), 'total_seasons': 9}
    scrape_provider, scraper_name, folder_path = 'folder4', 'D drive TV Shows', 'D:/My Media/TV Shows/'
    folders_sraper = folders.source(scrape_provider, scraper_name, folder_path)
    results = folders_sraper.results(info)
    logger(f'folder_results: {results}')
    scraper_settings = {'highlight_type': 2, 'hoster_highlight': '', 'torrent_highlight': '', 'real-debrid': '', 'premiumize': '', 'alldebrid': '', 'rd_cloud': '', 'pm_cloud': '', 'ad_cloud': '', 'furk': '', 'easynews': '', 'folders': '', '4k': 'FFFF3334', '1080p': 'FFE6B800', '720p': 'FF3C9900', 'sd': 'FFCAFFFF'}
    if not results: notification('no result'); return
    action = open_window(('windows.sources', 'SourcesResults'), 'sources_results.xml',
            window_format='list', window_style='non_contrast', window_id=2000, results=results, meta=meta,
            scraper_settings=scraper_settings, prescrape=False, filters_ignored=False, uncached_torrents=[])
    if not action: close_all_dialog()

def get_next_ep():
    nextep_settings = auto_nextep_settings('autoplay_nextep')
    # nextep_settings = {'scraper_time': 70, 'window_percentage': 10, 'alert_method': 0, 'default_action': 'play', 'use_chapters': True, 'play_type': 'autoscrape_nextep'}
    logger(f'nextep_settings: {nextep_settings}')
    EpisodeTools(meta, nextep_settings).auto_nextep()

def get_yt_dl():
    from modules.downloader import yt_dl
    yt_dl()

def get_sources():
    ret_all, media_type, vid_type = False, 'episode', None
    external_providers = get_external_sources(ret_all, media_type, vid_type)
    logger(f'get_external_sources: {len(external_providers)} :: {external_providers}')


def get_percent():
    watched_indicators = 1
    media_type = 'movie'
    tmdb_id = 1051
    season = episode = ''
    percent = get_progress_percent(get_bookmarks(watched_indicators, media_type), tmdb_id, season, episode)
    logger(f'percent: {percent}')