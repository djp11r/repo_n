# -*- coding: utf-8 -*-
from modules import service_functions
from modules.kodi_utils import Thread, xbmc_monitor, logger, notification

on_notification_actions = service_functions.OnNotificationActions()

class infiniteMonitor(xbmc_monitor):
	def __init__(self):
		xbmc_monitor.__init__(self)
		self.startServices()

	def startServices(self):
		service_functions.MakeDatabases().run()
		service_functions.CheckSettings().run()
		Thread(target=service_functions.CustomActions().run).start()
		# Thread(target=service_functions.CustomFonts().run).start()
		service_functions.RemoveOldDatabases().run()
		try: service_functions.SyncMyAccounts().run()
		except: pass
		Thread(target=service_functions.TraktMonitor().run).start()
		notification('Infinite runing', time=2000)
		Thread(target=service_functions.UpdateCheck().run).start()
		service_functions.AutoStart().run()

	def onNotification(self, sender, method, data):
		#logger('onNotification - sender, method, data', (sender, method, data))
		on_notification_actions.run(sender, method, data)


infiniteMonitor().waitForAbort()
logger('Infinite Main Monitor Service Finished')
