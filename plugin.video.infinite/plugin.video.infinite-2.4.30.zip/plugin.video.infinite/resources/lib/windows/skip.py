# -*- coding: utf-8 -*-

import traceback
from xbmcgui import Dialog, INPUT_NUMERIC
from windows import BaseDialog
from modules.kodi_utils import logger
from modules.notroparser import enable_show, updateSkip as updateSkip_database

BACK_ACTIONS = 92
PREVIOUS_MENU = 10


class Skip(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.closed = False
		self.isVisible = True
		self.selected = 'close'
		self.window_style = kwargs.get('window_style', 'netflix')
		self.skip_option = kwargs.get('skip_option')
		self.focus_button = kwargs.get('focus_button', 201)
		self.set_properties()

	def set_properties(self):
		# logger(f'self.window_style : {self.window_style}')
		self.setProperty('skip.window_style', self.window_style)
		self.skipLabel = f"SKIP INTRO: {self.skip_option.get('skip', '0')}"
		self.setProperty('skip.title', self.skipLabel)

	def onInit(self):
		self.setFocus(self.getControl(self.focus_button))
		self.monitor()

	def onClick(self, controlID):
		logger(f'Skip onclick: {controlID}')
		if controlID == 201:
			self.selected = 'True'
		elif controlID == 202:
			try:
				self.player.pause()
				updateskip_data(self.skip_option)
				self.player.pause()
			except Exception as ex: logger(f'onClick 202 error : {ex}')
		elif controlID [BACK_ACTIONS, PREVIOUS_MENU]:
			self.closed = True
			self.close()
		self.closed = True
		self.close()

	# @property
	# def isButtonVisible(self):
		# return self.isVisible

	# def setVisibility(self):
		# self.isVisible = not self.isVisible

	def closeDialog(self):	# pylint: disable=invalid-name
		self.close()

	def run(self):
		self.doModal()
		self.clearProperties()
		return self.selected

	def onAction(self, action):
		if action in self.closing_actions or action in [BACK_ACTIONS, PREVIOUS_MENU]:
			self.closed = True
			self.close()

	def monitor(self):
		# self.sleep(500)
		try:
			while not self.player.isPlayingVideo(): self.sleep(500)
			total_time = self.player.getTotalTime()
			while self.player.isPlaying():
				try:
					if self.closed: break
					current_time = self.player.getTime()
					# remaining = self.skip_option.get('skip', 300)
					if float(current_time) >= float(300):
						self.close()
						self.closed = True
					self.sleep(500)
				except: pass
			try:
				if current_time - 10 >= total_time:
					self.close()
			except: pass
		except Exception as exce:
			logger(f'Skip Error: {exce}')

class UpdateSkip(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		""""""
		self.skip_option = kwargs['skip_option']

	def onInit(self):
		self.show_dialog()

	def run(self):
		self.doModal()

	def show_dialog(self):
		tvshow = self.skip_option.get('title')
		skip = int(self.skip_option.get('skip'))
		start = int(self.skip_option.get('start'))
		eskip = int(self.skip_option.get('eskip'))
		# logger(f"skip: {skip}")
		self.getControl(111).setLabel(f"Title: {tvshow}")
		if self.skip_option.get('service') == 'True': self.getControl(112).setSelected(True)
		else: self.getControl(112).setSelected(False)
		self.setFocus(self.getControl(114))
		self.getControl(113).setLabel(f"Skip old value   : {skip}")
		self.getControl(114).setLabel(f"{skip}")
		self.getControl(115).setLabel(f"Skip start value : {start}")
		self.getControl(116).setLabel(f"{start}")
		self.getControl(117).setLabel(f"Exit Skip value  : {eskip}")
		self.getControl(118).setLabel(f"{eskip}")

	def onClick(self, controlid):
		if controlid == 121:
			try:
				# logger(f"slider_305: {self.getControl(115).getInt()}")
				self.skip_option.update({'service': str(self.getControl(112).isSelected()), 'skip': f'{self.getControl(114).getLabel()}', 'start': f'{self.getControl(116).getLabel()}', 'eskip': f'{self.getControl(118).getLabel()}'})
				# logger(f"spincontrolex_302: {self.getControl(114).getLabel()}")
				# logger(f"slider_305: {self.skip_option}")
				updateSkip_database(self.skip_option)
				# logger(f"radiobutton_301: {self.getControl(301).isSelected()}")
			except: logger("Error: {traceback.format_exc()}")
			self.close()
		elif controlid in [114, 116, 118]:
			text = self.InputNos()
			if text != None:
				self.getControl(controlid).setLabel(f'{str(text)}')
		elif controlid == 122:
			enable_show()
			self.close()

	def onAction(self, action):
		if action.getId() in [BACK_ACTIONS, PREVIOUS_MENU]:
			self.close()

	def InputNos(self):
		text = None
		dialog = Dialog()
		text = dialog.input('Value in (seconds)', type=INPUT_NUMERIC)
		return text


def updateskip_data(skip_option=None):
	try:
		# skip_option = {'title': 'Punyashlok Ahilya Bai', 'service': True, 'skip': '50', 'start': '0', 'eskip': '120'}
		from windows import open_window
		buttonskip = open_window(('windows.skip', 'UpdateSkip'), 'skipupdate.xml', skip_option=skip_option)
		# fr = UpdateSkip("skipupdate.xml", ADDON.getAddonInfo('path'), skip_option=skip_option)
		# fr.doModal()
		# del fr
	except:
		logger(f"Error: {traceback.format_exc()}")
