# -*- coding: utf-8 -*-

import base64
import re
from json import dumps, loads
from traceback import print_exc
from urllib.parse import urlencode, urlparse, quote_plus
import requests
try:
    from modules.kodi_utils import set_resolvedurl, logger, kodi_player, build_url, addon_icon, select_dialog, make_listitem, set_info,  notification, add_items, set_content, end_directory, set_view_mode, get_infolabel, set_category, external, get_list_item, nextpage
    from modules.settings import get_git_url
    from modules.utils import normalize
    from modules.source_utils import request, agent, get_page_server, uh_detect, unhunt, convert_youtube_duration_to_minutes
    from caches.main_cache import main_cache, cache_object
    from caches.settings_cache import get_setting
    ddurl = get_setting('infinite.live_url', '')
    chnnel_filter = get_setting('infinite.live_channels', 'DAZN, Movistar').split(', ')
except:
    # logger(f'import Exception: {print_exc()}')
    from modules.utils import logger, normalize
    from modules.main_cache import main_cache, cache_object
    from modules.client import request, agent, get_page_server
    from modules.jsunhunt import detect as uh_detect, unhunt
    import os
    nextpage = ''
    ddurl = 'https://dlhd.so'
    chnnel_filter = ['DAZN', 'Movistar', 'Espa', 'Alkass', 'Greece', 'Netherland', 'Germany', 'SUR', 'Deportes', 'Galavisi', 'Latino', 'Russia', 'Campeones', 'ES', 'Romania', 'DSTV', 'Italy', 'Argentina', 'Afrique', 'Denmark', 'Brasil', 'Sweden', 'Cosmote', 'Israe', 'Israel', 'Poland', 'Bulgaria', 'Spain', 'Qatar', 'Turkey', 'France', 'MENA', 'DE', 'Portugal', 'Croatia', 'Astro', 'Serbia']
from modules.dom_parser import parseDOM

tvappurl = 'https://thetvapp.to'
regex_pattern = re.compile(r'''(?:source|src|file)['"]*:\s*(?:"|')(.*?)(?:"|')''', flags=re.DOTALL+re.I)
regex_pattern1 = re.compile(r'''(?s)script>\s*var.*?"([^"]*)''', flags=re.DOTALL+re.I)
header = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7', 'Accept-Encoding': 'gzip, deflate', 'Accept-Language': 'en,en-US;q=0.9', 'Cache-Control': 'no-cache', 'Pragma': 'no-cache', 'Sec-Ch-Ua': '"Not(A:Brand";v="24", "Chromium";v="122"', 'Sec-Ch-Ua-Mobile': '?0', 'Sec-Ch-Ua-Platform': "Windows", 'Sec-Fetch-Dest': 'document', 'Sec-Fetch-Mode': 'navigate', 'Sec-Fetch-Site': 'same-site', 'Sec-Fetch-User': '?1', 'Upgrade-Insecure-Requests': '1', 'DNT': '1', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'}
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0'
play_youtube_url = 'plugin://plugin.video.youtube/play/?video_id'


def get_c_list(params):
    ch_name = params['list_name']
    cache_name = f'content_{ch_name}{urlencode(params)}'
    list_data = main_cache.get(cache_name)
    if not list_data:
        git_url = get_git_url()
        if ch_name == 'youtube': data = request(f'{git_url}/youtub_live.json')
        elif ch_name == 'pluto': data = request(f'{git_url}/pluto.json')
        elif ch_name == 'indianlive': data = request(f'{git_url}/indian_live.json')
        elif ch_name == 'daddy': list_data = ch_dl()
        elif ch_name == 'theapp': list_data = ch_tvapp()
        if ch_name not in ('daddy', 'theapp', 'plex'): list_data = eval(str(data)) # loads(data)
        if list_data: main_cache.set(cache_name, list_data, expiration=168) # 7days
    # logger(f'from cache list_data: {list_data}')
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_external = external()
    if list_data:
        add_items(handle, list(get_list_item(list_data, ch_name)))
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.episodes', 'episodes', is_external)
    else:
        notification(f'No links Found for: :{ch_name} Retry')
        end_directory(handle)
        return


def play(params):
    # logger(f'play params {params}')
    url = params['url']
    try:
        direct_player = False
        if params['provider'] == 'daddy':
            ourl = relv_daddy(url)
            if ourl: return set_resolvedurl(ourl, params['title'])
        elif params['provider'] == 'theapp': ourl = relv_theapp(url)
        elif params['provider'] == 'youtube': ourl = get_m3u8_url(url)
        elif params['provider'] == 'pluto' and 'm3u8' in url: ourl = f'{url}|User-Agent={agent()}&Referer={url}'
        elif params['provider'] == 'crick_live': ourl = url
        else: ourl = f'{url}|User-Agent={agent()}'
        if ourl is None:
            logger(f'--- Playing url: {ourl} \nparams: {params}')
            return notification(f'No links Found for: :{params["title"]} Retry')
        kodi_player(ourl, params['title'], direct_player)
    except:
        logger(f'play provider: {params} - Exception: {print_exc()}')
        return


def get_videoId(from_func, response):
    vars_ = re.compile(r'var ytInitialData =.*?[\'|"|{](.+)[\'|"|}][,;]</script>').findall(response)
    # logger(f'vars_>>> : {vars_}')
    ytInitialData = str(vars_[0])
    # logger(f'ytInitialData: {ytInitialData}')
    # logger(f'ytInitialData: {string_escape(vars_[0])}')
    return re.findall(r'(compactvideoRenderer|videoRenderer)\":\{\"videoId\":\"(.+?)\",', ytInitialData, re.IGNORECASE,)


def get_m3u8_url(url):
    # logger(f'get_m3u8_url url: {url}')
    furl = None
    if 'https://www.youtube.com/channel' in url: response = request(url)
    else: response = request(f'{url}/videos')
    # logger(response)
    videoIds = get_videoId('get_m3u8_url', response)
    videoId_counter = 0
    for videoId in videoIds:
        furl = None
        videoId_counter += 1
        live_yturl = f'https://www.youtube.com/watch?v={videoId[1]}'
        # logger(f'live_yturl: {live_yturl}')
        response = request(live_yturl)
        # logger(f'<<<--->>> \n{response}\n<<<--->>>')
        if '.m3u8' in response:
            # logger(f'get_m3u8_url response: {response}')
            if furl := extract_m3u8(response): break
    logger(f'Total videoId: {len(videoIds)} get link from videoId_counter: {videoId_counter} from: {url}')
    return furl


def extract_m3u8(response, m3u8_extension='.m3u8', https_prefix='https://', tuner_increment=5, initial_tuner=200):
    end = response.find(m3u8_extension)
    if end == -1: raise ValueError('No .m3u8 found in the response')
    end += len(m3u8_extension)
    tuner = initial_tuner
    # logger(f'extract_m3u8 tuner: {tuner} end: {end}')

    while True:
        # logger(f'extract_m3u8 response[{end - tuner}: {end}]')
        potential_link = response[end - tuner: end]
        if https_prefix in potential_link:
            link = potential_link
            start = link.find(https_prefix)
            end = link.find(m3u8_extension) + len(m3u8_extension)
            break
        else: tuner += tuner_increment
    logger(f'extract_m3u8 length of links: {len(link[start: end])}')
    # logger(f'extract_m3u8  type: {type(link)} length of links: {len(link[start: end])}  : repr {repr(link)} : {link[start: end]}')
    return link[start: end]


def get_ltv_link(resp):
    links = regex_pattern.findall(resp)
    # logger(f'play provider links: {links}\nresp: {resp}')
    links = [x for x in links if '.m3u8' in x]
    if not links:
        links = regex_pattern1.findall(resp)
        # logger(f'play provider links3: {links}')
        links = [base64.b64decode(links[0]).decode('utf-8')]
    # logger(f'play provider links4: {links}')
    links = [x for x in links if '.m3u8' in x]
    if not links:
        link = base64.b64decode(unhunt(resp))
        iurl = link.decode('utf-8', errors='ignore')
        iurl = str(iurl).split('https')
        # logger(f'play provider iurl: {iurl}') # ['ޝ\x1dyԨ\x1e', '://webhdrunns.mizhls.ru/lb/premium347/index.m3u8']
        links = [f'https{iurl[1]}']
        # logger(f'play provider links: {repr(links)}') # 'https://webhdrunns.mizhls.ru/lb/premium347/index.m3u8'

    if not links: return
    links = [x for x in links if '.m3u8' in x]
    links = list(set(links))
    if len(links) > 1:
        list_items = [{'line1': f'url:  {i}'} for i in links]
        kwargs = {'items': dumps(list_items), 'heading': 'Select source to play.', 'narrow_window': 'true'}
        return select_dialog(links, **kwargs)
    elif len(links) > 0: return links[0]


def ch_dl():
    url = f'{ddurl}/24-7-channels.php'
    do_adult = False  #xbmcaddon.Addon().getSetting('adult_pw')
    hea = {'Referer': f'{ddurl}/', 'User-Agent': UA}
    resp = request(url, headers=hea)
    # logger(f'resp: {resp}')
    ch_block = re.compile('<center><h1(.+?)tab-2', re.MULTILINE | re.DOTALL).findall(str(resp))
    chan_data = re.compile('href=\"(.*)\" target(.*)<strong>(.*)</strong>').findall(str(ch_block[0]))
    # logger(f'chan_data: {chan_data}')
    ch_list = []
    for item in chan_data:
        try:
            url, title = str(item[0]), str(item[2])
            if any(x in title for x in chnnel_filter): continue
            # logger(f'item: {repr(item)}')
            url_params = {'title': title, 'url': url}
            if "18+" not in title: ch_list.append(url_params)
            if do_adult and "18+" in title: ch_list.append(url_params)
        except: logger(f'item: {repr(item)} error: {print_exc()}')
    # logger(f'ch_list: {ch_list}')
    return ch_list


def relv_daddy(link):
    def get_currenturl(link, streamid):
        import requests
        UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
        url = f'{ddurl}{link}'
        hea = {'Referer': f'{ddurl}/', 'User-Agent': UA}
        resp = requests.post(url, headers=hea).text
        urla = re.compile('iframe src="(.*?)"').findall(resp)[0]
        hea = {'Referer': url, 'User-Agent': UA, }
        # logger(f'play provider urla: {urla}')
        resp = requests.post(urla, headers=hea, timeout=10).text
        # logger(f'play provider resp: {resp}')
        urlb = get_ltv_link(resp)
        if not urlb: return
        parsed_url = urlparse(urla)
        referer = f'{parsed_url.scheme}://{(parsed_url.netloc or parsed_url.path)}'
        referer = quote_plus(referer)
        # urla = urla.replace('id='+ch_id, 'id={}')
        # urlb = urlb.replace(streamid+'/index', '{}/index')
        return f'{urlb}|Referer={referer}/&Origin={referer}&Keep-Alive=true&User-Agent={quote_plus(UA)}'
    cache_name = f'content_ddurls'
    streamid = link.split('stream-')[1].replace('.php', '') # re.findall(r'.*?(\d+)\.php', link)[0]
    ddurls = get_currenturl(link, streamid)
    logger(f'relv_daddy for link: {link} streamid: {streamid} from cache ddurls: {ddurls}')
    return ddurls
    # ddurls = main_cache.get(cache_name)
    # if not ddurls:
        # ddurls = cache_object(get_currenturl, cache_name, [link, streamid], False, 4)
        # logger(f'relv_daddy just cache ddurls: {ddurls}')
    # return ddurls.format(streamid[0])


def ch_tvapp():
    url = f'{tvappurl}/tv'
    hea = {'User-Agent': UA, }
    resp = request(url, headers=hea, verify=False)
    # logger(f'resp: {resp}')
    html = parseDOM(resp, 'ol', attrs={'class': "list.*?"})[0]#.replace('<span>', '').replace('</span>', '').replace('\n', '').replace('  ', '').replace('@', ' @')
    chan_data = re.findall('href\s*=\s*"([^"]+)"\s*class.*?>([^<]+)<\/a>', html, re.DOTALL)

    ch_list = []
    for url, title in chan_data:
        try:
            url = url[:-1] if url.endswith('/') else url
            url = url.replace('/tv/', '')
            # href = f'https://thetvapp.to{url}' if url.startswith('/') else url
            if any(x in title for x in chnnel_filter): continue
            # logger(f'item: {repr(item)}')
            url_params = {'title': title.replace('&amp;', '&'), 'url': url}
            ch_list.append(url_params)
        except: logger(f'chan_data: {repr(chan_data)} error: {print_exc()}')
    # logger(f'ch_list: {ch_list}')
    return ch_list


def relv_theapp(id_):
    stream_url = ''
    header.update({'Origin': 'https://thetvapp.to', 'Referer': 'https://thetvapp.to/',})
    response = get_page_server(f'{tvappurl}/tv/{id_}/', '#loadVideoBtnOne', 'thetvapp')
    # logger(f'response: {repr(response)}')
    if not response:
        response = get_page_server(f'{tvappurl}/tv/{id_}/', '.col-lg-8', 'thetvapp')
    if 'source' in response:
        link = eval(response)
        if link: return f'{link["source"]}|{urlencode(header)}'
    return stream_url




def geetm_root(params):
    cache_name = 'content_geetmala'
    list_data = main_cache.get(cache_name)
    # logger(f'from cache list_data: {list_data}')
    if not list_data:
        uri = f'{get_git_url()}/geetmala.json'
        data = request(uri)
        list_data = eval(str(data))
        # list_data = json.loads(data)
        # logger(f'new list_data: {list_data}')
        if list_data: main_cache.set(cache_name, list_data, expiration=168) # 7days

    from sys import argv  # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_external = external()
    add_items(handle, list(get_list_item(list_data, 'youtube_r', True)))
    set_content(handle, 'tvshows')
    set_category(handle, 'tvshows')
    end_directory(handle, cacheToDisc=not is_external)
    set_view_mode('view.tvshows', 'tvshows', is_external)


def get_song_list(params):
    ourl = params['url']
    rescrape = params.get('rescrape', 'false')
    if ourl.endswith('value=') or ourl == 'YouTube':
        search_text = get_SearchQuery('Hindi Geetmala')
        ourl += quote_plus(search_text)

    cache_name = f'content_{urlencode(params)}'
    song_list = None
    if rescrape == 'true': main_cache.delete(cache_name)
    else: song_list = main_cache.get(cache_name)
    if not song_list:
        if ourl.startswith('YouTube'):
            song_list = Movie_search().search(search_text, [])
        else: song_list = make_song_list(params)
        if song_list:
            main_cache.set(cache_name, song_list, expiration=24)  # 1 days cache

    # logger(f'get_song_list item_list: {list(_process())}')
    from sys import argv  # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_external = external()
    if ourl.startswith('YouTube'):
        add_items(handle, list(get_list_item(song_list, 'youtube')))
        set_content(handle, 'videos')
        set_category(handle, 'videos')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.videos', 'videos', is_external)
    else:
        add_items(handle, list(get_list_item(song_list, 'youtube', True)))
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.episodes', 'episodes', is_external)


def get_SearchQuery(sitename):
    import xbmc
    keyboard = xbmc.Keyboard()
    keyboard.setHeading(f'Search {sitename}')
    keyboard.doModal()
    return keyboard.getText() if keyboard.isConfirmed() else ''


def make_song_list(params):
    url, rtitle, pg_no = params['url'], params.get('title', ''), params.get('pg_no', '1')
    base_link = 'https://www.hindigeetmala.net'
    find_data = re.compile('itemprop="name">(.+?)</span>')
    song_perpage = 25
    songs = []
    nextpg = True
    while len(songs) < song_perpage and nextpg:
        song_page = request(url)
        result = parseDOM(song_page, 'tr', attrs={'itemprop': 'track'})
        for item in result:
            try:
                title = parseDOM(item, 'span', attrs={'itemprop': 'name'})[0]
                vid_url = parseDOM(item, 'a', ret='href')[0]
                img = parseDOM(item, 'img', ret='src')[0]
                try:
                    album = parseDOM(item, 'span', attrs={'itemprop': 'inAlbum'})[0]
                    m_name = find_data.findall(album)[0]
                    m_year = re.findall(r'\(.+?\)', album, re.MULTILINE)
                    m_year = m_year[0].replace('(', '').replace(')', '') if m_year else ''
                    album = f'{m_name} - {m_year}'
                except: album = ''
                try:
                    artist = parseDOM(item, 'span', attrs={'itemprop': 'byArtist'})[0]
                    artist = find_data.findall(artist)[0]
                except: artist = ''
                songs.append({'title': title, 'pg_no': pg_no, 'mode': 'geetm_vid_list', 'album': album, 'plot': f'album: {album}\nArtist: {artist}', 'url': base_link + vid_url, 'poster': base_link + img, 'isfolder': True})
            except: pass
        if nextpg:
            # logger(f'get_yt_vid_links pg_no {type(pg_no)} {repr(pg_no)}')
            pg_no = int(pg_no) + 1
            if '?page=' not in url: url += f'?page={pg_no}'
            else:
                url = url.split('=')[0]
                url += f'={pg_no}'
        else: nextpg = False

    if nextpg:
        xname = re.sub('Next Page: \d{1,2}', '', rtitle)
        title = f'{xname} Next Page: {pg_no}'
        next_pg_dict = {'title': title, 'pg_no': str(pg_no), 'mode': 'geetm_list', 'plot': 'Go To Next Page....', 'url': url, 'poster': nextpage, 'isfolder': True}
        songs.append(next_pg_dict)
    # logger('totle from url: %s pg_no: %s song: %s \n %s' % (params['url'], pg_no, len(songs), songs))
    return songs


def get_yt_vid_links(params):
    # logger(f'get_yt_vid_links params {params}')
    title, url, album, thumb = params.get('title'), params.get('url'), params.get('album'), params.get('poster')
    vid_page = request(url)
    # logger(f'search vid_page {vid_page}')
    result = parseDOM(vid_page, 'table', attrs={'class': 'b1 w760 alcen'})
    result += parseDOM(vid_page, 'table', attrs={'class': 'b1 allef w100p'})
    choices = []
    # logger(f'result: {result}')
    choice_param = {'title': f'Song : {title}', 'mode': 'geetm_plvid', 'poster': thumb, }
    try:
        link = parseDOM(result, 'iframe', ret='src')[0]
        if 'youtube.com/embed' in link:
            if v_id := link.replace('https://www.youtube.com/embed/', '').strip():
                v_link = f'{play_youtube_url}={v_id}'
                choices.append(dict(choice_param, **{'url': v_link}))
    except:
        for item in result:
            if r := re.findall(r'''<lite-youtube.+?videoid="([^"]+)''', item, re.DOTALL):
                choices.append(dict(choice_param, **{'url': f'{play_youtube_url}={r[0]}'}))
        song_item = parseDOM(vid_page, 'div', attrs={'class': 'yt_nt'})
        # logger(f'song_item: {song_item}')
        results = parseDOM(song_item, 'a', attrs={'class': 'yt_nt'})
        # logger(f'results: {results}')
        for item in results:
            if v_id := item.replace('https://www.youtube.com/watch?v=', '').strip():
                v_link = f'{play_youtube_url}={v_id}'
                choices.append(dict(choice_param, **{'url': v_link}))

    links = parseDOM(result, 'tr')
    find_data = re.compile('<td>(.+?)</td>')
    found_movie = False
    for link in links:
        # logger(f'from Movie link: \n{link}\n>>>>>\n')
        td_data = find_data.findall(link)
        try:
            if 'Watch Full Movie:' in td_data[0]:
                movie_link = parseDOM(td_data[1], 'a', ret='href')
                # logger(f'movie links: {movie_link}')
                for link_item in movie_link:
                    v_id = link_item.replace('https://www.youtube.com/watch?v=', '').strip()
                    if v_link := f'{play_youtube_url}={v_id}':
                        found_movie = True
                        choices.append(dict(choice_param, **{'url': v_link, 'title': f'Movie: {album}'}))
        except: pass
    if not found_movie: choices = Movie_search().search(album, choices)
    return choices


def get_yt_links(params):
    string = f'content_geetm_yt_links_{urlencode(params)}'
    choices = main_cache.get(string)
    if not choices or params.get('rescrap') == 'true':
        # logger(f'get_yt_links url: {url}\ntitle: {title}\nAlbum: {album}')
        choices = get_yt_vid_links(params)
        if choices: main_cache.set(string, choices, expiration=24) # 1 day

    # logger(f'rescrap: {rescrap} choices {choices}')
    from sys import argv
    handle = int(argv[1])
    is_external = external()
    add_items(handle, list(get_list_item(choices, 'youtube')))
    set_content(handle, 'videos')
    set_category(handle, 'videos')
    end_directory(handle, cacheToDisc=not is_external)
    set_view_mode('view.videos', 'videos', is_external)


class Movie_search:
    def __init__(self):
        self.key = 'AIzaSyCjf8izIeXa1oFZo7_HeL0WgrOq1WF_I1k'
        self.search_link = f'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=15&q=%s&key={self.key}'

    def search(self, title, choices):
        try:
            query = f'{title} full|Full movie|Movie'
            query_url = self.search_link % quote_plus(query)
            # logger(f'query: {query}')
            # query_url += '&relevanceLanguage=en'
            headers = {'Accept': 'application/json'}
            response = requests.get(query_url, headers=headers).json()
            # logger(f'search json response {response}')
            if error := response.get('error', []):
                message = error.get('message', [])
                logger(f'message: {message}')
                return None

            json_items = response.get('items', [])
            # logger(f'search json_items {json_items} json_items {to_utf8(json_items)}')
            for search_result in json_items:
                try:
                    query = title.split('-')[0].lower().replace('.', '')
                    item_title = normalize(search_result['snippet']['title'].replace('.', ''))
                    if re.search('Full Movie|Movie', item_title, re.I) and re.search(query, item_title, re.I) and search_result['id']['kind'] == 'youtube#video':
                        vid_id = search_result['id']['videoId']
                        payload = {'id': vid_id, 'part': 'contentDetails', 'key': self.key}
                        url = f'https://www.googleapis.com/youtube/v3/videos/?&{urlencode(payload)}'
                        resp_dict = requests.get(url, headers=headers).json()
                        # resp_dict = self.session.get('https://www.googleapis.com/youtube/v3/videos', params=payload).json()
                        dur = resp_dict['items'][0]['contentDetails']['duration']
                        duration = convert_youtube_duration_to_minutes(dur)
                        # logger(f'dur: {dur} duration: {duration}')
                        if duration > 70:
                            v_link = f'{play_youtube_url}={vid_id}'
                            # logger(f'item_title: {item_title} v_link: {v_link}')
                            choices.append({'title': f'Movie: ({duration} minutes) {item_title}', 'mode': 'geetm_plvid', 'url': v_link})
                except: logger(f'Error: {print_exc()}')
        except: logger(f'Error: {print_exc()}')
        # logger(f'choices: {choices}')
        return choices