# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcvfs, xbmcaddon
import sys
import json
import random
import requests
import _strptime
from os import path as osPath, walk
from threading import Thread, activeCount
from urllib.parse import unquote, unquote_plus, urlencode, quote, parse_qsl, urlparse, quote_plus
from modules import icons
from traceback import print_exc
resolve = xbmcplugin.setResolvedUrl

try: xbmc_actor = xbmc.Actor
except: xbmc_actor = None
addon_object = xbmcaddon.Addon('plugin.video.infinite')
player, xbmc_player, numeric_input, xbmc_monitor, translatePath = xbmc.Player(), xbmc.Player, 1, xbmc.Monitor, xbmcvfs.translatePath
ListItem, getSkinDir, log, getCurrentWindowId, Window = xbmcgui.ListItem, xbmc.getSkinDir, xbmc.log, xbmcgui.getCurrentWindowId, xbmcgui.Window
File, exists, copy, delete, rmdir, rename = xbmcvfs.File, xbmcvfs.exists, xbmcvfs.copy, xbmcvfs.delete, xbmcvfs.rmdir, xbmcvfs.rename
get_infolabel, get_visibility, execute_JSON, window_xml_dialog = xbmc.getInfoLabel, xbmc.getCondVisibility, xbmc.executeJSONRPC, xbmcgui.WindowXMLDialog
executebuiltin, xbmc_sleep, convertLanguage, getSupportedMedia, PlayList = xbmc.executebuiltin, xbmc.sleep, xbmc.convertLanguage, xbmc.getSupportedMedia, xbmc.PlayList
monitor, window, dialog, progressDialog, progressDialogBG = xbmc_monitor(), Window(10000), xbmcgui.Dialog(), xbmcgui.DialogProgress(), xbmcgui.DialogProgressBG()
endOfDirectory, addSortMethod, listdir, mkdir, mkdirs = xbmcplugin.endOfDirectory, xbmcplugin.addSortMethod, xbmcvfs.listdir, xbmcvfs.mkdir, xbmcvfs.mkdirs
addDirectoryItem, addDirectoryItems, setContent, setCategory = xbmcplugin.addDirectoryItem, xbmcplugin.addDirectoryItems, xbmcplugin.setContent, xbmcplugin.setPluginCategory
try: from xbmc import VideoStreamDetail, AudioStreamDetail, SubtitleStreamDetail
except: VideoStreamDetail, AudioStreamDetail, SubtitleStreamDetail = {}, {}, {}
opensettings_params = {'mode': 'open_settings', 'query': '0.0'}
path_join = osPath.join
addon_info = addon_object.getAddonInfo
addon_path = addon_info('path')
userdata_path = translatePath(addon_info('profile'))
addon_icon = translatePath(addon_info('icon'))
default_addon_fanart = translatePath(addon_info('fanart'))
img_url = 'https://i.imgur.com/%s.png'
invoker_switch_dict = {'true': 'false', 'false': 'true'}
empty_poster, nextpage = img_url % icons.box_office, img_url % icons.nextpage
nextpage_landscape = img_url % icons.nextpage_landscape
item_jump, item_jump_landscape = img_url % icons.item_jump, img_url % icons.item_jump_landscape
tmdb_default_api = 'b370b60447737762ca38457bd77579b3'
trakt_default_id = '1038ef327e86e7f6d39d80d2eb5479bff66dd8394e813c5e0e387af0f84d89fb'
trakt_default_secret = '8d27a92e1d17334dae4a0590083a4f26401cb8f721f477a79fd3f218f8534fd1'
int_window_prop, pause_services_prop, firstrun_update_prop = 'infinite.internal_results.%s', 'infinite.pause_services', 'infinite.firstrun_update'
current_skin_prop, current_font_prop = 'infinite.current_skin', 'infinite.current_font'
myvideos_db_paths = {20: '121', 21: '132'}
sort_method_dict = {'episodes': 24, 'files': 5, 'label': 2, 'none': 0}
playlist_type_dict = {'music': 0, 'video': 1}
tmdb_dict_removals = ('adult', 'backdrop_path', 'genre_ids', 'original_language', 'original_title', 'overview', 'popularity', 'vote_count', 'video', 'origin_country', 'original_name')
with_media_removals = ('description', 'privacy', 'type', 'share_link', 'display_numbers', 'allow_comments', 'sort_by', 'sort_how', 'created_at', 'updated_at', 'comment_count', 'likes')
single_ep_list = ('episode.progress', 'episode.recently_watched', 'episode.next_trakt', 'episode.next_fenlight', 'episode.trakt_recently_aired', 'episode.trakt_calendar')
scraper_names = ['EXTERNAL SCRAPERS' 'FOLDERS 1-5']
extras_button_label_values = {
				'movie':
					{'movies_play': 'Playback', 'show_trailers': 'Trailer', 'show_images': 'Images',  'show_extrainfo': 'Extra Info', 'show_genres': 'Genres',
					'show_director': 'Director', 'show_options': 'Options', 'show_recommended': 'Recommended', 'show_more_like_this': 'More Like This',
					'show_trakt_manager': 'Trakt Manager', 'playback_choice': 'Playback Options', 'show_favorites_manager': 'Favorites Manager', 'show_plot': 'Plot',
					'show_keywords': 'Keywords', 'show_in_trakt_lists': 'In Trakt Lists'},
				'tvshow':
					{'tvshow_browse': 'Browse', 'show_trailers': 'Trailer', 'show_images': 'Images', 'show_extrainfo': 'Extra Info', 'show_genres': 'Genres',
					'play_nextep': 'Play Next', 'show_options': 'Options', 'show_recommended': 'Recommended', 'show_more_like_this': 'More Like This',
					'show_trakt_manager': 'Trakt Manager', 'play_random_episode': 'Play Random', 'show_favorites_manager': 'Favorites Manager', 'show_plot': 'Plot',
					'show_keywords': 'Keywords', 'show_in_trakt_lists': 'In Trakt Lists'}}
video_extensions = ('m4v', '3g2', '3gp', 'nsv', 'tp', 'ts', 'ty', 'pls', 'rm', 'rmvb', 'mpd', 'ifo', 'mov', 'qt', 'divx', 'xvid', 'bivx', 'vob', 'nrg', 'img', 'iso', 'udf', 'pva',
					'wmv', 'asf', 'asx', 'ogm', 'm2v', 'avi', 'bin', 'dat', 'mpg', 'mpeg', 'mp4', 'mkv', 'mk3d', 'avc', 'vp3', 'svq3', 'nuv', 'viv', 'dv', 'fli', 'flv', 'wpl',
					'xspf', 'vdr', 'dvr-ms', 'xsp', 'mts', 'm2t', 'm2ts', 'evo', 'ogv', 'sdp', 'avs', 'rec', 'url', 'pxml', 'vc1', 'h264', 'rcv', 'rss', 'mpls', 'mpl', 'webm',
					'bdmv', 'bdm', 'wtv', 'trp', 'f4v', 'pvr', 'disc')
image_extensions = ('jpg', 'jpeg', 'jpe', 'jif', 'jfif', 'jfi', 'bmp', 'dib', 'png', 'gif', 'webp', 'tiff', 'tif',
					'psd', 'raw', 'arw', 'cr2', 'nrw', 'k25', 'jp2', 'j2k', 'jpf', 'jpx', 'jpm', 'mj2')

def get_icon(image_name):
	return img_url % getattr(icons, image_name, 'I1JJhji')

def get_addon_fanart():
	return get_property('infinite.default_addon_fanart') or default_addon_fanart

def build_url(url_params):
	return f'plugin://plugin.video.infinite/?{urlencode(url_params)}'

def add_dir(url_params, list_name, handle, iconImage='folder', fanartImage=None, isFolder=True):
	fanart = fanartImage or get_addon_fanart()
	icon = get_icon(iconImage)
	url = build_url(url_params)
	listitem = make_listitem()
	listitem.setLabel(list_name)
	listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': fanart, 'banner': fanart})
	info_tag = listitem.getVideoInfoTag()
	info_tag.setPlot(' ')
	add_item(handle, url, listitem, isFolder)

def make_listitem():
	return ListItem(offscreen=True)

def add_item(handle, url, listitem, isFolder):
	addDirectoryItem(handle, url, listitem, isFolder)

def add_items(handle, item_list):
	addDirectoryItems(handle, item_list)

def set_content(handle, content):
	setContent(handle, content)

def set_category(handle, label):
	setCategory(handle, label)

def end_directory(handle, cacheToDisc=True):
	endOfDirectory(handle, cacheToDisc=cacheToDisc)

def set_view_mode(view_type, content='files', is_external=None):
	if not get_property('infinite.use_viewtypes') == 'true': return
	if is_external is None: is_external = external()
	if is_external: return
	view_id = get_property('infinite.%s' % view_type) or None
	if not view_id: return
	try:
		hold = 0
		sleep(100)
		while not container_content() == content:
			hold += 1
			if hold < 3000: sleep(1)
			else: return
		execute_builtin('Container.SetViewMode(%s)' % view_id)
	except: return

def remove_keys(dict_item, dict_removals):
	for k in dict_removals: dict_item.pop(k, None)
	return dict_item

def append_path(_path):
	sys.path.append(translatePath(_path))

def logger(heading, function=''):
	log(f'###Infinite###: {heading} {function}', 1)

def get_property(prop):
	return window.getProperty(prop)

def set_property(prop, value):
	return window.setProperty(prop, value)

def clear_property(prop):
	return window.clearProperty(prop)

def clear_all_properties():
	return window.clearProperties()

def addon(addon_id='plugin.video.infinite'):
	return xbmcaddon.Addon(id=addon_id)

def addon_installed(addon_id):
	return get_visibility(f'System.HasAddon({addon_id})')

def addon_enabled(addon_id):
	return get_visibility(f'System.AddonIsEnabled({addon_id})')

def container_content():
	return get_infolabel('Container.Content')

def set_sort_method(handle, method):
	addSortMethod(handle, sort_method_dict[method])

def make_session(url='https://'):
	session = requests.Session()
	retries = requests.adapters.Retry(total=3, backoff_factor=0.3, status_forcelist=(429, 500, 502, 503, 504, 520, 521, 522, 524, 530))
	session.mount(url, requests.adapters.HTTPAdapter(max_retries=retries, pool_maxsize=100))
	return session

def make_playlist(playlist_type='video'):
	return PlayList(playlist_type_dict[playlist_type])

def convert_language(lang):
	return convertLanguage(lang, 1)

def supported_media():
	return getSupportedMedia('video')

def path_exists(path):
	return exists(str(path))

def open_file(_file, mode='r'):
	return File(_file, mode)

def copy_file(source, destination):
	return copy(source, destination)

def delete_file(_file):
	try: delete(_file)
	except Exception as e:
		logger(f'delete_file error: {repr(e)}')
		from os import unlink, remove
		try:
			unlink(_file)
			remove(_file)
		except Exception as e: logger(f'2 delete_file error: {repr(e)}')

def delete_folder(_folder, force=False):
	rmdir(_folder, force)

def rename_file(old, new):
	rename(old, new)

def list_dirs(location):
	return listdir(location)

def make_directory(path):
	mkdir(path)

def make_directories(path):
	mkdirs(path)

def translate_path(path):
	return translatePath(path)

def sleep(time):
	return xbmc_sleep(time)

def execute_builtin(command, block=False):
	return executebuiltin(command, block)

def current_skin():
	return getSkinDir()

def get_window_id():
	return getCurrentWindowId()

def current_window_object():
	return Window(get_window_id())

def kodi_version():
	return int(get_infolabel('System.BuildVersion')[0:2])

def show_busy_dialog():
	return execute_builtin('ActivateWindow(busydialognocancel)')

def hide_busy_dialog():
	execute_builtin('Dialog.Close(busydialognocancel)')
	execute_builtin('Dialog.Close(busydialog)')

def close_dialog(dialog, block=False):
	execute_builtin(f'Dialog.Close({dialog},true)', block)

def close_all_dialog():
	execute_builtin('Dialog.Close(all,true)')

def run_addon(addon='plugin.video.infinite', block=False):
	return execute_builtin(f'RunAddon({addon})', block)

def external():
	return 'infinite' not in get_infolabel('Container.PluginName')

def home():
	return getCurrentWindowId() == 10000

def folder_path():
	return get_infolabel('Container.FolderPath')

def path_check(string):
	return string in folder_path()

def reload_skin():
	execute_builtin('ReloadSkin()')

def kodi_refresh():
	execute_builtin('UpdateLibrary(video,special://skin/foo)')

def run_plugin(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin(f'RunPlugin({params})', block)

def container_update(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin(f'Container.Update({params})', block)

def activate_window(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin(f'ActivateWindow(Videos,{params},return)', block)

def container_refresh():
	return execute_builtin('Container.Refresh')

def container_refresh_input(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin(f'Container.Refresh({params})', block)

def replace_window(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin(f'ReplaceWindow(Videos,{params})', block)

def disable_enable_addon(addon_name='plugin.video.infinite'):
	try:
		execute_JSON(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled', 'params': {'addonid': addon_name, 'enabled': False}}))
		execute_JSON(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled', 'params': {'addonid': addon_name, 'enabled': True}}))
	except: pass

def update_local_addons():
	execute_builtin('UpdateLocalAddons', True)
	sleep(2500)

def update_kodi_addons_db(addon_name='plugin.video.infinite'):
	import time
	import sqlite3 as database
	try:
		date = time.strftime('%Y-%m-%d %H:%M:%S')
		dbcon = database.connect(translate_path('special://database/Addons33.db'), timeout=40.0)
		dbcon.execute("INSERT OR REPLACE INTO installed (addonID, enabled, lastUpdated) VALUES (?, ?, ?)", (addon_name, 1, date))
		dbcon.close()
	except Exception as e: logger(f'error update_kodi_addons_db {str(e)}')

def get_jsonrpc(request):
	response = execute_JSON(json.dumps(request))
	result = json.loads(response)
	return result.get('result', None)

def jsonrpc_get_directory(directory, properties=['title', 'file', 'thumbnail']):
	command = {'jsonrpc': '2.0', 'id': 1, 'method': 'Files.GetDirectory', 'params': {'directory': directory, 'media': 'files', 'properties': properties}}
	try: results = [i for i in get_jsonrpc(command).get('files') if i['file'].startswith('plugin://') and i['filetype'] == 'directory']
	except: results = None
	return results

def jsonrpc_get_addons(_type, properties=['thumbnail', 'name']):
	command = {'jsonrpc': '2.0', 'method': 'Addons.GetAddons','params':{'type':_type, 'properties': properties}, 'id': '1'}
	results = get_jsonrpc(command).get('addons')
	return results

def jsonrpc_get_system_setting(setting_id, setting_value=''):
	command = {'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.GetSettingValue', 'params': {'setting': setting_id}}
	try: result = get_jsonrpc(command)['value']
	except: result = setting_value
	return result

def open_settings():
	from windows.base_window import open_window
	open_window(('windows.settings_manager', 'SettingsManager'), 'settings_manager.xml')

def external_scraper_settings():
	try:
		external = get_property('infinite.external_scraper.module')
		if external in ('empty_setting', ''): return
		execute_builtin('Addon.OpenSettings(%s)' % external)
	except: pass

def progress_dialog(heading='', icon=addon_icon):
	from windows.base_window import create_window
	progress_dialog = create_window(('windows.progress', 'Progress'), 'progress.xml', heading=heading, icon=icon)
	Thread(target=progress_dialog.run).start()
	return progress_dialog

def select_dialog(function_list, **kwargs):
	from windows.base_window import open_window
	selection = open_window(('windows.default_dialogs', 'Select'), 'select.xml', **kwargs)
	if selection in (None, []): return selection
	if kwargs.get('multi_choice', 'false') == 'true': return [function_list[i] for i in selection]
	return function_list[selection]

def confirm_dialog(heading='', text='Are you sure?', ok_label='OK', cancel_label='Cancel', default_control=11):
	from windows.base_window import open_window
	kwargs = {'heading': heading, 'text': text, 'ok_label': ok_label, 'cancel_label': cancel_label, 'default_control': default_control}
	return open_window(('windows.default_dialogs', 'Confirm'), 'confirm.xml', **kwargs)

def ok_dialog(heading='', text='No Results', ok_label='OK'):
	from windows.base_window import open_window
	kwargs = {'heading': heading, 'text': text, 'ok_label': ok_label}
	return open_window(('windows.default_dialogs', 'OK'), 'ok.xml', **kwargs)

def show_text(heading, text=None, file=None, font_size='small', kodi_log=False):
	from windows.base_window import open_window
	heading = heading.replace('[B]', '').replace('[/B]', '')
	if file:
		with open(file, encoding='utf-8', errors='ignore') as r: text = r.read() #with open(file, encoding='utf-8') as r: text = r.readlines()
	if kodi_log:
		confirm = confirm_dialog(text='Show Log Errors Only?', ok_label='Yes', cancel_label='No')
		if confirm is None: return
		if confirm:
			#text = [i for i in text if any(x in i.lower() for x in ('exception', 'error', '[test]'))]
			import re
			try:
				texts1 = re.compile('error(.*?)[\t ]*\r?\n[\t ]*', flags=re.DOTALL | re.IGNORECASE).findall(str(text))
				texts2 = re.compile('-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--', flags=re.DOTALL | re.IGNORECASE).findall(str(text))
				text = texts1 + texts2
				text = '\n'.join(text)
				# logger(f'texts1: {type(texts1)} {texts1} texts2: {type(texts2)} {texts2}  texts2:{type(text)} {text}')
				with open(file, 'w', encoding='utf-8', errors='ignore') as r: r.writelines(text)
			except: logger(f'error: {print_exc()}')
	return open_window(('windows.textviewer', 'TextViewer'), 'textviewer.xml', heading=heading, text=text, font_size=font_size)

def notification(line1, time=3000, icon=None, sound=False):
	icon = icon or addon_icon
	if 'error' in line1.lower():
		import inspect
		func = inspect.currentframe().f_back
		# allframs = inspect.getouterframes(inspect.currentframe())
		# logger(f'allframs: {allframs}')
		funcat = 'not found'
		if 'plugin.video.infinite' in func.f_code.co_filename:
			funcat = func.f_code.co_filename.split('plugin.video.infinite')[1]
		logger(f'line_number: {func.f_lineno} func name: {func.f_code.co_name} func file: {funcat}')
	dialog.notification('Infinite', line1, icon, time, sound)

def timeIt(func):
	import time
	fnc_name = func.__name__
	def wrap(*args, **kwargs):
		started_at = time.time()
		result = func(*args, **kwargs)
		logger(f'{__name__}.{fnc_name} {time.time() - started_at}')
		return result
	return wrap

def volume_checker():
	try:# 0% == -60db, 100% == 0db
		if get_property('infinite.playback.volumecheck_enabled') == 'false' or get_visibility('Player.Muted'): return
		from modules.utils import string_alphanum_to_num
		max_volume = min(int(get_property('infinite.playback.volumecheck_percent') or '50'), 100)
		if int(100 - (float(string_alphanum_to_num(get_infolabel('Player.Volume').split('.')[0]))/60)*100) > max_volume: execute_builtin('SetVolume(%d)' % max_volume)
	except: pass

def focus_index(index):
	current_window = current_window_object()
	focus_id = current_window.getFocusId()
	try: current_window.getControl(focus_id).selectItem(index)
	except: logger(f'focus_index Error: {print_exc()}')

def get_all_icon_vars(include_values=False):
	if include_values: return [(k, v) for k, v in vars(icons).items() if not k.startswith('__')]
	else: return [k for k, v in vars(icons).items() if not k.startswith('__')]

def toggle_language_invoker():
	from xml.dom.minidom import parse as mdParse
	close_all_dialog()
	addon_xml = translate_path('special://home/addons/plugin.video.infinite/addon.xml')
	root = mdParse(addon_xml)
	invoker_instance = root.getElementsByTagName('reuselanguageinvoker')[0].firstChild
	current_invoker_setting = invoker_instance.data
	new_value = invoker_switch_dict[current_invoker_setting]
	if not confirm_dialog(text='Turn [B]Reuse Langauage Invoker[/B] %s?' % ('On' if new_value == 'true' else 'Off')): return
	invoker_instance.data = new_value
	new_xml = str(root.toxml()).replace('<?xml version="1.0" ?>', '')
	with open(addon_xml, 'w', errors='ignore') as f: f.write(new_xml)
	execute_builtin('ActivateWindow(Home)', True)
	update_local_addons()
	disable_enable_addon()

def upload_logfile(params):
	log_files = [('Current Kodi Log', 'kodi.log'), ('Previous Kodi Log', 'kodi.old.log')]
	list_items = [{'line1': i[0]} for i in log_files]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Choose Which Log File to Upload', 'narrow_window': 'true'}
	log_file = select_dialog(log_files, **kwargs)
	if log_file is None: return
	log_name, log_file = log_file
	if not confirm_dialog(heading=log_name): return
	show_busy_dialog()
	url = 'https://paste.kodi.tv/'
	log_file = translate_path(f'special://logpath/{log_file}')
	if not path_exists(log_file): return ok_dialog(text='Error. Log Upload Failed')
	try:
		with open_file(log_file) as f: text = f.read()
		UserAgent = 'infinite %s' % addon_info('version')
		response = requests.post('%s%s' % (url, 'documents'), data=text.encode('utf-8', errors='ignore'), headers={'User-Agent': UserAgent}).json()
		user_code = response['key']
		if 'key' in response:
			try:
				from modules.utils import copy2clip
				copy2clip('%s%s' % (url, user_code))
			except: pass
			ok_dialog(text=f'{url}{user_code}' )
		else: ok_dialog(text='Error. Log Upload Failed')
	except: ok_dialog(text='Error. Log Upload Failed')
	hide_busy_dialog()

def fetch_kodi_imagecache(image):
	import sqlite3 as database
	result = None
	try:
		dbcon = database.connect(translate_path('special://database/Textures13.db'), timeout=40.0)
		dbcur = dbcon.cursor()
		dbcur.execute("SELECT cachedurl FROM texture WHERE url = ?", (image,))
		result = dbcur.fetchone()[0]
	except: pass
	return result

def get_video_database_path():
	database_path = translate_path('special://profile/Database/')
	def find(pattern, path):
		result = []
		for root, dirs, files in walk(path):
			for name in files:
				if 'MyVideos' in name and name.endswith('.db'):
					result.append(osPath.join(root, name))
		return result
	databasefile = find('MyVideos*.db', database_path)
	database_path_final = databasefile[0]
	return database_path_final


def infoTagger(infotag, meta=None):
	if not meta: return
	meta_get = meta.get
	for key, val in (
		('country', 'setCountries'),
		('director', 'setDirectors'),
		('duration', 'setDuration'),
		('genre', 'setGenres'),
		('imdbnumber', 'setIMDBNumber'),
		('mediatype', 'setMediaType'),
		('mpaa', 'setMpaa'),
		('original_title', 'setOriginalTitle'),
		('playcount', 'setPlaycount'),
		('plot', 'setPlot'),
		('premiered', 'setFirstAired' if 'episode' in meta else 'setPremiered'),
		('rating', 'setRating'),
		('studio', 'setStudios'),
		('tagline', 'setTagLine'),
		('title', 'setTitle'),
		('trailer', 'setTrailer'),
		('votes', 'setVotes'),
		('writer', 'setWriters'),
		('year', 'setYear'),
		# tvshow exclusive
		('air_date', 'setPremiered'),
		('aired', 'setFirstAired'),
		('episode', 'setEpisode'),
		('season', 'setSeason'),
		('status', 'setTvShowStatus'),
		('tvshowtitle', 'setTvShowTitle'),
		('ep_name', 'setTitle')
	):
		try:
			if not key in meta or not (arg := meta[key]): continue
			if   key in {'director', 'genre', 'studio', 'writer'}: arg = arg.split(', ')
			elif key in {'episode', 'season', 'year'}: arg = int(arg)
			func = getattr(infotag, val)
			func(arg)
		except: pass


def set_info(item, meta, setUniqueIDs=None, resumetime=''):
	try:
		if resumetime: resumetime = float(resumetime)
		meta_get = meta.get
		media_type = meta_get('mediatype') or meta_get('media_type')
		info_tag = item.getVideoInfoTag()
		info_tag.setMediaType(media_type)
		if setUniqueIDs: info_tag.setUniqueIDs(setUniqueIDs)
		info_tag.setPath(meta_get('path'))
		info_tag.setFilenameAndPath(meta_get('filenameandpath'))
		info_title = item.getLabel() if meta_get('title') == '' else meta_get('title')
		info_tag.setTitle(info_title)
		info_tag.setSortTitle(meta_get('sorttitle'))
		info_tag.setOriginalTitle(meta_get('originaltitle') or meta_get('original_title'))
		info_tag.setPlot(meta_get('plot'))
		info_tag.setPlotOutline(meta_get('plotoutline'))
		info_tag.setDateAdded(meta_get('dateadded'))
		info_tag.setPremiered(meta_get('premiered', '2024-1-1'))
		info_tag.setYear(convert_type(int, meta_get('year') or 2024))
		info_tag.setRating(convert_type(float, meta_get('rating') or 4.5))
		info_tag.setMpaa(meta_get('mpaa'))
		info_tag.setDuration(meta_get('duration', 1320))
		info_tag.setPlaycount(convert_type(int , meta_get('playcount') or 0))
		if isinstance(meta_get('votes'), str): meta_votes = str(meta_get('votes')).replace(',', '')
		else: meta_votes = meta_get('votes')
		if meta_votes: info_tag.setVotes(convert_type(int, meta_votes))
		info_tag.setLastPlayed(meta_get('lastplayed'))
		info_tag.setAlbum(meta_get('album'))
		info_tag.setTags(meta_get('tag', []))
		info_tag.setTagLine(meta_get('tagline'))
		try:
			info_tag.setGenres(meta_get('genre') or [])
			info_tag.setWriters(meta_get('writer') or [])
			info_tag.setDirectors(meta_get('director') or [])
			info_tag.setCountries(meta_get('country') or [])
			info_tag.setTrailer(meta_get('trailer') or '')
			info_tag.setStudios(meta_get('studio') or [])
		except: logger(f'set_info meta : {meta} error: {print_exc()}')
		info_tag.setIMDBNumber(meta_get('imdb_id'))
		if resumetime and meta_get('duration'): info_tag.setResumePoint(resumetime, meta_get('duration'))
		elif resumetime: info_tag.setResumePoint(resumetime)
		if media_type in ('tvshow', 'season', 'episode'):
			info_tag.setTvShowTitle(meta_get('tvshowtitle'))
			info_tag.setTvShowStatus(meta_get('status'))
		if media_type in ('episodes', 'episode'):
			info_tag.setEpisode(convert_type(int, meta_get('episode')))
			info_tag.setSeason(convert_type(int, meta_get('season')))
		try: info_tag.setCast([xbmc_actor(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in meta_get('cast', [])])
		except: info_tag.setCast([xbmc_actor(name=item, role='', thumbnail='') for item in meta_get('cast', [])])
	except: logger(f'set_info meta : {meta} error: {print_exc()}')
	return item

def convert_type(_type, _value):
	if _type == str and isinstance(_value, list): return ', '.join(list(_value))
	try: return _type(_value)
	except TypeError as Err: return _type()
	except Exception as Err: logger(f'convert_type error: {Err}')

def set_inputstream(url, litem, is_type='adaptive'):
	if is_type == 'adaptive':
		adaptive_plugin = translate_path('special://home/addons/inputstream.adaptive')
		if not path_exists(adaptive_plugin):
			try:
				execute_builtin('InstallAddon(script.module.inputstreamhelper)', True)
				execute_builtin('InstallAddon(inputstream.adaptive)', True)
			except: return litem
		litem.setProperty('inputstream', 'inputstream.adaptive')
		litem.setProperty('inputstream.adaptive.max_bandwidth', '100000000000')
		litem.setProperty('http-reconnect', 'true')
		# if '.m3u8' in url.lower(): litem.setMimeType('application/vnd.apple.mpegurl') #and inputstreamhelper.Helper('hls').check_inputstream():
		# elif '.ism' in url.lower(): litem.setMimeType('application/vnd.ms-sstr+xml')
		# elif '.mpd' in url.lower(): litem.setMimeType('application/dash+xml')
		if '|' in url: # and ('m3u8' in url.lower() or '.mpd' in url.lower()):
			url, strhdr = url.split('|')
			litem.setProperty('inputstream.adaptive.stream_headers', strhdr)
			# litem.setProperty('inputstream.adaptive.manifest_headers', strhdr)
		# litem.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
		# license_headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0', 'Content-Type': 'application/octet-stream', 'Origin': 'https://www.somesite.com'}
		# from urllib.parse import urlencode
		# license_config = {'license_server_url': 'https://license.server.com/licenserequest', 'headers': urlencode(license_headers), 'post_data': 'R{SSM}', 'response_data': 'R'}
		# litem.setProperty('inputstream.adaptive.license_key', '|'.join(license_config.values()))
	else: #if is_type == 'ffmpeg':
		ffmpeg_plugin = translate_path('special://home/addons/inputstream.ffmpegdirect')
		if not path_exists(ffmpeg_plugin):
			try: execute_builtin('InstallAddon(inputstream.ffmpegdirect)', True)
			except: return litem
		litem.setProperty('inputstream', 'inputstream.ffmpegdirect')
		litem.setMimeType('application/vnd.apple.mpegurl')
		litem.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
		# litem.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
		litem.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift')
	return litem

def kodi_player(url, channel='NO LABLE', direct_player=False):
	# logger(f'Common play:: channel: {channel} type(url): {type(url)} url: {url}')
	if direct_player:
		try:
			execute_builtin('PlayMedia(%s)' % url)
			hide_busy_dialog()
		except: logger(f'Common play:: {channel} Error {print_exc()}')
	else:
		from modules.player import infinitePlayer
		try: infinitePlayer().run(url, 'video', {'title': channel})
		except: logger(f'Common play:: {channel} Error {print_exc()}')

def set_resolvedurl(url, title='resolv'):
	from sys import argv
	handle = int(argv[1])
	play_item = xbmcgui.ListItem(path=url)
	info_tag = play_item.getVideoInfoTag()
	info_tag.setPath(url)
	info_tag.setTitle(title)
	resolve(handle, True, play_item)

def decorate_log_error(log_lines):
	import re
	text = ''
	for line in log_lines:
		if not any(re.findall(r'INFO|NOTICE', line)):
			line = line.replace('ERROR', '[COLOR red]ERROR[/COLOR]:').replace('WARNING', '[COLOR gold]WARNING[/COLOR]:')
		text += line
	return text

def get_list_item(list_data, provider='', isFolder=False):
	for item in list_data:
		get_item = item.get
		cm = []
		cm_append = cm.append
		# logger(f'lists _process item: {item}')
		title, poster, action, isfolder = get_item('title', get_item('name')) , get_item('poster', get_item('image', addon_icon)), get_item('mode', 'ltp_play'), get_item('isfolder') or isFolder
		if provider == 'watchonline': action = item.get('mode') or 'watchonline_s'
		elif provider == 'youtube_r': action = 'geetm_list'
		url_params = dict(item, **{'mode': action, 'title': title, 'poster': poster, 'imdb_id': title, 'provider': provider, 'rescrap': 'false', 'mediatype': 'episode', 'episode': 1, 'season': 1})
		url = build_url(url_params)
		if isfolder:
			rescrape_params = dict(url_params, **{'rescrap': 'true'})
			cm_append((f'Reload {title}', f'RunPlugin({build_url(rescrape_params)})'))
			cm_append(('Add to a Shortcut Folder', 'RunPlugin(%s)' % build_url({'mode': 'menu_editor.shortcut_folder_add_item', 'name': title, 'iconImage': poster})))
		cm_append(('Open Settings', f'RunPlugin({build_url(opensettings_params)})'))
		listitem = make_listitem()
		listitem.setLabel(title)
		listitem.addContextMenuItems(cm)
		listitem.setArt({'thumb': poster})
		listitem = set_info(listitem, url_params, {'imdb': str(title)})
		yield url, listitem, isfolder
	return

def open_external_settings(params):
	addon = params.get('addon')
	execute_builtin(f'Addon.OpenSettings({addon})')
	sleep(100)
	while get_visibility('Window.IsVisible(addonsettings)'): sleep(100)
	sleep(100)
	if 'resolveurl' in addon:
		execute_builtin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_cache)')
		sleep(200)
		notification('resolveurl reset cache', time=2000)
	elif 'openscrapers' in addon:
		force_trakt_update = sync_accounts()
		sleep(100)
		notification('sync accounts data', time=2000)
		if force_trakt_update:
			from apis.trakt_api import trakt_sync_activities
			trakt_sync_activities(force_update=True)
		execute_builtin('RunPlugin(plugin://script.module.openscrapers/?action=cleanSettings)')
		sleep(200)
		notification('openscrapers clean settings', time=2000)

def sync_accounts(silent=False):
	from openscrapers import get_creden
	from caches.settings_cache import get_setting, set_setting
	force_trakt_update = False
	all_acct = get_creden()
	try:
		trakt_acct = all_acct.get('trakt')
		if get_setting('infinite.trakt.token') != trakt_acct.get('token'):
			force_trakt_update = True
			set_setting('watched_indicators', '1')
			set_setting('trakt.user', trakt_acct.get('user'))
			set_setting('trakt.expires', trakt_acct.get('expires'))
			set_setting('trakt.refresh', trakt_acct.get('refresh'))
			set_setting('trakt.token', trakt_acct.get('token'))
		if get_setting('infinite.trakt.user') != trakt_acct.get('user'): set_setting('watched_indicators', '0')
	except: logger(f'Error: {print_exc()}')
	if not silent: notification('Settings Updated', time=1500)
	return force_trakt_update

def clear_sub():
	try:
		sub_formats = ('.srt', '.ssa', '.smi', '.sub', '.idx', '.nfo')
		subtitle_path = 'special://temp/%s'
		files = list_dirs(translate_path('special://temp/'))[1]
		for i in files:
			if i.startswith('infiniteSubs_') or i.endswith(sub_formats): delete_file(translate_path(subtitle_path % i))
		logger('Clear Subtitles Finished')
	except: logger(f'Clear Subtitles Finished Error: {print_exc}')

def update_metadb():
	try:
		from modules.downloader import runner
		from modules.settings import get_git_url
		custom_files_path = get_git_url()
		urls = ['/metacache.db?raw=true', '/skipintro.json?raw=true']
		# urls = ['/skipintro.json?raw=true']
		for url in urls:
			params = {'mode': 'downloader', 'action': 'hindi_file', 'name': 'metacache_test',
			'url': f'{custom_files_path}{url}', 'silent': True, 'media_type': 'file'}
			runner(params)
			notification('Files updated', time=2000)
	except:
		logger(f'Error: {print_exc()}')
		notification('Error', time=2000)
