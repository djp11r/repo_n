# -*- coding: utf-8 -*-
import re
import shutil
from zipfile import ZipFile
from caches.main_cache import main_cache
from modules.kodi_utils import requests, json, notification, sleep, delete_file, rename_file, quote, logger

user_agent = 'infinite v0.1'

class OpenSubtitlesAPI:
	def __init__(self):
		self.headers = {'User-Agent': user_agent}

	def search(self, query, imdb_id, language, season=None, episode=None):
		cache_name = f'opensubtitles_{imdb_id}_{language}'
		if season: cache_name += f'_{season}_{episode}'
		if cache := main_cache.get(cache_name): return cache
		url = f'https://rest.opensubtitles.org/search/imdbid-{imdb_id}/query-{quote(query)}{f"/season-{season}/episode-{episode}" if season else ""}/sublanguageid-{language}'
		response = self._get(url, retry=True)
		if not response: return logger(f'Error OpenSubtitlesAPI search url: {url}')
		response = json.loads(response.text)
		main_cache.set(cache_name, response, 48)
		return response

	def download(self, url, filepath, temp_zip, temp_path, final_path):
		result = self._get(url, stream=True, retry=True)
		with open(temp_zip, 'wb') as f: shutil.copyfileobj(result.raw, f)
		with ZipFile(temp_zip, 'r') as zip_file: zip_file.extractall(filepath)
		delete_file(temp_zip)
		rename_file(temp_path, final_path)
		with open(final_path, 'r', encoding='utf-8', errors='ignore') as sub_contents:
			file = sub_contents.read()
		ifile = self.cleanup_subtitles(file)
		if ifile:
			with open(final_path, mode='w', encoding='utf-8', errors='ignore') as f:
				f.write(ifile)
		return final_path

	def _get(self, url, stream=False, retry=False):
		response = requests.get(url, headers=self.headers, stream=stream)
		if '200' in str(response): return response
		elif '429' in str(response) and retry:
			notification('OpenSubtitles Rate Limited. Retrying in 10 secs..', 3500)
			sleep(10000)
			return self._get(url, stream)
		else: return

	def cleanup_subtitles(self, sub_contents):
		__url_regex = r'[a-z0-9][a-z0-9-]{0,5}[a-z0-9]\.[a-z0-9]{2,20}\.[a-z]{2,5}'
		fist_last_regex = '(Support us and become|to remove all ads|Watch any video online|Free Browser extension)'
		__credit_part_regex = r'(sync|synced|fix|fixed|corrected|corrections)'
		__credit_regex = __credit_part_regex + r' ?&? ?' + __credit_part_regex + r'? by'
		all_lines = sub_contents.split('\n')
		cleaned_lines = []
		buffer = []
		garbage = False

		if all_lines[0].strip() != '': all_lines.insert(0, '')
		if all_lines[-1].strip() != '': all_lines.append('')

		for line in all_lines:
			line = line.strip()
			if garbage and line != '': continue
			garbage = False
			line_contains_ad = (re.search(fist_last_regex, line, re.IGNORECASE) or re.search(__url_regex, line, re.IGNORECASE) or re.search(__credit_regex, line, re.IGNORECASE))

			if line_contains_ad:
				if not re.match(r'^\{\d+\}\{\d+\}', line):
					logger(f'(detected ad) {line.encode("ascii", errors="ignore")}')
					garbage = True
					buffer = []
				continue

			if line == '':
				if len(buffer) > 0:
					buffer.insert(0, '')
					cleaned_lines.extend(buffer)
					buffer = []
				continue
			buffer.append(line)
		return '\n'.join(cleaned_lines)