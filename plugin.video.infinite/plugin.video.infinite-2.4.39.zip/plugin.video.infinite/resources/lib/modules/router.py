# -*- coding: utf-8 -*-
from modules.kodi_utils import sys, parse_qsl
from modules.kodi_utils import logger

def routing():
	params = dict(parse_qsl(sys.argv[2].replace('?','')))
	_get = params.get
	# logger(f'routing params>>>> {params}')
	mode = _get('mode', 'navigator.main')
	# logger(f'routing mode>>>> {mode}')
	if 'navigator.' in mode:
		from indexers.navigator import Navigator
		exec('Navigator(params).%s()' % mode.split('.')[1])
	elif 'menu_editor' in mode:
		from modules.menu_editor import MenuEditor
		exec('MenuEditor(params).%s()' % mode.split('.')[1])
	elif 'discover.' in mode:
		if mode == 'discover.remove_from_history':
			from indexers.discover import remove_from_history
			params['silent'] = False
			remove_from_history(params)
		elif mode == 'discover.remove_all_history':
			from indexers.discover import remove_all_history
			params['silent'] = True
			remove_all_history(params)
		else:
			from indexers.discover import Discover
			exec('Discover(params).%s()' % mode.split('.')[1])
	elif 'furk.' in mode:
		if mode == 'furk.browse_packs':
			from modules.sources import Sources
			Sources().furkPacks(params['file_name'], params['file_id'])
		elif mode == 'furk.add_to_files':
			from indexers.furk import add_to_files
			add_to_files(params['item_id'])
		elif mode == 'furk.remove_from_files':
			from indexers.furk import remove_from_files
			remove_from_files(params['item_id'])
		elif mode == 'furk.remove_from_downloads':
			from indexers.furk import remove_from_downloads
			remove_from_downloads(params['item_id'])
		elif mode == 'furk.remove_from_files':
			from indexers.furk import add_uncached_file
			add_uncached_file(params['id'])
		elif mode == 'furk.myfiles_protect_unprotect':
			from indexers.furk import myfiles_protect_unprotect
			myfiles_protect_unprotect(params['action'], params['name'], params['item_id'])
		else:
			from indexers import furk
			exec('furk.%s(params)' % mode.split('.')[1])
	elif 'easynews.' in mode:
		from indexers import easynews
		exec('easynews.%s(params)' % mode.split('.')[1])
	elif '_play' in mode or 'play_' in mode:
		#logger('routing() mode: {} params: {}'.format(mode, params))
		if mode == 'play_media':
			from modules.sources import Sources
			Sources().playback_prep(params)
		# elif mode == 'play_display_results':
			# from modules.sources import Sources
			# Sources().display_results()
		# elif mode == 'play_file':
			# from modules.sources import Sources
			# Sources().play_file(params['title'], params['source'])
		elif mode == 'media_play':
			from modules.player import infinitePlayer
			infinitePlayer().run(_get('url', None), _get('media_type', None))
	elif 'choice' in mode:
		from indexers import dialogs
		if mode == 'scraper_color_choice': dialogs.scraper_color_choice(params['setting'])
		elif mode == 'scraper_dialog_color_choice': dialogs.scraper_dialog_color_choice(params['setting'])
		elif mode == 'scraper_quality_color_choice': dialogs.scraper_quality_color_choice(params['setting'])
		elif mode == 'imdb_images_choice': dialogs.imdb_images_choice(params['imdb_id'], params['rootname'])
		elif mode == 'set_quality_choice': dialogs.set_quality_choice(params['quality_setting'])
		elif mode == 'results_sorting_choice': dialogs.results_sorting_choice()
		elif mode == 'results_layout_choice': dialogs.results_layout_choice()
		elif mode == 'options_menu_choice': dialogs.options_menu(params)
		elif mode == 'meta_language_choice': dialogs.meta_language_choice()
		elif mode == 'extras_menu_choice': dialogs.extras_menu(params)
		elif mode == 'enable_scrapers_choice': dialogs.enable_scrapers_choice()
		elif mode == 'favorites_choice': dialogs.favorites_choice(params)
		elif mode == 'trakt_manager_choice': dialogs.trakt_manager_choice(params)
		elif mode == 'folder_scraper_manager_choice': dialogs.folder_scraper_manager_choice(params)
		elif mode == 'set_language_filter_choice': dialogs.set_language_filter_choice(params['filter_setting'])
		elif mode == 'media_extra_info_choice': dialogs.media_extra_info(params['media_type'], params['meta'])
		elif mode == 'extras_lists_choice': dialogs.extras_lists_choice()
		elif mode == 'random_choice': dialogs.random_choice(params)
		elif mode == 'highlight_choice': dialogs.highlight_choice()
	elif 'trakt.' in mode:
		if '.list' in mode:
			from indexers import trakt_lists
			exec('trakt_lists.%s(params)' % mode.split('.')[2])
		else:
			from apis import trakt_api
			exec('trakt_api.%s(params)' % mode.split('.')[1])
	elif 'build' in mode:
		if mode == 'build_movie_list':
			from indexers.movies import Movies
			Movies(params).fetch_list()
		elif mode == 'build_tvshow_list':
			from indexers.tvshows import TVShows
			TVShows(params).fetch_list()
		elif mode == 'build_season_list':
			from indexers.seasons import build_season_list
			build_season_list(params)
		elif mode == 'build_episode_list':
			from indexers.episodes import build_episode_list
			build_episode_list(params)
		elif mode == 'build_next_episode':
			from indexers.episodes import build_next_episode
			build_next_episode()
		elif mode == 'build_in_progress_episode':
			from indexers.episodes import build_in_progress_episode
			build_in_progress_episode()
		elif mode == 'build_recently_watched_episode':
			from indexers.episodes import build_recently_watched_episode
			build_recently_watched_episode()
		elif mode == 'build_my_calendar':
			from indexers.episodes import build_my_calendar
			build_my_calendar(params)
		elif mode == 'build_navigate_to_page':
			from modules.utils import build_navigate_to_page
			build_navigate_to_page(params)
		elif mode == 'build_next_episode_manager':
			from modules.episode_tools import build_next_episode_manager
			build_next_episode_manager()
		elif mode == 'imdb_build_user_lists':
			from indexers.imdb import imdb_build_user_lists
			imdb_build_user_lists(_get('media_type'))
		elif mode == 'build_popular_people':
			from indexers.people import popular_people
			popular_people()
		elif mode == 'imdb_build_keyword_results':
			from indexers.imdb import imdb_build_keyword_results
			imdb_build_keyword_results(params['media_type'], params['query'])
	elif 'favourites' in mode:
		from modules.favourites import Favourites
		exec('Favourites(params).%s()' % mode)
	elif 'watched_unwatched' in mode:
		if mode == 'mark_as_watched_unwatched_episode':
			from modules.watched_status import mark_as_watched_unwatched_episode
			mark_as_watched_unwatched_episode(params)
		elif mode == 'mark_as_watched_unwatched_season':
			from modules.watched_status import mark_as_watched_unwatched_season
			mark_as_watched_unwatched_season(params)
		elif mode == 'mark_as_watched_unwatched_tvshow':
			from modules.watched_status import mark_as_watched_unwatched_tvshow
			mark_as_watched_unwatched_tvshow(params)
		elif mode == 'mark_as_watched_unwatched_movie':
			from modules.watched_status import mark_as_watched_unwatched_movie
			mark_as_watched_unwatched_movie(params)
		elif mode == 'watched_unwatched_erase_bookmark':
			from modules.watched_status import erase_bookmark
			erase_bookmark(_get('media_type'), _get('tmdb_id'), _get('season', ''), _get('episode', ''), _get('refresh', 'false'))
	elif 'myaccounts' in mode:
		action = mode.split('.')[1]
		if action == 'open':
			from modules.kodi_utils import open_MyAccounts
			open_MyAccounts(params)
		else:
			from modules.kodi_utils import sync_MyAccounts
			sync_MyAccounts()
	elif 'history' in mode:
		if mode == 'search_history':
			from indexers.history import search_history
			search_history(params)
		elif mode == 'clear_search_history':
			from modules.history import clear_search_history
			clear_search_history()
		elif mode == 'remove_from_history':
			from modules.history import remove_from_search_history
			remove_from_search_history(params)
	elif 'real_debrid' in mode:
		if mode == 'real_debrid.rd_torrent_cloud':
			from indexers.real_debrid import rd_torrent_cloud
			rd_torrent_cloud()
		if mode == 'real_debrid.rd_downloads':
			from indexers.real_debrid import rd_downloads
			rd_downloads()
		elif mode == 'real_debrid.browse_rd_cloud':
			from indexers.real_debrid import browse_rd_cloud
			browse_rd_cloud(params['id'])
		elif mode == 'real_debrid.resolve_rd':
			from indexers.real_debrid import resolve_rd
			resolve_rd(params)
		elif mode == 'real_debrid.rd_account_info':
			from indexers.real_debrid import rd_account_info
			rd_account_info()
		elif mode == 'real_debrid.delete':
			from indexers.real_debrid import rd_delete
			rd_delete(_get('id'), _get('cache_type'))
		elif mode == 'real_debrid.authenticate':
			from apis.real_debrid_api import RealDebridAPI
			RealDebridAPI().auth()
		elif mode == 'real_debrid.revoke_authentication':
			from apis.real_debrid_api import RealDebridAPI
			RealDebridAPI().revoke()
	elif 'premiumize' in mode:
		if mode == 'premiumize.pm_torrent_cloud':
			from indexers.premiumize import pm_torrent_cloud
			pm_torrent_cloud(_get('id', None), _get('folder_name', None))
		elif mode == 'premiumize.pm_transfers':
			from indexers.premiumize import pm_transfers
			pm_transfers()
		elif mode == 'premiumize.pm_account_info':
			from indexers.premiumize import pm_account_info
			pm_account_info()
		elif mode == 'premiumize.rename':
			from indexers.premiumize import pm_rename
			pm_rename(_get('file_type'), _get('id'), _get('name'))
		elif mode == 'premiumize.delete':
			from indexers.premiumize import pm_delete
			pm_delete(_get('file_type'), _get('id'))
		elif mode == 'premiumize.authenticate':
			from apis.premiumize_api import PremiumizeAPI
			PremiumizeAPI().auth()
		elif mode == 'premiumize.revoke_authentication':
			from apis.premiumize_api import PremiumizeAPI
			PremiumizeAPI().revoke()
	elif 'alldebrid' in mode:
		if mode == 'alldebrid.ad_torrent_cloud':
			from indexers.alldebrid import ad_torrent_cloud
			ad_torrent_cloud(_get('id', None))
		elif mode == 'alldebrid.browse_ad_cloud':
			from indexers.alldebrid import browse_ad_cloud
			browse_ad_cloud(params['folder'])
		elif mode == 'alldebrid.resolve_ad':
			from indexers.alldebrid import resolve_ad
			resolve_ad(params)
		elif mode == 'alldebrid.ad_account_info':
			from indexers.alldebrid import ad_account_info
			ad_account_info()
		elif mode == 'alldebrid.authenticate':
			from apis.alldebrid_api import AllDebridAPI
			AllDebridAPI().auth()
		elif mode == 'alldebrid.revoke_authentication':
			from apis.alldebrid_api import AllDebridAPI
			AllDebridAPI().revoke()
	elif '_settings' in mode:
		if mode == 'open_settings':
			from modules.kodi_utils import open_settings
			open_settings(_get('query', '0.0'), _get('addon', 'plugin.video.infinite'))
		elif mode == 'clean_settings':
			from modules.kodi_utils import clean_settings
			clean_settings()
		elif mode == 'clear_settings_window_properties':
			from modules.kodi_utils import clear_settings_window_properties
			clear_settings_window_properties()
	elif '_cache' in mode:
		import caches
		if mode == 'clear_cache':
			caches.clear_cache(_get('cache'))
		elif mode == 'clear_all_cache':
			caches.clear_all_cache()
		elif mode == 'resolveurl_cacheclear':
			from modules.kodi_utils import clear_cache_resolveurl
			clear_cache_resolveurl()
	elif '_image' in mode:
		from indexers.images import Images
		Images().run(params)
	elif 'service_functions' in mode:
		from services import service_functions
		exec('service_functions.%s().run()' % mode.split('.')[1])
	elif '_text' in mode:
		if mode == 'show_text':
			from modules.kodi_utils import show_text
			show_text(_get('heading'), _get('text', None), _get('file', None), _get('font_size', 'small'), _get('kodi_log', 'false') == 'true')
		elif mode == 'show_text_media':
			from modules.kodi_utils import show_text_media
			show_text(_get('heading'), _get('text', None), _get('file', None), _get('meta'), {})
	elif '_view' in mode:
		from modules import kodi_utils
		if mode == 'choose_view':
			kodi_utils.choose_view(params['view_type'], _get('content', ''))
		elif mode == 'set_view':
			kodi_utils.set_view(params['view_type'])
	##EXTRA modes##
	elif mode == 'get_search_term':
		from modules.history import get_search_term
		get_search_term(params)
	elif mode == 'person_data_dialog':
		from indexers.people import person_data_dialog
		person_data_dialog(params)
	elif mode == 'downloader':
		from modules.downloader import runner
		runner(params)
	elif mode == 'clean_databases':
		from caches import clean_databases
		clean_databases()
	elif mode == 'manual_add_magnet_to_cloud':
		from modules.debrid import manual_add_magnet_to_cloud
		manual_add_magnet_to_cloud(params)
	elif mode == 'debrid.browse_packs':
		from modules.sources import Sources
		Sources().debridPacks(params['provider'], params['name'], params['magnet_url'], params['info_hash'])
	elif mode == 'upload_logfile':
		from modules.kodi_utils import upload_logfile
		upload_logfile()
	elif mode == 'toggle_language_invoker':
		from modules.kodi_utils import toggle_language_invoker
		toggle_language_invoker()
	elif mode == 'clean_databases':
		from caches import clean_databases
		clean_databases()
	elif mode == 'refresh_artwork':
		from modules.kodi_utils import refresh_artwork
		refresh_artwork()
	elif 'external_scrapers_' in mode:
		from modules import source_utils
		if mode == 'external_scrapers_toggle_all':
			source_utils.toggle_all(params.get('folder'), params.get('setting'))
		elif mode == 'external_scrapers_enable_disable_specific_all':
			source_utils.enable_disable_specific_all(params.get('folder'))
	elif mode == 'set_source_sorting':
		from indexers import dialogs
		dialogs.set_source_sorting(params['source_sorting_list'])
	# Context option Select or Rescrape Hindi episodes or Movies Sources
	elif '_select' in mode:
		from modules.source_utils import clear_and_rescrape
		if mode == 'scrape_select':
			# logger('vod_selectscrape params: {}'.format(params))
			clear_and_rescrape(params.get('content'), params['meta'], params.get('season', None), params.get('episode', None), params.get('c_type', None), False)
		elif mode == 'rescrape_select':
			clear_and_rescrape(params.get('content'), params['meta'], params.get('season', None), params.get('episode', None), params.get('c_type', None))
	# Scrape and play Hindi episodes or Movies Sources
	elif 'vod_prov_' in mode:
		#logger('routing() mode: {} params: {}'.format(mode, params))
		if mode == 'vod_prov_scape':
			from modules.hsources import hSources
			# if 'params' in params:
				# import json
				# params = json.loads(params['params'])
			# logger('### from hSources playback_prep>>>> \n{}'.format(params))
			hSources().playback_prep(params)
	# Scrape Indian Movies
	elif mode == 'vod_movies_list':
		from indexers.hindi.desirulez import movies
		# logger('### from vod_movies_list >>>> {}'.format(params))
		movies(params)
	# Scrape Hindi TV Shows
	elif 'vod_tv' in mode:
		if mode == 'vod_tvsh_dr':
			from indexers.hindi.desirulez import tv_shows
			# logger('### from vod_tvsh_dr >>>> {}'.format(params))
			tv_shows(params)
		elif mode == 'vod_tvepis_dr':
			from indexers.hindi.desirulez import tv_episo
			# logger('from vod_tvepis_dr :{}'.format(params))
			# tv_episo(params.get('url'), params.get('list_name'), params.get('ch_name'), params.get('pg_no'), params.get('meta', '[]'))
			tv_episo(params)
	elif 'geetm' in mode:
		if mode == 'geetm':
			from indexers.hindi.geetmala import geetm_root
			geetm_root(params)
		elif mode == 'geetm_list':
			from indexers.hindi.geetmala import get_song_list
			get_song_list(params)
		elif mode == 'geetm_vid_list':
			from indexers.hindi.geetmala import get_yt_links
			# logger('geetm_vid_list: {}'.format(params))
			get_yt_links(params)
		elif mode == 'geetm_plvid':
			from indexers.hindi.geetmala import play
			# logger('geetm_plvid: {}'.format(params))
			play(params.get('url'), params.get('title'))
	# Live TV
	elif 'livetv_' in mode:
		# logger('### from livetv_ params: {}'.format(params))
		if mode == 'livetv_ustvgo':
			from indexers.hindi.ustvgo import ustv_root
			ustv_root(params)
		elif mode == 'livetv_pluto':
			from indexers.hindi.lists import pluto
			pluto(params)
		elif mode == 'livetv_youtube_m3u':
			from indexers.hindi.lists import youtube_m3u
			youtube_m3u(params)
		elif mode == 'livetv_m3u':
			from indexers.hindi.lists import indian_live
			indian_live(params)
		elif mode == 'livetv_redjoyiptv':
			from indexers.hindi.lists import get_redjoyiptv_list
			get_redjoyiptv_list(params)
	elif 'watchonline_' in mode:
		if mode == 'watchonline_menu':
			from indexers.watchonline import root
			root()
		elif mode == 'watchonline_scrape_seasons':
			from indexers.watchonline import scrape_seasons
			scrape_seasons(params['url'])
		elif mode == 'watchonline_scrape_episodes':
			from indexers.watchonline import scrape_episodes
			scrape_episodes(params['url'])
		elif mode == 'watchonline_scrape_source':
			from indexers.watchonline import scrape_source
			scrape_source(params)
		elif mode == 'watchonline_ltp':
			# logger(f'watchonline_ltp params >>>> {params}')
			from indexers.watchonline import play
			play(params)
	elif 'distro_' in mode:
		if mode == 'distro_root':
			from indexers.hindi.distro import get_live_vod
			get_live_vod(params)
		elif mode == 'distro_get_items':
			if params.get('list_name') == "live":
				from indexers.hindi.distro import live_cats
				live_cats(params)
			else:
				if '**' in params.get('url'):
					from indexers.hindi.distro import distro_seasons
					distro_seasons(params)
				else:
					from indexers.hindi.distro import vod_cats
					vod_cats(params)
		elif mode == 'distro_pls':
			from indexers.hindi.distro import play
			play(params)
	elif 'ltp_' in mode:
		if mode == 'ltp_ustv':
			from indexers.hindi.ustvgo import play_old
			# logger('from defoult url >>>> {}'.format(params))
			play_old(params)
		elif mode == 'ltp_pluto':
			from indexers.hindi.lists import play
			# logger('from ltp_pluto url >>>> {}'.format(params['url']))
			play(params)
		elif mode == 'ltp_tubitv':
			from indexers.hindi.tubitv import play
			# logger('from ltp_tubitv url >>>> {}'.format(params))
			play(params)
	# tubi2
	elif 'tubitv' in mode:
		if mode == 'tubitv_main':
			from indexers.hindi.tubitv2 import Channels
			# logger(f'tubitv_main params>>>> {params}')
			Channels.section_list(params.get('rescrape'))
		elif "tubitv-content" in mode:
			from indexers.hindi.tubitv2 import Channels
			# logger(f'tubitv-content params>>>> {params}')
			Channels.content_list(mode)
		elif "tubitv-episodes" in mode:
			from indexers.hindi.tubitv2 import Channels
			# logger('tubitv Channels episode_list mode >>>> {}'.format(mode))
			Channels.episode_list(mode)
		elif "play-tubitv" in mode:
			from indexers.hindi.tubitv2 import Channels
			# logger('tubitv Channels play_tubi mode >>>> {}'.format(params))
			Channels.play_tubi(params)
		elif mode == "tubitv-search":
			from indexers.hindi.tubitv2 import Channels
			# logger('tubitv Channels search_tubi mode >>>> {}'.format(mode))
			Channels.search_tubi()

		# livetv_
		elif mode == 'tubitv_livemain':
			from indexers.hindi.tubitv2 import LiveChannels
			LiveChannels.channel_list()
		elif mode == 'tubitv_livesearch':
			from indexers.hindi.tubitv2 import LiveChannels
			LiveChannels.search_list()
		elif 'tubitv_liveget_channel' in mode:
			from indexers.hindi.tubitv2 import LiveChannels
			LiveChannels.get_channel(params)
	elif 'tubio' in mode:
		if mode == 'tubio':
			from indexers.hindi.tubitv import tubitv_root
			tubitv_root()
		elif mode == 'tubio_list':
			from indexers.hindi.tubitv import tubitv_categs
			# logger('### vod_tv_tubilist >>>> \n{}'.format(params))
			tubitv_categs(params)
		elif mode == 'tubio_tv':
			from indexers.hindi.tubitv import tubitv_shows
			# logger('### from geetmala >>>> \n{}'.format(params))
			tubitv_shows(params)
	# update_hindi_metadb
	elif mode == 'update_hindi_metadb':
		from modules.kodi_utils import update_hindi_metadb
		update_hindi_metadb()
	# for testing Mode
	elif 'testhindi' in mode:
		from indexers.hindi.testing_mod import testting
		testting()