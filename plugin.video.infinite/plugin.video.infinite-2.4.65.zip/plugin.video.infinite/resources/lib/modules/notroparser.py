# -*- coding: utf-8 -*-

import os
import re
from traceback import print_exc
from modules.kodi_utils import skipintro_db, json, logger


def clean_title(title):
    if title is None: return
    exctract_date = re.compile(r'(\d{1,2}[th|st|nd|rd]* [Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|August|Sep|September|Oct|October|Nov|November|Dec|December]* \d{2,4})')
    episode_data = re.compile(r'[Ee]pisode.+?(\d+)|[Ee]p (\d+)|[Ee](\d+)|[sS]eason.+?(\d+)|[sS]eason(\d+)|[sS](\d+)|[Cc]hapter (\d+)')
     # ansi_pattern = re.compile(r"(\x9B|\x1B\[)[0-?]*[ -\/]*[@-~]")
    ansi_pattern = re.compile(r'[^\x00-\x7f]')
    color_data = re.compile(r'\[COLOR.+?\].+?\[\/COLOR\]|\(.*?\)+')
    try:
        title = re.sub(color_data, '', title)  # remove date like [COLOR yellow]1x1[/COLOR] OR [COLOR cyan]July 10, 2017[/COLOR] or ( any thing( #)
        title = re.sub(exctract_date, '', title) # remove date like 18th April 2021
        title = re.sub(episode_data, '', title) # remove episod 12 or season 1 etc
        title = re.sub(ansi_pattern, '', title)  # remove ansi_pattern
        title = re.sub(r'&#(\d+);', '', title)
        title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
        title = title.replace('&quot;', '\"').replace('&amp;', '&')
        title = re.sub(r'([:;\-"\',!_.?~$@])', '', title) # remove all characters in bracket
        title = re.sub(r'\<[^>]*\>|\([^)]*\)', '', title) # remove like this <any thing> or (any thing)
        # title = re.sub(r'\([^>]*\)', '', title) # remove in bracket like (any thing) etcx
        # title = re.sub(r'\n|([[].+?[]])|([(].+?[)])|\s(vs|v[.])\s|(:|;|-|"|,|\'|\_|\.|\?)|\(|\)|\[|\]|\{|\}|\s', '', title).lower()
        # title = re.sub(r'\n|([\[({].+?[})\]])|([:;\-"\',!_.?~$@])|\s', '', title)
        title = re.sub(r"\s+", " ", title, flags=re.I) # Removing Multiple Spaces
    except: pass
    return title.strip()


def updateSkip(skip_option):
    logger(f'updateSkip skip_option: {skip_option}')
    with open(skipintro_db, mode='r', encoding='utf-8') as file:
        json_data = json.load(file)
    for item in json_data:
        if item['title'] == skip_option.get('title'):
            item['service'] = skip_option.get('service')
            item['skip'] = skip_option.get('skip')
            item['eskip'] = skip_option.get('eskip')
            item['start'] = skip_option.get('start')
    with open(skipintro_db, mode='w', encoding='utf-8') as file:
        json.dump(json_data, file)#, indent=2)


def newskip(title):
    try:
        with open(skipintro_db, mode='r', encoding='utf-8') as f:
            data = json.load(f)
    except: pass
    newIntro = {'title': title, 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '60'}
    data.append(newIntro)
    with open(skipintro_db, mode='w', encoding='utf-8') as f:
        json.dump(data, f)#, indent=2)
    return newIntro


def enable_show():
    with open(skipintro_db, mode='r', encoding='utf-8') as file:
        json_data = json.load(file)
    choices_list = []
    for item in json_data:
        if item['service'] == 'False':
            choices_list.append(item)
    # logger(f'len choice: {len(choices_list)} : {choices_list}')
    if len(choices_list) > 0:
        try:
            from xbmcgui import Dialog
            dialog = Dialog()
            choice = dialog.select("Select to Update.", ["%s" % i['title'] for i in choices_list], autoclose=4000)
            # logger(f'choice: {choice}')
            choice_option = choices_list[int(choice)]
            title = choices_list[int(choice)]['title']

            # logger(f'choice: type: {type(choice_option)} choice_option: {choice_option}')
            choice_option.update({'service': 'True'})
            logger(f'enable_show after upd: {choice_option}')
            updateSkip(choice_option)
        except: logger(f'Error: {print_exc()}')

def get_skip_option(title):
    title = clean_title(title)
    try:
        with open(skipintro_db, mode='r', encoding='utf-8') as f: data = json.load(f)
        start = [i for i in data if i['title'] == title][0]
    except: start = newskip(title)
    return start
