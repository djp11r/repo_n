# -*- coding: utf-8 -*-
import requests
from urllib3.util.retry import Retry
# from modules.kodi_utils import logger

def make_session(url='https://'):
	session = requests.Session()
	retries = Retry(total=3, backoff_factor=0.3, status_forcelist=[429, 500, 502, 503, 504, 520, 521, 522, 524, 530])
	session.mount(url, requests.adapters.HTTPAdapter(max_retries=retries, pool_maxsize=100))
	return session

def make_requests():
	return requests