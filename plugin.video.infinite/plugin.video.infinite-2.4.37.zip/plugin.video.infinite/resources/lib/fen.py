# -*- coding: utf-8 -*-
from sys import argv
from modules.router import routing
# from modules.kodi_utils import logger
# logger(f'repr(argv): {repr(argv)}')
# logger(f'repr(argv[2]): {repr(argv[2])}')
routing(argv[2])
