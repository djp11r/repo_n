# -*- coding: utf-8 -*-
import xbmc
import json
from threading import Thread
from traceback import print_exc

from datetime import timedelta
from caches.settings_cache import get_setting
from modules import kodi_utils as ku, settings as st, watched_status as ws
logger = ku.logger

class infinitePlayer(xbmc.Player):
	def __init__(self):
		xbmc.Player.__init__(self)

	def run(self, url=None, obj=None, info=None):
		ku.hide_busy_dialog()
		self.clear_playback_properties()
		self.info = info or {'title': ''}
		if not url: return self.run_error()
		try: return self.play_video(url, obj)
		except: return self.run_error()

	def play_video(self, url, obj):
		self.set_constants(url, obj)
		ku.volume_checker()
		self.play(self.url, self.make_listing())
		if not self.is_generic:
			self.check_playback_start()
			if self.playback_successful: self.monitor()
			else:
				self.obj.playback_successful = self.playback_successful
				self.obj.cancel_all_playback = self.cancel_all_playback
				if self.cancel_all_playback: self.kill_dialog()
				self.stop()
			try: del self.kodi_monitor
			except: pass

	def check_playback_start(self):
		resolve_percent = 0
		while self.playback_successful is None:
			ku.hide_busy_dialog()
			if not isinstance(self.obj, str):
				if not self.obj.progress_dialog: self.playback_successful = True
				elif self.obj.progress_dialog.skip_resolved(): self.playback_successful = False
				elif self.obj.progress_dialog.iscanceled() or self.kodi_monitor.abortRequested(): self.cancel_all_playback, self.playback_successful = True, False
			if resolve_percent >= 95: self.playback_successful = False
			elif ku.get_visibility('Window.IsTopMost(okdialog)'):
				ku.execute_builtin('SendClick(okdialog, 11)')
				self.playback_successful = False
			elif self.isPlayingVideo():
				try:
					if self.getTotalTime() not in ('0.0', '', 0.0, None) and ku.get_visibility('Window.IsActive(fullscreenvideo)'): self.playback_successful = True
				except: pass
			resolve_percent = round(resolve_percent + 10.0/100, 1)
			if not isinstance(self.obj, str): self.obj.progress_dialog.update_resolver(percent=resolve_percent)
			ku.sleep(50)

	def playback_close_dialogs(self):
		try: self.obj.playback_successful = True
		except: self.playback_successful = True
		self.kill_dialog()
		ku.sleep(200)
		ku.close_all_dialog()

	def monitor(self):
		try:
			ensure_dialog_dead, total_check_time, force_watched = False, 0, False
			play_random_continual, self.autoplay_nextep, play_random, show_stinger = False, False, False, False
			stinger_use_chapters, stingers_percentage_fallback = 90, 95
			if self.media_type == 'episode':
				try:
					play_random_continual = self.obj.random_continual
					play_random = self.obj.random
					disable_autoplay_next_episode = self.obj.disable_autoplay_next_episode
					if disable_autoplay_next_episode: ku.notification('Scrape with Custom Values - Autoplay Next Episode Cancelled', 4500)
					if any((play_random_continual, play_random, disable_autoplay_next_episode)): self.autoplay_nextep = False
					else: self.autoplay_nextep = self.obj.autoplay_nextep
				except:
					show_stinger = st.stingers_show()
					play_random_continual, self.autoplay_nextep = False, False
			while total_check_time <= 30 and not ku.get_visibility('Window.IsActive(fullscreenvideo)'):
				ku.sleep(100)
				total_check_time += 0.10
			ku.hide_busy_dialog()
			ku.sleep(1000)
			self.showSubtitles(True)
			while self.isPlayingVideo():
				try:
					if not ensure_dialog_dead:
						ensure_dialog_dead = True
						self.playback_close_dialogs()
					ku.sleep(1000)
					try: self.total_time, self.curr_time = self.getTotalTime(), self.getTime()
					except: ku.sleep(250); continue
					# if not self.resume_set and self.playback_percent > 0 and self.total_time: self.set_resume_playback()
					if not self.subs_searched: self.run_subtitles()
					self.current_point = round(float(self.curr_time/self.total_time * 100), 1)
					# logger(f'monitor self.autoplay_nextep: {self.autoplay_nextep} self.media_marked: {self.media_marked} self.current_point: {self.current_point} set_watched: {self.set_watched} self.total_time: {self.total_time}')
					if self.current_point >= self.set_watched:
						if play_random_continual: self.run_random_continual(); break
						if not self.media_marked: self.media_watched_marker()
					if self.media_type == 'episode':
						if self.obj.intro_checklist: self.run_episode_intro()
						if self.autoplay_nextep:
							if not self.nextep_info_gathered: self.info_next_ep()
							# logger(f'monitor round(self.total_time - self.curr_time): {round(self.total_time - self.curr_time)} self.start_prep: {self.start_prep}')
							if round(self.total_time - self.curr_time) <= self.start_prep: return self.run_next_ep()
					elif show_stinger and not self.movie_stingers_run: 
						final_chapter = self.final_chapter(75) or 90
						if self.current_point >= final_chapter: self.run_movie_stingers()
				except: pass #logger(f'2monitor Error: {print_exc()}')
			ku.hide_busy_dialog()
			if not self.media_marked: self.media_watched_marker(force_watched)
			self.clear_playback_properties()
		except:
			logger(f'1monitor Error: {print_exc()}')
			ku.hide_busy_dialog()
			try: self.obj.playback_successful, self.obj.cancel_all_playback = False, True
			except: self.playback_successful, self.cancel_all_playback = False, True
			return self.kill_dialog()

	def make_listing(self):
		listitem = ku.make_listitem()
		listitem.setPath(self.url)
		listitem.setContentLookup(False)
		info_tag = listitem.getVideoInfoTag(True)
		info_tag.setTitle(str(self.info.get('title') or ''))
		info_tag.setFilenameAndPath(self.url)
		if self.is_generic: info_tag.setMediaType('video')
		else:
			try:
				if ' , ' in self.url: self.set_watched = 30
				self.tvdb_id = self.meta_get('tvdb_id') or self.meta_get('imdb_id', '')
				self.tmdb_id, self.imdb_id = self.meta_get('tmdb_id', ''), self.meta_get('imdb_id', '')
				self.title, self.year = self.meta_get('title'), self.meta_get('year')
				self.season, self.episode = self.meta_get('season', ''), self.meta_get('episode', '')
				poster, clearlogo = self.meta_get('poster') or ku.get_icon('box_office'), self.meta_get('clearlogo') or ''
				genre, tagline = self.meta_get('genre', ''), self.meta_get('tagline')
				plot = self.meta_get('plot') or self.meta_get('tvshow_plot') or ''
				listitem.setLabel(self.title)
				listitem.setArt({'poster': poster, 'icon': poster, 'clearlogo': clearlogo})
				if self.media_type == 'movie': display_title, unique_ids, = self.title, {'imdb': self.imdb_id, 'tmdb': str(self.tmdb_id), 'tvdb': self.tvdb_id}
				else:
					display_title, unique_ids = self.meta_get('ep_name'), {'imdb': self.imdb_id, 'tmdb': str(self.tmdb_id), 'tvdb': self.tvdb_id}
					info_tag.setTvShowTitle(self.meta_get('tvshowtitle') or self.title), info_tag.setSeason(self.season), info_tag.setEpisode(self.episode)
				info_tag.setPlot(plot), info_tag.setYear(int(self.year)), info_tag.setTagLine(tagline), info_tag.setGenres(genre), info_tag.setIMDBNumber(self.imdb_id)
				info_tag.setTitle(display_title), info_tag.setMediaType(self.media_type), info_tag.setUniqueIDs(unique_ids)
			except: logger(f'make_listing Error: {print_exc()}')
			self.set_resume_point(listitem)
			self.set_playback_properties()
		if self.use_inputstream and any(x in self.url.lower() for x in ['m3u8', 'hls', 'mpd', 'ism']): listitem = ku.set_inputstream(self.url, listitem)
		return listitem

	def media_watched_marker(self, force_watched=False):
		self.media_marked = True
		try:
			if self.current_point >= self.set_watched or force_watched:
				watched_function = ws.mark_movie if self.media_type == 'movie' else ws.mark_episode
				watched_params = {'action': 'mark_as_watched', 'tmdb_id': self.tmdb_id, 'title': self.title, 'year': self.year, 'season': self.season, 'episode': self.episode,
									'from_playback': 'true', 'tvdb_id': self.tvdb_id, 'imdb_id': self.imdb_id}
				Thread(target=self.run_media_progress, args=(watched_function, watched_params)).start()
			else:
				ku.clear_property('infinite.random_episode_history')
				if self.current_point >= self.set_resume:
					progress_params = {'media_type': self.media_type, 'tmdb_id': self.tmdb_id, 'curr_time': round(self.curr_time, 2), 'total_time': self.total_time,
									'title': self.title, 'season': self.season, 'episode': self.episode, 'from_playback': 'true', 'imdb_id': self.imdb_id, 'tvdb_id': self.tvdb_id}
					Thread(target=self.run_media_progress, args=(ws.set_bookmark, progress_params)).start()
		except: logger(f'media_watched_marker Error: {print_exc()}')

	def run_media_progress(self, function, params):
		try: function(params)
		except: logger(f'run_media_progress Error: {print_exc()}')

	def run_episode_intro(self):
		for current in self.obj.intro_checklist:
			seek_time, text = None, None
			other = 'intro' if current == 'recap' else 'recap'
			curr_run, curr_start, curr_end = getattr(self, '%s_run' % current), getattr(self.obj, 'start_%s' % current), getattr(self.obj, 'end_%s' % current)
			other_run, other_start, other_end = getattr(self, '%s_run' % other), getattr(self.obj, 'start_%s' % other), getattr(self.obj, 'end_%s' % other)
			if not curr_run:
				if self.curr_time >= curr_start:
					setattr(self, '%s_run' % current, True)
					if not other_run and other_start is not None:
						if curr_end > other_end:
							setattr(self, '%s_run' % other, True)
							seek_time, text = curr_end, '%s & %s' % (current.upper(), other.upper())
						elif other_start - curr_end < 5:
							setattr(self, '%s_run' % other, True)
							seek_time, text = other_end, '%s & %s' % (current.upper(), other.upper())
						else: seek_time, text = curr_end, current.upper()
					else: seek_time, text = curr_end, current.upper()
					if seek_time - self.curr_time < 3: seek_time, text = None, 'RECAP & INTRO passed'
			self.obj.intro_checklist = [i for i in self.obj.intro_checklist if not getattr(self, '%s_run' % i)]

			if seek_time:
				self.seekTime(seek_time)
				text = 'Skip %s: [B]END %s[/B]' % (text, str(timedelta(seconds=seek_time)))
			if text: ku.notification(text, 5000)

	def run_next_ep(self):
		from modules.episode_tools import EpisodeTools
		if not self.media_marked: self.media_watched_marker(force_watched=True)
		# logger(f'run_next_ep params {repr(self.meta)}, {repr(self.nextep_settings)}')
		EpisodeTools(self.meta, self.nextep_settings).auto_nextep()

	def run_random_continual(self):
		from modules.episode_tools import EpisodeTools
		if not self.media_marked: self.media_watched_marker(force_watched=True)
		EpisodeTools(self.meta).play_random_continual(False)

	def run_movie_stingers(self):
		self.movie_stingers_run = True
		stinger_keys = self.meta.get('stinger_keys', None)
		if not stinger_keys:
			try:
				keywords = self.meta.get('keywords', [])
				stinger_keys = [i['name'] for i in keywords['keywords'] if i['name'] in ('duringcreditsstinger', 'aftercreditsstinger')]
				self.meta['stinger_keys'] = stinger_keys
			except: pass
		if stinger_keys:
			from windows.base_window import open_window
			Thread(target=lambda: open_window(('windows.playback_notifications', 'StingersNotification'), 'playback_notifications.xml', meta=self.meta)).start()

	def set_resume_point(self, listitem):
		if self.playback_percent > 0.0: listitem.setProperty('StartPercent', str(self.playback_percent))

	def info_next_ep(self):
		self.nextep_info_gathered = True
		try:
			percentage, start_outro, final_chapter = None, self.obj.start_outro, self.final_chapter(90)
			if start_outro is not None and round(self.total_time - start_outro) > 10: percentage = 100 - round(start_outro/self.total_time * 100)
			if not percentage and final_chapter: percentage = 100 - final_chapter
			if not percentage: percentage = 10
		except: percentage = 10
		window_time = round((percentage/100) * self.total_time)
		self.start_prep = int(get_setting('infinite.results.timeout', '60')) + window_time
		self.nextep_settings = {'window_time': window_time, 'play_type': 'autoplay_nextep'}

	def final_chapter(self, threshhold):
		try:
			final_chapter = float(ku.get_infolabel('Player.Chapters').split(',')[-1])
			if final_chapter >= threshhold: return final_chapter
		except: pass
		return None

	def kill_dialog(self):
		try: self.obj._kill_progress_dialog()
		except: ku.close_all_dialog()

	def set_constants(self, url, obj):
		if url.startswith('Direct_'): obj, url = 'video', url.replace('Direct_', '')
		self.url = url
		self.obj = obj
		self.is_generic = self.obj == 'video'
		self.set_watched, self.set_resume = 90, 5
		# logger(f'set_constants url: {url} self.info: {self.info}')
		if self.info.get('use_inputstream'): self.use_inputstream = False
		else: self.use_inputstream = st.get_use_inputstream()
		# logger(f'set_constants self.use_inputstream: {self.use_inputstream}')
		if not self.is_generic:
			try:
				self.meta = json.loads(obj) if isinstance(obj, str) else self.obj.meta
			except: logger(f'set_constants Error: {print_exc()}\nobj: {obj} url: {url}')
			self.meta_get, self.kodi_monitor = self.meta.get, ku.kodi_monitor()
			try: self.playback_percent = self.obj.playback_percent
			except:
				try: self.playback_percent = float(self.meta_get('playback_percent'))
				except: self.playback_percent = 0.0
			try: self.playing_filename = self.obj.playing_filename
			except: self.playing_filename = self.meta_get('disply_name')
			self.media_marked, self.nextep_info_gathered, self.movie_stingers_run = False, False, False
			self.playback_successful, self.cancel_all_playback = None, False
			self.media_type = self.meta_get('media_type')
			if self.media_type == 'episode': self.recap_run, self.intro_run = False, False
			self.subs_searched = False

	def set_playback_properties(self):
		try:
			if self.playing_filename: ku.set_property('subs.player_filename', self.playing_filename)
		except: pass

	def clear_playback_properties(self):
		ku.clear_property('infinite.window_stack')
		ku.clear_property('subs.player_filename')

	def run_error(self):
		try: self.obj.playback_successful = False
		except: pass
		self.clear_playback_properties()
		ku.notification('Playback Failed')
		return False

	def run_subtitles(self):
		self.subs_searched = True
		try:
			title = self.title if self.media_type == 'movie' else self.meta_get('tvshowtitle')
			media_id = self.tmdb_id if '|' in str(self.imdb_id) else self.imdb_id
			subfile = self.meta_get('subtitles')
			# if not subfile and '|' not in str(self.tvdb_id): subfile = Subtitles().get(title, media_id, self.season or None, self.episode or None)
			if subfile: self.setSubtitles(subfile)
			else: ku.notification('No Subtitles Found')
		except: logger(f'run_subtitles Error: {print_exc()}')

	def onPlayBackPaused(self):
		try:
			total_time = self.getTotalTime()
			if total_time <= 0: return
			pause_percent = round((self.getTime() / total_time) * 100, 2)
			ku.clear_property('infinite.random_episode_history')
			if self.current_point >= self.set_resume:
				logger(f'onPlayBackPaused callback self.set_resume: {self.set_resume}')
				progress_params = {'media_type': self.media_type, 'tmdb_id': self.tmdb_id, 'curr_time': round(self.curr_time, 2), 'total_time': self.total_time, 'title': self.title, 'season': self.season, 'episode': self.episode, 'from_playback': 'true', 'imdb_id': self.imdb_id, 'tvdb_id': self.tvdb_id}
				Thread(target=self.run_media_progress, args=(ws.set_bookmark, progress_params)).start()
		except Exception as e: logger(f'onPlayBackPaused error: {e}')
