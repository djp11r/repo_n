# -*- coding: utf-8 -*-
import copy
import re
import sys
import time
import json
import struct
import inspect
from random import random

import unicodedata
from html import unescape
from queue import SimpleQueue
from contextlib import nullcontext
from importlib import import_module, reload as rel_module
from threading import Thread, active_count
from datetime import datetime, timedelta, date
from caches.base_cache import open_db
from modules.settings import max_threads
from modules.kodi_utils import sleep, logger

# Precompile once at module import time
HEX_ENTITIES = {
	'&#x26;': '&', '&#x27;': "'", '&#xC6;': 'AE', '&#xC7;': 'C',
	'&#xF4;': 'o', '&#xE9;': 'e', '&#xEB;': 'e', '&#xED;': 'i',
	'&#xEE;': 'i', '&#xA2;': 'c', '&#xE2;': 'a', '&#xEF;': 'i',
	'&#xE1;': 'a', '&#xE8;': 'e', '%2E': '.', '&frac12;': '%BD',
	'&#xBD;': '%BD', '&#xB3;': '%B3', '&#xB0;': '%B0', '&amp;': '&',
	'&#xB7;': '.', '&#xE4;': 'A', '\xe2\x80\x99': ''
}

SPECIAL_ENCODED = {
	'"': '%22', '*': '%2A', '/': '%2F', ':': ',', '<': '%3C',
	'>': '%3E', '?': '%3F', '\\': '%5C', '|': '%7C'
}

SPECIAL_BLANKS = {
	'"': ' ', '/': ' ', ':': '', '<': ' ', '>': ' ', '?': ' ',
	'\\': ' ', '|': ' ', '%BD;': ' ', '%B3;': ' ', '%B0;': ' ',
	"'": "", ' - ': ' ', '.': ' ', '!': '', ';': '', ',': ''
}

# Build regex patterns once
HEX_RE = re.compile("|".join(map(re.escape, HEX_ENTITIES)))
ENC_RE = re.compile("|".join(map(re.escape, SPECIAL_ENCODED)))
BLANK_RE = re.compile("|".join(map(re.escape, SPECIAL_BLANKS)))

# Pre-compile the regex patterns outside the function for maximum speed
MISSING_SEMICOLON_PATTERN = re.compile(r'(&#[0-9]+)([^;0-9]+)')
MULTI_SPACE_PATTERN = re.compile(r'\s+')
# Combine all unique custom replacements into a single mapping dictionary
CUSTOM_REPLACEMENTS = {# Smart Quotes (Normalized to straight single quotes)
	"“": "'", "”": "'", "‘": "'", "’": "'", "â\x80\x99": "'", "\u02bb": "",
	# Dashes, Ellipses, and Math symbols
	"—": "",  # Em-dash removed
	"–": "-",  # En-dash replaced with hyphen
	"…": "...",  # Ellipsis normalized to three dots
	"%2B": "+",  # URL encoded plus sign
	# Path / Slash fixes
	"\\/": "/", "///": "//",
	# Strip tags, layout controls, and specific symbols
	"&nbsp;": " ", "\u2009": " ",  # Thin space
	"»": "", "&raquo;": "", "&Amp;": "&",
	# Raw Byte / Hex Escape Artifacts
	"\x80\x9c": "'", "\x80\x9d": "'", "\x80\x98": "'", "\x80\x99": "'", "\x80\x89": "", "\x80\x93": "-", "\x89": "", "\x8e": "", "\\xa": "a",
	"[spoiler]": "", "[/spoiler]": ""}
# Single-pass regex pattern for custom replacements
CUSTOM_REPLACE_PATTERN = re.compile("|".join(re.escape(k) for k in CUSTOM_REPLACEMENTS.keys()))

def replaceHTMLCodes(txt: str) -> str:
	"""High-performance HTML decoding pipeline optimized for Python 3.14."""
	if not txt: return ''
	# 1. Quick pre-check: Only run the double-decode loop if an entity actually exists
	# This skips heavy processing entirely for normal, clean strings
	for _ in range(2):
		if '&' not in txt and '\\' not in txt and '%' not in txt and '<' not in txt:
			break
		# 2. Decode raw backslash escape sequences first
		try: txt = txt.encode('utf-8').decode('unicode_escape')
		except Exception: pass
		# 3. Fix missing semicolons on numerical HTML entities
		txt = MISSING_SEMICOLON_PATTERN.sub(r'\1;\2', txt)
		# 4. Standard HTML unescaping (Built-in C-level speed)
		txt = unescape(txt)
		# 5. Fast, single-pass custom character replacements
		txt = CUSTOM_REPLACE_PATTERN.sub(lambda m: CUSTOM_REPLACEMENTS[m.group(0)], txt)
	# 6. Global structural cleanup (HTML tags, spacing, layout control)
	txt = txt.replace('<span class="st">', '').replace('</span>', '')
	#txt = txt.replace('\n', ' ').replace('\r', '').replace('\t', '')
	txt = MULTI_SPACE_PATTERN.sub(' ', txt)
	# 7. Final pass: Drop remaining non-ASCII characters
	return txt.encode('ascii', 'ignore').decode('ascii').strip()

def clean_html(html):
	html = re.sub(r'<!--.*?-->', '', html, flags=re.S) # remove comments
	html = re.sub(r'\s+', ' ', html) # collapse whitespace
	return html.strip()

class TaskPool:
	@staticmethod
	def process(_threads):
		for index, i in enumerate(_threads, 1):
			try: i.start()
			except Exception as e: logger(f'thread error: {index}: {e}')
			else: yield i

	def __init__(self, maxsize=None):
		self._queue = SimpleQueue()
		self._max_threads = maxsize or max_threads() or 20

	def _thread_target(self, queue, target, db_name):
		sig = inspect.signature(target)
		uses_db = 'dbcon' in sig.parameters
		context = open_db(db_name) if (uses_db and db_name) else nullcontext(None)
		with context as dbcon:
			while not queue.empty():
				try:
					args = queue.get()
					if uses_db: target(*args, dbcon=dbcon)
					else: target(*args)
				except Exception as e: logger(f'thread queue error {e}')

	def tasks(self, _target, _list, db_name=None):
		if not _list: return []
		if not isinstance(_list[0], tuple): _list = [(i,) for i in _list]
		self._max_threads = min(len(_list), self._max_threads)
		[self._queue.put(tag) for tag in _list]
		threads = [Thread(target=self._thread_target, args=(self._queue, _target, db_name)) for _ in range(self._max_threads)]
		return list(self.process(threads))

	def tasks_enumerate(self, _target, _list, db_name=None):
		# logger(f'min(len(_list)): {repr((len(_list)))} _target: {_target} data: {repr(_list)}')
		self._max_threads = min(len(_list), self._max_threads)
		# logger(f'queue maxsize {maxsize} self.maxsize {self.maxsize}')
		[self._queue.put((p, tag)) for p, tag in enumerate(_list, 1)]
		threads = [Thread(target=self._thread_target, args=(self._queue, _target, db_name)) for _ in range(self._max_threads)]
		return list(self.process(threads))


def make_thread_list(_target, _list):
	_max_threads = 30
	for item in _list:
		while active_count() > _max_threads: sleep(1)
		threaded_object = Thread(target=_target, args=(item,))
		threaded_object.start()
		yield threaded_object

def make_thread_list_enumerate(_target, _list):
	_max_threads = 30
	for count, item in enumerate(_list):
		while active_count() > _max_threads: sleep(1)
		threaded_object = Thread(target=_target, args=(count, item))
		threaded_object.start()
		yield threaded_object

def append_module_to_syspath(location):
	from modules.kodi_utils import translate_path
	sys.path.append(translate_path(location))

def manual_function_import(location, function_name):
	return getattr(import_module(location), function_name)

def reload_module(location):
	from importlib import reload as rel_module
	return rel_module(manual_module_import(location))

def manual_module_import(location):
	return import_module(location)

def random_integer(start=1, end=1000000):
	from random import randint
	return randint(start, end)

def chacha20_block(key, counter, nonce):
	"""Pure-Python ChaCha20 core block function."""
	assert len(key) == 32 and len(nonce) == 12
	ctx = [
		0x61707865, 0x3332206b, 0x6e617734, 0x6b206574, # Constants
		*struct.unpack('<8I', key),
		counter,
		*struct.unpack('<3I', nonce)
	]
	x = list(ctx)
	
	def quarter_round(a, b, c, d):
		x[a] = (x[a] + x[b]) & 0xffffffff; x[d] ^= x[a]; x[d] = ((x[d] << 16) | (x[d] >> 16)) & 0xffffffff
		x[c] = (x[c] + x[d]) & 0xffffffff; x[b] ^= x[c]; x[b] = ((x[b] << 12) | (x[b] >> 20)) & 0xffffffff
		x[a] = (x[a] + x[b]) & 0xffffffff; x[d] ^= x[a]; x[d] = ((x[d] <<  8) | (x[d] >> 24)) & 0xffffffff
		x[c] = (x[c] + x[d]) & 0xffffffff; x[b] ^= x[c]; x[b] = ((x[b] <<  7) | (x[b] >> 25)) & 0xffffffff

	for _ in range(10): # 20 rounds total (10 loops of 2 rounds)
		quarter_round(0, 4,  8, 12); quarter_round(1, 5,  9, 13)
		quarter_round(2, 6, 10, 14); quarter_round(3, 7, 11, 15)
		quarter_round(0, 5, 10, 15); quarter_round(1, 6, 11, 12)
		quarter_round(2, 7,  8, 13); quarter_round(3, 4,  9, 14)
		
	return struct.pack('<16I', *((x[i] + ctx[i]) & 0xffffffff for i in range(16)))

def chacha20_crypt(data, key, nonce):
	"""Encrypts or decrypts data using ChaCha20."""
	encrypted = bytearray()
	for block_idx in range((len(data) + 63) // 64):
		keystream = chacha20_block(key, block_idx, nonce)
		chunk = data[block_idx * 64 : (block_idx + 1) * 64]
		for b, k in zip(chunk, keystream):
			encrypted.append(b ^ k)
	return bytes(encrypted)

def chunks(item_list, limit):
	"""
	Yield successive limit-sized chunks from item_list.
	"""
	for i in range(0, len(item_list), limit): yield item_list[i:i + limit]

def string_to_float(string, default_return):
	"""
	Remove all alpha from string and return a float.
	Returns float of "default_return" upon ValueError or TypeError.
	"""
	if not string:return float(default_return)		
	try:
		cleaned = str(string).replace(' ', '').replace(',', '')
		return float(cleaned)
	except ValueError:
		try: return float(''.join(c for c in cleaned if c.isdigit() or c in '.-'))
		except (ValueError, TypeError): return float(default_return)
	except TypeError: return float(default_return)


def string_alphanum_to_num(string):
	"""
	Remove all alpha from string and return remaining string.
	Returns original string upon ValueError.
	"""
	try: return ''.join(c for c in string if c.isdigit())
	except ValueError: return string

def extract_ints(text):
	"""
	Finds all integers inside a string and returns them as a tuple.
	"""
	numbers = re.findall(r'\d+', text)
	return tuple(int(num) for num in numbers)

def jsondate_to_datetime(jsondate, resformat=None, remove_time=False):
	if not jsondate: return None
	if remove_time: datetime_object = datetime_workaround(jsondate, resformat).date()
	else: datetime_object = datetime_workaround(jsondate, resformat)
	return datetime_object

def get_datetime(string=False, dt=False):
	d = datetime.now()
	if dt: return d
	return d.strftime('%Y-%m-%d') if string else datetime.date(d)

def get_current_timestamp():
	return int(time.time())

def adjust_premiered_date(orig_date, adjust_hours):
	if not orig_date: return None, None
	try:
		t_struct = time.strptime(orig_date.split(' ')[0], '%Y-%m-%d')
		datetime_object = datetime(t_struct.tm_year, t_struct.tm_mon, t_struct.tm_mday, 20)
		adjusted_datetime = datetime_object + timedelta(hours=adjust_hours)
		adjusted_string = '%04d-%02d-%02d' % (adjusted_datetime.year, adjusted_datetime.month, adjusted_datetime.day)
		return adjusted_datetime.date(), adjusted_string
	except: return None, None

def make_day(today, date, date_format='%Y-%m-%d', use_words=True):
	if use_words:
		day_diff = (date - today).days
		relative_days = {-1: 'YESTERDAY', 0: 'TODAY', 1: 'TOMORROW'}
		if day_diff in relative_days: return relative_days[day_diff]
		if 1 < day_diff < 7: return date.strftime('%A').upper()
	try: return date.strftime(date_format)
	except ValueError: return date.strftime('%Y-%m-%d')

def subtract_dates(date1, date2):
	try:
		d1 = date1.date() if hasattr(date1, 'hour') else date1
		d2 = date2.date() if hasattr(date2, 'hour') else date2
		return (d1 - d2).days
	except: return 0

def datetime_workaround(data, _format):
	_object = None
	try: _object = datetime.strptime(data, _format)
	except:
		try: _object = datetime(*(time.strptime(data, _format)[0:6]))
		except:
			formats = ['%Y-%m-%dT%H:%M:%S.%fZ', '%Y-%m-%d %H:%M:%S', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d']
			for fmt in formats:
				try: return datetime.strptime(data, fmt)
				except: pass
	return _object

def date_difference(current_date, compare_date, difference_tolerance, allow_postive_difference=False):
	try:
		difference = subtract_dates(current_date, compare_date)
		if not allow_postive_difference and difference > 0: return False
		else: difference = abs(difference)
		return difference <= difference_tolerance
	except: return True

def calculate_age(born, str_format, died=None):
	""" born and died are str objects e.g. '1972-05-28' """
	try:
		b_struct = time.strptime(born, str_format)
		if died:
			d_struct = time.strptime(died, str_format)
			today_year, today_month, today_day = d_struct.tm_year, d_struct.tm_mon, d_struct.tm_mday
		else:
			today = date.today()
			today_year, today_month, today_day = today.year, today.month, today.day
		has_not_had_birthday = (today_month, today_day) < (b_struct.tm_mon, b_struct.tm_mday)
		return today_year - b_struct.tm_year - has_not_had_birthday
		
	except: return 0

def clean_file_name(s, use_encoding=False, use_blanks=True):
	if not s: return ''
	try:
		s = str(s)
		s = unescape(s)
		extra_hex_replacements = {"%2E": ".", "&frac12;": "%BD", "&#xBD;": "%BD", "&#xB3;": "%B3", "&#xB0;": "%B0", "&#xB7;": ".", "\xe2\x80\x99": ""}
		for k, v in extra_hex_replacements.items():
			if k in s: s = s.replace(k, v)
		mapping = {}
		if use_encoding: mapping.update({'"': '%22', '*': '%2A', '/': '%2F', ':': ',', '<': '%3C', '>': '%3E', '?': '%3F', '\\': '%5C', '|': '%7C'})
		if use_blanks: mapping.update({'"': ' ', '/': ' ', ':': '', '<': ' ', '>': ' ', '?': ' ', '\\': ' ', '|': ' ', '%BD;': ' ', '%B3;': ' ', '%B0;': ' ',
										"'": "", ' - ': ' ', '.': ' ', '!': '', ';': '', ',': ''})
		for original, replacement in mapping.items():
			if original in s: s = s.replace(original, replacement)
		return s.strip()
	except: return s

def normalize(txt):
	if not txt: return ''
	return ''.join(c for c in unicodedata.normalize('NFD', txt) if unicodedata.category(c) != 'Mn')

def clean_text_markup(text):
	if not text: return ''
	if '<br' in text: text = text.replace('<br/><br/>', '\n').replace('<br/>', '\n').replace('<br>', '\n')
	text = replace_html_codes(text)
	if '<' in text and '>' in text:
		chunks = text.split('<')
		text = chunks[0] + ''.join(chunk.split('>', 1)[-1] for chunk in chunks[1:] if '>' in chunk)
	return normalize(text).strip()

def replace_html_codes(txt):
	if not txt: return ''
	txt = unescape(txt)
	replacements = {"<ul>": "\n", "</ul>": "\n", "<li>": "\n* ", "</li>": "", "<br/><br/>": "\n", "&quot;": '"', "&amp;": "&", "[spoiler]": "", "[/spoiler]": ""}
	for original, replacement in replacements.items():
		if original in txt: txt = txt.replace(original, replacement)
	return txt

def gen_md5(value):
	import hashlib
	try:
		md5_hash = hashlib.md5()
		md5_hash.update(str(value).encode('utf-8'))
		return md5_hash.hexdigest()
	except: return value

def gen_file_hash(file):
	import hashlib
	try:
		md5_hash = hashlib.md5()
		with open(file, 'rb') as afile:
			buf = afile.read()
			md5_hash.update(buf)
			return md5_hash.hexdigest()
	except: pass

def extract_json_object(raw_text):
	try:
		start = raw_text.find("{")
		end = raw_text.rfind("}")
		if start == -1 or end == -1 or end <= start: return {}
		json_str = raw_text[start:end + 1]
		return json.loads(json_str)
	except: return {}

def sec2time(sec, n_msec=3):
	""" Convert seconds to 'D days, HH:MM:SS.FFF' """
	if isinstance(sec, (list, tuple)): return [sec2time(s, n_msec) for s in sec]
	m, s = divmod(sec, 60)
	h, m = divmod(m, 60)
	d, h = divmod(h, 24)
	if n_msec > 0: time_str = ('%02d:%02d:%0' + str(n_msec + 3) + '.' + str(n_msec) + 'f') % (h, m, s)
	else: time_str = "%02d:%02d:%02d" % (h, m, int(s))
	if d == 0: return time_str
	return '%d days, %s' % (d, time_str)

def released_key(item):
	return item.get('released') or item.get('first_aired') or '2050-01-01'

def title_key(title):
	if not title: return ''
	for article in ['the ', 'a ', 'an ']:
		if title.lower().startswith(article): return title[len(article):]
	return title

def sort_for_article(_list, _key):
	try: _list.sort(key=lambda k: title_key(k.get(_key)))
	except: pass
	return _list

def paginate_list(item_list, page, limit=20, paginate_start=0):
	if not item_list: return [], 0
	if paginate_start: item_list = item_list[paginate_start:]
	total_pages = -(-len(item_list) // limit)
	if page < 1 or page > total_pages: return [], total_pages
	start_idx = (page - 1) * limit
	end_idx = start_idx + limit
	return item_list[start_idx:end_idx], total_pages

def unzip(zip_location, destination_location, destination_check, show_busy=True):
	from zipfile import ZipFile
	from modules.kodi_utils import show_busy_dialog, hide_busy_dialog, path_exists
	if show_busy: show_busy_dialog()
	try:
		zipfile = ZipFile(zip_location)
		zipfile.extractall(path=destination_location)
		if path_exists(destination_check): status = True
		else: status = False
	except: status = False
	if show_busy: hide_busy_dialog()
	return status

def make_qrcode(url):
	if url is None: return
	return f'https://api.qrserver.com/v1/create-qr-code/?size=256x256&qzone=1&data={url}'
	# import segno
	# from os import path
	# from modules.kodi_utils import addon_profile
	# try:
	# 	art_path = path.join(addon_profile(), 'qr.png')
	# 	qrcode = segno.make(url, micro=False)
	# 	qrcode.save(art_path, scale=20)
	# except: return
	# return art_path

def make_tinyurl(url):
	import requests
	short_url = ''
	try:
		tiny_url = 'http://tinyurl.com/api-create.php'
		response = requests.get(tiny_url, params={'url': url})
		status = response.status_code
		if status == 200:
			short_url = response.text
		else: pass
	except: pass
	return short_url

def copy2clip(txt):
	if sys.platform == 'win32':
		try:
			from subprocess import check_call
			cmd = 'echo ' + txt.replace('&', '^&').strip() + '|clip'
			return check_call(cmd, shell=True)
		except: return
	if sys.platform == 'darwin':
		try:
			from subprocess import check_call
			cmd = f'echo {txt.strip()}|pbcopy'
			return check_call(cmd, shell=True)
		except: return
	if sys.platform == 'linux':
		try:
			from subprocess import Popen, PIPE
			p = Popen(['xsel', '-pi'], stdin=PIPE)
			p.communicate(input=txt)
		except: return



def sort_list(sort_key, sort_direction, list_data):
	try:
		reverse = sort_direction != 'asc'
		if sort_key == 'rank': return sorted(list_data, key=lambda x: x['rank'], reverse=reverse)
		if sort_key == 'added': return sorted(list_data, key=lambda x: x['listed_at'], reverse=reverse)
		if sort_key == 'title': return sorted(list_data, key=lambda x: title_key(x[x['type']].get('title')), reverse=reverse)
		if sort_key == 'released': return sorted(list_data, key=lambda x: released_key(x[x['type']]), reverse=reverse)
		if sort_key == 'runtime': return sorted(list_data, key=lambda x: x[x['type']].get('runtime', 0), reverse=reverse)
		if sort_key == 'popularity': return sorted(list_data, key=lambda x: x[x['type']].get('votes', 0), reverse=reverse)
		if sort_key == 'percentage': return sorted(list_data, key=lambda x: x[x['type']].get('rating', 0), reverse=reverse)
		if sort_key == 'votes': return sorted(list_data, key=lambda x: x[x['type']].get('votes', 0), reverse=reverse)
		if sort_key == 'random': return sorted(list_data, key=lambda k: random())
		return list_data
	except: return list_data

def make_thread_list_multi_arg(_target, _list):
	_max_threads = 30
	for item in _list:
		while active_count() > _max_threads: sleep(1)
		threaded_object = Thread(target=_target, args=item)
		threaded_object.start()
		yield threaded_object

def regex_from_to(text, from_string, to_string, excluding=True):
	return (
		re.search(rf"(?i){from_string}" + r"([\S\s]+?)" + to_string, text)[1]
		if excluding
		else re.search(rf"(?i)({from_string}" + r"[\S\s]+?" + to_string + ")", text)[1]
	)

def regex_get_all(text, start_with, end_with, excluding=True):
	return (
		re.findall(rf"(?i){start_with}" + r"([\S\s]+?)" + end_with, text)
		if excluding
		else re.findall(rf"(?i)({start_with}" + r"[\S\s]+?" + end_with + ")", text))

def batch_replace(s, replace_info):
	for r in replace_info:
		s = str(s).replace(r[0], r[1])
	return s

def byteify(data, ignore_dicts=False):
	try:
		if isinstance(data, str): return data.encode('utf-8', 'ignore')
		if isinstance(data, list): return [byteify(item, ignore_dicts=True) for item in data]
		if isinstance(data, dict) and not ignore_dicts: return dict([(byteify(key, ignore_dicts=True), byteify(value, ignore_dicts=True)) for key, value in data.items()])
		return data.encode('utf-8') if str(type(data)) == "<type 'unicode'>" else data
	except: pass
	return data

def change_image_resolution(image, replace_res):
	return re.sub(r'(w185|w300|w342|w780|w1280|h632|original)', replace_res, image)

def years_list(decades=None):
	interation = -10 if decades else -1
	year = datetime.today().year
	return list(range(year, 1899, interation))

def image_from_db(image_url, delete=True):
	import os
	import sqlite3 as database
	from modules.kodi_utils import translate_path, notification
	try:
		thumbs_folder = translate_path('special://thumbnails')
		dbfile = translate_path(os.path.join('special://database', 'Textures13.db'))
		if os.path.exists(dbfile):
			dbcon = database.connect(dbfile, isolation_level=None)
			dbcur = dbcon.cursor()
			dbcur.execute('''PRAGMA synchronous = OFF''')
			dbcur.execute('''PRAGMA journal_mode = OFF''')
		else: return notification('Failed')
		try: image_id, image_location = dbcur.execute("SELECT id, cachedurl FROM texture WHERE url = ?", (image_url,)).fetchone()
		except: return True
		path = os.path.join(thumbs_folder, image_location)
		if not delete: return path
		os.remove(path)
		dbcur.execute("DELETE FROM texture WHERE id=?", (image_id,))
		dbcur.execute("DELETE FROM sizes WHERE idtexture = ?", (image_id,))
		dbcur.execute("VACUUM")
		dbcon.commit()
		return True
	except: return False

def make_image(list_type, image_type, list_name, images, current_image):
	import os
	import shutil
	import urllib.request
	from PIL import Image
	from modules.kodi_utils import translate_path, addon_profile, make_directory, notification
	def _process(count, item):
		saved_path = translate_path(os.path.join(worker_image_folder, '%s_%02d.jpg' % (list_name, count + 1)))
		urllib.request.urlretrieve(item, saved_path)
		bg = Image.open(saved_path)
		bg.thumbnail(size_dimensions)
		new_img.paste(bg, placements[count])
	saved_final_image = None
	try:
		profile_path = addon_profile()
		worker_image_folder = os.path.join(profile_path, 'images', '%s_worker' % list_type)
		final_image_folder = os.path.join(profile_path, 'images', '%s_%s' % (list_type, image_type))
		saved_final_image = os.path.join(final_image_folder, '%s_%s.jpg' % (list_name, get_current_timestamp()))
		for location in (worker_image_folder, final_image_folder): make_directory(location)
		if image_type == 'poster': new_dimensions, size_dimensions, placements = (1000, 1500), (500, 750), ((0, 0), (500, 0), (0, 750), (500, 750))
		else: new_dimensions, size_dimensions, placements = (1280, 720), (640, 360), ((0, 0), (640, 0), (0, 360), (640, 360))
		new_img = Image.new('RGB', new_dimensions)
		threads = list(make_thread_list_enumerate(_process, images))
		[i.join() for i in threads]
		new_img.save(saved_final_image)
		shutil.rmtree(worker_image_folder)
		if current_image: os.remove(current_image)
	except Exception as e:
		logger('error creating Image', str(e))
		notification('Error Creating Image')
	return saved_final_image

def download_image(list_type, image_type, list_name, url, current_image):
	import os
	import shutil
	import urllib.request
	from modules.kodi_utils import addon_profile, make_directory, notification
	saved_final_image = None
	md5_image_name = gen_md5(list_name)
	try:
		profile_path = addon_profile()
		final_image_folder = os.path.join(profile_path, 'images', '%s_%s' % (list_type, image_type))
		saved_final_image = os.path.join(final_image_folder, '%s_%s.jpg' % (md5_image_name, get_current_timestamp()))
		make_directory(final_image_folder)
		urllib.request.urlretrieve(url, saved_final_image)
		if current_image: os.remove(current_image)
	except: notification('Error Creating Image')
	return saved_final_image


def epoch_to_datetime(date, date_format='%Y-%m-%d %H:%M:%S'):
	return time.strftime(date_format, time.gmtime(date))

def make_title_slug(name):
	name = name.strip()
	name = name.lower()
	name = re.sub('[^a-z0-9_]', '-', name)
	name = re.sub('--+', '-', name)
	return name

def list_to_string(_list):
	if isinstance(_list, list):
		_list = ', '.join(list(_list))
	return _list

def try_parse_int(string):
	try: return int(string)
	except: return 0

def to_utf8(obj):
	try:
		if isinstance(obj, str):
			obj = obj.encode('utf-8', 'ignore')
		elif isinstance(obj, dict):
			obj = copy.deepcopy(obj)
			for key, val in obj.items():
				obj[key] = to_utf8(val)
		elif obj is not None and hasattr(obj, "__iter__"):
			obj = obj.__class__([to_utf8(x) for x in obj])
	except: pass
	return obj

def to_unicode(obj):
	try:
		if isinstance(obj, str):
			# try: obj = unicode(obj, 'utf-8')
			# except TypeError: pass
			pass
		elif isinstance(obj, dict):
			obj = copy.deepcopy(obj)
			for key, val in obj.items():
				obj[key] = to_unicode(val)
		elif obj is not None and hasattr(obj, "__iter__"):
			obj = obj.__class__([to_unicode(x) for x in obj])
	except: pass
	return obj

def merge_dicts(*dict_args):
	"""
	Given any number of dicts, shallow copy and merge into a new dict,
	precedence goes to key value pairs in latter dicts.
	"""
	result = {}
	for dictionary in dict_args:
		result.update(dictionary)
	return result

def _conv_json_to_string(value):
	return json.dumps(value, ensure_ascii=False)

def make_dicts_value_tuple(obj):
	"""
	Given any number of dicts, shallow copy and merge into a new dict,
	precedence goes to key value pairs in latter dicts.
	"""
	obj = copy.deepcopy(obj)
	for key, val in obj.items():
		if isinstance(val, dict):
			try: val = _conv_json_to_string(val) # val = ', '.join(x for x in val if x != '')
			except: pass#logger(f'error val: {val}') # val = _conv_json_to_string(val)
		elif isinstance(val, list): val = ', '.join(x for x in val if x != '')
		obj[key] = str(val)
	return obj
