# -*- coding: utf-8 -*-
import json
import uuid
from caches.base_cache import connect_database, get_timestamp
from modules.fen_online_utils import single_sync
from modules.kodi_utils import logger

class PersonalListsCache:
	def __init__(self):
		self.last_sync_message = None

	@single_sync('personal_lists_db', 'personal_lists')
	def make_list(self, list_name, sort_order):
		try:
			time_stamp = get_timestamp()
			list_id = str(uuid.uuid4())
			contents = json.dumps([])
			total = 0
			dbcon = connect_database('personal_lists_db')
			dbcon.execute('INSERT OR REPLACE INTO personal_lists (id, name, contents, total, created, sort_order, updated) VALUES (?, ?, ?, ?, ?, ?, ?)',
						(list_id, list_name, contents, total, time_stamp, sort_order, time_stamp))
			return {'list_id': list_id, 'name': list_name, 'contents': contents, 'total': total, 'created': time_stamp, 'sort_order': sort_order, 'updated_time': time_stamp}
		except: return None

	@single_sync('personal_lists_db', 'personal_lists')
	def delete_list(self, list_id):
		try:
			dbcon = connect_database('personal_lists_db')
			dbcon.execute('DELETE FROM personal_lists WHERE id=?', (list_id,))
			dbcon.execute('VACUUM')
			return True
		except: return None

	@single_sync('personal_lists_db', 'personal_lists')
	def delete_list_contents(self, list_id):
		try:
			updated_time = get_timestamp()
			dbcon = connect_database('personal_lists_db')
			dbcon.execute('UPDATE personal_lists SET contents=?, total=? WHERE id=?', (json.dumps([]), '0', list_id))
			return True
		except: return None

	@single_sync('personal_lists_db', 'personal_lists')
	def update_single_detail(self, set_prop, new_value, list_id):
		try:
			updated_time = get_timestamp()
			dbcon = connect_database('personal_lists_db')
			dbcon.execute('UPDATE personal_lists SET %s=?, updated=? WHERE id=?' % set_prop, (new_value, updated_time, list_id))
			return True
		except: return None

	@single_sync('personal_lists_db', 'personal_lists')
	def add_remove_list_item(self, list_id, action, new_contents):
		self.last_sync_message = None
		try:
			dbcon = connect_database('personal_lists_db')
			contents = self.get_list(list_id, dbcon=dbcon)
			updated_time = get_timestamp()
			if action == 'add':
				if [str(i['media_id']) for i in contents if str(new_contents['media_id']) == str(i['media_id'])]:
					self.last_sync_message = 'Item Already in List'
					return None
				command = 'UPDATE personal_lists SET contents=?, total=total+1, updated=? WHERE id=?'
				contents.append(new_contents)
				self.last_sync_message = True
			else:
				if not [str(i['media_id']) for i in contents if str(new_contents) == str(i['media_id'])]:
					self.last_sync_message = 'Item Not in List'
					return None
				command = 'UPDATE personal_lists SET contents=?, total=total-1, updated=? WHERE id=?'
				contents = [i for i in contents if not str(i['media_id']) == str(new_contents)]
				self.last_sync_message = True
			dbcon.execute(command, (json.dumps(contents), get_timestamp(), list_id))
		except: self.last_sync_message = 'Error'
		return self.last_sync_message

	def get_lists(self):
		try:
			dbcon = connect_database('personal_lists_db')
			all_lists = dbcon.execute('SELECT id, name, total, created, sort_order, updated FROM personal_lists').fetchall()
			return [{'list_id': str(i[0]), 'name': str(i[1]), 'total': i[2], 'created_at': i[3], 'sort_order': i[4], 'updated': i[5]} for i in all_lists]
		except: return []

	def get_list(self, list_id, dbcon=None):
		content = []
		try:
			if not dbcon: dbcon = connect_database('personal_lists_db')
			try: content = json.loads(dbcon.execute('SELECT contents FROM personal_lists WHERE id=?', (list_id,)).fetchone()[0])
			except: content = eval(dbcon.execute('SELECT contents FROM personal_lists WHERE id=?', (list_id,)).fetchone()[0])
		except Exception as err: logger(f'err: {err}')
		return content

	def get(self, list_name):
		try:
			dbcon = connect_database('personal_lists_db')
			cache_data = dbcon.execute('SELECT contents FROM personal_lists WHERE name=?', (list_name,)).fetchone()
			if cache_data: return eval(cache_data[0])
		except Exception as err: logger(f'err: {err}')
		return []

	def get_list_id(self, list_name):
		try:
			olddata = self.get(list_name)
			if not olddata: olddata = self.make_list(list_name, 0)
			return olddata.get('list_id') or str(uuid.uuid4())
		except: pass
		return str(uuid.uuid4())

	@single_sync('personal_lists_db', 'personal_lists')
	def add_many_list_items(self, list_name, new_contents):
		try:
			dbcon = connect_database('personal_lists_db')
			contents = self.get_list(list_name, dbcon=dbcon)
			if contents:
				movies_compare_ids = [str(i['media_id']) for i in contents if i['type'] == 'movie']
				tvshows_compare_ids = [str(i['media_id']) for i in contents if i['type'] == 'tvshow']
				movies_new = [i for i in new_contents if i['type'] == 'movie' and str(i['media_id']) not in movies_compare_ids]
				tvshows_new = [i for i in new_contents if i['type'] == 'tvshow' and str(i['media_id']) not in tvshows_compare_ids]
				new_contents = movies_new + tvshows_new
			contents.extend(new_contents)
			dbcon.execute('UPDATE personal_lists SET contents=?, total=?, updated=? WHERE name=?', (json.dumps(contents), len(contents), get_timestamp(), list_name))
			return 'Success'
		except: return 'Error'

	@single_sync('personal_lists_db', 'personal_lists')
	def set(self, list_name, data):
		try:
			list_id = self.get_list_id(list_name)
			time_stamp = get_timestamp()
			dbcon = connect_database('personal_lists_db')
			dbcon.execute('INSERT OR REPLACE INTO personal_lists VALUES (?, ?, ?, ?, ?, ?, ?)', (list_name, json.dumps(data), len(data), time_stamp, 0, time_stamp, list_id))
		except: pass
		return

personal_lists_cache = PersonalListsCache()
