# -*- coding: utf-8 -*-

import random
import re
import string
from json import dumps, loads
from sys import argv
from traceback import print_exc

from xbmcgui import INPUT_ALPHANUM
from modules.player import infinitePlayer
from modules.kodi_utils import logger, confirm_dialog, build_url, make_listitem, add_item, notification, kodi_dialog, set_info, add_items, set_content, end_directory, set_view_mode, get_infolabel, kodi_player, set_category, external, kodi_player, select_dialog
from caches.main_cache import main_cache
from modules.settings import get_git_url
from modules.watched_status import get_media_info, get_progress_percent, get_watched_status
from modules.source_utils import request, generes_unify
from modules.utils import get_datetime

bi_url = 'https://tubitv.com'
git_url = get_git_url()
fanart = 'https://i.imgur.com/p18A3dF.png'
aicon = 'https://i.imgur.com/iOllLYX.png' # 'hindi_bi.png')
run_plugin = 'RunPlugin(%s)'
item_cleaner = re.compile(r'espanol|Español|lgbt|Doblado|k_drama|cj_enm|ganadores_y_nominados|telenovelas_y_series|para_los_nios_y_familias|japanese|hispanic|italian', re.I)
treplce_pattern = re.compile(r'\s+', flags=re.I) # remove Multiple Spaces
clean_pattern = re.compile(r'[:;\-",!_.?~$@]') # remove special characters

# faster translation-based cleaner
_TRANS = str.maketrans({c: ' ' for c in ':;"-,!_.?~$@'})
IS_EXTERNAL = external()

def clean_str(text):
    text = text.replace('&amp;', '&').replace('\xa0', ', ')
    # translate then normalize whitespace
    text = text.translate(_TRANS)
    return ' '.join(text.split())


def get_itemtype(itemtype, duration):
    itemtype_to_mtype = {'s': 'tvshow', 'v': 'episode'}
    m_type = itemtype_to_mtype.get(itemtype, 'movie')
    if itemtype == 'v' and duration > 3650: m_type = 'movie'
    return m_type


def get_tb_header():
    url = f'{git_url}/tb_c.txt'
    cache_key = 'get_bi_header'
    data = main_cache.get(cache_key)
    if not data:
        data = eval(request(url))
        logger(f'get_tb_header: {repr(data)}')
        if data: main_cache.set(cache_key, data)
    return data


class Common:
    tb_h = get_tb_header()
    handle = int(argv[1])
    is_external = external()

    @staticmethod
    def dlg_failed(mode):
        notification(mode)

    @staticmethod
    def random_generator(size=6, chars=string.ascii_uppercase + string.digits):
        # Added '# nosec' to suppress bandit warning since this is not used for security/cryptographic purposes.
        return ''.join(random.choice(chars) for _ in range(size))  # nosec

    @staticmethod
    # Parse string and extracts first match as a string
    # The default is to find the first match. Pass a 'number' if you want to match a specific match. So 1 would match
    # the second and so forth
    def find_single_match(text, pattern, number=0):
        try: return re.findall(pattern, text, flags=re.DOTALL)[number]
        except : return ''

    @staticmethod
    # Parse string and extracts multiple matches using regular expressions
    def find_multiple_matches(text, pattern):
        return re.findall(pattern, text, re.DOTALL)

    @staticmethod
    def open_url(url, headers=None):
        headers = Common.tb_h if headers is None else {}
        return request(url, headers=headers)

    @staticmethod
    def get_channels():
        data = Common.open_url('https://m7lib.dev/api/v1/channels/index.json', 'client')
        return loads(data)

    @staticmethod
    def search_channels(query):
        data = Common.open_url(f'{bi_url}/search/{query}')
        return loads(data)

    @staticmethod
    def _build_channel_listitem(mode, icon, fanart, title, meta, live):
        """
        Internal builder for channel items.
        Returns (url, listitem) without committing.
        """
        if not meta: meta = {}
        title = str(title)
        icon = icon or aicon
        item = make_listitem()
        item.setLabel(title)
        item.setArt({'thumb': icon, 'poster': icon, 'fanart': fanart})
        # watched/progress logic
        tmdb_id = str(meta.get('tmdb_id'))
        m_type = meta.get('media_type', 'movie')
        season = meta.get('season', '')
        episode = meta.get('episode', '')
        if not season and not episode: m_type = 'movie'
        if m_type == 'movie': watched_info, bookmarks = get_media_info('movie', None, None, False)
        else: watched_info, bookmarks = get_media_info('episode', None, None, False)
        playcount = get_watched_status(watched_info, tmdb_id, season, episode)
        progress = get_progress_percent(bookmarks, tmdb_id, season, episode)
        # logger(f'Common. tmdb_id: {tmdb_id} season, episode {season, episode} progress: {progress} playcount: {playcount}')
        meta.update({'media_type': m_type,'title': title, 'tvdb_id': tmdb_id, 'playcount': playcount, 'playback_percent': progress,})
        item = set_info(item, meta, {'imdb': tmdb_id, 'tmdb': tmdb_id, 'tvdb': ''}, progress)
        cm = []
        if progress:
            cm.append(('[B]Clear Progress[/B]', run_plugin % build_url({'mode': 'watched_status.erase_bookmark', 'media_type': m_type, 'tmdb_id': tmdb_id, 'season': season, 'episode': episode, 'refresh': 'true', 'watched_indicators': '0'})))
            item.setProperties({'WatchedProgress': progress})
        if playcount: cm.append(('[B]Mark Unwatched Infinite[/B]', run_plugin % build_url({'mode': 'watched_status.extra', 'action': 'mark_as_unwatched', 'media_type': m_type, 'tmdb_id': tmdb_id, 'tvdb_id': '', 'season': season, 'episode': episode, 'title': title,})))
        else: cm.append(('[B]Mark Watched Infinite[/B]', run_plugin % build_url({'mode': 'watched_status.extra', 'action': 'mark_as_watched', 'media_type': m_type, 'tmdb_id': tmdb_id, 'tvdb_id': '', 'season': season, 'episode': episode, 'title': title,})))
        item.addContextMenuItems(cm)
        # item.setProperties({'IsPlayable': 'false'})
        # logger(f'Common.add_channel 2meta: {meta}')
        if live: url = build_url({'mode': mode, 'pvr': '.pvr', 'title': title, 'meta': dumps(meta)})
        else: url = build_url({'mode': mode, 'title': title, 'meta': dumps(meta)})
        return url, item

    @staticmethod
    def _build_section_listitem(mode, icon, fanart, title, meta):
        """
        Internal builder for section items.
        Returns (url, listitem) without committing.
        """
        if not meta: meta = {}

        title = str(title) if title is not None else str(mode)
        icon = icon or aicon
        item = make_listitem()
        item.setLabel(title)
        item.setArt({'thumb': icon, 'poster': icon, 'fanart': fanart})
        tmdb = str(meta.get('tmdb_id'))
        if not meta.get('year'): meta['year'] = get_datetime().year
        meta.update({'title': title, 'tvdb_id': tmdb})
        cm = []
        cm.append((f'[B]Reload[/B] {title}', run_plugin % build_url({'mode': mode, 'title': title, 'rand': Common.random_generator(), 'meta': dumps(meta), 'rescrape': 'true' if 'bi-content' in mode else ''})))
        cm.append(('[B]Add to a Shortcut Folder[/B]', run_plugin % build_url({'mode': 'menu_editor.shortcut_folder_add_known', 'name': title, 'iconImage': icon, 'meta': dumps(meta), 'rescrape': 'false'})))
        item.addContextMenuItems(cm)
        item = set_info(item, meta, {'imdb': tmdb, 'tmdb': tmdb, 'tvdb': tmdb})
        url = build_url({'mode': mode, 'title': title, 'rand': Common.random_generator(), 'meta': dumps(meta), 'rescrape': 'false'})
        return url, item

    @staticmethod
    def add_channel(mode, icon, fanart, title=None, meta=None, live=True):
        url, item = Common._build_channel_listitem(mode, icon, fanart, title, meta, live)
        return add_item(handle=Common.handle, url=url, listitem=item, isFolder=False)

    @staticmethod
    def build_channel_item(mode, icon, fanart, title=None, meta=None, live=True):
        return Common._build_channel_listitem(mode, icon, fanart, title, meta, live)

    @staticmethod
    def add_section(mode, icon, fanart, title=None, meta=None):
        url, item = Common._build_section_listitem(mode, icon, fanart, title, meta)
        return add_item(handle=Common.handle, url=url, listitem=item, isFolder=True)

    @staticmethod
    def build_section_item(mode, icon, fanart, title=None, meta=None):
        return Common._build_section_listitem(mode, icon, fanart, title, meta)

    @staticmethod
    def aend_directory(_type):
        handle = Common.handle
        is_external = Common.is_external
        set_content(handle, _type)
        set_category(handle, 'Tubi')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode(f'view.{_type}', _type, is_external)

    @staticmethod
    def play(stream, channel='NO LABLE', _player=False):
        # logger(f'Common.play:: channel: {channel} type(stream): {type(stream)} stream: {stream}')
        if _player: kodi_player.play(stream, channel, _player)
        else:
            try: kodi_player(stream, channel=channel)
            except: logger(f'Common.play:: {channel} Error {print_exc()}')

    @staticmethod
    def get_stream_and_play(mode):
        url = f'{bi_url}/oz?slug={mode}'
        try:
            data = loads(Common.open_url(url))
            title = data.get('title', 'Not Found')
            stream = data.get('stream', '')
            # logger(f'Common.get_stream_and_play data: {data}')
            if 'm3u8' in stream: kodi_player(stream, channel=title)
            else: Common.dlg_failed(f'Can not found url for: {title}')
        except: logger(f'Common.get_stream_and_play Error {print_exc()}')


    @staticmethod
    def play_bi(params):
        try:
            stream_id = params['mode'].split('bi_play')[0]
            # logger(f'Common.play_bi:: meta: {meta}')
            Common.get_bi_stream(stream_id, params['meta'])
        except:
            logger(f'Common.play_bi Error {print_exc()}')
            Common.dlg_failed('play_bi Oops something went wrong.')

    @staticmethod
    def meta_update(meta, data):
        subtitles, duration, ratings = '', 3600, 'R'
        try: meta = loads(meta)
        except: return meta
        if subtitles := data.get('subtitles'):
            # logger(f'Common. subtitles: {repr(subtitles)} data: {repr(data)}')
            meta['subtitles'] = next((i['url'] for i in subtitles if 'English' in str(i)), '')
        if duration := data.get('duration'):
            try: meta['duration'] = int(duration)
            except ValueError: pass
        if ratings := data.get('ratings'):
            meta['mpaa'] = next((r.get('code') for r in ratings if 'code' in r), 'R')
        if imdb_id := data.get('imdb_id'):
            meta['imdb_id'] = imdb_id
        try:
            skip_data = data.get('credit_cuepoints') or {}
            skip_option = meta.get('skip_option') or {}
            # logger(f'Common.meta_update skip_option: {repr(skip_option)} skip_data: {repr(skip_data)}')
            intro_start = skip_data.get('intro_start')
            intro_end = skip_data.get('intro_end')
            postlude = skip_data.get('postlude')
            skip_option['skip'] = str(intro_end - intro_start) if intro_end and intro_start is not None else '50'
            skip_option['start'] = str(intro_start) if intro_start is not None else '10'
            eskip = int(duration) - int(postlude) if postlude else 300
            skip_option['eskip'] = 90 if eskip <= 10 else eskip
            meta['skip_option'] = skip_option
            # logger(f'Common.meta_update skip_option: {repr(skip_option)}')
        except: logger(f'Common.meta_update data: {data}\n Error {print_exc()}')
        return meta

    @staticmethod
    def get_bi_stream(stream_id, meta):
        cache_key = f'stream_{stream_id}'
        cached = main_cache.get(cache_key)
        if cached:
            try: return infinitePlayer().run(cached['stream'], meta)
            except : logger(f'Common.get_bi_stream cached Error {print_exc()}')

        url = f'{bi_url}/oz/videos/{stream_id}/content'
        try:
            data = loads(Common.open_url(url))
            title = data.get('title', 'Not Found')
            # logger(f'Common.get_bi_stream data: {type(data)} {repr(data)}\n {type(meta)} meta: {repr(meta)}')
            stream = data.get('url', '')
            meta = Common.meta_update(meta, data)
            # logger(f'Common. type: {type(meta)} meta: {repr(meta)}')
            if not stream:
                manifest_type = ('hlsv3', 'hlsv6_fairplay', 'hlsv6_playready_psshv0', 'hlsv6_widevine_nonclearlead',)
                try:
                    video_resources = data['video_resources']
                    if len(video_resources) > 1:
                        logger(f'Common. video_resources data: {data}')
                        list_items = [{'line1': 'url Type:  ' + i['type'] + ' ' + i['resolution']} for i in video_resources]
                        kwargs = {'items': dumps(list_items), 'heading': 'Set source to play.', 'narrow_window': 'true',}
                        choice = select_dialog(video_resources, **kwargs)
                        stream = choice['manifest'].get('url')
                    else: stream = [d['manifest'].get('url') for d in video_resources if d['manifest'].get('url') and d['type'] in manifest_type][0]
                except:
                    # logger(f'Common. no video_resources data: {data}')
                    if not confirm_dialog(text='like to Play video preview Are you sure?'): return
                    stream = data.get('video_preview_url')
                    Common.dlg_failed(f'preview url for: {title}')
                    # stream = re.sub(r'start(\d+)-end(\d+)', f'start0-end{duration}', stream)
            # logger(f'Common. stream: {stream}\ndumps(meta): {dumps(meta)}\ndata: {data}')
            if 'm3u8' in stream:
                try: meta_obj = loads(meta) if isinstance(meta, str) else meta
                except : meta_obj = meta
                main_cache.set(cache_key, {'stream': stream}, expiration=72)
                infinitePlayer().run(stream, dumps(meta_obj))
            elif '.mp4' in stream: kodi_player(stream, channel=title, direct_player=True)
            else: logger(f'Common. error data: {data}'); Common.dlg_failed(f'Can not found url for: {title}')
        except: logger(f'Common.get_bi_stream url: {url}\nError {print_exc()}'); Common.dlg_failed(f'Can not found url for: {url}')


class Stream(Common):
    @staticmethod
    def get_explore_org_streams():
        stream_list = []
        url = 'https://omega.explore.org/api/get_cam_group_info.json?id=79' # base64.b64decode(explore_org_base).decode('UTF-8')
        data = Common.open_url(url, 'client')
        json_results = loads(data)['data']['feeds']
        for stream in sorted(json_results, key=lambda k: k['title']):
            if stream.get('is_inactive') is False and stream.get('is_offline') is False and stream.get('video_id') is not None:
                if stream.get('thumb') == '': icon = f'https://i.ytimg.com/vi/{stream["video_id"]}/hqdefault.jpg'
                else: icon = stream['thumb']
                if stream.get('thumbnail_large_url') == '': fanart = f'https://i.ytimg.com/vi/{stream["video_id"]}/hqdefault.jpg'
                else: fanart = stream.get('thumbnail_large_url')
                meta = {'duration': 10, 'title': stream['title']}
                stream_list.append({'id': stream['video_id'], 'poster': icon, 'fanart': fanart, 'title': stream['title'], 'meta': dumps(meta, ensure_ascii=False),})
        if stream_list: return stream_list
        return None

    @staticmethod
    def get_bi_categories():
        url = f'{git_url}/json_data/categories.json'
        # logger(f'Stream. url {url}')
        data = Common.open_url(url, 'client')
        if data: return sorted(eval(str(data)), key=lambda d: d['title'])
        return None

    @staticmethod
    def get_bi_content(category):
        # url = f'{git_url}/json_data/{category}.json'
        url = f'{bi_url}/oz/containers/{category}/content?cursor=1&limit=250'
        data = Common.open_url(url)
        content_list = []
        # logger(f'Stream. data: {type(data)} {repr(data)}')

        try: json_results = loads(data)
        except: return logger(f'Stream.get_bi_content category {category} url: {url} data: {data} Error {print_exc()}')
        contents = json_results.get('contents') or {}
        for key in contents.keys():
            try:
                _item = contents[key]
                title_raw = _item.get('title', '')
                if item_cleaner.search(title_raw): continue
                if str(_item.get('lang')) != 'English': continue
                duration = int(_item.get('duration') or 1800)
                itemtype = get_itemtype(_item.get('type'), duration)
                year = _item.get('year') or get_datetime().year
                try: genre = generes_unify(_item.get('tags') or [], itemtype)
                except: genre = []
                plot = clean_str(_item.get('description') or '')
                try: icon = _item.get('posterarts')[0]
                except: icon = aicon
                try: mpaa = _item.get('ratings')[0]['value']
                except: mpaa = 'R'
                try: subtitles = _item.get('subtitles')[0]['url']
                except: subtitles = ''
                dur_min = duration // 60
                plot = f'mpaa: {mpaa}\nYear: {year}\nDuration: {dur_min} mins\nPlot: {plot}'
                title = clean_str(title_raw)
                title_id = title.replace("'", '').replace(':', '').lower()
                tmdb_id = f'{title_id}|{year}'
                fitem = {'id': _item.get('id'), 'type': _item.get('type'), 'title': title, 'mpaa': mpaa, 'tmdb_id': tmdb_id, 'imdb_id': tmdb_id, 'poster': icon, 'year': year, 'genre': genre, 'plot': plot, 'duration': duration, 'media_type': itemtype, 'disply_name': tmdb_id, 'subtitles': subtitles,}
                if itemtype == 'tvshow': fitem['tvshowtitle'] = title
                content_list.append(fitem)
            except: logger(f'Stream.get_bi_content category {category}  item: {key} Error {print_exc()}')
        return sorted(content_list, key=lambda d: (d['type'], d['title']))

    @staticmethod
    def get_bi_episodes(show, show_name):
        content_list = []
        url = f'{bi_url}/oz/videos/0{show[0]}/content'
        tvshowtitle = str(show_name)
        data = Common.open_url(url)
        try: json_results = loads(data)
        except: logger(f'Stream.get_bi_episodes category: {show} url: {url} data: {data} Error {print_exc()}'); return []
        # logger(f'Stream.get_bi_episodes\nshow: {show} url: {url}\n json_results: {json_results}')
        children = json_results.get('children') or []
        for sitem in range(len(children)):
            try:
                node = children[sitem]
                items = node.get('children') or []
                try: season = int(node.get('id'))
                except: season = None
                for epi in range(len(items)):
                    _item = items[epi]
                    title_raw = _item.get('title', '')
                    if item_cleaner.search(title_raw): continue
                    duration = int(_item.get('duration') or 1800)
                    year = _item.get('year') or get_datetime().year
                    genre = _item.get('tags') or []
                    plot = clean_str(_item.get('description') or '')
                    icon = (_item.get('thumbnails') or [aicon])[0]
                    try: episode = int(_item.get('episode_number'))
                    except: episode = None
                    try: mpaa = (_item.get('ratings') or [{'value': 'R'}])[0].get('value', 'R')
                    except: mpaa = 'R'
                    subtitles = (_item.get('subtitles') or [{}])[0].get('url', '')
                    title = clean_str(title_raw)
                    title_id = tvshowtitle.replace("'", '').replace(':', '').lower()
                    dur_min = duration // 60
                    plot = f'{tvshowtitle}:\nFrom: {show[1]}\nmpaa: {mpaa}\nYear: {year}\nDuration: {dur_min} mins\nPlot: {plot}'
                    tmdb_id = f'{title_id}|{year}'
                    content_list.append({'id': _item.get('id'), 'title': title, 'tmdb_id': tmdb_id, 'imdb_id': tmdb_id, 'poster': icon, 'year': year, 'genre': genre, 'plot': plot, 'duration': duration, 'media_type': 'episode', 'season': season, 'episode': episode, 'disply_name': title, 'tvshowtitle': tvshowtitle, 'ep_name': title, 'subtitles': subtitles,})
            except: logger(f'Stream.get_bi_episodes category: {show} Error {print_exc()}')
        return content_list

    @staticmethod
    def get_bi_search(query):
        content_list = []
        url = f'{bi_url}/oz/search/{query}'
        data = Common.open_url(url)
        try: json_results = loads(data)
        except: return []
        # logger(f'Stream.search json_results {json_results}')

        for _item in json_results:
            try:
                title_raw = _item.get('title', '')
                if item_cleaner.search(title_raw): continue
                duration = int(_item.get('duration') or 3600)
                year = _item.get('year') or get_datetime().year
                genre = _item.get('tags') or []
                plot = clean_str(_item.get('description') or '')
                try: icon = _item.get('posterarts')[0]
                except: icon = aicon
                try: mpaa = _item.get('ratings')[0]['value']
                except: mpaa = 'R'
                try: subtitles = _item.get('subtitles')[0]['url']
                except: subtitles = ''
                dur_min = duration // 60
                plot = f'mpaa: {mpaa}\nYear: {year}\nDuration: {dur_min} mins\nPlot: {plot}'
                title = clean_str(title_raw)
                itemtype = get_itemtype(_item.get('type'), duration)
                tmdb_id = f'{title}|{year}'
                fitem = {'id': _item.get('id'), 'type': _item.get('type'), 'title': title, 'mpaa': mpaa, 'tmdb_id': tmdb_id, 'imdb_id': tmdb_id, 'poster': icon, 'year': year, 'genre': genre, 'plot': plot, 'duration': duration, 'media_type': itemtype, 'disply_name': tmdb_id, 'subtitles': subtitles,}
                if itemtype == 'tvshow': fitem['tvshowtitle'] = title
                content_list.append(fitem)
            except: logger(f'Stream.get_bi_search _item: {_item} Error {print_exc()}')
        if content_list: return sorted(content_list, key=lambda d: (d['type'], d['title']))
        return None


class LiveChannels(Common):
    def __init__(self):
        Common.__init__(self)

    @staticmethod
    def channel_list():
        try:
            channels_list = main_cache.get('content_bi_livech_root')
            if not channels_list:
                channels_list = Common.get_channels()
                if channels_list: main_cache.set('content_bi_livech_root', channels_list, expiration=336) # 336 == 14 days cache

            # Generate Channel List
            # logger(f'LiveChannels.channels_list {channels_list}')
            ch_slugs = ['bloomberg', 'cbs-sports-hq', 'pbs-kids', 'stirr-news-247', 'stirr-bloomberg-tv', 'stirr-law-crime', 'stirr-nasatv', 'stirr-comet', 'stirr-contv', 'stirr-comedy-dynamics', 'stirr-failarmy', 'stirr-afv', 'stirr-johnny-carson-tv', 'stirr-unsolved-mysteries', 'stirr-forensics-files', 'stirr-greatest-american-hero', 'stirr-wiseguy', 'stirr-the-commish', 'stirr-hunter', 'stirr-crime-story', 'stirr-filmrise-free-movies', 'stirr-stirr-movies', 'stirr-cinehouse', 'stirr-docurama', 'stirr-stirr-sports', 'stirr-edgesport', 'stirr-wpt', 'stirr-filmrise-classic-tv', 'stirr-american-classics', 'stirr-britcom', 'stirr-the-lucy-show', 'stirr-the-lone-ranger', 'stirr-stirr-westerns', 'stirr-movie-mix', 'stirr-stirr-comedy', 'stirr-stirr-documentaries', 'stirr-stirr-travel', 'vuit-investigate-tv', 'vuit-wgcl-atlanta-ga', 'vuit-wtvm-columbus-ga', 'vuit-wagt-augusta-ga', 'vuit-wrdw-augusta-ga', 'vuit-politics-uncut', 'vuit-walb-albany-ga', 'vuit-wtoc-savannah-ga', 'xumo-nbc-news-now', 'xumo-abc-news-live', 'xumo-cbs-news', 'xumo-comedy-dynamics', 'xumo-cinelife', 'xumo-docurama', 'pluto-tv-kids', 'pluto-tv-news', 'pluto-cnn', 'pluto-bloomberg-tv', 'pluto-classic-movies-channel', 'pluto-tv-action', 'pluto-tv-science', 'pluto-tv-animals', 'pluto-funny-af', 'pluto-tv-true-crime', 'pluto-buzzr', 'pluto-xive-tv', 'pluto-tv-travel', 'pluto-tv-history', 'pluto-tv-comedy', 'pluto-tv-romance', 'pluto-fox-sports', 'pluto-the-new-detectives', 'pluto-tv-thrillers', 'pluto-tv-drama', 'pluto-cmt-westerns', 'pluto-unsolved-mysteries', 'pluto-tv-sci-fi', 'pluto-tv-fantastic', 'pluto-british-tv', 'pluto-tv-documentaries', 'pluto-tv-spotlight', 'pluto-forensic-files', 'pluto-tv-military', 'pluto-weather-nation', 'pluto-tv-land-sitcoms', 'pluto-cold-case-files', 'pluto-tv-cult-films', 'pluto-tv-terror', 'pluto-bet-tv', 'pluto-comedy-central-tv', 'pluto-nick-jr-tv', 'pluto-tv-backcountry', 'pluto-paramount-movie-channel', 'pluto-doctor-who-classic', 'pluto-nfl-channel', 'pluto-tv-land-drama', 'pluto-american-gladiators', 'pluto-baywatch', 'pluto-tv-lives', 'pluto-cmt-tv', 'pluto-pga-tour', 'pluto-bein-sports-xtra', 'pluto-nbc-news-now', 'pluto-cops', 'pluto-blaze-live', 'pluto-johnny-carson-tv', 'pluto-stories-by-amc', 'pluto-the-walking-dead-esp', 'pluto-western-tv', 'pluto-cbs-sports-hq', 'pluto-csi', 'pluto-star-trek-1', 'pluto-tv-suspense', 'pluto-classic-tv-comedy', 'pluto-classic-tv-drama-ptv1', 'pluto-the-amazing-race', 'pluto-tv-drama-life', 'pluto-tv-crime-drama', 'pluto-90210', 'pluto-tv-crime-movies', 'pluto-tv-staff-picks', 'pluto-narcos', 'pluto-showtime-selects', 'pluto-dr-oz', 'pluto-bbc-home',]
            Common.add_section('bi_livesearch', aicon, fanart, 'Search Channel')

            coll = []
            for channel in channels_list:
                try:
                    if channel.get('slug') in ch_slugs:
                        url, item = Common.build_channel_item(f'{channel["slug"]}bi_liveget_channel', channel.get('poster', aicon), fanart, channel.get('title', ''), {}, live=True)
                        coll.append((url, item, False))
                except : logger(f'{__name__} channel_list channel Error: {print_exc()}')
            if coll: add_items(Common.handle, coll)
            Common.aend_directory('episodes')
        except:
            logger(f'LiveChannels.channel_list Error {print_exc()}')
            Common.dlg_failed('Oops something went wrong.')

    @staticmethod
    def search_list():
        try:
            # Generate Channel List from search query
            retval = kodi_dialog().input('Search...', type=INPUT_ALPHANUM)
            if retval and len(retval) > 0:
                cache_key = f'content_bi_livech_search_{retval}'
                search_list = main_cache.get(cache_key)
                if not search_list:
                    search_list = Common.search_channels(retval)
                    if search_list: main_cache.set(cache_key, search_list, expiration=14) # 336 == 14 days cache
                if search_list:
                    coll = []
                    for channel in search_list:
                        try:
                            url, item = Common.build_channel_item(f'{channel["slug"]}bi_liveget_channel', channel.get('poster', aicon), fanart, channel.get('title', ''), {}, live=True)
                            coll.append((url, item, False))
                        except : logger(f'LiveChannels.search_list channel Error {print_exc()}')
                    if coll: add_items(Common.handle, coll)
                    Common.aend_directory('episodes')
                else: Common.dlg_failed('No results.')
            else: Common.dlg_failed('Please enter something to search for.')
        except:
            logger(f'LiveChannels.search_list Error {print_exc()}')
            Common.dlg_failed('Oops something went wrong.')

    @staticmethod
    def get_channel(params):
        try:
            mode = params['mode']
            mode = mode.split('bi_liveget_channel')[0]
            Common.get_stream_and_play(mode)
        except: logger(f'LiveChannels.get_channel Error {print_exc()}')


class Channels(Stream):
    @staticmethod
    def section_list(rescrape):
        try:
            Common.add_section('bi-search', aicon, fanart, 'Search Tubi')
            # logger(f'Channels.section_list rescrape: {rescrape}')
            if rescrape == 'true': main_cache.delete_like('content_bi_root%')
            section_list = main_cache.get('content_bi_root')
            if not section_list:
                # logger(f'Channels.section_list: {section_list}')
                section_list = Stream.get_bi_categories()
                if section_list: main_cache.set('content_bi_root', section_list, expiration=336) # 14 days cache

            coll = []
            for category in section_list:
                try:
                    url, item = Common.build_section_item(f'{category["id"]}bi-content', category.get('poster', aicon), fanart, category.get('title', ''), category)
                    coll.append((url, item, True))
                except : logger(f'Channels.section_list category Error: {print_exc()}')
            if coll: add_items(Common.handle, coll)
            Common.aend_directory('tvshows')
        except :
            logger(f'Channels.section_list Error {print_exc()}')
            Common.dlg_failed('Oops something went wrong.')

    @staticmethod
    def content_list(mode, rescrape):
        try:
            category = mode.split('bi-content')[0]
            cache_key = f'content_bi_{category}'
            if rescrape == 'true': main_cache.delete_like(cache_key + '%')
            content_list = main_cache.get(cache_key)
            if not content_list:
                content_list = Stream.get_bi_content(category)
                if content_list: main_cache.set(cache_key, content_list, expiration=168)  # 7 days cache

            coll = []
            for entry in content_list or []:
                try:
                    title = entry.get('title', '')
                    # if item_cleaner.search(title): continue
                    poster = entry.get('poster', aicon)
                    etype = entry.get('type')
                    if etype == 'v':
                        url, item = Common.build_channel_item(f'{entry["id"]}bi_play', poster, fanart, title, entry, live=False)
                        coll.append((url, item, False))
                    elif etype == 's':
                        url, item = Common.build_section_item(f'{entry["id"]}bi-episodes{category}', poster, fanart, title, entry)
                        coll.append((url, item, True))
                except : logger(f'Channels.content_list entry Error {print_exc()}')
            if coll: add_items(Common.handle, coll)
            Common.aend_directory('tvshows')
        except :
            logger(f'Channels.content_list mode: {mode} Error {print_exc()}')
            Common.dlg_failed('content_list Oops something went wrong.')

    @staticmethod
    def episode_list(params):
        try:
            show = params['title']
            mode = params['mode']
            mode = mode.split('bi-episodes')
            # logger(f'Channels.episode_list mode {mode}')
            cache_key = f'episodes_{show}_bi_{mode[1]}'
            episode_list = main_cache.get(cache_key)
            if not episode_list:
                episode_list = Stream.get_bi_episodes(mode, show)
                if episode_list: main_cache.set(cache_key, episode_list, expiration=72)  # 3 days cache

            if not episode_list:
                Common.dlg_failed('episode_list not avilable.')
                Common.aend_directory('episodes')
                return

            coll = []
            for entry in episode_list:
                try:
                    url, item = Common.build_channel_item(f'{entry["id"]}bi_play', entry.get('poster', aicon), fanart, entry.get('title', ''), entry, live=False)
                    coll.append((url, item, False))
                except : logger(f'Channels.episode_list entry Error {print_exc()}')
            if coll: add_items(Common.handle, coll)
            Common.aend_directory('episodes')
        except :
            logger(f'Channels.episode_list Error {print_exc()}')
            Common.dlg_failed('episode_list Oops something went wrong.')

    @staticmethod
    def search_bi():
        try:
            retval = kodi_dialog().input('Search bi', type=INPUT_ALPHANUM)
            if not retval:
                Common.dlg_failed('Please enter something to search for.')
                return

            cache_key = f'content_bi_search_{retval}'
            search_list = main_cache.get(cache_key)
            if not search_list:
                search_list = Stream.get_bi_search(retval)
                if search_list: main_cache.set(cache_key, search_list, expiration=336)

            if not search_list or len(search_list) <= 1:
                Common.dlg_failed('No results.')
                return

            coll = []
            for entry in search_list:
                try:
                    title = entry.get('title', '')
                    if item_cleaner.search(title): continue
                    poster = entry.get('poster', aicon)
                    etype = entry.get('type')
                    if etype == 'v':
                        url, item = Common.build_channel_item(f'{entry["id"]}bi_play', poster, fanart, title, entry, live=False)
                        coll.append((url, item, False))
                    elif etype == 's':
                        url, item = Common.build_section_item(f'{entry["id"]}bi-episodes', poster, fanart, title, entry)
                        coll.append((url, item, True))
                except : logger(f'Channels.search_bi entry Error {print_exc()}')
            if coll: add_items(Common.handle, coll)
            Common.aend_directory('tvshows')
        except :
            logger(f'Channels.search_bi Error {print_exc()}')
            Common.dlg_failed('search_bi Oops something went wrong.')
