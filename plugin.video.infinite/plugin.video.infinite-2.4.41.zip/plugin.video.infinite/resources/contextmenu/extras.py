# -*- coding: utf-8 -*-
import sys
from xbmc import executebuiltin

executebuiltin('RunPlugin(%s)' % sys.listitem.getProperty('infinite_extras_params'))
