# -*- coding: utf-8 -*-

from modules.kodi_utils import logger, get_setting, sleep
from windows.skip import Skip
from windows import open_window, create_window
import sys, time, datetime
# from caches import clean_databases


def testting():
    test_window()


def test_window():
    # windows.next_episode <<<<<<<<<
    meta = {'tmdb_id': 96488, 'tvdb_id': 371242, 'imdb_id': 'tt9310136', 'rating': 6.7, 'plot': 'Based on a true story that spanned more than 30 years in which a young man was charged and convicted of brutally murdering his mother. Each episode is structured around an interrogation taken directly from the real police case files, with the goal of turning the viewer into a detective.', 'tagline': 'Justice is a matter of perspective.', 'votes': 20, 'premiered': '2020-02-05', 'year': '2020', 'poster': 'https://image.tmdb.org/t/p/w185/oJAvkzejtQzqwsDjkd8Y0m2oDL9.jpg', 'fanart': 'https://image.tmdb.org/t/p/w300/mvUvM6MLriYmmzAuuOznpPjbVSO.jpg', 'genre': ['Drama', 'Crime'], 'title': 'Interrogation', 'original_title': 'Interrogation', 'english_title': '', 'season_data': [{'air_date': '2020-02-05', 'episode_count': 10, 'id': 138202, 'name': 'Season 1', 'overview': '', 'poster_path': '/rC9T7UGmRKPK0C0BRcQUywVE6ZU.jpg', 'season_number': 1}], 'alternative_titles': [], 'duration': 2700, 'rootname': 'Interrogation (2020)', 'imdbnumber': 'tt9310136', 'country': ['United States of America'], 'mpaa': 'TV-MA', 'trailer': 'plugin://plugin.video.youtube/play/?video_id=bIGBrzjbtks', 'country_codes': ['US'], 'writer': [], 'director': [], 'all_trailers': [{'iso_639_1': 'en', 'iso_3166_1': 'US', 'name': 'Official Trailer', 'key': 'bIGBrzjbtks', 'site': 'YouTube', 'size': 1080, 'type': 'Trailer', 'official': True, 'published_at': '2020-01-12T23:38:05.000Z', 'id': '5e63b121459ad60018570747'}], 'cast': [{'name': 'Peter Sarsgaard', 'role': 'David Russell', 'thumbnail': 'https://image.tmdb.org/t/p/w185/jOc4VjxPaOkWOqnLCxd8BJy9g5i.jpg'}, {'name': 'Kyle Gallner', 'role': 'Eric Fisher', 'thumbnail': 'https://image.tmdb.org/t/p/w185/xY40mgzeGCJrV6P5Vlh2TgIOmkR.jpg'}, {'name': 'David Strathairn', 'role': 'Henry Fisher', 'thumbnail': 'https://image.tmdb.org/t/p/w185/fhkvTcrCDPTAclTnE7sqQS1NZKq.jpg'}, {'name': 'Kodi Smit-McPhee', 'role': 'Chris Keller', 'thumbnail': 'https://image.tmdb.org/t/p/w185/sesCWba9NwPDYDZzbVLs7OgLOti.jpg'}], 'studio': ['CBS All Access'], 'extra_info': {'status': 'Canceled', 'type': 'Scripted', 'homepage': 'https://www.paramountplus.com/shows/interrogation/', 'created_by': 'John Mankiewicz, Anders Weidemann', 'next_episode_to_air': None, 'last_episode_to_air': {'air_date': '2020-02-05', 'episode_number': 10, 'id': 2071848, 'name': 'I.A. Sgt. Ian Lynch & Det. Brian Chen vs Trey Carano 2003', 'overview': "Twenty years after Mary Fisher's death, Internal Affairs Sgt. Lynch and Det. Chen fly to Texas to interview Trey Carano, a former friend of Eric's, who shares his account of Eric's whereabouts in the days and hours leading up to the murder.", 'production_code': '', 'runtime': 45, 'season_number': 1, 'show_id': 96488, 'still_path': '/yGgL588X4eF6vuAaMeDMiyRxAKQ.jpg', 'vote_average': 8.0, 'vote_count': 1}}, 'total_aired_eps': 10, 'mediatype': 'tvshow', 'total_seasons': 1, 'tvshowtitle': 'Interrogation', 'status': 'Canceled', 'poster2': 'https://assets.fanart.tv/fanart/tv/371242/tvposter/interrogation-5e3f0a6ff1c62.jpg', 'fanart2': 'https://assets.fanart.tv/fanart/tv/371242/showbackground/interrogation-5eb26359e9234.jpg', 'banner': 'https://assets.fanart.tv/fanart/tv/371242/tvbanner/interrogation-5edcd09889554.jpg', 'clearart': '', 'clearlogo': '', 'landscape': 'https://assets.fanart.tv/fanart/tv/371242/tvthumb/interrogation-5e3f0a8a0bb17.jpg', 'discart': '', 'keyart': '', 'fanart_added': True, 'clearlogo2': 'https://assets.fanart.tv/fanart/tv/371242/hdtvlogo/interrogation-5eb265b6c946e.png', 'ep_name': None, 'media_type': 'episode', 'season': 1, 'episode': 5, 'background': False, 'skip_option': {'title': 'Interrogation', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '60'}, 'skip_style': 'netflix'}
    # action = open_window(('windows.next_episode', 'NextEpisode'), 'next_episode.xml', meta=meta, function='confirm')
    action = open_window(('windows.next_episode', 'NextEpisode'), 'next_episode.xml', meta=meta, function='next_ep')
    # logger(f'action: {action}')

    # windows.skip <<<<<<<<<<
    skip_option = {'title': 'The Blacklist', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '300'}
    # # if get_setting('skip.dialog') == "Regular":
        # # buttonskip = open_window(('windows.skip', 'Skip'), 'skip_dialog.xml', skip_option=skip_option)
        # # # buttonskip = Skip("skip_dialog.xml", location, "default", "1080i", skip_option=self.skip_option)
    # # else:
        # # buttonskip = open_window(('windows.skip', 'Skip'), 'skip.xml', skip_option=skip_option)
    # windowstyle = get_setting('skip.dialog')
    # logger(f'windowstyle: {windowstyle.lower()}')
    # buttonskip = open_window(('windows.skip', 'Skip'), 'skipmulti.xml', skip_option=skip_option, focus_button=201, window_style=windowstyle.lower())
    # logger(f'buttonskip: {buttonskip}')

    # yes_no_progress_media <<<<<<<
    # from threading import Thread
    # # meta = {'mediatype': 'episode', 'year': 2022, 'plot': 'Monday   Friday\nCrime Patrol is an Indian Hindi crime anthology series created by Subramanian S.lyer for Sony Entertainment Television India and Sony Entertainment Television Asia. The Series Currently airing its fifth season.', 'title': 'Crime Patrol', 'studio': 'Sony', 'poster': 'https://www.desi-serials.cc/wp-content/uploads/2020/08/Crime-Patrol-300x169.jpg', 'homepage': 'https://www.desi-serials.cc/watch-online/sony-tv/crime-patrol-season-4-updateslatest/', 'genre': 'Monday   Friday, Crime, Drama, Mystery, Reality-TV', 'cast': [], 'tmdb_id': 'Sony|Crime Patrol', 'imdb_id': 'tt1921518', 'rating': 7.9, 'clearlogo': '', 'trailer': '', 'votes': 50, 'tagline': '', 'director': '', 'writer': '', 'episodes': 764, 'seasons': '1, 2, 3, 4, 23', 'extra_info': {'status': '', 'collection_id': ''}, 'tvdb_id': 'Sony|crime patrol', 'duration': 2520, 'mpaa': 'TV-MA', 'episode': 428, 'tvshowtitle': 'Crime Patrol', 'playcount': 0, 'original_title': 'Crime Patrol', 'total_seasons': 1, 'url': 'https://www.desi-serials.cc/crime-patrol-episode-28th-april-2022-watch-online/424912/', 'fanart': 'https://www.desi-serials.cc/wp-content/uploads/2020/08/Crime-Patrol-300x169.jpg', 'premiered': 2003, 'season': 1, 'ep_name': '28th April 2022', 'media_type': 'episode', 'background': False, 'skip_option': {'title': 'Crime Patrol', 'service': 'True', 'skip': '15', 'start': '10', 'eskip': '300'}}
    # kwargs = {'meta': meta, 'text': 'ok i see', 'enable_buttons': True, 'true_button': "Yes", 'false_button': "No", 'focus_button': 11}
    # open_window(('windows.confirm_progress_media', 'ConfirmProgressMedia'), 'confirm_progress_media.xml', **kwargs)

    # # windows.select_ok <<<<<<<<<<<<
    # from modules.kodi_utils import local_string, confirm_dialog, ok_dialog
    # confirm_dialog(heading='Infinite', text=local_string(32855), ok_label=local_string(32824), cancel_label=local_string(32828), top_space=True)
    # ok_dialog(heading='Infinite', text=local_string(32855))

def cache_test():
    ctime = datetime.datetime.now()
    current_time = int(time.mktime(ctime.timetuple()))
    clean_databases(current_time, database_check=False, silent=True)
    from modules.source_utils import sources
    providers = sources('true', 'episode')
    from indexers.hindi.lists import youtube_m3u
    youtube_m3u()
    from caches.h_cache import MainCache
    MainCache().clean_hindi_lists()
    logger(providers)
    from caches import clrCache_version_update
    clrCache_version_update(clr_cache=True, clr_navigator=False)
    from apis.trakt_api import trakt_sync_activities
    status = trakt_sync_activities()
    logger(f'status: {status}')


def dl_db_file():
    params = {
    'mode': 'downloader',
    'action': 'cloud_file',
    'name': 'metacache_test',
    'url': 'https://github.com/djp11r/repojp/blob/master/etc/allxml/metacache.db?raw=true',
    'media_type': 'file'}
    from modules.downloader import runner
    runner(params)