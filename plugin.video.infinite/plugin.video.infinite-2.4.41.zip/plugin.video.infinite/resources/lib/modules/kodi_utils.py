# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcvfs
from xbmcaddon import Addon
import sys
import json
import requests
import _strptime
import sqlite3 as database
from threading import Thread, activeCount
from urllib.parse import unquote, unquote_plus, urlencode, quote, parse_qsl, urlparse, quote_plus
from modules import icons
import traceback
import inputstreamhelper

__addon__ = Addon(id='plugin.video.infinite')
addon_version = __addon__.getAddonInfo('version')
player, xbmc_player, numeric_input, xbmc_monitor, translatePath = xbmc.Player(), xbmc.Player, xbmcgui.INPUT_NUMERIC, xbmc.Monitor, xbmcvfs.translatePath
get_infolabel, get_visibility, execute_JSON, window_xml_dialog = xbmc.getInfoLabel, xbmc.getCondVisibility, xbmc.executeJSONRPC, xbmcgui.WindowXMLDialog
monitor, window, dialog, progressDialog, progressDialogBG = xbmc.Monitor(), xbmcgui.Window(10000), xbmcgui.Dialog(), xbmcgui.DialogProgress(), xbmcgui.DialogProgressBG()
window_xml_left_action, window_xml_right_action, window_xml_up_action, window_xml_down_action, window_xml_info_action = 1, 2, 3, 4, 11
window_xml_selection_actions, window_xml_closing_actions, window_xml_context_actions = (7, 100), (9, 10, 13, 92), (101, 108, 117)
empty_poster, item_jump, item_next = icons.box_office, icons.item_jump, icons.item_next
tmdb_default_api, fanarttv_default_api = 'b370b60447737762ca38457bd77579b3', 'fa836e1c874ba95ab08a14ee88e05565'
img_url = 'https://i.imgur.com/%s'
database_path_raw = 'special://profile/addon_data/plugin.video.infinite/databases/'
current_dbs = ('navigator.db', 'watched.db', 'favourites.db', 'views.db', 'traktcache4.db', 'maincache.db', 'metacache.db', 'debridcache.db', 'providerscache2.db', 'hindi_maincache.db', 'hindi_metacache.db', 'skipintro.json')
infinite_settings_str, kodi_menu_cache_str, infinite_kodi_menu_cache_str = 'infinite_settings', 'kodi_menu_cache', 'infinite_kodi_menu_cache'
databases_path = translatePath(database_path_raw)
navigator_db = translatePath(''.join([database_path_raw, current_dbs[0]]))
watched_db = translatePath(''.join([database_path_raw, current_dbs[1]]))
favorites_db = translatePath(''.join([database_path_raw, current_dbs[2]]))
views_db = translatePath(''.join([database_path_raw, current_dbs[3]]))
trakt_db = translatePath(''.join([database_path_raw, current_dbs[4]]))
maincache_db = translatePath(''.join([database_path_raw, current_dbs[5]]))
metacache_db = translatePath(''.join([database_path_raw, current_dbs[6]]))
debridcache_db = translatePath(''.join([database_path_raw, current_dbs[7]]))
external_db = translatePath(''.join([database_path_raw, current_dbs[8]]))

hindi_db = translatePath(''.join([database_path_raw, current_dbs[9]]))
hindi_meta_db = translatePath(''.join([database_path_raw, current_dbs[10]]))
skipintro_db = translatePath(''.join([database_path_raw, current_dbs[11]]))
icon_directory = 'special://home/addons/plugin.video.infinite/resources/media/%s'
next_icon = translatePath(icon_directory % 'item_next.png')

userdata_path = translatePath('special://profile/addon_data/plugin.video.infinite/')
addon_settings = translatePath('special://home/addons/plugin.video.infinite/resources/settings.xml')
user_settings = translatePath('special://profile/addon_data/plugin.video.infinite/settings.xml')
addon_icon, addon_fanart = translatePath('special://home/addons/plugin.video.infinite/icon.png'), translatePath('special://home/addons/plugin.video.infinite/fanart.png')
myvideos_db_paths = {18: '116', 19: '119', 20: '119'}
movie_dict_removals = ('fanart_added', 'cast', 'poster', 'rootname', 'imdb_id', 'tmdb_id', 'tvdb_id', 'all_trailers', 'fanart', 'banner', 'clearlogo', 'clearlogo2', 'clearart',
			'landscape', 'discart', 'original_title', 'english_title', 'extra_info', 'alternative_titles', 'country_codes', 'fanarttv_fanart', 'fanarttv_poster', 'fanart2','poster2',
			'keyart', 'images')
tvshow_dict_removals = ('fanart_added', 'cast', 'poster', 'rootname', 'imdb_id', 'tmdb_id', 'tvdb_id', 'all_trailers', 'discart', 'total_episodes', 'total_seasons', 'fanart',
			'banner', 'clearlogo', 'clearlogo2', 'clearart', 'landscape', 'season_data', 'original_title', 'extra_info', 'alternative_titles', 'english_title', 'season_summary',
			'country_codes', 'fanarttv_fanart', 'fanarttv_poster', 'total_aired_eps', 'fanart2', 'poster2', 'keyart', 'images')
episode_dict_removals = ('thumb', 'guest_stars')

def append_path(_path):
	sys.path.append(translatePath(_path))

def local_string(string):
	try: string = int(string)
	except: return string
	try: string = str(__addon__.getLocalizedString(string))
	except: string = __addon__.getLocalizedString(string)
	return string

def build_url(url_params):
	return ''.join(['plugin://plugin.video.infinite/?', urlencode(url_params)])

def remove_meta_keys(dict_item, dict_removals):
	for k in dict_removals: dict_item.pop(k, None)
	return dict_item

def add_dir(url_params, list_name, handle, iconImage='folder', fanartImage=None, isFolder=True):
	fanart = fanartImage or addon_fanart
	icon = get_icon(iconImage)
	url = build_url(url_params)
	listitem = make_listitem()
	listitem.setLabel(list_name)
	listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': fanart, 'banner': icon})
	add_item(handle, url, listitem, isFolder)

def set_view_mode(view_type, content='files'):
	view_id = get_property('infinite_view_type_%s' % view_type)
	if not view_id:
		try:
			dbcon = database.connect(views_db, timeout=40.0, isolation_level=None)
			dbcur = dbcon.cursor()
			dbcur.execute("SELECT view_id FROM views WHERE view_type = ?", (str(view_type),))
			view_id = dbcur.fetchone()[0]
		except: return
	try:
		hold = 0
		sleep(100)
		while not container_content() == content:
			hold += 1
			if hold < 5000: sleep(1)
			else: return
		if view_id: execute_builtin('Container.SetViewMode(%s)' % view_id)
	except: return

def get_icon(image_name):
	# try: icon = getattr(icons, image_name)
	# except:
	icon = translate_path(icon_directory % image_name) + str('.png')
	return icon

def logger(function):
	xbmc.log('###Infinite###: %s' % (function), 1)
	#import xbmc
	# from datetime import datetime
	# from modules.kodi_utils import translate_path
	# notice = 1 if py_tools.isPY3 else 2
	# import os
	# log_file = os.path.join(translate_path('special://logpath/'), 'infinite.log')
	# with open(log_file, 'a', encoding='utf-8') as f:
		# # with open_file(log_file, 'a') as f:
		# # line = '###%s###:\n %s' % (heading, function)
		# line = "[%s %s] %s\n %s" % (datetime.now().date(), str(datetime.now().time())[:8], heading, function)
		# f.write(line.rstrip('\r\n')+'\n')


def get_property(prop):
	return window.getProperty(prop)

def set_property(prop, value):
	return window.setProperty(prop, value)

def clear_property(prop):
	return window.clearProperty(prop)

def addon(addon_id='plugin.video.infinite'):
	return Addon(id=addon_id)

def addon_installed(addon_id):
	return get_visibility('System.HasAddon(%s)' % addon_id)

def addon_enabled(addon_id):
	return get_visibility('System.AddonIsEnabled(%s)' % addon_id)

def add_item(handle, url, listitem, isFolder):
	xbmcplugin.addDirectoryItem(handle, url, listitem, isFolder)

def add_items(handle, item_list):
	xbmcplugin.addDirectoryItems(handle, item_list)

def set_content(handle, content):
	xbmcplugin.setContent(handle, content)

def set_category(handle, category):
	xbmcplugin.setPluginCategory(handle, category)

def set_sort_method(handle, method):
	if method == 'episodes': sort_method = xbmcplugin.SORT_METHOD_EPISODE
	elif method == 'files': sort_method = xbmcplugin.SORT_METHOD_FILE
	else: sort_method = xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE#label
	xbmcplugin.addSortMethod(handle, sort_method)

def end_directory(handle, cacheToDisc=None):
	if cacheToDisc == None: cacheToDisc = get_property(infinite_kodi_menu_cache_str) == 'true'
	xbmcplugin.endOfDirectory(handle, cacheToDisc=cacheToDisc)

def make_session(url='https://'):
	session = requests.Session()
	session.mount(url, requests.adapters.HTTPAdapter(pool_maxsize=100))
	return session	

def make_requests():
	return requests

def make_playlist(_type='video'):
	return xbmc.PlayList(xbmc.PLAYLIST_VIDEO) if _type == 'video' else xbmc.PlayList(xbmc.PLAYLIST_MUSIC)

def convert_language(lang):
	return xbmc.convertLanguage(lang, xbmc.ISO_639_2)

def supported_media():
	return xbmc.getSupportedMedia('video')

def path_exists(path):
	return xbmcvfs.exists(str(path))

def make_directory(path):
	xbmcvfs.mkdir(path)

def make_directories(path):
	xbmcvfs.mkdirs(path)

def open_file(_file, mode='r'):
	return xbmcvfs.File(_file, mode)

def copy_file(source, destination):
	return xbmcvfs.copy(source, destination)

def delete_file(_file):
	try: xbmcvfs.delete(_file)
	except Exception as e:
		logger(f'1 delete_file error: {repr(e)}')
		from os import unlink, remove
		try:
			unlink(_file)
			remove(_file)
		except Exception as e: logger(f'2 delete_file error: {repr(e)}')

def delete_folder(_folder, force=False):
	xbmcvfs.rmdir(_folder, force)

def rename_file(old, new):
	xbmcvfs.rename(old, new)

def list_dirs(location):
	return xbmcvfs.listdir(location)

def make_listitem():
	return xbmcgui.ListItem(offscreen=True)

def translate_path(path):
	return translatePath(path)

def sleep(time):
	return xbmc.sleep(time)

def execute_builtin(command):
	return xbmc.executebuiltin(command)

def get_kodi_version():
	return int(get_infolabel('System.BuildVersion')[0:2])

def current_skin():
	return xbmc.getSkinDir()

def current_window_id():
	return xbmcgui.Window(xbmcgui.getCurrentWindowId())

def get_video_database_path():
	return translate_path('special://profile/Database/MyVideos%s.db' % myvideos_db_paths[get_kodi_version()])

def show_busy_dialog():
	return execute_builtin('ActivateWindow(busydialognocancel)')

def hide_busy_dialog():
	execute_builtin('Dialog.Close(busydialognocancel)')
	execute_builtin('Dialog.Close(busydialog)')

def close_all_dialog():
	execute_builtin('Dialog.Close(all,true)')

def container_content():
	return get_infolabel('Container.Content')

def external_browse():
	return 'infinite' not in get_infolabel('Container.PluginName')

def widget_refresh():
	return execute_builtin('UpdateLibrary(video,special://skin/foo)')

def run_plugin(params):
	if isinstance(params, dict): params = build_url(params)
	return xbmc.executebuiltin('RunPlugin(%s)' % params)

def container_update(params):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin('Container.Update(%s)' % params)

def container_refresh():
	return execute_builtin('Container.Refresh')

def disable_enable_addon(addon_name='plugin.video.infinite'):
	try:
		execute_JSON(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled', 'params': {'addonid': addon_name, 'enabled': False}}))
		execute_JSON(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled', 'params': {'addonid': addon_name, 'enabled': True}}))
	except: pass

def update_local_addons():
	execute_builtin('UpdateLocalAddons')
	sleep(2500)

def progress_dialog(heading=32036, icon=addon_icon):
	from windows import create_window
	if isinstance(heading, int): heading = local_string(heading)
	progress_dialog = create_window(('windows.progress', 'Progress'), 'progress.xml', heading=heading, icon=icon)
	Thread(target=progress_dialog.run).start()
	return progress_dialog

def ok_dialog(heading=32036, text='', ok_label=32839, top_space=True):
	from windows import open_window
	if isinstance(heading, int): heading = local_string(heading)
	if isinstance(text, int): text = local_string(text)
	if isinstance(ok_label, int): ok_label = local_string(ok_label)
	if not text: text = '[CR][CR]%s' % local_string(32760)
	elif top_space: text = '[CR][CR]%s' % text
	kwargs = {'heading': heading, 'text': text, 'ok_label': ok_label}
	return open_window(('windows.select_ok', 'OK'), 'ok.xml', **kwargs)

def confirm_dialog(heading=32036, text='', ok_label=32839, cancel_label=32840, top_space=True, default_control=11):
	from windows import open_window
	if isinstance(heading, int): heading = local_string(heading)
	if isinstance(text, int): text = local_string(text)
	if isinstance(ok_label, int): ok_label = local_string(ok_label)
	if isinstance(cancel_label, int): cancel_label = local_string(cancel_label)
	if not text: text = '[CR][CR]%s' % local_string(32580)
	elif top_space: text = '[CR][CR]%s' % text
	kwargs = {'heading': heading, 'text': text, 'ok_label': ok_label, 'cancel_label': cancel_label, 'default_control': default_control}
	return open_window(('windows.select_ok', 'Confirm'), 'confirm.xml', **kwargs)

def select_dialog(function_list, **kwargs):
	from windows import open_window
	window_xml = kwargs.get('window_xml', 'select.xml')
	selection = open_window(('windows.select_ok', 'Select'), window_xml, **kwargs)
	if selection in ([], None): return None
	if kwargs.get('multi_choice', 'false') == 'true': return [function_list[i] for i in selection]
	return function_list[selection]

def confirm_progress_media(meta, text='', enable_buttons=False, true_button=32824, false_button=32828, focus_button=11, percent=0):
	if enable_buttons:
		from windows import open_window
		if isinstance(text, int): text = local_string(text)
		if isinstance(true_button, int): true_button = local_string(true_button)
		if isinstance(false_button, int): false_button = local_string(false_button)
		kwargs = {'meta': meta, 'text': text, 'enable_buttons': enable_buttons, 'true_button': true_button, 'false_button': false_button, 'focus_button': focus_button}
		return open_window(('windows.confirm_progress_media', 'ConfirmProgressMedia'), 'confirm_progress_media.xml', **kwargs)
	else:
		from windows import create_window
		progress_dialog = create_window(('windows.confirm_progress_media', 'ConfirmProgressMedia'), 'confirm_progress_media.xml', meta=meta)
		Thread(target=progress_dialog.run).start()
		return progress_dialog

def show_text(heading, text=None, file=None, font_size='small', kodi_log=False):
	from windows import open_window
	if isinstance(heading, int): heading = local_string(heading)
	if isinstance(text, int): text = local_string(text)
	heading = heading.replace('[B]', '').replace('[/B]', '')
	if file:
		with open(file, encoding='utf-8') as r: text = r.read()
	if kodi_log and confirm_dialog(heading='Infinite', text=local_string(32855), ok_label=local_string(32824), cancel_label=local_string(32828), top_space=True):
		import re
		# with open(file, encoding='utf-8') as r: text = r.readlines()
		# texts1 = [i for i in text if any(x in i.lower() for x in ('exception', 'error'))]
		try: 
			texts1 = re.compile("error(.*?)[\t ]*\r?\n[\t ]*", flags=re.DOTALL | re.IGNORECASE).findall(str(text))
			# logger(f'texts1: {type(texts1)} {texts1}')
			texts2 = re.compile("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--", flags=re.DOTALL | re.IGNORECASE).findall(str(text))
			# logger(f'texts2: {type(texts2)} {texts2}')
			text = texts1 + texts2
			# logger(f'texts2:{type(text)} {text}')
			with open(file, 'w', encoding='utf-8') as r: r.writelines(''.join(text))
		except: logger(f'error: {traceback.format_exc()}')
	text = ''.join(text)
	return open_window(('windows.textviewer', 'TextViewer'), 'textviewer.xml', heading=heading, text=text, font_size=font_size)

def notification(line1, time=5000, icon=None, sound=False):
	if isinstance(line1, int): line1 = local_string(line1)
	icon = icon or addon_icon
	if 'error' in line1.lower():
		import inspect
		func = inspect.currentframe().f_back
		funcat = 'not found'
		if 'plugin.video.infinite' in func.f_code.co_filename:
			funcat = func.f_code.co_filename.split('plugin.video.infinite')[1]
		logger("line_number: %s func name: %s func file: %s" % (func.f_lineno, func.f_code.co_name, funcat))
	xbmcgui.Dialog().notification(local_string(32036), line1, icon, time, sound)

def choose_view(view_type, content):
	handle = int(sys.argv[1])
	set_view_str = local_string(32547)
	settings_icon = get_icon('settings')
	listitem = make_listitem()
	listitem.setLabel(set_view_str)
	params_url = build_url({'mode': 'set_view', 'view_type': view_type})
	listitem.setArt({'icon': settings_icon, 'poster': settings_icon, 'thumb': settings_icon, 'fanart': addon_fanart, 'banner': settings_icon})
	add_item(handle, params_url, listitem, False)
	set_content(handle, content)
	end_directory(handle)
	set_view_mode(view_type, content)

def set_temp_highlight(temp_highlight):
	current_highlight = get_property('infinite.highlight')
	set_property('infinite.highlight', temp_highlight)
	return current_highlight

def restore_highlight(current_highlight):
	set_property('infinite.highlight', current_highlight)

def set_view(view_type):
	view_id = str(current_window_id().getFocusId())
	dbcon = database.connect(views_db, timeout=40.0, isolation_level=None)
	dbcur = dbcon.cursor()
	dbcur.execute('''PRAGMA synchronous = OFF''')
	dbcur.execute('''PRAGMA journal_mode = OFF''')
	dbcur.execute("INSERT OR REPLACE INTO views VALUES (?, ?)", (view_type, view_id))
	set_view_property(view_type, view_id)
	notification(get_infolabel('Container.Viewmode').upper(), time=500)

def set_view_property(view_type, view_id):
	set_property('infinite_view_type_%s' % view_type, view_id)

def set_view_properties():
	dbcon = database.connect(views_db, timeout=40.0, isolation_level=None)
	dbcur = dbcon.cursor()
	dbcur.execute('''PRAGMA synchronous = OFF''')
	dbcur.execute('''PRAGMA journal_mode = OFF''')
	dbcur.execute("SELECT * FROM views")
	view_ids = dbcur.fetchall()
	for item in view_ids: set_view_property(item[0], item[1])

def timeIt(func):
	# Thanks to 123Venom
	import time
	fnc_name = func.__name__
	def wrap(*args, **kwargs):
		started_at = time.time()
		result = func(*args, **kwargs)
		logger('%s.%s' % (__name__ , fnc_name), (time.time() - started_at))
		return result
	return wrap

def volume_checker(volume_setting):
	# 0% == -60db, 100% == 0db
	try:
		if get_visibility('Player.Muted'): return
		from modules.utils import string_alphanum_to_num
		max_volume = int(min(int(volume_setting), 100))
		current_volume_db = int(string_alphanum_to_num(get_infolabel('Player.Volume').split('.')[0]))
		current_volume_percent = int(100 - ((float(current_volume_db)/60)*100))
		if current_volume_percent > max_volume: execute_builtin('SetVolume(%d)' % int(max_volume))
	except: pass

def focus_index(index, sleep_time=100):
	sleep(sleep_time)
	current_window = current_window_id()
	focus_id = current_window.getFocusId()
	try: current_window.getControl(focus_id).selectItem(index)
	except: logger("focus_index Error: {}".format(traceback.format_exc()))

def clear_settings_window_properties():
	clear_property('infinite_settings')
	notification(32576, 2500)

def fetch_kodi_imagecache(image):
	result = None
	try:
		dbcon = database.connect(translate_path('special://database/Textures13.db'), timeout=40.0)
		dbcur = dbcon.cursor()
		dbcur.execute("SELECT cachedurl FROM texture WHERE url = ?", (image,))
		result = dbcur.fetchone()[0]
	except: pass
	return result

def get_all_icon_vars(include_values=False):
	if include_values: return [(k, v) for k, v in vars(icons).items() if not k.startswith('__') and (v.endswith('.png') or v.endswith('.jpg'))]
	else: return [k for k, v in vars(icons).items() if not k.startswith('__') and (v.endswith('.png') or v.endswith('.jpg'))]

def toggle_language_invoker():
	import xml.etree.ElementTree as ET
	close_all_dialog()
	sleep(100)
	addon_xml = translate_path('special://home/addons/plugin.video.infinite/addon.xml')
	current_addon_setting = get_setting('reuse_language_invoker', 'true')
	new_value = 'false' if current_addon_setting == 'true' else 'true'
	if not confirm_dialog(text=local_string(33018) % (current_addon_setting.upper(), new_value.upper()), top_space=False): return
	if new_value == 'true' and not confirm_dialog(text=33019): return
	tree = ET.parse(addon_xml)
	root = tree.getroot()
	for item in root.iter('reuselanguageinvoker'):
		item.text = new_value
		tree.write(addon_xml)
		break
	set_setting('reuse_language_invoker', new_value)
	ok_dialog(text=32576)
	execute_builtin('ActivateWindow(Home)')
	update_local_addons()
	disable_enable_addon()

def upload_logfile():
	# Thanks 123Venom
	if not confirm_dialog(text=32580): return
	show_busy_dialog()
	url = 'https://paste.kodi.tv/'
	log_file = translate_path('special://logpath/kodi.log')
	if not path_exists(log_file): return ok_dialog(text=33039)
	try:
		with open_file(log_file) as f: text = f.read()
		UserAgent = 'Fen %s' % __addon__.getAddonInfo('version')
		response = requests.post(''.join([url, 'documents']), data=text.encode('utf-8', errors='ignore'), headers={'User-Agent': UserAgent}).json()
		if 'key' in response: ok_dialog(text=''.join([url, response['key']]))
		else: ok_dialog(text=33039)
	except: ok_dialog(text=33039)
	hide_busy_dialog()

def open_settings(query, addon='plugin.video.infinite'):
	hide_busy_dialog()
	if query:
		try:
			button, control = 100, 80
			menu, function = query.split('.')
			execute_builtin('Addon.OpenSettings(%s)' % addon)
			execute_builtin('SetFocus(%i)' % (int(menu) - button))
			execute_builtin('SetFocus(%i)' % (int(function) - control))
		except: execute_builtin('Addon.OpenSettings(%s)' % addon)
	else: execute_builtin('Addon.OpenSettings(%s)' % addon)

def clean_settings():
	import xml.etree.ElementTree as ET
	def _make_content(dict_object):
		content = '<settings version="2">'
		new_line = '\n    '
		for item in dict_object:
			_id = item['id']
			if _id in active_settings:
				if 'default' in item and 'value' in item: content += '%s<setting id="%s" default="%s">%s</setting>' % (new_line, _id, item['default'], item['value'])
				elif 'default' in item: content += '%s<setting id="%s" default="%s"></setting>' % (new_line, _id, item['default'])
				elif 'value' in item: content += '%s<setting id="%s">%s</setting>' % (new_line, _id, item['value'])
				else: content += '%s<setting id="%s"></setting>' % new_line
		content += '\n</settings>'
		return content
	close_all_dialog()
	active_settings, current_user_settings = [], []
	active_append, current_append = active_settings.append, current_user_settings.append
	root = ET.parse(addon_settings).getroot()
	for i in root.findall('./category/setting'):
		setting_id = i.get('id')
		if setting_id: active_append(setting_id)
	root = ET.parse(user_settings).getroot()
	for i in root:
		dict_item = {}
		setting_id = i.get('id')
		setting_default = i.get('default')
		setting_value = i.text
		dict_item['id'] = setting_id
		if setting_value: dict_item['value'] = setting_value
		if setting_default: dict_item['default'] = setting_default
		current_append(dict_item)
	new_content = _make_content(current_user_settings)
	with open_file(user_settings, 'w') as f: f.write(new_content)
	notification(32576, 2500)

def set_setting(setting_id, value):
	addon().setSetting(setting_id, value)

def get_setting(setting_id, fallback=None):
	try: settings_dict = json.loads(get_property(infinite_settings_str))
	except: settings_dict = make_settings_dict()
	if settings_dict is None or setting_id not in settings_dict:
		settings_dict = get_setting_fallback(setting_id)
		make_settings_dict()
	value = settings_dict.get(setting_id, '')
	if value == '':
		if fallback is None: return value
		return fallback
	return value

def get_setting_fallback(setting_id):
	return {setting_id: addon().getSetting(setting_id)}

def make_settings_dict():
	import xml.etree.ElementTree as ET
	settings_dict = None
	clear_property(infinite_settings_str)
	try:
		if not path_exists(userdata_path): make_directories(userdata_path)
		root = ET.parse(user_settings).getroot()
		settings_dict = {}
		dict_update = settings_dict.update
		for item in root:
			setting_id = item.get('id')
			setting_value = item.text
			if setting_value is None: setting_value = ''
			dict_item = {setting_id: setting_value}
			dict_update(dict_item)
		set_property(infinite_settings_str, json.dumps(settings_dict))
	except: pass
	set_view_properties()
	set_property(infinite_kodi_menu_cache_str, get_setting(kodi_menu_cache_str))
	set_property('infinite.meta_filter', get_setting('meta_filter', 'false'))
	set_property('infinite.highlight', get_setting('infinite.highlight', 'dodgerblue'))
	return settings_dict

def pause_settings_change():
	set_property('infinite_pause_onSettingsChanged', 'true')

def unpause_settings_change():
	clear_property('infinite_pause_onSettingsChanged')


def set_resolvedurl(handle, item):
	xbmcplugin.setResolvedUrl(handle, True, item)

def decorate_log_error(log_lines):
	import re
	text = ''
	for line in log_lines:
		if not any(re.findall(r'INFO|NOTICE', line)):
			line = line.replace('ERROR', '[COLOR red]ERROR[/COLOR]:').replace('WARNING', '[COLOR gold]WARNING[/COLOR]:')
		text += line
	return text

def clear_cache_resolveurl():
	try:
		if confirm_dialog():
			if get_visibility('System.HasAddon(script.module.resolveurl)'):
				execute_builtin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_cache)')
			sleep(200)
			# notice = 'resolveurl reset cache'
		else: return
	except:
		notification(32574, time=2000)

def open_MyAccounts(params):
	from myaccounts import openMASettings
	openMASettings(params.get('query', '0.0'))
	sleep(100)
	while get_visibility('Window.IsVisible(addonsettings)') or get_property('myaccounts.active') == 'true': sleep(100)
	sleep(100)
	force_trakt_update = sync_MyAccounts()
	sleep(100)
	open_settings(params.get('return_query', '5.0'))
	if force_trakt_update:
		from apis.trakt_api import trakt_sync_activities
		trakt_sync_activities(force_update=True)

def sync_MyAccounts(silent=False):
	import myaccounts
	force_trakt_update = False
	all_acct = myaccounts.getAll()
	try:
		trakt_acct = all_acct.get('trakt')
		if trakt_acct.get('username') not in ('', None):
			if get_setting('trakt.user') != trakt_acct.get('username'):
				force_trakt_update = True
			set_setting('trakt_indicators_active', 'true')
			set_setting('watched_indicators', '1')
		else:
			set_setting('trakt_indicators_active', 'false')
			set_setting('watched_indicators', '0')
		set_setting('trakt.user', trakt_acct.get('username'))
		set_setting('trakt.expires', trakt_acct.get('expires'))
		set_setting('trakt.refresh', trakt_acct.get('refresh'))
		set_setting('trakt.token', trakt_acct.get('token'))
	except: pass
	# try:
		# fu_acct = all_acct.get('furk')
		# set_setting('furk_login', fu_acct.get('username'))
		# set_setting('furk_password', fu_acct.get('password'))
		# if fu_acct.get('api_key') != '': set_setting('furk_api_key', fu_acct.get('api_key'))
		# elif get_setting('furk_api_key') != '': kodi_utils.addon('script.module.myaccounts').setSetting('furk.api.key', get_setting('furk_api_key'))
	# except: pass
	# try:
		# en_acct = all_acct.get('easyNews')
		# set_setting('easynews_user', en_acct.get('username'))
		# set_setting('easynews_password', en_acct.get('password'))
	# except: pass
	# try:
		# tmdb_acct = all_acct.get('tmdb')
		# tmdb_key = tmdb_acct.get('api_key')
		# if not tmdb_key: tmdb_key = '050ee5c6c85883b200be501c878a2aed'
		# set_setting('tmdb_api', tmdb_key)
	# except: pass
	# try:
		# fanart_acct = all_acct.get('fanart_tv')
		# fanart_key = fanart_acct.get('api_key')
		# if not fanart_key: fanart_key = 'fe073550acf157bdb8a4217f215c0882'
		# set_setting('fanart_client_key', fanart_key)
	# except: pass
	try:
		imdb_acct = all_acct.get('imdb')
		set_setting('imdb_user', imdb_acct.get('user'))
	except: pass
	# try:
		# rd_acct = all_acct.get('realdebrid')
		# if get_setting('rd.username') != rd_acct.get('username'):
			# set_setting('rd.username', rd_acct.get('username'))
			# set_setting('rd.client_id', rd_acct.get('client_id'))
			# set_setting('rd.refresh', rd_acct.get('refresh'))
			# set_setting('rd.secret', rd_acct.get('secret'))
			# set_setting('rd.token', rd_acct.get('token'))
			# set_setting('rd.auth', rd_acct.get('token'))
	# except: pass
	# try:
		# pm_acct = all_acct.get('premiumize')
		# set_setting('pm.token', pm_acct.get('token'))
		# if get_setting('pm.account_id') != pm_acct.get('username'):
			# set_setting('pm.account_id', pm_acct.get('username'))
	# except: pass
	# try:
		# ad_acct = all_acct.get('alldebrid')
		# set_setting('ad.token', ad_acct.get('token'))
		# if get_setting('ad.account_id') != ad_acct.get('username'):
			# set_setting('ad.account_id', ad_acct.get('username'))
	# except: pass
	if not silent: notification(33030, time=1500)
	return force_trakt_update


def update_hindi_metadb():
	try:
		from modules.downloader import runner
		urls = ['https://raw.githubusercontent.com/djp11r/repo_n/mayb/etc/allxml/hindi_metacache.db?raw=true', 'https://raw.githubusercontent.com/djp11r/repo_n/mayb/etc/allxml/skipintro.json?raw=true']
		# urls = ['https://raw.githubusercontent.com/djp11r/repo_n/mayb/etc/allxml/skipintro.json']
		for url in urls:
			params = {
			'mode': 'downloader',
			'action': 'cloud_file',
			'name': 'metacache_test',
			'url': url,
			'media_type': 'file'}
			runner(params)
			notification(50040, time=2000)
	except:
		logger(f'Error: {traceback.format_exc()}')
		notification(32574, time=2000)

def refresh_artwork():
	if not confirm_dialog(): return
	database = database
	dbcon = database.connect(translate_path('special://database/Textures13.db'), timeout=40.0, isolation_level=None)
	dbcur = dbcon.cursor()
	dbcur.execute('''PRAGMA synchronous = OFF''')
	dbcur.execute('''PRAGMA journal_mode = OFF''')
	for item in ('icon.png', 'fanart.png'):
		try:
			icon_path = translate_path('special://home/addons/plugin.video.infinite/%s' % item)
			dbcur.execute("SELECT cachedurl FROM texture WHERE url = ?", (icon_path,))
			image = dbcur.fetchone()[0]
			removal_path = translate_path('special://thumbnails/%s' % image)
			delete_file(removal_path)
		except: pass
	sleep(200)
	execute_builtin('ReloadSkin()')
	sleep(500)
	notification(32576, time=2000)



def metadataClean(metadata):
	if not metadata: return metadata
	allowed = ('genre', 'country', 'year', 'episode', 'season', 'sortepisode', 'sortseason', 'episodeguide', 'showlink',
					'top250', 'setid', 'tracknumber', 'rating', 'userrating', 'watched', 'playcount', 'overlay', 'cast', 'castandrole',
					'director', 'mpaa', 'plot', 'plotoutline', 'title', 'originaltitle', 'sorttitle', 'duration', 'studio', 'tagline', 'writer',
					'tvshowtitle', 'premiered', 'status', 'set', 'setoverview', 'tag', 'imdbnumber', 'code', 'aired', 'credits', 'lastplayed',
					'album', 'artist', 'votes', 'path', 'trailer', 'dateadded', 'mediatype', 'dbid')
	return {k: v for k, v in metadata.items() if k in allowed}

def set_info(item, meta, setUniqueIDs, resumetime=0):
	if get_kodi_version() == 19:
		item.setUniqueIDs(setUniqueIDs)
		item.setCast(meta.get('cast', []) + meta.get('guest_stars', []))
		meta = metadataClean(meta)
		try: meta.pop('cast')
		except: pass
		item.setInfo('Video', meta)
		item.setProperty('resumetime', str(resumetime))
	else:
		# logger(f'meta : {meta}')
		meta_get = meta.get
		videoInfoTag = item.getVideoInfoTag()

		videoInfoTag.setMediaType(meta_get('mediatype'))
		videoInfoTag.setUniqueIDs(setUniqueIDs)
		videoInfoTag.setPath(meta_get('path'))
		videoInfoTag.setFilenameAndPath(meta_get('filenameandpath'))
		videoInfoTag.setTitle(item.getLabel() or meta_get('title'))
		videoInfoTag.setSortTitle(meta_get('sorttitle'))
		videoInfoTag.setOriginalTitle(meta_get('originaltitle'))
		videoInfoTag.setPlot(meta_get('plot'))
		videoInfoTag.setPlotOutline(meta_get('plotoutline'))
		videoInfoTag.setDateAdded(meta_get('dateadded'))
		videoInfoTag.setPremiered(meta_get('premiered'))
		videoInfoTag.setYear(int(meta_get('year', 0)))
		rating = meta_get('rating')
		if not rating: rating = 0.0
		videoInfoTag.setRating(float(rating))
		videoInfoTag.setMpaa(meta_get('mpaa'))
		videoInfoTag.setDuration(meta_get('duration', 0))
		videoInfoTag.setPlaycount(int(meta_get('playcount', 0)))
		videoInfoTag.setVotes(int(meta_get('votes', 0)))
		videoInfoTag.setLastPlayed(meta_get('lastplayed'))
		videoInfoTag.setAlbum(meta_get('album'))
		videoInfoTag.setGenres(meta_get('genre', []))
		videoInfoTag.setCountries(meta_get('country', []))
		videoInfoTag.setTags(meta_get('tag', []))
		videoInfoTag.setTrailer(meta_get('trailer'))
		videoInfoTag.setTagLine(meta_get('tagline'))
		videoInfoTag.setStudios(meta_get('studio', []))
		videoInfoTag.setWriters(meta_get('writer', []))
		videoInfoTag.setDirectors(meta_get('director', []))
		videoInfoTag.setIMDBNumber(meta_get('imdb_id'))
		videoInfoTag.setResumePoint(float(resumetime), meta_get('duration', 0))
		if meta_get('mediatype') in ['tvshow', 'season']:
			videoInfoTag.setTvShowTitle(meta_get('tvshowtitle'))
			videoInfoTag.setTvShowStatus(meta_get('status'))
		if meta_get('mediatype') in ['episodes', 'episode']:
			videoInfoTag.setTvShowTitle(meta_get('tvshowtitle'))
			videoInfoTag.setEpisode(int(meta_get('episode')))
			videoInfoTag.setSeason(int(meta_get('season')))
		cast_list = cast_tuple(meta_get('cast', []) + meta_get('guest_stars', []))
		videoInfoTag.setCast(cast_list)
	return item

def set_inputstream(url, listitem):
	inputstream = 'inputstream.adaptive'
	if 'm3u8' in url.lower() and inputstreamhelper.Helper('hls').check_inputstream():
		listitem.setProperty('inputstream', inputstream)
		listitem.setProperty('%s.manifest_type'%(inputstream), 'hls')
		listitem.setProperty('http-reconnect', 'true')
		listitem.setMimeType('application/vnd.apple.mpegurl')
	elif '.mpd' in url.lower():
		listitem.setProperty('inputstream', inputstream)
		listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
		listitem.setMimeType('application/dash+xml')
		listitem.setContentLookup(False)
	if '|' in url and ('m3u8' in url.lower() or '.mpd' in url.lower()):
		url, strhdr = url.split('|')
		listitem.setProperty('inputstream.adaptive.stream_headers', strhdr)
		listitem.setPath(url)
	return listitem

def cast_tuple(cast_list):
	cast = []
	for actor in cast_list:
		if isinstance(actor, dict):
			thumbnail = ''
			if 'thumbnail' in actor:
				thumbnail = actor.get('thumbnail', '')
			cast.append(xbmc.Actor(actor.get('name', ''), actor.get('role', ''), actor.get('order', 0), thumbnail))
		if isinstance(actor, list):
			cast.append(xbmc.Actor(actor, '', 0, ''))
	# logger(f'cast : {type(cast)}  {cast}')
	return cast

def list_to_string(_list):
	if isinstance(_list, list):
		_list = ', '.join([i for i in _list])
	return _list

def print_out_infoteg(listitem):
	videoInfoTag = listitem.getVideoInfoTag()
	logger(f'getMediaType       : {videoInfoTag.getMediaType()}')
	logger(f'getPath            : {videoInfoTag.getPath()}')
	logger(f'getFilenameAndPath : {videoInfoTag.getFilenameAndPath()}')
	logger(f'getTitle           : {videoInfoTag.getTitle()}')
	logger(f'getOriginalTitle   : {videoInfoTag.getOriginalTitle()}')
	logger(f'getPlot            : {videoInfoTag.getPlot()}')
	logger(f'getPlotOutline     : {videoInfoTag.getPlotOutline()}')
	logger(f'getYear            : {videoInfoTag.getYear()}')
	logger(f'getRating          : {videoInfoTag.getRating()}')
	logger(f'getDuration        : {videoInfoTag.getDuration()}')
	logger(f'getAlbum           : {videoInfoTag.getAlbum()}')
	logger(f'getTagLine         : {videoInfoTag.getTagLine()}')
	logger(f'getEpisode         : {videoInfoTag.getEpisode()}')
	logger(f'getSeason          : {videoInfoTag.getSeason()}')
	logger(f'getCast            : {videoInfoTag.getCast()}')
	try:
		logger(f'getPremieredAsW3C  : {videoInfoTag.getPremieredAsW3C()}')
		logger(f'getLastPlayedAsW3C : {videoInfoTag.getLastPlayedAsW3C()}')
		logger(f'getVotesAsInt      : {videoInfoTag.getVotesAsInt()}')
		logger(f'getGenres          : {videoInfoTag.getGenres()}')
		logger(f'getWriters         : {videoInfoTag.getWriters()}')
		logger(f'getDirectors       : {videoInfoTag.getDirectors()}')
		logger(f'getUniqueIDs       : {videoInfoTag.getUniqueIDs()}')
		logger(f'getSortTitle       : {videoInfoTag.getSortTitle()}')
		logger(f'getDateAdded       : {videoInfoTag.getDateAdded()}')
		logger(f'getMpaa            : {videoInfoTag.getMpaa()}')
		logger(f'getPlaycount       : {videoInfoTag.getPlaycount()}')
		logger(f'getCountries       : {videoInfoTag.getCountries()}')
		logger(f'getTags            : {videoInfoTag.getTags()}')
		logger(f'getStudios         : {videoInfoTag.getStudios()}')
		logger(f'getResumePoint     : {videoInfoTag.getResumePoint()}')
		logger(f'getTvShowTitle     : {videoInfoTag.getTvShowTitle()}')
		logger(f'getTvShowStatus    : {videoInfoTag.getTvShowStatus()}')
	except: pass
