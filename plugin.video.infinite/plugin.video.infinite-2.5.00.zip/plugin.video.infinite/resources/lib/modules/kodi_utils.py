# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcvfs, xbmcaddon
import sys
import json
import random
import requests
import _strptime
from os import path as osPath
from threading import Thread, activeCount
from urllib.parse import unquote, unquote_plus, urlencode, quote, parse_qsl, urlparse, quote_plus
from modules import icons

from traceback import print_exc
resolve = xbmcplugin.setResolvedUrl
from urllib3.util.retry import Retry
from xml.dom.minidom import parse as mdParse

addon_object = xbmcaddon.Addon('plugin.video.infinite')
player, xbmc_player, numeric_input, xbmc_monitor, translatePath, xbmc_actor = xbmc.Player(), xbmc.Player, 1, xbmc.Monitor, xbmcvfs.translatePath, xbmc.Actor
ListItem, getSkinDir, log, getCurrentWindowId, Window = xbmcgui.ListItem, xbmc.getSkinDir, xbmc.log, xbmcgui.getCurrentWindowId, xbmcgui.Window
File, exists, copy, delete, rmdir, rename = xbmcvfs.File, xbmcvfs.exists, xbmcvfs.copy, xbmcvfs.delete, xbmcvfs.rmdir, xbmcvfs.rename
get_infolabel, get_visibility, execute_JSON, window_xml_dialog = xbmc.getInfoLabel, xbmc.getCondVisibility, xbmc.executeJSONRPC, xbmcgui.WindowXMLDialog
executebuiltin, xbmc_sleep, convertLanguage, getSupportedMedia, PlayList = xbmc.executebuiltin, xbmc.sleep, xbmc.convertLanguage, xbmc.getSupportedMedia, xbmc.PlayList
monitor, window, dialog, progressDialog, progressDialogBG = xbmc_monitor(), Window(10000), xbmcgui.Dialog(), xbmcgui.DialogProgress(), xbmcgui.DialogProgressBG()
endOfDirectory, addSortMethod, listdir, mkdir, mkdirs = xbmcplugin.endOfDirectory, xbmcplugin.addSortMethod, xbmcvfs.listdir, xbmcvfs.mkdir, xbmcvfs.mkdirs
addDirectoryItem, addDirectoryItems, setContent, setCategory = xbmcplugin.addDirectoryItem, xbmcplugin.addDirectoryItems, xbmcplugin.setContent, xbmcplugin.setPluginCategory
window_xml_left_action, window_xml_right_action, window_xml_up_action, window_xml_down_action, window_xml_info_action = 1, 2, 3, 4, 11
window_xml_selection_actions, window_xml_closing_actions, window_xml_context_actions = (7, 100), (9, 10, 13, 92), (101, 108, 117)
try: from xbmc import VideoStreamDetail, AudioStreamDetail, SubtitleStreamDetail
except: VideoStreamDetail, AudioStreamDetail, SubtitleStreamDetail = {}, {}, {}
path_join = osPath.join
addon_info = addon_object.getAddonInfo
addon_path = addon_info('path')
userdata_path = translatePath(addon_info('profile'))
addon_icon = translatePath(addon_info('icon'))
default_addon_fanart = translatePath(addon_info('fanart'))
colorpalette_path = path_join(userdata_path, 'color_palette/')
colorpalette_zip_path = path_join(addon_path,'resources', 'media', 'color_palette.zip')
img_url = 'https://i.imgur.com/%s.png'
invoker_switch_dict = {'true': 'false', 'false': 'true'}
empty_poster, item_jump, nextpage = img_url % icons.box_office, img_url % icons.item_jump, img_url % icons.nextpage
nextpage_landscape, item_jump_landscape = img_url % icons.nextpage_landscape, img_url % icons.item_jump_landscape
tmdb_default_api = 'b370b60447737762ca38457bd77579b3'
int_window_prop, pause_services_prop = 'infinite.internal_results.%s', 'infinite.pause_services'
current_skin_prop, services_finished_prop = 'infinite.current_skin', 'infinite.services_finished'
myvideos_db_paths = {20: '121', 21: '122'}
sort_method_dict = {'episodes': 24, 'files': 5, 'label': 2}
playlist_type_dict = {'music': 0, 'video': 1}
tmdb_dict_removals = ('adult', 'backdrop_path', 'genre_ids', 'original_language', 'original_title', 'overview', 'popularity', 'vote_count', 'video', 'origin_country', 'original_name')
extras_button_label_values = {
				'movie':
					{'movies_play': 'Playback', 'show_trailers': 'Trailer', 'show_images': 'Images',  'show_extrainfo': 'Extra Info', 'show_genres': 'Genres',
					'show_director': 'Director', 'show_options': 'Options', 'show_media_images': 'Media Images', 'show_recommended': 'Recommended',
					'show_trakt_manager': 'Trakt Manager', 'playback_choice': 'Playback Options', 'show_favorites_manager': 'Favorites Manager', 'show_plot': 'Plot',
					'show_keywords': 'Keywords'},
				'tvshow':
					{'tvshow_browse': 'Browse', 'show_trailers': 'Trailer', 'show_images': 'Images', 'show_extrainfo': 'Extra Info', 'show_genres': 'Genres',
					'play_nextep': 'Play Next', 'show_options': 'Options', 'show_media_images': 'Media Images', 'show_recommended': 'Recommended',
					'show_trakt_manager': 'Trakt Manager', 'play_random_episode': 'Play Random', 'show_favorites_manager': 'Favorites Manager', 'show_plot': 'Plot',
					'show_keywords': 'Keywords'}}
movie_extras_buttons_defaults = [('extras.movie.button10', 'movies_play'), ('extras.movie.button11', 'show_trailers'), ('extras.movie.button12', 'show_keywords'),
					('extras.movie.button13', 'show_images'), ('extras.movie.button14', 'show_extrainfo'), ('extras.movie.button15', 'show_genres'),
					('extras.movie.button16', 'show_director'), ('extras.movie.button17', 'show_options')]
tvshow_extras_buttons_defaults = [('extras.tvshow.button10', 'tvshow_browse'), ('extras.tvshow.button11', 'show_trailers'), ('extras.tvshow.button12', 'show_keywords'),
					('extras.tvshow.button13', 'show_images'), ('extras.tvshow.button14', 'show_extrainfo'), ('extras.tvshow.button15', 'show_genres'),
					('extras.tvshow.button16', 'play_nextep'), ('extras.tvshow.button17', 'show_options')]
view_ids = ('view.main', 'view.movies', 'view.tvshows', 'view.seasons', 'view.episodes', 'view.episodes_single', 'view.premium')
video_extensions = ('m4v', '3g2', '3gp', 'nsv', 'tp', 'ts', 'ty', 'pls', 'rm', 'rmvb', 'mpd', 'ifo', 'mov', 'qt', 'divx', 'xvid', 'bivx', 'vob', 'nrg', 'img', 'iso', 'udf', 'pva',
					'wmv', 'asf', 'asx', 'ogm', 'm2v', 'avi', 'bin', 'dat', 'mpg', 'mpeg', 'mp4', 'mkv', 'mk3d', 'avc', 'vp3', 'svq3', 'nuv', 'viv', 'dv', 'fli', 'flv', 'wpl',
					'xspf', 'vdr', 'dvr-ms', 'xsp', 'mts', 'm2t', 'm2ts', 'evo', 'ogv', 'sdp', 'avs', 'rec', 'url', 'pxml', 'vc1', 'h264', 'rcv', 'rss', 'mpls', 'mpl', 'webm',
					'bdmv', 'bdm', 'wtv', 'trp', 'f4v', 'pvr', 'disc')
image_extensions = ('jpg', 'jpeg', 'jpe', 'jif', 'jfif', 'jfi', 'bmp', 'dib', 'png', 'gif', 'webp', 'tiff', 'tif',
					'psd', 'raw', 'arw', 'cr2', 'nrw', 'k25', 'jp2', 'j2k', 'jpf', 'jpx', 'jpm', 'mj2')
default_highlights = {'provider.rd_highlight': 'FF3C9900', 'provider.pm_highlight': 'FFFF3300', 'provider.ad_highlight': 'FFE6B800', 'provider.easynews_highlight': 'FF00B3B2',
					'provider.debrid_cloud_highlight': 'FF7A01CC', 'provider.folders_highlight': 'FFB36B00', 'scraper_4k_highlight': 'FFFF3334',
					'scraper_1080p_highlight': 'FFE6B800', 'scraper_720p_highlight': 'FF3C9900', 'scraper_SD_highlight': 'FFCAFFFF', 'scraper_single_highlight': 'FF008EB2'}

def get_icon(image_name):
	return img_url % getattr(icons, image_name, 'I1JJhji')

def get_addon_fanart():
	return get_property('infinite.addon_fanart') or default_addon_fanart

def build_url(url_params):
	return f'plugin://plugin.video.infinite/?{urlencode(url_params)}'

def add_dir(url_params, list_name, handle, iconImage='folder', fanartImage=None, isFolder=True):
	fanart = fanartImage or get_addon_fanart()
	icon = get_icon(iconImage)
	url = build_url(url_params)
	listitem = make_listitem()
	listitem.setLabel(list_name)
	listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': fanart, 'banner': fanart})
	info_tag = listitem.getVideoInfoTag()
	info_tag.setPlot(' ')
	add_item(handle, url, listitem, isFolder)

def empty_listing():
	handle = int(sys.argv[1])
	url = ''
	listitem = make_listitem()
	listitem.setLabel('')
	listitem.setArt({'icon': empty_poster, 'poster': empty_poster, 'thumb': empty_poster, 'fanart': '', 'banner': ''})
	info_tag = listitem.getVideoInfoTag()
	info_tag.setPlot(' ')
	add_item(handle, url, listitem, False)
	end_directory(handle)

def make_listitem():
	return ListItem(offscreen=True)

def add_item(handle, url, listitem, isFolder):
	addDirectoryItem(handle, url, listitem, isFolder)

def add_items(handle, item_list):
	addDirectoryItems(handle, item_list)

def set_content(handle, content):
	setContent(handle, content)

def set_category(handle, label):
	setCategory(handle, label)

def end_directory(handle, cacheToDisc=True):
	endOfDirectory(handle, cacheToDisc=cacheToDisc)

def set_view_mode(view_type, content='files', is_external=None):
	if is_external is None: is_external = external()
	if is_external: return
	view_id = get_property('infinite.%s' % view_type) or None
	if not view_id: return
	try:
		hold = 0
		sleep(100)
		while not container_content() == content:
			hold += 1
			if hold < 5000: sleep(1)
			else: return
		execute_builtin('Container.SetViewMode(%s)' % view_id)
	except: return

def remove_keys(dict_item, dict_removals):
	for k in dict_removals: dict_item.pop(k, None)
	return dict_item

def append_path(_path):
	sys.path.append(translatePath(_path))

def logger(heading, function=''):
	log(f'###Infinite###: {heading} {function}', 1)

def get_property(prop):
	return window.getProperty(prop)

def set_property(prop, value):
	return window.setProperty(prop, value)

def clear_property(prop):
	return window.clearProperty(prop)

def addon(addon_id='plugin.video.infinite'):
	return xbmcaddon.Addon(id=addon_id)

def addon_installed(addon_id):
	return get_visibility(f'System.HasAddon({addon_id})')

def addon_enabled(addon_id):
	return get_visibility(f'System.AddonIsEnabled({addon_id})')

def container_content():
	return get_infolabel('Container.Content')

def set_sort_method(handle, method):
	addSortMethod(handle, sort_method_dict[method])

def make_session(url='https://', total=3, backoff_factor=0.3, status_forcelist=(429, 500, 502, 503, 504, 520, 521, 522, 524, 530)):
	from requests.adapters import HTTPAdapter
	session = requests.Session()
	retries = Retry(total=total, backoff_factor=backoff_factor, status_forcelist=status_forcelist)
	session.mount(url, HTTPAdapter(max_retries=retries, pool_maxsize=100))
	return session

def make_playlist(playlist_type='video'):
	return PlayList(playlist_type_dict[playlist_type])

def convert_language(lang):
	return convertLanguage(lang, 1)

def supported_media():
	return getSupportedMedia('video')

def path_exists(path):
	return exists(str(path))

def open_file(_file, mode='r'):
	return File(_file, mode)

def copy_file(source, destination):
	return copy(source, destination)

def delete_file(_file):
	try: delete(_file)
	except Exception as e:
		logger(f'delete_file error: {repr(e)}')
		from os import unlink, remove
		try:
			unlink(_file)
			remove(_file)
		except Exception as e: logger(f'2 delete_file error: {repr(e)}')

def delete_folder(_folder, force=False):
	rmdir(_folder, force)

def rename_file(old, new):
	rename(old, new)

def list_dirs(location):
	return listdir(location)

def make_directory(path):
	mkdir(path)

def make_directories(path):
	mkdirs(path)

def translate_path(path):
	return translatePath(path)

def sleep(time):
	return xbmc_sleep(time)

def execute_builtin(command, block=False):
	return executebuiltin(command, block)

def current_skin():
	return getSkinDir()

def get_window_id():
	return getCurrentWindowId()

def current_window_object():
	return Window(get_window_id())

def kodi_version():
	return int(get_infolabel('System.BuildVersion')[0:2])

def get_video_database_path():
	return translate_path('special://profile/Database/MyVideos%s.db' % myvideos_db_paths[kodi_version()])

def show_busy_dialog():
	return execute_builtin('ActivateWindow(busydialognocancel)')

def hide_busy_dialog():
	execute_builtin('Dialog.Close(busydialognocancel)')
	execute_builtin('Dialog.Close(busydialog)')

def close_dialog(dialog, block=False):
	execute_builtin(f'Dialog.Close({dialog},true)', block)

def close_all_dialog():
	execute_builtin('Dialog.Close(all,true)')

def run_addon(addon='plugin.video.infinite', block=False):
	return execute_builtin(f'RunAddon({addon})', block)

def external():
	return 'infinite' not in get_infolabel('Container.PluginName')

def home():
	return getCurrentWindowId() == 10000

def folder_path():
	return get_infolabel('Container.FolderPath')

def path_check(string):
	return string in folder_path()

def reload_skin():
	execute_builtin('ReloadSkin()')

def kodi_refresh():
	execute_builtin('UpdateLibrary(video,special://skin/foo)')

def run_plugin(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin(f'RunPlugin({params})', block)

def container_update(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin(f'Container.Update({params})', block)

def activate_window(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin(f'ActivateWindow(Videos,{params},return)', block)

def container_refresh():
	return execute_builtin('Container.Refresh')

def container_refresh_input(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin(f'Container.Refresh({params})', block)

def replace_window(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin(f'ReplaceWindow(Videos,{params})', block)

def disable_enable_addon(addon_name='plugin.video.infinite'):
	try:
		execute_JSON(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled', 'params': {'addonid': addon_name, 'enabled': False}}))
		execute_JSON(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled', 'params': {'addonid': addon_name, 'enabled': True}}))
	except: pass

def update_local_addons():
	execute_builtin('UpdateLocalAddons', True)
	sleep(2500)
 
def update_kodi_addons_db(addon_name='plugin.video.infinite'):
	import time
	import sqlite3 as database
	try:
		date = time.strftime('%Y-%m-%d %H:%M:%S')
		dbcon = database.connect(translate_path('special://database/Addons33.db'), timeout=40.0)
		dbcon.execute("INSERT OR REPLACE INTO installed (addonID, enabled, lastUpdated) VALUES (?, ?, ?)", (addon_name, 1, date))
		dbcon.close()
	except Exception as e: logger(f'error update_kodi_addons_db {str(e)}')

def get_jsonrpc(request):
	response = execute_JSON(json.dumps(request))
	result = json.loads(response)
	return result.get('result', None)

def jsonrpc_get_directory(directory, properties=['title', 'file', 'thumbnail']):
	command = {'jsonrpc': '2.0', 'id': 1, 'method': 'Files.GetDirectory', 'params': {'directory': directory, 'media': 'files', 'properties': properties}}
	try: results = [i for i in get_jsonrpc(command).get('files') if i['file'].startswith('plugin://') and i['filetype'] == 'directory']
	except: results = None
	return results

def jsonrpc_get_addons(_type, properties=['thumbnail', 'name']):
	command = {'jsonrpc': '2.0', 'method': 'Addons.GetAddons','params':{'type':_type, 'properties': properties}, 'id': '1'}
	results = get_jsonrpc(command).get('addons')
	return results

def open_settings():
	from windows.base_window import open_window
	open_window(('windows.settings_manager', 'SettingsManager'), 'settings_manager.xml')

def external_scraper_settings():
	try:
		external = get_property('infinite.external_scraper.module')
		if external in ('empty_setting', ''): return
		execute_builtin('Addon.OpenSettings(%s)' % external)
	except: pass

def progress_dialog(heading='', icon=addon_icon):
	from windows.base_window import create_window
	progress_dialog = create_window(('windows.progress', 'Progress'), 'progress.xml', heading=heading, icon=icon)
	Thread(target=progress_dialog.run).start()
	return progress_dialog

def select_dialog(function_list, **kwargs):
	from windows.base_window import open_window
	selection = open_window(('windows.default_dialogs', 'Select'), 'select.xml', **kwargs)
	if selection in (None, []): return selection
	if kwargs.get('multi_choice', 'false') == 'true': return [function_list[i] for i in selection]
	return function_list[selection]

def confirm_dialog(heading='', text='Are you sure?', ok_label='OK', cancel_label='Cancel', default_control=11):
	from windows.base_window import open_window
	kwargs = {'heading': heading, 'text': text, 'ok_label': ok_label, 'cancel_label': cancel_label, 'default_control': default_control}
	return open_window(('windows.default_dialogs', 'Confirm'), 'confirm.xml', **kwargs)

def ok_dialog(heading='', text='No Results', ok_label='OK'):
	from windows.base_window import open_window
	kwargs = {'heading': heading, 'text': text, 'ok_label': ok_label}
	return open_window(('windows.default_dialogs', 'OK'), 'ok.xml', **kwargs)

def show_text(heading, text=None, file=None, font_size='small', kodi_log=False):
	from windows.base_window import open_window
	heading = heading.replace('[B]', '').replace('[/B]', '')
	if file:
		with open(file, encoding='utf-8', errors='ignore') as r: text = r.read()
		#with open(file, encoding='utf-8') as r: text = r.readlines()
	if kodi_log:
		confirm = confirm_dialog(text='Show Log Errors Only?', ok_label='Yes', cancel_label='No')
		if confirm is None: return
		if confirm:
			#text = [i for i in text if any(x in i.lower() for x in ('exception', 'error', '[test]'))]
			import re
			try:
				texts1 = re.compile('error(.*?)[\t ]*\r?\n[\t ]*', flags=re.DOTALL | re.IGNORECASE).findall(str(text))
				texts2 = re.compile('-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--', flags=re.DOTALL | re.IGNORECASE).findall(str(text))
				text = texts1 + texts2
				# logger(f'text: {text}')
				text = '\n'.join(text)
				# logger(f'texts1: {type(texts1)} {texts1} texts2: {type(texts2)} {texts2}  texts2:{type(text)} {text}')
				with open(file, 'w', encoding='utf-8', errors='ignore') as r: r.writelines(text)
			except: logger(f'error: {print_exc()}')
	return open_window(('windows.textviewer', 'TextViewer'), 'textviewer.xml', heading=heading, text=text, font_size=font_size)

def notification(line1, time=3000, icon=None, sound=False):
	icon = icon or addon_icon
	if 'error' in line1.lower():
		import inspect
		func = inspect.currentframe().f_back
		# allframs = inspect.getouterframes(inspect.currentframe())
		# logger(f'allframs: {allframs}')
		funcat = 'not found'
		if 'plugin.video.infinite' in func.f_code.co_filename:
			funcat = func.f_code.co_filename.split('plugin.video.infinite')[1]
		logger(f'line_number: {func.f_lineno} func name: {func.f_code.co_name} func file: {funcat}')
	dialog.notification('Infinite', line1, icon, time, sound)

def timeIt(func):
	# Thanks to 123Venom
	import time
	fnc_name = func.__name__
	def wrap(*args, **kwargs):
		started_at = time.time()
		result = func(*args, **kwargs)
		logger(f'{__name__}.{fnc_name} {time.time() - started_at}')
		return result
	return wrap

def volume_checker():
	# 0% == -60db, 100% == 0db
	try:
		if get_property('infinite.playback.volumecheck_enabled') == 'false' or get_visibility('Player.Muted'): return
		from modules.utils import string_alphanum_to_num
		max_volume = min(int(get_property('infinite.playback.volumecheck_percent') or '50'), 100)
		if int(100 - (float(string_alphanum_to_num(get_infolabel('Player.Volume').split('.')[0]))/60)*100) > max_volume: execute_builtin('SetVolume(%d)' % max_volume)
	except: pass

def focus_index(index, sleep_time=1000):
	show_busy_dialog()
	sleep(sleep_time)
	current_window = current_window_object()
	focus_id = current_window.getFocusId()
	try: current_window.getControl(focus_id).selectItem(index)
	except: logger(f'focus_index Error: {print_exc()}')
	hide_busy_dialog()

def get_all_icon_vars(include_values=False):
	if include_values: return [(k, v) for k, v in vars(icons).items() if not k.startswith('__')]
	else: return [k for k, v in vars(icons).items() if not k.startswith('__')]

def toggle_language_invoker():
	from xml.dom.minidom import parse as mdParse
	close_all_dialog()
	addon_xml = translate_path('special://home/addons/plugin.video.infinite/addon.xml')
	root = mdParse(addon_xml)
	invoker_instance = root.getElementsByTagName('reuselanguageinvoker')[0].firstChild
	current_invoker_setting = invoker_instance.data
	new_value = invoker_switch_dict[current_invoker_setting]
	if not confirm_dialog(text='Turn [B]Reuse Langauage Invoker[/B] %s?' % ('On' if new_value == 'true' else 'Off')): return
	invoker_instance.data = new_value
	new_xml = str(root.toxml()).replace('<?xml version="1.0" ?>', '')
	with open(addon_xml, 'w', errors='ignore') as f: f.write(new_xml)
	set_property(services_finished_prop, 'false')
	execute_builtin('ActivateWindow(Home)', True)
	update_local_addons()
	disable_enable_addon()

def unzip(zip_location, destination_location, destination_check, show_busy=True):
	if show_busy: show_busy_dialog()
	try:
		from zipfile import ZipFile
		zipfile = ZipFile(zip_location)
		zipfile.extractall(path=destination_location)
		if path_exists(destination_check): status = True
		else: status = False
	except: status = False
	if show_busy: hide_busy_dialog()
	return status

def upload_logfile(params):
	log_files = [('Current Kodi Log', 'kodi.log'), ('Previous Kodi Log', 'kodi.old.log')]
	list_items = [{'line1': i[0]} for i in log_files]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Choose Which Log File to Upload', 'narrow_window': 'true'}
	log_file = select_dialog(log_files, **kwargs)
	if log_file is None: return
	log_name, log_file = log_file
	if not confirm_dialog(heading=log_name): return
	show_busy_dialog()
	url = 'https://paste.kodi.tv/'
	log_file = translate_path(f'special://logpath/{log_file}')
	if not path_exists(log_file): return ok_dialog(text='Error. Log Upload Failed')
	try:
		with open_file(log_file) as f: text = f.read()
		UserAgent = 'infinite %s' % addon_info('version')
		response = requests.post('%s%s' % (url, 'documents'), data=text.encode('utf-8', errors='ignore'), headers={'User-Agent': UserAgent}).json()
		user_code = response['key']
		if 'key' in response:
			try:
				from modules.utils import copy2clip
				copy2clip('%s%s' % (url, user_code))
			except: pass
			ok_dialog(text=f'{url}{user_code}' )
		else: ok_dialog(text='Error. Log Upload Failed')
	except: ok_dialog(text='Error. Log Upload Failed')
	hide_busy_dialog()





def restart_services(silent=True):
	if not silent:
		if not confirm_dialog(): return
	execute_builtin('ActivateWindow(Home)', True)
	sleep(1000)
	Thread(target=disable_enable_addon).start()

def make_requests():
	return requests

def metadataClean(metadata):
	if not metadata: return metadata
	allowed = ('genre', 'country', 'year', 'episode', 'season', 'sortepisode', 'sortseason', 'episodeguide', 'showlink',
				'top250', 'setid', 'tracknumber', 'rating', 'userrating', 'watched', 'playcount', 'overlay', 'cast', 'castandrole',
				'director', 'mpaa', 'plot', 'plotoutline', 'title', 'originaltitle', 'sorttitle', 'duration', 'studio', 'tagline', 'writer',
				'tvshowtitle', 'premiered', 'status', 'set', 'setoverview', 'tag', 'imdbnumber', 'code', 'aired', 'credits', 'lastplayed',
				'album', 'artist', 'votes', 'path', 'trailer', 'dateadded', 'mediatype', 'dbid')
	return {k: v for k, v in metadata.items() if k in allowed}

def set_info(item, meta, setUniqueIDs=None, resumetime=''):
	if resumetime: resumetime = float(resumetime)
	# if isinstance(meta, str): meta = json.loads(meta)
	try:
		meta_get = meta.get
		info_tag = item.getVideoInfoTag()
		info_tag.setMediaType(meta_get('mediatype'))
		if setUniqueIDs: info_tag.setUniqueIDs(setUniqueIDs)
		info_tag.setPath(meta_get('path'))
		info_tag.setFilenameAndPath(meta_get('filenameandpath'))
		info_title = item.getLabel() if meta_get('title') == '' else meta_get('title')
		info_tag.setTitle(info_title)
		info_tag.setSortTitle(meta_get('sorttitle'))
		info_tag.setOriginalTitle(meta_get('originaltitle') or meta_get('original_title'))
		info_tag.setPlot(meta_get('plot'))
		info_tag.setPlotOutline(meta_get('plotoutline'))
		info_tag.setDateAdded(meta_get('dateadded'))
		info_tag.setPremiered(meta_get('premiered', '2024-1-1'))
		info_tag.setYear(convert_type(int, meta_get('year', 2024)))
		info_tag.setRating(convert_type(float, meta_get('rating', 4.5)))
		info_tag.setMpaa(meta_get('mpaa'))
		info_tag.setDuration(meta_get('duration', 0))
		info_tag.setPlaycount(convert_type(int , meta_get('playcount', 0)))
		if isinstance(meta_get('votes'), str): meta_votes = str(meta_get('votes')).replace(',', '')
		else: meta_votes = meta_get('votes')
		if meta_votes: info_tag.setVotes(convert_type(int, meta_votes))
		info_tag.setLastPlayed(meta_get('lastplayed'))
		info_tag.setAlbum(meta_get('album'))
		info_tag.setTags(meta_get('tag', []))
		info_tag.setTagLine(meta_get('tagline'))
		try:
			info_tag.setGenres(convert_type(list, meta_get('genre')))
			info_tag.setWriters(convert_type(list, meta_get('writer')))
			info_tag.setDirectors(convert_type(list, meta_get('director')))
			info_tag.setCountries(convert_type(list, meta_get('country')))
			info_tag.setTrailer(convert_type(str, meta_get('trailer')))
			info_tag.setStudios(convert_type(list, meta_get('studio')))
		except: logger(f'set_info meta : {meta} error: {print_exc()}')
		info_tag.setIMDBNumber(meta_get('imdb_id'))
		if resumetime and meta_get('duration'): info_tag.setResumePoint(resumetime, meta_get('duration'))
		elif resumetime: info_tag.setResumePoint(resumetime)
		if meta_get('mediatype') in ('tvshow', 'season', 'episode'):
			info_tag.setTvShowTitle(meta_get('tvshowtitle'))
			info_tag.setTvShowStatus(meta_get('status'))
		if meta_get('mediatype') in ('episodes', 'episode'):
			info_tag.setEpisode(convert_type(int, meta_get('episode')))
			info_tag.setSeason(convert_type(int, meta_get('season')))
		try: info_tag.setCast([xbmc_actor(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in meta_get('cast', [])])
		except: info_tag.setCast([xbmc_actor(name=item, role='', thumbnail='') for item in meta_get('cast', [])])
	except: logger(f'set_info meta : {meta} error: {print_exc()}')
	return item

def convert_type(_type, _value):
	try: return _type(_value)
	except TypeError as Err: return _type()
	except Exception as Err: logger(f'convert_type error: {Err}')

def set_inputstream(url, listitem):
	try: import inputstreamhelper
	except: inputstreamhelper = None
	if not inputstreamhelper: return listitem
	listitem.setMimeType('application/xml+dash')
	listitem.setContentLookup(False)
	listitem.setProperty('inputstream', 'inputstream.adaptive')
	listitem.setProperty('inputstream.adaptive.max_bandwidth', '100000000000')
	listitem.setProperty('http-reconnect', 'true')
	if 'hls' in url.lower(): #and inputstreamhelper.Helper('hls').check_inputstream():
		listitem.setMimeType('application/vnd.apple.mpegurl')
	elif '.ism' in url.lower():
		listitem.setMimeType('application/vnd.ms-sstr+xml')
	if '|' in url: # and ('m3u8' in url.lower() or '.mpd' in url.lower()):
		url, strhdr = url.split('|')
		listitem.setProperty('inputstream.adaptive.stream_headers', strhdr)
	# listitem.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
	# license_headers = {
		# 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0',
		# 'Content-Type': 'application/octet-stream',
		# 'Origin': 'https://www.somesite.com'
	# }
	# from urllib.parse import urlencode
	# license_config = { # for Python < v3.7 you should use OrderedDict to keep order
		# 'license_server_url': 'https://license.server.com/licenserequest',
		# 'headers': urlencode(license_headers),
		# 'post_data': 'R{SSM}',
		# 'response_data': 'R'
	# }
	# listitem.setProperty('inputstream.adaptive.license_key', '|'.join(license_config.values()))
	# listitem.setPath(url)
	return listitem

def print_out_infoteg(listitem):
	info_tag = listitem.getVideoInfoTag()
	logger(f'getMediaType       : {info_tag.getMediaType()}')
	logger(f'getPath            : {info_tag.getPath()}')
	logger(f'getFilenameAndPath : {info_tag.getFilenameAndPath()}')
	logger(f'getTitle           : {info_tag.getTitle()}')
	logger(f'getOriginalTitle   : {info_tag.getOriginalTitle()}')
	logger(f'getPlot            : {info_tag.getPlot()}')
	logger(f'getPlotOutline     : {info_tag.getPlotOutline()}')
	logger(f'getYear            : {info_tag.getYear()}')
	logger(f'getRating          : {info_tag.getRating()}')
	logger(f'getDuration        : {info_tag.getDuration()}')
	logger(f'getAlbum           : {info_tag.getAlbum()}')
	logger(f'getTagLine         : {info_tag.getTagLine()}')
	logger(f'getEpisode         : {info_tag.getEpisode()}')
	logger(f'getSeason          : {info_tag.getSeason()}')
	logger(f'getCast            : {info_tag.getCast()}')
	try:
		logger(f'getPremieredAsW3C  : {info_tag.getPremieredAsW3C()}')
		logger(f'getLastPlayedAsW3C : {info_tag.getLastPlayedAsW3C()}')
		logger(f'getVotesAsInt      : {info_tag.getVotesAsInt()}')
		logger(f'getGenres          : {info_tag.getGenres()}')
		logger(f'getWriters         : {info_tag.getWriters()}')
		logger(f'getDirectors       : {info_tag.getDirectors()}')
		logger(f'getUniqueIDs       : {info_tag.getUniqueIDs()}')
		logger(f'getSortTitle       : {info_tag.getSortTitle()}')
		logger(f'getDateAdded       : {info_tag.getDateAdded()}')
		logger(f'getMpaa            : {info_tag.getMpaa()}')
		logger(f'getPlaycount       : {info_tag.getPlaycount()}')
		logger(f'getCountries       : {info_tag.getCountries()}')
		logger(f'getTags            : {info_tag.getTags()}')
		logger(f'getStudios         : {info_tag.getStudios()}')
		logger(f'getResumePoint     : {info_tag.getResumePoint()}')
		logger(f'getTvShowTitle     : {info_tag.getTvShowTitle()}')
		logger(f'getTvShowStatus    : {info_tag.getTvShowStatus()}')
	except: logger(f'print_out_infoteg Error: {print_exc()}')


def kodi_player(url, channel='NO LABLE', direct_player=False):
	# logger(f'Common play:: channel: {channel} type(url): {type(url)} url: {url}')
	if direct_player:
		try:
			execute_builtin('PlayMedia(%s)' % url)
			# listitem = make_listitem()
			# listitem.setContentLookup(False)
			# info_tag = listitem.getVideoInfoTag()
			# info_tag.setMediaType('video')
			# info_tag.setTitle(str(channel))
			# info_tag.setFilenameAndPath(url)
			# listitem.setLabel(channel)
			# listitem.setPath(url)
			# listitem = set_inputstream(url, listitem)
			# player.play(url, listitem)
			hide_busy_dialog()
		except: logger(f'Common play:: {channel} Error {print_exc()}')
	else:
		from modules.player import infinitePlayer
		try: infinitePlayer().run(url, 'video', {'title': channel})
		except: logger(f'Common play:: {channel} Error {print_exc()}')

def set_resolvedurl(handle, item):
	resolve(handle, True, item)

def decorate_log_error(log_lines):
	import re
	text = ''
	for line in log_lines:
		if not any(re.findall(r'INFO|NOTICE', line)):
			line = line.replace('ERROR', '[COLOR red]ERROR[/COLOR]:').replace('WARNING', '[COLOR gold]WARNING[/COLOR]:')
		text += line
	return text

def clear_cache_resolveurl():
	try:
		if confirm_dialog():
			if get_visibility('System.HasAddon(script.module.resolveurl)'):
				execute_builtin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_cache)')
			sleep(200)
			# notice = 'resolveurl reset cache'
		else: return
	except:
		notification('resolveurl reset cache', time=2000)

def open_external_settings(params):
	addon = params.get('addon')
	execute_builtin(f'Addon.OpenSettings({addon})')
	sleep(100)
	while get_visibility('Window.IsVisible(addonsettings)'): sleep(100)
	sleep(100)
	if 'myaccounts' == addon:
		force_trakt_update = sync_myaccounts()
		sleep(100)
		if force_trakt_update:
			from apis.trakt_api import trakt_sync_activities
			trakt_sync_activities(force_update=True)

def sync_myaccounts(silent=False):
	from myaccounts import getAll
	from caches.settings_cache import get_setting, set_setting
	force_trakt_update = False
	all_acct = getAll()
	try:
		trakt_acct = all_acct.get('trakt')
		if get_setting('infinite.trakt.token') != trakt_acct.get('token'):
			force_trakt_update = True
			set_setting('watched_indicators', '1')
			set_setting('trakt.user', trakt_acct.get('username'))
			set_setting('trakt.expires', trakt_acct.get('expires'))
			set_setting('trakt.refresh', trakt_acct.get('refresh'))
			set_setting('trakt.token', trakt_acct.get('token'))
		if get_setting('infinite.trakt.user') != trakt_acct.get('username'): set_setting('watched_indicators', '0')

		imdb_acct = all_acct.get('imdb')
		set_setting('imdb_user', imdb_acct.get('user'))
	except: logger(f'Error: {print_exc()}')
	if not silent: notification('Settings Updated', time=1500)
	return force_trakt_update

def update_metadb():
	try:
		from modules.downloader import runner
		from modules.settings import get_git_url
		custom_files_path = get_git_url()
		urls = ['/metacache.db?raw=true', '/skipintro.json?raw=true']
		# urls = ['/skipintro.json']
		for url in urls:
			params = {
			'mode': 'downloader',
			'action': 'hindi_file',
			'name': 'metacache_test',
			'url': f'{custom_files_path}{url}',
			'silent': True,
			'media_type': 'file'}
			runner(params)
			notification('Files updated', time=2000)
	except:
		logger(f'Error: {print_exc()}')
		notification('Error', time=2000)
