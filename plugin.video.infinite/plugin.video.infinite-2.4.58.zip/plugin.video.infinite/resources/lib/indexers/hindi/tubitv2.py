# -*- coding: utf-8 -*-

import datetime
import os
import json
import re
from sys import argv
import string
import random
import traceback


# stream_failed = "Unable to get stream. Please try again later."
stream_plug = "https://m7lib.dev/api/v1/channels/"
# stream_plug = "aHR0cHM6Ly9tN2xpYi5kZXYvYXBpL3YxL2NoYW5uZWxzLw=="
# stream_plug = base64.b64decode(stream_plug).decode('UTF-8')
explore_org_base = "https://omega.explore.org/api/get_cam_group_info.json?id=79"
# explore_org_base = "aHR0cHM6Ly9vbWVnYS5leHBsb3JlLm9yZy9hcGkvZ2V0X2NhbV9ncm91cF9pbmZvLmpzb24/aWQ9Nzk="
# explore_org_base = base64.b64decode(explore_org_base).decode('UTF-8')
tubi_tv_base = "https://tubitv.com/oz"
# tubi_tv_base = "aHR0cHM6Ly90dWJpdHYuY29tL296"
# tubi_tv_base = base64.b64decode(tubi_tv_base).decode('UTF-8')
try:
    from xbmcgui import INPUT_ALPHANUM
    from indexers.hindi.live_client import scrapePage, wrigtht_json, agent
    from modules.player import infinitePlayer
    from modules.kodi_utils import logger, build_url, make_listitem, add_item, notification, dialog, set_info, set_resolvedurl, addon_fanart, add_items, set_content, end_directory, set_view_mode, get_infolabel
    from caches.h_cache import main_cache
    from modules.watched_status import get_bookmarks, get_progress_percent, get_watched_status,  get_watched_info
    testing = False
except:
    from modules.live_client import scrapePage, wrigtht_json, agent
    from modules.utils import logger
    from h_cache import main_cache
    testing = True
aicon = 'https://i.imgur.com/iOllLYX.png' # "hindi_tubi.png")
run_plugin = 'RunPlugin(%s)'
ch_slugs = ['bloomberg', 'cbs-sports-hq', 'pbs-kids', 'stirr-news-247', 'stirr-bloomberg-tv', 'stirr-law-crime', 'stirr-nasatv', 'stirr-comet', 'stirr-contv', 'stirr-comedy-dynamics', 'stirr-failarmy', 'stirr-afv', 'stirr-johnny-carson-tv', 'stirr-unsolved-mysteries', 'stirr-forensics-files', 'stirr-greatest-american-hero', 'stirr-wiseguy', 'stirr-the-commish', 'stirr-hunter', 'stirr-crime-story', 'stirr-filmrise-free-movies', 'stirr-stirr-movies', 'stirr-cinehouse', 'stirr-docurama', 'stirr-stirr-sports', 'stirr-edgesport', 'stirr-wpt', 'stirr-filmrise-classic-tv', 'stirr-american-classics', 'stirr-britcom', 'stirr-the-lucy-show', 'stirr-the-lone-ranger', 'stirr-stirr-westerns', 'stirr-movie-mix', 'stirr-stirr-comedy', 'stirr-stirr-documentaries', 'stirr-stirr-travel', 'vuit-investigate-tv', 'vuit-wgcl-atlanta-ga', 'vuit-wtvm-columbus-ga', 'vuit-wagt-augusta-ga', 'vuit-wrdw-augusta-ga', 'vuit-politics-uncut', 'vuit-walb-albany-ga', 'vuit-wtoc-savannah-ga', 'xumo-nbc-news-now', 'xumo-abc-news-live', 'xumo-cbs-news', 'xumo-comedy-dynamics', 'xumo-cinelife', 'xumo-docurama', 'pluto-tv-kids', 'pluto-tv-news', 'pluto-cnn', 'pluto-bloomberg-tv', 'pluto-classic-movies-channel', 'pluto-tv-action', 'pluto-tv-science', 'pluto-tv-animals', 'pluto-funny-af', 'pluto-tv-true-crime', 'pluto-buzzr', 'pluto-xive-tv', 'pluto-tv-travel', 'pluto-tv-history', 'pluto-tv-comedy', 'pluto-tv-romance', 'pluto-fox-sports', 'pluto-the-new-detectives', 'pluto-tv-thrillers', 'pluto-tv-drama', 'pluto-cmt-westerns', 'pluto-unsolved-mysteries', 'pluto-tv-sci-fi', 'pluto-tv-fantastic', 'pluto-british-tv', 'pluto-tv-documentaries', 'pluto-tv-spotlight', 'pluto-forensic-files', 'pluto-tv-military', 'pluto-weather-nation', 'pluto-tv-land-sitcoms', 'pluto-cold-case-files', 'pluto-tv-cult-films', 'pluto-tv-terror', 'pluto-bet-tv', 'pluto-comedy-central-tv', 'pluto-nick-jr-tv', 'pluto-tv-backcountry', 'pluto-paramount-movie-channel', 'pluto-doctor-who-classic', 'pluto-nfl-channel', 'pluto-tv-land-drama', 'pluto-american-gladiators', 'pluto-baywatch', 'pluto-tv-lives', 'pluto-cmt-tv', 'pluto-pga-tour', 'pluto-bein-sports-xtra', 'pluto-nbc-news-now', 'pluto-cops', 'pluto-blaze-live', 'pluto-johnny-carson-tv', 'pluto-stories-by-amc', 'pluto-the-walking-dead-esp', 'pluto-western-tv', 'pluto-cbs-sports-hq', 'pluto-csi', 'pluto-star-trek-1', 'pluto-tv-suspense', 'pluto-classic-tv-comedy', 'pluto-classic-tv-drama-ptv1', 'pluto-the-amazing-race', 'pluto-tv-drama-life', 'pluto-tv-crime-drama', 'pluto-90210', 'pluto-tv-crime-movies', 'pluto-tv-staff-picks', 'pluto-narcos', 'pluto-showtime-selects', 'pluto-dr-oz', 'pluto-bbc-home']

def get_clean_title(title):
    title = title.replace("'", "").replace("-", "").replace(":", "").replace("  ", " ").lower()
    return title.strip()

def get_skip_option(item):
    skip_option = {'title': item, 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '60'}
    return skip_option

def get_itemtype(itemtype, duration):
    mediatype = 'movie'
    if itemtype == 's': mediatype = 'tvshow'
    elif itemtype == 'v':
        if duration <= 3650: mediatype = 'episode'
    return mediatype

def plot_clean(plot):
    return re.sub(r'([:;\-"\',!_.?~$@])', '', plot)


class LiveChannels:

    @staticmethod
    def channel_list():
        try:
            channels_list = main_cache.get('content_list_tubitv2_livech_root')
            if not channels_list:
                channels_list = Common.get_channels()
                if channels_list: main_cache.set('content_list_tubitv2_livech_root', channels_list, expiration = datetime.timedelta(hours = 336)) # 336 == 14 days cache

            # Generate Channel List
            # logger(f'LiveChannels channels_list {channels_list}')
            Common.add_section('tubitv_livesearch', aicon, addon_fanart, "Search Channel")
            for channel in channels_list:
                try:
                    if channel["slug"] in ch_slugs: Common.add_channel(f"{channel['slug']}tubitv_liveget_channel", channel["poster"], addon_fanart, channel["name"], {}, True)
                except: logger(f'LiveChannels channel_list channel Error: {traceback.print_exc()}')
            handle = int(argv[1])
            set_content(handle, 'episodes')
            end_directory(handle)
        except:
            logger(f'LiveChannels channel_list Error {traceback.print_exc()}')
            notification("Oops something went wrong.", 1000)

    @staticmethod
    def search_list():
        try:
            # Generate Channel List from search query
            retval = dialog.input('Search...', type=INPUT_ALPHANUM)
            if retval and len(retval) > 0:
                search_list = main_cache.get(f'content_list_tubitv2_livech_search_{retval}')
                if not search_list:
                    search_list = Common.search_channels(retval)
                    if search_list: main_cache.set(f'content_list_tubitv2_livech_search_{retval}', search_list, expiration=datetime.timedelta(hours=336)) # 336 == 14 days cache
                if len(search_list) > 0:
                    for channel in search_list:
                        Common.add_channel(f'{channel["slug"]}tubitv_liveget_channel', channel["poster"], addon_fanart, channel["name"], {}, True)
                    handle = int(argv[1])
                    set_content(handle, 'episodes')
                    end_directory(handle)
                    set_view_mode('view.episodes', 'episodes')
                else:
                    notification('No results.', 1000)
                    exit()
            else:
                notification('Please enter something to search for.', 1000)
                exit()
        except:
            logger(f'LiveChannels search_list Error {traceback.print_exc()}')
            notification('Oops something went wrong.', 1000)
            exit()

    @staticmethod
    def get_channel(params):
        try:
            title = params['title']
            mode = params['mode']
            mode = mode.split('tubitv_liveget_channel')[0]
            Common.get_stream_and_play(mode)
        except: logger(f'LiveChannels get_channel Error {traceback.print_exc()}')


class Channels:

    @staticmethod
    def section_list(rescrape):
        try:
            # Common.add_section("tubitv-search", aicon, addon_fanart, "Search Tubi")
            # logger(f'section_list rescrape: {rescrape}')
            if rescrape == 'true': main_cache.delete_one('content_list_tubitv2_root')
            section_list = main_cache.get('content_list_tubitv2_root')
            if not section_list:
                # logger(f'Updating section_list: {section_list}')
                section_list = Stream.get_tubi_tv_categories()
                if section_list: main_cache.set('content_list_tubitv2_root', section_list, expiration=datetime.timedelta(hours=336)) # 14 days cache

            for category in section_list:
                try:
                    if re.search(r"espanol|Español|lgbt|LGBT|ganadores_y_nominados|telenovelas_y_series|para_los_nios_y_familias", str(category), flags=re.I): continue
                    Common.add_section(f'{category["id"]}tubitv-content', category["poster"], addon_fanart, category["title"], category)
                except Exception as e: logger(f'Channels section_list category Error: {traceback.print_exc()}')
            handle = int(argv[1])
            set_content(handle, 'tvshows')
            end_directory(handle)
            set_view_mode('view.tvshows', 'tvshows')
        except Exception as e:
            logger(f'Channels section_list Error {traceback.print_exc()}')
            notification('Oops something went wrong.', 1000)

    @staticmethod
    def content_list(mode):
        try:
            category = mode.split('tubitv-content')[0]
            cache_name = f'content_list_tubitv2_content_{category}'
            content_list = main_cache.get(cache_name)
            if not content_list:
                content_list = Stream.get_tubi_tv_content(category)
                if content_list: main_cache.set(cache_name, content_list, expiration=datetime.timedelta(hours=48))  # 48 hrs cache

            for entry in content_list:
                try:
                    if entry["type"] == "v": Common.add_channel(f'{entry["id"]}play-tubitv', entry["poster"], addon_fanart, entry["title"], entry, live=False)
                    elif entry["type"] == "s": Common.add_section(f'{entry["id"]}tubitv-episodes', entry["poster"], addon_fanart, entry["title"], entry)
                except Exception as e: logger(f'Channels content_list entry Error {traceback.print_exc()}')
            handle = int(argv[1])
            set_content(handle, 'tvshows')
            end_directory(handle)
            set_view_mode('view.tvshows', 'tvshows')
        except Exception as e:
            logger(f'Channels content_list mode: {mode} Error {traceback.print_exc()}')
            notification('content_list Oops something went wrong.', 1000)

    @staticmethod
    def episode_list(mode):
        try:
            show = mode.split('tubitv-episodes')[0]
            cache_name = f'content_list_tubitv2_episodes_{show}'
            episode_list = main_cache.get(cache_name)
            if not episode_list:
                episode_list = Stream.get_tubi_tv_episodes(show)
                if episode_list: main_cache.set(cache_name, episode_list, expiration=datetime.timedelta(hours=48))  # 48 hrs cache

            for entry in episode_list:
                try: Common.add_channel(f'{entry["id"]}play-tubitv', entry["poster"], addon_fanart, entry["title"], entry, live=False)
                except Exception as e: logger(f'Channels episode_list entry Error {traceback.print_exc()}')
            handle = int(argv[1])
            set_content(handle, 'episodes')
            end_directory(handle)
            set_view_mode('view.episodes', 'episodes')
        except Exception as e:
            logger(f'Channels episode_list Error {traceback.print_exc()}')
            notification('episode_list Oops something went wrong.', 1000)

    @staticmethod
    def search_tubi():
        try:
            retval = dialog.input('Search Tubi', type=INPUT_ALPHANUM)
            if retval and len(retval) > 0:
                search_list = main_cache.get(f'content_list_tubitv2_search_tubi_{retval}')
                if not search_list:
                    search_list = Stream.get_tubi_tv_search(retval)
                    if search_list: main_cache.set(f'content_list_tubitv2_search_tubi_{retval}', search_list, expiration=datetime.timedelta(hours=336)) # 336 == 14 days cache

                if len(search_list) > 1:
                    for entry in search_list:
                        try:
                            if re.search(r"espanol|lgbt|LGBT", str(entry), flags=re.I): continue
                            if entry["type"] == "v": Common.add_channel(f'{entry["id"]}play-tubitv', entry["poster"], addon_fanart, entry["title"], entry["meta"], live=False)
                            elif entry["type"] == "s": Common.add_section(f'{entry["id"]}tubitv-episodes', entry["poster"], addon_fanart, entry["title"], entry["meta"])
                        except Exception as e: logger(f'Channels search_tubi entry Error {traceback.print_exc()}')
                    handle = int(argv[1])
                    set_content(handle, 'tvshows')
                    end_directory(handle)
                    set_view_mode('view.tvshows', 'tvshows')
                else:
                    notification('No results.', 1000)
                    exit()
            else:
                notification('Please enter something to search for.', 1000)
                exit()
        except Exception as e:
            logger(f'Channels search_tubi Error {traceback.print_exc()}')
            notification('search_tubi Oops something went wrong.', 1000)

    @staticmethod
    def play_tubi(params):
        try:
            title = params['title']
            mode = params['mode']
            meta = params['meta']
            # logger(f'play_tubi:: meta: {meta}')
            stream_id = mode.split('play-tubitv')[0]
            Common.get_tubi_tv_stream(stream_id, meta)
        except Exception as e:
            logger(f'Channels play_tubi Error {traceback.print_exc()}')
            notification('play_tubi Oops something went wrong.', 1000)


class Common:
    UA = agent()
    watched_info = get_watched_info(0)
    bookmarks_movie = get_bookmarks(0, 'movie')
    bookmarks_episode = get_bookmarks(0, 'episode')
    # logger(f'Common watched_info: {watched_info}\nbookmarks_movie: {bookmarks_movie}\nbookmarks_episode: {bookmarks_episode}\nCommon UA: {UA}')

    @staticmethod
    def dlg_failed(mode):
        notification(mode, 1000)
        exit()

    @staticmethod
    def random_generator(size=6, chars=string.ascii_uppercase + string.digits):
        # Added '# nosec' to suppress bandit warning since this is not used for security/cryptographic purposes.
        return ''.join(random.choice(chars) for _ in range(size))  # nosec

    @staticmethod
    # Parse string and extracts first match as a string
    # The default is to find the first match. Pass a 'number' if you want to match a specific match. So 1 would match
    # the second and so forth
    def find_single_match(text, pattern, number=0):
        try:
            matches = re.findall(pattern, text, flags=re.DOTALL)
            result = matches[number]
        except AttributeError: result = ""
        return result

    @staticmethod
    # Parse string and extracts multiple matches using regular expressions
    def find_multiple_matches(text, pattern):
        return re.findall(pattern, text, re.DOTALL)

    @staticmethod
    # Open URL
    def open_url(url, user_agent=True):
        if not user_agent: header = {'User-Agent': Common.UA}
        else: header = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11' 'KODI'}
        # logger(f"Common get_stream_and_play header: {header}")
        httpHeaders = {'Accept': "application/json, text/javascript, text/html,*/*",
                       'Accept-Encoding': 'gzip,deflate,sdch',
                       'Accept-Language': 'en-US,en;q=0.8'
                       }
        return scrapePage(url, headers=header).text

    @staticmethod
    # Available channels
    def get_channels():
        url = f'{stream_plug}index.json'
        # logger(f'get_channels url: {url}')
        data = Common.open_url(url)
        return json.loads(data)

    @staticmethod
    def search_channels(query):
        url = f'{stream_plug}?search={query}'
        # logger(f'search_channels url: {url}')
        data = Common.open_url(url)
        return json.loads(data)

    @staticmethod
    def add_streams(streams):
        coll = []
        for stream in streams:
            icon = stream['icon']
            mode = stream['mode']
            u = f"{argv[0]}?mode={str(mode)}&pvr=.pvr"  # argv[0] + '?mode=' + str(stream['id']) + '&pvr=.pvr'
            item = stream['title'] if stream['title'] is not None else stream['id']
            listitem = make_listitem()
            listitem.setLabel(str(item))
            listitem.setProperty('skipPlayCount', 'true')
            listitem.setProperty('IsPlayable', 'true')
            listitem.setContentLookup(False)
            listitem.setIsFolder(False)
            listitem.setArt({'thumb': icon, 'poster': icon, 'banner': icon})
            stream.update({'imdb_id': str(item), 'mediatype': 'episode', 'episode': 1, 'season': 0})
            setUniqueIDs = {'imdb': str(item)}
            listitem = set_info(listitem, stream, setUniqueIDs)
            coll.append((u, listitem, False))
        return add_items(int(argv[1]), coll)

    @staticmethod
    def add_channel(mode, icon, fanart, title=None, meta={}, live=True):
        item = str(title) if title is not None else str(mode)
        if icon == '': icon = aicon
        cm = []
        cm_append = cm.append
        listitem = make_listitem()
        set_properties = listitem.setProperties
        listitem.setLabel(item)
        listitem.setArt({'thumb': icon, 'poster': icon, 'banner': icon, 'fanart': fanart})
        tmdb_id = str(meta.get('tmdb_id'))
        season, episode = meta.get('season', ''), meta.get('episode', '')
        playcount, overlay = get_watched_status(Common.watched_info, tmdb_id, season, episode)
        if meta.get('media_type') == 'movie': bookmarks = Common.bookmarks_movie
        else:  bookmarks = Common.bookmarks_episode
        progress = get_progress_percent(bookmarks, tmdb_id, season, episode)
        # logger(f'get_channels tmdb_id: {tmdb_id} progress: {progress} playcount: {playcount} overlay: {overlay}')
        meta.update({'title': item, 'playcount': playcount, 'overlay': overlay})
        setUniqueIDs = {'imdb': tmdb_id, 'tmdb': tmdb_id, 'tvdb': ''}
        listitem = set_info(listitem, meta, setUniqueIDs)
        if progress:
            clearprog_params = build_url({'mode': 'watched_status.erase_bookmark', 'media_type': meta.get('media_type'), 'tmdb_id': tmdb_id, 'season': season, 'episode': episode, 'refresh': 'true'})
            cm_append(('[B]Clear Progress[/B]', run_plugin % clearprog_params))
            set_properties({'WatchedProgress': progress, 'resumetime': progress, 'infinite.in_progress': 'true'})
        if playcount:
            unwatched_params = build_url({'mode': 'watched_status.extra', 'action': 'mark_as_unwatched', 'media_type': meta.get('media_type'), 'tmdb_id': tmdb_id, 'tvdb_id': '', 'season': season, 'episode': episode, 'title': item})
            cm_append(('[B]Mark Unwatched Infinite[/B]', run_plugin % unwatched_params))
        else:
            watched_params = build_url({'mode': 'watched_status.extra', 'action': 'mark_as_watched', 'media_type': meta.get('media_type'), 'tmdb_id': tmdb_id, 'tvdb_id': '', 'season': season, 'episode': episode, 'title': item})
            cm_append(('[B]Mark Watched Infinite[/B]', run_plugin % watched_params))
        listitem.addContextMenuItems(cm)
        if live is True: u = build_url({'mode': str(mode), 'pvr': '.pvr', 'title': item, 'meta': json.dumps(meta, ensure_ascii=False)})
        else: u = build_url({'mode': str(mode), 'title': item, 'meta': json.dumps(meta, ensure_ascii=False)})
        # logger(f'get_channels 2meta: {meta}')
        return add_item(handle=int(argv[1]), url=u, listitem=listitem, isFolder=False)

    @staticmethod
    def add_section(mode, icon, fanart, title=None, meta={}):
        # logger(f'Common add_section mode: {mode} title: {title}')
        cm = []
        cm_append = cm.append
        item = title if title is not None else mode
        if icon == '': icon = aicon
        listitem = make_listitem()
        listitem.setLabel(str(item))
        listitem.setArt({'thumb': icon, 'poster': icon, 'banner': icon, 'fanart': fanart})
        meta.update({'title': item})
        add_to_short_flod = build_url({'mode': 'menu_editor.shortcut_folder_add_item', 'name': item, 'iconImage': icon, 'meta': json.dumps(meta, ensure_ascii=False)})
        cm_append(('[B]Add to a Shortcut Folder[/B]', run_plugin % add_to_short_flod))
        listitem.addContextMenuItems(cm)
        setUniqueIDs = {'imdb': meta.get('imdb_id'), 'tmdb': meta.get('tmdb_id'), 'tvdb': ''}
        u = build_url({'mode': str(mode), 'rand': Common.random_generator(), 'meta': json.dumps(meta, ensure_ascii=False)})
        listitem = set_info(listitem, meta, setUniqueIDs)
        return add_item(handle=int(argv[1]), url=u, listitem=listitem, isFolder=True)

    @staticmethod
    # Return the Channel ID from YouTube URL
    def get_youtube_channel_id(url):
        return url.split("?v=")[-1].split("/")[-1].split("?")[0].split("&")[0]

    @staticmethod
    # Return the full YouTube plugin url
    def get_playable_youtube_url(channel_id):
        return f'plugin://plugin.video.youtube/play/?video_id={channel_id}'

    @staticmethod
    # Play stream
    # Optional: set xbmc_player to True to use xbmc.Player() instead of xbmcplugin.setResolvedUrl()
    def play(stream, channel='NO LABLE', xbmc_player=False):
        # logger(f'Common play:: channel: {channel} type(stream): {type(stream)} stream: {stream}')
        try: infinitePlayer().run(stream, 'video', {'title': channel})
        except: logger(f'Common play:: {channel} Error {traceback.print_exc()}')

    @staticmethod
    # Get and Play stream
    def get_stream_and_play(mode):
        stream = None
        name, stream = 'Not Found', ''
        url = f'{stream_plug}?slug={mode}'
        try:
            data = json.loads(Common.open_url(url))
            name = data['name']
            # logger(f'Common get_stream_and_play data: {data}')
            stream = data['stream']
        except: logger(f'get_stream_and_play Error {traceback.print_exc()}')

        if "m3u8" in stream: infinitePlayer().run(stream, 'video', {'title': name})
        else: Common.dlg_failed(f'Can not found url for: {name}')

    @staticmethod
    def get_tubi_tv_stream(stream_id, meta):
        url = f'{tubi_tv_base}/videos/{stream_id}/content'
        name, stream = 'Not Found', ''
        try:
            data = json.loads(Common.open_url(url))
            name = data['title']
            # logger(f'Common get_tubi_tv_stream data: {data}')
            stream = data.get("url", None)
            if not stream:
                video_resources = data["video_resources"]
                # logger(f'Common get_tubi_tv_stream video_resources: {video_resources}')
                url_list = [d['manifest'].get('url') for d in video_resources if d['manifest'].get('url') and d['type'] == 'hlsv3']
                # logger(f'Common get_tubi_tv_stream url_list: {url_list}')
                stream = f'{url_list[0]}'  #f"{random.choice(url_list)}"
        except: logger(f'get_tubi_tv_stream video_resources: {video_resources}\nError {traceback.print_exc()}')

        if "m3u8" in stream: infinitePlayer().run(stream, meta)
        else: Common.dlg_failed(f'Can not found url for: {name}')


class Stream:

    @staticmethod
    def get_explore_org_streams():
        stream_list = []
        url = explore_org_base # base64.b64decode(explore_org_base).decode('UTF-8')
        data = Common.open_url(url)
        json_results = json.loads(data)['data']['feeds']
        for stream in sorted(json_results, key=lambda k: k['title']):
            if stream["is_inactive"] is False and stream["is_offline"] is False and stream["video_id"] is not None:
                if stream["thumb"] == "": icon = f'https://i.ytimg.com/vi/{stream["video_id"]}/hqdefault.jpg'
                else: icon = stream["thumb"]
                if stream["thumbnail_large_url"] == "": fanart = f'https://i.ytimg.com/vi/{stream["video_id"]}/hqdefault.jpg'
                else: fanart = stream["thumbnail_large_url"]
                meta = {"duration": 10}
                stream_list.append({"id": stream["video_id"], "poster": icon, "fanart": fanart, "title": stream["title"], "meta": meta})
        return stream_list

    @staticmethod
    def get_tubi_tv_categories():
        cat_list = []
        url = f'{tubi_tv_base}/containers/'
        logger(f'url {url}')
        if testing:
            data = main_cache.get('content_list_get_tubi_tv_categories')
            if not data:
                data = Common.open_url(url)
                if data: main_cache.set('content_list_get_tubi_tv_categories', data, expiration=datetime.timedelta(hours=336))  # 14 days cache
        else: data = Common.open_url(url)
        json_results = json.loads(data)

        for category in range(len(json_results['list'])):
            try: icon = json_results['hash'][json_results['list'][category]]['thumbnail']
            except: icon = aicon
            try: Genres = json_results['hash'][json_results['list'][category]]['tags']
            except: Genres = []
            try: plot = plot_clean(json_results['hash'][json_results['list'][category]]['description'])
            except: plot = ''
            try:
                cat_list.append({"id": json_results['list'][category],
                                 "poster": icon,
                                 "Genres": Genres, "plot": plot, "year": 2023,
                                 "title": json_results['hash'][json_results['list'][category]]['title']})
            except: logger(f'Stream get_tubi_tv_categories Error: {traceback.print_exc()}')
        return cat_list

    @staticmethod
    def get_tubi_tv_content(category):
        content_list = []
        url = f'{tubi_tv_base}/containers/{category}/content?cursor=1&limit=200'
        if testing:
            cache_name = f'content_list_tubitv2_content_{url}'
            data = main_cache.get(cache_name)
            if not data:
                data = Common.open_url(url)
                if data: main_cache.set(cache_name, data, expiration=datetime.timedelta(hours=48))  # 48 hrs cache
        else: data = Common.open_url(url)
        json_results = json.loads(data)

        for movie in json_results['contents'].keys():
            try:
                if re.search(r"espanol|Español|lgbt|LGBT", str(json_results['contents'][movie]), flags=re.I): continue
                try: duration = int(json_results['contents'][movie]['duration'])
                except: duration = 0
                try: year = int(json_results['contents'][movie]['year'])
                except: year = 2023
                try: genre = json_results['contents'][movie]['tags']
                except: genre = []
                try: plot = plot_clean(json_results['contents'][movie]['description'])
                except: plot = ''
                try: icon = json_results['contents'][movie]['posterarts'][0]
                except: icon = aicon
                title = str(json_results['contents'][movie]['title'])
                itemtype = json_results['contents'][movie]['type']
                itemtype = get_itemtype(itemtype, duration)
                tmdb_id = f'{get_clean_title(title)}_{year}'
                tvshowtitle = title if itemtype == 'tvshow' else ''
                content_list.append({"id": json_results['contents'][movie]['id'],
                                     "type": json_results['contents'][movie]['type'],
                                     "title": title,"poster": icon, "year": year, "genre": genre, "plot": plot, "duration": duration,
                                     "media_type": itemtype, "tmdb_id": tmdb_id, "imdb_id": tmdb_id,
                                     "tvshowtitle": tvshowtitle, "skip_style": "netflix", "skip_option": get_skip_option(get_clean_title(title))})
            except: logger(f'Stream get_tubi_tv_content category: {category} Error {traceback.print_exc()}')
        return content_list

    @staticmethod
    def get_tubi_tv_episodes(show):
        episode_list = []
        url = f'{tubi_tv_base}/videos/0{show}/content'
        if testing:
            cache_name = f'content_list_tubitv2_episodes_{url}'
            data = main_cache.get(cache_name)
            if not data:
                data = Common.open_url(url)
                if data: main_cache.set(cache_name, data, expiration=datetime.timedelta(hours=48))  # 48 hrs cache
        else: data = Common.open_url(url)
        json_results = json.loads(data)
        tvshowtitle = str(json_results['title'])

        for season in range(len(json_results['children'])):
            try:
                for episode in range(len(json_results['children'][season]['children'])):
                    if re.search(r"espanol|Español|lgbt|LGBT", str(json_results['children'][season]['children'][episode]), flags=re.I): continue
                    try: duration = int(json_results['children'][season]['children'][episode]['duration'])
                    except: duration = 0
                    try: year = int(json_results['children'][season]['children'][episode]['year'])
                    except: year = 2023
                    try: genre = json_results['children'][season]['children'][episode]['tags']
                    except: genre = []
                    try: plot = plot_clean(json_results['children'][season]['children'][episode]['description'])
                    except: plot = ''
                    try: icon = json_results['children'][season]['children'][episode]['thumbnails'][0]
                    except: icon = aicon
                    # try: url = json_results['children'][season]['children'][episode]['url']
                    # except: url = ''
                    try: season_no = int(json_results['children'][season]['id'])
                    except: season_no = 1
                    try: episode_no = int(json_results['children'][season]['children'][episode]['episode_number'])
                    except: episode_no = 1
                    title = str(json_results['children'][season]['children'][episode]['title'])
                    # itemtype = json_results['children'][season]['children'][episode]['type']
                    itemtype = get_itemtype('v', duration)
                    tmdb_id = f'{get_clean_title(tvshowtitle)}_{year}'
                    tvshowtitle = tvshowtitle if itemtype in ('tvshow', 'episode') else ''
                    episode_list.append({"id": json_results['children'][season]['children'][episode]['id'],
                                         "title": title, "tmdb_id": tmdb_id, "imdb_id": tmdb_id, "poster": icon, "year": year, "genre": genre, "plot": plot, "duration": duration,
                                         "media_type": itemtype, "season": season_no, "episode": episode_no,
                                         "tvshowtitle": tvshowtitle, "skip_style": "netflix", "skip_option": get_skip_option(get_clean_title(title))})
            except: logger(f'Stream get_tubi_tv_episodes category: {show} Error {traceback.print_exc()}')
        return episode_list

    @staticmethod
    def get_tubi_tv_search(query):
        search_list = []
        url = f'{tubi_tv_base}/search/{query}'
        data = Common.open_url(url)
        json_results = json.loads(data)
        logger(f'Stream search json_results {json_results}')

        for result in json_results:
            try:
                if re.search(r"espanol|Español|lgbt|LGBT", str(result), flags=re.I): continue
                try: duration = int(result['duration'])
                except: duration = 0
                try: year = int(result['year'])
                except: year = 2023
                try: genre = result['tags']
                except: genre = []
                try: plot = plot_clean(result['description'])
                except: plot = ''
                try: icon = result['posterarts'][0]
                except: icon = aicon
                # logger(f'Stream search result {result}')
                title = str(result['title'])
                itemtype = result['type']
                itemtype = get_itemtype(itemtype, duration)
                tmdb_id = f'{get_clean_title(title)}_{year}'
                tvshowtitle = title if itemtype in ('tvshow', 'episode') else ''
                search_list.append({"id": result['id'],
                                    "title": title, "tmdb_id": tmdb_id, "poster": icon, "year": year, "genre": genre, "plot": plot, "duration": duration,
                                    "media_type": itemtype,
                                    "tvshowtitle": tvshowtitle, "skip_style": "netflix", "skip_option": get_skip_option(get_clean_title(title))})
            except: logger(f'Stream get_tubi_tv_search result: {result} Error {traceback.print_exc()}')
        return search_list
