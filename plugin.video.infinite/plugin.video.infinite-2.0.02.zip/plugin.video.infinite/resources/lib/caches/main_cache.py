# -*- coding: utf-8 -*-
from caches.base_cache import BaseCache, get_timestamp
from modules.kodi_utils import logger
from traceback import print_exc

id_LIKE_DELETE = '''DELETE FROM maincache WHERE id LIKE ?'''

class MainCache(BaseCache):
	def __init__(self):
		BaseCache.__init__(self, 'maincache_db', 'maincache')

	def delete_all(self):
		try:
			dbcon = self.manual_connect('maincache_db')
			for i in dbcon.execute('SELECT id FROM maincache'): self.delete_memory_cache(str(i[0]))
			dbcon.execute('DELETE FROM maincache')
			dbcon.execute('VACUUM')
			return True
		except: return False

	def delete_all_folderscrapers(self):
		dbcon = self.manual_connect('maincache_db')
		remove_list = [str(i[0]) for i in dbcon.execute('SELECT id from maincache where id LIKE %s' % "'FOLDERSCRAPER_%'").fetchall()]
		if not remove_list: return True
		try:
			dbcon.execute('DELETE FROM maincache WHERE id LIKE %s' % "'FOLDERSCRAPER_%'")
			dbcon.execute('VACUUM')
			for item in remove_list: self.delete_memory_cache(str(item))
			return True
		except: return False

	def clean_database(self):
		try:
			dbcon = self.manual_connect('maincache_db')
			dbcon.execute('DELETE from maincache WHERE CAST(expires AS INT) <= ?', (get_timestamp(),))
			dbcon.execute('VACUUM')
			return True
		except: return False

	def delete_all_lists(self):
		media_list = ("'FOLDERS%'", "'get_sources_%'", "'get_hostDict%'", "'opensubtitles_%'", "'https%'", "'content_%'", "'shows_%'", "'episodes_%'", "'movies_%'")
		command = ''
		for count, item in enumerate(media_list, 1):
			if count == 1: command = 'SELECT id from maincache where id LIKE %s' % item
			else: command += f' OR id LIKE {item}'
		dbcon = self.manual_connect('maincache_db')
		results = dbcon.execute(command).fetchall()
		try:
			for item in results:
				try:
					remove_id = str(item[0])
					dbcon.execute(id_LIKE_DELETE, (remove_id,))
					self.delete_memory_cache(remove_id)
				except: logger(f'delete_all_lists remove_id:{repr(item)} Error:{print_exc()}')
			dbcon.execute('VACUUM')
		except: logger(f'delete_all_lists Error:{print_exc()}')

	def delete_like(self, id_item):
		try:
			dbcon = self.manual_connect('maincache_db')
			dbcon.execute(id_LIKE_DELETE, (str(id_item),))
			self.delete_memory_cache(str(id_item))
			dbcon.execute("VACUUM")
		except: return logger(f'delete_like id_item:{repr(id_item)}\nError: {print_exc()}')


main_cache = MainCache()

def cache_object(function, string, args, json=True, expiration=24):
	if data := main_cache.get(string): return data
	args = tuple(args) if isinstance(args, list) else (args, )
	result = function(*args).json() if json else function(*args)
	main_cache.set(string, result, expiration=expiration)
	return result
