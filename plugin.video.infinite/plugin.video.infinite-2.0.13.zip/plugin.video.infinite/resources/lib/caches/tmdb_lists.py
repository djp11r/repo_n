# -*- coding: utf-8 -*-
from caches.base_cache import BaseCache, get_timestamp
# from modules.kodi_utils import logger

class TMDbListsCache(BaseCache):
	def __init__(self):
		super().__init__('tmdb_lists_db', 'tmdb_lists')

	def clear_all_lists(self):
		try:
			with self.dbcon:
				self.dbcon.execute('DELETE FROM tmdb_lists WHERE id = ?', ('get_user_lists',))
			self.dbcon.execute('VACUUM')
			return True
		except: return False

	def clear_list(self, list_id):
		try:
			with self.dbcon:
				self.dbcon.execute('DELETE FROM tmdb_lists WHERE id = ?', ('get_list_details_%s' % list_id,))
			self.dbcon.execute('VACUUM')
			return True
		except: return False

	def clear_watchfavrecs(self, list_id, media_type):
		try:
			string = 'get_watchfavrecs_list_details_%s_%s' % (list_id, media_type)
			with self.dbcon:
				self.dbcon.execute('DELETE FROM tmdb_lists WHERE id = ?', (string,))
			self.dbcon.execute('VACUUM')
			return True
		except: return False

	def clear_all(self):
		try:
			with self.dbcon:
				self.dbcon.execute('DELETE FROM tmdb_lists WHERE id = ?', ('get_user_lists',))
				self.dbcon.execute('DELETE FROM tmdb_lists WHERE id LIKE %s' % "'get_list_details_%'")
				self.dbcon.execute('DELETE FROM tmdb_lists WHERE id LIKE %s' % "'get_watchfavrecs_list_details_%'")
			self.dbcon.execute('VACUUM')
			return True
		except: return False

	def clean_database(self):
		try:
			with self.dbcon:
				self.dbcon.execute('DELETE from tmdb_lists WHERE CAST(expires AS INT) <= ?', (get_timestamp(),))
			self.dbcon.execute('VACUUM')
			return True
		except: return False

	def set_sort_order(self, list_id, sort_order):
		try:
			with self.dbcon:
				self.dbcon.execute('INSERT OR REPLACE INTO tmdb_lists VALUES (?, ?, ?)', ('sort_order_%s' % list_id, sort_order, 0))
			return True
		except: return False

	def get_sort_orders(self):
		try:
			with self.dbcon:
				cache_data = self.dbcon.execute('SELECT id, data FROM tmdb_lists WHERE id LIKE %s' % "'sort_order_%'").fetchall()
			cache_data = dict([(int(i[0].replace('sort_order_', '')), i[1]) for i in cache_data])
			return cache_data
		except: return {}

tmdb_lists_cache = TMDbListsCache()

def tmdb_lists_cache_object(function, string, args, json=False, expiration=24):
	if cache := tmdb_lists_cache.get(string): return cache
	if args is not None:
		if not isinstance(args, (tuple, list)): args = (args,)
		response = function(*args)
	else: response = function(*args)
	result = response.json() if json else response
	if result in ([], {}, '[]', '{}', '', None): expiration = 0.1
	else: expiration = expiration
	tmdb_lists_cache.set(string, result, expiration=expiration)
	return result