# -*- coding: utf-8 -*-
import json
from caches.base_cache import open_db
# from modules.kodi_utils import logger

class EpisodeGroupsCache:
	def get(self, tmdb_id):
		with open_db('episode_groups_db') as dbcon:
			try: data = json.loads(dbcon.execute('SELECT data FROM groups_data WHERE tmdb_id = ?', (str(tmdb_id),)).fetchone()[0])
			except: data = {}
		return data

	def set(self, tmdb_id, data):
		with open_db('episode_groups_db') as dbcon: dbcon.execute('INSERT OR REPLACE INTO groups_data VALUES (?, ?)', (str(tmdb_id), json.dumps(data)))

	def delete(self, tmdb_id):
		with open_db('episode_groups_db') as dbcon:
			dbcon.execute('DELETE FROM groups_data where tmdb_id=?', (str(tmdb_id),))
			dbcon.execute('VACUUM')

	def clear_cache(self):
		with open_db('episode_groups_db') as dbcon:
			dbcon.execute('DELETE FROM groups_data')
			dbcon.execute('VACUUM')

episode_groups_cache = EpisodeGroupsCache()
