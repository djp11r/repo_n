# -*- coding: utf-8 -*-
import json
from caches.base_cache import open_db, get_timestamp, serialize_db_value, deserialize_db_value
# from modules.kodi_utils import logger

class ExternalCache(object):
	def get(self, source, media_type, tmdb_id, title, year, season, episode):
		result = None
		try:
			with open_db('external_db') as dbcon:
				cache_data = dbcon.execute(
				'SELECT results, expires FROM results_data WHERE provider = ? AND db_type = ? AND tmdb_id = ? AND title = ? AND year = ?, AND season = ? AND episode = ?',
				(source, media_type, tmdb_id, title, year, season, episode))
				if cache_data:
					if cache_data[1] > get_timestamp(): result = deserialize_db_value(cache_data[0])
					else: self.delete(source, media_type, tmdb_id, title, season, episode, dbcon)
		except: pass
		return result

	def set(self, source, media_type, tmdb_id, title, year, season, episode, results, expire_time):
		try:
			expires = get_timestamp(expire_time)
			with open_db('external_db') as dbcon:
				dbcon.execute('INSERT OR REPLACE INTO results_data VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
					(source, media_type, tmdb_id, title, year, season, episode, serialize_db_value(results or []), int(expires)))
		except: pass

	def delete(self, source, media_type, tmdb_id, title, season, episode, dbcon):
		try:
			dbcon.execute('DELETE FROM results_data WHERE provider = ? AND db_type = ? AND tmdb_id = ? AND title = ? AND year = ? AND season = ? AND episode = ?',
				(source, media_type, tmdb_id, title, season, episode))
		except: return

	def delete_cache_single(self, media_type, tmdb_id):
		try:
			with open_db('external_db') as dbcon:
				dbcon.execute('DELETE FROM results_data WHERE db_type=? AND tmdb_id=?', (media_type, tmdb_id))
				dbcon.execute('VACUUM')
			return True
		except: return False

	def clear_cache(self):
		try:
			with open_db('external_db') as dbcon:
				dbcon.execute('DELETE FROM results_data', ())
				dbcon.execute('VACUUM')
			return True
		except: return False

	def clean_database(self):
		try:
			with open_db('external_db') as dbcon:
				dbcon.execute('DELETE from results_data WHERE expires <= ?', (get_timestamp(),))
				dbcon.execute('VACUUM')
			return True
		except: return False

external_cache = ExternalCache()
