# -*- coding: utf-8 -*-
from caches.base_cache import BaseCache, open_db, get_timestamp
from modules.kodi_utils import logger
from traceback import format_exc

class MainCache(BaseCache):
	def __init__(self):
		BaseCache.__init__(self, 'maincache_db', 'maincache')

	def delete_all(self):
		try:
			with open_db('maincache_db') as dbcon:
				dbcon.execute('DELETE FROM maincache')
			dbcon.execute('VACUUM')
			return True
		except: return False

	def delete_all_folderscrapers(self):
		try:
			# Let SQLite do the matching and deleting in a single pass
			with open_db('maincache_db') as dbcon:
				cursor = dbcon.execute('DELETE FROM maincache WHERE id LIKE ?', ('FOLDERSCRAPER_%',))
				# Smart Optimization: Only run VACUUM if items were actually dropped
				if cursor.rowcount > 0: dbcon.execute('VACUUM')
			return True
		except: return False

	def clean_database(self):
		try:
			with open_db('maincache_db') as dbcon:
				cursor = dbcon.execute('DELETE from maincache WHERE CAST(expires AS INT) <= ?', (get_timestamp(),))
				if cursor.rowcount > 0: dbcon.execute('VACUUM')
			return True
		except: return False

	def delete_all_lists(self):
		media_list = ("'FOLDERS%'", "'get_sources_%'", "'get_hostDict%'", "'opensubtitles_%'", "'https%'", "'content_%'", "'shows_%'", "'episodes_%'", "'movies_%'")
		command = ''
		for count, item in enumerate(media_list, 1):
			if count == 1: command = 'SELECT id from maincache where id LIKE %s' % item
			else: command += f' OR id LIKE {item}'
		with open_db('maincache_db') as dbcon:
			results = dbcon.execute(command).fetchall()
			try:
				for item in results:
					try:
						remove_id = str(item[0])
						dbcon.execute('''DELETE FROM maincache WHERE id LIKE ?''', (remove_id,))
					except: logger(f'delete_all_lists remove_id:{repr(item)} Error:{format_exc()}')
				dbcon.execute('VACUUM')
			except: logger(f'delete_all_lists Error:{format_exc()}')
		return

	def delete_like(self, id_item):
		try:
			with open_db('maincache_db') as dbcon:
				cursor = dbcon.execute('''DELETE FROM maincache WHERE id LIKE ?''', (str(id_item),))
				if cursor.rowcount > 0: dbcon.execute("VACUUM")
		except: logger(f'delete_like id_item:{repr(id_item)}\nError: {format_exc()}')
		return

main_cache = MainCache()

def cache_object(function, string, args=None, json=True, expiration=24):
	if data := main_cache.get(string): return data
	if args is not None:
		if not isinstance(args, (tuple, list)): args = (args,)
		response = function(*args)
	else: response = function(*args)
	result = response.json() if json else response
	if result: main_cache.set(string, result, expiration=expiration)
	return result
