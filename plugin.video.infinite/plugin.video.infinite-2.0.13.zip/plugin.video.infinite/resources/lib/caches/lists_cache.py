# -*- coding: utf-8 -*-
from caches.base_cache import BaseCache, open_db, get_timestamp
from modules.settings import lists_cache_duraton
# from modules.kodi_utils import logger

class ListsCache(BaseCache):
	def __init__(self):
		BaseCache.__init__(self, 'lists_db', 'lists')

	def delete_all_lists(self):
		try:
			with open_db('lists_db') as dbcon:
				cursor = dbcon.execute('DELETE FROM lists WHERE id NOT LIKE %s' % "'ai_%'")
				if cursor.rowcount > 0: dbcon.execute('VACUUM')
			return True
		except: return False

	def clean_database(self):
		try:
			with open_db('lists_db') as dbcon:
				dbcon.execute('DELETE from lists WHERE expires <= ?', (get_timestamp(),))
				dbcon.execute('VACUUM')
			return True
		except: return False

lists_cache = ListsCache()

def lists_cache_object(function, string, args, json=False, expiration=168):
	if data := lists_cache.get(string): return data
	if args is not None:
		if not isinstance(args, (tuple, list)): args = (args,)
		response = function(*args)
	else: response = function(*args)
	result = response.json() if json else response
	if result in ([], {}, '[]', '{}', '', None): expiration = 0.1
	else: expiration = expiration or lists_cache_duraton()
	lists_cache.set(string, result, expiration=expiration)
	return result