# -*- coding: utf-8 -*-
from caches.base_cache import open_db
from modules.fen_online_utils import single_sync
from modules.utils import sort_for_article
# from modules.kodi_utils import logger

class FavoritesCache:
	@single_sync('favorites_db', 'favorites')
	def set_favorite(self, media_type, tmdb_id, title):
		try:
			with open_db('favorites_db') as dbcon: dbcon.execute('INSERT INTO favorites VALUES (?, ?, ?)', (media_type, str(tmdb_id), title))
			return True
		except: return None

	@single_sync('favorites_db', 'favorites')
	def delete_favorite(self, media_type, tmdb_id, title):
		try:
			with open_db('favorites_db') as dbcon: dbcon.execute('DELETE FROM favorites where db_type=? and tmdb_id=?', (media_type, str(tmdb_id)))
			return True
		except: return None

	def get_favorites(self, media_type):
		with open_db('favorites_db') as dbcon: favorites = dbcon.execute('SELECT tmdb_id, title FROM favorites WHERE db_type=?', (media_type,)).fetchall()
		return [{'tmdb_id': str(i[0]), 'title': str(i[1])} for i in favorites]

	@single_sync('favorites_db', 'favorites')
	def clear_favorites(self, media_type):
		try:
			with open_db('favorites_db') as dbcon:
				dbcon.execute('DELETE FROM favorites WHERE db_type=?', (media_type,))
				dbcon.execute('VACUUM')
			return True
		except: return None

favorites_cache = FavoritesCache()

def get_favorites(media_type, dummy_arg):
	data = favorites_cache.get_favorites(media_type)
	data = sort_for_article(data, 'title')
	return [{'media_id': i['tmdb_id'], 'title': i['title']} for i in data]
