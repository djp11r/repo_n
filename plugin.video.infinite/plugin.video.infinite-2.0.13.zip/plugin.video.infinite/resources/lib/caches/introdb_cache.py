# -*- coding: utf-8 -*-
from caches.base_cache import BaseCache
# from modules.kodi_utils import logger


def episode_intros_cache_object(function, url, json=True):
	intro_db = BaseCache('intro_db', 'intro_data')
	if data := intro_db.get_no_expiry(url): return data
	response = function(url)
	result = response.json() if json else response
	intro_db.set_no_expiry(url, result)
	return result