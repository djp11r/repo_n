# -*- coding: utf-8 -*-
import os
import zlib
import json
import base64
import string
import secrets
import hashlib
from traceback import format_exc

from caches.base_cache import open_db, get_timestamp
from caches.settings_cache import get_setting, set_setting, set_many_settings
from modules.utils import chacha20_crypt, epoch_to_datetime
from modules import kodi_utils

#AI used to ensure correct encryption/decryption handling

logger = kodi_utils.logger
base_url = '%s/users/%s/%s.json'
key_test = (None, 'empty_setting', '')
all_dbs = [('watched_db', 'watched'), ('watched_db', 'progress'), ('personal_lists_db', 'personal_lists'), ('favorites_db', 'favorites'), ('settings_db', 'settings'), ('watched_db', 'watched_status'), ('navigator_db', 'navigator')]
o_url = 'https://learning-db-jp-default-rtdb.firebaseio.com'
# i_url = 'https://infinite-back-default-rtdb.firebaseio.com'
# i_registration_key = 'F5WEQNgzzteFanuom335Js7sDBQqBBaEu28W5KQ3'
# e_url = 'https://testinfinite-back-default-rtdb.firebaseio.com'
# e_registration_key = 'b5zAt5GV1avXHzcRXNumY6Nc5f2SiSjnH0fjIqWE'
registration_key = 'AueurtnEUUEnnfl193847cPP48vnjh'

def get_last_sync(table_name):
	last_sync = int(get_setting('infinite.fen_online.sync_timestamp_%s' % table_name, '0'))
	if not last_sync: last_sync = set_last_sync(table_name)
	return last_sync

def set_last_sync(table_name, timestamp=None):
	timestamp = timestamp or get_timestamp()
	set_setting('fen_online.sync_timestamp_%s' % table_name, str(timestamp))
	return timestamp

def clear_last_syncs():
	set_many_settings([(i[0], '0') for i in all_dbs])

def create_profile():
	max_attempts = 3
	assign_own_key = kodi_utils.confirm_dialog(heading='Online Sync',
									text='You need a 6-10 character User Code[CR]Do you want to assign it yourself or allow infinite to assign a random string?',
									ok_label='Assign', cancel_label='Random', default_control=11)
	if assign_own_key is None: return
	if assign_own_key:
		for attempts in range(1, max_attempts + 1):
			remaining = max_attempts - attempts
			user_code = kodi_utils.kodi_dialog().input(heading='Enter a 6-10 character User Code')
			if user_code in (None, ''): return False
			user_code = user_code.upper().strip()
			if (not 6 <= len(user_code) <= 10) or not user_code.isalnum():
				if remaining == 0: return
				if not kodi_utils.confirm_dialog(heading='infinite Online Sync', text=('Use only Alphanumeric characters (A-Z and 0-9)[CR][CR]'
										'Use 6-10 characters[CR][CR]Try again? ....%s attempts remaining') % remaining,
										ok_label='Retry', cancel_label='Cancel', default_control=10): return
			else: break
	else: user_code = ''.join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(6))
	for attempts in range(1, max_attempts + 1):
		remaining = max_attempts - attempts
		user_pin = kodi_utils.kodi_dialog().numeric(0, 'Enter a 4-digit PIN')
		if user_pin in (None, ''): return False
		if len(user_pin) != 4 or not user_pin.isdigit():
			if remaining == 0: return
			if not kodi_utils.confirm_dialog(heading='infinite Online Sync', text=('Use only Numbers (0-9)[CR][CR]'
									'Use exactly 4 Numbers[CR][CR]Try again? ....%s attempts remaining') % remaining,
									ok_label='Retry', cancel_label='Cancel', default_control=10): return
		else: break
	user_hex, crypto_key_hex = make_user_keys(user_code, user_pin)
	success = create_account(user_hex)
	if success:
		set_many_settings([('fen_online.user_active', 'true'), ('fen_online.user_code', user_code), ('fen_online.user_pin', user_pin),
							('fen_online.user_hex', user_hex), ('fen_online.crypto_key_hex', crypto_key_hex)])
		full_push()
		kodi_utils.ok_dialog('infinite Online Sync', ('Success![CR]Your new User Code is [B]%s[/B][CR]Your new User PIN is [B]%s[/B]'
						'[CR]You need these for access, so keep them safe[CR]They cannot be recovered if lost' % (user_code, user_pin)))
	else: kodi_utils.ok_dialog('infinite Online Sync', 'FAILED![CR]There was an error creating your account[CR][CR]Please try again')

def connect_device():
	if not kodi_utils.confirm_dialog(heading='infinite Online Sync', text=('Connecting to a current infinite Online Account will mean that your local data '
		'will be overwritten with the data from the infinite Online account. This includes if there is no data currently online. Consider this before continuing'),
		ok_label='Continue', cancel_label='Cancel', default_control=11): return
	max_attempts = 3
	current_user_code, current_user_pin = get_setting('infinite.fen_online.user_code', ''), get_setting('infinite.fen_online.user_pin', '')
	for attempts in range(1, max_attempts + 1):
		remaining = max_attempts - attempts
		user_code = kodi_utils.kodi_dialog().input(heading='Enter your 6-10 character User Code', defaultt=current_user_code)
		if user_code in (None, ''): return False
		user_code = user_code.upper().strip()
		if (not 6 <= len(user_code) <= 10) or not user_code.isalnum():
			if remaining == 0: return
			if not kodi_utils.confirm_dialog(heading='infinite Online Sync', text=('Use only Alphanumeric characters (A-Z and 0-9)[CR][CR]'
									'Use 6-10 characters[CR][CR]Try again? ....%s attempts remaining') % remaining,
									ok_label='Retry', cancel_label='Cancel', default_control=10): return
		else: break
	for attempts in range(1, max_attempts + 1):
		remaining = max_attempts - attempts
		user_pin = kodi_utils.kodi_dialog().numeric(0, 'Enter your 4-digit PIN', current_user_pin)
		if user_pin in (None, ''): return False
		if len(user_pin) != 4 or not user_pin.isdigit():
			if remaining == 0: return
			if not kodi_utils.confirm_dialog(heading='infinite Online Sync', text=('Use only Numbers (0-9)[CR][CR]'
									'Use exactly 4 Numbers[CR][CR]Try again? ....%s attempts remaining') % remaining,
									ok_label='Retry', cancel_label='Cancel', default_control=10): return
		else: break
	kodi_utils.show_busy_dialog()
	user_hex, crypto_key_hex = make_user_keys(user_code, user_pin)
	response = make_call('GET', '', user_hex, show_busy=True)
	if response.status_code == 200:
		set_many_settings([('fen_online.user_active', 'true'), ('fen_online.user_code', user_code), ('fen_online.user_pin', user_pin),
							('fen_online.user_hex', user_hex), ('fen_online.crypto_key_hex', crypto_key_hex)])
		run_sync()
	kodi_utils.hide_busy_dialog()

def revoke_account():
	if kodi_utils.confirm_dialog(heading='infinite Online Sync', text='Revoke Authorization for this Device?', ok_label='Yes', cancel_label='No'):
		set_many_settings([('fen_online.user_active', 'false'), ('fen_online.user_hex', 'empty_setting'), ('fen_online.crypto_key_hex', 'empty_setting')])
		kodi_utils.set_property('infinite.fen_online.last_sync', str(get_timestamp()))

def delete_online_data():
	if not kodi_utils.confirm_dialog(heading='infinite Online Sync', text='Delete all Online Data for this Account?', ok_label='Yes', cancel_label='No'): return
	if not kodi_utils.confirm_dialog(heading='infinite Online Sync', text='Are you sure? This can not be undone', ok_label='Yes', cancel_label='No'): return
	user_hex = get_setting('infinite.fen_online.user_hex')
	deletion_payload = {'watched': None, 'progress': None, 'settings': None, 'personal_lists': None, 'favorites': None, 'last_updated_data': None}
	response = make_call('PATCH', '', user_hex, data=deletion_payload, show_busy=True)

def full_push():
	user_hex, crypto_key_hex = get_setting('infinite.fen_online.user_hex'), get_setting('infinite.fen_online.crypto_key_hex')
	if any(i in [user_hex, crypto_key_hex] for i in key_test): return False
	kodi_utils.show_busy_dialog()
	try:
		payload = {}
		for db_name, table_name in all_dbs:
			try: payload = process_push(db_name, table_name, crypto_key_hex, payload)
			except Exception as e: logger('full push payload adds error', str(e))
		if payload: response = make_call('PATCH', '', user_hex, data=payload)
	except Exception as e: logger('full push main error', str(e))
	kodi_utils.hide_busy_dialog()
	kodi_utils.set_property('infinite.fen_online.last_sync', str(get_timestamp()))

def full_pull(full_data=None):
	user_hex, crypto_key_hex = get_setting('infinite.fen_online.user_hex'), get_setting('infinite.fen_online.crypto_key_hex')
	if any(i in [user_hex, crypto_key_hex] for i in key_test): return False
	response = make_call('GET', '', user_hex)
	if response.status_code == 200: full_data = response.json() or {}
	if not full_data: return
	last_updated_data = full_data.get('last_updated_data', {})
	for db_name, table_name in all_dbs:
		try:
			encrypted_string = full_data.get(table_name)
			if encrypted_string in (None, 'null', ''): continue
			try: data_dict_list = decrypt_data(encrypted_string, crypto_key_hex)
			except: continue
			if not data_dict_list: continue
			online_timestamp = last_updated_data.get(table_name) or get_timestamp()
			success = process_pull(db_name, table_name, online_timestamp, data_dict_list)
		except Exception as e: logger('full pull main error', str(e))
	kodi_utils.set_property('infinite.fen_online.last_sync', str(get_timestamp()))

def push_single(db_name, table_names, user_hex=None, crypto_key_hex=None, session=None):
	if not user_hex: user_hex, crypto_key_hex = get_setting('infinite.fen_online.user_hex'), get_setting('infinite.fen_online.crypto_key_hex')
	if isinstance(table_names, str): table_names = [table_names]
	payload = {}
	for table_name in table_names: payload = process_push(db_name, table_name, crypto_key_hex, payload)
	if payload: response = make_call('PATCH', '', user_hex, data=payload, session=session)
	return

def pull_single(db_name, table_name, timestamp, user_hex=None, crypto_key_hex=None, session=None):
	if not user_hex: user_hex, crypto_key_hex = get_setting('infinite.fen_online.user_hex'), get_setting('infinite.fen_online.crypto_key_hex')
	if any(i in [user_hex, crypto_key_hex] for i in key_test): return False
	response = make_call('GET', table_name, user_hex, session=session)
	if response.status_code != 200: return None
	encrypted_string = response.json()
	if encrypted_string in (None, 'null', ''): return None
	try: data_dict_list = decrypt_data(encrypted_string, crypto_key_hex)
	except: return None
	if not data_dict_list:
		logger(f'pull_single {table_name} data_dict_list: {repr(data_dict_list)} so now check local and if there is data push to online')
		# push_single(db_name, table_name)
		return None
	success = process_pull(db_name, table_name, timestamp, data_dict_list)
	if not success: return None
	return response

def run_sync():
	user_hex, crypto_key_hex = get_setting('infinite.fen_online.user_hex'), get_setting('infinite.fen_online.crypto_key_hex')
	if any(i in [user_hex, crypto_key_hex] for i in key_test): return None
	session = kodi_utils.make_session()
	response = make_call('GET', 'last_updated_data', user_hex, session=session)
	status_code = response.status_code
	if status_code != 200: return status_code, None
	data_updated = False
	last_updated_data = response.json() or {}
	# logger(f'init run_sync\nlast_updated_data={repr(last_updated_data)}\nsync_times       ={repr(sync_times)}')
	payload = {}
	for db_name, table_name in all_dbs:
		online_timestamp = int(last_updated_data.get(table_name, '0'))
		local_timestamp = get_last_sync(table_name)
		msg = None
		if local_timestamp != online_timestamp: data_updated = True
		if online_timestamp > local_timestamp: # online wins
			pull_single(db_name, table_name, online_timestamp, user_hex=user_hex, crypto_key_hex=crypto_key_hex, session=session)
			msg = 'pull'
		elif local_timestamp > online_timestamp: # local wins
			payload = process_push(db_name, table_name, crypto_key_hex, payload)
			msg = 'push'
		if msg: logger(f'run_sync for {db_name, table_name} Data: {msg} Online/Local Timestamps {epoch_to_datetime(online_timestamp)}, {epoch_to_datetime(local_timestamp)}')
	if payload: response = make_call('PATCH', '', user_hex, data=payload, session=session)
	session.close()
	kodi_utils.set_property('infinite.fen_online.last_sync', str(get_timestamp()))
	return status_code, data_updated

def access_user_code():
	user_code, user_pin = get_setting('infinite.fen_online.user_code'), get_setting('infinite.fen_online.user_pin')
	if user_code in key_test: return kodi_utils.ok_dialog('infinite Online Sync', 'No User Code is Available')
	expires_in = 20
	start, time_passed = get_timestamp(), 0
	content = 'User Code: [B]%s[/B][CR]User Pin: [B]%s[/B]' % (user_code, user_pin)
	progressDialog = kodi_utils.progress_dialog('infinite Online Sync', kodi_utils.get_icon('firebase'))
	progressDialog.update(content, 100)
	while not progressDialog.iscanceled() and time_passed < expires_in:
		time_passed = get_timestamp() - start
		progress = int(100 * (expires_in - time_passed) / float(expires_in))
		progress = max(0, min(100, progress))
		progressDialog.update(content, progress)
		kodi_utils.sleep(1000)
	try: progressDialog.close()
	except: pass
	return

def delete_current_data(db_name, table_name, dbcon=None):
	if dbcon is None: dbcon = open_db(db_name)
	with dbcon:
		dbcon.execute('DELETE FROM %s' % table_name)
		dbcon.execute('VACUUM')

def make_sql_inserts(data_dict_list):
	columns = list(data_dict_list[0].keys())
	columns_str = ', '.join(columns)
	placeholders_str = ', '.join(['?'] * len(columns))
	data_tuples = [tuple(row[col] for col in columns) for row in data_dict_list]
	return columns_str, placeholders_str, data_tuples

def make_call(method, url, user_hex, session=None, data=None, timeout=10, show_busy=False):
	if show_busy: kodi_utils.show_busy_dialog()
	if not session:
		session = kodi_utils.make_session()
		close_session = True
	else: close_session = False
	user_url = get_setting('infinite.fen_online.url', o_url)
	url = base_url % (user_url, user_hex, url)
	try: response = session.request(method=method.upper(), url=url, json=data, timeout=timeout)
	except Exception as e:
		logger('make_call Error', str(e))
		response = None
	if close_session: session.close()
	if show_busy: kodi_utils.hide_busy_dialog()
	if response.status_code != 200:
		error = '%s: %s' % (response.status_code, response.json().get('error', 'Error Unknown'))
		logger('make_call error response', error)
		kodi_utils.notification(error)
	return response

def create_account(user_hex, session=None):
	if not session: session = kodi_utils.make_session()
	try:
		user_url = get_setting('infinite.fen_online.url', o_url)
		target_url = user_url + '/registration_open.json'
		response = session.request(method='GET', url=target_url)
		if response.status_code != 200 or response.json() != True:
			logger('Registration failed', 'Server registrations are currently closed')
			return False
	except: return False
	try:
		response = make_call('PUT', 'profile', user_hex, session=session, data={'activated': True, 'registration_key': registration_key})
		if response.status_code == 200: return True
		else:
			logger('Registration failed with server status', response.status_code)
			return False
	except Exception as e:
		logger('Exception during profile upload', str(e))
		return False

def make_user_keys(user_code, user_pin):
	credentials = '%s::%s' % (user_code, user_pin)
	credentials = credentials.encode('utf-8')
	dynamic_salt = f'Kodi_Fen_{user_code}_2026'.encode('utf-8')
	user_hex = hashlib.pbkdf2_hmac(hash_name='sha256', password=credentials, salt=dynamic_salt, iterations=100000).hex()
	crypto_key_hex = hashlib.pbkdf2_hmac(hash_name='sha256', password=credentials, salt=dynamic_salt[::-1], iterations=100000).hex()
	return user_hex, crypto_key_hex

def encrypt_data(data_dict, crypto_key_hex):
	try:
		key_bytes = bytes.fromhex(crypto_key_hex)
		json_bytes = json.dumps(data_dict).encode('utf-8')
		compressed_bytes = zlib.compress(json_bytes, level=9)
		nonce = os.urandom(12)
		ciphertext = chacha20_crypt(compressed_bytes, key_bytes, nonce)
		return base64.b64encode(nonce + ciphertext).decode('utf-8')
	except: return logger(f'error encrypt_data data_dict: {data_dict}: {format_exc()}')

def decrypt_data(base64_string, crypto_key_hex):
	try:
		key_bytes = bytes.fromhex(crypto_key_hex)
		raw_bytes = base64.b64decode(base64_string.encode('utf-8'))
		nonce = raw_bytes[:12]
		ciphertext = raw_bytes[12:]
		compressed_bytes = chacha20_crypt(ciphertext, key_bytes, nonce)
		json_bytes = zlib.decompress(compressed_bytes)
		return json.loads(json_bytes.decode('utf-8'))
	except: return logger(f'error decrypt_data base64_string: {base64_string}: {format_exc()}')

def process_rows(db_path, table_name):
	try:
		with open_db(db_path, row_factory=True) as dbcon:
			local_rows = dbcon.execute('SELECT * FROM %s' % table_name).fetchall()
		return local_rows
	except Exception as e:
		logger(f'error {e}\nprocess_rows  no data found on table_name: {table_name}: {format_exc()}')
		return []

def process_push(db_name, table_name, crypto_key_hex, payload):
	timestamp = set_last_sync(table_name)
	data_dict_list = process_rows(db_name, table_name)
	payload[table_name] = encrypt_data(data_dict_list, crypto_key_hex)
	payload['last_updated_data/%s' % table_name] = timestamp
	return payload

def process_pull(db_name, table_name, timestamp, data_dict_list):
	try: columns_str, placeholders_str, data_tuples = make_sql_inserts(data_dict_list)
	except: return False
	with open_db(db_name) as dbcon:
		delete_current_data(db_name, table_name, dbcon=dbcon)
		query = 'INSERT OR REPLACE INTO %s (%s) VALUES (%s)' % (table_name, columns_str, placeholders_str)
		result = dbcon.executemany(query, data_tuples)
	# dbcon.close()
	set_last_sync(table_name, timestamp)
	logger('Pull Sync Status Inserted into (%s, %s) %s rows from %s tuples.' % (db_name, table_name, result.rowcount, len(data_dict_list)))
	return result.rowcount == len(data_dict_list)
