# -*- coding: utf-8 -*-
import os
import json
import copy
from urllib.parse import parse_qsl, unquote
from windows.base_window import BaseDialog
from modules import kodi_utils
logger = kodi_utils.logger

class List(BaseDialog):
	'''
	modes:				select: select one
						basic: up/down, enable/disable
						move: up/down
						enable: enabe/disable
						full: up/down, enable/disable, add

	all_items: 			items for list.
	enumerate: 			enumerate the list for display
	active_enabled: 	int value for number of listitems needing to be enabled from the top of the list.
						i.e. a value of 8 means the first 8 items are always enabled, the rest disabled
	listitem_preface: 	str for prefix of listitem name
	narrow_window:      defaults to 'true'
	buttons:            select/deselect Buttons used. Defaults to 'false'
	'''
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.window_id = 2025
		self.kwargs = kwargs
		self.all_items = copy.deepcopy(self.kwargs['all_items'])
		self.mode = self.kwargs.get('mode', 'basic')
		self.return_position = self.kwargs.get('return_position')
		self.enumerate = self.kwargs.get('enumerate', 'false') == 'true'
		self.active_enabled = self.kwargs.get('active_enabled')
		self.listitem_preface = self.kwargs.get('listitem_preface')
		self.heading = self.kwargs.get('heading', 'infinite')
		self.buttons = self.kwargs.get('buttons', 'false')
		self.narrow_window = self.kwargs.get('narrow_window', 'false')
		self.item_list = []
		self.chosen_indexes = []
		self.selected = None
		self.position = None
		self.set_properties()
		self.set_active_navigation_buttons()
		self.make_menu()

	def onInit(self):
		self.add_items(self.window_id, self.item_list)
		self.setFocusId(self.focus)

	def run(self):
		self.doModal()
		self.clearProperties()
		if self.mode == 'select':
			if self.selected is not None:
				if self.return_position: return self.selected
				return self.all_items[self.selected]
			return None
		return self.all_items

	def onClick(self, controlId):
		if controlId in (10, 11):
			for i in self.all_items: i['enabled'] = {10: True, 11: False}[controlId]
			self.refresh_menu()
		self.position = self.get_position(self.window_id)
		if self.position < 0: return
		if controlId == 300: self.add_item(self.position)
		if controlId == 301: self.move_item(self.position, direction=-1)
		elif controlId == 302: self.move_item(self.position, direction=1)
		elif controlId == 303: self.toggle_item(self.position)
		else: return

	def onAction(self, action):
		if self.mode == 'select':
			if action in self.selection_actions:
				if self.position is None: return self.close()
				self.selected = self.position
				return self.close()
		if action in self.closing_actions: return self.close()

	def make_menu(self):
		def builder():
			for count, item in enumerate(self.all_items, 1):
				listitem = self.make_listitem()
				name1 = item.get('name') or item.get('name1') or item.get('line1') or ''
				name2 = item.get('name2') or item.get('line2') or ''
				if self.listitem_preface: name1 = self.listitem_preface + name1
				if self.enumerate: name1 = '%02d. %s' % (count, name1)
				if 'enabled' in item: listitem.setProperty('enabled', 'true' if item['enabled'] else 'false')
				if 'icon' in item: listitem.setProperty('icon', item['icon'])
				else: listitem.setProperty('icon', '')
				listitem.setProperty('name1', name1)
				listitem.setProperty('name2', name2)
				yield listitem
		self.enforce_active_enabled()
		self.item_list = list(builder())

	def enforce_active_enabled(self):
		if self.active_enabled == None: return
		for index, item in enumerate(self.all_items): item['enabled'] = index < self.active_enabled

	def toggle_item(self, position):
		self.all_items[position]['enabled'] = not self.all_items[position]['enabled']
		self.refresh_menu()

	def move_item(self, position, direction):
		total_items = len(self.all_items)
		if total_items <= 1: return
		target = (position + direction) % total_items
		moving_item = self.all_items.pop(position)
		self.all_items.insert(target, moving_item)
		for index, item in enumerate(self.all_items): item['position'] = index
		self.refresh_menu(new_focus=target)

	def refresh_menu(self, new_focus=None):
		if new_focus is None: new_focus = self.get_position(self.window_id)
		self.make_menu()
		self.reset_window(self.window_id)
		self.add_items(self.window_id, self.item_list)
		self.select_item(self.window_id, new_focus)

	def add_item(self, position):
		target = position + 1
		browsed_result = self._path_browser()
		if browsed_result == None: return
		menu_item = self._get_menu_item(browsed_result['file'])
		name, icon = browsed_result['label'], self._get_icon_var(browsed_result['thumbnail'])
		menu_name = self._get_external_name_input(name) or name
		icon_choice = self._icon_select(default_icon=icon)
		menu_item.update({'name': menu_name, 'iconImage': icon_choice, 'icon': kodi_utils.get_icon(icon_choice), 'enabled': True})
		self.all_items.insert(target, menu_item)
		for index, item in enumerate(self.all_items): item['position'] = index
		self.refresh_menu()

	def _path_browser(self, label='', file='plugin://plugin.video.infinite?mode=navigator.main&full_list=true', thumbnail=''):
		kodi_utils.show_busy_dialog()
		results = kodi_utils.jsonrpc_get_directory(file)
		kodi_utils.hide_busy_dialog()
		list_items = []
		if file != 'plugin://plugin.video.infinite?mode=navigator.main&full_list=true':
			list_items.append({'line1': 'Use [B]%s[/B] As Path' % label, 'icon': thumbnail, 'value': json.dumps({'label': label, 'file': file, 'thumbnail': thumbnail})})
		list_items.extend([{'line1': '%s >>' % i['label'], 'icon': i['thumbnail'],
			'value': json.dumps({'label': i['label'], 'file': '%s%s' % (i['file'], '&full_list=true') if 'navigator.main' in i['file'] else i['file'],
								'thumbnail': i['thumbnail']})} for i in results])
		kwargs = {'heading': 'Path Browser', 'all_items': list_items, 'mode': 'select'}
		choice = kodi_utils.list_dialog(**kwargs)
		if choice == None: return None
		choice = choice['value']
		choice = json.loads(choice)
		if choice['file'] == file: return choice
		else: return self._path_browser(**choice)

	def _get_menu_item(self, path):
		return dict(parse_qsl(path.replace('plugin://plugin.video.infinite/?','')))

	def _get_icon_var(self, icon_path):
		try:
			all_icons = kodi_utils.get_all_icons()
			icon_value = unquote(icon_path)
			icon_value = os.path.basename(os.path.normpath(icon_value))
			icon_value = icon_value.replace('.png/', '').replace('.png', '')
			icon_var = [i for i in all_icons if i == icon_value][0]
		except: icon_var = 'folder'
		return icon_var

	def _icon_select(self, default_icon=''):
		if default_icon.startswith('http') or 'plugin.video.infinite' in default_icon: return default_icon
		all_icons = kodi_utils.get_all_icons()
		if default_icon:
			try:
				all_icons.remove(default_icon)
				all_icons.insert(0, default_icon)
			except: pass
			list_items = [{'line1': i if i != default_icon else '%s (default)' % default_icon, 'icon': kodi_utils.get_icon(i), 'value': i} for i in all_icons]
		else: list_items = [{'line1': i, 'icon': kodi_utils.get_icon(i), 'value': i} for i in all_icons]
		kwargs = {'heading': 'Choose Icon', 'all_items': list_items, 'mode': 'select'}
		choice = kodi_utils.list_dialog(**kwargs)
		if choice: choice = choice['value']
		return choice

	def _get_external_name_input(self, current_name):
		new_name = kodi_utils.kodi_dialog().input('', defaultt=current_name)
		if new_name == current_name: return None
		return new_name

	def set_active_navigation_buttons(self):
		included_buttons = {'basic': ['301', '302', '303'], 'move': ['301', '302'], 'enable': ['303'], 'full': ['300', '301', '302', '303'], 'select': ['2025']}[self.mode]
		for button_id in included_buttons: self.setProperty('%s.enabled' % button_id, 'true')
		self.focus = int(included_buttons[-1])

	def set_properties(self):
		self.setProperty('heading', self.heading)
		self.setProperty('mode', self.mode)
		self.setProperty('narrow_window', self.narrow_window)
		self.setProperty('buttons', self.buttons)

class Confirm(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.ok_label = kwargs['ok_label']
		self.cancel_label = kwargs['cancel_label']
		self.text = kwargs['text']
		self.heading = kwargs['heading'] or 'Infinite'
		self.default_control = kwargs['default_control']
		self.selected = None
		self.set_properties()

	def onInit(self):
		self.setFocusId(self.default_control)

	def run(self):
		self.doModal()
		return self.selected

	def onClick(self, controlID):
		self.selected = {10: True, 11: False}[controlID]
		self.close()

	def onAction(self, action):
		if action in self.closing_actions: self.close()

	def set_properties(self):
		self.setProperty('ok_label', self.ok_label)
		self.setProperty('cancel_label', self.cancel_label)
		self.setProperty('text', self.text)
		self.setProperty('heading', self.heading)

class OK(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.ok_label = kwargs.get('ok_label')
		self.text = kwargs['text']
		self.heading = kwargs['heading'] or 'Infinite'
		self.set_properties()

	def onInit(self):
		self.setFocusId(10)

	def run(self):
		self.doModal()

	def onClick(self, controlID):
		self.close()

	def onAction(self, action):
		if action in self.closing_actions:
			self.close()

	def set_properties(self):
		self.setProperty('ok_label', self.ok_label)
		self.setProperty('text', self.text)
		self.setProperty('heading', self.heading)
