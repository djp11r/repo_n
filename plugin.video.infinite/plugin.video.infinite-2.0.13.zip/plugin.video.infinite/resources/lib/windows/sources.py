# -*- coding: utf-8 -*-
import time
import json
from traceback import format_exc
from windows.base_window import BaseDialog
from caches.settings_cache import set_setting
from modules.utils import TaskPool, list_to_string
from modules.settings import provider_sort_ranks, avoid_episode_spoilers, max_threads
from modules.meta_lists import filter_mappings
from modules.kodi_utils import get_icon, kodi_dialog, hide_busy_dialog, addon_fanart, ok_dialog, notification, img_url, logger, list_dialog


class SourcesResults(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.window_id = 2000
		self.filter_window_id = 2100
		self.filter_items_made = False
		self.selected = False
		self.results = kwargs.get('results')
		self.uncached_results = kwargs.get('uncached_results', [])
		self.info_highlights_dict = kwargs.get('scraper_settings')
		self.episode_group_label = kwargs.get('episode_group_label', '')
		self.prescrape = kwargs.get('prescrape')
		self.meta = kwargs.get('meta')
		self.filters_ignored = kwargs.get('filters_ignored', False)
		self.meta_get = self.meta.get
		self.empty_poster = get_icon('box_office')
		self.addon_fanart = addon_fanart()
		self.poster = self.meta_get('poster') or self.empty_poster
		self.prerelease_values, self.prerelease_key = ('CAM', 'SCR', 'TELE'), 'CAM/SCR/TELE'
		self.make_items()
		self.set_properties()

	def onInit(self):
		self.filter_applied = False
		self.set_image(200, self.poster)
		self.add_items(self.window_id, self.item_list)
		self.make_starting_filter_item()
		self.setFocusId(self.window_id)

	def run(self):
		self.doModal()
		self.clearProperties()
		self.clear_home_property('window_theme.sources')
		hide_busy_dialog()
		return self.selected

	def onAction(self, action):
		if self.get_visibility('Control.HasFocus(%s)' % self.filter_window_id):
			if not self.filter_items_made: self.make_filter_items()
			return self.filter_action(action)
		chosen_listitem = self.get_listitem(self.window_id)
		if action in self.closing_actions:
			if self.filter_applied: return self.clear_filter()
			self.selected = (None, '')
			return self.close()
		elif action in self.selection_actions:
			if self.prescrape and chosen_listitem.getProperty('perform_full_search') == 'true':
				self.selected = ('perform_full_search', '')
				return self.close()
			chosen_source = self.results[int(chosen_listitem.getProperty('position'))-1]
			# if 'Uncached' in chosen_source.get('cache_provider', ''):
			# 	from modules.debrid import manual_add_magnet_to_cloud
			# 	return manual_add_magnet_to_cloud({'mode': 'manual_add_magnet_to_cloud', 'provider': chosen_source['debrid'], 'magnet_url': chosen_source['url']})
			self.selected = ('play', chosen_source)
			return self.close()
		elif action in self.context_actions:
			source = self.results[int(chosen_listitem.getProperty('position'))-1]
			choice = self.context_menu(source)
			if choice: return self.execute_code('RunPlugin(%s)' % self.build_url(choice))
		elif action in self.closing_actions:
			if self.filter_applied: return self.clear_filter()
			self.selected = (None, '')
			return self.close()

	def make_items(self, filtered_list=None):
		def builder(count, item):
			try:
				get = item.get
				listitem = self.make_listitem()
				set_properties = listitem.setProperties
				scrape_provider, source, quality, name = get('scrape_provider'), get('source'), get('quality', 'SD'), get('name')
				quality_lower = quality.lower()
				pack = get('package', 'false') in ('true', 'show', 'season')
				extraInfo = get('extraInfo', '')
				if pack: extraInfo = '[B]%s PACK[/B] | %s' % (get('package').upper(), extraInfo)
				if self.episode_group_label: extraInfo = '%s | %s' % (self.episode_group_label, extraInfo)
				extraInfo = '%s | %s' % (get('size_label') or '', extraInfo)
				extraInfo = extraInfo.rstrip('| ')
				if scrape_provider == 'external':
					source_name = get('provider_site')
					provider = source.title()
					provider_lower = provider.lower()
					if highlight_type == 0: key = provider_lower
					else: key = quality_lower
				else:
					source_name = source.title()
					provider = 'folders'
					if highlight_type == 0: key = provider
					else: key = quality_lower
				set_properties({'name': name, 'source_name': source_name, 'count': '%02d.' % count, 'extraInfo': extraInfo,
								'quality': quality.upper(), 'position': str(count), 'source': json.dumps(item), 'provider': provider, 'highlight': self.info_highlights_dict[key], 'source_type': source})
				item_list.append((listitem, count)) # yield listitem
			except Exception as e: logger(f'error builder: {e} format_exc: {format_exc()}')

		try:
			item_list = []
			highlight_type = self.info_highlights_dict['highlight_type']
			if filtered_list:
				threads = TaskPool().tasks_enumerate(builder, filtered_list)
				[i.join() for i in threads]
				item_list.sort(key=lambda k: k[1])
				item_list = [i[0] for i in item_list]
				return item_list
			threads = TaskPool().tasks_enumerate(builder, self.results)
			[i.join() for i in threads]
			item_list.sort(key=lambda k: k[1])
			self.item_list = [i[0] for i in item_list]
			if self.prescrape:
				prescrape_listitem = self.make_listitem()
				prescrape_listitem.setProperty('perform_full_search', 'true')
			self.total_results = str(len(self.item_list))
			if self.prescrape: self.item_list.append(prescrape_listitem)
		except Exception as e: logger(f'error make_items: {e} format_exc: {format_exc()}')

	def make_starting_filter_item(self):
		listitem = self.make_listitem()
		self.add_items(self.filter_window_id, [listitem.setProperties({'label': '', 'filter_type': '', 'filter_value': ''})])

	def make_filter_items(self):
		def builder(count, item):
			listitem = self.make_listitem()
			listitem.setProperties({'label': item[0], 'filter_type': item[1], 'filter_value': item[2]})
			filter_list.append((listitem, count))
		filter_list = []
		duplicates = set()
		qualities = [i.getProperty('quality') for i in self.item_list \
							if not (i.getProperty('quality') in duplicates or duplicates.add(i.getProperty('quality'))) \
							and not i.getProperty('quality') == '']
		if any(i in self.prerelease_values for i in qualities): qualities = [i for i in qualities if not i in self.prerelease_values] + [self.prerelease_key]
		qualities.sort(key=('4K', '1080P', '720P', 'SD', 'CAM/SCR/TELE').index)
		quality_totals = {i: len([x for x in self.item_list if x.getProperty('quality') == i]) for i in qualities}
		if 'CAM/SCR/TELE' in qualities: quality_totals['CAM/SCR/TELE'] = len([i for i in self.item_list if i.getProperty('quality') in self.prerelease_values])
		duplicates = set()
		providers = [i.getProperty('provider') for i in self.item_list \
							if not (i.getProperty('provider') in duplicates or duplicates.add(i.getProperty('provider'))) \
							and not i.getProperty('provider') == '']
		provider_totals = {i: len([x for x in self.item_list if x.getProperty('provider') == i]) for i in providers}
		sort_ranks = provider_sort_ranks()
		provider_choices = sorted(sort_ranks.keys(), key=sort_ranks.get)
		provider_choices = [i.upper() for i in provider_choices]
		try: providers.sort(key=provider_choices.index)
		except: pass
		qualities = [('Show [B]%s[/B] Only | [B]%d[/B] Results' % (i, quality_totals[i]), 'quality', i) for i in qualities]
		providers = [('Show [B]%s[/B] Only | [B]%d[/B] Results' % (i, provider_totals[i]), 'provider', i) for i in providers]
		data = []
		data.extend(qualities)
		data.extend(providers)
		data.extend([('Filter by [B]Title[/B]...', 'special', 'title'), ('Filter by [B]Info[/B]...', 'special', 'extraInfo')])
		threads = TaskPool().tasks_enumerate(builder, data)
		[i.join() for i in threads]
		filter_list.sort(key=lambda k: k[1])
		filter_list = [i[0] for i in filter_list]
		self.reset_window(self.filter_window_id)
		self.add_items(self.filter_window_id, filter_list)
		self.filter_items_made = True

	def filter_action(self, action):
		if action == self.right_action or action in self.closing_actions:
			self.select_item(self.filter_window_id, 0)
			self.setFocusId(self.window_id)
		filtered_list = []
		if action in self.selection_actions:
			chosen_listitem = self.get_listitem(self.filter_window_id)
			filter_type, filter_value = chosen_listitem.getProperty('filter_type'), chosen_listitem.getProperty('filter_value')
			if filter_type in ('quality', 'provider'):
				if filter_value == self.prerelease_key: filtered_list = [i for i in self.item_list if i.getProperty(filter_type) in self.prerelease_values]
				else: filtered_list = [i for i in self.item_list if i.getProperty(filter_type) == filter_value]
			elif filter_type == 'special':
				if filter_value == 'title':
					keywords = kodi_dialog().input('Enter Keyword (Comma Separated for Multiple)')
					if not keywords: return
					keywords.replace(' ', '')
					keywords = keywords.split(',')
					choice = [i.upper() for i in keywords]
					filtered_list = [i for i in self.item_list if all(x in i.getProperty('name') for x in choice)]
				elif filter_value == 'extraInfo':
					all_items = sorted([{'name': v, 'value': k} for k, v in filter_mappings().items()], key=lambda x: x['name'])
					all_items = [{**d, 'enabled': False, 'icon': self.poster} for d in all_items]
					kwargs = {'heading': 'Filter Results', 'all_items': all_items, 'mode': 'enable'}
					choice = list_dialog(**kwargs)
					if choice is None: return
					all_items = sorted(choice, key=lambda k: k.get('position') or 0)
					chosen_tags = [i['value'] for i in all_items if i['enabled']]
					filtered_list = []
					for i in self.item_list:
						extra_info = i.getProperty('extraInfo') or ''
						info_tags = [i.strip() for i in extra_info.split('|')]
						if all(i in info_tags for i in chosen_tags): filtered_list.append(i)
				elif filter_value == 'showuncached': filtered_list = self.make_items(self.uncached_results)
				else: return
			if not filtered_list: return ok_dialog(text='No Results')
			self.set_filter(filtered_list)

	def set_properties(self):
		self.set_home_property('window_theme.sources', self.get_home_property('window_theme'))
		self.setProperty('fanart', self.meta_get('fanart') or self.addon_fanart)
		self.setProperty('clearlogo', self.meta_get('clearlogo') or '')
		self.setProperty('title', self.meta_get('title'))
		self.setProperty('total_results', self.total_results)
		self.setProperty('filters_ignored', '| Filters Ignored' if self.filters_ignored else '')
		tvdata = '' if not self.meta_get('season') else 'season: %s episode: %s' %(self.meta_get('season'), self.meta_get('episode'))
		self.setProperty('showinfo', 'Title: %s[CR]Premiered: %s[CR]%s' % (self.meta_get('title'), self.meta_get('premiered'), tvdata) or '')

	def context_menu(self, item):
		down_file_params, down_pack_params, browse_pack_params, add_magnet_to_cloud_params = None, None, None, None
		item_get = item.get
		# item_id, name, magnet_url, info_hash = item_get('id', None), item_get('name'), item_get('url', 'None'), item_get('hash', 'None')
		provider_source, scrape_provider, cache_provider = item_get('source'), item_get('scrape_provider'), item_get('cache_provider', 'None')
		uncached = 'Uncached' in cache_provider
		source, meta_json = json.dumps(item), json.dumps(self.meta)
		choices, down_play_params = [], {}
		choices_append = choices.append
		if not uncached and scrape_provider != 'folders':
			down_file_params = {'mode': 'downloader.runner', 'action': 'meta.single', 'name': self.meta_get('rootname', ''), 'source': source,
								'url': None, 'provider': scrape_provider, 'meta': meta_json}
			down_play_params = {'mode': 'download_and_watch', 'action': 'meta.single', 'source': source, 'meta': meta_json, 'name': self.meta_get('rootname', ''), 'provider': scrape_provider, 'url': None}
		choices_append(('Info', 'results_info'))
		if down_file_params:
			choices_append(('Download File', down_file_params))
			choices_append(('Download and Watch Now', down_play_params))
		if not choices: return notification('No Options Available')
		all_items = [{'line1': i[0], 'icon': self.poster, 'value': i[1]} for i in choices]
		kwargs = {'heading': 'Choose Image Type to Browse', 'all_items': all_items, 'mode': 'select'}
		choice = list_dialog(**kwargs)
		if choice: choice = choice['value']
		return choice

	def set_filter(self, filtered_list):
		self.filter_applied = True
		self.reset_window(self.window_id)
		self.add_items(self.window_id, filtered_list)
		self.setFocusId(self.window_id)
		self.setProperty('total_results', str(len(filtered_list)))
		self.setProperty('filter_applied', 'true')
		self.setProperty('filter_info', '| Press [B]BACK[/B] to Cancel')

	def clear_filter(self):
		self.filter_applied = False
		self.reset_window(self.window_id)
		self.add_items(self.window_id, self.item_list)
		self.setFocusId(self.window_id)
		self.select_item(self.filter_window_id, 0)
		self.setProperty('total_results', self.total_results)
		self.setProperty('filter_applied', 'false')
		self.setProperty('filter_info', '')

class SourcesPlayback(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.meta = kwargs.get('meta')
		self.is_canceled, self.skip_resolve, self.resume_choice = False, False, None
		self.meta_get = self.meta.get
		self.addon_fanart = addon_fanart()
		self.start_time = time.time()
		self.enable_scraper()

	def run(self):
		self.doModal()
		self.clearProperties()
		self.clear_modals()

	def onClick(self, controlID):
		self.resume_choice = {10: 'resume', 11: 'start_over', 12: 'cancel'}[controlID]

	def onAction(self, action):
		if action in self.closing_actions: self.is_canceled = True
		elif action == self.right_action and self.window_mode == 'resolver': self.skip_resolve = True

	def iscanceled(self):
		return self.is_canceled

	def skip_resolved(self):
		status = self.skip_resolve
		self.skip_resolve = False
		return status

	def reset_is_cancelled(self):
		self.is_canceled = False

	def enable_scraper(self):
		self.window_mode = 'scraper'
		self.set_scraper_properties()

	def enable_resolver(self):
		self.window_mode = 'resolver'
		self.set_resolver_properties()

	def enable_resume(self, percent):
		self.window_mode = 'resume'
		self.set_resume_properties(percent)

	def busy_spinner(self, toggle='true'):
		self.setProperty('enable_busy_spinner', toggle)

	def set_scraper_properties(self):
		title, genre = self.meta_get('title'), list_to_string(self.meta_get('genre', ''))
		poster, year = self.meta_get('poster') or self.addon_fanart, str(self.meta_get('year'))
		fanart, clearlogo = self.meta_get('fanart') or self.addon_fanart, self.meta_get('clearlogo') or ''
		self.setProperty('window_mode', self.window_mode)
		self.setProperty('fanart', fanart)
		self.setProperty('clearlogo', clearlogo)
		self.setProperty('title', title)
		self.setProperty('genre', genre)
		self.setProperty('year', year)
		self.setProperty('poster', poster)
		self.setProperty('result_highlight_4k', 'FFFF3334')
		self.setProperty('result_highlight_1080p', 'FFE6B800')
		self.setProperty('result_highlight_720p', 'FF3C9900')
		self.setProperty('result_highlight_sd', 'FFCAFFFF')
		self.setProperty('flag_highlight', 'FF7C7C7C')
		self.setProperty('result_highlight', 'FFFFFFFF')
		if self.meta_get('media_type') == 'episode':
			ep_name = self.meta_get('ep_name') or ''
			title2 = f'S{self.meta_get("season")}E{self.meta_get("episode")}:: {ep_name} :: premiered: {self.meta_get("premiered", "")}'
		else: title2 = f'Year: {self.meta_get("year")}'
		self.setProperty('title2', title2)

	def set_resolver_properties(self):
		if self.meta_get('media_type') == 'movie': self.text = self.meta_get('plot')
		else:
			plot = self.meta_get('plot', '') or self.meta_get('tvshow_plot', '')
			self.text = '[B]%02dx%02d - %s[/B][CR][CR]%s' % (self.meta_get('season'), self.meta_get('episode'), self.meta_get('ep_name', 'N/A').upper(), plot)
		self.setProperty('window_mode', self.window_mode)
		self.setProperty('text', self.text)

	def set_resume_properties(self, percent):
		self.setProperty('window_mode', self.window_mode)
		self.setProperty('resume_percent', percent)
		self.setFocusId(10)
		self.update_resumer()

	def update_scraper(self, results_sd, results_720p, results_1080p, results_4k, results_total, content='', percent=0):
		self.setProperty('results_4k', str(results_4k))
		self.setProperty('results_1080p', str(results_1080p))
		self.setProperty('results_720p', str(results_720p))
		self.setProperty('results_sd', str(results_sd))
		self.setProperty('results_total', str(results_total))
		self.setProperty('percent', f'{percent:.2f}')
		self.set_text(2001, content)
		self.setProperty('elapsed_time', f'{int(max((time.time() - self.start_time), 0))}')

	def update_resolver(self, text='', percent=0):
		try: self.setProperty('percent', f'{percent:.2f}')
		except: pass
		if text: self.set_text(2002, text)

	def update_resumer(self):
		count = 0
		while self.resume_choice is None:
			percent = int((float(count)/10000)*100)
			if percent >= 100: self.resume_choice = 'resume'
			self.setProperty('percent', str(percent))
			count += 100
			self.sleep(100)
