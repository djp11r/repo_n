# -*- coding: utf-8 -*-

import datetime
import time
from random import choice
from traceback import format_exc

from caches.base_cache import clean_databases, clrcache_version_update
from caches.main_cache import main_cache
from caches.meta_cache import meta_cache
from caches.settings_cache import get_setting, default_settings
from modules.kodi_utils import update_metadb, confirm_dialog, logger, notification, ok_dialog, show_text, sleep
from modules.metadata import tvshow_meta
from modules.watched_status import get_progress_percent, get_next_episodes
from modules.settings import tmdb_api_key, auto_nextep_settings, get_folderscraper_info
from windows.base_window import create_window, open_window
from modules.source_utils import external_sources, check_title
from modules.utils import get_datetime, epoch_to_datetime
from indexers.dialogs import set_filter_sort
from scrapers import folders


def testting():
    data = set_filter_sort('source_sorting')
    logger(f'data = {repr(data)}')

def test_window(win='_noti'):
    # tmdb_id = 'Sony|The Kapil Sharma Show Season 4'
    action = None
    if win in ('sources_results', 'still_watching', 'infopop', 'playback', 'resolver', 'resume', 'progress', '_noti'):
        from modules.metadata import tvshow_meta
        api_key = tmdb_api_key()
        tmdb_id = 94997
        meta = tvshow_meta('tmdb_id', tmdb_id, api_key, get_datetime())
    if win == '_noti': # windows.next_episode <<<<<<<<<
        if not meta.get('season'):
            data = meta.get('season_data')[-1]
            season, episode = data.get('season_number') - 1, data.get('episode_count') - 1
            meta.update({'season': season, 'episode': episode, 'ep_name': meta.get('title')})
        status = choice(['series_premiere', 'season_premiere', 'mid_season_premiere', 'mid_season_finale', 'season_finale', 'series_finale'])
        meta.update({'episode_type': status})
        action = open_window(('windows.playback_notifications', 'NextEpisode'), 'playback_notifications.xml', meta=meta, default_action='cancel', test=True)
        if action in ('cancel', 'close'):
            meta.update({'stinger_keys': 'duringcreditsstinger'})
            action = open_window(('windows.playback_notifications', 'StingersNotification'), 'playback_notifications.xml', meta=meta, test=True)
        # if not action:
            # skip_option = get_skip_option()
            # action = open_window(('windows.skip', 'Skip'), 'skipmulti.xml', skip_option=skip_option, test=True, focus_button=201, window_style='end_skip')
    elif win == 'infopop': # windows.infopop <<<<<<<<<
        action = open_window(('windows.extras', 'Extras'), 'extras.xml', options_media_type=meta.get('media_type'), meta=meta, is_external='false')
    elif win == 'still_watching':
        action = open_window(('windows.playback_notifications', 'StillWatching'), 'playback_notifications.xml', test=True, meta=meta)
    elif win in ('playback', 'resolver', 'resume', 'progress'): # playback && resolver etc<<<<<<<
        # kwargs = {'meta': meta, 'text': 'ok i see', 'enable_buttons': True, 'true_button': 'Yes', 'false_button': 'No', 'focus_button': 11}
        kwargs = {'meta': meta, 'text': 'ok i see', 'enable_fullscreen': True}
        _threads = []
        start_time = time.time()
        scraper_timeout = int(get_setting('results.timeout', '30'))
        sleep_time, elapsed_time = 100, 0
        end_time = start_time + scraper_timeout
        from xbmc import Monitor
        from threading import Thread
        monitor = Monitor()
        if win in ('playback', 'resolver', 'resume'): progress_dialog = create_window(('windows.sources', 'SourcesPlayback'), 'sources_playback.xml', meta=meta)
        elif win == 'progress': progress_dialog = create_window(('windows.progress', 'Progress'), 'progress.xml', heading='progress', icon=meta.get('poster'))
        Thread(target=progress_dialog.run).start()
        if win == 'resolver': progress_dialog.enable_resolver()
        if win == 'resume': progress_dialog.enable_resume(15)
        remaining_providers = ['freeworldnews.tv', 'playersb.com', 'vedshare.com', 'voeunblock8.com', 'youtu.be']
        try:
            while not progress_dialog.iscanceled() and not monitor.abortRequested() and elapsed_time < end_time:
                if progress_dialog.iscanceled(): break
                sources_total = sources_4k = sources_1080p = sources_720p = sources_sd = 5
                current_time = time.time()
                elapsed_time = current_time - start_time
                line1 = ', '.join(remaining_providers).upper()
                percent = int((elapsed_time / float(scraper_timeout)) * 100)
                try:
                    if win == 'playback': progress_dialog.update_scraper(sources_sd, sources_720p, sources_1080p, sources_4k, sources_total, line1, percent)
                    elif win == 'resolver': progress_dialog.update_resolver(percent=percent)
                    elif win == 'resume': progress_dialog.update_resumer()
                    elif win == 'progress': progress_dialog.update(percent=percent)
                except: logger(f'error: {format_exc()}')
                sleep(100)
                # logger(f'percent: {percent} elapsed_time: {elapsed_time}')
                if percent >= 100: break
                if current_time >= end_time: break
        except: logger(f'error: {format_exc()}')
        progress_dialog.close()
        try: del monitor
        except: pass
    elif win == 'sources_results': # windows.select_ok <<<<<<<<<<<<
        results = [{'source': 'tvarticles', 'quality': 'SD', 'info': 'All part: Single', 'url': 'https://tvarticles.org/vidd.php?id=2239785', 'direct': False, 'name': 'The Kapil Sharma Show S1E226', 'name': 'The Kapil Sharma Show S1E226', 'provider_site': 'tvarticles', 'scrape_provider': 'external', 'extraInfo': 'All part: Single', 'size_label': None, 'size': 0}, {'source': 'gdrive', 'name': 'Modern.Family.S11E08.720p.WEB-HD.x264-Pahe.in.mkv', 'name_info': '.720p.web.hd.x264.pahe.in.mkv.', 'quality': '720p', 'url': 'https://gd.djp97s.workers.dev/Modern.Family.S11E08.720p.WEB-HD.x264-Pahe.in.mkv', 'info': 'AVC | WEB | MKV', 'direct': True, 'size': 0.15, 'name': 'Modern Family S11E8', 'provider_site': 'gdrive', 'scrape_provider': 'external', 'extraInfo': 'AVC | WEB | MKV', 'size_label': '0.15 GB',  'quality_rank': 3 }, {'source': 'mixdrop.co', 'quality': 'SD', 'info': 'MP4 | ', 'url': 'https://mixdrop.co/e/wn6dpeo6szdwlx', 'direct': False, 'name': 'Modern Family S11E8',  'name': 'Modern Family S11E8', 'provider_site': '123moviestv_me', 'scrape_provider': 'external', 'extraInfo': '', 'size_label': None, 'size': 0}]
        scraper_settings = {'highlight_type': 2, 'hoster_highlight': '', 'torrent_highlight': '', 'real-debrid': '', 'premiumize': '', 'alldebrid': '', 'rd_cloud': '', 'pm_cloud': '', 'ad_cloud': '', 'furk': '', 'easynews': '', 'folders': '', '4k': 'FFFF3334', '1080p': 'FFE6B800', '720p': 'FF3C9900', 'sd': 'FFCAFFFF'}
        action = open_window(('windows.sources', 'SourcesResults'), 'sources_results.xml', window_format='list', window_style='non_contrast', window_id=2000, results=results, meta=meta, scraper_settings=scraper_settings, prescrape=False, filters_ignored=False, uncached_results=[])
    # elif win in ('skip_win', 'updateskip', 'end_skip'): # windows.skip <<<<<<<<<<
        # logger(f'windowstyle: {windowstyle.lower()}')
        # skip_option = get_skip_option()
        # if win == 'skip_win': action = open_window(('windows.skip', 'Skip'), 'skipmulti.xml', skip_option=skip_option, test=True, focus_button=201, media_type='episode', window_style=0)
        # else: action = open_window(('windows.skip', 'Skip'), 'skipmulti.xml', skip_option=skip_option, test=True, focus_button=201, window_style='end_skip')
    elif win == 'select_ok_win': # windows.select_ok <<<<<<<<<<<<
        confirm_dialog()
        ok_dialog()
        show_text(heading='Infinite', text='ok i c')
    return

def cache_test():
    # main_cache.clean_hindi_lists()
    # clrcache_version_update(clr_cache=True, clr_navigator=False)
    # status = trakt_sync_activities()
    # logger(f'status: {status}')
    from caches.navigator_cache import navigator_cache
    list_contents = []
    #navigator_cache.set_list('Most', 'shortcut_folder', list_contents)

def get_folders(mtype='episode'):
    folder_info, internal_scraper_names = get_folderscraper_info()
    # logger(f'folder_info: {folder_info}\ninternal_scraper_names: {internal_scraper_names}')
    prescrape_scrapers = []
    if mtype == 'movie':
        info = {'media_type': 'movie', 'title': 'Star Wars: The Last Jedi', 'year': '2017', 'tmdb_id': 181808, 'imdb_id': 'tt2527336', 'aliases': [{'title': 'Star Wars: Episode VIII', 'country': ''}, {'title': 'Star Wars: Episode VIII – The Last Jedi', 'country': ''}, {'title': 'The Last Jedi', 'country': ''}, {'title': 'Star Wars - The Last Jedi - 3D', 'country': ''}, {'title': 'Star Wars: Episode VIII - The Last Jedi: Legendary', 'country': ''}, {'title': 'Star Wars: Episode 8 - The Last Jedi', 'country': ''}, {'title': 'Star Wars Episode VIII - The Last Jedi', 'country': ''}, {'title': 'Star Wars: Episode VIII - The Last Jedi 3D', 'country': ''}, {'title': 'Star Wars։ Episode VIII - The Last Jedi', 'country': ''}, {'title': 'Star Wars 8 - The Last Jedi', 'country': ''}, {'title': 'Star Wars: Episode VIII - The Last Jedi', 'country': ''}, {'title': 'Star Wars։ The Last Jedi (Episode VIII)', 'country': ''}, {'title': 'TLJ', 'country': ''}, {'title': 'Star Wars: The Last Jedi', 'country': ''}, {'title': 'Star Wars: The Last Jedi US', 'country': ''}], 'season': None, 'episode': None, 'tvdb_id': 'None', 'ep_name': None, 'expiry_times': (336, 0, 0), 'total_seasons': 1}
        scrape_provider, scraper_name, folder_path = 'folder1', 'English Enet', 'smb://cp:srusty@ENET/Media/ENet/English Movies/'
    else:
        info = {'media_type': 'episode', 'title': '24', 'year': '2001', 'tmdb_id': 1973, 'imdb_id': 'tt0285331', 'aliases': [{'title': 'Twenty Four', 'country': ''}, {'title': '24: Live Another Day', 'country': ''}, {'title': '24', 'country': ''}, {'title': '24 US', 'country': ''}], 'season': 1, 'episode': 2, 'tvdb_id': 76290, 'ep_name': 'Day 1 12:00 A.M.-1:00 A.M.', 'expiry_times': (240, 720, 720), 'total_seasons': 9}
        info = {'media_type': 'episode', 'title': 'Mirzapur Season 2', 'year': '2024', 'tmdb_id': 'Amazon Prime|mirzapur season 2', 'imdb_id': 'None', 'aliases': [{'title': 'Mirzapur Season 2', 'country': '', 'url': ''}], 'season': 2, 'episode': 1, 'tvdb_id': 'Amazon Prime|mirzapur season 2', 'ep_name': 'Episode 1', 'expiry_times': (72, 72, 240), 'total_seasons': 1}
        scrape_provider, scraper_name, folder_path = 'folder2', 'Folder 2', 'smb://cp:srusty@ENET/Media/ENet/TV Shows/'
    folders_sraper = folders.source(scrape_provider, scraper_name, folder_path)
    results = folders_sraper.results(info)
    logger(f'get_folders results: {results}')
    scraper_settings = {'highlight_type': 2, 'hoster_highlight': '', 'torrent_highlight': '', 'real-debrid': '', 'premiumize': '', 'alldebrid': '', 'rd_cloud': '', 'pm_cloud': '', 'ad_cloud': '', 'furk': '', 'easynews': '', 'folders': '', '4k': 'FFFF3334', '1080p': 'FFE6B800', '720p': 'FF3C9900', 'sd': 'FFCAFFFF'}
    if not results: notification('no result'); return
    action = open_window(('windows.sources', 'SourcesResults'), 'sources_results.xml',
            window_format='list', window_style='non_contrast', window_id=2000, results=results, meta=meta,
            scraper_settings=scraper_settings, prescrape=False, filters_ignored=False, uncached_torrents=[])
    logger(f'get_folders action: {action}')

def get_next_ep():
    from modules.episode_tools import EpisodeTools
    nextep_settings = auto_nextep_settings('autoplay_nextep')
    # nextep_settings = {'scraper_time': 70, 'window_percentage': 10, 'alert_method': 0, 'default_action': 'play', 'use_chapters': True, 'play_type': 'autoscrape_nextep'}
    nextep_settings.update({'window_time': 100, 'play_type': 'autoplay_nextep'})
    logger(f'nextep_settings: {nextep_settings}')
    url_params = EpisodeTools(meta, nextep_settings).next_episode_info()
    logger(f'url_params: {url_params}')
