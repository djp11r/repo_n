# -*- coding: utf-8 -*-
import functools
import threading
from apis import fen_online_api
from caches.base_cache import flush_wal
from modules.settings import fen_online_user_active
from modules.kodi_utils import logger

def single_sync(db_name, table_names):
	def decorator(func):
		@functools.wraps(func)
		def wrapper(*args, **kwargs):
			result = func(*args, **kwargs)
			if not fen_online_user_active(): return result
			if result:
				try:
					flush_wal(db_name)
					threading.Thread(target=fen_online_api.push_single, args=(db_name, table_names)).start()
				except Exception as e: logger('error single_sync decorator', str(e))
			return result
		return wrapper
	return decorator
