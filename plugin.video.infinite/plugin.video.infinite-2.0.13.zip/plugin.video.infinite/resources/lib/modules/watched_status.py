# -*- coding: utf-8 -*-
from datetime import datetime
from traceback import format_exc
from modules.fen_online_utils import single_sync
from caches.base_cache import connect_database, sqlite3, get_timestamp, serialize_db_value, deserialize_db_value
from modules.kodi_utils import kodi_progress_background, sleep, get_video_database_path, notification, kodi_refresh
from modules.utils import get_datetime, adjust_premiered_date, jsondate_to_datetime, sort_for_article, TaskPool
from modules import metadata, settings, kodi_utils
from modules.kodi_utils import logger

def get_database():
	return connect_database('watched_db')

def get_hidden_progress_items():
	try:
		watched_db = get_database()
		watched_info = watched_db.execute('SELECT status FROM watched_status WHERE db_type = ?', ('hidden_progress_items',)).fetchone()[0]
		watched_db.close()
		return deserialize_db_value(watched_info)
	except: return []

def update_hidden_progress(media_id):
	if not str(media_id).isdigit(): return
	current_hidden = set(get_hidden_progress_items())
	target_id = int(media_id)
	if target_id not in current_hidden: return
	current_hidden.discard(target_id)
	hide_unhide_progress_items({'action': 'undrop', 'media_type': 'shows', 'media_id': media_id, 'refresh': 'false'})

def hide_unhide_progress_items(params):
	action, media_id, refresh = params['action'], int(params.get('media_id', '0')), params.get('refresh', 'true') == 'true'
	current_items = get_hidden_progress_items() or []
	if action == 'drop': current_items.append(media_id)
	else: current_items.remove(media_id)
	watched_db = get_database()
	watched_db.execute('INSERT OR REPLACE INTO watched_status VALUES (?, ?, ?, ?)', ('hidden_progress_items', 'hidden', serialize_db_value(current_items), get_timestamp()))
	watched_db.close()
	active_tvshows_information(force_refresh=True)
	active_next_episodes_information(force_refresh=True)
	if refresh: kodi_refresh()

def get_last_played_value():
	return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

def make_batch_insert(action, media_type, media_id, season, episode, title, last_played, timestamp):
	if action == 'mark_as_watched': return (media_type, media_id, season, episode, last_played, title, timestamp)
	else: return (media_type, media_id, season, episode)

def refresh_container(refresh=True):
	if refresh: kodi_refresh()

def _get_data(string):
	result = None
	watched_db = get_database()
	cache_data = watched_db.execute('SELECT last_updated, status FROM watched_status WHERE db_type = ?', (string,)).fetchone()
	if cache_data and cache_data[0] > get_timestamp(): result = deserialize_db_value(cache_data[1])
	watched_db.close()
	return result

def _set_data(string, results):
	watched_db = get_database()
	watched_db.execute('INSERT OR REPLACE INTO watched_status VALUES (?, ?, ?, ?)', (string, 'active', serialize_db_value(results), get_timestamp(24)))
	watched_db.close()

def active_tvshows_information(status_type=None, force_refresh=False):
	def _process(item):
		media_id = item['media_id']
		meta = metadata.tvshow_meta('tmdb_id', media_id, api_key, current_date)
		watched_status = get_watched_status_tvshow(watched_info[media_id], meta.get('total_aired_eps'))[0]
		if watched_status == 1: item['status'] = 'watched'
		elif watched_status == 0: item['status'] = 'progress'
		results_append(item)
	if force_refresh: results = None
	else: results = _get_data('tvshows_information')
	if not results:
		results = []
		results_append = results.append
		api_key = settings.tmdb_api_key()
		current_date = get_datetime()
		watched_info = watched_info_tvshow()
		threads = TaskPool().tasks(_process, list(watched_info.values()))
		for i in threads: i.join()
		_set_data('tvshows_information', results)
		if force_refresh: return
	results = [i for i in results if i['status'] == status_type]
	if status_type == 'progress':
		hidden_items = set(str(k) for k in get_hidden_progress_items())
		if hidden_items: results = [i for i in results if str(i['media_id']) not in hidden_items]
	return results

def active_next_episodes_information(force_refresh=False):
	def _process(item):
		media_id = item['media_id']
		meta = metadata.tvshow_meta('tmdb_id', media_id, api_key, current_date)
		season_data = meta.get('season_data')
		season, episode = get_next(item['season'], item['episode'], season_data)
		if season and episode:
			episodes_data = metadata.episodes_meta(season, meta)
			if not episodes_data: return
			episode_item = next((i for i in episodes_data if i['episode'] == episode), None)
			if not episode_item: return
			episode_date, premiered = adjust_premiered_date(episode_item.get('premiered'), adjust_hours)
			if not episode_date or current_date < episode_date: return
			item.update({'season': season, 'episode': episode})
			results_append(item)
	if force_refresh: results = None
	else: results = _get_data('next_episodes_information')
	if not results:
		results = []
		results_append = results.append
		api_key = settings.tmdb_api_key()
		current_date = get_datetime()
		adjust_hours = settings.date_offset()
		data = get_next_episodes()
		threads = TaskPool().tasks(_process, list(data))
		for i in threads: i.join()
		_set_data('next_episodes_information', results)
		if force_refresh: return
	hidden_items = set(str(k) for k in get_hidden_progress_items())
	if hidden_items: results = [i for i in results if str(i['media_id']) not in hidden_items]
	results = sorted(results, key=lambda i: jsondate_to_datetime(i['last_played'], '%Y-%m-%d %H:%M:%S'), reverse=True)
	return results

def watched_info_movie(watched_db=None):
	if not watched_db: watched_db = get_database()
	try:
		watched_info = watched_db.execute('SELECT media_id, title, last_played FROM watched WHERE db_type = ?', ('movie',)).fetchall()
		watched_db.close()
		return {row[0]: {'media_id': row[0], 'title': row[1], 'last_played': row[2]} for row in watched_info}
	except: return {}

def get_bookmarks_movie(watched_db=None):
	if not watched_db: watched_db = get_database()
	try:
		info = watched_db.execute('SELECT media_id, resume_point, curr_time, resume_id FROM progress WHERE db_type = ?', ('movie',)).fetchall()
		watched_db.close()
		info = dict([(i[0], {'media_id': i[0], 'resume_point': i[1], 'curr_time': i[2], 'resume_id': i[3]}) for i in info])
	except: info = {}
	return info

def get_watched_status_movie(watched_info, media_id):
	if not watched_info: return 0
	try:
		watched = 1 if media_id in watched_info else 0
		return watched
	except: return 0

def get_progress_status_movie(progress_info, media_id):
	try: percent = str(round(float(progress_info[media_id]['resume_point'])))
	except: percent = None
	return percent

def watched_info_tvshow(watched_db=None):
	if not watched_db: watched_db = get_database()
	try:
		query = '''SELECT media_id, season, episode, title, last_played, total_played FROM (
					SELECT media_id, season, episode, title, last_played, ROW_NUMBER() OVER (PARTITION BY media_id ORDER BY last_played DESC, last_updated DESC, season DESC, episode DESC) as rn,
					COUNT(*) OVER (PARTITION BY media_id) as total_played FROM watched WHERE db_type = 'episode') WHERE rn = 1'''
		data = watched_db.execute(query).fetchall()
		watched_db.close()
		return {row[0]: {'media_id': row[0], 'season': int(row[1]), 'episode': int(row[2]), 'title': row[3], 'last_played': row[4], 'total_played': int(row[5])} for row in data}
	except: return {}

def get_watched_status_tvshow(watched_info, aired_eps):
	if not watched_info: return 0, 0, aired_eps
	try:
		watched = min(watched_info['total_played'], aired_eps)
		unwatched = aired_eps - watched
		if watched >= aired_eps: playcount = 1
		else: playcount = 0
		return playcount, watched, unwatched
	except: return 0, 0, aired_eps

def get_progress_status_tvshow(watched, aired_eps):
	try: progress = int((float(watched)/aired_eps)*100) or 1
	except: progress = 1
	return progress

def watched_info_season(media_id, watched_db=None):
	if not watched_db: watched_db = get_database()
	try: watched_info = dict(watched_db.execute('SELECT season, COUNT(*) AS COUNTER FROM watched WHERE db_type = ? AND media_id = ? GROUP BY media_id, season',
							('episode', str(media_id))).fetchall())
	except: watched_info = {}
	finally: watched_db.close()
	return watched_info

def get_watched_status_season(watched_info, aired_eps):
	if not watched_info: return 0, 0, aired_eps
	try:
		watched = min(watched_info, aired_eps)
		unwatched = aired_eps - watched
		if watched >= aired_eps: playcount = 1
		else: playcount = 0
		return playcount, watched, unwatched
	except: return 0, 0, aired_eps

def get_progress_status_season(watched, aired_eps):
	try: progress = int((float(watched)/aired_eps)*100)
	except: progress = 0
	return progress

def watched_info_episode(media_id, watched_db=None):
	if not watched_db: watched_db = get_database()
	try: watched_info = watched_db.execute('SELECT season, episode FROM watched WHERE db_type = ? AND media_id = ?', ('episode', str(media_id))).fetchall()
	except: watched_info = []
	watched_db.close()
	return watched_info

def get_watched_status_episode(watched_info, season_episode):
	if season_episode in watched_info: return 1
	return 0

def get_bookmarks_episode(media_id, season, watched_db=None):
	if not watched_db: watched_db = get_database()
	try:
		info = watched_db.execute('SELECT resume_point, curr_time, resume_id, episode FROM progress WHERE db_type = ? AND media_id = ? AND season = ?',
			('episode', str(media_id), int(season))).fetchall()
		watched_db.close()
		info = dict([(i[3], {'resume_point': i[0], 'curr_time': i[1], 'resume_id': i[2]}) for i in info])
	except: info = {}
	return info

def get_bookmarks_all_episode(media_id, total_seasons, watched_db=None):
	if not watched_db: watched_db = get_database()
	all_seasons_info = {}
	for season in range(1, total_seasons + 1):
		try:
			season_info = get_bookmarks_episode(media_id, season, watched_db)
			all_seasons_info[season] = season_info
		except: pass
	watched_db.close()
	return all_seasons_info

def get_progress_status_episode(progress_info, episode):
	try: percent = str(float(progress_info[episode]['resume_point']))
	except: percent = None
	return percent

def get_progress_status_all_episode(progress_info, season, episode):
	try: percent = str(round(float(progress_info[season][episode]['resume_point'])))
	except: percent = None
	return percent

def get_resume_seconds(progress, duration):
	return float(int(float(progress)/100 * duration))

def clear_local_bookmarks():
	try:
		dbcon = sqlite3.connect(get_video_database_path())
		file_ids = dbcon.execute("SELECT idFile FROM files WHERE strFilename LIKE 'plugin.video.infinite%'").fetchall()
		for i in ('bookmark', 'streamdetails', 'files'): dbcon.executemany("DELETE FROM %s WHERE idFile=?" % i, file_ids)
	except: pass

def mark_movie(params):
	# logger(f'mark_movie params: {params}')
	action, media_type = params.get('action'), 'movie'
	refresh, from_playback = params.get('refresh', 'true') == 'true', params.get('from_playback', 'false') == 'true'
	if from_playback: refresh = False
	tmdb_id, title = params.get('tmdb_id'), params.get('title')
	watched_status_mark(media_type, tmdb_id, action, title)
	erase_bookmark(media_type, tmdb_id, '', '', refresh)
	refresh_container(refresh)

def mark_tvshow(params):
	# logger(f'mark_tvshow params: {params}')
	title, action, tmdb_id = params.get('title', ''), params.get('action'), params.get('tmdb_id')
	progress_backround = kodi_progress_background()
	progress_backround.create('[B]Please Wait..[/B]', '')
	current_date = get_datetime()
	insert_list = []
	insert_append = insert_list.append
	meta = metadata.tvshow_meta('tmdb_id', tmdb_id, settings.tmdb_api_key(), get_datetime())
	season_data = meta['season_data']
	season_data = [i for i in season_data if i['season_number'] > 0]
	total = len(season_data)
	last_played = get_last_played_value()
	for count, item in enumerate(season_data, 1):
		season_number = item['season_number']
		ep_data = metadata.episodes_meta(season_number, meta)
		for ep in ep_data:
			season_number = ep['season']
			ep_number = ep['episode']
			display = '%s - S%.2dE%.2d' % (title, int(season_number), int(ep_number))
			progress_backround.update(int(float(count)/float(total)*100), '[B]Please Wait..[/B]', display)
			episode_date, premiered = adjust_premiered_date(ep['premiered'], settings.date_offset())
			if episode_date and current_date < episode_date: continue
			insert_append(make_batch_insert(action, 'episode', tmdb_id, season_number, ep_number, title, last_played, get_timestamp()))
	batch_watched_status_mark(insert_list, action, 'episode')
	progress_backround.close()
	refresh_container()

def mark_season(params):
	# logger(f'mark_season params: {params}')
	season = int(params.get('season'))
	if season == 0: return notification('Failed')
	insert_list = []
	insert_append = insert_list.append
	action, title, tmdb_id = params.get('action'), params.get('title'), params.get('tmdb_id')
	heading = '[B]Mark Watched %s[/B]' if action == 'mark_as_watched' else '[B]Mark Unwatched %s[/B]'
	progress_backround = kodi_progress_background()
	progress_backround.create('[B]Please Wait..[/B]', '')
	current_date = get_datetime()
	meta = metadata.tvshow_meta('tmdb_id', tmdb_id, settings.tmdb_api_key(), get_datetime())
	ep_data = metadata.episodes_meta(season, meta)
	last_played = get_last_played_value()
	for count, item in enumerate(ep_data, 1):
		season_number = item['season']
		ep_number = item['episode']
		display = '%s - S%.2dE%.2d' % (title, season_number, ep_number)
		episode_date, premiered = adjust_premiered_date(item['premiered'], settings.date_offset())
		if episode_date and current_date < episode_date: continue
		progress_backround.update(int(float(count) / float(len(ep_data)) * 100), '[B]Please Wait..[/B]', display)
		insert_append(make_batch_insert(action, 'episode', tmdb_id, season_number, ep_number, title, last_played, get_timestamp()))
	batch_watched_status_mark(insert_list, action, 'episode')
	progress_backround.close()
	refresh_container()

def mark_episode(params):
	# logger(f'mark_episode params: {params}')
	season, episode, title = int(params.get('season')), int(params.get('episode')), params.get('title')
	if season == 0: return notification('Failed')
	action, media_type = params.get('action'), 'episode'
	refresh, from_playback = params.get('refresh', 'true') == 'true', params.get('from_playback', 'false') == 'true'
	if from_playback: refresh = False
	tmdb_id = params.get('tmdb_id')
	watched_status_mark(media_type, tmdb_id, action, title, season, episode)
	erase_bookmark(media_type, tmdb_id, season, episode, refresh)
	refresh_container(refresh)

def get_next_episodes():
	try:
		dbcon = get_database()
		query = '''SELECT media_id, season, episode, title, last_played FROM watched 
		WHERE db_type = 'episode' GROUP BY media_id HAVING MAX(printf('%04d-%04d', season, episode)) ORDER BY last_played DESC'''
		data = dbcon.execute(query).fetchall()
		# logger(f'get_next_episodes 1 data: {repr(data)}')
		dbcon.close()
		return [{'media_id': int(i[0]), 'season': int(i[1]), 'episode': int(i[2]), 'title': i[3], 'last_played': i[4], 'order': c} for c, i in enumerate(data) if str(i[0]).isdigit()]
	except: return []

def get_next(season, episode, season_data):
	if episode == 0: episode = 1
	else:
		try:
			episode_count = next((i['episode_count'] for i in season_data if i['season_number'] == season), None)
			season = season if episode < episode_count else season + 1
			episode = episode + 1 if episode < episode_count else 1
		except: pass
	return season, episode

def get_in_progress_movies(dummy_arg, page_no):
	dbcon = get_database()
	data = dbcon.execute('SELECT media_id, title, last_played FROM progress WHERE db_type = ?', ('movie',)).fetchall()
	data = [{'media_id': i[0], 'title': i[1], 'last_played': i[2]} for i in data if not i[0] == '']
	dbcon.close()
	if settings.lists_sort_order('progress') == 0: data = sort_for_article(data, 'title')
	else: data = sorted(data, key=lambda x: x['last_played'], reverse=True)
	return data

def get_in_progress_tvshows(dummy_arg, page_no):
	# results = cache_watched_tvshow_status(active_tvshows_information, 'progress')
	results = active_tvshows_information('progress')
	# hidden_items = get_hidden_progress_items(watched_indicators())
	# results = [i for i in results if not int(i['media_id']) in hidden_items]
	if settings.lists_sort_order('progress') == 0: results = sort_for_article(results, 'title')
	else: results = sorted(results, key=lambda x: x['last_played'], reverse=True)
	return results

def get_in_progress_episodes():
	dbcon = get_database()
	data = dbcon.execute('SELECT media_id, season, episode, resume_point, last_played, title FROM progress WHERE db_type = ?', ('episode',)).fetchall()
	episode_list = [{'media_id': int(i[0]), 'season': int(i[1]), 'episode': int(i[2]), 'resume_point': float(i[3]), 'date': i[4], 'title': i[5]} for i in data if str(i[0]).isdigit()]
	dbcon.close()
	if settings.lists_sort_order('progress') == 0: episode_list = sort_for_article(episode_list, 'title')
	else: episode_list.sort(key=lambda k: k['date'], reverse=True)
	return episode_list

def get_watched_items(media_type, page_no):
	if media_type == 'tvshow': results = active_tvshows_information('watched')
	else: results = [v for k,v in watched_info_movie().items()]
	if settings.lists_sort_order('watched') == 0: results = sort_for_article(results, 'title')
	else: results = sorted(results, key=lambda x: x['last_played'], reverse=True)
	return results

@single_sync('watched_db', ['progress'])
def erase_bookmark(media_type, media_id, season='', episode='', refresh='false'):
	try:
		watched_db = get_database()
		result = watched_db.execute('DELETE FROM progress where db_type = ? and media_id = ? and season = ? and episode = ?', (media_type, media_id, season, episode))
		watched_db.close()
		refresh_container(refresh == 'true')
		return True if result.rowcount > 0 else None
	except: return None

@single_sync('watched_db', ['progress'])
def batch_erase_bookmark(insert_list, action, dbcon=None):
	try:
		changes_made = False
		dbcon = dbcon or get_database()
		modified_list = [(i[0], i[1], i[2], i[3]) for i in insert_list] if action == 'mark_as_watched' else insert_list
		for item in modified_list: result = dbcon.execute('DELETE FROM progress where db_type = ? and media_id = ? and season = ? and episode = ?', item)
		dbcon.close()
		return True
	except: return None

@single_sync('watched_db', ['progress'])
def set_bookmark(params):
	try:
		media_type, tmdb_id, curr_time, total_time = params.get('media_type'), params.get('tmdb_id') or params.get('media_id'), params.get('curr_time'), params.get('total_time')
		resume_point, title, season, episode = params.get('resume_point'), params.get('title'), params.get('season'), params.get('episode')
		refresh = False if params.get('from_playback', 'false') == 'true' else True
		if not resume_point:
			adjusted_current_time = float(curr_time) - 5
			resume_point = round(adjusted_current_time/float(total_time)*100,1)
		last_played = get_last_played_value()
		last_updated = get_timestamp()
		dbcon = get_database()
		dbcon.execute('INSERT OR REPLACE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
					(media_type, tmdb_id, season, episode, str(resume_point), str(curr_time), last_played, 0, title, last_updated))
		dbcon.close()
		refresh_container(refresh)
		return True
	except: return None

@single_sync('watched_db', ['watched', 'progress'])
def watched_status_mark(media_type, media_id, action, title, season='', episode=''):
	try:
		last_played = get_last_played_value()
		last_updated = get_timestamp()
		dbcon = get_database()
		if action == 'mark_as_watched':
			dbcon.execute('INSERT OR REPLACE INTO watched VALUES (?, ?, ?, ?, ?, ?, ?)', (media_type, media_id, season, episode, last_played, title, last_updated))
		elif action == 'mark_as_unwatched':
			dbcon.execute('DELETE FROM watched WHERE (db_type = ? and media_id = ? and season = ? and episode = ?)', (media_type, media_id, season, episode))
		dbcon.execute('DELETE FROM progress where db_type = ? and media_id = ? and season = ? and episode = ?', (media_type, media_id, season, episode))
		if media_type == 'episode':
			active_tvshows_information(force_refresh=True)
			active_next_episodes_information(force_refresh=True)
		dbcon.close()
		return True
	except Exception as e: notification('Error: %s' % str(e))
	return None

@single_sync('watched_db', ['watched'])
def batch_watched_status_mark(insert_list, action, media_type=''):
	try:
		dbcon = get_database()
		initial_changes = dbcon.total_changes
		if action == 'mark_as_watched': dbcon.executemany('INSERT OR IGNORE INTO watched VALUES (?, ?, ?, ?, ?, ?, ?)', insert_list)
		elif action == 'mark_as_unwatched': dbcon.executemany('DELETE FROM watched WHERE (db_type = ? and media_id = ? and season = ? and episode = ?)', insert_list)
		success = dbcon.total_changes > initial_changes
		batch_erase_bookmark(insert_list, action, dbcon)
		if media_type == 'episode':
			active_tvshows_information(force_refresh=True)
			active_next_episodes_information(force_refresh=True)
		dbcon.close()
		return True if success else None
	except Exception as e: notification('Error: %s' % str(e))
	return None


def unmark_previous_episode(params):
	try:
		season, episode = int(params.get('season')), int(params.get('episode'))
		if episode == 1:
			season = params['season'] = season - 1
			meta = metadata.tvshow_meta('tmdb_id', params.get('tmdb_id'), kodi_utils.tmdb_api_key(), get_datetime())
			params['episode'] = episode = next((i for i in meta['season_data'] if i['season_number'] == season))['episode_count']
		else: episode = params['episode'] = episode - 1
		return mark_episode(params)
	except: notification('Error')

def get_recently_watched(media_type, short_list=0):
	if media_type == 'movie':
		watched_movies = watched_info_movie().items()
		data = sorted([v for k,v in watched_movies], key=lambda x: x['last_played'], reverse=True)
		if short_list: data = data[:20]
	elif media_type == 'tvshow':
		watched_tvshows = watched_info_tvshow().items()
		data = sorted([v for k,v in watched_tvshows], key=lambda x: x['last_played'], reverse=True)
		if short_list: data = data[:20]
	else:
		dbcon = get_database()
		data = dbcon.execute('SELECT media_id, season, episode, title, last_played FROM watched WHERE db_type = ? ORDER BY last_played DESC', ('episode',)).fetchall()
		data = [{'media_ids': {'tmdb': int(i[0])}, 'season': int(i[1]), 'episode': int(i[2]), 'title': i[3], 'last_played': i[4]} for i in data if str(i[0]).isdigit()]
		if short_list: data = data[:20]
		dbcon.close()
	return data





def ishindi(tvdb_id):
	try:
		return '|' in str(tvdb_id)
	except: return False

def get_media_info(media_type, media_id=None, season=None, watched_indicators_dict=True):
	watched_db = get_database()
	try:
		if media_id: watched_info = watched_db.execute('SELECT season, episode FROM watched WHERE db_type = ? AND media_id = ?', (media_type, str(media_id))).fetchall()
		else:
			if watched_indicators_dict:
				watched_info = watched_db.execute('SELECT media_id, title, last_played, season, episode FROM watched WHERE db_type = ?', (media_type,)).fetchall()
				watched_info = dict([(i[0], {'media_id':i[0], 'title': i[1], 'last_played': i[2]}) for i in watched_info])
			else: watched_info = watched_db.execute('SELECT media_id, season, episode FROM watched WHERE db_type = ?', (media_type,)).fetchall()
	except: watched_info = []
	try:
		if media_type == 'movie':
			bookmarks = watched_db.execute('SELECT media_id, resume_point, curr_time, resume_id FROM progress WHERE db_type = ?', ('movie',)).fetchall()
			if watched_indicators_dict: bookmarks = dict([(i[0], {'media_id': i[0], 'resume_point': i[1], 'curr_time': i[2], 'resume_id': i[3]}) for i in bookmarks])
		else:
			if media_id: bookmarks = watched_db.execute('SELECT resume_point, curr_time, season, episode, resume_id FROM progress WHERE db_type = ? AND media_id = ?', (media_type, str(media_id))).fetchall()
			elif season: bookmarks = watched_db.execute('SELECT resume_point, curr_time, resume_id, episode FROM progress WHERE db_type = ? AND media_id = ? AND season = ?', ('episode', str(media_id), season)).fetchall()
			else: bookmarks = watched_db.execute('SELECT media_id, resume_point, curr_time, season, episode, resume_id FROM progress WHERE db_type = ?', (media_type,)).fetchall()
			# logger(f'from media_id: {media_id} season: {season} watched_indicators_dict: {watched_indicators_dict} bookmarks : {bookmarks}')
			if watched_indicators_dict:
				try: bookmarks = dict([(i[3], {'resume_point': i[0], 'curr_time': i[1], 'resume_id': i[2]}) for i in bookmarks])
				except: bookmarks = {}
	except: bookmarks = []
	finally: watched_db.close()
	return watched_info, bookmarks

def detect_bookmark(bookmarks, tmdb_id, season='', episode=''):
	if season == '': return [(i[1], i[2], i[3]) for i in bookmarks if i[0] == str(tmdb_id)][0]
	else: return [(i[1], i[2], i[5]) for i in bookmarks if i[0] == str(tmdb_id) and i[3] == season and i[4] == episode][0]

def get_progress_percent(bookmarks, tmdb_id, season='', episode=''):
	try: percent = str(float(detect_bookmark(bookmarks, tmdb_id, season, episode)[0]))
	except: percent = None
	return percent

def get_watched_status(watched_info, tmdb_id, season, episode):
	try:
		if season == '':
			if watched := [i for i in watched_info if i[0] == tmdb_id]: return 1
		else:
			if watched := [i for i in watched_info if i == (tmdb_id, season, episode)]:
				# logger(f'from watched_info : {watched_info} (tmdb_id, season, episode): {(tmdb_id, season, episode)}')
				return 1
		return 0
	except: return 0

def mark_as_watched_unwatched_extra(params):
	# logger(f'params: {params}')
	tmdb_id, action, media_type = params.get('tmdb_id'), params.get('action'), params.get('media_type')
	season, episode, title = params.get('season'), params.get('episode'), params.get('title')
	watched_status_mark(media_type, tmdb_id, action, title, season, episode)
	refresh_container()

@single_sync('watched_db', ['watched'])
def get_watched_info(media_type='episode'):
	try:
		from modules.kodi_utils import list_dialog
		dbcon = connect_database('watched_db', True)
		watched_info = dbcon.execute("SELECT media_id AS name, COUNT(*) AS value FROM watched WHERE db_type = ? AND media_id LIKE '%|%' GROUP BY media_id", (media_type,)).fetchall()
		# logger(f'all_items total: {len(watched_info)} watched_info: {watched_info}')
		all_items = [{**d, 'enabled': True} for d in watched_info]
		kwargs = {'heading': 'Remove from watch DB.', 'all_items': all_items, 'mode': 'enable'}
		choice = list_dialog(**kwargs)
		# logger(f'all_items total: {len(choice)} choice: {choice}')
		list_items = [(media_type, i.get('name')) for i in choice if not i.get('enabled')]
		# logger(f'list_items = {repr(list_items)}')
		if list_items: dbcon.executemany('DELETE FROM watched WHERE (db_type = ? and media_id = ?)', list_items)
		notification(f'Remove {len(list_items)} item from watch DB')
		dbcon.close()
	except:
		logger(f'error: {format_exc()}')
	return