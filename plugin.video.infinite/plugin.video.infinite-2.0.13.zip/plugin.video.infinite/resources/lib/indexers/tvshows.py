# -*- coding: utf-8 -*-
import sys
import json
from traceback import format_exc
from modules.metadata import tvshow_meta
from modules.meta_lists import context_menu_defaults
from modules.utils import get_datetime, get_current_timestamp, paginate_list, TaskPool, manual_function_import
from modules import kodi_utils, settings, watched_status
logger = kodi_utils.logger

class TVShows:
	tmdb_main_set = {'tmdb_tv_popular', 'tmdb_tv_popular_today', 'tmdb_tv_premieres', 'tmdb_tv_trending', 'tmdb_tv_trending_recent'}
	special_set = {'tmdb_tv_languages', 'tmdb_tv_year', 'tmdb_tv_recommendations', 'tmdb_tv_genres', 'tmdb_tv_search', 'tmdb_tv_keyword_results', 'tmdb_tv_keyword_results_direct'}
	personal_set = {'in_progress_tvshows', 'favorites_tvshows', 'watched_tvshows'}
	tmdb_personal = ('tmdb_watchlist', 'tmdb_favorite', 'tmdb_recommendations')
	trailer_url = 'plugin://plugin.video.infinite/?mode=default_trailer_choice&media_type=tvshow&tmdb_id=%s&imdb_id=%s'

	def __init__(self, params):
		self.params = params
		self.params_get = self.params.get
		self.category_name = self.params_get('category_name', None) or self.params_get('name', None) or 'TV Shows'
		self.id_type, self.list, self.action = self.params_get('id_type', 'tmdb_id'), self.params_get('list', []), self.params_get('action', None)
		self.tmdb_api_key = settings.tmdb_api_key()
		self.items, self.new_page, self.total_pages, self.is_external = [], {}, None, kodi_utils.external()
		if self.is_external: self.widget_hide_next_page = settings.widget_hide_next_page()
		else: self.widget_hide_next_page = False
		self.custom_order = self.params_get('custom_order', 'false') == 'true'
		self.paginate_start = int(self.params_get('paginate_start', '0'))
		self.append = self.items.append
		self.jump_to = settings.jump_to_enabled()

	def fetch_list(self):
		handle = int(sys.argv[1])
		try:
			is_random = self.params_get('random', 'false') == 'true'
			try: page_no = int(self.params_get('new_page', '1'))
			except: page_no = self.params_get('new_page')
			if page_no == 1 and not self.is_external:
				folder_path = kodi_utils.folder_path()
				if not any([x in folder_path for x in ('build_season_list', 'build_episode_list')]): kodi_utils.set_property('infinite.exit_params', folder_path)
			if self.action in self.tmdb_main_set: function = self.fetch_tmdb_main
			elif self.action in self.special_set: function = self.fetch_tmdb_special
			elif self.action in self.personal_set: function = self.fetch_personal
			elif self.action == 'trakt_tv_related': function = self.fetch_trakt_tv_related
			else: function = None
			if function: function(page_no)
			if not self.list: kodi_utils.notification('No Results')
			kodi_utils.add_items(handle, self.worker())
			if self.new_page and not self.widget_hide_next_page:
				self.new_page = {**self.new_page, 'mode': 'build_tvshow_list', 'action': self.action, 'category_name': self.category_name}
				kodi_utils.add_dir(handle, self.new_page, 'Next Page (%s) >>' % self.new_page['new_page'], 'nextpage', kodi_utils.get_icon('nextpage_landscape'))
			if self.total_pages and self.total_pages > 2 and self.jump_to:
				kodi_utils.add_dir(handle, {'mode': 'navigate_to_page_choice', 'current_page': page_no, 'total_pages': self.total_pages, 'url_params': json.dumps(self.new_page), 'all_pages': json.dumps(self.list)}, 'Jump To...', 'item_jump', kodi_utils.get_icon('item_jump_landscape'), isFolder=False)
		except: logger(f'fetch_list self.params: {self.params}\nError: {format_exc()}')
		kodi_utils.set_content(handle, 'tvshows')
		kodi_utils.set_category(handle, self.category_name)
		kodi_utils.end_directory(handle, cacheToDisc=False if self.is_external else True)
		if not self.is_external: kodi_utils.set_view_mode('view.tvshows', 'tvshows', self.is_external)

	def build_tvshow_content(self, _position, _id, dbcon):
		try:
			if isinstance(_id, dict):
				if _id.get('tmdb', None): self.id_type, _id = 'tmdb_id', _id['tmdb']
				elif _id.get('imdb', None): self.id_type, _id = 'imdb_id', _id['imdb']
			meta = tvshow_meta(self.id_type, _id, self.tmdb_api_key, self.current_date, self.current_time, dbcon)
			if not meta or 'blank_entry' in meta: return
			meta_get = meta.get
			tmdb_id = meta_get('tmdb_id')
			imdb_id = meta_get('imdb_id')
			str_tmdb_id = str(tmdb_id)
			cm = []
			cm_append = cm.append
			cm_extend = cm.extend
			plugin_cmd = 'RunPlugin(%s)'
			build_url = self.build_url
			title = meta_get('title')
			try: year = int(meta_get('year') or 2050)
			except: year = 2050
			trailer, premiered = meta_get('trailer'), meta_get('premiered')
			tvdb_id = meta_get('tvdb_id')
			poster = meta_get('poster')
			if self.rpdb_api_key and poster:
				try: poster = (meta_get('rpdb_poster') % self.rpdb_api_key) + self.rpdb_format
				except: pass
			if not poster: poster = self.poster_empty
			fanart = meta_get('fanart') or self.fanart_empty
			clearlogo, landscape = meta_get('clearlogo') or '', meta_get('landscape') or ''
			total_seasons, total_aired_eps = meta_get('total_seasons') or meta_get('seasons', 1), meta_get('total_aired_eps')
			unaired = total_aired_eps == 0
			if unaired: progress, playcount, total_watched, total_unwatched, visible_progress = 0, 0, 0, total_aired_eps, '0'
			else:
				playcount, total_watched, total_unwatched = watched_status.get_watched_status_tvshow(self.watched_info.get(str(tmdb_id)), total_aired_eps)
				if total_watched: 
					progress = watched_status.get_progress_status_tvshow(total_watched, total_aired_eps)
					visible_progress = '0' if progress == 100 else progress
				else: progress, visible_progress = 0, '0'
			extras_params = {'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'tvshow'}
			if total_seasons == 1: url_params = {'mode': 'build_episode_list', 'tmdb_id': tmdb_id, 'season': 1}
			else: url_params = {'mode': 'build_season_list', 'tmdb_id': tmdb_id}
			if self.open_extras:
				cm_append(['extras', ('[B]Browse[/B]', 'Container.Update(%s)' % build_url(url_params))])
				url_params = extras_params
			else:
				cm_append(['extras', ('[B]Extras[/B]', plugin_cmd % build_url(extras_params))])
			url = self.build_main_url(url_params, self.is_external)
			cm_extend([
			['select', ('Add to Shortcut Folder', plugin_cmd % build_url({'mode': 'menu_editor.shortcut_folder_add_known', 'url': build_url({**url_params, 'name': title, 'poster': poster or fanart or landscape})}))],
			['more_info', ('[B]More Info[/B]', plugin_cmd % build_url({'mode': 'media_info_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id}))],
			['options', ('[B]Options[/B]', plugin_cmd % build_url({'mode': 'options_menu_choice', 'content': 'tvshow', 'tmdb_id': tmdb_id, 'poster': poster}))],
			['browse', ('Browse %s' % title, plugin_cmd % build_url({'mode': 'build_season_list', 'tmdb_id': tmdb_id}))],
			['browse_more', ('[B]Browse More[/B]', plugin_cmd % build_url({'mode': 'browse_more_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id,
				'title': title, 'poster': poster}))],
			['personal_manager', ('[B]Personal Lists Manager[/B]', plugin_cmd % build_url({'mode': 'personallists_manager_choice', 'tmdb_id': tmdb_id, 'media_type': 'tvshow',
				'title': title, 'premiered': premiered, 'current_time': self.current_time, 'icon': poster}))],
			['favorites_manager', ('[B]Favorites Manager[/B]', plugin_cmd % build_url({'mode': 'favorites_manager_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id,
				'title': title}))]])
			if not playcount and not unaired:
				cm_append(['mark_watched', ('[B]Mark Watched[/B]', plugin_cmd % build_url({'mode': 'watched_status.mark_tvshow',
							'action': 'mark_as_watched', 'title': title, 'tmdb_id': tmdb_id}))])
			if progress:
				cm_append(['mark_watched', ('[B]Mark Unwatched[/B]', plugin_cmd % build_url({'mode': 'watched_status.mark_tvshow', 'action': 'mark_as_unwatched',
							'title': title, 'tmdb_id': tmdb_id}))])
			if not self.is_external: cm_append(['exit', ('[B]Exit TV Show List[/B]', plugin_cmd % build_url({'mode': 'navigator.exit_media_menu'}))])
			else: cm_extend([['refresh', ('[B]Refresh Widgets[/B]', plugin_cmd % build_url({'mode': 'refresh_widgets'}))],
				['reload', ('[B]Reload Widgets[/B]', plugin_cmd % build_url({'mode': 'kodi_refresh'}))]])
			cm = self.process_context_menu(cm)
			listitem = self.make_listitem()
			info_tag = listitem.getVideoInfoTag()
			info_tag.setMediaType('tvshow')
			info_tag.setTitle(title)
			info_tag.setTvShowTitle(title)
			info_tag.setOriginalTitle(meta_get('original_title'))
			info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': str(tmdb_id)})
			info_tag.setIMDBNumber(imdb_id)
			info_tag.setPlot(meta_get('plot'))
			info_tag.setPlaycount(playcount)
			info_tag.setGenres(meta_get('genre'))
			info_tag.setYear(year)
			info_tag.setTagLine(meta_get('tagline'))
			info_tag.setStudios(meta_get('studio'))
			info_tag.setWriters(meta_get('writer'))
			info_tag.setDirectors(meta_get('director'))
			info_tag.setVotes(meta_get('votes'))
			info_tag.setMpaa(meta_get('mpaa'))
			info_tag.setDuration(meta_get('duration'))
			info_tag.setCountries(meta_get('country'))
			info_tag.setTrailer(meta_get('auto_trailer') or self.trailer_url % (tmdb_id, imdb_id))
			info_tag.setPremiered(premiered)
			info_tag.setTvShowStatus(meta_get('status'))
			info_tag.setRating(meta_get('rating'))
			cast = meta_get('short_cast') or meta_get('cast') or []
			kodi_actor = self.kodi_actor
			info_tag.setCast([kodi_actor(item.get('name') or '', role=item.get('role') or '', thumbnail=item.get('thumbnail') or '') for item in cast])
			listitem.setLabel(title)
			listitem.addContextMenuItems(cm)
			listitem.setArt({'poster': poster, 'fanart': fanart, 'clearlogo': clearlogo, 'landscape': landscape, 'thumb': poster or landscape or fanart,
							'icon': landscape, 'tvshow.poster': poster, 'tvshow.clearlogo': clearlogo})
			listitem.setProperties({'watchedepisodes': str(total_watched), 'unwatchedepisodes': str(total_unwatched),'watchedprogress': visible_progress,
							'totalepisodes': str(total_aired_eps), 'totalseasons': str(total_seasons)})
			self.append(((url, listitem, self.is_folder), _position))
		except: logger(f'build_tvshow_content item_position: {_position}, _id: {_id}\nmeta: {meta} Error: {format_exc()}')

	def worker(self):
		self.kodi_actor, self.make_listitem = kodi_utils.kodi_actor(), kodi_utils.make_listitem
		self.build_url, self.build_main_url = kodi_utils.build_url, kodi_utils.build_main_url
		self.poster_empty, self.fanart_empty = kodi_utils.get_icon('box_office'), kodi_utils.addon_fanart()
		self.current_date, self.current_time = get_datetime(), get_current_timestamp()
		context_menu_enabled = settings.context_menu_enabled()
		context_menu_order = [i for i in settings.context_menu_order() if i in context_menu_enabled]
		self.cm_ordered_items = context_menu_order if context_menu_order != context_menu_defaults().split(',') else None
		rpdb_info = settings.rpdb_info('tvshow')
		self.rpdb_api_key, self.rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
		self.open_extras = settings.media_open_action('tvshow') == 1
		self.is_folder = False if self.open_extras else True
		self.watched_info = watched_status.watched_info_tvshow(watched_status.get_database())
		self.window_command = 'ActivateWindow(Videos,%s,return)' if self.is_external else 'Container.Update(%s)'
		if self.custom_order:
			threads = TaskPool().tasks(self.build_tvshow_content, self.list, 'metacache_db')
			[i.join() for i in threads]
		else:
			threads = TaskPool().tasks_enumerate(self.build_tvshow_content, self.list, 'metacache_db')
			[i.join() for i in threads]
			self.items.sort(key=lambda k: k[1])
			self.items = [i[0] for i in self.items]
		return self.items

	def fetch_tmdb_main(self, page_no):
		from apis import tmdb_api
		data = getattr(tmdb_api, self.action)(page_no)
		self.list = [i['id'] for i in data.get('results', [])]
		if data.get('total_pages', 0) > page_no: self.new_page = {'new_page': str(page_no + 1)}

	def fetch_tmdb_special(self, page_no):
		from apis import tmdb_api
		function = getattr(tmdb_api, self.action)
		if self.action == 'tmdb_tv_discover':
			url = self.params_get('url')
			data = function(url, page_no)
			page_meta = {'url': url}
		else:
			key_id = self.params_get('key_id') or self.params_get('query')
			if not key_id: return
			data = function(key_id, page_no)
			page_meta = {'key_id': key_id}
		self.list = [i['id'] for i in data.get('results', [])]
		if data.get('total_pages', 0) > page_no: self.new_page = dict(page_meta, **{'new_page': str(page_no + 1)})

	def fetch_personal(self, page_no):
		funcs = {'in_progress_tvshows': ('modules.watched_status', 'get_in_progress_tvshows'), 'watched_tvshows': ('modules.watched_status', 'get_watched_items'),
				'favorites_tvshows': ('caches.favorites_cache', 'get_favorites')}
		function = manual_function_import(*funcs[self.action])
		all_pages = function('tvshow', page_no)
		data, total_pages = self.paginate_list(all_pages, page_no)
		self.list = [i['media_id'] for i in data]
		if total_pages > 2: self.total_pages = total_pages
		if total_pages > page_no: self.new_page = {'new_page': str(page_no + 1), 'paginate_start': self.paginate_start, 'all_pages': json.dumps(all_pages)}

	def fetch_trakt_tv_related(self, page_no):
		from apis.trakt_api import trakt_tv_related
		self.id_type = 'multi_dict'
		key_id = self.params_get('key_id')
		if not key_id.startswith('tt'): key_id = tvshow_meta('tmdb_id', key_id, self.tmdb_api_key, get_datetime())['imdb_id']
		data = trakt_tv_related(key_id)
		self.list = [i['ids'] for i in data]

	def process_context_menu(self, context_menu_items):
		if not self.cm_ordered_items: return [i[1] for i in context_menu_items]
		return [i for x in self.cm_ordered_items for n, i in context_menu_items if x == n]

	def paginate_list(self, data, page_no):
		if settings.paginate(self.is_external):
			limit = settings.page_limit(self.is_external)
			data, total_pages = paginate_list(data, page_no, limit, self.paginate_start)
			if self.is_external: self.paginate_start = limit
		else: total_pages = 1
		return data, total_pages
