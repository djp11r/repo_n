# -*- coding: utf-8 -*-
import json
import re
from sys import argv
from traceback import print_exc
from urllib.parse import urlencode
import requests

try:
    from modules.kodi_utils import logger, kodi_player, build_url, add_items, addon_icon, end_directory, set_content, set_view_mode, get_infolabel, notification, add_item, make_listitem, external, set_category, set_info, get_list_item, execute_builtin, nextpage
    from modules.source_utils import request, get_host_dict, agent, replace_html_codes, get_host, process, keepclean_title, check_hosted_media
    from caches.main_cache import main_cache
    from modules.settings import get_git_url
    opensettings_params = build_url({'mode': 'open_settings', 'query': '0.0'})
except:
    import os, sys
    file = os.path.realpath(__file__)
    sys.path.append(os.path.join(os.path.dirname(file), 'modules'))
    from modules.utils import logger
    from modules.main_cache import main_cache
    from modules.client import request, agent
    from modules.scrape_sources import process
    from modules.client_utils import replaceHTMLCodes as replace_html_codes
    from modules.source_utils import get_host
    logger(f'import Exception: \n{print_exc()}')
    get_host_dict = ['oyohd.one', 'file.fm']

from modules.dom_parser import parseDOM

odd_domains = ['iwatchamericandadonline.com', 'watchcriminalminds.com', 'watchfamilyguyonline.com', 'watchgreysanatomy.com', 'watchhawaiifive0online.com', 'watchmodernfamilyonline.com', 'watchroseanneonline.com', 'watchspongebobsquarepantsonline.com']

ajax_link = '/wp-admin/admin-ajax.php'
hostDict = get_host_dict()


def get_image(ele):
    try:
        try: image = parseDOM(ele, 'img', ret='data-src')[0]
        except: image = parseDOM(ele, 'img', ret='src')[0]
    except: image = 'DefaultFolder.png'
    if image.startswith('//'): image = f'https:{image}'
    return image


def root(params):
    try:
        cache_name = f'content_{urlencode(params)}'
        list_data = main_cache.get(cache_name)
        if not list_data:
            uri = f'{get_git_url()}/watchonline.json'
            data = request(uri)
            list_data = eval(str(data))
            main_cache.set(cache_name, list_data, expiration=336)
        handle = int(argv[1])
        is_external = external()
        add_items(handle, list(get_list_item(list_data, 'watchonline', True)))
        set_content(handle, '')
        set_category(handle, '')
        end_directory(handle, cacheToDisc=not is_external)
    except: logger(f'root Exception: \n{print_exc()}')


def scrape_seasons(params):
    # logger(f'scrape_seasons params: {params}')
    base_link = params['url']
    # self.list.append({'title': 'Random Episode (Sometimes Fails)', 'url': base_link+'/?redirect_to', 'poster': None, 'mode': 'watchonline_scrape_episode'})
    itemlist = [{'title': 'Random Episode (Sometimes Fails)', 'url': f'{base_link}/?redirect_to', 'poster': None, 'mode': 'watchonline_source'}]
    ends = params.get('endings')
    # logger(f'scrape_seasons site_link: {base_link} type {type(ends)} repr(ends): {repr(ends)}')
    cache_name = f'shows_{urlencode(params)}'
    item_list = main_cache.get(cache_name)
    if not item_list:
        item_list = get_seasons(itemlist, base_link, ends)
        main_cache.set(cache_name, item_list, expiration=336)  # 14 days cache
    handle = int(argv[1])
    is_external = external()
    add_items(handle, list(get_list_item(item_list, 'watchonline', True)))
    set_content(handle, 'seasons')
    set_category(handle, 'seasons')
    end_directory(handle, cacheToDisc=not is_external)


def get_seasons(item_list, base_link, ends):
    for end in eval(ends):
        site_link = base_link + end
        # logger(f'scrape_seasons site_link: {site_link}')
        try:
            site_html = request(site_link, timeout='30')
            if '<div class="pagination">' in site_html:
                try:
                    pagination = parseDOM(site_html, 'div', attrs={'class': 'pagination'})[0]
                    page2_link = parseDOM(pagination, 'a', ret='href')[0]
                except: page2_link = None
                if page2_link: site_html += request(page2_link, timeout='30')
            if '/series/' in site_link:
                image = get_image(site_html)
                seasons = parseDOM(site_html, 'li', attrs={'id': r'menu-item-.*?'})
                for i in seasons:
                    try:
                        title = parseDOM(i, 'a')[0]
                        title = replace_html_codes(title)
                        if title in ['Home', 'TV Shows', 'Seasons', 'Season List', 'Other', 'Other Websites', ]:
                            continue
                        link = parseDOM(i, 'a', ret='href')[0]
                        if not link.startswith(base_link): link = f'{base_link}{link}'
                        item_list.append({'title': title.title(), 'url': link, 'poster': image, 'mode': 'watchonline_e'})
                    except: logger(f'1 scrape_seasons Exception: {print_exc()}')
            else:
                seasons = parseDOM(site_html, 'article')
                for i in seasons:
                    try:
                        title = parseDOM(i, 'img', ret='alt')[0]
                        title = replace_html_codes(title)
                        link = parseDOM(i, 'a', ret='href')[0]
                        if not link.startswith(base_link): link = f'{base_link}{link}'
                        image = get_image(i)
                        item_list.append({'title': title.title(), 'url': link, 'poster': image, 'mode': 'watchonline_e'})
                    except: logger(f'2 scrape_seasons Exception: {print_exc()}')
        except: logger(f'scrape_seasons Exception: {print_exc()}')
        return item_list


def scrape_episodes(url):
    try:
        cache_name = f'episodes_{url}'
        item_list = main_cache.get(cache_name)
        if not item_list:
            item_list = get_episodes(url)
            main_cache.set(cache_name, item_list, expiration=336)  # 14 days cache
        handle = int(argv[1])
        add_items(handle, list(get_list_item(item_list, 'watchonline', True)))
        is_external = external()
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.episode_lists', 'episodes', is_external)
    except: logger(f'scrape_episodes Exception: {print_exc()}')


def get_episodes(url):
    episodes_list = []
    base_host = get_host(url)
    base_link = f'https://{base_host}'
    html = request(url, timeout='30')
    if any(i in url for i in odd_domains):
        episodes = parseDOM(html, 'article')
        for i in episodes:
            try:
                title = parseDOM(i, 'h2', attrs={'class': 'entry-title'})[0]
                title = replace_html_codes(title)
                link = parseDOM(i, 'a', ret='href')[0]
                if not link.startswith(base_link): link = f'{base_link}{link}'
                image = get_image(i)
                episodes_list.append({'title': title, 'url': link, 'poster': image, 'mode': 'watchonline_source'})
            except: logger(f'1 scrape_episodes Exception: \n{print_exc()}')
    else:
        episodes = parseDOM(html, 'li', attrs={'class': r'mark-.*?'})
        for i in episodes:
            try:
                title1 = parseDOM(i, 'div', attrs={'class': 'numerando'})[0]
                title2 = parseDOM(i, 'div', attrs={'class': 'episodiotitle'})[0]
                title2 = parseDOM(title2, 'a')[0]
                title_layout = f'[B]{title1}[/B] ({title2})'
                title = replace_html_codes(title_layout)
                link = parseDOM(i, 'a', ret='href')[0]
                if not link.startswith(base_link): link = f'{base_link}{link}'
                image = get_image(i)
                episodes_list.append({'title': title, 'url': link, 'poster': image, 'mode': 'watchonline_source'})
            except: logger(f'2 scrape_episodes Exception: \n{print_exc()}')
    return episodes_list


def scrape_source(params):
    try:
        cache_name = f'content_{urlencode(params)}'
        item_list = main_cache.get(cache_name)
        if not item_list:
            item_list = get_sources(params)
            main_cache.set(cache_name, item_list, expiration=6) # 6hrs
        handle = int(argv[1])
        is_external = external()
        add_items(handle, list(get_list_item(item_list, 'watchonline')))
        set_content(handle, '')
        set_category(handle, '')
        end_directory(handle, cacheToDisc=not is_external)
    except: logger(f'outter scrape_source Exception: {print_exc()}')


def get_sources(params):
    sources_list = []
    url = params['url']
    title = params.get('title')
    thumb = params.get('poster')
    base_host = get_host(url)
    base_link = f'https://{base_host}'
    if '/?redirect_to' in url: url += '=random&post_type=episodes'
    # logger(f'Scraper Testing starting url: {repr(url)}')
    # logger(f'Scraper Testing base_link: {repr(base_link)}')
    html = request(url, timeout='30')
    if any(i in url for i in odd_domains):
        results = parseDOM(html, 'iframe', ret='data-src')
        for result in results:
            try:
                result_url = replace_html_codes(result)
                result_html = request(result_url, timeout='30')
                result_link = parseDOM(result_html, 'iframe', ret='src')[0]
                for source in process(hostDict, result_link):
                    title = f'{title} {source["source"]} ( {source["quality"]} {source["info"]})'
                    link = source['url']
                    sources_list.append({'title': title, 'url': link, 'poster': thumb, 'mode': 'watchonline_ltp'})
            except: logger(f'1 scrape_source Exception: {print_exc()}')
    else:
        session = requests.Session()
        customheaders = {
            'Host': base_host,
            'Accept': '*/*',
            'Origin': base_link,
            'X-Requested-With': 'XMLHttpRequest',
            'User-Agent': agent(),
            'Referer': url,
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'en-US,en;q=0.9'
            }
        post_link = base_link + ajax_link
        results = re.compile('''class=['"]dooplay_player_option['"] data-type=['"](.+?)['"] data-post=['"](.+?)['"] data-nume=['"](\d+)['"]>''', re.DOTALL).findall(html)
        for data_type, data_post, data_nume in results:
            try:
                # logger(f'Scraper Testing data_post: {repr(data_post)} data_type: {data_type}')
                payload = {'action': 'doo_player_ajax', 'post': data_post, 'nume': data_nume, 'type': data_type}
                r = session.post(post_link, headers=customheaders, data=payload)
                i = r.text
                p = i.replace('\\', '')
                link = parseDOM(p, 'iframe', ret='src')[0]
                for source in process(hostDict, link):
                    # logger(f'Scraper Testing source: {repr(source)}')
                    title = f'{title} {source["source"]} ( {source["quality"]} {source["info"]})'
                    link = source['url']
                    sources_list.append({'title': title, 'url': link, 'poster': thumb, 'mode': 'watchonline_ltp'})
            except: logger(f'2 scrape_source Exception: {print_exc()}')
    return sources_list


def play(params):
    try:
        # logger(f'play params: {params}')
        url = check_hosted_media(params['url'])
        if url: kodi_player(url, str(params['title']))
        else: notification('Error : No Stream Available.:')
    except:
        logger(f'play Exception: \n{print_exc()}')
        notification('Error : No Stream Available.:')


def doc_root(params):
    cache_name = f'content_{urlencode(params)}'
    docu_data = main_cache.get(cache_name)
    if not docu_data:
        docu_data = get_root_items()
        if docu_data: main_cache.set(cache_name, docu_data, expiration=336)  # 14 days cache

    # docu_data = list(reversed(docu_data))
    # logger(f'total: {len(docu_data)} item_list: {docu_data}')
    from sys import argv
    handle = int(argv[1])
    if docu_data:
        is_external = external()
        add_items(handle, list(get_list_item(docu_data, 'docu_data', True)))
        set_content(handle, 'tvshows')
        set_category(handle, 'tvshows')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.main', 'tvshows', is_external)
    else:
        notification('No items Found in doc_root.')
        end_directory(handle)
        return


def get_root_items():
    item_list = []
    html = request('https://topdocumentaryfilms.com/list/')
    # logger(f'html: {html}')
    cat_list = parseDOM(html, 'div', attrs={'class': 'sitemap-wraper'})
    # logger(f'total: {len(cat_list)} cat_list: {cat_list}')
    for content in cat_list:
        try:
            cat_info = parseDOM(content, 'h2')[0]
            # logger(f'cat_info: {cat_info}')
            cat_url = parseDOM(cat_info, 'a', ret='href')[0]
            # cat_title = parseDOM(cat_info, 'a')[0].encode('utf-8', 'ignore').decode('utf-8').replace('&amp;','&').replace('&#39;',''').replace('&quot;',''').replace('&#39;',''').replace('&#8211;',' - ').replace('&#8217;',''').replace('&#8216;',''').replace('&#038;','&').replace('&acirc;','')
            cat_title = parseDOM(cat_info, 'a')[0]
            try: cat_icon = parseDOM(content, 'img', ret='data-src')[0]
            except:
                try: cat_icon = parseDOM(content, 'img', ret='src')[0]
                except: cat_icon = ''
            # cat_action = 'docuHeaven&docuCat=%s' % cat_url
            item_list.append({'title': cat_title, 'url': cat_url, 'poster': cat_icon, 'mode': 'docu_get_items'})
        except: logger(f'root() Exception: {print_exc()}')
    return item_list


def docu_list(params):
    url, iconImage = params['url'], params['poster']
    params = {'url': url, 'poster': iconImage}
    cache_name = f'content_{urlencode(params)}'
    docu_data = main_cache.get(cache_name)
    if not docu_data:
        docu_data = docu_list_items(url)
        if docu_data: main_cache.set(cache_name, docu_data, expiration=48)  # 2 days cache

    # docu_data = list(reversed(docu_data))
    # logger(f'total: {len(docu_data)} item_list: {docu_data}')
    from sys import argv
    handle = int(argv[1])
    if docu_data:
        is_external = external()
        add_items(handle, list(get_list_item(docu_data, 'docu_data')))
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.main', 'episodes', is_external)
    else:
        notification('No items Found in docu_list.')
        end_directory(handle)
        return


def docu_list_items(url):
    item_list = []
    try:
        html = request(url)
        # logger(f'html: {html}')
        cat_list = parseDOM(html, 'article', attrs={'class': 'module clearfix'})
        # logger(f'cat_list: {cat_list}')
        for content in cat_list:
            try:
                docu_info = parseDOM(content, 'h2')[0]
                # logger(f'docu_info: {docu_info}')
                docu_url = parseDOM(docu_info, 'a', ret='href')[0]
                docu_title = keepclean_title(parseDOM(docu_info, 'a')[0])
                try: docu_icon = parseDOM(content, 'img', ret='data-src')[0]
                except:
                    try: docu_icon = parseDOM(content, 'img', ret='src')[0]
                    except: docu_icon = ''
                # docu_action = 'docuHeaven&docuPlay=%s' % docu_url
                item_list.append({'title': docu_title, 'url': docu_url, 'poster': docu_icon, 'mode': 'docu_pls'})
            except: logger(f'docu_list() url:: {url} Error {print_exc()}')
        try:
            navi_content = parseDOM(html, 'div', attrs={'class': 'pagination module'})[0]
            links = parseDOM(navi_content, 'a', ret='href')
            link = links[(len(links) - 1)]
            # docu_action = 'docuHeaven&docuCat=%s' % link
            item_list.append({'title': 'Next Page', 'url': link, 'poster': nextpage, 'mode': 'docu_get_items', 'isfolder': True})
        except: logger(f'docu_list() url:: {url} Error {print_exc()}')
    except: logger(f'docu_list() Exception: {print_exc()}')
    # self.addDirectory(self.list)
    # logger(f'total: {len(item_list)} item_list: {item_list}')
    return item_list


def docu_play(params):
    try:
        furl = None
        url = params['url']
        html = request(url)
        # logger(f'html: {html}')
        docu_item = parseDOM(html, 'meta', attrs={'itemprop': 'embedUrl'}, ret='content')[0]
        if 'http:' not in docu_item and 'https:' not in docu_item: docu_item = f'https:{docu_item}'
        url = docu_item
        # docu_title = parseDOM(docu_page, 'meta', attrs={'property':'og:title'}, ret='content')[0].encode('utf-8', 'ignore').decode('utf-8').replace('&amp;','&').replace('&#39;',''').replace('&quot;',''').replace('&#39;',''').replace('&#8211;',' - ').replace('&#8217;',''').replace('&#8216;',''').replace('&#038;','&').replace('&acirc;','')
        docu_title = keepclean_title(parseDOM(html, 'meta', attrs={'property': 'og:title'}, ret='content')[0])
        # logger(f'docu_title: {docu_title} url: {url}')
        if 'youtube' in url:
            if 'videoseries' not in url:
                try: video_id = parseDOM(html, 'div', attrs={'class': 'youtube-player'}, ret='data-id')[0]
                except: video_id = url.split('/')[-1]
                furl = f'plugin://plugin.video.youtube/play/?video_id={video_id}'
        elif 'dailymotion' in url:
            video_id = parseDOM(html, 'div', attrs={'class': 'youtube-player'}, ret='data-id')[0]
            furl = getDailyMotionStream(video_id)
        else:
            logger(f'Play Documentary: Unknown Host: url: {repr(url)}')
            furl = check_hosted_media(url)
        logger(f'Play Documentary: docu_title: {docu_title} url: {repr(url)}')
        if furl: kodi_player(furl, docu_title)
    except: logger(f'docu_play() Exception: {print_exc()}')


def sort_key(elem):
    return 1 if elem[0] == 'auto' else int(elem[0].split('@')[0])


# Code originally written by gujal, as part of the DailyMotion Addon in the official Kodi Repo. Modified to fit the needs here.
def getDailyMotionStream(vid_id):
    headers = {'User-Agent': 'Android'}
    cookie = {'Cookie': 'lang=en_US; ff=off'}
    r = requests.get(f'http://www.dailymotion.com/player/metadata/video/{vid_id}', headers=headers, cookies=cookie, )
    content = r.json()
    if content.get('error') is not None:
        Error = (content['error']['title'])
        logger(f'getDailyMotionStream() Error: {Error}')
        return notification(f'getDailyMotionStream() Error: {Error}')
    else:
        cc = content['qualities']
        cc = cc.items()
        cc = sorted(cc, key=sort_key, reverse=True)
        m_url = ''
        other_playable_url = []
        for source, json_source in cc:
            source = source.split('@')[0]
            for item in json_source:
                if m_url := item.get('url', None):
                    if source == 'auto': continue
                    elif int(source) <= 2:
                        if 'video' in item.get('type', None): return m_url
                    elif '.mnft' in m_url: continue
                    other_playable_url.append(m_url)
        if other_playable_url:  # probably not needed, only for last resort
            for m_url in other_playable_url:
                if '.m3u8?auth' in m_url:
                    rr = requests.get(m_url, cookies=r.cookies.get_dict(), headers=headers)
                    if not rr.headers.get('set-cookie'):
                        return re.findall(r'(http.+)', rr.text)[0].split('#cell')[0]
                    logger('adding cookie to url')
                    return re.findall(r'(http.+)', rr.text)[0].split('#cell')[0] + '|Cookie=' + rr.headers['set-cookie']
