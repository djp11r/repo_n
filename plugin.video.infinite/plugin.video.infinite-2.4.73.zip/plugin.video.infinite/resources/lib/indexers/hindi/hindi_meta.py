# -*- coding: utf-8 -*-
import json
import re
from traceback import print_exc

from urllib.parse import quote_plus, urljoin


try:
    from indexers.hindi.live_client import scrapePage, requests, find_season_in_title, keepclean_title
    from caches.h_cache import metacache
    from modules.kodi_utils import logger, item_next
except:
    import os, sys

    file = os.path.realpath(__file__)
    sys.path.append(os.path.join(os.path.dirname(file), 'modules'))
    from live_client import scrapePage, requests, find_season_in_title, keepclean_title, read_write_file
    from modules.h_cache import metacache
    from modules.utils import logger

    item_next = ''

from modules.dom_parser import parseDOM
from modules.utils import replace_html_codes


def metacache_set(mediatype, meta):
    if mediatype == 'movie': metacache.set('movie', 'tmdb_id', meta)
    else: metacache.set('tvshow', 'tmdb_id', meta)


def gettmdb_id(mediatype, title, year, studio):
    return (
        f'{title.lower()}|{year}'
        if mediatype == 'movie'
        else f'{studio}|{title.lower()}'
    )


def fetch_meta(mediatype, title, tmdb_id, homepage, studio='Hindi', poster='hindi_movies.png', plot='', genre=[], year=2022, cast=[], imdb_id='', rating=5.0):
    # title_tm = keepclean_title(title)
    # tmdb_id = gettmdb_id(mediatype, title, year, studio)
    meta, custom_artwork = metacache.get(mediatype, 'tmdb_id', tmdb_id)
    # logger(f'shows desirulez meta: {str(meta)}')
    if meta is None:
        # imdbdata = {}
        if not plot and re.search('desi-serials|playdesi', str(homepage), re.I):
            plot, rating, genre = get_plot_tvshow(homepage)
        meta = populet_dict(mediatype=mediatype, title=title, homepage=homepage, studio=studio, poster=poster, tmdb_id=tmdb_id, imdb_id=imdb_id, plot=plot, genre=genre, year=year, cast=cast, rating=rating)
        imdbdata = get_datajson_imdb(meta)
        if imdbdata:
            logger(f'imdb_id imdbdata: {imdbdata}')
            meta = meta_merge_update(meta, imdbdata)
        metacache_set(mediatype, meta)
    return meta


def uniquify(string):
    """
    Remove duplicates
    :param string: 'Comedy, Drama, Biography, Drama, Sport'
    :return: 'Comedy, Biography, Drama, Sport'
    """
    output = []
    # seen = set()
    # for word in string.split(','):
    #     if word not in seen:
    #         output.append(word.strip())
    #         seen.add(word)
    # logger(seen)
    [output.append(n.strip()) for n in string.split(',') if n.strip() not in output]
    return ', '.join(output)


def meta_merge_update(meta, imdbdata):
    # logger(f'meta_merge_update meta: {meta}\n imdbdata: {imdbdata}')
    try:
        if isinstance(meta['genre'], list) and isinstance(imdbdata['genre'], list):
            genre = meta['genre'] + imdbdata['genre']
            if len(genre) > 1: genre = list(set(genre))
            meta.update({'genre': genre})
    except: logger(f'shows desirulez Error: {print_exc()}')
    if meta['plot'] == '' and imdbdata['plot'] != '': meta.update({'plot': imdbdata['plot']})
    if 'hindi_' in meta['poster'] and imdbdata['poster'] != '': meta.update({'poster': imdbdata['poster']})
    if imdbdata['duration']: meta.update({'duration': imdbdata['duration']})
    if imdbdata['mpaa']: meta.update({'mpaa': imdbdata['mpaa']})
    if imdbdata['imdb_id']: meta.update({'imdb_id': imdbdata['imdb_id']})
    if imdbdata['year']: meta.update({'year': imdbdata['year']})
    if imdbdata['rating']: meta.update({'rating': imdbdata['rating']})
    if imdbdata['episodes'] != 0: meta.update({'episodes': imdbdata['episodes']})
    if imdbdata['seasons'] != 0: meta.update({'seasons': imdbdata['seasons'], 'season': imdbdata['seasons']})
    return meta


def populet_dict(mediatype, title, homepage, studio, poster, tmdb_id, imdb_id, plot, genre, year, cast, rating):
    """
    :useges
    meta = populet_dict(mediatype='movie', title=title, year=year,
                        studio=ch_name, plot='', fanart=imgurl,
                        genre='', tvshowtitle=None, imdb_id=imdb)
    :param mediatype:
    :param title:
    :param studio:
    :param homepage:
    :param poster:
    :param tmdb_id:
    :param plot:
    :param year:
    :param genre:
    :param cast:
    :param imdb_id:
    :param rating:
    :return: dict
    """
    if imdb_id == '': imdb_id = tmdb_id
    try:
        if 'addons\\plugin.video.infinite' in poster:
            special_path = 'special://home/addons'
            poster = f'{special_path}{poster.split("addons")[1]}'
            poster = poster.replace('\\', '/')
    except: logger(f'homepath not found: {print_exc()}')
    if cast is None: cast = [{'role': '', 'name': '', 'thumbnail': ''}]
    if rating is None: rating = 4
    plot = replace_html_codes(plot)
    plot = plot.replace('\\n', ' ').replace('\\u2009', ' ').replace("\\'", "'").replace('\\r', '').strip()
    if isinstance(studio, str): studio = studio.split(',')
    if not genre: genre = []
    if isinstance(genre, str):
        genre = replace_html_codes(genre)
        genre = genre.split(',')
    fgenre = []
    for genre in genre:
        genre = genre.replace('<span data-sheets-value="{"1"', '')
        genre = replace_html_codes(genre)
        fgenre.append(genre.strip())
    # logger(f'IN genre: {genre} plot: {plot}')
    if not fgenre:
        fgenre = ['movie'] if mediatype == 'movie' else ['tv']
    if len(fgenre) > 1: fgenre = list(set(fgenre))  #remove duplicate items from list
    dic_meta = {'mediatype': mediatype,
                'year': year,
                'plot': plot,
                'title': title,
                'studio': studio,
                'poster': poster,
                'homepage': homepage,
                'genre': fgenre,  #['Animation, Music, Documentary']
                'cast': cast,
                'tmdb_id': tmdb_id,
                'imdb_id': imdb_id,
                'rating': rating,
                'clearlogo': '', 'trailer': '',
                'votes': 50, 'tagline': '', 'director': [],
                'writer': [], 'episodes': 0, 'seasons': 0,
                'extra_info': {'status': '', 'collection_id': ''}}
    if mediatype == 'movie': dic_meta.update({'tvdb_id': 'None', 'duration': 5400, 'mpaa': 'R'})
    else:
        season = find_season_in_title(title)
        dic_meta.update({'tvdb_id': imdb_id, 'duration': 1320, 'mpaa': 'TV-MA', 'season': season, 'episodes': 2, 'seasons': season, 'episode': 1, 'tvshowtitle': title})

    return dic_meta


def seach_omdbapi(meta):
    title = meta['title']
    year = meta['year']
    if meta['mediatype'] == 'movie': dType = 'movie'
    else: dType = 'series'
    title = keepclean_title(title)
    title = re.sub(r'(\d+)', '', title)
    title = title.strip()
    api_url = f'http://www.omdbapi.com/?apikey=dd7e2fc7&s={quote_plus(title)}'
    # logger(f'url: {api_url}')
    session = requests.Session()
    result = session.get(api_url, timeout=20.0)
    item_meta = json.loads(result.text)
    # logger(f'result: {item_meta}')
    # item_meta = json.loads(rt)
    if not item_meta.get('Search'): return meta
    for item in item_meta.get('Search'):
        otitle = item['Title']
        if title.lower() in otitle.lower() and item['Type'] == dType:
            id_year = item['Year']
            id_year = re.sub(r'[^\x00-\x7f]', r'-', id_year)  # remove all non-ASCII characters
            if '-' in id_year: id_year = id_year.split('-')[0]
            if item.get('Year'): meta['year'] = id_year
            if item.get('imdbID'): meta['imdb_id'] = item['imdbID']
            if item.get('Poster'): meta['poster'] = item['Poster']
            # logger(f'item: {item}')
            break
    return meta


def get_datajson_imdb(metadict):
    oimdb_id = metadict['imdb_id']
    if not oimdb_id.startswith('tt'): metadict = seach_omdbapi(metadict)
    oimdb_id = metadict['imdb_id']
    if oimdb_id.startswith('tt'):
        url = f'https://www.imdb.com/title/{oimdb_id}/'
    else:
        if metadict['mediatype'] == 'movie': url = f'https://www.imdb.com/search/title/?title={quote_plus(metadict["title"])}&title_type=feature,tv_movie&countries=in'
        else: url = f'https://www.imdb.com/search/title/?title={quote_plus(metadict["title"])}&title_type=tv_series,tv_episode,tv_miniseries&countries=in'
    logger(f'for : {metadict["title"]} checking url: {url}')
    result = scrapePage(url).text
    # result = read_write_file(file_n='www.imdb.com.html')
    # metadict = {'title': title, 'year': year, 'rating': 5.0, 'plot': '', 'imdb_id': oimdb_id, 'mpaa': cmpaa, 'duration': cduration, 'genre': [], 'poster': 'hindi_movies.png', 'episodes': 0, 'seasons': 0}
    imdbmetadict = imdb_json_parser(result, metadict)
    if not imdbmetadict: imdbmetadict = imdb_html_parser(result, metadict)
    return imdbmetadict


def imdb_json_parser(result, metadict):
    try:
        scripts = parseDOM(result, 'script', attrs={'id': '__NEXT_DATA__'})
        item_meta = json.loads(scripts[0])
        item_meta1 = item_meta['props']['pageProps']['aboveTheFoldData']
        # logger(f'item_meta1: {item_meta1}')
        try:
            year = item_meta1['releaseYear']['year']
            if year: metadict.update({'year': year})
        except: pass
        try:
            ratings = item_meta1['ratingsSummary']['aggregateRating']
            if ratings: metadict.update({'rating': ratings})
        except: pass
        try:
            rgen = item_meta1['genres']['genres']
            # genres = ', '.join(str(x['text']) for x in rgen if x != '')
            genres = [str(x['text']) for x in rgen if x != '']
            metadict.update({'genre': genres})

            plot = item_meta1['plot']['plotText']['plainText']
            plot = replace_html_codes(plot)
            if plot: metadict.update({'plot': plot})
        except: pass
        try:
            certf = item_meta1['certificate']['rating']
            if certf: metadict.update({'mpaa': certf})
        except: pass
        item_meta2 = item_meta['props']['pageProps']['mainColumnData']
        # logger(f'item_meta2: {item_meta2}')
        try:
            runtime = item_meta2['runtime']['seconds']
            if runtime: metadict.update({'duration': runtime})
        except: pass
        try:
            poster = item_meta2['titleMainImages']['edges'][0]['node']['url']
            if poster: metadict.update({'poster': poster})
        except: pass
        try:
            episodes = item_meta2['episodes']['episodes']['total']
            seasons = item_meta2['episodes']['seasons'][-1]
            #logger(f'>>> seasons: {seasons}\nepisodes: {episodes}\nitem_meta2: {item_meta2}')
            # seasons = ', '.join(str(x['number']) for x in seasons if str(x) != '')  # seasons = [x['number'] for x in seasons if x != '']
            if episodes: metadict.update({'episodes': int(episodes)})
            if seasons: metadict.update({'seasons': int(seasons.get('number', 1))})
        except: pass
        ctitle = item_meta1['titleText']['text']
        if ctitle: metadict.update({'title': keepclean_title(ctitle)})
    except:
        return
    # logger(f'imdb_json_parser metadict: {metadict}')
    return metadict


def imdb_html_parser(result, metadict):
    try:
        items = parseDOM(result, 'div', attrs={'class': 'ipc-page-content-container.+?'})
        try:
            duration_wrapper = parseDOM(items, 'ul', attrs={'class': '.+?TitleBlockMetaDat.+?'})
            duration = parseDOM(duration_wrapper, 'li', attrs={'class': 'ipc-inline-list__item'})
            duration = duration[1] if metadict['mediatype'] == 'movie' else duration[2]
            dur = duration.replace('<!-- -->', '')
            duration = get_sec_string(dur)
            if duration: metadict.update({'duration': duration})
        except: pass
        try:
            poster = parseDOM(items, 'img', attrs={'class': '.+?ipc-image.+?'}, ret='src')[0]
            if '/nopicture/' in poster: poster = '0'
            poster = re.sub(r'(?:_SX|_SY|_UX|_UY|_CR|_AL)(?:\d+|_).+?\.', '_SX500.', poster)
            poster = replace_html_codes(poster)
            if poster: metadict.update({'poster': poster})
        except: pass
        try:
            # genresplot_wrapper = parseDOM(items, 'div', attrs={'class': '.+?GenresAndPlot__ContentParent.+?'})
            # logger(f'Total: {len(genresplot_wrapper)} duration_wrapper: {genresplot_wrapper}')
            genres_wrapper = parseDOM(items, 'a', attrs={'class': '.+?GenresAndPlot__GenreChip.+?'})
            genre = [item.replace('<span class="ipc-chip__text" role="presentation">', '').replace('</span>', '') for item in genres_wrapper if item]
            if genre: metadict.update({'genre': genre})
        except: pass
        try:
            plot_wrapper = parseDOM(items, 'p', attrs={'class': '.+?GenresAndPlot__Plot.+?'})
            plot = parseDOM(plot_wrapper, 'span', attrs={'class': 'GenresAndPlot__TextContainerBreakpoint.+?'})[0]
            plot = span_clening(plot)
            if plot: metadict.update({'plot': plot})
        except: pass
        try:
            rating_wrapper = parseDOM(items, 'div', attrs={'class': 'AggregateRatingButton__ContentWrap.+?'})
            rating = parseDOM(rating_wrapper, 'span', attrs={'class': 'AggregateRatingButton__RatingScore.+?'})[0]
            if rating: metadict.update({'rating': rating})
        except: pass
        try:
            mpaa_wrapper = parseDOM(items, 'div', attrs={'class': 'UserRatingButton.+?'})
            mpaa = parseDOM(mpaa_wrapper, 'div', attrs={'data-testid': 'hero-rating-bar.+?'})
            mpaa = mpaa[0].strip()
            if mpaa == 'Rate': pass
            elif mpaa: metadict.update({'mpaa': mpaa})
        except: pass
        try:
            title_wrapper = parseDOM(items, 'div', attrs={'class': 'TitleBlock__TitleContainer.+?'})
            title = parseDOM(title_wrapper, 'h1', attrs={'class': 'TitleHeader__TitleText.+?'})[0]
            if title: metadict.update({'title': keepclean_title(title)})
        except: pass
        try:
            year_wrapper = parseDOM(items, 'span', attrs={'class': 'TitleBlockMetaData__ListItemText.+?'})
            try: year = re.search(r'\d{4}', year_wrapper).group()
            except: year = 2023
            if year: metadict.update({'year': year})
        except: pass
    except: pass
    # logger(f'imdb_html_parser metadict: {metadict}')
    return metadict


def imdbid(title):
    imdb_id = None
    if title == 'war': imdb_id = 'tt7430722'
    elif title == 'line of descent': imdb_id = 'tt2257284'
    elif title == 'ishq aaj kal ': imdb_id = 'tt11199474'
    elif title == 'is she raju': imdb_id = 'tt9861220'
    elif title == 'good newwz': imdb_id = 'tt8504014'
    elif title == 'bhoot part one: The Haunted Ship': imdb_id = 'tt10463030'
    elif title == 'gandi baat': imdb_id = 'tt8228316'
    elif title == 'meera mathur': imdb_id = 'tt14941996'
    elif title == 'haseen dillruba': imdb_id = 'tt11027830'
    elif title == 'kem chho': imdb_id = 'tt11569584'
    return imdb_id


def get_sec_string(str_time):
    min_str = re.compile(r'(\d+)[m|min]')
    hrs_str = re.compile(r'(\d+)h')
    hrs_s = min_s = 0
    hrs_s = re.findall(hrs_str, str_time)
    if hrs_s: hrs_s = int(hrs_s[0]) * 60 * 60
    min_s = re.findall(min_str, str_time)
    if min_s: min_s = int(min_s[0]) * 60
    return hrs_s + min_s


def span_clening(span_text):
    span_text = span_text.rsplit('<span>', 1)[0].strip()
    span_text = re.sub('<.+?>|</.+?>', '', span_text)
    span_text = re.sub('\xa0', ' ', span_text)
    span_text = re.sub('See all certifications', '', span_text)
    # if '...' in span_text: span_text = span_text.split('...')[0]
    if 'add a plot' not in span_text.lower():
        span_text = replace_html_codes(span_text)
        # span_text = unescape(span_text)
        span_text.strip().replace('\\n', '')
    else: span_text = ''
    return span_text


def get_duplic(links_list):
    # links_list = [{'title': 'Anwar Ka Ajab Kissa','tmdb_id': 'Anwar Ka Ajab Kissa|2013'}, {'title': 'Anwar Ka Ajab Kissa','tmdb_id': 'Anwar Ka Ajab Kissa|2020'}, {'title': 'Ardhangini','tmdb_id': 'Ardhangini|1959'}, {'title': 'Class Of '83','tmdb_id': 'Class Of '83|2020'}, {'title': 'Class Of 83','tmdb_id': 'Class Of 83|2020'}, {'title': 'Julie','tmdb_id': 'Julie|1975'}, {'title': 'Julie','tmdb_id': 'Julie|Season 1'} ]
    # logger(f'strating len: {len(links_list)}')
    uniqueValues = []
    duplicateValues = []
    duplicatedict = []
    for d in links_list:
        if d['title'].lower() not in uniqueValues: uniqueValues.append(d['title'].lower())
        else:
            duplicateValues.append(d['title'])
            duplicatedict.append(d)
    # logger(f'List of Duplicate values in Dictionary: {duplicateValues} \n {duplicatedict}')
    return duplicateValues


def analyze_imdbid(href):
    """Return an imdbID from a URL.
    useges:
    movieID=analyze_imdbid(x.get('link') or '')
    """
    re_imdbid = re.compile(r'(title/tt|name/nm|company/co|user/ur)([0-9]+)')
    if not href: return None
    match = re_imdbid.search(href)
    return str(match[2]) if match else None


def get_plot_tvshow(show_url=None):
    episo_page = scrapePage(show_url).text
    # episo_page = read_write_file(file_n='www.desi-serials.cc.html')
    # logger(f'episo_page: {episo_page}')
    result1 = parseDOM(episo_page, 'div', attrs={'class': 'main-content col-lg-9'})
    result1 += parseDOM(episo_page, 'div', attrs={'class': 'blog-posts posts-large posts-container'})
    # logger(f'result1: {result1}')
    # ## for overview <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    plot = ''
    genres = []
    rating = 5.0

    result = parseDOM(result1, 'div', attrs={'id': 'content'})
    # logger(f'result: {result[0]}')
    p = parseDOM(result, 'div', attrs={'class': 'page-content'})
    p = parseDOM(p, 'div', attrs={'class': 'page-content'})
    # logger(f'p1: {p}')
    if p:
        title_overview = re.findall(r'<p>(.+?)</p>', str(p))
        # logger(f'title_overview: {title_overview}')
        try: plot = title_overview[0].replace('<br/><br/>', '').replace('\\n', '').strip()
        except: pass
        # logger(f'plot: {plot}')
        try:
            rest_ofp = title_overview[1].replace('<br/><br/>', '').replace('\\n', '').strip()
            # logger(f'rating: {rest_ofp}')
            rating = re.findall(r'Show Rating: </span>\s+(.+?)/.+? <p>', rest_ofp)[0]
            # logger(f'rating: {rating}')
            genres = re.findall(r'Genre: </span>\s+(.+?)$', rest_ofp)  #[0]
            # logger(f'plot: {plot}\nrating: {rating}, genre: {genres}')
        except: pass
    else:
        # logger(f'result:  {result}')
        try: plot = re.findall(r'loading="lazy" \/><\/div>(.*?)<p>.+?<span', str(result), re.M)[0].strip()
        except: pass
        try:
            genress = re.findall(r'<span.+?font-weight:bold">(.+?)<\/span>', str(result), re.M)  #[0]
            for genre in genress:
                if 'on:' in genre: genre = genre.split(':')[1].strip()
                if genre: genres.append(genre)
                # genre = genre.replace('Show is Aired on:', '').strip()
        except: pass
    # logger(f'genre: {genre} plot: {plot}')

    # if isinstance(genre, list): genre = ', '.join(x.strip() for x in genre if x != '')
    # genre = genre.replace('.', '').replace(' :', ',').replace('&#8211;', ' ').replace('&#8230;', '').strip()
    plot = replace_html_codes(plot)
    # plot = f'{genre}\n{plot}'
    return plot, rating, genres


def get_movies(params):
    # logger(f'from : get_movies params: {params}')
    desirule_url = 'https://www.desirulez.cc:443'
    non_str_list = ['+', 'season', 'episode']
    url = params['url']
    ch_name = params['ch_name']
    # iconImage = params['iconImage']
    pg_no = params['pg_no']
    movies = results = next_p = []
    movies_page = scrapePage(url)
    if movies_page:
        results = parseDOM(movies_page.text, 'h3', attrs={'class': 'threadtitle'})
        next_p = parseDOM(movies_page.text, 'span', attrs={'class': 'prev_next'})
    for item in results:
        # logger(f'item: {item}')
        try:
            try: title = parseDOM(item, 'a', attrs={'class': 'title threadtitle_unread'})[0]
            except:
                title = parseDOM(item, 'a', attrs={'class': 'title'})
                title = title[0] if title else parseDOM(item, 'a')[0]
            # title = title#.encode('ascii', 'ignore')
            # logger(f'title: {title} type(title): {type(title)}')
            try: parsed = re.compile(r'(.+) [{(](\d+|\w+ \d+|\w+)[})]').findall(str(title))[0]
            except: parsed = '', ''
            # logger(f'type title: {type(parsed[0])} parsed[0]: {parsed[0]} parsed[1] {parsed[1]}')
            title = parsed[0]
            year = parsed[1]
            if not re.search(r'\d{4}', year):
                try: year = re.search(r'\d{4}', title).group()
                except: year = 2022
            url = parseDOM(item, 'a', ret='href')
            if not url: url = parseDOM(item, 'a', attrs={'class': 'title'}, ret='href')
            if isinstance(url, list) and len(url) > 0: url = str(url[0])
            url = url if url.startswith(desirule_url) else urljoin(desirule_url, url)
            if title and all(x not in title for x in non_str_list):
                title = keepclean_title(title)
                tmdb_id = gettmdb_id('movie', title, year, None)
                meta = fetch_meta(mediatype='movie', title=title, tmdb_id=tmdb_id, homepage=url, year=year)
                movies.append({'year': year, 'ch_name': ch_name, 'url': url, 'tmdb_id': tmdb_id, 'meta': meta, 'pg_no': pg_no, 'title': title})
        except: logger(f'desirulez get_movies {print_exc()}')

    if next_p:
        next_p_url = parseDOM(next_p, 'a', attrs={'rel': 'next'}, ret='href')[0]
        url = next_p_url.split('?')[0] if '?' in next_p_url else next_p_url
        try:
            pg_no = re.compile(r'page\d{1,2}').findall(url)[0]
            pg_no = pg_no.replace('page', '')
            # logger(f'pg_no: {pg_no}')
        except:
            pg_no = '1'
        title = f'Next Page: {pg_no}'
        if url.startswith('forumdisplay'): url = f'https://www.desirulez.cc:443/{url}'
        movies.append({'year': '', 'ch_name': ch_name, 'url': url, 'tmdb_id': '', 'meta': {'poster': item_next, 'plot': f'For More: {ch_name} Movies Go To: {title}', 'genre': []}, 'pg_no': pg_no, 'title': title})
    # movies = json.dumps(movies, default = hindi_sources.dumper, indent = 2)
    # logger(f'len(movies): {len(movies)} movies :  {movies}')
    return movies


def get_movies_desicinemas(params):
    # logger(f'from : get_movies_desicinemas params: {params}')
    m_url = params['url']
    ch_name = params['ch_name']
    pg_no = params['pg_no']
    movies = results = next_p = []
    # m_url = 'https://desicinemas.tv/movies/'
    movies_page = scrapePage(m_url)
    # movies_page = to_utf8(remove_accents(movies_page))
    # movies_page = movies_page.replace('\n', ' ')
    # read_write_file(read=False, result=movies_page)
    # movies_page = read_write_file()
    # logger(f'movies_page: {movies_page}')
    # result = parseDOM(result, 'div', attrs={'class': 'Main Container'})
    if movies_page:
        results = parseDOM(movies_page.text, 'li', attrs={'class': 'TPostMv post-.+?'})
        next_p = parseDOM(movies_page.text, 'div', attrs={'class': 'nav-links'})
    # logger(f'total episodes: {len(results)} result: {results}')
    # r = [(parseDOM(i, 'a', ret='href'), parseDOM(i, 'a', ret='title'), parseDOM(i, 'a')[0]) for i in results]
    # logger(f'r: {r}\n >>>.')
    for i in results:
        try:
            url = parseDOM(i, 'a', ret='href')[0]
            title = parseDOM(i, 'h2', attrs={'class': 'Title'})[0]
            try:
                year = parseDOM(i, 'span', attrs={'class': 'Qlty Yr'})[0]
                if not year: year = parseDOM(i, 'span', attrs={'class': 'Date'})[0]
            except: year = 2023
            # logger(f'genre: {genre}\n >>>.')
            # logger(f'url: {Descri}\n >>>.')
            # if url:
            if '(Punjabi)' in title: continue
            if '(Marathi)' in title: continue
            title = keepclean_title(title)
            tmdb_id = gettmdb_id('movie', title, year, None)
            imgurl = parseDOM(i, 'img', ret='data-src')[0]
            Descri = parseDOM(i, 'div', attrs={'class': 'Description'})[0]
            plot = parseDOM(Descri, 'p')[0]
            genre = parseDOM(Descri, 'p', attrs={'class': 'Genre'})
            genre = parseDOM(genre, 'a')
            # if isinstance(genre, list): genre = ', '.join(x.strip() for x in genre if x != '')
            cast = parseDOM(Descri, 'p', attrs={'class': 'Cast'})
            cast = parseDOM(cast, 'a')
            # logger(f'imdbdata: {imdbdata}')
            meta = fetch_meta(mediatype='movie', title=title, tmdb_id=tmdb_id, homepage=url, poster=imgurl, year=year, plot=plot, genre=genre, cast=cast)
            movies.append({'year': year, 'ch_name': ch_name, 'url': url, 'tmdb_id': tmdb_id, 'meta': meta, 'pg_no': pg_no, 'title': title})
        except:
            logger(f'get_movies_desicinemas {print_exc()}')

    # logger(f'total movies: {len(movies)} movies: {movies}')
    # ## Next page
    # logger(f'next_p: {next_p}')
    if not movies: return
    if next_p:
        try:
            # next_p_u = parseDOM(next_p, 'a', attrs={'class': 'page-link'}, ret='href')[1]
            next_p_u = parseDOM(next_p, 'a', ret='href')[-1]
            # logger(f'next_p_u: {next_p_u}')
            pg_no = re.compile('/([0-9]+)/').findall(next_p_u)[0]
            # logger(f'pg_no: {pg_no}')
            title = f'Next Page: {pg_no}'
            movies.append({'year': '', 'ch_name': ch_name, 'url': next_p_u, 'tmdb_id': '', 'meta': {'poster': item_next, 'plot': f'For More: {ch_name} Movies Go To: {title}', 'genre': ['-']}, 'pg_no': pg_no, 'title': title})
        except: logger(f'get_movies_desicinemas {print_exc()}')
    # logger(f'total movies: {len(movies)} movies: {movies}')
    return movies


def get_tv_shows_desitelly(params):
    # logger(f'from : get_tv_shows_desitelly params: {params}')
    base_url = params['url']
    ch_name = params['ch_name']
    iconImage = params['iconImage']
    shows = results = []
    show_page = scrapePage(base_url)
    if show_page:
        results = parseDOM(show_page.text, 'div', attrs={'class': 'vc_column_container col-md-3'})
        results += parseDOM(show_page.text, 'div', attrs={'class': 'vc_column_container col-md-4'})
    # logger(f'result shows: {results}')

    for i in results:
        if i:
            url = parseDOM(i, 'a', ret='href')[0]
            lch_name = url.split('/')
            chan_name = lch_name[4]
            # ch_name = str(chan_name.replace('-', ' ').title())
            if chan_name:
                imgurl = parseDOM(i, 'img', ret='src')
                try: imgurl = imgurl[0]
                except: imgurl = iconImage
                if 'www.desi-serials.cc' in base_url:
                    if imgurl.startswith('/images'): imgurl = f'https://www.desi-serials.cc{imgurl}'
                    try:
                        title = parseDOM(i, 'a', attrs={'class': 'porto-sicon-title-link'})[0]
                        title_overview = parseDOM(i, 'div', attrs={'class': 'porto-sicon-header'})[0]
                        genre = re.findall(r'<\/h5>\s+(.+?)$', title_overview)  # logger('1 desi-serials title: {} ,genre: {} '.format(title, genre))
                    except:
                        title_overview = parseDOM(i, 'div', attrs={'class': 'porto-sicon-header'})[0]
                        title_overview = re.findall(r'porto-sicon-title-link.+>(.+?)<\/a><\/h5>(.+?)$', title_overview)[0]
                        title = title_overview[0]
                        genre = title_overview[1]
                        logger(f'2 desi-serials title: {title} genre: {genre} ')
                else:
                    if imgurl.startswith('/images'): imgurl = f'https://playdesi.tv{imgurl}'
                    genre = parseDOM(i, 'p')  #[0]
                    title = parseDOM(i, 'h4', attrs={'class': 'porto-sicon-title'})[0]
                title = keepclean_title(title)
                tmdb_id = gettmdb_id('tvshow', title, None, ch_name)
                # logger(f'for playdesi: title: {title} genre: {genre} ')
                # if imgurl is None: imgurl = iconImage
                meta = fetch_meta(mediatype='tvshow', title=title, tmdb_id=tmdb_id, homepage=url, studio=ch_name, poster=imgurl)
                shows.append({'url': url, 'title': title, 'ch_name': ch_name, 'tmdb_id': tmdb_id, 'meta': meta})
    # logger(f'len(shows): {len(shows)} shows :  {shows}')
    return shows
