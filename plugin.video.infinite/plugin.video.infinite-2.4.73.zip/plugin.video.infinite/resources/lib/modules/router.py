# -*- coding: utf-8 -*-
from modules.kodi_utils import external_browse, parse_qsl, get_property, services_finished_prop, make_fake_widget
# from modules.kodi_utils import logger

def exit_system_check():
	if external_browse(): return True

def services_finished():
	return get_property(services_finished_prop) == 'true'

def routing(sys):
	if not services_finished():
		from modules.kodi_utils import make_fake_widget
		if make_fake_widget(): return
	params = dict(parse_qsl(sys.argv[2][1:], keep_blank_values=True))
	_get = params.get
	# logger(f'routing params>>>> {params}')
	mode = _get('mode', 'navigator.main')
	# logger(f'routing mode>>>> {mode}')
	if 'navigator.' in mode:
		from indexers.navigator import Navigator
		return exec('Navigator(params).%s()' % mode.split('.')[1])
	elif 'menu_editor.' in mode:
		from modules.menu_editor import MenuEditor
		return exec('MenuEditor(params).%s()' % mode.split('.')[1])
	elif 'discover.' in mode:
		from indexers.discover import Discover
		return exec('Discover(params).%s()' % mode.split('.')[1])
	elif 'furk.' in mode:
		if mode == 'furk.browse_packs':
			from modules.sources import Sources
			return Sources().furkPacks(_get('file_name'), _get('file_id'))
		elif mode == 'furk.add_to_files':
			from indexers.furk import add_to_files
			return add_to_files(_get('item_id'))
		elif mode == 'furk.remove_from_files':
			from indexers.furk import remove_from_files
			return remove_from_files(_get('item_id'))
		elif mode == 'furk.myfiles_protect_unprotect':
			from indexers.furk import myfiles_protect_unprotect
			return myfiles_protect_unprotect(_get('action'), _get('name'), _get('item_id'))
		else:
			from indexers import furk
			return exec('furk.%s(params)' % mode.split('.')[1])
	elif 'easynews.' in mode:
		from indexers import easynews
		return exec('easynews.%s(params)' % mode.split('.')[1])
	elif 'playback.' in mode:
		if mode == 'playback.media':
			from modules.sources import Sources
			return Sources().playback_prep(params)
		elif mode == 'playback.video':
			from modules.player import infinitePlayer
			return infinitePlayer().run(_get('url', None), _get('obj', None))
	elif 'choice' in mode:
		from indexers import dialogs
		return exec('dialogs.%s(params)' % mode)
	elif 'trakt.' in mode:
		if '.list' in mode:
			from indexers import trakt_lists
			return exec('trakt_lists.%s(params)' % mode.split('.')[2])
		else:
			from apis import trakt_api
			return exec('trakt_api.%s(params)' % mode.split('.')[1])
	elif 'build' in mode:
		if mode == 'build_movie_list':
			from indexers.movies import Movies
			return Movies(params).fetch_list()
		elif mode == 'build_tvshow_list':
			from indexers.tvshows import TVShows
			return TVShows(params).fetch_list()
		elif mode == 'build_season_list':
			from indexers.seasons import build_season_list
			return build_season_list(params)
		elif mode == 'build_episode_list':
			from indexers.episodes import build_episode_list
			return build_episode_list(params)
		elif mode == 'build_in_progress_episode':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.progress')
		elif mode == 'build_recently_watched_episode':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.recently_watched')
		elif mode == 'build_next_episode':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.next')
		elif mode == 'build_my_calendar':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.trakt', params)
		elif mode == 'build_next_episode_manager':
			from modules.episode_tools import build_next_episode_manager
			return build_next_episode_manager()
		elif mode == 'imdb_build_user_lists':
			from indexers.imdb import imdb_build_user_lists
			return imdb_build_user_lists(_get('media_type'))
		elif mode == 'build_popular_people':
			from indexers.people import popular_people
			return popular_people()
		elif mode == 'imdb_build_keyword_results':
			from indexers.imdb import imdb_build_keyword_results
			return imdb_build_keyword_results(_get('media_type'), _get('query'))
	elif 'watched_status.' in mode:
		if mode == 'watched_status.mark_episode':
			from modules.watched_status import mark_episode
			return mark_episode(params)
		elif mode == 'watched_status.mark_season':
			from modules.watched_status import mark_season
			return mark_season(params)
		elif mode == 'watched_status.mark_tvshow':
			from modules.watched_status import mark_tvshow
			return mark_tvshow(params)
		elif mode == 'watched_status.mark_movie':
			from modules.watched_status import mark_movie
			return mark_movie(params)
		elif mode == 'watched_status.erase_bookmark':
			from modules.watched_status import erase_bookmark
			return erase_bookmark(_get('media_type'), _get('tmdb_id'), _get('season', ''), _get('episode', ''), _get('refresh', 'false'))
		elif mode == 'watched_status.extra':
			from modules.watched_status import mark_as_watched_unwatched_extra
			return mark_as_watched_unwatched_extra(params)
	elif 'history.' in mode:
		if mode == 'history.search':
			from indexers.history import search_history
			return search_history(params)
		elif mode == 'history.clear_search':
			from modules.history import clear_search_history
			return clear_search_history()
		elif mode == 'history.remove':
			from modules.history import remove_from_search_history
			return remove_from_search_history(params)
		elif mode == 'history.clear_all':
			from modules.history import clear_all_history
			return clear_all_history(_get('setting_id'), _get('refresh', 'false'))
	elif 'real_debrid' in mode:
		if mode == 'real_debrid.rd_torrent_cloud':
			from indexers.real_debrid import rd_torrent_cloud
			return rd_torrent_cloud()
		if mode == 'real_debrid.rd_downloads':
			from indexers.real_debrid import rd_downloads
			return rd_downloads()
		elif mode == 'real_debrid.browse_rd_cloud':
			from indexers.real_debrid import browse_rd_cloud
			return browse_rd_cloud(_get('id'))
		elif mode == 'real_debrid.resolve_rd':
			from indexers.real_debrid import resolve_rd
			return resolve_rd(params)
		elif mode == 'real_debrid.rd_account_info':
			from indexers.real_debrid import rd_account_info
			return rd_account_info()
		elif mode == 'real_debrid.authenticate':
			from apis.real_debrid_api import RealDebridAPI
			return RealDebridAPI().auth()
		elif mode == 'real_debrid.revoke_authentication':
			from apis.real_debrid_api import RealDebridAPI
			return RealDebridAPI().revoke()
	elif 'premiumize' in mode:
		if mode == 'premiumize.pm_torrent_cloud':
			from indexers.premiumize import pm_torrent_cloud
			return pm_torrent_cloud(_get('id', None), _get('folder_name', None))
		elif mode == 'premiumize.pm_transfers':
			from indexers.premiumize import pm_transfers
			return pm_transfers()
		elif mode == 'premiumize.pm_account_info':
			from indexers.premiumize import pm_account_info
			return pm_account_info()
		elif mode == 'premiumize.authenticate':
			from apis.premiumize_api import PremiumizeAPI
			return PremiumizeAPI().auth()
		elif mode == 'premiumize.revoke_authentication':
			from apis.premiumize_api import PremiumizeAPI
			return PremiumizeAPI().revoke()
	elif 'alldebrid' in mode:
		if mode == 'alldebrid.ad_torrent_cloud':
			from indexers.alldebrid import ad_torrent_cloud
			return ad_torrent_cloud(_get('id', None))
		elif mode == 'alldebrid.browse_ad_cloud':
			from indexers.alldebrid import browse_ad_cloud
			return browse_ad_cloud(_get('folder'))
		elif mode == 'alldebrid.resolve_ad':
			from indexers.alldebrid import resolve_ad
			return resolve_ad(params)
		elif mode == 'alldebrid.ad_account_info':
			from indexers.alldebrid import ad_account_info
			return ad_account_info()
		elif mode == 'alldebrid.authenticate':
			from apis.alldebrid_api import AllDebridAPI
			return AllDebridAPI().auth()
		elif mode == 'alldebrid.revoke_authentication':
			from apis.alldebrid_api import AllDebridAPI
			return AllDebridAPI().revoke()
	elif '_settings' in mode:
		if mode == 'open_settings':
			from modules.kodi_utils import open_settings
			return open_settings(_get('query', '0.0'), _get('addon', 'plugin.video.infinite'))
		elif mode == 'clean_settings':
			from modules.kodi_utils import clean_settings
			return clean_settings()
		elif mode == 'clear_settings_window_properties':
			from modules.kodi_utils import clear_settings_window_properties
			return clear_settings_window_properties()
	elif '_cache' in mode:
		import caches
		if mode == 'clear_cache':
			return caches.clear_cache(_get('cache'))
		elif mode == 'clear_all_cache':
			return caches.clear_all_cache()
		elif mode == 'clean_databases_cache':
			return caches.clean_databases()
		elif mode == 'check_corrupt_databases_cache':
			return caches.check_corrupt_databases()
		elif mode == 'resolveurl_cacheclear':
			from modules.kodi_utils import clear_cache_resolveurl
			return clear_cache_resolveurl()
	elif '_image' in mode:
		from indexers.images import Images
		return Images().run(params)
	elif '_text' in mode:
		if mode == 'show_text':
			from modules.kodi_utils import show_text
			return show_text(_get('heading'), _get('text', None), _get('file', None), _get('font_size', 'small'), _get('kodi_log', 'false') == 'true')
		elif mode == 'show_text_media':
			from modules.kodi_utils import show_text_media
			return show_text(_get('heading'), _get('text', None), _get('file', None), _get('meta'), {})
	elif '_view' in mode:
		from modules.kodi_utils import choose_view, set_view
		if mode == 'choose_view':
			return choose_view(_get('view_type'), _get('content', ''))
		elif mode == 'set_view':
			return set_view(_get('view_type'))
	##EXTRA modes##
	elif mode == 'kodi_refresh':
		from modules.kodi_utils import kodi_refresh
		return kodi_refresh()
	elif mode == 'get_search_term':
		from modules.history import get_search_term
		return get_search_term(params)
	elif mode == 'person_data_dialog':
		from indexers.people import person_data_dialog
		return person_data_dialog(params)
	elif mode == 'download_manager':
		from modules.downloader import download_manager
		return download_manager(params)
	elif mode == 'manual_add_magnet_to_cloud':
		from modules.debrid import manual_add_magnet_to_cloud
		return manual_add_magnet_to_cloud(params)
	elif mode == 'upload_logfile':
		from modules.kodi_utils import upload_logfile
		return upload_logfile()
	elif mode == 'toggle_language_invoker':
		from modules.kodi_utils import toggle_language_invoker
		return toggle_language_invoker()
	elif mode == 'downloader':
		from modules.downloader import runner
		return runner(params)
	elif mode == 'debrid.browse_packs':
		from modules.sources import Sources
		return Sources().debridPacks(_get('provider'), _get('name'), _get('magnet_url'), _get('info_hash'))
	elif mode == 'refresh_artwork':
		from modules.kodi_utils import refresh_artwork
		return refresh_artwork()
	elif 'external_scrapers_' in mode:
		from modules.source_utils import toggle_all, enable_disable
		if mode == 'external_scrapers_toggle_all': return toggle_all(_get('folder'), _get('setting'))
		elif mode == 'external_scrapers_enable_disable_specific_all': return enable_disable(_get('folder'))
	elif 'myaccounts' in mode:
		action = mode.split('.')[1]
		from modules.kodi_utils import open_MyAccounts, sync_MyAccounts
		if action == 'open': return open_MyAccounts(params)
		else: return sync_MyAccounts()
	elif mode == 'set_source_sorting':
		from indexers.dialogs import set_source_sorting
		return set_source_sorting(_get('source_sorting_list'))
	# Context option Select or Rescrape Hindi episodes or Movies Sources
	elif '_select' in mode:
		from modules.source_utils import clear_and_rescrape
		# logger(f'_select params: {params}')
		if mode == 'scrape_select': return clear_and_rescrape(params, False)
		elif mode == 'rescrape_select': return clear_and_rescrape(params)
	# Scrape Indian Movies
	elif mode == 'vod_movies_list':
		from indexers.hindi.desirulez import movies
		# logger(f'### from vod_movies_list params: {params}')
		return movies(params)
	# Scrape Hindi TV Shows
	elif 'vod_tv' in mode:
		# logger(f'vod_tv params: {params}')
		if mode == 'vod_tvsh_dr':
			from indexers.hindi.desirulez import tv_shows
			return tv_shows(params)
		elif mode == 'vod_tvepis_dr':
			from indexers.hindi.desirulez import tv_episo
			return tv_episo(params)
	elif 'geetm' in mode:
		# logger(f'geetm params: {params}')
		if mode == 'geetm':
			from indexers.hindi.geetmala import geetm_root
			return geetm_root(params)
		elif mode == 'geetm_list':
			from indexers.hindi.geetmala import get_song_list
			return get_song_list(params)
		elif mode == 'geetm_vid_list':
			from indexers.hindi.geetmala import get_yt_links
			return get_yt_links(params)
		elif mode == 'geetm_plvid':
			from indexers.hindi.geetmala import play
			return play(_get('url'), _get('title'))
	# Live TV
	elif 'livetv_' in mode:
		# logger(f'### from livetv_ params: {params}')
		if mode == 'livetv_ustvgo':
			from indexers.hindi.ustvgo import ustv_root
			return ustv_root(params)
		elif mode == 'livetv_pluto':
			from indexers.hindi.lists import pluto
			return pluto(params)
		elif mode == 'livetv_youtube_m3u':
			from indexers.hindi.lists import youtube_m3u
			return youtube_m3u(params)
		elif mode == 'livetv_m3u':
			from indexers.hindi.lists import indian_live
			return indian_live(params)
		elif mode == 'livetv_redjoyiptv':
			from indexers.hindi.lists import get_redjoyiptv_list
			return get_redjoyiptv_list(params)
	elif 'watchonline_' in mode:
		# logger(f'watchonline_ params >>>> {params}')
		if mode == 'watchonline_menu':
			from indexers.hindi.watchonline import root
			return root()
		elif mode == 'watchonline_scrape_seasons':
			from indexers.hindi.watchonline import scrape_seasons
			return scrape_seasons(_get('url'))
		elif mode == 'watchonline_scrape_episodes':
			from indexers.hindi.watchonline import scrape_episodes
			return scrape_episodes(_get('url'))
		elif mode == 'watchonline_scrape_source':
			from indexers.hindi.watchonline import scrape_source
			return scrape_source(params)
		elif mode == 'watchonline_ltp':
			from indexers.hindi.watchonline import play
			return play(params)
	elif 'distro_' in mode:
		if mode == 'distro_root':
			from indexers.hindi.distro import get_live_vod
			return get_live_vod(params)
		elif mode == 'distro_get_items':
			if _get('list_name') == 'live':
				from indexers.hindi.distro import live_cats
				return live_cats(params)
			else:
				if '**' in _get('url'):
					from indexers.hindi.distro import distro_seasons
					return distro_seasons(params)
				else:
					from indexers.hindi.distro import vod_cats
					return vod_cats(params)
		elif mode == 'distro_pls':
			from indexers.hindi.distro import play
			return play(params)
	elif 'docu_' in mode:
		if mode == 'docu_root':
			from indexers.hindi.docu import doc_root
			return doc_root(params)
		elif mode == 'docu_get_items':
			from indexers.hindi.docu import docu_list
			return docu_list(params)
		elif mode == 'docu_pls':
			from indexers.hindi.docu import docu_play
			return docu_play(params)
	elif 'ltp_' in mode:
		# logger(f'from ltp_ params: {params}')
		if mode == 'ltp_ustv':
			from indexers.hindi.ustvgo import play_old
			return play_old(params)
		elif mode == 'ltp_pluto':
			from indexers.hindi.lists import play
			return play(params)
		elif mode == 'ltp_tubitv':
			from indexers.hindi.tubitv import play
			return play(params)
		elif mode == 'ltp_123tv':
			from indexers.hindi.ustvgo import play123
			return play123(params)
	# shadownet
	elif 'shadownet_' in mode:
		from indexers.hindi.shadownet import iptv
		iptv = iptv()
		if mode == 'shadownet_root':
			return iptv.root()
		if mode == 'shadownet_scrape_channel':
			return iptv.scrape_channel(_get('url'))
		elif mode == 'shadownet_scrape_category':
			return iptv.scrape_category(_get('url'))
	# tubi2
	elif 'tubitv' in mode:
		# logger(f'tubitv params>>>> {params}')
		if mode == 'tubitv_main':
			from indexers.hindi.tubitv2 import Channels
			return Channels.section_list(_get('rescrape'))
		elif 'tubitv-content' in mode:
			from indexers.hindi.tubitv2 import Channels
			return Channels.content_list(mode)
		elif 'tubitv-episodes' in mode:
			from indexers.hindi.tubitv2 import Channels
			return Channels.episode_list(params)
		elif 'play-tubitv' in mode:
			from indexers.hindi.tubitv2 import Channels
			return Channels.play_tubi(params)
		elif mode == 'tubitv-search':
			from indexers.hindi.tubitv2 import Channels
			return Channels.search_tubi()

		# livetv_
		elif mode == 'tubitv_livemain':
			from indexers.hindi.tubitv2 import LiveChannels
			return LiveChannels.channel_list()
		elif mode == 'tubitv_livesearch':
			from indexers.hindi.tubitv2 import LiveChannels
			return LiveChannels.search_list()
		elif 'tubitv_liveget_channel' in mode:
			from indexers.hindi.tubitv2 import LiveChannels
			return LiveChannels.get_channel(params)
	elif 'tubio' in mode:
		# logger(f'tubio params>>>> {params}')
		if mode == 'tubio':
			from indexers.hindi.tubitv import tubitv_root
			return tubitv_root()
		elif mode == 'tubio_list':
			from indexers.hindi.tubitv import tubitv_categs
			return tubitv_categs(params)
		elif mode == 'tubio_tv':
			from indexers.hindi.tubitv import tubitv_shows
			return tubitv_shows(params)
	# update_hindi_metadb
	elif mode == 'update_hindi_metadb':
		from modules.kodi_utils import update_hindi_metadb
		return update_hindi_metadb()
	# for testing Mode
	elif 'testhindi' in mode:
		from indexers.hindi.testing_mod import testting
		return testting()
