# -*- coding: utf-8 -*-
from xbmc import executebuiltin

executebuiltin('RunPlugin(plugin://plugin.video.infinite/?mode=kodi_refresh)')
