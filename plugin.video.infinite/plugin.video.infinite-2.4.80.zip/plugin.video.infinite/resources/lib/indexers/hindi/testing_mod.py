# -*- coding: utf-8 -*-
from traceback import print_exc
from modules.kodi_utils import logger, get_setting, sleep, close_all_dialog 
from modules.watched_status import get_watched_info
from windows.skip import Skip
from windows import open_window, create_window
import sys, time, datetime
# from caches import clean_databases


def testting():
    # update_hindi_metadb()
    test_window()
    #get_meta()


def test_window(win='nextep_win'):
    meta = {'tmdb_id': 21572, 'tvdb_id': 170491, 'imdb_id': 'tt1190931', 'rating': 8.4, 'plot': 'Case 1: The Imposter: Dr. Barnes For twenty years he was an imposter doctor! Dr. Gerald Barnes has a thriving practice specializing in "executive" medical exams. His salary is six-figures and life is good. But there\'s a problem: he\'s not the real Dr. Gerald Barnes. Case 2: Interstate Bank Mart Bandit He leaves no clues behind, only a trail of broken dreams and empty bank accounts. Forty-three robberies in 20 months. The M.O. is always the same. Police say it\'s the work of one man: "The Interstate Bank Mart Bandit!".', 'tagline': '', 'votes': 8, 'premiered': '2007-06-28', 'year': '2007', 'poster': 'https://image.tmdb.org/t/p/w185/bilmBb9Q4sLesr1gdMknSGfQQ7H.jpg', 'fanart': 'https://image.tmdb.org/t/p/w300/z7OINGcfImMIU4bg0EUrrycZWR6.jpg', 'genre': ['Documentary', 'Crime'], 'title': 'American Greed', 'original_title': 'American Greed', 'english_title': '', 'season_data': [{'air_date': '2009-09-09', 'episode_count': 3, 'id': 31339, 'name': 'Specials', 'overview': '', 'poster_path': None, 'season_number': 0}, {'air_date': '2007-06-21', 'episode_count': 6, 'id': 31335, 'name': 'Season 1', 'overview': '', 'poster_path': None, 'season_number': 1}, {'air_date': '2008-01-30', 'episode_count': 10, 'id': 31336, 'name': 'Season 2', 'overview': '', 'poster_path': None, 'season_number': 2}, {'air_date': '2009-01-07', 'episode_count': 8, 'id': 31337, 'name': 'Season 3', 'overview': '', 'poster_path': None, 'season_number': 3}, {'air_date': '2010-02-03', 'episode_count': 12, 'id': 31338, 'name': 'Season 4', 'overview': '', 'poster_path': None, 'season_number': 4}, {'air_date': '2011-01-19', 'episode_count': 14, 'id': 31340, 'name': 'Season 5', 'overview': '', 'poster_path': None, 'season_number': 5}, {'air_date': '2012-01-25', 'episode_count': 17, 'id': 31341, 'name': 'Season 6', 'overview': '', 'poster_path': None, 'season_number': 6}, {'air_date': '2013-02-22', 'episode_count': 13, 'id': 31342, 'name': 'Season 7', 'overview': '', 'poster_path': None, 'season_number': 7}, {'air_date': None, 'episode_count': 1, 'id': 83919, 'name': 'Season 8', 'overview': '', 'poster_path': None, 'season_number': 8}, {'air_date': '2015-01-15', 'episode_count': 6, 'id': 83918, 'name': 'Season 9', 'overview': '', 'poster_path': None, 'season_number': 9}, {'air_date': '2016-03-31', 'episode_count': 12, 'id': 79035, 'name': 'Season 10', 'overview': '', 'poster_path': None, 'season_number': 10}, {'air_date': '2017-01-23', 'episode_count': 5, 'id': 85896, 'name': 'Season 11', 'overview': '', 'poster_path': None, 'season_number': 11}, {'air_date': '2018-02-26', 'episode_count': 20, 'id': 100110, 'name': 'Season 12', 'overview': '', 'poster_path': None, 'season_number': 12}, {'air_date': '2019-08-12', 'episode_count': 16, 'id': 130186, 'name': 'Season 13', 'overview': '', 'poster_path': None, 'season_number': 13}, {'air_date': '2021-01-18', 'episode_count': 7, 'id': 166369, 'name': 'Season 14', 'overview': '', 'poster_path': '/lp4BWrPsfQUY0yTBBbkbdUJkfPm.jpg', 'season_number': 14}, {'air_date': '2021-06-27', 'episode_count': 6, 'id': 200545, 'name': 'Season 15', 'overview': '', 'poster_path': None, 'season_number': 15}], 'alternative_titles': [], 'duration': 2580, 'rootname': 'American Greed - 1x02', 'imdbnumber': 'tt1190931', 'country': [], 'mpaa': '', 'trailer': '', 'country_codes': [], 'writer': [], 'director': [], 'all_trailers': [], 'cast': [], 'studio': ['CNBC'], 'extra_info': {'status': 'Returning Series', 'type': 'Documentary', 'homepage': 'https://www.cnbc.com/american-greed/', 'created_by': 'N/A', 'next_episode_to_air': None, 'last_episode_to_air': {'air_date': '2021-07-12', 'episode_number': 6, 'id': 3071490, 'name': "A Father's Fraud", 'overview': 'Karl Karlsen is a hardworking man with what seems to be a terrible streak of bad luck, as his wife and son both die in accidents nearly 20 years apart; Karl has a secret: their suspicious deaths have been keeping his bank account full.', 'production_code': '', 'runtime': 43, 'season_number': 15, 'show_id': 21572, 'still_path': None, 'vote_average': 0.0, 'vote_count': 0}}, 'total_aired_eps': 153, 'mediatype': 'tvshow', 'total_seasons': 15, 'tvshowtitle': 'American Greed', 'status': 'Returning Series', 'clearlogo': '', 'images': {'backdrops': [{'file_path': '/hLA3vuKSOXmyu7DH804huzlgj9j.jpg'}, {'file_path': '/jqWjO8VDnX56zzBTQSZO0E3Aa7Z.jpg'}], 'logos': [], 'posters': [{'file_path': '/bilmBb9Q4sLesr1gdMknSGfQQ7H.jpg'}]}, 'changed_artwork': {}, 'poster2': '', 'fanart2': '', 'clearlogo2': '', 'banner': '', 'clearart': '', 'landscape': '', 'discart': '', 'keyart': '', 'fanart_added': True, 'media_type': 'episode', 'season': 1, 'episode': 2, 'ep_name': 'The Imposter: Dr. Barnes / Interstate Bank Mart Bandit', 'background': False, 'skip_option': {'title': 'American Greed', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '60'}, 'skip_style': 'netflix', 'url': 'stack://https://hls10x.vidfiles.net/videos/hls/Xfr7iZq8WhU_8biyCi66dw/1663270600/336669/c57c343c19862f3f143cb7c67efe60be/ep.1.v1.1655284255.m3u8|User-Agent=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%3B+rv%3A68.0%29+Gecko%2F20100101+Firefox%2F68.0&Referer=https%3A%2F%2Fmembed.net%2Floadserver.php%3Fid%3DMzM2NjY5', 'bookmark': 0}
    # meta = {'mediatype': 'episode', 'year': 2022, 'plot': 'The Kapil Sharma Show, also known as TKSS, is an Indian Hindi-language stand-up comedy and talk show broadcast by Sony Entertainment Television. Hosted by Kapil Sharma The series revolved around Sharma and his neighbours in the Shantivan Non Co-operative Housing Society.', 'title': 'The Kapil Sharma Show Season 4', 'studio': ['Sony'], 'poster': 'https://www.desi-serials.cc/wp-content/uploads/2022/08/The-Kapil-Sharma-Show-300x169.jpg', 'homepage': 'https://www.desi-serials.cc/watch-online/sony-tv/the-kapil-sharma-show-season-4/', 'genre': ['Saturday  Sunday.', 'Comedy', 'Talk-Show'], 'cast': [], 'tmdb_id': 'Sony|The Kapil Sharma Show Season 4', 'imdb_id': 'tt5747326', 'rating': 7.3, 'clearlogo': '', 'trailer': '', 'votes': 50, 'tagline': '', 'director': [], 'writer': [], 'episodes': 390, 'seasons': '1, 2, 3, 4', 'extra_info': {'status': '', 'collection_id': ''}, 'tvdb_id': 'Sony|the kapil sharma show', 'duration': 3600, 'mpaa': 'TV-MA', 'season': 4, 'episode': 910, 'tvshowtitle': 'The Kapil Sharma Show Season 4', 'playcount': 0, 'original_title': 'The Kapil Sharma Show Season 4', 'total_seasons': '4', 'url': 'https://www.desi-serials.cc/the-kapil-sharma-show-season-4-episode-10th-september-2022-watch-online/441968/', 'fanart': 'https://www.desi-serials.cc/wp-content/uploads/2022/08/The-Kapil-Sharma-Show-300x169.jpg', 'premiered': '2022-09-10', 'ep_name': '10th September 2022', 'overlay': 4, 'media_type': 'episode', 'background': False, 'skip_option': {'title': 'The Kapil Sharma Show', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '300'}, 'skip_style': 'netflix'}
    if win == 'nextep_win': # windows.next_episode <<<<<<<<<
        action = open_window(('windows.next_episode', 'NextEpisode'), 'next_episode.xml', meta=meta, test=True, default_action='cancel', play_type='autoplay_nextep', focus_button=11)
        if action == 'cancel':
            action = open_window(('windows.skip', 'Skip'), 'skipmulti.xml', skip_option=meta.get('skip_option'), focus_button=201, window_style='end_skip')
        action = open_window(('windows.next_episode', 'NextEpisode'), 'next_episode.xml', meta=meta, test=True, default_action='cancel', play_type='autoscrape_nextep', focus_button=11)
    elif win == 'infopop': # windows.infopop <<<<<<<<<
        action = open_window(('windows.extras', 'Extras'), 'extras.xml', options_media_type=meta.get('media_type'), meta=meta, is_widget='false')
    elif win == 'skip_win': # windows.skip <<<<<<<<<<
        skip_option = {'title': 'The Blacklist', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '300'}
        windowstyle = 'netflix'#get_setting('skip.dialog')
        logger(f'windowstyle: {windowstyle.lower()}')
        buttonskip = open_window(('windows.skip', 'Skip'), 'skipmulti.xml', skip_option=skip_option, focus_button=201, window_style=windowstyle.lower())
        logger(f'buttonskip: {buttonskip}')
    elif win == 'sources_playback': # sources_playback && resolver_dialog<<<<<<<
        from threading import Thread
        from modules import kodi_utils, settings
        # kwargs = {'meta': meta, 'text': 'ok i see', 'enable_buttons': True, 'true_button': 'Yes', 'false_button': 'No', 'focus_button': 11}
        kwargs = {'meta': meta, 'text': 'ok i see', 'enable_fullscreen': True}
        _threads = []
        start_time = time.time()
        scraper_timeout = int(kodi_utils.get_setting('results.timeout', '30'))
        sleep_time = 100
        end_time = start_time + scraper_timeout
        monitor = kodi_utils.monitor
        ls = kodi_utils.local_string
        progress_dialog = create_window(('windows.sources', 'SourcesPlayback'), 'sources_playback.xml', meta=meta)
        Thread(target=progress_dialog.run).start()
        ### &&&& for resolver_dialog uncomment next line
        # progress_dialog.enable_resolver()
        # progress_dialog.busy_spinner('false')
        # progress_dialog.enable_resume(text=ls(32790) % 15)
        remaining_providers = ['freeworldnews.tv', 'playersb.com', 'vedshare.com', 'voeunblock8.com', 'youtu.be']
        try:
            while not progress_dialog.iscanceled() and not monitor.abortRequested():
                if progress_dialog.iscanceled(): break
                sources_total = sources_4k = sources_1080p = sources_720p = sources_sd = 5
                current_time = time.time()
                current_progress = current_time - start_time
                line1 = ', '.join(remaining_providers).upper()
                percent = int((current_progress/float(scraper_timeout))*100)
                try: progress_dialog.update_scraper(sources_sd, sources_720p, sources_1080p, sources_4k, sources_total, line1, percent, current_progress)
                except: progress_dialog.update_resolver(text=line1)
                kodi_utils.sleep(10)
                # if len(remaining_providers) == 0: break
                # logger(f'percent: {percent} current_progress: {current_progress}')
                if percent >= 100: break
                if current_time >= end_time: break
        except: logger(f'error: {print_exc()}')
        progress_dialog.close()
        try: del monitor
        except: pass
    elif win == 'sources_results': # windows.select_ok <<<<<<<<<<<<
        results = [{'source': 'tvarticles', 'quality': 'SD', 'info': 'All part: Single', 'url': 'https://tvarticles.org/vidd.php?id=2239785', 'direct': False, 'name': 'The Kapil Sharma Show S1E226', 'name_info': '', 'provider': 'desiserials', 'display_name': 'The Kapil Sharma Show S1E226', 'external': True, 'scrape_provider': 'external', 'extraInfo': 'All part: Single', 'module_path': 'openscrapers.sources_openscrapers.en.desiserials', 'size_label': None, 'size': 0, 'provider_rank': 11, 'quality_rank': 4}]
        scraper_settings = {'highlight_type': 2, 'hoster_highlight': '', 'torrent_highlight': '', 'real-debrid': '', 'premiumize': '', 'alldebrid': '', 'rd_cloud': '', 'pm_cloud': '', 'ad_cloud': '', 'furk': '', 'easynews': '', 'folders': '', '4k': 'FFFF3334', '1080p': 'FFE6B800', '720p': 'FF3C9900', 'sd': 'FFCAFFFF'}
        action, chosen_item = open_window(('windows.sources', 'SourceResults'), 'sources_results.xml',
				window_format='list', window_style='non_contrast', window_id=2000, results=results, meta=meta,
				scraper_settings=scraper_settings, prescrape=False, filters_ignored=False, uncached_torrents=[])
        if not action: close_all_dialog()
    elif win == 'select_ok_win': # windows.select_ok <<<<<<<<<<<<
        from modules.kodi_utils import local_string, confirm_dialog, ok_dialog
        confirm_dialog(heading='Infinite', text=local_string(32855), ok_label=local_string(32824), cancel_label=local_string(32828))
        ok_dialog(heading='Infinite', text=local_string(32855))

def cache_test():
    ctime = datetime.datetime.now()
    current_time = int(time.mktime(ctime.timetuple()))
    clean_databases(current_time, database_check=False, silent=True)
    from modules.source_utils import sources
    providers = sources('true', 'episode')
    from indexers.hindi.lists import youtube_m3u
    youtube_m3u()
    from caches.h_cache import MainCache
    MainCache().clean_hindi_lists()
    logger(providers)
    from caches import clrCache_version_update
    clrCache_version_update(clr_cache=True, clr_navigator=False)
    from apis.trakt_api import trakt_sync_activities
    status = trakt_sync_activities()
    logger(f'status: {status}')

def get_meta():
    from modules import kodi_utils, settings
    from modules.utils import get_datetime
    from modules.metadata import episodes_meta, all_episodes_meta, tvshow_meta
    current_date = get_datetime
    meta_user_info = settings.metadata_user_info()
    ep_data_get = {'media_ids': {'tmdb': 93812}, 'season': 2}
    meta = tvshow_meta('trakt_dict', ep_data_get['media_ids'], meta_user_info, current_date)
    logger(f'meta: {meta}')

def get_folders():
    from modules.source_utils import internal_sources
    from modules.kodi_utils import get_setting
    prescrape_scrapers = []
    active_internal_scrapers = ['folders']
    # prescrape_scrapers.extend(internal_sources(active_internal_scrapers, True))
    media_type = 'movie45'
    if media_type == 'movie': source_dir = '%s.movies_directory'
    else:  source_dir = '%s.tv_shows_directory'
    # setting = '%s.movies_directory' % source if media_type == 'movie' else '%s.tv_shows_directory' % source
    folder_info = [(get_setting('%s.display_name' % i), i) for i in ('folder1', 'folder2', 'folder3', 'folder4', 'folder5') if not get_setting(source_dir % i) in (None, 'None', '')]
    logger(f'prescrape_scrapers: {folder_info}')
