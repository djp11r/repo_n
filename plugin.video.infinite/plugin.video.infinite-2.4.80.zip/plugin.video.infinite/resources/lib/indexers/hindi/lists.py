# -*- coding: utf-8 -*-

import datetime
import base64
import json
import re
from traceback import print_exc
from urllib.parse import urlencode

from modules import dom_parser

try:
    from modules.kodi_utils import logger, build_url, addon_icon, make_listitem, set_info,  notification, add_items, set_content, end_directory, set_view_mode, get_infolabel, set_category, external_browse, get_git_url
    from modules.utils import normalize
    from indexers.hindi.live_client import scrapePage, agent, read_write_file, string_escape, replaceHTMLCodes
    from caches.h_cache import main_cache
except:
    # logger(f'import Exception: {print_exc()}')
    from modules.utils import logger, normalize
    from modules.live_client import scrapePage, agent, read_write_file, string_escape, replaceHTMLCodes
    from modules.h_cache import main_cache
    import os
selective = [{'title': 'Fox 5 Atlanta (WAGA)', 'url': 'https://lnc-waga-fox-aws.tubi.video/index.m3u8', 'poster': 'https://i.imgur.com/qdYfhpZ.jpg', 'action': 'ltp_pluto'},
    {'title': 'Fox 5 Atlanta GA (WAGA-TV)', 'url': 'https://csm-e-eb.csm.tubi.video/csm/extlive/tubiprd01,p-WAGA-Monetizer.m3u8', 'action': 'ltp_pluto'},
    {'title': 'Fox Atlanta-GA (WAGA-DT1)', 'url': 'https://trn10.tulix.tv/WAGA-FOX/index.m3u8', 'action': 'ltp_pluto'},
    {'title': 'Fox Weather', 'url': 'https://csm-e-eb.csm.tubi.video/csm/extlive/tubiprd01,Fox-Weather.m3u8', 'action': 'ltp_pluto'},
    {'title': 'Fox Weather', 'url': 'https://live-news-manifest.tubi.video/live-news-manifest/csm/extlive/tubiprd01,Fox-Weather.m3u8', 'action': 'ltp_pluto'},
    {'title': 'Fox Weather', 'url': 'https://247wlive.foxweather.com/stream/index.m3u8', 'poster': 'https://i.imgur.com/ojLdgOg.png', 'action': 'ltp_pluto'}]


def youtube_m3u(params):
    ch_name = params['list_name']
    rescrape = params['rescrape']
    iconImage = params['iconImage']
    params = {'ch_name': ch_name, 'rescrape': rescrape, 'iconImage': iconImage}
    cache_name = f'content_youtube_m3u_{ch_name}{urlencode(params)}'
    list_data = None
    if rescrape == 'true': main_cache.delete(cache_name)
    else: list_data = main_cache.get(cache_name)
    # logger(f'from cache list_data: {list_data}')
    if not list_data:
        # uri = 'https://raw.githubusercontent.com/benmoose39/YouTube_to_m3u/main/youtube.m3u'
        # page = scrapePage(uri).text
        # list_data = m3u2list(normalize(page))
        uri = f'{get_git_url()}/youtub_live.json'
        data = scrapePage(uri).text
        list_data = json.loads(data)
        # logger(f'new list_data: {list_data}')
        if list_data: main_cache.set(cache_name, list_data, expiration=datetime.timedelta(hours=12))
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_widget = external_browse()
    if list_data:
        item_list = list(_process(list_data, 'youtube_m3u'))
        add_items(handle, item_list)
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle)
        set_view_mode('view.episodes', 'episodes', is_widget)
    else:
        notification(f'No links Found for: :{ch_name} Retry', 900)
        end_directory(handle)
        return


def m3u2list(response, chList=None):
    if chList is None: chList = []
    nondesiralbe = ('Marathi', 'Malayalam', 'Tamil', 'Urdu', 'Albania', 'Exyu', 'Telugu', 'Kannada', 'Odisha', 'Malayalam', 'Radio', 'Türk', 'East Africa', 'France', 'Pakistan', 'Taiwan News', 'Music')
    matches = re.compile('^#EXTINF:-?[0-9]*(.*?),([^\"]*?)\n(.*?)$', re.M).findall(response)
    li = []
    for params, display_name, url in matches:
        # logger(f'display_name: {display_name}')
        display_name = display_name.replace('$', '').strip()
        if url != '':
            item_data = {'params': params, 'title': display_name, 'url': url.strip()}
            if display_name not in nondesiralbe: li.append(item_data)
    for channel in li:
        item_data = {'action': 'ltp_pluto', 'title': (channel['title']), 'url': channel['url']}
        matches = re.compile(' (.*?)="(.*?)"').findall(channel['params'])
        for field, value in matches:
            field = field.strip().lower().replace('-', '_')
            if field == 'tvg_logo':
                value = value.strip()
                if value is None or value == 'logo N/A' or value == '.': value = ''
                elif value.endswith('.png') or not value.endswith('.jpg'): value = value
            item_data[field] = value.strip()
        if 'tvg_logo' not in item_data: item_data['tvg_logo'] = ''
        chList.append(item_data)
    #logger(f'chList: {chList}')
    return chList


def pluto(params):
    cache_name = 'content_pluto_'
    list_data = None
    if params['rescrape'] == 'true': main_cache.delete(cache_name)
    else: list_data = main_cache.get(cache_name)

    if not list_data:
        # uri = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL1RlbXBlc3QwNTgwL3htbC9tYXN0ZXIvcGx1dG8ubTN1'
        # try: uri = base64.b64decode(uri.encode('ascii')).decode('ascii')
        # except: uri = base64.b64decode(uri.encode('ascii'))
        uri = f'{get_git_url()}/pluto.json'
        data = scrapePage(uri).text
        list_data = json.loads(data)
        # uri = 'https://raw.githubusercontent.com/Tempest0580/xml/master/webos.m3u8'
        # uri = 'https://raw.githubusercontent.com/Tempest0580/xml/master/pluto.m3u'
        # page = scrapePage(uri).text
        # list_data = m3u2list(page)
        if list_data: main_cache.set(cache_name, list_data, expiration=datetime.timedelta(hours=36))
    # else:
        # with open(pluto_chennel, 'r') as f:
            # page = json.load(f)

    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_widget = external_browse()
    add_items(handle, list(_process(list_data, 'pluto')))
    set_content(handle, 'episodes')
    set_category(handle, 'episodes')
    end_directory(handle)
    set_view_mode('view.episodes', 'episodes', is_widget)


def indian_live(params):
    cache_name = 'content_indian_live'
    list_data = None
    if params['rescrape'] == 'true': main_cache.delete(cache_name)
    else: list_data = main_cache.get(cache_name)

    if not list_data:
        # uri = 'https://raw.githubusercontent.com/Vikassm73/AjaykRepo/main/Zips/India.m3u'
        # page = scrapePage(uri).text
        # # page = read_write_file(file_n='raw.githubusercontent.com.html')
        # # with open(pluto_chennel1, 'r', encoding='utf-8') as f:
            # # page = f.read()
        # list_data = m3u2list(page)
        uri = f'{get_git_url()}/indian_live.json'
        data = scrapePage(uri).text
        list_data = json.loads(data)
        if list_data: main_cache.set(cache_name, list_data, expiration=datetime.timedelta(hours=36))
        # logger(f'page: {page}')
    # else:
        # with open(pluto_chennel, 'r') as f:
            # page = json.load(f)
    # logger(f'total: {len(page)} page: {page}')
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_widget = external_browse()
    add_items(handle, list(_process(list_data, 'indian_live')))
    set_content(handle, 'episodes')
    set_category(handle, 'episodes')
    end_directory(handle)
    set_view_mode('view.episodes', 'episodes', is_widget)


def _process(list_data, provider):
    if provider == 'indian_live': list_data = selective + list_data
    for i in list_data:
        # logger(f'lists _process item: {item}')
        listitem = make_listitem()
        title = i['title']
        poster = i.get('poster', '')
        thumb = i['poster'] if poster.startswith('http') else addon_icon
        url_params = {'mode': i['action'], 'title': title, 'url': i['url'], 'provider': provider}
        url = build_url(url_params)
        options_params = {'mode': 'options_menu_choice', 'suggestion': title, 'play_params': json.dumps(url_params)}
        cm = [('[B]Options...[/B]', f'RunPlugin({build_url(options_params)})')]
        listitem.setLabel(title)
        listitem.addContextMenuItems(cm)
        listitem.setArt({'thumb': thumb})
        i.update({'imdb_id': title, 'mediatype': 'episode', 'episode': 1, 'season': 0})
        listitem = set_info(listitem, i, {'imdb': str(title)})
        yield url, listitem, False
    return


def play(params):
    # logger(f'play params '{params}'')
    url = params['url']
    try:
        if params['provider'] == 'pluto' and 'm3u8' in url: url = f'{url}|User-Agent={agent()}&Referer={url}'
        elif params['provider'] == 'youtube_m3u': url = get_m3u8_url(params['url'])
        else: url = f'{url}|User-Agent={agent()}' #url = f'{url}|User-Agent={agent()}&Upgrade-Insecure-Requests=1'
        logger(f'--- Playing title: {params["title"]}  url: {url}')
        from modules.player import infinitePlayer
        # infoLabels = {'title': params['title']}
        infinitePlayer().run(url, 'video', {'title': params['title']})
    except:
        logger(f'play provider: {params["provider"]} - Exception: {print_exc()}')
        return


def get_videoId(from_func, response):
    vars_ = re.compile(r'var ytInitialData =.*?[\'|"|{](.+)[\'|"|}][,;]</script>').findall(response)
    # logger(f'vars_>>> : {vars_}')
    ytInitialData = string_escape(vars_[0])
    # logger(f'ytInitialData: {ytInitialData}')
    return re.findall(
        r'(compactvideoRenderer|videoRenderer)\":\{\"videoId\":\"(.+?)\",',
        ytInitialData,
        re.IGNORECASE,
    )


def get_m3u8_url(url):
    # logger(f'get_m3u8_url url: {url}')
    furl = None
    if 'https://www.youtube.com/channel' in url: response = scrapePage(url).text
    else: response = scrapePage(f'{url}/videos').text
    # response = read_write_file('www.youtube.com.html')
    # response = to_utf8(response)
    # logger(response)
    videoIds = get_videoId('get_m3u8_url', response)
    videoId_counter = 0
    for videoId in videoIds:
        furl = None
        videoId_counter += 1
        live_yturl = f'https://www.youtube.com/watch?v={videoId[1]}'
        # logger(f'live_yturl: {live_yturl}')
        response = scrapePage(live_yturl).text
        # logger(f'<<<--->>> \n{response}\n<<<--->>>')
        if '.m3u8' in response:
            # logger(f'videoId_counter: {videoId_counter}')
            furl = extract_m3u8(response)
            if furl: break
    logger(f'Total videoId: {len(videoIds)} get link from 2videoId_counter: {videoId_counter}')
    if furl: return furl
    else: return 'https://raw.githubusercontent.com/benmoose39/YouTube_to_m3u/main/assets/moose_na.m3u'


def extract_m3u8(response):
    end = response.find('.m3u8') + 5
    tuner = 100
    while True:
        if 'https://' in response[end - tuner: end]:
            link = response[end - tuner: end]
            start = link.find('https://')
            end = link.find('.m3u8') + 5
            break
        else: tuner += 5
    # logger(f'{link[start: end]}')
    return link[start: end]


def get_redjoyiptv_list(params):
    # url = 'https://embed.castamp.com/ArchieIPL'
    url = 'https://redjoyiptv.co/ipl-crickethindi.m3u8'
    response = scrapePage(url).text
    # response = read_write_file('crickethindi.m3u8')
    logger(f'response: {response}')
    matches = re.compile('^https([^\'"]+.m3u8)$', re.M).findall(response)
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    try:
        url = f'https{matches[0]}'
        # logger(f'matches: https{matches[0]}')
        # response = scrapePage(url).text
        # ch_list = m3u2list(response, [])
        ch_list = [{'action': 'ltp_pluto', 'title': 'IPL Cricket', 'url': url}]
        add_items(handle, list(_process(ch_list, 'redjoyiptv_list')))
        is_widget = external_browse()
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle)
        set_view_mode('view.episodes', 'episodes', is_widget)
    except:
        notification(f'No links Found matches :{matches} Retry', 900)
        end_directory(handle)
        return


#if __name__ == '__main__':
    # response = read_write_file('neff.m3u8')
    # m3u2list(response, [])
    #get_redjoyiptv_list()
#     item = {'url': 'https://www.youtube.com/channel/UCT1egsvA08YcdMLiEu1DTRg'}
#     url = get_m3u8_url(item['url'])
#     logger(f'final url: {url}')
