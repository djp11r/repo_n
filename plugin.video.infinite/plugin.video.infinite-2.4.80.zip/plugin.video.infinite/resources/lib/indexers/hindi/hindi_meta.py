# -*- coding: utf-8 -*-
import json
import re
from traceback import print_exc

from urllib.parse import quote_plus, urljoin


try:
    from indexers.hindi.live_client import scrapePage, requests, find_season_in_title, keepclean_title
    from caches.h_cache import metacache
    from modules.kodi_utils import logger, item_next
except:
    import os, sys

    file = os.path.realpath(__file__)
    sys.path.append(os.path.join(os.path.dirname(file), 'modules'))
    from live_client import scrapePage, requests, find_season_in_title, keepclean_title, read_write_file
    from modules.h_cache import metacache
    from modules.utils import logger

    item_next = ''

from modules.dom_parser import parseDOM
from modules.utils import replace_html_codes


def metacache_set(mediatype, meta):
    if mediatype == 'movie': metacache.set('movie', 'tmdb_id', meta)
    else: metacache.set('tvshow', 'tmdb_id', meta)


def gettmdb_id(mediatype, title, year, studio):
    return (
        f'{title.lower()}|{year}'
        if mediatype == 'movie'
        else f'{studio}|{title.lower()}'
    )


def fetch_meta(mediatype, title, season, tmdb_id, homepage, studio='Hindi', poster='hindi_movies.png', plot='', genre=None, year=2022, cast=None, imdb_id='', rating=5.0):
    if genre is None: genre = []
    if cast is None: cast = []
    meta, custom_artwork = metacache.get(mediatype, 'tmdb_id', tmdb_id)
    # logger(f'shows desirulez meta: {str(meta)}')
    if meta is None:
        if not plot and re.search('desi-serials|playdesi', str(homepage), re.I):
            plot, rating, genre = get_plot_tvshow(homepage)
        meta = populet_dict(mediatype=mediatype, title=title, season=season, homepage=homepage, studio=studio, poster=poster, tmdb_id=tmdb_id, imdb_id=imdb_id, plot=plot, genre=genre, year=year, cast=cast, rating=rating)
        if imdbdata := get_datajson_imdb(meta):
            logger(f'imdb_id imdbdata: {imdbdata}')
            meta = meta_merge_update(meta, imdbdata)
        metacache_set(mediatype, meta)
    return meta


def meta_merge_update(meta, imdbdata):
    # logger(f'meta_merge_update meta: {meta}\n imdbdata: {imdbdata}')
    try:
        if isinstance(meta['genre'], list) and isinstance(imdbdata['genre'], list):
            genre = meta['genre'] + imdbdata['genre']
            if len(genre) > 1: genre = list(set(genre))
            meta.update({'genre': genre})
    except: logger(f'shows desirulez Error: {print_exc()}')
    if meta['plot'] == '' and imdbdata['plot'] != '': meta.update({'plot': imdbdata['plot']})
    if 'hindi_' in meta['poster'] and imdbdata['poster'] != '': meta.update({'poster': imdbdata['poster']})
    if imdbdata['duration']: meta.update({'duration': imdbdata['duration']})
    if imdbdata['mpaa']: meta.update({'mpaa': imdbdata['mpaa']})
    if imdbdata['imdb_id']: meta.update({'imdb_id': imdbdata['imdb_id']})
    if imdbdata['year']: meta.update({'year': imdbdata['year']})
    if imdbdata['rating']: meta.update({'rating': imdbdata['rating']})
    if imdbdata['episodes'] != 0: meta.update({'episodes': imdbdata['episodes']})
    if imdbdata['seasons'] != 0: meta.update({'seasons': imdbdata['seasons'], 'season': imdbdata['seasons']})
    return meta


def populet_dict(mediatype, title, season, homepage, studio, poster, tmdb_id, imdb_id, plot, genre, year, cast, rating):
    """
    :useges
    meta = populet_dict(mediatype='movie', title=title, year=year,
                        studio=ch_name, plot='', fanart=imgurl,
                        genre='', tvshowtitle=None, imdb_id=imdb)
    :param mediatype:
    :param title:
    :param studio:
    :param homepage:
    :param poster:
    :param tmdb_id:
    :param plot:
    :param year:
    :param genre:
    :param cast:
    :param imdb_id:
    :param rating:
    :return: dict
    """
    if imdb_id == '': imdb_id = tmdb_id
    try:
        if 'addons\\plugin.video.infinite' in poster:
            special_path = 'special://home/addons'
            poster = f'{special_path}{poster.split("addons")[1]}'
            poster = poster.replace('\\', '/')
    except: logger(f'homepath not found: {print_exc()}')
    if cast is None: cast = [{'role': '', 'name': '', 'thumbnail': ''}]
    if rating is None: rating = 4
    plot = replace_html_codes(plot)
    plot = plot.replace('\\n', ' ').replace('\\u2009', ' ').replace("\\'", "'").replace('\\r', '').strip()
    if isinstance(studio, str): studio = studio.split(',')
    if not genre: genre = []
    if isinstance(genre, str):
        genre = replace_html_codes(genre)
        genre = genre.split(',')
    fgenre = []
    for genr in genre:
        genr = genr.replace('<span data-sheets-value="{"1"', '')
        genr = replace_html_codes(genr)
        fgenre.append(genr.strip())
    # logger(f'IN genre: {genre} plot: {plot}')
    if not fgenre:
        fgenre = ['movie'] if mediatype == 'movie' else ['tv']
    if len(fgenre) > 1: fgenre = list(set(fgenre))  #remove duplicate items from list
    dic_meta = {'mediatype': mediatype,
                'year': year,
                'plot': plot,
                'title': title,
                'studio': studio,
                'poster': poster,
                'homepage': homepage,
                'genre': fgenre,  #['Animation, Music, Documentary']
                'cast': cast,
                'tmdb_id': tmdb_id,
                'imdb_id': imdb_id,
                'rating': rating,
                'clearlogo': '', 'trailer': '',
                'votes': 50, 'tagline': '', 'director': [],
                'writer': [], 'episodes': 0, 'seasons': 0,
                'extra_info': {'status': '', 'collection_id': ''}}
    if mediatype == 'movie': dic_meta.update({'tvdb_id': 'None', 'duration': 5400, 'mpaa': 'R'})
    else: dic_meta.update({'tvdb_id': imdb_id, 'duration': 1320, 'mpaa': 'TV-MA', 'season': season, 'episodes': 2, 'seasons': season, 'episode': 1, 'tvshowtitle': title})
    return dic_meta


def seach_omdbapi(meta):
    title = meta['title']
    year = meta['year']
    dType = 'movie' if meta['mediatype'] == 'movie' else 'series'
    title = keepclean_title(title)
    title = re.sub(r'(\d+)', '', title)
    title = title.strip()
    api_url = f'http://www.omdbapi.com/?apikey=dd7e2fc7&s={quote_plus(title)}'
    # logger(f'url: {api_url}')
    session = requests.Session()
    result = session.get(api_url, timeout=20.0)
    item_meta = json.loads(result.text)
    # logger(f'result: {item_meta}')
    # item_meta = json.loads(rt)
    if not item_meta.get('Search'): return meta
    for item in item_meta.get('Search'):
        otitle = item['Title']
        if title.lower() in otitle.lower() and item['Type'] == dType:
            id_year = item['Year']
            id_year = re.sub(r'[^\x00-\x7f]', r'-', id_year)  # remove all non-ASCII characters
            if '-' in id_year: id_year = id_year.split('-')[0]
            if item.get('Year'): meta['year'] = id_year
            if item.get('imdbID'): meta['imdb_id'] = item['imdbID']
            if item.get('Poster'): meta['poster'] = item['Poster']
            # logger(f'item: {item}')
            break
    return meta


def get_datajson_imdb(metadict):
    oimdb_id = metadict['imdb_id']
    if not oimdb_id.startswith('tt'): metadict = seach_omdbapi(metadict)
    oimdb_id = metadict['imdb_id']
    if oimdb_id.startswith('tt'):
        url = f'https://www.imdb.com/title/{oimdb_id}/'
    elif metadict['mediatype'] == 'movie': url = f'https://www.imdb.com/search/title/?title={quote_plus(metadict["title"])}&title_type=feature,tv_movie&countries=in'
    else: url = f'https://www.imdb.com/search/title/?title={quote_plus(metadict["title"])}&title_type=tv_series,tv_episode,tv_miniseries&countries=in'
    logger(f'for : {metadict["title"]} checking url: {url}')
    result = scrapePage(url).text
    # result = read_write_file(file_n='www.imdb.com.html')
    # metadict = {'title': title, 'year': year, 'rating': 5.0, 'plot': '', 'imdb_id': oimdb_id, 'mpaa': cmpaa, 'duration': cduration, 'genre': [], 'poster': 'hindi_movies.png', 'episodes': 0, 'seasons': 0}
    return imdb_json_parser(result, metadict) or imdb_html_parser(result, metadict)


def imdb_json_parser(result, metadict):
    try:
        scripts = parseDOM(result, 'script', attrs={'id': '__NEXT_DATA__'})
        item_meta = json.loads(scripts[0])
        item_meta1 = item_meta['props']['pageProps']['aboveTheFoldData']
        # logger(f'item_meta1: {item_meta1}')
        try:
            if year := item_meta1['releaseYear']['year']:
                metadict.update({'year': year})
        except: pass
        try:
            if ratings := item_meta1['ratingsSummary']['aggregateRating']:
                metadict.update({'rating': ratings})
        except: pass
        try:
            rgen = item_meta1['genres']['genres']
            # genres = ', '.join(str(x['text']) for x in rgen if x != '')
            genres = [str(x['text']) for x in rgen if x != '']
            if genres: metadict.update({'genre': genres})

            plot = item_meta1['plot']['plotText']['plainText']
            if plot := replace_html_codes(plot):
                metadict.update({'plot': plot})
        except: pass
        try:
            if certf := item_meta1['certificate']['rating']:
                metadict.update({'mpaa': certf})
        except: pass
        item_meta2 = item_meta['props']['pageProps']['mainColumnData']
        # logger(f'item_meta2: {item_meta2}')
        try:
            if runtime := item_meta2['runtime']['seconds']:
                metadict.update({'duration': runtime})
        except: pass
        try:
            if poster := item_meta2['titleMainImages']['edges'][0]['node']['url']:
                metadict.update({'poster': poster})
        except: pass
        try:
            if seasons := item_meta2['episodes']['seasons'][-1]:
                metadict.update({'seasons': int(seasons.get('number', 1))})
            if episodes := item_meta2['episodes']['episodes']['total']:
                metadict.update({'episodes': int(episodes)})
        except: pass
        if ctitle := item_meta1['titleText']['text']:
            metadict.update({'title': keepclean_title(ctitle)})
    except:
        return
    # logger(f'imdb_json_parser metadict: {metadict}')
    return metadict


def imdb_html_parser(result, metadict):
    try:
        items = parseDOM(result, 'div', attrs={'class': 'ipc-page-content-container.+?'})
        try:
            duration_wrapper = parseDOM(items, 'ul', attrs={'class': '.+?TitleBlockMetaDat.+?'})
            duration = parseDOM(duration_wrapper, 'li', attrs={'class': 'ipc-inline-list__item'})
            duration = duration[1] if metadict['mediatype'] == 'movie' else duration[2]
            dur = duration.replace('<!-- -->', '')
            if duration := get_sec_string(dur):
                metadict.update({'duration': duration})
        except: pass
        try:
            poster = parseDOM(items, 'img', attrs={'class': '.+?ipc-image.+?'}, ret='src')[0]
            if '/nopicture/' in poster: poster = '0'
            poster = re.sub(r'(?:_SX|_SY|_UX|_UY|_CR|_AL)(?:\d+|_).+?\.', '_SX500.', poster)
            if poster := replace_html_codes(poster):
                metadict.update({'poster': poster})
        except: pass
        try:
            # genresplot_wrapper = parseDOM(items, 'div', attrs={'class': '.+?GenresAndPlot__ContentParent.+?'})
            # logger(f'Total: {len(genresplot_wrapper)} duration_wrapper: {genresplot_wrapper}')
            genres_wrapper = parseDOM(items, 'a', attrs={'class': '.+?GenresAndPlot__GenreChip.+?'})
            if genre := [
                item.replace(
                    '<span class="ipc-chip__text" role="presentation">', ''
                ).replace('</span>', '')
                for item in genres_wrapper
                if item
            ]:
                if genre: metadict.update({'genre': genre})
        except: pass
        try:
            plot_wrapper = parseDOM(items, 'p', attrs={'class': '.+?GenresAndPlot__Plot.+?'})
            plot = parseDOM(plot_wrapper, 'span', attrs={'class': 'GenresAndPlot__TextContainerBreakpoint.+?'})[0]
            if plot := span_clening(plot):
                metadict.update({'plot': plot})
        except: pass
        try:
            rating_wrapper = parseDOM(items, 'div', attrs={'class': 'AggregateRatingButton__ContentWrap.+?'})
            if rating := parseDOM(
                rating_wrapper,
                'span',
                attrs={'class': 'AggregateRatingButton__RatingScore.+?'},
            )[0]:
                metadict.update({'rating': rating})
        except: pass
        try:
            mpaa_wrapper = parseDOM(items, 'div', attrs={'class': 'UserRatingButton.+?'})
            mpaa = parseDOM(mpaa_wrapper, 'div', attrs={'data-testid': 'hero-rating-bar.+?'})
            mpaa = mpaa[0].strip()
            if mpaa == 'Rate': pass
            elif mpaa: metadict.update({'mpaa': mpaa})
        except: pass
        try:
            title_wrapper = parseDOM(items, 'div', attrs={'class': 'TitleBlock__TitleContainer.+?'})
            if title := parseDOM(
                title_wrapper,
                'h1',
                attrs={'class': 'TitleHeader__TitleText.+?'},
            )[0]:
                metadict.update({'title': keepclean_title(title)})
        except: pass
        try:
            year_wrapper = parseDOM(items, 'span', attrs={'class': 'TitleBlockMetaData__ListItemText.+?'})
            try: year = re.search(r'\d{4}', year_wrapper).group()
            except: year = 2023
            if year: metadict.update({'year': year})
        except: pass
    except: pass
    # logger(f'imdb_html_parser metadict: {metadict}')
    return metadict


def get_sec_string(str_time):
    min_str = re.compile(r'(\d+)[m|min]')
    hrs_str = re.compile(r'(\d+)h')
    hrs_s = min_s = 0
    hrs_s = re.findall(hrs_str, str_time)
    if hrs_s: hrs_s = int(hrs_s[0]) * 60 * 60
    min_s = re.findall(min_str, str_time)
    if min_s: min_s = int(min_s[0]) * 60
    return hrs_s + min_s


def span_clening(span_text):
    span_text = span_text.rsplit('<span>', 1)[0].strip()
    span_text = re.sub('<.+?>|</.+?>', '', span_text)
    span_text = re.sub('\xa0', ' ', span_text)
    span_text = re.sub('See all certifications', '', span_text)
    # if '...' in span_text: span_text = span_text.split('...')[0]
    if 'add a plot' not in span_text.lower():
        span_text = replace_html_codes(span_text)
        # span_text = unescape(span_text)
        span_text.strip().replace('\\n', '')
    else: span_text = ''
    return span_text


def get_plot_tvshow(show_url=None):
    episo_page = scrapePage(show_url).text
    # episo_page = read_write_file(file_n='www.desi-serials.cc.html')
    # logger(f'episo_page: {episo_page}')
    result1 = parseDOM(episo_page, 'div', attrs={'class': 'main-content col-lg-9'})
    result1 += parseDOM(episo_page, 'div', attrs={'class': 'blog-posts posts-large posts-container'})
    # logger(f'result1: {result1}')
    # ## for overview <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    plot = ''
    genres = []
    rating = 5.0

    result = parseDOM(result1, 'div', attrs={'id': 'content'})
    # logger(f'result: {result[0]}')
    p = parseDOM(result, 'div', attrs={'class': 'page-content'})
    if p := parseDOM(p, 'div', attrs={'class': 'page-content'}):
        title_overview = re.findall(r'<p>(.+?)</p>', str(p))
        # logger(f'title_overview: {title_overview}')
        try: plot = title_overview[0].replace('<br/><br/>', '').replace('\\n', '').strip()
        except: pass
        # logger(f'plot: {plot}')
        try:
            rest_ofp = title_overview[1].replace('<br/><br/>', '').replace('\\n', '').strip()
            # logger(f'rating: {rest_ofp}')
            rating = re.findall(r'Show Rating: </span>\s+(.+?)/.+? <p>', rest_ofp)[0]
            # logger(f'rating: {rating}')
            genres = re.findall(r'Genre: </span>\s+(.+?)$', rest_ofp)  #[0]
            # logger(f'plot: {plot}\nrating: {rating}, genre: {genres}')
        except: pass
    else:
        # logger(f'result:  {result}')
        try: plot = re.findall(r'loading="lazy" \/><\/div>(.*?)<p>.+?<span', str(result), re.M)[0].strip()
        except: pass
        try:
            genress = re.findall(r'<span.+?font-weight:bold">(.+?)<\/span>', str(result), re.M)  #[0]
            for genre in genress:
                if 'on:' in genre: genre = genre.split(':')[1].strip()
                if genre: genres.append(genre)
                # genre = genre.replace('Show is Aired on:', '').strip()
        except: pass
    # logger(f'genre: {genre} plot: {plot}')

    # if isinstance(genre, list): genre = ', '.join(x.strip() for x in genre if x != '')
    # genre = genre.replace('.', '').replace(' :', ',').replace('&#8211;', ' ').replace('&#8230;', '').strip()
    plot = replace_html_codes(plot)
    # plot = f'{genre}\n{plot}'
    return plot, rating, genres
