# -*- coding: utf-8 -*-

import re
from json import dumps, loads
from traceback import print_exc
from urllib.parse import urlencode, urlparse

try:
    from modules.kodi_utils import logger, build_url, addon_icon, select_dialog, make_listitem, set_info,  notification, add_items, set_content, end_directory, set_view_mode, get_infolabel, set_category, external
    from modules.settings import get_git_url
    from modules.utils import normalize
    from modules.source_utils import request, agent
    from caches.main_cache import main_cache
    from caches.settings_cache import get_setting
    baseurl = get_setting('infinite.live_url', '')
    tvappurl = 'https://thetvapp.to'
    chnnel_filter = get_setting('infinite.live_channels', 'DAZN, Movistar').split(', ')
except:
    # logger(f'import Exception: {print_exc()}')
    from modules.utils import logger, normalize
    from modules.main_cache import main_cache
    from modules.client import request, agent
    import os
    baseurl = 'https://dlhd.sx'
    tvappurl = 'https://thetvapp.to'
    chnnel_filter = ['DAZN', 'Movistar', 'Espa', 'Alkass', 'Greece', 'Netherland', 'Germany', 'SUR', 'Deportes', 'Galavisi', 'Latino', 'Russia', 'Campeones', 'ES', 'Romania', 'DSTV', 'Italy', 'Argentina', 'Afrique', 'Denmark', 'Brasil', 'Sweden', 'Cosmote', 'Israe', 'Israel', 'Poland', 'Bulgaria', 'Spain', 'Qatar', 'Turkey', 'France', 'MENA', 'DE', 'Portugal', 'Croatia', 'Astro', 'Serbia']
from modules.dom_parser import parseDOM


def youtube(params):
    ch_name = params['list_name']
    iconImage = params['iconImage']
    # params = {'ch_name': ch_name, 'rescrape': rescrape, 'iconImage': iconImage}
    cache_name = f'content_youtube_{ch_name}{urlencode(params)}'
    list_data = None
    list_data = main_cache.get(cache_name)
    if not list_data:
        uri = f'{get_git_url()}/youtub_live.json'
        data = request(uri)
        list_data = loads(data)
        if list_data: main_cache.set(cache_name, list_data, expiration=168) # 7days
    # logger(f'from cache list_data: {list_data}')
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_external = external()
    if list_data:
        item_list = list(_process(list_data, 'youtube'))
        add_items(handle, item_list)
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.episodes', 'episodes', is_external)
    else:
        notification(f'No links Found for: :{ch_name} Retry')
        end_directory(handle)
        return


def pluto(params):
    cache_name = 'content_pluto_'
    list_data = None
    list_data = main_cache.get(cache_name)

    if not list_data:
        uri = f'{get_git_url()}/pluto.json'
        data = request(uri)
        list_data = loads(data)
        if list_data: main_cache.set(cache_name, list_data, expiration=168) # 7days
    # logger(f'from cache list_data: {list_data}')
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_external = external()
    add_items(handle, list(_process(list_data, 'pluto')))
    set_content(handle, 'episodes')
    set_category(handle, 'episodes')
    end_directory(handle, cacheToDisc=not is_external)
    set_view_mode('view.episodes', 'episodes', is_external)


def indian(params):
    cache_name = 'content_indian'
    list_data = None
    list_data = main_cache.get(cache_name)

    if not list_data:
        uri = f'{get_git_url()}/indian_live.json'
        data = request(uri)
        list_data = loads(data)
        if list_data: main_cache.set(cache_name, list_data, expiration=168) # 7days
    # logger(f'total: {len(list_data)} list_data: {list_data}')
    selective = [{'title': 'Fox 5 Atlanta (WAGA)', 'url': 'https://live-news-manifest.tubi.video/live-news-manifest/csm/extlive/tubiprd01,WAGA.m3u8', 'poster': 'https://i.imgur.com/qdYfhpZ.jpg', 'action': 'ltp_pluto'}, {'title': 'LiveNOW from FOX (720p)', 'url': 'https://lnc-fox-live-now.tubi.video/index.m3u8', 'action': 'ltp_pluto'}, {'title': 'Fox Weather', 'url': 'https://csm-e-eb.csm.tubi.video/csm/extlive/tubiprd01,Fox-Weather.m3u8', 'action': 'ltp_pluto'}, {'title': 'Fox Weather', 'url': 'https://live-news-manifest.tubi.video/live-news-manifest/csm/extlive/tubiprd01,Fox-Weather.m3u8', 'action': 'ltp_pluto'}, {'title': 'Fox Weather', 'url': 'https://247wlive.foxweather.com/stream/index.m3u8', 'poster': 'https://i.imgur.com/ojLdgOg.png', 'action': 'ltp_pluto'}]
    flist_data = selective + list_data
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_external = external()
    add_items(handle, list(_process(flist_data, 'indian')))
    set_content(handle, 'episodes')
    set_category(handle, 'episodes')
    end_directory(handle, cacheToDisc=not is_external)
    set_view_mode('view.episodes', 'episodes', is_external)


def _process(list_data, provider):
    for i in list_data:
        # logger(f'lists _process item: {item}')
        listitem = make_listitem()
        title = i['title']
        poster = i.get('poster', '')
        thumb = poster if poster.startswith('http') else addon_icon
        url_params = {'mode': i['action'], 'title': title, 'url': i['url'], 'provider': provider}
        url = build_url(url_params)
        options_params = {'mode': 'options_menu_choice', 'suggestion': title, 'play_params': dumps(url_params)}
        cm = [('[B]Options...[/B]', f'RunPlugin({build_url(options_params)})')]
        listitem.setLabel(title)
        listitem.addContextMenuItems(cm)
        listitem.setArt({'thumb': thumb})
        i.update({'imdb_id': title, 'mediatype': 'episode', 'episode': 1, 'season': 0})
        listitem = set_info(listitem, i, {'imdb': str(title)})
        yield url, listitem, False
    return


def play(params):
    # logger(f'play params {params}')
    url = params['url']
    try:
        info = {'title': params['title']}
        if params['provider'] == 'daddy':
            ourl = resolv_daddy_stream(url)
            info = {'title': params['title'], 'use_inputstream': 'not use_inputstream'}
        elif params['provider'] == 'tvapp': ourl = resolv_theapp_stream(url)
        elif params['provider'] == 'youtube': ourl = get_m3u8_url(url)
        elif params['provider'] == 'pluto' and 'm3u8' in url: ourl = f'{url}|User-Agent={agent()}&Referer={url}'
        elif params['provider'] == 'crick_live': ourl = url
        else: ourl = f'{url}|User-Agent={agent()}' #url = f'{url}|User-Agent={agent()}&Upgrade-Insecure-Requests=1'
        logger(f'--- Playing title: {params["title"]}  url: {ourl} info: {info}')
        if ourl is None: return notification(f'No links Found for: :{params["title"]} Retry')
        from modules.player import infinitePlayer
        infinitePlayer().run(ourl, 'video', info)
    except:
        logger(f'play provider: {params["provider"]} - Exception: {print_exc()}')
        return


def get_videoId(from_func, response):
    vars_ = re.compile(r'var ytInitialData =.*?[\'|"|{](.+)[\'|"|}][,;]</script>').findall(response)
    # logger(f'vars_>>> : {vars_}')
    ytInitialData = str(vars_[0])
    # logger(f'ytInitialData: {ytInitialData}')
    # logger(f'ytInitialData: {string_escape(vars_[0])}')
    return re.findall(r'(compactvideoRenderer|videoRenderer)\":\{\"videoId\":\"(.+?)\",', ytInitialData, re.IGNORECASE,)


def get_m3u8_url(url):
    # logger(f'get_m3u8_url url: {url}')
    furl = None
    if 'https://www.youtube.com/channel' in url: response = request(url)
    else: response = request(f'{url}/videos')
    # logger(response)
    videoIds = get_videoId('get_m3u8_url', response)
    videoId_counter = 0
    for videoId in videoIds:
        furl = None
        videoId_counter += 1
        live_yturl = f'https://www.youtube.com/watch?v={videoId[1]}'
        # logger(f'live_yturl: {live_yturl}')
        response = request(live_yturl)
        # logger(f'<<<--->>> \n{response}\n<<<--->>>')
        if '.m3u8' in response:
            # logger(f'get_m3u8_url response: {response}')
            furl = extract_m3u8(response)
            if furl: break
    logger(f'Total videoId: {len(videoIds)} get link from videoId_counter: {videoId_counter} from: {url}')
    return furl or None


def extract_m3u8(response, m3u8_extension='.m3u8', https_prefix='https://', tuner_increment=5, initial_tuner=200):
    end = response.find(m3u8_extension)
    if end == -1: raise ValueError('No .m3u8 found in the response')
    end += len(m3u8_extension)
    tuner = initial_tuner
    # logger(f'extract_m3u8 tuner: {tuner} end: {end}')

    while True:
        # logger(f'extract_m3u8 response[{end - tuner}: {end}]')
        potential_link = response[end - tuner: end]
        if https_prefix in potential_link:
            link = potential_link
            start = link.find(https_prefix)
            end = link.find(m3u8_extension) + len(m3u8_extension)
            break
        else: tuner += tuner_increment
    logger(f'extract_m3u8 length of links: {len(link[start: end])}')
    # logger(f'extract_m3u8  type: {type(link)} length of links: {len(link[start: end])}  : repr {repr(link)} : {link[start: end]}')
    return link[start: end]


UA = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0'


def channels():
    url = f'{baseurl}/24-7-channels.php'
    do_adult = False  #xbmcaddon.Addon().getSetting('adult_pw')
    hea = {'Referer': f'{baseurl}/', 'user-agent': UA}
    resp = request(url, headers=hea)
    # logger(f'resp: {resp}')
    ch_block = re.compile('<center><h1(.+?)tab-2', re.MULTILINE | re.DOTALL).findall(str(resp))
    chan_data = re.compile('href=\"(.*)\" target(.*)<strong>(.*)</strong>').findall(str(ch_block[0]))
    # logger(f'chan_data: {chan_data}')
    channels = []
    for item in chan_data:
        try:
            url, title = str(item[0]), str(item[2])
            if any(x in title for x in chnnel_filter): continue
            # logger(f'item: {repr(item)}')
            url_params = {'title': title, 'url': url, 'action': 'ltp_pluto'}
            if "18+" not in title: channels.append(url_params)
            if do_adult and "18+" in title: channels.append(url_params)
        except: logger(f'item: {repr(item)} error: {print_exc()}')
    # logger(f'channels: {channels}')
    return channels


def resolv_daddy_stream(link):
    url = f'{baseurl}{link}'
    hea = {'Referer': f'{baseurl}/', 'user-agent': UA}
    resp = request(url, headers=hea)
    url_1 = re.compile('iframe src="(.*)" width').findall(resp)[0]
    hea = {'Referer': url, 'user-agent': UA, }
    # logger(f'play provider url_1: {url_1}')
    resp = request(url_1, headers=hea)
    # logger(f'play provider resp: {resp}')
    stream = re.compile('source:\'(.*)\'').findall(resp)
    # logger(f'play provider resp: {stream}')
    links = [x for x in stream if '.m3u8?auth=' in x]
    if len(links) > 1:
        list_items = [{'line1': 'url Type:  ' + i} for i in links]
        kwargs = {'items': dumps(list_items), 'heading': 'Select source to play.', 'narrow_window': 'true'}
        link = select_dialog(links, **kwargs)
    else: link = links[0]
    referer = f'{urlparse(url_1).scheme}://{(urlparse(url_1).netloc or urlparse(url_1).link)}'
    return f'{link}|Referer={referer}/&Origin={referer}&Keep-Alive=true&User-Agent={UA}'


def daddy(params):
    cache_name = 'content_daddy'
    list_data = main_cache.get(cache_name)
    if not list_data:
        list_data = channels()
        if list_data: main_cache.set(cache_name, list_data, expiration=168)
    from sys import argv
    handle = int(argv[1])
    is_external = external()
    if list_data:
        add_items(handle, list(_process(list_data, 'daddy')))
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.episodes', 'episodes', is_external)
    else:
        notification('No links Found for: : daddy Retry')
        end_directory(handle)
        return


def channels_tvapp():
    url = f'{tvappurl}/tv'
    hea = {'user-agent': UA, }
    resp = request(url, headers=hea, verify=False)
    # logger(f'resp: {resp}')
    html = parseDOM(resp, 'ol', attrs={'class': "list.*?"})[0]#.replace('<span>', '').replace('</span>', '').replace('\n', '').replace('  ', '').replace('@', ' @')
    chan_data = re.findall('href\s*=\s*"([^"]+)"\s*class.*?>([^<]+)<\/a>', html, re.DOTALL)

    channels = []
    for url, title in chan_data:
        try:
            url = url[:-1] if url.endswith('/') else url
            url = url.replace('/tv/', '')
            # href = f'https://thetvapp.to{url}' if url.startswith('/') else url
            if any(x in title for x in chnnel_filter): continue
            # logger(f'item: {repr(item)}')
            url_params = {'title': title.replace('&amp;', '&'), 'url': url, 'action': 'ltp_pluto'}
            channels.append(url_params)
        except: logger(f'chan_data: {repr(chan_data)} error: {print_exc()}')
    # logger(f'channels: {channels}')
    return channels


def tvapp(params):
    cache_name = 'content_tvapp'
    list_data = main_cache.get(cache_name)
    if not list_data:
        list_data = channels_tvapp()
        if list_data: main_cache.set(cache_name, list_data, expiration=168)
    from sys import argv
    handle = int(argv[1])
    is_external = external()
    if list_data:
        add_items(handle, list(_process(list_data, 'tvapp')))
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.episodes', 'episodes', is_external)
    else:
        notification('No links Found for: : tvapp Retry')
        end_directory(handle)
        return


def resolv_theapp_stream(id_):
    stream_url = ''
    # id_ = re.findall('tv\/(.+?)$', url, re.DOTALL)
    # id_ = id_[0] if id_ else ''
    # if id_: id_ = id_[:-1] if id_.endswith('/') else id_
    # url_api = b64decode(''.join(chr(int(c)) for c in '118O0O107O0O71O0O99O0O104O0O57O0O67O0O99O0O119O0O70O0O109O0O76O0O115O0O86O0O50O0O89O0O121O0O86O0O109O0O100O0O117O0O119O0O87O0O89O0O108O0O82O0O88O0O76O0O121O0O86O0O71O0O90O0O117O0O86O0O72O0O97O0O48O0O82O0O88O0O97O0O105O0O74O0O87O0O89O0O121O0O57O0O121O0O76O0O54O0O77O0O72O0O99O0O48O0O82O0O72O0O97'.split('O0O'))[::-1]).decode('utf-8')
    url_api = 'https://rabbitthunder-teal.vercel.app/api/mzc'
    ft = {'id': id_}

    response = request(url_api, post=ft, verify=False)
    if 'source":"' in response:
        stream_url = re.findall('source"\:"([^"]+)"', response, re.DOTALL+re.I)[0]
        headersx = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0', 'Accept': '*/*', 'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3', 'Origin': 'https://thetvapp.to', 'DNT': '1', 'Referer': 'https://thetvapp.to/', 'Sec-Fetch-Dest': 'empty', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'same-site',}
        stream_url = f'{stream_url}|{urlencode(headersx)}'
    return stream_url
