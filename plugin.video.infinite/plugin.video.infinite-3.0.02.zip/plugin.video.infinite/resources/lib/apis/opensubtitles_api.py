# -*- coding: utf-8 -*-
import shutil
from zipfile import ZipFile
from caches.main_cache import main_cache
from modules.kodi_utils import requests, json, notification, sleep, delete_file, rename_file, quote, logger

user_agent = 'infinite v0.1'

class OpenSubtitlesAPI:
	def __init__(self):
		self.headers = {'User-Agent': user_agent}

	def search(self, query, imdb_id, language, season=None, episode=None):
		cache_name = f'opensubtitles_{imdb_id}_{language}'
		if season: cache_name += f'_{season}_{episode}'
		if cache := main_cache.get(cache_name): return cache
		url = f'https://rest.opensubtitles.org/search/imdbid-{imdb_id}/query-{quote(query)}{f"/season-{season}/episode-{episode}" if season else ""}/sublanguageid-{language}'
		response = self._get(url, retry=True)
		if not response: return logger(f'Error OpenSubtitlesAPI search url: {url}')
		response = json.loads(response.text)
		main_cache.set(cache_name, response, 48)
		return response

	def download(self, url, filepath, temp_zip, temp_path, final_path):
		result = self._get(url, stream=True, retry=True)
		with open(temp_zip, 'wb') as f: shutil.copyfileobj(result.raw, f)
		with ZipFile(temp_zip, 'r') as zip_file: zip_file.extractall(filepath)
		delete_file(temp_zip)
		rename_file(temp_path, final_path)
		return final_path

	def _get(self, url, stream=False, retry=False):
		response = requests.get(url, headers=self.headers, stream=stream)
		if '200' in str(response): return response
		elif '429' in str(response) and retry:
			notification('OpenSubtitles Rate Limited. Retrying in 10 secs..', 3500)
			sleep(10000)
			return self._get(url, stream)
		else: return
