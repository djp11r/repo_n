# -*- coding: utf-8 -*-
from caches.settings_cache import get_setting, set_setting
from modules import kodi_utils
# logger = kodi_utils.logger

translate_path, get_property = kodi_utils.translate_path, kodi_utils.get_property
download_directories_dict = {'movie': 'infinite.movie_download_directory', 'episode': 'infinite.tvshow_download_directory', 'thumb_url': 'infinite.image_download_directory',
							'image_url': 'infinite.image_download_directory','image': 'infinite.image_download_directory', 'premium': 'infinite.premium_download_directory',
							None: 'infinite.premium_download_directory', 'None': False}
results_window_numbers_dict = {'List': 2000, 'Rows': 2001, 'WideList': 2002}
default_action_dict = {'0': 'play', '1': 'cancel', '2': 'pause'}
extras_open_action_dict = {'movie': (1, 3), 'tvshow': (2, 3)}
paginate_dict = {True: 'infinite.paginate.limit_widgets', False: 'infinite.paginate.limit_addon'}
nextep_sort_key_dict = {0: 'last_played', 1: 'first_aired', 2: 'name'}
prescrape_scrapers_tuple = ('easynews', 'rd_cloud', 'pm_cloud', 'ad_cloud', 'folders')
sort_to_top_dict = {'folders': 'infinite.results.sort_folders_first', 'rd_cloud': 'infinite.results.sort_rdcloud_first',
					'pm_cloud': 'infinite.results.sort_pmcloud_first', 'ad_cloud': 'infinite.results.sort_adcloud_first'}
internal_scrapers_clouds_list = [('rd', 'provider.rd_cloud'), ('pm', 'provider.pm_cloud'), ('ad', 'provider.ad_cloud')]

def tmdb_api_key():
	return get_setting('infinite.tmdb_api', '')

def trakt_client():
	return get_setting('infinite.trakt.client', '')

def trakt_secret():
	return get_setting('infinite.trakt.secret', '')

def results_format():
	window_format = str(get_setting('infinite.results.list_format', 'List'))
	if not window_format in results_window_numbers_dict:
		window_format = 'List'
		set_setting('results.list_format', window_format)
	window_number = results_window_numbers_dict[window_format]
	return window_format.lower(), window_number

def store_resolved_to_cloud(debrid_service, pack):
	setting_value = int(get_setting('infinite.store_resolved_to_cloud.%s' % debrid_service.lower(), '0'))
	return setting_value in (1, 2) if pack else setting_value == 1

def enabled_debrids_check(debrid_service):
	if not get_setting('infinite.%s.enabled' % debrid_service) == 'true': return False
	return authorized_debrid_check(debrid_service)

def authorized_debrid_check(debrid_service):
	if get_setting('infinite.%s.token' % debrid_service) in (None, '', 'empty_setting'): return False
	return True

def playback_settings():
	return (int(get_setting('infinite.playback.watched_percent', '90')), int(get_setting('infinite.playback.resume_percent', '5')))

def limit_resolve():
	return get_setting('infinite.playback.limit_resolve', 'false') == 'true'

def movies_directory():
	return translate_path(get_setting('infinite.movies_directory'))

def tv_show_directory():
	return translate_path(get_setting('infinite.tv_shows_directory'))

def download_directory(media_type=None):
	return translate_path(get_setting(download_directories_dict[media_type]))

def auto_start_infinite():
	return get_setting('infinite.auto_start_infinite', 'false') == 'true'

def source_folders_directory(media_type, source):
	setting = f'infinite.{source}.movies_directory' if media_type == 'movie' else f'infinite.{source}.tv_shows_directory'
	if get_setting(setting) not in ('', 'None', None): return translate_path( get_setting(setting))
	else: return False

def paginate(is_home):
	paginate_lists = int(get_setting('infinite.paginate.lists', '0'))
	return paginate_lists in (2, 3) if is_home else paginate_lists in (1, 3)

def page_limit(is_home):
	return int(get_setting(paginate_dict[is_home], '20'))

def quality_filter(setting):
	return get_setting(f'infinite.{setting}').split(', ')

def audio_filters():
	setting = get_setting('infinite.filter_audio')
	return [] if setting in ('empty_setting', '') else setting.split(', ')

def include_prerelease_results():
	return get_setting('infinite.include_prerelease_results', 'true') == 'true'

def auto_play(media_type):
	return get_setting(f'infinite.auto_play_{media_type}', 'false') == 'true'

def autoplay_next_episode():
	return bool(auto_play('episode') and get_setting('infinite.autoplay_next_episode', 'false') == 'true')

def autoscrape_next_episode():
	if not auto_play('episode') and get_setting('infinite.autoscrape_next_episode', 'false') == 'true': return True
	else: return False

def auto_rescrape_with_all():
	return int(get_setting('infinite.results.auto_rescrape_with_all', '0'))

def auto_nextep_settings(play_type):
	play_type = 'autoplay' if play_type == 'autoplay_nextep' else 'autoscrape'
	window_percentage = 100 - int(get_setting('infinite.%s_next_window_percentage' % play_type, '95'))
	use_chapters = get_setting('infinite.%s_use_chapters' % play_type, 'true') == 'true'
	scraper_time = int(get_setting('infinite.results.timeout', '60')) + 90
	if play_type == 'autoplay':
		alert_method = int(get_setting('fenlight.autoplay_alert_method', '0'))
		default_action = default_action_dict[get_setting('infinite.autoplay_default_action', '1')]
	else: alert_method, default_action = '', ''
	return {'scraper_time': scraper_time, 'window_percentage': window_percentage, 'alert_method': alert_method, 'default_action': default_action, 'use_chapters': use_chapters}

def filter_status(filter_type):
	return int(get_setting(f'infinite.filter_{filter_type}', '0'))

def ignore_results_filter():
	return int(get_setting('infinite.results.ignore_filter', '0'))

def trakt_sync_interval():
	setting = get_setting('infinite.trakt.sync_interval', '25')
	interval = int(setting) * 60
	return setting, interval

def lists_sort_order(setting):
	return int(get_setting(f'infinite.sort.{setting}', '0'))

def auto_start():
	return get_setting('infinite.auto_start', 'false') == 'true'

def use_minimal_media_info():
	return get_setting('infinite.use_minimal_media_info', 'true') == 'true'

def single_ep_display_format(is_external):
	if is_external: setting, default = 'infinite.single_ep_display_widget', '1'
	else: setting, default = 'infinite.single_ep_display', ''
	return int(get_setting(setting, default))

def easynews_active():
	if get_setting('infinite.provider.easynews', 'false') == 'true': easynews_status = easynews_authorized()
	else: easynews_status = False
	return easynews_status

def easynews_authorized():
	easynews_user = get_setting('infinite.easynews_user', 'empty_setting')
	easynews_password = get_setting('infinite.easynews_password', 'empty_setting')
	if easynews_user in ('empty_setting', '') or easynews_password in ('empty_setting', ''): easynews_status = False
	else: easynews_status = True
	return easynews_status

def extras_enable_extra_ratings():
	return get_setting('infinite.extras.enable_extra_ratings', 'true') == 'true'

def extras_enable_scrollbars():
	return get_setting('infinite.extras.enable_scrollbars', 'true')

def extras_enabled_menus():
	setting = get_setting('infinite.extras.enabled', '2000,2050,2051,2052,2053,2054,2055,2056,2057,2058,2059,2060,2061,2062')
	if setting in ('', None, 'noop', []): return []
	return [int(i) for i in setting.split(',')]

def check_prescrape_sources(scraper, media_type):
	if scraper in prescrape_scrapers_tuple: return get_setting(f'infinite.check.{scraper}') == 'true'
	if get_setting(f'infinite.check.{scraper}') == 'true' and auto_play(media_type): return True
	else: return False

def external_scraper_info():
	module = get_setting('infinite.external_scraper.module')
	if module in ('empty_setting', ''): return None, ''
	return module, module.split('.')[-1]

def filter_by_name(scraper):
	if get_property('fs_filterless_search') == 'true': return False
	return get_setting(f'infinite.{scraper}.title_filter', 'false') == 'true'

def easynews_language_filter():
	enabled = get_setting('infinite.easynews.filter_lang') == 'true'
	filters = get_setting('infinite.easynews.lang_filters').split(', ') if enabled else []
	return enabled, filters

def results_sort_order():
	return (
			lambda k: (k['quality_rank'], k['provider_rank'], -k['size']), #Quality, Provider, Size
			lambda k: (k['quality_rank'], -k['size'], k['provider_rank']), #Quality, Size, Provider
			lambda k: (k['provider_rank'], k['quality_rank'], -k['size']), #Provider, Quality, Size
			lambda k: (k['provider_rank'], -k['size'], k['quality_rank']), #Provider, Size, Quality
			lambda k: (-k['size'], k['quality_rank'], k['provider_rank']), #Size, Quality, Provider
			lambda k: (-k['size'], k['provider_rank'], k['quality_rank'])  #Size, Provider, Quality
			)[int(get_setting('infinite.results.sort_order', '1'))]

def active_internal_scrapers():
	settings = ['provider.external', 'provider.folders']
	# settings_append = settings.append
	# for item in internal_scrapers_clouds_list:
		# if enabled_debrids_check(item[0]): settings_append(item[1])
	return [i.split('.')[1] for i in settings if get_setting(f'infinite.{i}') == 'true']

def provider_sort_ranks():
	return {'folders': 0, 'gdrive': 1, 'external': 2}

def sort_to_top(provider):
	return get_setting(sort_to_top_dict[provider]) == 'true'

def auto_resume(media_type):
	auto_resume = get_setting(f'infinite.auto_resume_{media_type}')
	if auto_resume == '1': return True
	return bool(auto_resume == '2' and auto_play(media_type))

def scraping_settings():
	highlight_type = int(get_setting('infinite.highlight.type', '0'))
	if highlight_type == 2:
		highlight = get_setting('infinite.scraper_single_highlight', 'FF008EB2')
		return {'highlight_type': 1, '4k': highlight, '1080p': highlight, '720p': highlight, 'sd': highlight}
	easynews_highlight, debrid_cloud_highlight, folders_highlight = '', '', ''
	rd_highlight, pm_highlight, ad_highlight, highlight_4K, highlight_1080P, highlight_720P, highlight_SD = '', '', '', '', '', '', ''
	if highlight_type == 0:
		easynews_highlight = get_setting('infinite.provider.easynews_highlight', 'FF00B3B2')
		debrid_cloud_highlight = get_setting('infinite.provider.debrid_cloud_highlight', 'FF7A01CC')
		folders_highlight = get_setting('infinite.provider.folders_highlight', 'FFB36B00')
		rd_highlight = get_setting('infinite.provider.rd_highlight', 'FF3C9900')
		pm_highlight = get_setting('infinite.provider.pm_highlight', 'FFFF3300')
		ad_highlight = get_setting('infinite.provider.ad_highlight', 'FFE6B800')
	else:
		highlight_4K = get_setting('infinite.scraper_4k_highlight', 'FFFF3334')
		highlight_1080P = get_setting('infinite.scraper_1080p_highlight', 'FFE6B800')
		highlight_720P = get_setting('infinite.scraper_720p_highlight', 'FF3C9900')
		highlight_SD = get_setting('infinite.scraper_SD_highlight', 'FFCAFFFF')
	return {'highlight_type': highlight_type,'real-debrid': rd_highlight, 'premiumize': pm_highlight, 'alldebrid': ad_highlight, 'rd_cloud': debrid_cloud_highlight,
			'pm_cloud': debrid_cloud_highlight, 'ad_cloud': debrid_cloud_highlight, 'easynews': easynews_highlight, 'folders': folders_highlight,
			'4k': highlight_4K, '1080p': highlight_1080P, '720p': highlight_720P, 'sd': highlight_SD}

def omdb_api_key():
	return get_setting('infinite.omdb_api', 'dd7e2fc7')

def default_all_episodes():
	return int(get_setting('infinite.default_all_episodes', '0'))

def get_meta_filter():
	return get_setting('infinite.meta_filter', 'true')

def widget_hide_next_page():
	return get_setting('infinite.widget_hide_next_page', 'false') == 'true'

def widget_hide_watched():
	return get_setting('infinite.widget_hide_watched', 'false') == 'true'

def calendar_sort_order():
	return int(get_setting('infinite.trakt.calendar_sort_order', '0'))

def date_offset():
	return int(get_setting('infinite.datetime.offset', '0')) + 5

def extras_open_action(media_type):
	return int(get_setting('infinite.extras.open_action', '0')) in extras_open_action_dict[media_type]

def watched_indicators():
	if get_setting('infinite.trakt.user') in ('empty_setting', ''): return 0
	return int(get_setting('infinite.watched_indicators', '0'))

def nextep_method():
	return int(get_setting('infinite.nextep.method', '0'))

def nextep_limit_history():
	return get_setting('infinite.nextep.limit_history', 'false') == 'true'

def nextep_limit():
	return int(get_setting('infinite.nextep.limit', '20'))

def nextep_include_unwatched():
	return int(get_setting('infinite.nextep.include_unwatched', '0'))

def nextep_include_airdate():
	return get_setting('infinite.nextep.include_airdate', 'false') == 'true'

def nextep_airing_today():
	return get_setting('infinite.nextep.airing_today', 'false') == 'true'

def nextep_include_unaired():
	return get_setting('infinite.nextep.include_unaired', 'false') == 'true'

def nextep_sort_key():
	return nextep_sort_key_dict[int(get_setting('infinite.nextep.sort_type', '0'))]

def nextep_sort_direction():
	return int(get_setting('infinite.nextep.sort_order', '0')) == 0

def update_delay():
	return int(get_setting('infinite.update.delay', '45'))

def update_action():
	return int(get_setting('infinite.update.action', '2'))

def update_use_test_repo():
	return get_setting('infinite.update.use_test_repo', 'true') == 'true'



def get_folderscraper_info(media_type='movie', all_avilable=False):
	if all_avilable:
		folder_info = [(get_setting(f'infinite.{i}.display_name'), i, source_folders_directory('movie', i)) for i in ('folder1', 'folder2', 'folder3', 'folder4', 'folder5')]
		folder_info += [(get_setting(f'infinite.{i}.display_name'), i, source_folders_directory('tv_shows', i)) for i in ('folder1', 'folder2', 'folder3', 'folder4', 'folder5')]
	else: folder_info = [(get_setting(f'infinite.{i}.display_name'), i, source_folders_directory(media_type, i)) for i in ('folder1', 'folder2', 'folder3', 'folder4', 'folder5')]
	return [i for i in folder_info if i[0] not in (None, 'None', '') and i[2]], [i[0] for i in folder_info if i[2]]

def get_source_sorting_list():
	return get_setting('infinite.source_sorting').split(', ')

def get_source_filter_by_size(vid_type, duration):
	from modules.utils import string_to_float
	# logger(f'get_source_filter_by_size results.filter_size_method: {repr(get_setting("results.filter_size_method"))}')
	if get_setting('infinite.results.filter_size_method') == '2': max_size = string_to_float(get_setting(f'infinite.results.{vid_type}_size_max'), '2500')/1000
	else: max_size = ((0.125 * (0.90 * string_to_float(get_setting('infinite.results.line_speed', '20'), '20'))) * duration)/1000
	return max_size

def get_git_url():
	return get_setting('infinite.git_url')

def get_use_inputstream():
	return get_setting('infinite.use_inputstream') == 'true'

def get_sub_settings():
	auto_enable = get_setting('infinite.subtitles.auto_enable')
	subs_action = get_setting('infinite.subtitles.subs_action')
	language = get_setting('infinite.subtitles.language_primary_name')
	audio_preference = get_setting('infinite.audio.preference', 'false') == 'true'
	secondary_language = get_setting('infinite.subtitles.language_secondary_name')
	return {'auto_enable': auto_enable, 'subs_action': subs_action, 'language': language,
			'audio_preference': audio_preference, 'secondary_language': secondary_language}