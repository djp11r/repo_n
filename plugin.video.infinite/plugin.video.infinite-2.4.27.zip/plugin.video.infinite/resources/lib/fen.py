# -*- coding: utf-8 -*-
from sys import argv
from modules.router import routing
# from modules.kodi_utils import logger
# logger(f'Args: |{repr(argv)}|')
routing(argv[2])
