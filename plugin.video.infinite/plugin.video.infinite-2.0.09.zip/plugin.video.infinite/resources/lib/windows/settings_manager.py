# -*- coding: utf-8 -*-
from windows.base_window import BaseDialog
from caches.settings_cache import settings_cache
from modules.fen_online_utils import single_sync
from modules.kodi_utils import get_infolabel
# from modules.kodi_utils import logger

class SettingsManager(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.menu_focus, self.submenu_focus = kwargs.get('menu_focus', 0), kwargs.get('submenu_focus', None)

	def onInit(self):
		self.set_delayed_position_focus(2000, int(self.menu_focus), render_delay=25)
		if self.submenu_focus: self.set_delayed_position_focus(2100, int(self.submenu_focus), render_delay=25)

	@single_sync('settings_db', 'settings')
	def run(self):
		start_list = self.get_all_settings()
		self.doModal()
		self.clearProperties()
		return self.settings_check(start_list)

	def onAction(self, action):
		if action in self.closing_actions: return self.close()
		if action in self.context_actions:
			setting_id = get_infolabel('ListItem.Property(setting_id)')
			if not setting_id: return
			from caches.settings_cache import set_default
			set_default(setting_id)

	def get_all_settings(self):
		return settings_cache.get_all(return_dict=False)

	def settings_check(self, start_list):
		end_list = self.get_all_settings()
		if start_list != end_list: return True
		return None

class SettingsManagerFolders(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)

	def run(self):
		self.doModal()
		self.clearProperties()
