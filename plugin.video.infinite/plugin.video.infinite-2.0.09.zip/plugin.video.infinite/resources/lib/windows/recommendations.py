# -*- coding: utf-8 -*-
from windows.base_window import BaseDialog
from modules.meta_lists import recommendations_list, recommendations_refinement_modifiers, recommendation_invalid_critical
# from modules.kodi_utils import logger

class Recommendations(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.category_id = 2000
		self.sub_category_id = 2100
		self.button_ids = (10, 11, 12, 13, 14)
		self.selection = None
		self.last_selected_category = 'Current Mood & Energy'
		self.all_recommendation = recommendations_list()
		self.set_properties()

	def set_properties(self):
		self.setProperty('origin_pane', str(self.category_id))
		self.setProperty('refinement_id', '0')
		self.setProperty('position_id', '0')

	def onInit(self):
		self.make_category_menu()
		self.make_subcategory_menu()
		self.setFocusId(self.category_id)
	
	def run(self):
		self.doModal()
		self.clearProperties()
		return self.selection

	def onAction(self, action):
		if action in self.closing_actions: return self.close()
		focus_id = self.getFocusId()
		if focus_id in self.button_ids: return
		if focus_id == self.category_id:
			selected_category = self.get_listitem(self.category_id).getProperty('label')
			if selected_category != self.last_selected_category:
				self.last_selected_category = selected_category
				self.reset_window(self.sub_category_id)
				self.make_subcategory_menu(selected_category)
		elif action in self.selection_actions:
				chosen_item = self.get_listitem(self.sub_category_id)
				self.make_selection(chosen_item)
				self.close()

	def make_selection(self, chosen_item):
		selected_category, selected_subcategory = chosen_item.getProperty('selected_category'), chosen_item.getProperty('selected_subcategory')
		self.selection = self.all_recommendation[selected_category][selected_subcategory]
		self.selection['sub_category'] = selected_subcategory
		invalid_refinements = recommendation_invalid_critical()
		refinement_id = int(self.getProperty('refinement_id'))
		if refinement_id in invalid_refinements.get(selected_subcategory, []): refinement_id = 0
		self.selection['refinement_id'] = refinement_id
		self.selection['description'] = self.selection['description'] + recommendations_refinement_modifiers()[refinement_id]

	def make_category_menu(self):
		def builder():
			for item in self.all_recommendation:
				listitem = self.make_listitem()
				listitem.setProperty('label', item)
				yield listitem
		item_list = list(builder())
		self.add_items(self.category_id, item_list)

	def make_subcategory_menu(self, selected_category='Current Mood & Energy'):
		def builder():
			for c, (k, v) in enumerate(category_data.items()):
				listitem = self.make_listitem()
				listitem.setProperties({'label': '[B]••• %s •••[/B]' % k, 'description': v['description'], 'selected_category': selected_category,
										'selected_subcategory': k, 'position': c})
				yield listitem
		category_data = self.all_recommendation.get(selected_category)
		item_list = list(builder())
		self.add_items(self.sub_category_id, item_list)

