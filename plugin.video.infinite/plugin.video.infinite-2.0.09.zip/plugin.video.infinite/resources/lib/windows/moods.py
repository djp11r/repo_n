# -*- coding: utf-8 -*-
from windows.base_window import BaseDialog
from modules.meta_lists import moods, mood_colors
# from modules.kodi_utils import logger

class Moods(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.category_id = 2000
		self.sub_category_id = 2100
		self.selection = None
		self.last_selected_category = 'Restless & Hyperactive'
		self.all_moods = moods()
		self.mood_colors = mood_colors()

	def onInit(self):
		self.make_category_menu()
		self.make_subcategory_menu()
		self.setFocusId(self.category_id)
	
	def run(self):
		self.doModal()
		self.clearProperties()
		return self.selection

	def onAction(self, action):
		if action in self.closing_actions: return self.close()
		focus_id = self.getFocusId()
		if focus_id == self.category_id:
			selected_category = self.get_listitem(self.category_id).getProperty('label')
			if selected_category != self.last_selected_category:
				self.last_selected_category = selected_category
				self.reset_window(self.sub_category_id)
				self.make_subcategory_menu(selected_category)
		else:
			if action in self.selection_actions:
				chosen_item = self.get_listitem(self.sub_category_id)
				selected_category, selected_subcategory = chosen_item.getProperty('selected_category'), chosen_item.getProperty('selected_subcategory')
				self.selection = self.all_moods[selected_category][selected_subcategory]
				self.selection['sub_category'] = selected_subcategory
				self.close()

	def make_category_menu(self):
		def builder():
			for item in self.all_moods:
				listitem = self.make_listitem()
				listitem.setProperty('label', item)
				listitem.setProperty('category_color', self.mood_colors.get(item))
				yield listitem
		item_list = list(builder())
		self.add_items(self.category_id, item_list)

	def make_subcategory_menu(self, selected_category='Restless & Hyperactive'):
		def builder():
			for k, v in category_data.items():
				listitem = self.make_listitem()
				bobble = '[COLOR %s]•••[/COLOR]' % category_color
				listitem.setProperties({'label': '[B]%s %s %s[/B]' % (bobble, k, bobble), 'description': v['description'], 'category_color': category_color,
										'selected_category': selected_category, 'selected_subcategory': k})
				yield listitem
		category_data = self.all_moods.get(selected_category)
		category_color = self.mood_colors.get(selected_category)
		item_list = list(builder())
		self.add_items(self.sub_category_id, item_list)

