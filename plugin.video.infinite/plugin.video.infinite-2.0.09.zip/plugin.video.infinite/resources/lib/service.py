# -*- coding: utf-8 -*-

from modules import kodi_utils
from modules.service import MainMonitor


if __name__ == '__main__':
	with MainMonitor() as omain:
		while not omain.monitor.abortRequested():
			if omain.monitor.waitForAbort(1):
				break
	kodi_utils.logger('Main Monitor Service Finished')
