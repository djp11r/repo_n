# -*- coding: utf-8 -*-
import sys
from traceback import print_exc
from urllib.parse import unquote
from caches.navigator_cache import navigator_cache as nc
from caches.settings_cache import get_setting, set_setting
from modules.watched_status import get_recently_watched
from modules.utils import years_list
from modules.kodi_utils import logger, translate_path as tp, build_url, notification, addon, make_listitem, list_dirs, add_item, set_content, end_directory, set_view_mode, add_items, get_infolabel, set_sort_method, set_category, container_refresh_input, current_window_object, close_all_dialog, sleep, home, get_property, set_property, get_icon, container_refresh, get_addon_fanart, external
from modules.settings import download_directory, trakt_user_active, get_folderscraper_info, recommend_service, tmdblist_user_active
from modules.meta_lists import movie_certifications, tvshow_certifications, languages as languages_list, decades_, networks as networks_list, watch_providers_movies, watch_providers_tvshows, movie_genres, tvshow_genres
from caches.main_cache import main_cache


class Navigator:
	def __init__(self, params):
		self.params = params
		self.params_get = self.params.get
		self.category_name = self.params_get('name', 'infinite')
		self.list_name = self.params_get('action', 'RootList')
		self.is_external = external()
		self.make_listitem = make_listitem
		self.build_url = build_url
		self.add_item = add_item
		self.get_icon = get_icon
		self.fanart = get_addon_fanart()
		self.run_plugin = 'RunPlugin(%s)'
		self.trakt_active = trakt_user_active()
		self.testing = get_setting('infinite.testing') == 'true'

	def main(self):
		def _process():
			for count, item in enumerate(browse_list):
				try:
					url = self.build_url(item)
					icon = item.get('iconImage', '')
					if not icon.startswith('http'):
						icon = self.get_icon(icon)
						item['iconImage'] = icon
					listitem = self.make_listitem()
					listitem.setLabel(item.get('name', ''))
					listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': self.fanart, 'banner': icon, 'landscape': icon})
					info_tag = listitem.getVideoInfoTag(True)
					info_tag.setPlot(' ')
					if not self.is_external:
						cm_items = [
						('[B]Move[/B]', self.run_plugin % self.build_url({'mode': 'menu_editor.move', 'active_list': self.list_name, 'position': count})),
						('[B]Remove[/B]', self.run_plugin % self.build_url({'mode': 'menu_editor.remove', 'active_list': self.list_name, 'position': count})),
						('[B]Add Content[/B]', self.run_plugin % self.build_url({'mode': 'menu_editor.add', 'active_list': self.list_name, 'position': count})),
						('[B]Restore Menu[/B]', self.run_plugin % self.build_url({'mode': 'menu_editor.restore', 'active_list': self.list_name, 'position': count})),
						('[B]Check for New Menu Items[/B]', self.run_plugin % self.build_url({'mode': 'menu_editor.update', 'active_list': self.list_name, 'position': count})),
						('[B]Reload Menu[/B]', self.run_plugin % self.build_url({'mode': 'menu_editor.reload', 'active_list': self.list_name, 'position': count})),
						('[B]Browse Removed items[/B]', self.run_plugin % self.build_url({'mode': 'menu_editor.browse', 'active_list': self.list_name, 'position': count})),
						('[B]Add to Shortcut Folder[/B]', self.run_plugin % self.build_url({'mode': 'menu_editor.shortcut_folder_add_known', 'url': url}))]
						listitem.addContextMenuItems(cm_items)
					yield ((url, listitem, True), count)
				except: logger(f'error: {print_exc()}')
		if self.params_get('full_list', 'false') == 'true': browse_list = nc.get_main_lists(self.list_name)[0]
		else: browse_list = nc.currently_used_list(self.list_name)
		# logger(f'browse_list1: type: {type(browse_list)} {len(browse_list)} {browse_list}')
		if not self.trakt_active: browse_list = list(filter(lambda d: 'Next Episodes' not in d.values(), browse_list))
		if self.testing: browse_list = [{'name': 'Test', 'mode': 'testhindi', 'isFolder': 'false', 'iconImage': 'infinite'}] + browse_list
		results = sorted(list(_process()), key=lambda k: k[1])
		add_items(int(sys.argv[1]), [i[0] for i in results])
		self.end_directory()

	def my_lists(self):
		if get_setting('tmdb.account_id') not in ('', None): self.add({'mode': 'navigator.tmdb_lists_personal'}, 'TMDb Lists', 'tmdb')
		self.add({'mode': 'personal_lists.get_personal_lists'}, 'Personal Lists', 'lists')
		if self.trakt_active: self.add({'mode': 'navigator.trakt_lists_personal'}, 'Trakt private Lists', 'trakt')
		self.add({'mode': 'navigator.folder_navigator', 'action': 'browse'}, 'Sources Folders', 'folder_green')
		self.add({'mode': 'navigator.discover'}, 'Discover', 'discover')
		self.add({'mode': 'navigator.favorites'}, 'Favorites', 'favorites')
		self.add({'mode': 'navigator.shortcut_folders'}, 'Shortcut Folders', 'folder')
		self.add({'mode': 'navigator.trakt_lists_public'}, 'Trakt Public Lists', 'trakt')
		self.add({'mode': 'navigator.random_lists'}, 'Random Lists', 'random')
		self.add({'mode': 'navigator.people'}, 'People', 'people')
		self.add({'mode': 'navigator.downloads'}, 'Downloads', 'downloads')
		if get_setting('imdb_user') not in ('0', None): self.add({'mode': 'build_imdb_list', 'name': 'My Lists'}, 'IMDb Lists', 'imdb')
		self.end_directory()

	def favorites(self):
		self.add({'mode': 'build_movie_list', 'action': 'favorites_movies', 'name': 'Movies'}, 'Movies', 'movies')
		self.add({'mode': 'build_tvshow_list', 'action': 'favorites_tvshows', 'name': 'TV Shows'}, 'TV Shows', 'tv')
		self.add({'mode': 'favorite_people_list_image_results', 'isFolder': 'false', 'name': 'People'}, 'People', 'genre_family')
		self.end_directory()

	def trakt_lists_public(self):
		self.add({'mode': 'trakt.list.get_trakt_user_lists', 'list_type': 'trending', 'list_mode': 'personal', 'category_name': 'Trending User Lists'}, 'Trending User Lists', 'trending_recent')
		self.add({'mode': 'trakt.list.get_trakt_user_lists', 'list_type': 'popular', 'list_mode': 'personal', 'category_name': 'Popular User Lists'}, 'Popular User Lists', 'trakt')
		self.add({'mode': 'trakt.list.get_trakt_user_lists', 'list_type': 'trending', 'list_mode': 'official', 'category_name': 'Trending Official Lists'},
				'Trending Official Lists', 'trakt')
		self.add({'mode': 'trakt.list.get_trakt_user_lists', 'list_type': 'popular', 'list_mode': 'official', 'category_name': 'Popular Official Lists'},
				'Popular Official Lists', 'trakt')
		self.add({'mode': 'navigator.search_history', 'action': 'trakt_lists'}, 'Search User Lists', 'search')
		self.end_directory()

	def discover(self):
		self.add({'mode': 'navigator.discover_contents', 'media_type': 'movie'}, 'Movies', 'movies')
		self.add({'mode': 'navigator.discover_contents', 'media_type': 'tvshow'}, 'TV Shows', 'tv')
		self.end_directory()

	def random_lists(self):
		self.add({'mode': 'navigator.build_random_lists', 'menu_type': 'movie'}, 'Random Movie Lists', 'movies')
		self.add({'mode': 'navigator.build_random_lists', 'menu_type': 'tvshow'}, 'Random TV Show Lists', 'tv')
		self.add({'mode': 'navigator.build_random_lists', 'menu_type': 'because_you_watched'}, 'Random Because You Watched', 'because_you_watched')
		if tmdblist_user_active(): self.add({'mode': 'navigator.build_random_lists', 'menu_type': 'tmdb_lists'}, 'Random TMDb Lists', 'tmdb')
		self.add({'mode': 'navigator.build_random_lists', 'menu_type': 'personal_lists'}, 'Random Personal Lists', 'lists')
		if self.trakt_active:
			self.add({'mode': 'navigator.build_random_lists', 'menu_type': 'trakt_personal'}, 'Random Trakt Lists (Personal)', 'trakt')
			self.add({'mode': 'navigator.build_random_lists', 'menu_type': 'trakt_public'}, 'Random Trakt Lists (Public)', 'trakt')
		self.end_directory()

	def people(self):
		self.add({'mode': 'tmdb_people_list_image_results', 'action': 'popular', 'isFolder': 'false', 'name': 'Popular'}, 'Popular', 'popular')
		self.add({'mode': 'tmdb_people_list_image_results', 'action': 'day', 'isFolder': 'false', 'name': 'Trending'}, 'Trending', 'trending')
		self.add({'mode': 'tmdb_people_list_image_results', 'action': 'week', 'isFolder': 'false', 'name': 'Trending This Week'}, 'Trending This Week', 'trending_recent')
		self.end_directory()

	def search(self):
		self.add({'mode': 'navigator.search_history', 'action': 'movie', 'name': 'Search History Movies'}, 'Search Movies', 'search_movie')
		self.add({'mode': 'navigator.search_history', 'action': 'tvshow', 'name': 'Search History TV Shows'}, 'Search TV Shows', 'search_tv')
		self.add({'mode': 'navigator.search_history', 'action': 'people', 'name': 'Search History People'}, 'Search People', 'search_people')
		self.add({'mode': 'navigator.search_history', 'action': 'tmdb_keyword_movie', 'name': 'Search History Keywords (Movies)'}, 'Search Keywords (Movies)', 'search_tmdb')
		self.add({'mode': 'navigator.search_history', 'action': 'tmdb_keyword_tvshow', 'name': 'Search History Keywords (TV Shows)'}, 'Search Keywords (TV Shows)', 'search_tmdb')
		self.add({'mode': 'navigator.search_history', 'action': 'trakt_lists'}, 'Search Trakt User Lists', 'search_trakt_lists')
		self.end_directory()

	def downloads(self):
		self.add({'mode': 'downloader.manager', 'name': 'Download Manager', 'isFolder': 'false'}, 'Download Manager', 'downloads')
		self.add({'mode': 'downloader.viewer', 'folder_type': 'movie', 'name': 'Movies'}, 'Movies', 'movies')
		self.add({'mode': 'downloader.viewer', 'folder_type': 'episode', 'name': 'TV Shows'}, 'TV Shows', 'tv')
		self.add({'mode': 'browser_image', 'folder_path': download_directory('image'), 'isFolder': 'false'}, 'Images', 'people')
		self.end_directory()

	def tools(self):
		self.add({'mode': 'open_settings', 'isFolder': 'false'}, 'Settings', 'settings')
		self.add({'mode': 'navigator.log_utils'}, 'Changelog & Log Utils', 'settings2')
		self.add({'mode': 'navigator.data_sync_manager'}, 'Data Sync Utilities', 'backup')
		self.add({'mode': 'navigator.maintenance'}, 'Database & Cache Maintenance', 'settings2')
		self.add({'mode': 'build_next_episode_manager'}, 'TV Shows Progress Manager', 'settings2')
		self.add({'mode': 'navigator.shortcut_folders'}, 'Shortcut Folders Manager', 'settings2')
		self.add({'mode': 'navigator.set_view_modes'}, 'Set Views', 'settings2')
		# self.add({'mode': 'navigator.update_utils'}, 'Update Utilities', 'settings2')
		self.add({'mode': 'language_invoker_choice', 'isFolder': 'false'}, 'Toggle Language Invoker (ADVANCED!!)', 'settings2')
		if get_setting('infinite.external_scraper.module') not in ('empty_setting', ''): self.add({'mode': 'external_scraper_settings', 'addon': 'script.module.openscrapers', 'isFolder': 'false'}, 'External Scraper Settings', 'settings')
		self.end_directory()

	def settings_manager(self):
		self.add({'mode': 'open_settings', 'isFolder': 'false'}, 'Open Settings', 'settings')
		self.add({'mode': 'sync_settings', 'silent': 'false', 'isFolder': 'false'}, 'Remake Settings Cache', 'settings')
		self.end_directory()

	def data_sync_manager(self):
		self.add({'mode': 'data_sync_manager.full_sync', 'silent': 'false', 'isFolder': 'false'}, 'Force Data Sync', 'backup')
		self.add({'mode': 'data_sync_manager.full_import', 'silent': 'false', 'isFolder': 'false'}, 'Force Data Import', 'backup')
		self.add({'mode': 'data_sync_manager.full_export', 'silent': 'false', 'isFolder': 'false'}, 'Force Data Export', 'backup')
		self.end_directory()

	def maintenance(self):
		self.add({'mode': 'check_databases_integrity_cache', 'isFolder': 'false'}, 'Check for Corrupt Databases', 'settings')
		self.add({'mode': 'clear_cache', 'cache': 'trakt', 'isFolder': 'false'}, 'Clear Trakt Cache', 'settings')
		self.add({'mode': 'sync_settings', 'silent': 'false', 'isFolder': 'false'}, 'Remake Settings Cache', 'settings')
		self.add({'mode': 'clear_cache', 'cache': 'external_scrapers', 'isFolder': 'false'}, 'Clear External Scrapers Cache', 'settings')
		self.add({'mode': 'clean_databases_cache', 'isFolder': 'false'}, 'Clean Databases', 'settings')
		self.add({'mode': 'sync_settings', 'silent': 'false', 'isFolder': 'false'}, 'Remake Settings Cache', 'settings')
		self.add({'mode': 'clear_all_cache', 'isFolder': 'false'}, 'Clear All Cache (Excluding Favorites)', 'settings')
		self.add({'mode': 'clear_favorites_choice', 'isFolder': 'false'}, 'Clear Favorites Cache', 'settings')
		self.add({'mode': 'search.clear_search', 'isFolder': 'false'}, 'Clear Search History Cache', 'settings')
		self.add({'mode': 'clear_cache', 'cache': 'main', 'isFolder': 'false'}, 'Clear Main Cache', 'settings')
		self.add({'mode': 'clear_cache', 'cache': 'meta', 'isFolder': 'false'}, 'Clear Meta Cache', 'settings')
		self.add({'mode': 'clear_cache', 'cache': 'list', 'isFolder': 'false'}, 'Clear Lists Cache', 'settings')
		self.add({'mode': 'clear_cache', 'cache': 'ai_functions', 'isFolder': 'false'}, 'Clear AI Data Cache', 'settings')
		self.add({'mode': 'clear_cache', 'cache': 'tmdb_list', 'isFolder': 'false'}, 'Clear TMDb Personal List Cache', 'settings')
		self.add({'mode': 'clear_cache', 'cache': 'imdb', 'isFolder': 'false'}, 'Clear IMDb Cache', 'settings')
		self.add({'mode': 'clear_cache', 'cache': 'internal_scrapers', 'isFolder': 'false'}, 'Clear Internal Scrapers Cache', 'settings')
		self.add({'mode': 'clear_cache', 'cache': 'folders', 'isFolder': 'false'}, 'Clear Folder Scraper', 'settings')
		self.add({'mode': 'clear_cache', 'cache': 'local_bookmark', 'isFolder': 'false'}, 'Clear Local Bookmark', 'settings2')
		self.add({'mode': 'clear_cache', 'cache': 'h_list', 'isFolder': 'false'}, 'Clear All Hindi Lists', 'settings2')
		self.add({'mode': 'clear_cache', 'cache': 'h_content', 'isFolder': 'false'}, 'Clear Hindi content', 'settings2')
		self.add({'mode': 'clear_cache', 'cache': 'h_shows', 'isFolder': 'false'}, 'Clear Hindi shows', 'settings2')
		self.add({'mode': 'clear_cache', 'cache': 'h_episodes', 'isFolder': 'false'}, 'Clear Hindi episodes', 'settings2')
		self.add({'mode': 'clear_cache', 'cache': 'h_movies', 'isFolder': 'false'}, 'Clear Hindi movies', 'settings2')
		self.add({'mode': 'clear_cache', 'cache': 'h_meta', 'isFolder': 'false'}, 'Clear Hindi Meta', 'settings2')
		self.add({'mode': 'clear_cache', 'cache': 'external_scrapers_statistics', 'isFolder': 'false'}, 'Clear Providers statistics', 'settings2')
		self.end_directory()

	def set_view_modes(self):
		self.add({'mode': 'navigator.choose_view', 'view_type': 'view.main', 'content': '', 'name': 'menus'}, 'Set Menus', 'folder')
		self.add({'mode': 'navigator.choose_view', 'view_type': 'view.movies', 'content': 'movies'}, 'Set Movies', 'movies')
		self.add({'mode': 'navigator.choose_view', 'view_type': 'view.tvshows', 'content': 'tvshows'}, 'Set TV Shows', 'tv')
		self.add({'mode': 'navigator.choose_view', 'view_type': 'view.seasons', 'content': 'seasons'}, 'Set Seasons', 'ontheair')
		self.add({'mode': 'navigator.choose_view', 'view_type': 'view.episodes', 'content': 'episodes'}, 'Set Episodes', 'next_episodes')
		self.add({'mode': 'navigator.choose_view', 'view_type': 'view.episodes_single', 'content': 'episodes', 'name': 'episode lists'}, 'Set Episode Lists', 'calender')
		self.add({'mode': 'navigator.choose_view', 'view_type': 'view.premium', 'content': 'files', 'name': 'premium files'}, 'Set Premium Files', 'premium')
		self.end_directory()

	def update_utils(self):
		self.add({'mode': 'updater.update_check', 'isFolder': 'false'}, 'Check For Updates', 'github')
		# self.add({'mode': 'updater.rollback_check', 'isFolder': 'false'}, 'Rollback to a Previous Version', 'github')
		self.add({'mode': 'updater.get_changes', 'isFolder': 'false'}, 'Check Online Version Changelog', 'github')
		self.end_directory()

	def log_utils(self):
		infinite_clogpath, log_loc, old_log_loc = tp('special://home/addons/plugin.video.infinite/resources/text/changelog.txt'), tp('special://logpath/kodi.log'), tp('special://logpath/kodi.old.log')
		self.add({'mode': 'show_text', 'heading': 'Kodi Log Viewer', 'file': log_loc, 'kodi_log': 'true', 'isFolder': 'false'}, 'Kodi Log Viewer', 'lists')
		self.add({'mode': 'navigator.tips'}, 'Tips for Use', 'settings2')
		self.add({'mode': 'show_text', 'heading': 'Changelog', 'file': infinite_clogpath, 'font_size': 'large', 'isFolder': 'false'}, 'Changelog', 'lists')
		self.add({'mode': 'show_text', 'heading': 'Kodi Log Viewer (Old)', 'file': old_log_loc, 'kodi_log': 'true', 'isFolder': 'false'}, 'Kodi Log Viewer (Old)', 'lists')
		self.add({'mode': 'upload_logfile', 'isFolder': 'false'}, 'Upload Kodi Log to Pastebin', 'lists')
		self.end_directory()

	def certifications(self):
		menu_type = self.params_get('menu_type')
		if menu_type == 'movie': mode, action, certifications = 'build_movie_list', 'tmdb_movies_certifications', movie_certifications()
		else: mode, action, certifications = 'build_tvshow_list', 'trakt_tv_certifications', tvshow_certifications()
		for i in certifications: self.add({'mode': mode, 'action': action, 'key_id': i['id'], 'name': i['name']}, i['name'], 'certifications')
		self.end_directory()

	def languages(self):
		menu_type = self.params_get('menu_type')
		if menu_type == 'movie': mode, action = 'build_movie_list', 'tmdb_movies_languages'
		else: mode, action = 'build_tvshow_list', 'tmdb_tv_languages'
		for i in languages_list(): self.add({'mode': mode, 'action': action, 'key_id': i['id'], 'name': i['name']}, i['name'], 'languages')
		self.end_directory()

	def years(self):
		menu_type = self.params_get('menu_type')
		if menu_type == 'movie': mode, action, years = 'build_movie_list', 'tmdb_movies_year', years_list()
		else: mode, action, years = 'build_tvshow_list', 'tmdb_tv_year', years_list()
		for i in years: self.add({'mode': mode, 'action': action, 'key_id': i, 'name': str(i)}, str(i), 'calender')
		self.end_directory()

	def genres(self):
		menu_type = self.params_get('menu_type')
		if menu_type == 'movie': genre_list, mode, action = movie_genres(), 'build_movie_list', 'tmdb_movies_genres'
		else: genre_list, mode, action = tvshow_genres(), 'build_tvshow_list', 'tmdb_tv_genres'
		for i in genre_list: self.add({'mode': mode, 'action': action, 'key_id': i['id'], 'name': i['name']}, i['name'], i['icon'])
		self.end_directory()

	def search_history(self):
		search_mode_dict = {
		'movie': ('movie_queries', {'mode': 'search.get_key_id', 'media_type': 'movie', 'isFolder': 'false'}),
		'tvshow': ('tvshow_queries', {'mode': 'search.get_key_id', 'media_type': 'tv_show', 'isFolder': 'false'}),
		'people': ('people_queries', {'mode': 'search.get_key_id', 'search_type': 'people', 'isFolder': 'false'}),
		'tmdb_keyword_movie': ('keyword_tmdb_movie_queries', {'mode': 'search.get_key_id', 'search_type': 'tmdb_keyword', 'media_type': 'movie', 'isFolder': 'false'}),
		'tmdb_keyword_tvshow': ('keyword_tmdb_tvshow_queries', {'mode': 'search.get_key_id', 'search_type': 'tmdb_keyword', 'media_type': 'tvshow', 'isFolder': 'false'}),
		'easynews_video': ('easynews_video_queries', {'mode': 'search.get_key_id', 'search_type': 'easynews_video', 'isFolder': 'false'}),
		'easynews_image': ('easynews_image_queries', {'mode': 'search.get_key_id', 'search_type': 'easynews_image', 'isFolder': 'false'}),
		'trakt_lists': ('trakt_list_queries', {'mode': 'search.get_key_id', 'search_type': 'trakt_lists', 'isFolder': 'false'})}
		setting_id, action_dict = search_mode_dict[self.list_name]
		url_params = dict(action_dict)
		data = main_cache.get(setting_id) or []
		self.add(action_dict, '[B]NEW SEARCH...[/B]', 'search_new')
		for i in data:
			try:
				key_id = unquote(i)
				url_params['key_id'] = key_id
				url_params['setting_id'] = setting_id
				cm_items = [('[B]Remove from history[/B]', self.run_plugin % self.build_url({'mode': 'search.remove', 'setting_id':setting_id, 'key_id': key_id})),
							('[B]Clear All History[/B]', self.run_plugin % self.build_url({'mode': 'search.clear_all', 'setting_id':setting_id, 'refresh': 'true'}))]
				self.add(url_params, key_id, 'search_history', cm_items=cm_items)
			except: pass
		self.category_name = self.params_get('name') or 'History'
		self.end_directory()

	def keyword_results(self):
		from apis.tmdb_api import tmdb_keywords_by_query
		media_type, key_id = self.params_get('media_type'), self.params_get('key_id') or self.params_get('query')
		try: page_no = int(self.params_get('new_page', '1'))
		except: page_no = self.params_get('new_page')
		mode = 'build_movie_list' if media_type == 'movie' else 'build_tvshow_list'
		action = 'tmdb_movie_keyword_results' if media_type == 'movie' else 'tmdb_tv_keyword_results'
		data = tmdb_keywords_by_query(key_id, page_no)
		for item in data['results']:
			name = item['name'].upper()
			self.add({'mode': mode, 'action': action, 'key_id': item['id'], 'iconImage': 'tmdb', 'category_name': name}, name, iconImage='tmdb')
		if data['total_pages'] > page_no:
			new_page = {'mode': 'navigator.keyword_results', 'key_id': key_id, 'category_name': self.category_name, 'new_page': str(data['page'] + 1)}
			self.add(new_page, 'Next Page (%s) >>' % new_page['new_page'], 'nextpage', False)
		self.category_name = 'Search Results for %s' % key_id.upper()
		self.end_directory()

	def choose_view(self):
		handle = int(sys.argv[1])
		content = self.params['content']
		view_type, name = self.params['view_type'], self.params.get('name') or content
		self.add({'mode': 'navigator.set_view', 'view_type': view_type, 'name': name, 'isFolder': 'false'}, 'Set view and then click here', 'settings')
		set_content(handle, content)
		end_directory(handle)
		set_view_mode(view_type, content, False)

	def set_view(self):
		set_setting(self.params['view_type'], str(current_window_object().getFocusId()))
		notification('%s: %s' % (self.params['name'].upper(), get_infolabel('Container.Viewmode').upper()))

	def shortcut_folders(self):
		folders = nc.get_shortcut_folders()
		if folders:
			for i in folders:
				name = i[0]
				convert_sr = '[B]Remove Random[/B]' if '[COLOR red][RANDOM][/COLOR]' in name else '[B]Make Random[/B]'
				cm_items = [('[B]Rename[/B]', self.run_plugin % self.build_url({'mode': 'menu_editor.shortcut_folder_rename'})),
							('[B]Delete Shortcut Folder[/B]' , self.run_plugin % self.build_url({'mode': 'menu_editor.shortcut_folder_delete'})),
							('[B]Make New Shortcut Folder[/B]' , self.run_plugin % self.build_url({'mode': 'menu_editor.shortcut_folder_make'})),
							(convert_sr , self.run_plugin % self.build_url({'mode': 'menu_editor.shortcut_folder_convert', 'name': name}))]
				self.add({'mode': 'navigator.build_shortcut_folder_contents', 'name': name, 'iconImage': 'folder'}, name, 'folder', cm_items=cm_items)
		else: self.add({'mode': 'menu_editor.shortcut_folder_make', 'isFolder': 'false'}, '[I]Make New Shortcut Folder...[/I]', 'new')
		self.category_name = 'Shortcut Folders'
		self.end_directory()

	def build_shortcut_folder_contents(self):
		list_name = self.params_get('name')
		is_random = '[COLOR red][RANDOM][/COLOR]' in list_name
		contents = nc.get_shortcut_folder_contents(list_name)
		if is_random:
			from indexers.random_lists import random_shortcut_folders
			return random_shortcut_folders(list_name.replace(' [COLOR red][RANDOM][/COLOR]', ''), contents)
		if contents:
			for count, item in enumerate(contents):
				item_get = item.get
				iconImage = item_get('iconImage', None)
				if iconImage: icon, original_image = iconImage, True if iconImage.startswith('http') else False
				else: icon, original_image = 'folder', False
				cm_items = [
				('[B]Move[/B]', self.run_plugin % self.build_url({'mode': 'menu_editor.shortcut_folder_edit', 'active_list': list_name, 'position': count, 'action': 'move'})),
				('[B]Remove[/B]' , self.run_plugin % self.build_url({'mode': 'menu_editor.shortcut_folder_edit', 'active_list': list_name, 'position': count, 'action': 'remove'})),
				('[B]Add Content[/B]' , self.run_plugin % self.build_url({'mode': 'menu_editor.shortcut_folder_add', 'name': list_name})),
				('[B]Rename[/B]' , self.run_plugin % self.build_url({'mode': 'menu_editor.shortcut_folder_edit', 'active_list': list_name, 'position': count, 'action': 'rename'})),
				('[B]Clear All[/B]' , self.run_plugin % self.build_url({'mode': 'menu_editor.shortcut_folder_edit', 'active_list': list_name, 'position': count, 'action': 'clear'}))]
				self.add(item, item_get('name'), icon, original_image, cm_items=cm_items)
		elif is_random: pass
		else: self.add({'mode': 'menu_editor.shortcut_folder_add', 'name': list_name, 'isFolder': 'false'}, '[I]Add Content...[/I]', 'new')
		self.end_directory()

	def discover_contents(self):
		from caches.discover_cache import discover_cache
		action, media_type = self.params_get('action', ''), self.params_get('media_type')
		if not action:
			if self.params_get('show_new', 'true') == 'true':
				self.add({'mode': 'discover_choice', 'media_type': media_type, 'isFolder': 'false'}, '[I]Make New Discover List...[/I]', 'new')
			results = discover_cache.get_all(media_type)
			if media_type == 'movie': mode, action = 'build_movie_list', 'tmdb_movies_discover'
			else: mode, action = 'build_tvshow_list', 'tmdb_tv_discover'
			for item in results:
				name, data = item['id'], item['data']
				cm_items = [('[B]Remove from history[/B]', self.run_plugin % self.build_url({'mode': 'navigator.discover_contents', 'action':'delete_one', 'name': name})),
							('[B]Clear All History[/B]', self.run_plugin % self.build_url({'mode': 'navigator.discover_contents', 'action':'clear_cache', 'media_type': media_type}))]
				if '[random]' in data:
					self.add({'mode': 'random.%s' % mode, 'action': action, 'name': name, 'url': data, 'new_page': 'random', 'random': 'true'},
								name, 'discover', cm_items=cm_items)
				else: self.add({'mode': mode, 'action': action, 'name': name, 'url': data}, name, 'discover', cm_items=cm_items)
			self.end_directory()
		else:
			if action == 'delete_one': discover_cache.delete_one(self.params_get('name'))
			elif action == 'clear_cache': discover_cache.clear_cache(media_type)
			container_refresh()

	def exit_media_menu(self):
		params = get_property('infinite.exit_params')
		if params: return container_refresh_input(params)

	def tmdb_watchlists(self):
		self.category_name = 'Watchlist'
		self.add({'mode': 'tmdblist.build_tmdb_list', 'list_id': 'watchlist', 'media_type': 'movie', 'list_name': 'Movie Watchlist'}, 'Movies Watchlist', 'tmdb')
		self.add({'mode': 'tmdblist.build_tmdb_list', 'list_id': 'watchlist', 'media_type': 'tv', 'list_name': 'TV Show Watchlist'}, 'TV Shows Watchlist', 'tmdb')
		self.end_directory()

	def tmdb_favorites(self):
		self.category_name = 'Favorites'
		self.add({'mode': 'tmdblist.build_tmdb_list', 'list_id': 'favorites', 'media_type': 'movie', 'list_name': 'Movie Favorites'}, 'Movie Favorites', 'tmdb')
		self.add({'mode': 'tmdblist.build_tmdb_list', 'list_id': 'favorites', 'media_type': 'tv', 'list_name': 'TV Show Favorites'}, 'TV Show Favorites', 'tmdb')
		self.end_directory()

	def tmdb_recommendations(self):
		self.category_name = 'Recommendations'
		self.add({'mode': 'tmdblist.build_tmdb_list', 'list_id': 'recommendations', 'media_type': 'movie', 'list_name': 'Movie Recommendations'}, 'Movie Recommendations', 'tmdb')
		self.add({'mode': 'tmdblist.build_tmdb_list', 'list_id': 'recommendations', 'media_type': 'tv', 'list_name': 'TV Show Recommendations'}, 'TV Show Recommendations', 'tmdb')
		self.end_directory()

	def tmdb_lists_personal(self):
		self.add({'mode': 'navigator.tmdb_watchlists'}, 'Watchlist', 'tmdb')
		self.add({'mode': 'navigator.tmdb_favorites'}, 'Favorites', 'tmdb')
		self.add({'mode': 'navigator.tmdb_recommendations'}, 'Recommendations', 'tmdb')
		self.add({'mode': 'tmdblist.get_tmdb_lists'}, 'My Lists', 'tmdb')
		self.end_directory()

	def trakt_lists_personal(self):
		self.add({'mode': 'navigator.trakt_collections'}, 'Collection', 'traktcollection')
		self.add({'mode': 'navigator.trakt_watchlists'}, 'Watchlist', 'traktwatchlist')
		self.add({'mode': 'trakt.list.get_trakt_lists', 'list_type': 'my_lists', 'category_name': 'My Lists'}, 'My Lists', 'traktmylists')
		self.add({'mode': 'trakt.list.get_trakt_lists', 'list_type': 'liked_lists', 'category_name': 'Liked Lists'}, 'Liked Lists', 'traktlikedlists')
		self.add({'mode': 'navigator.trakt_favorites', 'category_name': 'Favorites'}, 'Favorites', 'trakt')
		self.add({'mode': 'navigator.trakt_recommendations', 'category_name': 'Recommended'}, 'Recommended', 'traktrecommendations')
		self.add({'mode': 'build_my_calendar'}, 'Calendar', 'traktcalendar')
		self.end_directory()

	def decades(self):
		menu_type = self.params_get('menu_type')
		if menu_type == 'movie': mode, action, decades = 'build_movie_list', 'tmdb_movies_decade', decades_()
		else: mode, action, decades = 'build_tvshow_list', 'tmdb_tv_decade', decades_()
		for i in decades: self.add({'mode': mode, 'action': action, 'key_id': i['id'], 'name': i['name']}, i['name'], 'calendar_decades')
		self.end_directory()

	def networks(self):
		menu_type = self.params_get('menu_type')
		if menu_type == 'movie': return
		for i in sorted(networks_list(), key=lambda k: k['name']): self.add({'mode': 'build_tvshow_list', 'action': 'tmdb_tv_networks', 'key_id': i['id'], 'name': i['name']}, i['name'],
																		self.get_icon(i['logo'], 'network_icons'), original_image=True)
		self.end_directory()

	def providers(self):
		menu_type = self.params_get('menu_type')
		tmdb_img = 'https://image.tmdb.org/t/p/original/%s'
		if menu_type == 'movie': mode, action, function = 'build_movie_list', 'tmdb_movies_providers', watch_providers_movies()
		else: mode, action, function = 'build_tvshow_list', 'tmdb_tv_providers', watch_providers_tvshows()
		for i in function: self.add({'mode': mode, 'action': action, 'key_id': i['id'], 'name': i['name']}, i['name'], tmdb_img % i['logo'], original_image=True)
		self.end_directory()

	def trakt_collections(self):
		self.category_name = 'Collection'
		self.add({'mode': 'build_movie_list', 'action': 'trakt_collection', 'category_name': 'Movies Collection'}, 'Movies Collection', 'traktcollection')
		self.add({'mode': 'build_tvshow_list', 'action': 'trakt_collection', 'category_name': 'TV Shows Collection'}, 'TV Shows Collection', 'traktcollection')
		self.add({'mode': 'build_movie_list', 'action': 'trakt_collection_lists', 'new_page': 'recent', 'category_name': 'Recently Added Movies'}, 'Recently Added Movies', 'traktcollection')
		self.add({'mode': 'build_tvshow_list', 'action': 'trakt_collection_lists', 'new_page': 'recent', 'category_name': 'Recently Added TV Shows'}, 'Recently Added TV Shows', 'traktcollection')
		self.add({'mode': 'build_my_calendar', 'recently_aired': 'true'}, 'Recently Aired Episodes', 'traktcalendar')
		self.end_directory()

	def trakt_watchlists(self):
		self.category_name = 'Watchlist'
		self.add({'mode': 'build_movie_list', 'action': 'trakt_watchlist', 'category_name': 'Movies Watchlist'}, 'Movies Watchlist', 'traktwatchlist')
		self.add({'mode': 'build_tvshow_list', 'action': 'trakt_watchlist', 'category_name': 'TV Shows Watchlist'}, 'TV Shows Watchlist', 'traktwatchlist')
		self.add({'mode': 'build_movie_list', 'action': 'trakt_watchlist_lists', 'new_page': 'recent', 'category_name': 'Recently Added Movies'}, 'Recently Added Movies', 'traktwatchlist')
		self.add({'mode': 'build_tvshow_list', 'action': 'trakt_watchlist_lists', 'new_page': 'recent', 'category_name': 'Recently Added TV Shows'},
					'Recently Added TV Shows', 'traktwatchlist')
		self.end_directory()

	def trakt_recommendations(self):
		self.category_name = 'Recommended'
		self.add({'mode': 'build_movie_list', 'action': 'trakt_recommendations', 'category_name': 'Recommended Movies'}, 'Movies Recommended', 'traktrecommendations')
		self.add({'mode': 'build_tvshow_list', 'action': 'trakt_recommendations', 'category_name': 'Recommended TV Shows'}, 'TV Shows Recommended', 'traktrecommendations')
		self.end_directory()

	def trakt_favorites(self):
		self.category_name = 'Favorites'
		self.add({'mode': 'build_movie_list', 'action': 'trakt_favorites', 'category_name': 'Favorite Movies'}, 'Movies', 'trakt')
		self.add({'mode': 'build_tvshow_list', 'action': 'trakt_favorites', 'category_name': 'Favorite TV Shows'}, 'TV Shows', 'trakt')
		self.end_directory()

	def tips(self):
		tips_location = 'special://home/addons/plugin.video.infinite/resources/text/tips'
		files = sorted(list_dirs(tips_location)[1])
		tips_location += '/%s'
		tips_list = []
		tips_append = tips_list.append
		for item in files:
			tip = item.replace('.txt', '')[4:]
			if '!!HELP!!' in tip: tip, sort_order = tip.replace('!!HELP!!', '[COLOR crimson][B]HELP!!![/B][/COLOR] '), 0
			elif '!!NEW!!' in tip: tip, sort_order = tip.replace('!!NEW!!', '[COLOR chartreuse][B]NEW!![/B][/COLOR] '), 1
			elif '!!SPOTLIGHT!!' in tip: tip, sort_order = tip.replace('!!SPOTLIGHT!!', '[COLOR orange][B]SPOTLIGHT![/B][/COLOR] '), 2
			else: sort_order = 3
			params = {'mode': 'show_text', 'heading': tip, 'file': tp(tips_location % item), 'font_size': 'large', 'isFolder': 'false'}
			tips_append((params, tip, sort_order))
		item_list = sorted(tips_list, key=lambda x: x[2])
		for c, i in enumerate(item_list, 1): self.add(i[0], '[B]%02d. [/B]%s' % (c, i[1]), 'information')
		self.end_directory()

	def because_you_watched(self):
		recommend_type = recommend_service()
		from modules.episode_tools import single_last_watched_episodes
		menu_type = self.params_get('menu_type')
		action_dict = {'movie':
		{'mode': 'build_movie_list', 'action': {0: 'tmdb_movies_recommendations', 1: 'imdb_more_like_this', 2: 'ai_similar', 3: 'trakt_movies_related'}, 'media_type': 'movie'},
						'tvshow':
		{'mode': 'build_tvshow_list', 'action': {0: 'tmdb_tv_recommendations', 1: 'imdb_more_like_this', 2: 'ai_similar', 3: 'trakt_tv_related'}, 'media_type': 'episode'}}
		action_params = action_dict[menu_type]
		mode, action, media_type = action_params['mode'], action_params['action'][recommend_type], action_params['media_type']
		recently_watched = get_recently_watched(media_type)
		if media_type == 'episode': recently_watched = single_last_watched_episodes(recently_watched)
		for item in recently_watched:
			if media_type == 'movie':
				name = item['title']
				key_id = item['media_id'] if recommend_type in (0, 1, 3) else 'movie|%s' % item['media_id']
			else:
				name = '%s - %sx%s' % (item['title'], str(item['season']), str(item['episode']))
				key_id = item['media_ids']['tmdb'] if recommend_type in (0, 1, 3) else 'tvshow|%s' % item['media_ids']['tmdb']
			params = {'mode': mode, 'action': action, 'key_id': key_id, 'name': 'Because You Watched %s' % name}
			if recommend_type == 1: params['get_imdb'] = 'true'
			self.add(params, name, 'because_you_watched')
		self.end_directory()

	def folder_navigator(self):
		def _process():
			for info in results:
				try:
					name = info[2].split('/')[-3:-1]
					fname = ' '.join(name)
					listitem = make_listitem()
					listitem.addContextMenuItems([])
					listitem.setLabel(fname)
					listitem.setArt({'icon': self.get_icon('folder_green'), 'fanart': self.fanart})
					info_tag = listitem.getVideoInfoTag()
					info_tag.setPlot(' ')
					yield (info[2], listitem, True)
				except: pass
		results, items_name = get_folderscraper_info(all_avilable=True)
		item_list = list(_process())
		handle = int(sys.argv[1])
		add_items(handle, item_list)
		set_sort_method(handle, 'files')
		self.end_directory()
		set_view_mode('view.main', '')

	def vod_movies(self):
		self.add({'url': '/movies/', 'mode': 'vod_movies', 'pg_no': '1', 'list_name': 'hindi'}, 'Hindi Movies', iconImage='h_movies')
		self.add({'url': '/category/gujarati/', 'mode': 'vod_movies', 'pg_no': '1', 'list_name': 'gujarati'}, 'Gujarati Movies', iconImage='h_movies')
		self.add({'mode': 'geetm', 'list_name': 'geetmala'}, 'Geet Mala', iconImage='h_movies')
		self.add({'mode': 'bi_main', 'list_name': 'tubi'}, 'Tubi TV', iconImage='tubi')
		self.add({'mode': 'ltv', 'list_name': 'youtube'}, 'Youtube Stream', iconImage='utube')
		self.add({'mode': 'watchonline', 'list_name': 'watchol'}, 'Watchonline', iconImage='tv')
		self.add({'mode': 'ltv', 'list_name': 'indianlive'}, 'Indian Channels', iconImage='h_icon')
		self.add({'mode': 'ltv', 'list_name': 'pluto'}, 'Pluto TV', iconImage='pluto')
		self.add({'mode': 'docu', 'list_name': 'docu'}, 'Top Documentary', iconImage='genre_documentary')
		self.add({'mode': 'ltv', 'list_name': 'theapp'}, 'Channels theapp', iconImage='live')
		self.add({'mode': 'ltv', 'list_name': 'ddevent'}, 'Channels dd event', iconImage='live')
		self.add({'mode': 'ltv', 'list_name': 'daddy'}, 'Channels dd live', iconImage='live')
		self.end_directory()

	def vod_hindi(self):
		_links = eval(get_setting('infinite.urls'))
		_link, _link1, _link2, _link3 = _links.get('desiserials'), _links.get('playdesi'), _links.get('yodesi'), _links.get('desirulez')
		self.add({'url': [f'{_link2}/sab-tv', f'{_link}/sab-tv-hd', f'{_link3}/sab-tv'], 'mode': 'vod_shows', 'list_name': 'Sab TV'}, 'Sab TV', iconImage='sony_sab')
		self.add({'url': [f'{_link2}/sony-tv', f'{_link}/sony-tv', f'{_link3}/sony-tv'], 'mode': 'vod_shows', 'list_name': 'Sony'}, 'Sony', iconImage='sony_set')
		self.add({'url': [f'{_link2}/colors', f'{_link}/color-tv-hd', f'{_link3}/colors-tv'], 'mode': 'vod_shows', 'list_name': 'Colors'}, 'Colors', iconImage='colors')
		self.add({'url': [f'{_link2}/zee-tv', f'{_link}/zee-tv', f'{_link3}/zee-tv'], 'mode': 'vod_shows', 'list_name': 'Zee'}, 'Zee', iconImage='zee')
		self.add({'url': [f'{_link2}/star-plus', f'{_link}/star-plus-hdepisodes', f'{_link3}/star-plus'], 'mode': 'vod_shows', 'list_name': 'Star Plus'}, 'Star Plus', iconImage='star_plus')

		self.add({'url': [f'{_link1}/gujarati-web-series'], 'mode': 'vod_shows', 'list_name': 'Gujarati web series'}, 'Gujarati web series', iconImage='guju_ws')
		self.add({'url': [f'{_link1}/sonyliv'], 'mode': 'vod_shows', 'list_name': 'SonyLiv'}, 'SonyLiv', iconImage='sony_liv')
		self.add({'url': [f'{_link1}/voot', f'{_link2}/voot'], 'mode': 'vod_shows', 'list_name': 'Voot'}, 'Voot', iconImage='voot')
		self.add({'url': [f'{_link1}/zee5', f'{_link2}/zee5'], 'mode': 'vod_shows', 'list_name': 'Zee5 Web Series'}, 'Zee5 Web Series', iconImage='zee5')
		self.add({'url': [f'{_link1}/mx-player', f'{_link2}/mx-web-series'], 'mode': 'vod_shows', 'list_name': 'Mx Player'}, 'Mx Originals', iconImage='mx')
		self.add({'url': [f'{_link1}/amazon-prime', f'{_link2}/amazon'], 'mode': 'vod_shows', 'list_name': 'Amazon Prime'}, 'Amazon Prime', iconImage='primevideo')
		self.add({'url': [f'{_link1}/netflix', f'{_link2}/netflix'], 'mode': 'vod_shows', 'list_name': 'Netflix'}, 'Netflix', iconImage='netflix')
		self.add({'url': [f'{_link1}/alt-balaji', f'{_link2}/alt-balaji'], 'mode': 'vod_shows', 'list_name': 'ALT Balaji Web Series'}, 'ALT Balaji Web Series', iconImage='altbalaji')
		self.add({'url': [f'{_link1}/hotstar', f'{_link2}/hotstar'], 'mode': 'vod_shows', 'list_name': 'HotStar Web Series'}, 'HotStar Web Series', iconImage='hotstar')
		self.add({'url': [f'{_link1}/hot-star-quix'], 'mode': 'vod_shows', 'list_name': 'HotStar Quix Web Series'}, 'HotStar Quix Web Series', iconImage='hotstar_quix')
		self.add({'url': [f'{_link1}/eros-now', f'{_link2}/eros-now-web-series'], 'mode': 'vod_shows', 'list_name': 'Eros Now'}, 'Eros Now', iconImage='erosnow')
		self.end_directory()

	def build_random_lists(self):
		random_list_dict = {
		'movie': ('Random Movie Lists', nc.random_movie_lists),
		'tvshow': ('Random TV Show Lists', nc.random_tvshow_lists),
		'because_you_watched': ('Random Because You Watched Lists', nc.random_because_you_watched_lists),
		'tmdb_lists': ('Random TMDb Lists', nc.random_tmdb_lists),
		'personal_lists': ('Random Personal Lists', nc.random_personal_lists),
		'trakt_personal': ('Random Trakt Lists (Personal)', nc.random_trakt_lists_personal),
		'trakt_public': ('Random Trakt Lists (Public)', nc.random_trakt_lists_public)}
		self.category_name, function = random_list_dict[self.params_get('menu_type')]
		func = function()
		for item in func: self.add(item, item['name'], item['iconImage'])
		self.end_directory()

	def add(self, url_params, list_name, iconImage='folder', original_image=False, cm_items=[]):
		isFolder = url_params.get('isFolder', 'true') == 'true'
		icon = iconImage if original_image else self.get_icon(iconImage)
		url_params.update({'iconImage': icon, 'name': list_name})
		url = self.build_url(url_params)
		listitem = self.make_listitem()
		listitem.setLabel(list_name)
		listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': self.fanart, 'banner': icon, 'landscape': icon})
		info_tag = listitem.getVideoInfoTag(True)
		info_tag.setPlot(' ')
		if not self.is_external:
			if isFolder:
				folder_item = ('Add to Shortcut Folder', self.run_plugin % self.build_url({'mode': 'menu_editor.shortcut_folder_add_known', 'url': self.build_url(url_params)}))
				if cm_items: cm_items.append(folder_item)
				else: cm_items = [folder_item]
				if url_params.get('mode') == 'vod_shows': cm_items.append((f'Clear Cache: for {list_name}', self.run_plugin % self.build_url({'mode': 'clear_cache', 'cache': 'h_shows', 'isFolder': 'false'})))
			listitem.addContextMenuItems(cm_items)
		self.add_item(int(sys.argv[1]), url, listitem, isFolder)

	def end_directory(self):
		handle = int(sys.argv[1])
		set_content(handle, '')
		set_category(handle, self.category_name)
		end_directory(handle)
		set_view_mode('view.main', '')
