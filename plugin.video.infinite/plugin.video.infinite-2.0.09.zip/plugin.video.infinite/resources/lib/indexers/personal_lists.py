# -*- coding: utf-8 -*-
import os
import sys
import json
from random import shuffle
from traceback import print_exc
from threading import Thread
from urllib.parse import unquote
from caches.personal_lists_cache import personal_lists_cache
from indexers.movies import Movies
from indexers.tvshows import TVShows
from modules import kodi_utils, settings, metadata
from modules.utils import TaskPool, paginate_list, sort_for_article, get_datetime, get_current_timestamp
logger = kodi_utils.logger

def get_personal_lists(params):
	def _process():
		for item in data:
			try:
				list_id, list_name, sort_order, list_total = item['list_id'], item['name'], item['sort_order'], item['total']
				if 'hidden_list' in list_name: continue
				display = '%s [I](x%02d)[/I]' % (list_name, list_total)
				mode = 'random.build_personal_lists_contents' if random else 'personal_lists.build_personal_list'
				url_params = {'mode': mode, 'list_id': list_id, 'list_name': list_name, 'category_name': list_name, 'sort_order': sort_order, 'name': list_name}
				if random: url_params['random'] = 'true'
				url = build_url(url_params)
				cm = [('[B]Make New List[/B]', 'RunPlugin(%s)' % build_url({'mode': 'personal_lists.make_new_personal_list'})),
				('[B]Edit Properties[/B]', 'RunPlugin(%s)' % build_url({'mode': 'personal_lists.adjust_personal_list_properties', 'list_id': list_id,
																		'list_name': list_name, 'sort_order': sort_order})),
				('[B]Delete List[/B]', 'RunPlugin(%s)' % build_url({'mode': 'personal_lists.delete_personal_list', 'list_id': list_id, 'list_name': list_name})),
				('[B]Add to Shortcut Folder[/B]', 'RunPlugin(%s)' % build_url({'mode': 'menu_editor.shortcut_folder_add_known', 'url': url}))]
				listitem = kodi_utils.make_listitem()
				listitem.setLabel(display)
				listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': background, 'banner': background})
				info_tag = listitem.getVideoInfoTag(True)
				info_tag.setPlot('')
				listitem.addContextMenuItems(cm)
				yield url, listitem, True
			except: pass
	def _new_process():
		url = build_url({'mode': 'personal_lists.make_new_personal_list'})
		cm = [('Import Tmdb List', 'RunPlugin(%s)' % build_url({'mode': 'personal_lists.import_tmdb_list'}))]
		new_icon = kodi_utils.get_icon('new')
		listitem = kodi_utils.make_listitem()
		listitem.setLabel('[I]Make New Personal List...[/I]')
		listitem.setArt({'icon': new_icon, 'poster': new_icon, 'thumb': new_icon, 'fanart': background, 'banner': background})
		info_tag = listitem.getVideoInfoTag(True)
		info_tag.setPlot(' ')
		listitem.addContextMenuItems(cm)
		yield url, listitem, False
	icon, background = kodi_utils.get_icon('lists'), kodi_utils.get_addon_fanart()
	build_url = kodi_utils.build_url
	random = params.get('random', 'false') == 'true'
	handle = int(sys.argv[1])
	try:
		data = get_all_personal_lists()
		result = []
		if data: result = list(_process())
		result += list(_new_process())
		kodi_utils.add_items(handle, result)
	except: pass
	kodi_utils.set_content(handle, 'files')
	kodi_utils.set_category(handle, 'Personal Lists')
	kodi_utils.end_directory(handle)
	kodi_utils.set_view_mode('view.main')

def build_personal_list(params):
	def _process(function, _list):
		item_list_extend(function(_list).worker())
	def _paginate_list(data, page_no, paginate_start):
		# if use_result: total_pages = 1
		if paginate_enabled:
			limit = settings.page_limit(is_external)
			data, total_pages = paginate_list(data, page_no, limit, paginate_start)
			if is_external: paginate_start = limit
		else: total_pages = 1
		return data, total_pages, paginate_start
	handle, is_external = int(sys.argv[1]), kodi_utils.external()
	hide_next_page = is_external and settings.widget_hide_next_page()
	threads, item_list, content, list_name = [], [], 'movies', ''
	try:
		item_list_extend = item_list.extend
		paginate_enabled = settings.paginate(is_external)
		use_result = 'result' in params
		list_id, list_name, sort_order = params.get('list_id'), params.get('list_name'), params.get('sort_order')
		page_no, paginate_start = int(params.get('new_page', '1')), int(params.get('paginate_start', '0'))
		new_params = {'mode': 'personal_lists.build_personal_list', 'list_id': list_id, 'list_name': list_name, 'sort_order': sort_order, 'paginate_start': paginate_start}
		if page_no == 1 and not is_external: kodi_utils.set_property('infinite.exit_params', kodi_utils.folder_path())
		if use_result: result = params.get('result', [])
		else: result = get_personal_list(params)
		process_list, total_pages, paginate_start = _paginate_list(result, page_no, paginate_start)
		movie_list = {'list': [(c, i['media_id']) for c, i in enumerate(process_list) if i['type'] == 'movie'], 'custom_order': 'true'}
		tvshow_list = {'list': [(c, i['media_id']) for c, i in enumerate(process_list) if i['type'] == 'tvshow'], 'custom_order': 'true'}
		content = 'movies' if len(movie_list['list']) > len(tvshow_list['list']) else 'tvshows'
		for item in ((Movies, movie_list), (TVShows, tvshow_list)):
			if not item[1]['list']: continue
			threaded_object = Thread(target=_process, args=item)
			threaded_object.start()
			threads.append(threaded_object)
		[i.join() for i in threads]
		item_list.sort(key=lambda k: k[1])
		if use_result: return content, [i[0] for i in item_list]
		kodi_utils.add_items(handle, [i[0] for i in item_list])
		if total_pages > page_no and not hide_next_page:
			new_page = str(page_no + 1)
			new_params['new_page'] = new_page
			kodi_utils.add_dir(handle, new_params, 'Next Page (%s) >>' % new_page, 'nextpage', kodi_utils.get_icon('nextpage_landscape'))
		if total_pages > 2 and settings.jump_to_enabled() and not is_external:
			kodi_utils.add_dir(handle, {'mode': 'navigate_to_page_choice', 'current_page': page_no, 'total_pages': total_pages, 'url_params': json.dumps(new_params), 'all_pages': result}, 'Jump To...', 'item_jump', kodi_utils.get_icon('item_jump_landscape'), isFolder=False)
	except: logger(f'error params: {params}: {print_exc()}')
	kodi_utils.set_content(handle, content)
	kodi_utils.set_category(handle, list_name)
	kodi_utils.end_directory(handle, cacheToDisc=False if is_external else True)
	if not is_external: kodi_utils.set_view_mode('view.%s' % content, content, is_external)

def get_all_personal_lists():
	contents = personal_lists_cache.get_lists()
	try: contents = sort_for_article(contents, 'name')
	except: pass
	return contents

def delete_personal_list(params):
	list_name, list_id = params.get('list_name', ''), params.get('list_id', '')
	if not kodi_utils.confirm_dialog(heading='Personal Lists', text='Delete [B]%s[/B] Personal List?' % list_name): return
	if personal_lists_cache.delete_list(list_id): return kodi_utils.kodi_refresh()
	kodi_utils.notification('Error Deleting List', 3000)

def delete_personal_list_contents(params):
	list_name, list_id = params.get('list_name', ''), params.get('list_id', '')
	if not list_change_warning(list_name): return
	if personal_lists_cache.delete_list_contents(list_id): return
	kodi_utils.notification('Error Deleting List Contents', 3000)

def get_personal_list(params):
	list_id, sort_order = params['list_id'], params.get('sort_order', None)
	contents = personal_lists_cache.get_list(list_id)
	try:
		if sort_order == 'None': pass
		elif sort_order in ('5', 'shuffle'): shuffle(contents)
		elif sort_order in ('', '0'): contents = sort_for_article(contents, 'title')
		elif sort_order in ('1', '2'): contents.sort(key=lambda k: int(k['date_added']), reverse=sort_order != '1')
		else: contents.sort(key=lambda k: (k['release_date'] is None, k['release_date']), reverse=sort_order != '3')
	except: pass
	return contents

def make_new_personal_list(params):
	is_retry = params.get('is_retry', False)
	list_name = personal_list_name()
	if list_name == None: return None, None
	if not unique_list_check(list_name): return make_new_personal_list(params)
	sort_order = personal_sort_order()
	if sort_order == None: return None, None
	data = personal_lists_cache.make_list(list_name, sort_order)
	if data:
		list_id = data.get('list_id')
		if not list_id:
			kodi_utils.notification('Error Creating List', 3000)
			return None, None
	else:
		kodi_utils.notification('Error Creating List', 3000)
		return None, None
	if any([kodi_utils.path_check('get_personal_lists') or kodi_utils.external()]): kodi_utils.kodi_refresh()
	return list_id, list_name

def unique_list_check(list_name):
	contents = personal_lists_cache.get_lists()
	list_names = [i['name'] for i in contents]
	if list_name in list_names:
		kodi_utils.ok_dialog('Personal Lists', 'List Already Exists[CR]Choose a different name')
		return False
	return True

def adjust_personal_list_properties(params):
	sort_order_dict = {'0': 'Title', '1': 'Date Added (asc)', '2': 'Date Added (desc)', '3': 'Release Date (asc)', '4': 'Release Date (desc)', '5': 'Shuffle'}
	list_id, list_name, sort_order = params.get('list_id', ''), params.get('list_name', ''), params.get('sort_order', '')
	choices = [('Change Name', 'Currently [B]%s[/B]' % (list_name), 'list_name'),
				('Change Sort Order', 'Currently [B]%s[/B]' % sort_order_dict.get(sort_order, 'None'), 'sort_order'),
				('Empty List Contents', 'Delete All Contents of %s' % list_name, 'empty_contents'),
				('Copy one List to other', 'Copy one List to other', 'copy_list_item'),
				('Import Tmdb List', 'Import a Tmdb List into %s' % list_name, 'import_tmdb')]
	list_items = [{'line1': item[0], 'line2': item[1] or item[0]} for item in choices]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Personal List Properties', 'multi_line': 'true', 'narrow_window': 'true'}
	action = kodi_utils.select_dialog([i[2] for i in choices], **kwargs)
	if action == None: return kodi_utils.kodi_refresh() if params.get('refresh', 'false') == 'true' else None
	if action == 'list_name':
		new_name = personal_list_name(list_name)
		if new_name == None: return adjust_personal_list_properties(params)
		personal_lists_cache.update_single_detail('name', new_name, list_id)
		params.update({'list_name': new_name, 'refresh': 'true'})
	elif action == 'sort_order':
		new_sort_order = personal_sort_order()
		if new_sort_order == None: return adjust_personal_list_properties(params)
		personal_lists_cache.update_single_detail('sort_order', new_sort_order, list_id)
		params.update({'sort_order': new_sort_order, 'refresh': 'true'})
	elif action == 'empty_contents':
		delete_personal_list_contents({'list_name': list_name, 'list_id': list_id})
		params.update({'refresh': 'true'})
	elif action == 'import_tmdb':
		import_tmdb_list()
	elif action == 'copy_list_item':
		copy_list_item()
	return adjust_personal_list_properties(params)

def personal_list_name(list_name=''):
	new_name = kodi_utils.kodi_dialog().input('Please Choose a Name for the New List', defaultt=list_name)
	if not new_name: return None
	new_name = unquote(new_name)
	return new_name

def personal_sort_order():
	choices = [('Title (asc)', '0'), ('Date Added (asc)', '1'), ('Date Added (desc)', '2'), ('Release Date (asc)', '3'), ('Release Date (desc)', '4'), ('Shuffle', '5')]
	list_items = [{'line1': item[0]} for item in choices]
	kwargs = {'items': json.dumps(list_items), 'heading': 'List Sort Order', 'narrow_window': 'true'}
	sort_order = kodi_utils.select_dialog([i[1] for i in choices], **kwargs)
	if sort_order == None: return None
	return sort_order

def list_change_warning(list_name, text='[B]CAUTION!!![/B][CR][CR]This will change the contents of [B]%s[/B]. Continue?'):
	return kodi_utils.confirm_dialog(heading='Personal Lists', text=text % list_name, ok_label='Yes', cancel_label='No')



def import_tmdb_list(parms=''):
	from indexers.tmdb_lists import tmdb_lists_cache_object, get_all_tmdb_lists, get_tmdb_list
	contents = tmdb_lists_cache_object(get_all_tmdb_lists, 'get_user_lists', settings.get_setting('infinite.sort.list_sort', '0'))
	list_items = [{'line1': '%s%s' % (item['name'],  ' [I](x%d)[/I]' % item['number_of_items'] if 'number_of_items' in item else '')} for item in contents]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Select', 'narrow_window': 'true'}
	chosen_list = kodi_utils.select_dialog(contents, **kwargs)
	if chosen_list == None: return
	list_id, list_name = chosen_list['id'], chosen_list.get('name')
	contents = tmdb_lists_cache_object(get_tmdb_list, f'{list_name}_1', {'list_id': list_id})
	insert_update_list('tmdb', list_name, contents)
	# if result == 'Success':
		# if confirm_dialog(heading='Personal Lists', text='Rename List to Match Tmdb List Name?', ok_label='Yes', cancel_label='No'):
			# personal_lists_cache.update_single_detail('name', list_name, list_name)


def insert_update_list(_type, list_name, contents):
	if not unique_list_check(list_name):
		if not list_change_warning(list_name): return
	else: personal_lists_cache.make_list(list_name, 0)
	new_contents = process_tmdb_list(contents)
	result = personal_lists_cache.add_many_list_items(list_name, new_contents)
	kodi_utils.notification(result)

def process_tmdb_list(chosen_list):
	media_type_check = {'movie': 'movie', 'tv': 'tvshow', 'show': 'tvshow', 'tvshow': 'tvshow'}
	new_contents = []
	new_contents_append = new_contents.append
	current_timestamp = kodi_utils.get_current_timestamp()
	for count, item in enumerate(chosen_list):
		try:
			media_type = item.get('type') or item.get('media_type')
			media_id = item['id']
			if media_id in (None, 'None', ''): continue
			title = item.get('name') or item.get('title')
			try: release_date = item.get('first_air_date') or item.get('release_date')
			except: release_date = ''
			date_added = current_timestamp + count
			new_contents_append({'media_id': str(media_id), 'title': title, 'type': media_type_check[media_type], 'release_date': release_date, 'date_added': str(date_added)})
		except: continue
	return new_contents

def external_process_view(params):
	def _process(function, _list, _type):
		if not _list.get('list', []): return
		data = function(_list).worker()
		results_extend(data)
	tmdb_movies, imdb_movies, tmdb_tvshows, imdb_tvshows = {}, {}, {}, {}
	item_list, list_name, list_type, media_type = json.loads(params['item_list']), params['list_name'], params['list_type'], params['media_type']
	movies = {'list': [(i['order'], i['id']) for i in item_list if i['mt'] == 'm'], 'id_type': '%s_id' % list_type, 'custom_order': 'true'}
	tvshows = {'list': [(i['order'], i['id']) for i in item_list if i['mt'] == 'tv'], 'id_type': '%s_id' % list_type, 'custom_order': 'true'}
	threads, results = [], []
	results_extend = results.extend
	handle, is_external = int(sys.argv[1]), kodi_utils.external()
	content = max([('movies', len(tmdb_movies.get('list', []) + imdb_movies.get('list', []))), ('tvshows', len(tmdb_tvshows.get('list', []) + imdb_tvshows.get('list', [])))],
					key=lambda k: k[1])[0]
	for item in ((Movies, movies, 'movies'), (TVShows, tvshows, 'tvshows')):
		threaded_object = Thread(target=_process, args=item)
		threaded_object.start()
		threads.append(threaded_object)
	[i.join() for i in threads]
	results.sort(key=lambda k: k[1])
	kodi_utils.add_items(handle, [i[0] for i in results])
	kodi_utils.set_content(handle, content)
	kodi_utils.set_category(handle, list_name)
	kodi_utils.end_directory(handle, cacheToDisc=False if is_external else True)
	if not is_external:
		if params.get('refreshed') == 'true': kodi_utils.sleep(1000)
		kodi_utils.set_view_mode('view.%s' % content, content, is_external)

class ExternalImport:
	def __init__(self, params, item_list):
		self.results = []
		self.progressDialog = None
		self.results_append = self.results.append
		self.item_list = item_list
		self.total_items = len(self.item_list)
		self.list_name, self.list_type, self.media_type = params.get('list_name'), params.get('list_type', None), params.get('media_type', None)
		self.action, self.author, self.description = params.get('action', None), params.get('author', 'Unknown') or 'Unknown', params.get('description', '')
		self.import_indicator, self.poster, self.fanart = params.get('busy_indicator', 'none'), params.get('poster', ''), params.get('fanart', '')
		self.api_key, self.current_time, self.current_timestamp = settings.tmdb_api_key(), get_datetime(), get_current_timestamp()

	def process(self, item):
		try:
			original_id, id_type, order = item['id'], '%s_id' % self.list_type, item['order']
			m_type = item.get('mt') or self.media_type
			m_type = 'movie' if m_type == 'm' else 'tvshow'
			function = metadata.movie_meta if m_type == 'movie' else metadata.tvshow_meta
			meta = function(id_type, original_id, self.api_key, self.current_time, self.current_timestamp)
			title, media_id, release_date, date_added = meta['title'], meta['tmdb_id'], meta['premiered'], self.current_timestamp + order
			self.results_append({'media_id': str(media_id), 'title': title, 'type': m_type, 'release_date': release_date, 'date_added': str(date_added), 'order': order})
			if self.progressDialog: self.progressDialog.update(meta['title'], int(float(len(self.results)) / float(self.total_items) * 100), meta['poster'])
		except: pass

	def run(self):
		if self.import_indicator == 'busy': kodi_utils.show_busy_dialog()
		elif self.import_indicator == 'progress':
			self.progressDialog = kodi_utils.progress_dialog('Importing Media', kodi_utils.get_icon('lists'))
			kodi_utils.sleep(1000)
		threads = TaskPool().tasks(self.process, self.item_list)
		[i.join() for i in threads]
		self.results.sort(key=lambda k: k['order'])
		success = personal_lists_cache.make_list(self.list_name, 0)
		if not success: return kodi_utils.notification('Error Creating [B]%s[/B]' % self.list_name)
		items_added = personal_lists_cache.add_many_list_items(self.list_name, self.results)
		if items_added == 'Success':
			self.close_indicator()
			kodi_utils.notification('Items Added to New List [B]%s[/B]' % self.list_name)
		else:
			self.close_indicator()
			kodi_utils.notification('Error Adding Items to [B]%s[/B]' % self.list_name)
		return 

	def close_indicator(self):
		if self.progressDialog:
			self.progressDialog.close()
			kodi_utils.sleep(100)
		elif self.import_indicator == 'busy': kodi_utils.hide_busy_dialog()

def external_import(params):
	kodi_utils.sleep(200)
	kodi_utils.close_all_dialog()
	kodi_utils.sleep(200)
	action = params.get('action', None)
	list_name, list_type, media_type = params.get('list_name'), params.get('list_type', None), params.get('media_type_default', None)
	params['media_type'] = media_type
	if not action:
		choices = [('View', 'view'), ('Import', 'import'), ('Import & View', 'import_view')]
		list_items = [{'line1': i[0]} for i in choices]
		kwargs = {'items': json.dumps(list_items), 'narrow_window': 'true', 'heading': 'TESTING: Choose Import Action'}
		choice = kodi_utils.select_dialog(choices, **kwargs)
		if choice == None: return
		action = choice[1]
	item_list = params.get('list_items', '')
	if not item_list:
		base_64 = params.get('base64_items') or ''
		if base_64:
			import gzip
			import base64
			try:
				payload_bytes = base64.b64decode(base_64)
				try: json_bytes = gzip.decompress(payload_bytes)
				except: json_bytes = payload_bytes
				item_list = json.loads(json_bytes.decode('utf-8', 'ignore'))
			except: kodi_utils.notification('Invalid External Payload (base64_items)')
	else: item_list = json.loads(params.get('list_items', '[]'))
	if not item_list: return kodi_utils.notification('No Items in Import List. Try Again.', 3000)
	item_list = [dict(i, **{'order': c, 'mt': i.get('mt') or media_type}) for c, i in enumerate(item_list)]
	if list_name: list_name = unquote(list_name)
	else: list_name = personal_list_name()
	if not list_name: return
	if 'import' in action: ExternalImport(params, [(i,) for i in item_list]).run()
	if 'view' in action:
		kodi_utils.activate_window({'mode': 'personal_lists.external_process_view', 'item_list': json.dumps(item_list), 'media_type': media_type,
									'list_type': list_type, 'list_name': list_name}, True)
	if action == 'import' and (kodi_utils.path_check('get_personal_lists') or kodi_utils.external()): kodi_utils.kodi_refresh()
	return

def copy_list_item():
	def get_lists(title='Select'):
		list_items = [{'line1': '%s%s' % (item['name'],  ' [I](x%d)[/I]' % item['number_of_items'] if 'number_of_items' in item else '')} for item in contents]
		kwargs = {'items': json.dumps(list_items), 'heading': title, 'narrow_window': 'true'}
		chosen_list = kodi_utils.select_dialog(contents, **kwargs)
		return chosen_list
	def get_list_items(params):
		return personal_lists_cache.get_list(params['name'])
	contents = personal_lists_cache.get_lists()
	# logger(f'contents: {repr(contents)}')
	params1 = get_lists('Select list To copy From')
	if params1 == None: return
	_list1 = get_list_items(params1)
	params2 = get_lists('Select list To copy to')
	if params2 == None: return
	result = personal_lists_cache.add_many_list_items(params2['name'], _list1)
	return True

def build_imdb_list(params):
	def _process(function, _list):
		item_list_extend(function(_list).worker())
	def _paginate_list(data, page_no, paginate_start):
		if paginate_enabled:
			limit = kodi_utils.page_limit(is_external)
			data, total_pages = paginate_list(data, page_no, limit, paginate_start)
			if is_external: paginate_start = limit
		else: total_pages = 1
		return data, total_pages, paginate_start
	handle, is_external, list_name = int(sys.argv[1]), kodi_utils.external(), 'IMDB List'
	hide_next_page = is_external and kodi_utils.widget_hide_next_page()
	content = 'movies'
	try:
		threads, item_list, content = [], [], 'movies'
		item_list_extend = item_list.extend
		paginate_enabled = kodi_utils.paginate(is_external)
		use_result = 'result' in params
		list_name, sort_order = params.get('list_name'), params.get('sort_order', '0')
		page_no, paginate_start = int(params.get('new_page', '1')), int(params.get('paginate_start', '0'))
		new_params = {'mode': 'personal_lists.build_imdb_list', 'list_name': list_name, 'sort_order': sort_order, 'seen': 'true', 'paginate_start': paginate_start}
		if page_no == 1 and not is_external: kodi_utils.set_property('infinite.exit_params', kodi_utils.folder_path())
		if use_result: result = params.get('result', [])
		else:
			from apis.imdb_api import get_imdb_list
			result = kodi_utils.cache_object(get_imdb_list, f'imdb_api.get_imdb_list', json=False)
		process_list, total_pages, paginate_start = _paginate_list(result, page_no, paginate_start)
		movie_list = {'list': [(c, i['media_id']) for c, i in enumerate(process_list) if i['type'] == 'movie'], 'custom_order': 'true'}
		tvshow_list = {'list': [(c, i['media_id']) for c, i in enumerate(process_list) if i['type'] == 'tvshow'], 'custom_order': 'true'}
		content = 'movies' if len(movie_list['list']) > len(tvshow_list['list']) else 'tvshows'
		for item in ((Movies, movie_list), (TVShows, tvshow_list)):
			if not item[1]['list']: continue
			threaded_object = Thread(target=_process, args=item)
			threaded_object.start()
			threads.append(threaded_object)
		[i.join() for i in threads]
		item_list.sort(key=lambda k: k[1])
		if use_result: return content, [i[0] for i in item_list]
		kodi_utils.add_items(handle, [i[0] for i in item_list])
		if total_pages > page_no and not hide_next_page:
			new_page = str(page_no + 1)
			new_params['new_page'] = new_page
			kodi_utils.add_dir(handle, new_params, 'Next Page (%s) >>' % new_page, 'nextpage', kodi_utils.get_icon('nextpage_landscape'))
		if total_pages > 2 and kodi_utils.jump_to_enabled() and not is_external: kodi_utils.add_dir(handle, {'mode': 'navigate_to_page_choice', 'current_page': page_no, 'total_pages': total_pages, 'url_params': json.dumps(new_params), 'all_pages': result}, 'Jump To...', 'item_jump', kodi_utils.get_icon('item_jump_landscape'), isFolder=False)
	except: logger(f'error params: {params}: {print_exc()}')
	kodi_utils.set_content(handle, content)
	kodi_utils.set_category(handle, list_name)
	kodi_utils.end_directory(handle, cacheToDisc=False if is_external else True)
	if not is_external:
		if params.get('refreshed') == 'true': kodi_utils.sleep(1000)
		kodi_utils.set_view_mode('view.%s' % content, content, is_external)
	return