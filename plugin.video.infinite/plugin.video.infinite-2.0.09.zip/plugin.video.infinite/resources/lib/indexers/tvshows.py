# -*- coding: utf-8 -*-
import sys
import json
from traceback import print_exc
from modules.metadata import tvshow_meta
from modules.utils import manual_function_import, get_datetime, TaskPool, get_current_timestamp, paginate_list
from modules.watched_status import get_database, watched_info_tvshow, get_watched_status_tvshow, get_progress_status_tvshow
from modules.kodi_utils import logger, item_jump_landscape, add_dir, external, sleep, get_icon, add_item, set_property, set_content, set_sort_method, set_view_mode, end_directory, make_listitem, build_url, add_items, nextpage_landscape, get_property, clear_property, focus_index, set_category, home, folder_path, set_info, addon_fanart, build_main_url
from modules.settings import rpdb_info as rpdb_i, media_open_action, default_all_episodes, page_limit, paginate, widget_hide_next_page, widget_hide_watched, watched_indicators, tmdb_api_key, cm_sort_order, cm_default_order, jump_to_enabled, ai_model_active


class TVShows:
	tmdb_main = ('tmdb_tv_popular', 'tmdb_tv_popular_today', 'tmdb_tv_premieres', 'tmdb_tv_trending', 'tmdb_tv_trending_recent', 'tmdb_tv_airing_today','tmdb_tv_on_the_air','tmdb_tv_upcoming')
	special = ('tmdb_tv_year', 'tmdb_tv_recommendations', 'tmdb_tv_genres', 'tmdb_tv_search', 'tmdb_tv_keyword_results', 'tmdb_tv_keyword_results_direct', 'ai_similar', 'tmdb_tv_similar','tmdb_tv_languages','tmdb_tv_networks','tmdb_tv_providers','tmdb_tv_decade')
	personal = {'in_progress_tvshows': ('modules.watched_status', 'get_in_progress_tvshows'), 'watched_tvshows': ('modules.watched_status', 'get_watched_items'),
	'favorites_tvshows': ('modules.favorites', 'get_favorites'),'recent_watched_tvshows': ('modules.watched_status', 'get_recently_watched'), }
	trakt_main = ('trakt_tv_trending', 'trakt_tv_trending_recent', 'trakt_tv_most_watched', 'trakt_tv_most_favorited')
	trakt_special = ('trakt_tv_certifications',)
	trakt_personal = ('trakt_collection', 'trakt_watchlist', 'trakt_collection_lists', 'trakt_watchlist_lists', 'trakt_favorites')
	tmdb_personal = ('tmdb_watchlist', 'tmdb_favorite', 'tmdb_recommendations')
	imdb_personal = ('imdb_watchlist', 'imdb_user_list_contents', 'imdb_keywords_list_contents')
	trakt_search = ('trakt_tv_search', 'trakt_anime_search')


	def __init__(self, params):
		self.params = params
		self.params_get = self.params.get
		self.category_name = self.params_get('category_name', None) or self.params_get('name', None) or 'TV Shows'
		self.id_type, self.list, self.action = self.params_get('id_type', 'tmdb_id'), self.params_get('list', []), self.params_get('action', None)
		self.tmdb_api_key = tmdb_api_key()
		self.items, self.new_page, self.total_pages, self.is_external = [], {}, None, external()
		if self.is_external:
			self.widget_hide_next_page = widget_hide_next_page()
			self.widget_hide_watched = self.action not in ('watched_tvshows', 'recent_watched_tvshows') and widget_hide_watched()
		else: self.widget_hide_next_page, self.widget_hide_watched = False, False
		self.custom_order = self.params_get('custom_order', 'false') == 'true'
		self.paginate_start = int(self.params_get('paginate_start', '0'))
		self.append = self.items.append
		self.build_main_url = build_main_url
		self.fromtmbd = self.params_get('fromtmbd', 'false') == 'true'
		self.current_date, self.current_time = get_datetime(), get_current_timestamp()
		self.all_episodes, self.open_extras = default_all_episodes(), media_open_action('tvshow') == 1
		self.is_folder = False if self.open_extras else True
		rpdb_info = rpdb_i('tvshow')
		self.rpdb_api_key, self.rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
		self.watched_indicators = watched_indicators()
		self.watched_title = 'Trakt' if self.watched_indicators == 1 else 'infinite'
		self.watched_info = watched_info_tvshow(get_database())
		self.window_command = 'ActivateWindow(Videos,%s,return)' if self.is_external else 'Container.Update(%s)'
		self.cm_sort_order = cm_sort_order()
		self.custom_cm_menu = self.cm_sort_order != cm_default_order()
		self.poster_empty, self.fanart_empty = get_icon('box_office'), addon_fanart()
		self.make_listitem, self.build_url = make_listitem, build_url
		self.ai_model_active = ai_model_active()

	def fetch_list(self):
		handle = int(sys.argv[1])
		try:
			is_random = self.params_get('random', 'false') == 'true'
			try: page_no = int(self.params_get('new_page', '1'))
			except: page_no = self.params_get('new_page')
			if page_no == 1 and not self.is_external:
				folderpath = folder_path()
				if all(x not in folderpath for x in ('build_season_list', 'build_episode_list')): set_property('infinite.exit_params', folderpath)
			if self.action in self.personal: var_module, import_function = self.personal[self.action]
			else: var_module, import_function = f'apis.{self.action.split("_")[0]}_api', self.action
			try: function = manual_function_import(var_module, import_function)
			except: function = None
			# logger(f'fetch_list self.action: {self.action}\nvar_module: {var_module}\nimport_function: {import_function}')
			if self.action in self.tmdb_main:
				data = function(page_no)
				self.list = [i['id'] for i in data['results']]
				if not is_random and data['total_pages'] > page_no: self.new_page = {'new_page': str(page_no + 1)}
			elif self.action in self.trakt_main:
				self.id_type = 'trakt_dict'
				data = function(page_no)
				try: self.list = [i['show']['ids'] for i in data]
				except: self.list = [i['ids'] for i in data]
				if not is_random: self.new_page = {'new_page': str(page_no + 1)}
			elif self.action in self.special:
				key_id = self.params_get('key_id') or self.params_get('query')
				if not key_id: return
				data = function(key_id, page_no)
				self.list = [i['id'] for i in data['results']]
				if not is_random and data['total_pages'] > page_no: self.new_page = {'new_page': str(page_no + 1), 'key_id': key_id}
			elif self.action in self.personal:
				data = function('tvshow', page_no)
				c_data, total_pages = self.paginate_list(data, page_no)
				self.list = [i['media_id'] for i in c_data]
				if total_pages > 2: self.total_pages = total_pages
				if total_pages > page_no: self.new_page = {'new_page': str(page_no + 1), 'paginate_start': self.paginate_start}
			elif self.action == 'tmdb_tv_discover':
				url = self.params_get('url')
				data = function(url, page_no)
				results = data['results']
				self.list = [i['id'] for i in results]
				if data['total_pages'] > page_no: self.new_page = {'url': url, 'new_page': str(data['page'] + 1)}
			elif self.action == 'trakt_tv_related':
				self.id_type = 'trakt_dict'
				key_id = self.params_get('key_id')
				if not key_id.startswith('tt'): key_id = tvshow_meta('tmdb_id', key_id, self.tmdb_api_key, get_datetime())['imdb_id']
				data = function(key_id)
				self.list = [i['ids'] for i in data]
			elif self.action in self.trakt_special:
				key_id = self.params_get('key_id', None) or self.params_get('query')
				if not key_id: return
				self.id_type = 'trakt_dict'
				data = function(key_id, page_no)
				self.list = [i['show']['ids'] for i in data]
				if not is_random: self.new_page = {'new_page': str(page_no + 1), 'key_id': key_id}
			elif self.action in self.tmdb_personal:
				data, total_pages = function('tv', page_no, 1)
				self.list = [i['id'] for i in data]
				if total_pages > page_no: self.new_page = {'new_page': str(page_no + 1), 'new_letter': 1}
			elif self.action in self.trakt_personal:
				self.id_type = 'trakt_dict'
				data = function('shows', page_no)
				if self.action in ('trakt_collection_lists', 'trakt_favorites'): total_pages, c_data = 1, data
				else: c_data, total_pages = self.paginate_list(data, page_no)
				self.list = [i['media_ids'] for i in c_data]
				if total_pages > 2: self.total_pages = total_pages
				try:
					if total_pages > page_no: self.new_page = {'new_page': str(page_no + 1), 'paginate_start': self.paginate_start}
				except: pass
			elif self.action in self.trakt_search:
				key_id = self.params_get('key_id', None) or self.params_get('query')
				if not key_id: return
				self.id_type = 'trakt_dict'
				data, total_pages = function(key_id, page_no)
				self.list = [i['show']['ids'] for i in data]
				if int(total_pages) > page_no: self.new_page = {'new_page': str(page_no + 1), 'key_id': key_id}
			elif self.action == 'trakt_recommendations':
				self.id_type = 'trakt_dict'
				data = function('shows')
				c_data, total_pages = self.paginate_list(data, page_no)
				self.list = [i['ids'] for i in c_data]
				if total_pages > 2: self.total_pages = total_pages
				try:
					if total_pages > page_no: self.new_page = {'new_page': str(page_no + 1), 'paginate_start': self.paginate_start}
				except: pass
			elif self.action in self.imdb_personal:
				self.id_type = 'imdb_id'
				list_id = self.params_get('list_id', None)
				data, next_page = function('tvshow', list_id, page_no)
				self.list = [i['imdb_id'] for i in data]
				if next_page: self.new_page = {'list_id': list_id, 'new_page': str(page_no + 1), 'new_letter': 1}
			elif self.action == 'imdb_more_like_this':
				from apis.imdb_api import imdb_more_like_this
				self.id_type = 'imdb_id'
				key_id = self.params_get('key_id')
				if self.params_get('get_imdb'):
					key_id = tvshow_meta('tmdb_id', key_id, self.tmdb_api_key, get_datetime(), get_current_timestamp())['imdb_id']
				self.list = data = imdb_more_like_this(key_id)
			elif self.action == 'ai_recommendation':
				key_id = self.params_get('key_id') or self.params_get('query')
				if not key_id: return
				recommendation_info = json.loads(key_id)
				data = function(recommendation_info, page_no)
				results = data['results']
				self.list = [i['id'] for i in results]
			add_items(handle, self.worker())
			if self.new_page and not self.widget_hide_next_page:
				self.new_page.update({'mode': 'build_tvshow_list', 'action': self.action, 'category_name': self.category_name})
				add_dir(handle, self.new_page, 'Next Page (%s) >>' % self.new_page['new_page'], 'nextpage', get_icon('nextpage_landscape'))
			if self.total_pages and self.total_pages > 2 and jump_to_enabled() and not self.is_external:
				add_dir(handle, {'mode': 'navigate_to_page_choice', 'current_page': page_no, 'total_pages': self.total_pages, 'url_params': json.dumps(self.new_page), 'all_pages': data}, 'Jump To...', 'item_jump', get_icon('item_jump_landscape'), isFolder=False)
		except: logger(f'fetch_list self.params: {self.params}\nError: {print_exc()}')
		set_content(handle, 'tvshows')
		set_category(handle, self.category_name)
		end_directory(handle, cacheToDisc=not self.is_external)
		if not self.is_external:
			if self.params_get('refreshed') == 'true': sleep(1000)
			set_view_mode('view.tvshows', 'tvshows', self.is_external)

	def build_tvshow_content(self, _position, _id, dbcon):
		try:
			if isinstance(_id, dict):
				if _id.get('tmdb', None): self.id_type, _id = 'tmdb_id', _id['tmdb']
				elif _id.get('imdb', None): self.id_type, _id = 'imdb_id', _id['imdb']
			meta = tvshow_meta(self.id_type, _id, self.tmdb_api_key, self.current_date, self.current_time, dbcon)
			if not meta or 'blank_entry' in meta: return
			cm = []
			cm_append = cm.append
			cm_extend = cm.extend
			listitem = self.make_listitem()
			set_properties = listitem.setProperties
			meta_get = meta.get
			trailer, title, year, premiered = meta_get('trailer'), meta_get('title'), meta_get('year') or '2050', meta_get('premiered')
			tvdb_id, imdb_id = meta_get('tvdb_id'), meta_get('imdb_id')
			cast = meta_get('short_cast', []) or meta_get('cast', []) or []
			if self.rpdb_api_key:
				try: poster = meta_get('rpdb_poster') % self.rpdb_api_key + self.rpdb_format
				except: poster = meta_get('poster') or self.poster_empty
			else: poster = meta_get('poster') or self.poster_empty
			fanart = meta_get('fanart') or self.fanart_empty
			clearlogo, landscape = meta_get('clearlogo') or '', meta_get('landscape') or ''
			thumb = poster or landscape or fanart
			tmdb_id, total_seasons, total_aired_eps = meta_get('tmdb_id'), meta_get('total_seasons') or meta_get('seasons', 1), meta_get('total_aired_eps')
			unaired = total_aired_eps == 0
			if unaired: progress, playcount, total_watched, total_unwatched = 0, 0, 0, total_aired_eps
			else:
				playcount, total_watched, total_unwatched = get_watched_status_tvshow(self.watched_info.get(str(tmdb_id), None), total_aired_eps)
				if total_watched: progress = get_progress_status_tvshow(total_watched, total_aired_eps)
				else: progress = 0
			visible_progress = '0' if progress == 100 else progress
			extras_params = self.build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'tvshow', 'is_external': self.is_external})
			options_params = self.build_url({'mode': 'options_menu_choice', 'content': 'tvshow', 'tmdb_id': tmdb_id, 'poster': poster, 'is_external': self.is_external})
			browse_recommended_params = self.build_url({'mode': 'build_tvshow_list', 'action': 'tmdb_tv_recommendations', 'key_id': tmdb_id, 'is_external': self.is_external, 'name': 'Recommended based on %s' % title})
			browse_related_params = self.build_url({'mode': 'build_tvshow_list', 'action': 'trakt_tv_related', 'key_id': imdb_id, 'is_external': self.is_external,
										'name': 'Related to %s' % title})
			browse_more_like_this_params = self.build_url({'mode': 'build_tvshow_list', 'action': 'imdb_more_like_this', 'key_id': imdb_id, 'name': 'More Like This based on %s' % title, 'is_external': self.is_external})
			browse_similar_params = self.build_url({'mode': 'build_tvshow_list', 'action': 'ai_similar', 'is_external': self.is_external, 'key_id': 'tvshow|%s' % tmdb_id, 'name': 'AI Similar based on %s' % title})
			browse_in_trakt_list_params = self.build_url({'mode': 'trakt.list.in_trakt_lists', 'media_type': 'tvshow', 'imdb_id': imdb_id, 'is_external': self.is_external, 'category_name': '%s In Trakt Lists' % title})
			trakt_manager_params = self.build_url({'mode': 'trakt_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow', 'icon': poster})
			personal_manager_params = self.build_url({'mode': 'personallists_manager_choice', 'list_type': 'tvshow', 'tmdb_id': tmdb_id, 'title': title, 'premiered': premiered, 'current_time': self.current_time, 'icon': poster})
			tmdb_manager_params = self.build_url({'mode': 'tmdblists_manager_choice', 'media_type': 'tv', 'tmdb_id': tmdb_id, 'icon': poster})
			favorites_manager_params = self.build_url({'mode': 'favorites_manager_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'title': title})
			if self.all_episodes:
				if self.all_episodes == 1 and total_seasons > 1: url_params = {'mode': 'build_season_list', 'tmdb_id': tmdb_id}
				else: url_params = {'mode': 'build_episode_list', 'tmdb_id': tmdb_id, 'season': 'all'}
			else: url_params = {'mode': 'build_season_list', 'tmdb_id': tmdb_id}
			if self.open_extras:
				cm_append(['extras', ('[B]Browse[/B]', 'Container.Update(%s)' % url_params)])
				url_params = extras_params
			else: cm_append(['extras', ('[B]Extras[/B]', 'RunPlugin(%s)' % extras_params)])
			
			url = self.build_main_url(url_params, self.is_external)
			cm_extend([
			['cast', ('[B]Cast[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'tmdb_cast_dialog_image_results', 'media_type': 'tvshow', 'tmdb_id': tmdb_id}))],
			['more_info', ('[B]More Info[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'media_extra_info_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id}))],
			['options', ('[B]Options[/B]', 'RunPlugin(%s)' % options_params)],
			['recommended', ('[B]Browse Recommended[/B]', self.window_command % browse_recommended_params)],
			['related', ('[B]Browse Related[/B]', self.window_command % browse_related_params)],
			['more_like_this', ('[B]Browse More Like This[/B]', self.window_command % browse_more_like_this_params)],
			['in_trakt_list', ('[B]In Trakt Lists[/B]', self.window_command % browse_in_trakt_list_params)],
			['trakt_manager', ('[B]Trakt Lists Manager[/B]', 'RunPlugin(%s)' % trakt_manager_params)],
			['personal_manager', ('[B]Personal Lists Manager[/B]', 'RunPlugin(%s)' % personal_manager_params)],
			['tmdb_manager', ('[B]TMDb Lists Manager[/B]', 'RunPlugin(%s)' % tmdb_manager_params)],
			['favorites_manager', ('[B]Favorites Manager[/B]', 'RunPlugin(%s)' % favorites_manager_params)]])
			if self.ai_model_active: cm_append(['similar', ('[B]Browse AI Similar[/B]', self.window_command % browse_similar_params)])
			if playcount:
				if self.widget_hide_watched: return
			elif not unaired:
				cm_append(['mark_watched', ('[B]Mark Watched %s[/B]' % self.watched_title, 'RunPlugin(%s)' % self.build_url({'mode': 'watched_status.mark_tvshow', 'action': 'mark_as_watched', 'title': title,'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id}))])
			if progress:
				cm_append(['mark_watched', ('[B]Mark Unwatched %s[/B]' % self.watched_title, 'RunPlugin(%s)' % self.build_url({'mode': 'watched_status.mark_tvshow', 'action': 'mark_as_unwatched', 'title': title, 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id}))])
				set_properties({'watchedepisodes': str(total_watched), 'unwatchedepisodes': str(total_unwatched)})
			set_properties({'watchedprogress': str(visible_progress), 'totalepisodes': str(total_aired_eps), 'totalseasons': str(total_seasons)})
			cm_append(['browse', ('[B]Add to a Shortcut Folder[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'menu_editor.shortcut_folder_add_known', 'name': title, 'iconImage': poster}))])
			if self.is_external:
				cm_extend([['refresh', ('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'refresh_widgets'}))],
						['reload', ('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'kodi_refresh'}))]])
			else: cm_extend([['exit', ('[B]Exit TV Show List[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'navigator.exit_media_menu'}))]])
			cm = self.context_menu(cm)
			listitem.setLabel(title)
			listitem.addContextMenuItems(cm)
			listitem.setArt({'poster': poster, 'fanart': fanart, 'icon': poster, 'clearlogo': clearlogo, 'landscape': landscape, 'thumb': thumb,
							'tvshow.poster': poster, 'tvshow.clearlogo': clearlogo})
			meta.update({'playcount': playcount, 'year': year, 'cast': cast})
			listitem = set_info(listitem, meta, {'imdb': imdb_id, 'tmdb': str(tmdb_id), 'tvdb': str(tvdb_id)})
			set_properties({
				'infinite.extras_params': extras_params,
				'infinite.options_params': options_params,
				'infinite.browse_recommended_params': browse_recommended_params,
				'infinite.browse_related_params': browse_related_params,
				'infinite.browse_more_like_this_params': browse_more_like_this_params,
				'infinite.browse_similar_params': browse_similar_params,
				'infinite.browse_in_trakt_list_params': browse_in_trakt_list_params,
				'infinite.trakt_manager_params': trakt_manager_params,
				'infinite.personal_manager_params': personal_manager_params,
				'infinite.tmdb_manager_params': tmdb_manager_params,
				'infinite.favorites_manager_params': favorites_manager_params
			})
			if self.fromtmbd: self.append((url, listitem, self.is_folder))
			else: self.append(((url, listitem, self.is_folder), _position))
		except: logger(f'build_tvshow_content item_position: {_position}, _id: {_id} Error: {print_exc()}')

	def worker(self):
		if self.custom_order:
			threads = TaskPool().tasks(self.build_tvshow_content, self.list, 'metacache_db')
			[i.join() for i in threads]
		else:
			threads = TaskPool().tasks_enumerate(self.build_tvshow_content, self.list, 'metacache_db')
			[i.join() for i in threads]
			self.items.sort(key=lambda k: k[1])
			self.items = [i[0] for i in self.items]
		return self.items

	def context_menu(self, context_menu_items):
		if self.custom_cm_menu:
			try: context_menu_items = sorted([i for i in context_menu_items if i[0] in self.cm_sort_order], key=lambda k: self.cm_sort_order[k[0]])
			except: pass
		return [i[1] for i in context_menu_items]

	def paginate_list(self, data, page_no):
		if paginate(self.is_external):
			limit = page_limit(self.is_external)
			data, total_pages = paginate_list(data, page_no, limit, self.paginate_start)
			if self.is_external: self.paginate_start = limit
		else: total_pages = 1
		return data, total_pages
