# -*- coding: utf-8 -*-
import sys
from threading import Thread
from apis.imdb_api import imdb_more_like_this
from indexers.movies import Movies
from indexers.tvshows import TVShows
from modules.settings import widget_hide_next_page
from modules import kodi_utils
# logger = kodi_utils.logger

def build_more_like_this(params):
	def _process(function, _list, _type):
		if not _list['list']: return
		item_list_extend(function(_list).worker())
	threads, item_list = [], []
	item_list_extend = item_list.extend
	imdb_id, title, current_cursor, page_no = params['key_id'], params['title'], params.get('end_cursor', None), int(params.get('new_page', '1'))
	handle, is_external, list_name, content = int(sys.argv[1]), kodi_utils.external(), 'More Like This based on %s' % title, 'movies'
	hide_next_page = is_external and widget_hide_next_page()
	result = imdb_more_like_this(imdb_id, current_cursor)
	movie_list = {'list': [(i['order'], i['media_id']) for i in result['results'] if i['media_type'] == 'movie'], 'id_type': 'imdb_id', 'custom_order': 'true'}
	tvshow_list = {'list': [(i['order'], i['media_id']) for i in result['results'] if i['media_type'] == 'tvshow'], 'id_type': 'imdb_id', 'custom_order': 'true'}
	content = max([('movies', len(movie_list['list'])), ('tvshows', len(tvshow_list['list']))], key=lambda k: k[1])[0]
	for item in ((Movies, movie_list, 'movies'), (TVShows, tvshow_list, 'tvshows')):
		threaded_object = Thread(target=_process, args=item)
		threaded_object.start()
		threads.append(threaded_object)
	[i.join() for i in threads]
	item_list.sort(key=lambda k: k[1])
	kodi_utils.add_items(handle, [i[0] for i in item_list])
	if result['has_next_page'] and not hide_next_page:
		new_page = str(page_no + 1)
		url_params = {'mode': 'imdb.list.build_more_like_this', 'key_id': imdb_id, 'title': title, 'end_cursor': result['end_cursor'], 'new_page': new_page}
		kodi_utils.add_dir(handle, url_params,  'Next Page (%s) >>' % new_page, 'nextpage', kodi_utils.get_icon('nextpage_landscape'))
	kodi_utils.set_content(handle, content)
	kodi_utils.set_category(handle, list_name)
	kodi_utils.end_directory(handle, cacheToDisc=False if is_external else True)
	if not is_external: kodi_utils.set_view_mode('view.%s' % content, content, is_external)