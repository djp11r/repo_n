import asyncio,json,re, time
import urllib.request
from traceback import print_stack, print_exc
from urllib.parse import urlencode,urljoin
from concurrent.futures import ThreadPoolExecutor
from modules.kodi_utils import logger,build_url,nextpage,set_info,make_listitem,add_items,set_content,end_directory,set_view_mode,notification,external,set_category, opensettings_params
from caches.main_cache import main_cache
from caches.settings_cache import get_setting
from modules.source_utils import request, fetch_meta, gettmdb_id,keepclean_title,find_season_in_title,additional_title_cleaner,get_episode_date,get_int_epi,string_date_to_num
from modules.watched_status import get_media_info,get_watched_status_movie,get_progress_status_movie,get_watched_status_episode,get_progress_status_episode
from modules.dom_parser import parseDOM
from modules.utils import clean_html

thumb=fanart='https://i.imgur.com/p18A3dF.png'
dr_url='https://desirulez.net'
run_plugin='RunPlugin(%s)'
MAX_CONCURRENCY=5
TITLE_YEAR_RE=re.compile(r'(.+?) [{(](\d{4})[})]')
YEAR_EXTRACT_RE=re.compile(r'(\d{4})')


MAX_THREADS = 8

executor = ThreadPoolExecutor(max_workers=MAX_THREADS)

def profile(label):
    def wrap(func):
        async def inner(*args, **kwargs):
            start = time.time()
            result = await func(*args, **kwargs)
            end = time.time()
            logger(f"[PROFILE] {label}: {end - start:.4f}s")
            return result
        return inner
    return wrap


async def run_limited(func, *args):
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(executor, lambda: func(*args))


async def async_request(url, timeout=15):
    loop = asyncio.get_running_loop()
    raw = await loop.run_in_executor(None, lambda: _sync_fetch(url, timeout))
    return clean_html(raw)

def _sync_fetch(url, timeout):
    try:
        return request(url, timeout=timeout)
    except:
        return ''

async def async_paginated_fetch(first_params, fetch_page_fn, max_pages=5):
    items=[]
    async with asyncio.TaskGroup() as tg:
        tasks=[tg.create_task(fetch_page_fn(first_params))]
        pages=1
        while tasks and pages<=max_pages:
            t=tasks.pop(0)
            page_items,next_params=await t
            if page_items:items.extend(page_items)
            if next_params and pages<max_pages:
                tasks.append(tg.create_task(fetch_page_fn(next_params)))
            pages+=1
    return items


def parse_movie_block_fast(block, list_name, pg_no):
    try:
        url = parseDOM(block, 'a', ret='href') or parseDOM(block,'a',attrs={'class':'title'},ret='href')
        if not url: return None
        url = url[0]
        title = None
        t = parseDOM(block,'h2',attrs={'class':'Title'})
        if t:
            title = t[0]
            year=parseDOM(block,'span',attrs={'class':'Qlty Yr'})[0]
        if not title:
            raw=parseDOM(block,'a',attrs={'class':'title'}) or parseDOM(block,'a')
            raw=raw[0]
            p=TITLE_YEAR_RE.findall(str(raw))
            if p:
                title,year=p[0]
            if not title:
                t = parseDOM(raw, 'h2', attrs={'class': 'Title'})
                if t: title = t[0]
                y=YEAR_EXTRACT_RE.search(raw)
                year=y.group() if y else None
        title=keepclean_title(title)
        if not title: return None
        if any(x in title for x in ('(Marathi)', '(Punjabi)', '+', 'season', 'episode')):  return None
        img = parseDOM(block, 'img', ret='src')
        img = img[0] if img else thumb
        tmdb_id = gettmdb_id('movie', title, year)
        try: img = parseDOM(block, 'img', ret='data-src')[0]
        except: img
        try:
            descri = parseDOM(block, 'div', attrs={'class': 'Description'})[0]
            genre = parseDOM(descri, 'p', attrs={'class': 'Genre'})
            genre = parseDOM(genre, 'a')
            cast = parseDOM(descri, 'p', attrs={'class': 'Cast'})
            cast = parseDOM(cast, 'a')
            plot = parseDOM(descri, 'p')[0]
        except: genre, cast, plot = '', '', ''
        meta = fetch_meta.fetch('movie', title, tmdb_id, url, poster=img, plot=plot, genre=genre, year=year, cast=cast)
        return {'year': meta.get('year'), 'list_name': list_name, 'url': url, 'tmdb_id': tmdb_id, 'meta': meta, 'pg_no': pg_no, 'title': title}
    except: return None


async def async_get_movies_page(params):
    _links=eval(get_setting('infinite.urls'))
    # logger(f'params: {repr(params)}\n_links: {repr(_links)}')
    url = params['url'] if (params['url']).startswith('http') else _links.get('desicinemas') + params['url']
    page=await async_request(url)
    if not page:
        url = params['url'] if (params['url']).startswith('http') else _links.get('desirulez') + params['url']
        page=await async_request(url)
    # logger(f'url: {repr(url)}')
    if not page:return[],None
    # logger(f'page: {repr(page)}')
    movies=[]
    seen = set()
    results=parseDOM(page,'li',attrs={'class':'TPostMv post-.+?'})
    if not results: results = parseDOM(page, 'h3', attrs={'class': 'threadtitle'})
    next_p=parseDOM(page,'div',attrs={'class':'nav-links'})
    if not next_p: next_p = parseDOM(page, 'span', attrs={'class': 'prev_next'})
    # Parse blocks in parallel with MAX_THREADS
    # logger(f'results: {repr(results)}')
    # logger(f'next_p: {repr(next_p)}')
    tasks = [run_limited(parse_movie_block_fast, b, 'Hindi movies', params['pg_no']) for b in results]
    parsed = await asyncio.gather(*tasks)

    for item in parsed:
        if not item: continue
        title = item['title']
        if title in seen: continue
        seen.add(title)
        movies.append(item)

    next_params=None
    if next_p:
        try:
            np=parseDOM(next_p,'a',ret='href')[-1]
            pg=re.compile(r'/([0-9]+)/').findall(np)[0]
            name=f'Next Page: {pg}'
            movies.append({'list_name':params['list_name'],'url':np,'tmdb_id':'','meta':{'poster':nextpage,'plot':f'For More: {params["list_name"]} Movies Go To: {name}','genre':['-']},'pg_no':pg,'title':name})
            next_params={'url':np,'list_name':params['list_name'],'pg_no':pg}
        except:pass
    return movies,next_params

async def async_get_movies(params):
    return await async_paginated_fetch(params,async_get_movies_page,max_pages=1)

def movies_async(params):
    loop=asyncio.new_event_loop();asyncio.set_event_loop(loop)
    data=loop.run_until_complete(async_get_movies(params))
    p=params.copy();p['async_movies']=data
    return movies_render(p)

def movies_render(params):
    params['movies_data']=params['async_movies']
    return movies(params)

def movies(params):
    from sys import argv
    handle=int(argv[1])
    movies_data=params.get('movies_data')
    if not movies_data:
        cache_name=f'movies_{urlencode(params)}'
        movies_data=main_cache.get(cache_name)
        if not movies_data:
            movies_data=asyncio.run(async_get_movies(params))
            if movies_data:main_cache.set(cache_name,movies_data,expiration=336)
    if not movies_data:
        notification(f'No movies Found for: {params["list_name"]} Retry');end_directory(handle);return
    watched_info,bookmarks=get_media_info(0,'movie')
    is_ext=external()
    def _p():
        for item in movies_data:
            try:
                li=make_listitem();setp=li.setProperties;cm=[];cma=cm.append
                title=item['title'];year=item.get('year');meta=item['meta'];mg=meta.get
                poster,tmdb_id=mg('poster'),str(mg('tvdb_id') or item.get('tmdb_id'))
                imdb_id=str(mg('imdb_id') or tmdb_id)
                play=get_watched_status_movie(watched_info,tmdb_id)
                prog=get_progress_status_movie(bookmarks,tmdb_id)
                meta.update({'mediatype':'movie','premiered':str(year),'original_title':title,'playcount':play,'url':item['url'],'fanart':poster})
                mj=json.dumps(meta)
                ids={'imdb':imdb_id,'tmdb':tmdb_id}
                li.setLabel(title.title())
                if 'Next Page:' in title:
                    u=build_url({'mode':'vod_movies','list_name':params['list_name'],'url':item['url'],'pg_no':item['pg_no'],'rescrape':'false','iconImage':params['iconImage']})
                    li.setArt({'icon':nextpage,'fanart':fanart});setp({'SpecialSort':'bottom'})
                    li=set_info(li,meta,ids);yield u,li,True;continue
                data={'mode':'playback.media','media_type':'movie','title':title,'tmdb_id':tmdb_id,'year':year,'hindi_':'true'}
                u=build_url(data)
                data['mode']='scrape_select';cma(('Select Source',run_plugin%build_url(data)))
                data['mode']='rescrape_select';cma(('Rescrape & Select Source',run_plugin%build_url(data)))
                if prog:
                    cma(('[B]Clear Progress[/B]',run_plugin%build_url({'mode':'watched_status.erase_bookmark','media_type':'movie','tmdb_id':tmdb_id,'refresh':'true','watched_indicators':'0'})))
                    setp({'WatchedProgress':prog})
                if play:
                    cma(('[B]Mark Unwatched Infinite[/B]',run_plugin%build_url({'mode':'watched_status.mark_movie','action':'mark_as_unwatched','tmdb_id':tmdb_id,'title':title,'year':year})))
                else:
                    cma(('[B]Mark Watched Infinite[/B]',run_plugin%build_url({'mode':'watched_status.mark_movie','action':'mark_as_watched','tmdb_id':tmdb_id,'title':title,'year':year})))
                ex={'mode':'extras_menu_choice','tmdb_id':tmdb_id,'media_type':'movie','meta':mj,'is_external':is_ext}
                cma(('[B]Extras[/B]',run_plugin%build_url(ex)))
                cma(('Open Settings',run_plugin%build_url(opensettings_params)))
                li.addContextMenuItems(cm)
                li.setArt({'poster':poster,'icon':poster,'thumb':poster,'clearart':poster,'fanart':fanart})
                li=set_info(li,meta,ids,prog)
                setp({'infinite.extras_params':json.dumps(ex),'IsPlayable':'false'})
                yield u,li,False
            except:pass
    add_items(handle,list(_p()))
    set_content(handle,'movies');set_category(handle,'movies')
    end_directory(handle,cacheToDisc=not is_ext)
    set_view_mode('view.movies','movies',is_ext)

def safe_parse_show_block(i):
    title = None
    genre = None

    try:
        # 1) Primary: <p class="small-title"><a>Title</a></p>
        p = parseDOM(i, 'p', attrs={'class': 'small-title'})
        if p:
            t = parseDOM(p, 'a')
            if t:
                title = t[0].strip()
        # 2) Fallback: <a class="porto-sicon-title-link">Title</a>
        if not title:
            t = parseDOM(i, 'a', attrs={'class': 'porto-sicon-title-link'})
            if t:
                title = t[0].strip()
            title_overview = parseDOM(i, 'div', attrs={'class': 'porto-sicon-header'})
            if title_overview: genre = re.findall(r'</h5>\s+(.+?)$', title_overview[0])
        # 3) Fallback: <div class="porto-sicon-header">…</div>
        if not title:
            hdr = parseDOM(i, 'div', attrs={'class': 'porto-sicon-header'})
            if hdr:
                # Try to extract title + genre from header
                m = re.findall(r'>([^<]+)</a></h5>\s*(.*?)$', hdr[0])
                if m:
                    title = m[0][0].strip()
                    genre = m[0][1].strip()
                # 4) Fallback: <h4 class="porto-sicon-title">Title</h4>
                if not title:
                    g = parseDOM(i, 'p')
                    if g: genre = g[0].strip()
                    t = parseDOM(i, 'h4', attrs={'class': 'porto-sicon-title'})
                    if t: title = t[0].strip()
        # 5) Fallback: <figcaption><a>Title</a></figcaption>
        if not title:
            fc = parseDOM(i, 'figcaption')
            if fc:
                t = parseDOM(fc, 'a')
                if t:
                    title = t[0].strip()
                    genre = t[1].strip()
                # 6) Fallback: any <a> tag
                if not title:
                    t = parseDOM(i, 'a', attrs={'class': 'title'})
                    if t: title = t[0].strip()
                    if not title: parseDOM(i, 'a')
    except Exception as e: logger(f'safe_parse_show_block item: {i}\nerror: {e}')
    return title, genre

def parse_show_block_fast(block, list_name):
    # t0 = time.time()
    try:
        url = parseDOM(block, 'a', ret='href')
        if not url: return None
        title, genre = safe_parse_show_block(block)
        if not title: return None
        url = url[0]
        img = parseDOM(block, 'img', ret='src')
        img = img[0] if img else thumb
        # if img.startswith('/images'):img=f'{s_url}{img}'
        # logger(f'img: {repr(img)}')
        season = find_season_in_title(title)
        # logger(f'season: {repr(season)}')
        tmdb_id = gettmdb_id('tvshow', title, studio=list_name)
        # logger(f'tmdb_id: {repr(tmdb_id)}')
        meta = fetch_meta.fetch('tvshow', title, tmdb_id, url, season, list_name, img, genre=genre)
        meta['season'] = season
        # logger(f'meta: {repr(meta)}')
        return {
            'url': url,
            'title': title,
            'list_name': list_name,
            'tmdb_id': tmdb_id,
            'meta': meta
        }
    except Exception as err:
        logger(f"parse_show_block_fast block: {block}\nerr: {err}\n Error: {print_stack(limit=15)}")
        return None
    # finally:
        # logger(f"[PROFILE] block parsed in {time.time() - t0:.4f}s")


# @profile("async_get_shows_page")
async def async_get_shows_page(params):
    urls=params['url'];list_name=params['list_name']
    if isinstance(urls,str):urls=eval(urls)
    parse=parseDOM;keep=keepclean_title
    shows=[];seen=set()
    # logger(f'urls: {urls}')
    for s_url in urls:
        page = await async_request(s_url)
        if not page: continue
        results=[]
        cur=parse(page,'div',attrs={'id':'tab-0-title-1'})
        if cur:
            results=parse(cur[0],'div',attrs={'class':'one_.+?'})
            if get_setting('infinite.old.hindi_shows','false')=='true':
                past=parse(page,'div',attrs={'id':'tab-1-title-2'})
                if past:results+=parse(past[0],'div',attrs={'class':'one_.+?'})
        if not results:
            results+=parse(page,'div',attrs={'class':'vc_column_container col-md-3'})
            results+=parse(page,'div',attrs={'class':'vc_column_container col-md-4'})
        if not results:
            results += parse(page,'figure',attrs={'class':'gallery-item'})

        # logger(f'results: {repr(results)}')
        if results:
            # Parse each blocks in parallel with MAX_THREADS
            tasks = [run_limited(parse_show_block_fast, b, list_name) for b in results]
            parsed = await asyncio.gather(*tasks)
            # logger(f'parsed title: {repr(parsed)}')

            for item in parsed:
                if not item: continue
                title = item['title']
                if title in seen:
                    logger(f'duplicate title: {repr(title)}')
                    continue
                seen.add(title)
                shows.append(item)
            return shows, None
    return [], None # If all URLs failed


async def async_get_shows(params):
    return await async_paginated_fetch(params,async_get_shows_page,max_pages=1)

def tv_shows_async(params):
    loop=asyncio.new_event_loop();asyncio.set_event_loop(loop)
    data=loop.run_until_complete(async_get_shows(params))
    p=params.copy();p['async_shows']=data
    return tv_shows_render(p)

def tv_shows_render(params):
    params['shows']=params['async_shows']
    return shows(params)

def shows(params):
    from sys import argv
    handle=int(argv[1])
    b_url,list_name,iconImage=params['url'],params['list_name'],params['iconImage']
    shows=params.get('shows')
    if not shows:
        cache_name=f'shows_{b_url}'
        shows=main_cache.get(cache_name)
        if not shows:
            shows=asyncio.run(async_get_shows(params))
            if shows:main_cache.set(cache_name,shows,expiration=336)
    # logger(f'shows: {repr(shows)}')
    if not shows:
        notification(f'No Shows Found for: {list_name} Retry or check the Hindi provider url.')
        end_directory(handle);return
    is_ext=external()
    def _p():
        dumps=json.dumps;make=make_listitem;build=build_url;set_info_local=set_info;fan=fanart
        for item in shows:
            try:
                u=item['url']
                if get_setting('infinite.old.hindi_shows','false')=='false' and '-archive' in u:continue
                meta=item['meta'];mg=meta.get;title=item['title']
                poster=mg('poster',iconImage);tmdb_id=mg('tmdb_id');imdb_id=mg('imdb_id');tvdb_id=mg('tmdb_id')
                season=mg('season',1);tot=mg('seasons',1);play=item.get('playcount',0)
                meta.update({'mediatype':'tvshow','playcount':play,'original_title':title,'season':season,'total_seasons':tot,'url':u,'fanart':poster,'premiered':str(mg('year'))})
                mj=dumps(meta)
                data={'mode':'vod_episode','title':title,'list_name':list_name,'url':u,'iconImage':poster,'season':season,'imdb_id':imdb_id,'tmdb_id':tmdb_id,'meta':mj,'pg_no':'1','rescrape':'false'}
                url_item=build(data)
                li=make();li.setLabel(title.title());li.setArt({'icon':poster,'poster':poster,'thumb':poster,'fanart':fan})
                cm=[];cma=cm.append
                data['rescrape']='true';cma((f'[B]Reload[/B] {title.title()}',run_plugin%build(data)))
                ex={'mode':'extras_menu_choice','tmdb_id':tmdb_id,'media_type':'tvshow','meta':mj,'is_external':is_ext}
                cma(('[B]Extras[/B]',run_plugin%build(ex)))
                cma(('[B]Add to a Shortcut Folder[/B]',run_plugin%build({'mode':'menu_editor.shortcut_folder_add_known','name':title,'iconImage':poster})))
                cma(('Open Settings',run_plugin%build(opensettings_params)))
                li.addContextMenuItems(cm,replaceItems=False)
                li=set_info_local(li,meta,{'imdb':imdb_id,'tmdb':tmdb_id,'tvdb':tvdb_id})
                li.setProperties({'infinite.extras_params':dumps(ex),'totalepisodes':str(mg('total_aired_eps') or 1),'totalseasons':str(tot),'IsPlayable':'false'})
                yield url_item,li,True
            except Exception as err: logger(f"shows item: {item}\nerr: {err}")
    add_items(handle,list(_p()))
    set_content(handle,'tvshows');set_category(handle,'tvshows')
    end_directory(handle,cacheToDisc=not is_ext)
    set_view_mode('view.main','tvshows',is_ext)


def parse_episode_block_fast(block, title, list_name, pg_no):
    try:
        if 'promo' in block or '(Day' in block: return None
        url = parseDOM(block, 'a', ret='href')
        if not url: return None
        url = url[0]
        ep_name = None
        try:
            ep_name = parseDOM(block, 'a')
            if not ep_name:
                h2 = parseDOM(block, 'h2')[0]
                ep_name = parseDOM(h2, 'a', ret='title')
            if not ep_name:
                ep_name = parseDOM(block, 'a', attrs={'class': 'title'})
                ep_name += parseDOM(block, 'a')
        except Exception as err: logger(f'i: {block} error: {err}')
        if not ep_name: return None
        ep_name = ep_name[0]
        ep_name = additional_title_cleaner(ep_name)
        if 'Episode' in ep_name or title != 'Awards': ep_name = get_episode_date(ep_name, title)
        #logger(f'2ep_name: {ep_name}')
        if '?' in url: url = url.split('?')[0]
        int_epi, year = get_int_epi(ep_name)
        premiered = string_date_to_num(ep_name)
        return {'url': url, 'title': ep_name, 'list_name': list_name, 'episode': int_epi, 'premiered': premiered, 'year': year, 'pg_no': pg_no}
    except: return None


async def async_get_episode_page(params):
    url=params['url'];title=params['title'];list_name=params['list_name'];pg_no=params.get('pg_no','1')
    eps=[];seen=set()
    page=await async_request(url)
    if not page:return eps,None
    parse=parseDOM
    results=parse(page,'div',attrs={'class':'post-details'})
    if not results:
        results+=parse(page,'article')
        results+=parse(page,'div',attrs={'class':'main-content col-lg-9'}) or parse(page,'div',attrs={'class':'blog-posts posts-large posts-container'})
    if not results:results+=parse(results,'h2',attrs={'class':'entry-title'})
    
    # Parse blocks in parallel with MAX_THREADS
    tasks = [run_limited(parse_episode_block_fast, b, title, list_name, pg_no) for b in results]
    parsed = await asyncio.gather(*tasks)

    for item in parsed:
        if not item: continue
        eps.append(item)
    next_p=parse(page,'div',attrs={'class':'nav-links'}) or parse(page,'div',attrs={'class':'pagination-wrap'}) or parse(page,'div',attrs={'class':'pages-nav'})
    next_params=None
    if next_p:
        try:
            np=parse(next_p,'a',ret='href')[-1]
            pg=re.compile(r'/([0-9]+)/').findall(np)[0]
            name=f'Next Page: {pg}'
            eps.append({'url':np,'title':name,'list_name':list_name,'episode':pg,'premiered':'','year':0,'pg_no':pg})
            next_params={'url':np,'title':title,'list_name':list_name,'pg_no':pg}
        except:pass
    return eps,next_params

async def async_get_episode(params):
    return await async_paginated_fetch(params,async_get_episode_page,max_pages=1)

def tv_episo_async(params):
    loop=asyncio.new_event_loop();asyncio.set_event_loop(loop)
    data=loop.run_until_complete(async_get_episode(params))
    p=params.copy();p['async_eps']=data
    return tv_episo_render(p)

def tv_episo_render(params):
    params['episodes_data']=params['async_eps']
    return episodes(params)

def episodes(params):
    from sys import argv
    handle=int(argv[1])
    list_items=[];append=list_items.append
    url=params['url'];rescrape=params['rescrape'];meta=json.loads(params['meta']);title=params['title'];list_name=params['list_name']
    tvdb_id=meta.get('tvdb_id');season=meta.get('season',1);tmdb_id=meta.get('tmdb_id') or tvdb_id;imdb_id=meta.get('imdb_id') or tvdb_id
    cache_name=f'episodes_{urlencode({"url":url,"pg_no":params["pg_no"]})}'
    if rescrape=='true':
        main_cache.delete_like(cache_name);episodes_data=None
    else:
        episodes_data=params.get('episodes_data') or main_cache.get(cache_name)
    if not episodes_data:
        episodes_data=asyncio.run(async_get_episode(params))
        if episodes_data:main_cache.set(cache_name,episodes_data,expiration=18)
    if not episodes_data:
        notification(f'No Episode Found for: {title} Retry or change the Hindi provider in setting.')
        end_directory(handle);return
    watched_info,bookmarks=get_media_info(0,'episode',tvdb_id,season)
    make=make_listitem;build=build_url;dumps=json.dumps;set_info_local=set_info;fan=fanart;poster=params.get('iconImage')
    for item in episodes_data:
        try:
            li=make();setp=li.setProperties;cm=[];cma=cm.append
            ep=item['title'];int_epi=int(item['episode']);year=item['year'];prem=item['premiered']
            meta.update({'mediatype':'episode','trailer':'','premiered':prem,'episode':int_epi,'year':year,'ep_name':ep,'url':item['url']})
            ids={'imdb':imdb_id,'tmdb':tmdb_id,'tvdb':tvdb_id}
            li.setLabel(ep)
            if 'Next Page:' in ep:
                u=build({'mode':'vod_episode','title':title,'list_name':list_name,'url':item['url'],'iconImage':poster,'meta':dumps(meta),'pg_no':item['pg_no'],'rescrape':'false'})
                item.update({'plot':f'For More:[CR]{title}[CR]Go To: {ep}'})
                li.setArt({'icon':nextpage,'fanart':fan});setp({'SpecialSort':'bottom'})
                li=set_info_local(li,item,ids);isfolder=True
            else:
                play=get_watched_status_episode(watched_info,(int(season),int_epi))
                prog=get_progress_status_episode(bookmarks,int_epi)
                meta.update({'playcount':play})
                data={'mode':'playback.media','media_type':'episode','tmdb_id':tmdb_id,'tvshowtitle':title,'year':year,'season':season,'episode':int_epi,'ep_name':ep,'tvdb_id':tvdb_id,'hindi_':'true'}
                u=build(data)
                data['mode']='scrape_select';cma(('Select Source',run_plugin%build(data)))
                data['mode']='rescrape_select';cma(('Rescrape & Select Source',run_plugin%build(data)))
                cma(('Open Settings',run_plugin%build(opensettings_params)))
                if prog:
                    cma(('[B]Clear Progress[/B]',run_plugin%build({'mode':'watched_status.erase_bookmark','media_type':'episode','tmdb_id':tmdb_id,'season':season,'episode':int_epi,'refresh':'true','watched_indicators':'0'})))
                    setp({'WatchedProgress':prog})
                if play:
                    cma(('[B]Mark Unwatched Infinite[/B]',run_plugin%build({'mode':'watched_status.mark_episode','action':'mark_as_unwatched','tmdb_id':tmdb_id,'tvdb_id':tvdb_id,'season':season,'episode':int_epi,'title':title})))
                else:
                    cma(('[B]Mark Watched Infinite[/B]',run_plugin%build({'mode':'watched_status.mark_episode','action':'mark_as_watched','tmdb_id':tmdb_id,'tvdb_id':tvdb_id,'season':season,'episode':int_epi,'title':title})))
                li.addContextMenuItems(cm)
                li.setArt({'poster':poster,'fanart':fan,'icon':poster,'thumb':poster,'clearart':poster})
                li=set_info_local(li,meta,ids,prog);isfolder=False
            setp({'IsPlayable':'false'})
            append({'listitem':(u,li,isfolder),'display':ep})
        except:pass
    if 'Episode' in list_items[0]['display']:list_items.sort(key=lambda x:x['display'])
    items=[i['listitem'] for i in list_items]
    is_ext=external()
    add_items(handle,items)
    set_content(handle,'episodes');set_category(handle,'episodes')
    end_directory(handle,cacheToDisc=not is_ext)
    set_view_mode('view.episode_lists','episodes',is_ext)
