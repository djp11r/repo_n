# -*- coding: utf-8 -*-

def get_years(start_year):
	from datetime import datetime
	current_year = datetime.now().year
	return [{'name': str(year), 'id': year} for year in range(current_year, start_year - 1, -1)]

def get_decades(start_decade):
	from datetime import datetime
	current_year = datetime.now().year
	current_decade = (current_year // 10) * 10
	return [{'name': '%ss' % decade, 'id': decade} for decade in range(current_decade, start_decade - 1, -10)]

def years_movies():
	return get_years(1900)

def years_tvshows():
	return get_years(1944)

def decades_movies():
	return get_decades(1900)

def decades_tvshows():
	return get_decades(1940)

def decades_():
	return [
{'name': '2030s', 'id': 2030}, {'name': '2020s', 'id': 2020}, {'name': '2010s', 'id': 2010}, {'name': '2000s', 'id': 2000}, {'name': '1990s', 'id': 1990},
{'name': '1980s', 'id': 1980}, {'name': '1970s', 'id': 1970}, {'name': '1960s', 'id': 1960}, {'name': '1950s', 'id': 1950}, {'name': '1940s', 'id': 1940},
{'name': '1930s', 'id': 1930}, {'name': '1920s', 'id': 1920}, {'name': '1910s', 'id': 1910}, {'name': '1900s', 'id': 1900}]


def oscar_winners():
	return (
{'results': [{'id': 1054867}, {'id': 1064213}, {'id': 872585}, {'id': 545611}, {'id': 776503}, {'id': 581734}, {'id': 496243}, {'id': 490132}, {'id': 399055}, {'id': 376867},
{'id': 314365}, {'id': 194662}, {'id': 76203}, {'id': 68734}, {'id': 74643}, {'id': 45269}, {'id': 12162}, {'id': 12405}, {'id': 6977}, {'id': 1422}],
'total_pages': 5, 'page': 1},
{'results': [{'id': 1640}, {'id': 70}, {'id': 122}, {'id': 1574}, {'id': 453}, {'id': 98}, {'id': 14}, {'id': 1934}, {'id': 597}, {'id': 409}, {'id': 197}, {'id': 13}, {'id': 424},
{'id': 33}, {'id': 274}, {'id': 581}, {'id': 403}, {'id': 380}, {'id': 746}, {'id': 792}],
'total_pages': 5, 'page': 2},
{'results': [{'id': 606}, {'id': 279}, {'id': 11050}, {'id': 783}, {'id': 9443}, {'id': 16619}, {'id': 12102}, {'id': 11778}, {'id': 703}, {'id': 1366}, {'id': 510}, {'id': 240},
{'id': 9277}, {'id': 238}, {'id': 1051}, {'id': 11202}, {'id': 3116}, {'id': 17917}, {'id': 10633}, {'id': 874}],
'total_pages': 5, 'page': 3},
{'results': [{'id': 15121}, {'id': 11113}, {'id': 5769}, {'id': 947}, {'id': 1725}, {'id': 284}, {'id': 665}, {'id': 17281}, {'id': 826}, {'id': 2897}, {'id': 15919}, {'id': 654},
{'id': 11426}, {'id': 27191}, {'id': 2769}, {'id': 705}, {'id': 25430}, {'id': 23383}, {'id': 33667}, {'id': 887}],
'total_pages': 5, 'page': 4},
{'results': [{'id': 28580}, {'id': 17661}, {'id': 27367}, {'id': 289}, {'id': 43266}, {'id': 223}, {'id': 770}, {'id': 34106}, {'id': 43278}, {'id': 43277}, {'id': 12311},
{'id': 3078}, {'id': 56164}, {'id': 33680}, {'id': 42861}, {'id': 143}, {'id': 65203}, {'id': 28966}, {'id': 631}],
'total_pages': 5, 'page': 5}
)

def movie_certifications():
	return [
{'name': 'G', 'id': 'G'}, {'name': 'PG', 'id': 'PG'}, {'name': 'PG-13', 'id': 'PG-13'},
{'name': 'R', 'id': 'R'}, {'name': 'NC-17', 'id': 'NC-17'}, {'name': 'NR', 'id': 'NR'}]

def tvshow_certifications():
	return [
{'name': 'TV-Y', 'id': 'tv-y'}, {'name': 'TV-Y7', 'id': 'tv-y7'}, {'name': 'TV-G', 'id': 'tv-g'},
{'name': 'TV-PG', 'id': 'tv-pg'}, {'name': 'TV-14', 'id': 'tv-14'}, {'name': 'TV-MA', 'id': 'tv-ma'}]

def languages():
	return [
{'name': 'Arabic', 'id': 'ar'}, {'name': 'Bosnian', 'id': 'bs'}, {'name': 'Bulgarian', 'id': 'bg'}, {'name': 'Chinese', 'id': 'zh'}, {'name': 'Croatian', 'id': 'hr'},
{'name': 'Dutch', 'id': 'nl'}, {'name': 'English', 'id': 'en'}, {'name': 'Finnish', 'id': 'fi'}, {'name': 'French', 'id': 'fr'}, {'name': 'German', 'id': 'de'},
{'name': 'Greek', 'id': 'el'}, {'name': 'Hebrew', 'id': 'he'}, {'name': 'Hindi', 'id': 'hi'}, {'name': 'Hungarian', 'id': 'hu'}, {'name': 'Icelandic', 'id': 'is'},
{'name': 'Italian', 'id': 'it'}, {'name': 'Japanese', 'id': 'ja'}, {'name': 'Korean', 'id': 'ko'}, {'name': 'Macedonian', 'id': 'mk'}, {'name': 'Norwegian', 'id': 'no'},
{'name': 'Persian', 'id': 'fa'}, {'name': 'Polish', 'id': 'pl'}, {'name': 'Portuguese', 'id': 'pt'}, {'name': 'Punjabi', 'id': 'pa'}, {'name': 'Romanian', 'id': 'ro'},
{'name': 'Russian', 'id': 'ru'}, {'name': 'Serbian', 'id': 'sr'}, {'name': 'Slovenian', 'id': 'sl'}, {'name': 'Spanish', 'id': 'es'}, {'name': 'Swedish', 'id': 'sv'},
{'name': 'Turkish', 'id': 'tr'}, {'name': 'Ukrainian', 'id': 'uk'}]

def language_choices():
	return {
'None': 'None', 'Afrikaans': 'afr', 'Albanian': 'alb', 'Arabic': 'ara',
'Armenian': 'arm', 'Basque': 'baq', 'Bengali': 'ben', 'Bosnian': 'bos',
'Breton': 'bre', 'Bulgarian': 'bul', 'Burmese': 'bur', 'Catalan': 'cat',
'Chinese': 'chi', 'Croatian': 'hrv', 'Czech': 'cze', 'Danish': 'dan',
'Dutch': 'dut', 'English': 'eng', 'Esperanto': 'epo', 'Estonian': 'est',
'Finnish': 'fin', 'French': 'fre', 'Galician': 'glg', 'Georgian': 'geo',
'German': 'ger', 'Greek': 'ell', 'Hebrew': 'heb', 'Hindi': 'hin',
'Hungarian': 'hun', 'Icelandic': 'ice', 'Indonesian': 'ind', 'Italian': 'ita',
'Japanese': 'jpn', 'Kazakh': 'kaz', 'Khmer': 'khm', 'Korean': 'kor',
'Latvian': 'lav', 'Lithuanian': 'lit', 'Luxembourgish': 'ltz', 'Macedonian': 'mac',
'Malay': 'may', 'Malayalam': 'mal',  'Manipuri': 'mni', 'Mongolian': 'mon',
'Montenegrin': 'mne', 'Norwegian': 'nor', 'Occitan': 'oci', 'Persian': 'per',
'Polish': 'pol', 'Portuguese': 'por', 'Portuguese(Brazil)': 'pob', 'Romanian': 'rum',
'Russian': 'rus', 'Serbian': 'scc', 'Sinhalese': 'sin', 'Slovak': 'slo',
'Slovenian': 'slv', 'Spanish': 'spa', 'Swahili': 'swa', 'Swedish': 'swe',
'Syriac': 'syr', 'Tagalog': 'tgl', 'Tamil': 'tam', 'Telugu': 'tel',
'Thai': 'tha', 'Turkish': 'tur', 'Ukrainian': 'ukr', 'Urdu': 'urd',
'Vietnamese': 'vie'}

def movie_genres():
	return [
{'name': 'Action', 'id': '28', 'icon': 'genre_action'}, {'name': 'Adventure', 'id': '12', 'icon': 'genre_adventure'}, {'name': 'Animation', 'id': '16', 'icon': 'genre_animation'},
{'name': 'Comedy', 'id': '35', 'icon': 'genre_comedy'}, {'name': 'Crime', 'id': '80', 'icon': 'genre_crime'}, {'name': 'Documentary', 'id': '99', 'icon': 'genre_documentary'},
{'name': 'Drama', 'id': '18', 'icon': 'genre_drama'}, {'name': 'Family', 'id': '10751', 'icon': 'genre_family'}, {'name': 'Fantasy', 'id': '14', 'icon': 'genre_fantasy'},
{'name': 'History', 'id': '36', 'icon': 'genre_history'}, {'name': 'Horror', 'id': '27', 'icon': 'genre_horror'}, {'name': 'Music', 'id': '10402', 'icon': 'genre_music'},
{'name': 'Mystery', 'id': '9648', 'icon': 'genre_mystery'}, {'name': 'Romance', 'id': '10749', 'icon': 'genre_romance'},
{'name': 'Science Fiction', 'id': '878', 'icon': 'genre_scifi'}, {'name': 'TV Movie', 'id': '10770', 'icon': 'genre_soap'}, {'name': 'Thriller', 'id': '53', 'icon': 'genre_thriller'},
{'name': 'War', 'id': '10752', 'icon': 'genre_war'}, {'name': 'Western', 'id': '37', 'icon': 'genre_western'}]

def tvshow_genres():
	return [
{'name': 'Action & Adventure', 'id': '10759', 'icon': 'genre_action'}, {'name': 'Animation', 'id': '16', 'icon': 'genre_animation'},
{'name': 'Comedy', 'id': '35', 'icon': 'genre_comedy'}, {'name': 'Crime', 'id': '80', 'icon': 'genre_crime'}, {'name': 'Documentary', 'id': '99', 'icon': 'genre_documentary'},
{'name': 'Drama', 'id': '18', 'icon': 'genre_drama'}, {'name': 'Family', 'id': '10751', 'icon': 'genre_family'}, {'name': 'Kids', 'id': '10762', 'icon': 'genre_kids'},
{'name': 'Mystery', 'id': '9648', 'icon': 'genre_mystery'}, {'name': 'News', 'id': '10763', 'icon': 'genre_news'}, {'name': 'Reality', 'id': '10764', 'icon': 'genre_reality'},
{'name': 'Sci-Fi & Fantasy', 'id': '10765', 'icon': 'genre_scifi'}, {'name': 'Soap', 'id': '10766', 'icon': 'genre_soap'}, {'name': 'Talk', 'id': '10767', 'icon': 'genre_talk'},
{'name': 'War & Politics', 'id': '10768', 'icon': 'genre_war'}, {'name': 'Western', 'id': '37', 'icon': 'genre_western'}]



def regions():
	return [
{'id': 'AF', 'name': 'Afghanistan'}, {'id': 'AL', 'name': 'Albania'}, {'id': 'DZ', 'name': 'Algeria'}, {'id': 'AQ', 'name': 'Antarctica'},
{'id': 'AR', 'name': 'Argentina'}, {'id': 'AM', 'name': 'Armenia'}, {'id': 'AU', 'name': 'Australia'}, {'id': 'AT', 'name': 'Austria'},
{'id': 'BD', 'name': 'Bangladesh'}, {'id': 'BY', 'name': 'Belarus'}, {'id': 'BE', 'name': 'Belgium'}, {'id': 'BR', 'name': 'Brazil'},
{'id': 'BG', 'name': 'Bulgaria'}, {'id': 'KH', 'name': 'Cambodia'}, {'id': 'CA', 'name': 'Canada'}, {'id': 'CL', 'name': 'Chile'},
{'id': 'CN', 'name': 'China'}, {'id': 'HR', 'name': 'Croatia'}, {'id': 'CZ', 'name': 'Czech Republic'}, {'id': 'DK', 'name': 'Denmark'},
{'id': 'EG', 'name': 'Germany'}, {'id': 'FI', 'name': 'France'}, {'id': 'FR', 'name': 'Finland'}, {'id': 'DE', 'name': 'Egypt'},
{'id': 'GR', 'name': 'Greece'}, {'id': 'HK', 'name': 'Hong Kong'}, {'id': 'HU', 'name': 'Hungary'}, {'id': 'IS', 'name': 'Iceland'},
{'id': 'IN', 'name': 'India'}, {'id': 'ID', 'name': 'Indonesia'}, {'id': 'IR', 'name': 'Iran'}, {'id': 'IQ', 'name': 'Iraq'},
{'id': 'IE', 'name': 'Ireland'}, {'id': 'IL', 'name': 'Israel'}, {'id': 'IT', 'name': 'Italy'}, {'id': 'JP', 'name': 'Japan'},
{'id': 'MY', 'name': 'Malaysia'}, {'id': 'NP', 'name': 'Nepal'}, {'id': 'NL', 'name': 'Netherlands'}, {'id': 'NZ', 'name': 'New Zealand'},
{'id': 'NO', 'name': 'Norway'}, {'id': 'PK', 'name': 'Pakistan'}, {'id': 'PY', 'name': 'Paraguay'}, {'id': 'PE', 'name': 'Peru'},
{'id': 'PH', 'name': 'Philippines'}, {'id': 'PL', 'name': 'Poland'}, {'id': 'PT', 'name': 'Portugal'}, {'id': 'PR', 'name': 'Puerto Rico'},
{'id': 'RO', 'name': 'Romania'}, {'id': 'RU', 'name': 'Russian Federation'},   {'id': 'SA', 'name': 'Saudi Arabia'}, {'id': 'RS', 'name': 'Serbia'},
{'id': 'SG', 'name': 'Singapore'}, {'id': 'SK', 'name': 'Slovakia'}, {'id': 'SI', 'name': 'Slovenia'}, {'id': 'ZA', 'name': 'South Africa'},
{'id': 'ES', 'name': 'Spain'}, {'id': 'LK', 'name': 'Sri Lanka'}, {'id': 'SE', 'name': 'Sweden'}, {'id': 'CH', 'name': 'Switzerland'},
{'id': 'TH', 'name': 'Thailand'}, {'id': 'TR', 'name': 'Turkey'}, {'id': 'UA', 'name': 'Ukraine'}, {'id': 'AE', 'name': 'United Arab Emirates'},
{'id': 'GB', 'name': 'United Kingdom'}, {'id': 'US', 'name': 'United States'}, {'id': 'UY', 'name': 'Uruguay'}, {'id': 'VE', 'name': 'Venezuela'},
{'id': 'VN', 'name': 'Viet Nam'}, {'id': 'YE', 'name': 'Yemen'}, {'id': 'ZW', 'name': 'Zimbabwe'}]

def networks():
	return sorted([
{'id': 54, 'name': 'Disney Channel', 'logo': 'ZCgEkp6'}, {'id': 44, 'name': 'Disney XD', 'logo': 'PAJJoqQ'}, {'id': 2, 'name': 'ABC', 'logo': 'qePLxos'},
{'id': 493, 'name': 'BBC America', 'logo': 'TUHDjfl'}, {'id': 6, 'name': 'NBC', 'logo': 'yPRirQZ'}, {'id': 13, 'name': 'Nickelodeon', 'logo': 'OUVoqYc'},
{'id': 14, 'name': 'PBS', 'logo': 'r9qeDJY'}, {'id': 16, 'name': 'CBS', 'logo': '8OT8igR'}, {'id': 19, 'name': 'FOX', 'logo': '6vc0Iov'},
{'id': 21, 'name': 'The WB', 'logo': 'rzfVME6'}, {'id': 24, 'name': 'BET', 'logo': 'ZpGJ5UQ'}, {'id': 30, 'name': 'USA Network', 'logo': 'Doccw9E'},
{'id': 23, 'name': 'CBC', 'logo': 'unQ7WCZ'}, {'id': 88, 'name': 'FX', 'logo': 'aQc1AIZ'}, {'id': 33, 'name': 'MTV', 'logo': 'QM6DpNW'},
{'id': 34, 'name': 'Lifetime', 'logo': 'tvYbhen'}, {'id': 35, 'name': 'Nick Junior', 'logo': 'leuCWYt'}, {'id': 41, 'name': 'TNT', 'logo': 'WnzpAGj'},
{'id': 43, 'name': 'National Geographic', 'logo': 'XCGNKVQ'}, {'id': 47, 'name': 'Comedy Central', 'logo': 'ko6XN77'}, {'id': 49, 'name': 'HBO', 'logo': 'Hyu8ZGq'},
{'id': 55, 'name': 'Spike', 'logo': 'BhXYytR'}, {'id': 67, 'name': 'Showtime', 'logo': 'SawAYkO'}, {'id': 56, 'name': 'Cartoon Network', 'logo': 'zmOLbbI'},
{'id': 65, 'name': 'History Channel', 'logo': 'LEMgy6n'}, {'id': 84, 'name': 'TLC', 'logo': 'c24MxaB'}, {'id': 68, 'name': 'TBS', 'logo': 'RVCtt4Z'},
{'id': 71, 'name': 'The CW', 'logo': 'Q8tooeM'}, {'id': 74, 'name': 'Bravo', 'logo': 'TmEO3Tn'}, {'id': 76, 'name': 'E!', 'logo': '3Delf9f'},
{'id': 77, 'name': 'Syfy', 'logo': '9yCq37i'}, {'id': 80, 'name': 'Adult Swim', 'logo': 'jCqbRcS'}, {'id': 91, 'name': 'Animal Planet', 'logo': 'olKc4RP'},
{'id': 110, 'name': 'CTV', 'logo': 'qUlyVHz'}, {'id': 129, 'name': 'A&E', 'logo': 'xLDfHjH'}, {'id': 158, 'name': 'VH1', 'logo': 'IUtHYzA'},
{'id': 174, 'name': 'AMC', 'logo': 'ndorJxi'}, {'id': 928, 'name': 'Crackle', 'logo': '53kqZSY'}, {'id': 202, 'name': 'WGN America', 'logo': 'TL6MzgO'},
{'id': 209, 'name': 'Travel Channel', 'logo': 'mWXv7SF'}, {'id': 213, 'name': 'Netflix', 'logo': 'jI5c3bw'}, {'id': 251, 'name': 'Audience', 'logo': '5Q3mo5A'},
{'id': 270, 'name': 'SundanceTV', 'logo': 'qldG5p2'}, {'id': 318, 'name': 'Starz', 'logo': 'Z0ep2Ru'}, {'id': 359, 'name': 'Cinemax', 'logo': 'zWypFNI'},
{'id': 364, 'name': 'truTV', 'logo': 'HnB3zfc'}, {'id': 384, 'name': 'Hallmark Channel', 'logo': 'zXS64I8'}, {'id': 397, 'name': 'TV Land', 'logo': '1nIeDA5'},
{'id': 1024, 'name': 'Amazon', 'logo': 'ru9DDlL'}, {'id': 1267, 'name': 'Freeform', 'logo': 'f9AqoHE'}, {'id': 4, 'name': 'BBC 1', 'logo': 'u8x26te'},
{'id': 332, 'name': 'BBC 2', 'logo': 'SKeGH1a'}, {'id': 3, 'name': 'BBC 3', 'logo': 'SDLeLcn'}, {'id': 100, 'name': 'BBC 4', 'logo': 'PNDalgw'},
{'id': 214, 'name': 'Sky 1', 'logo': 'xbgzhPU'}, {'id': 9, 'name': 'ITV', 'logo': '5Hxp5eA'}, {'id': 26, 'name': 'Channel 4', 'logo': '6ZA9UHR'},
{'id': 99, 'name': 'Channel 5', 'logo': '5ubnvOh'}, {'id': 136, 'name': 'E4', 'logo': 'frpunK8'}, {'id': 210, 'name': 'HGTV', 'logo': 'INnmgLT'},
{'id': 453, 'name': 'Hulu', 'logo': 'uSD2Cdw'}, {'id': 1436, 'name': 'YouTube Red', 'logo': 'ZfewP1Y'}, {'id': 64, 'name': 'Discovery Channel', 'logo': '8UrXnAB'},
{'id': 2739, 'name': 'Disney+', 'logo': 'DVrPgbM'}, {'id': 2552, 'name': 'Apple TV +', 'logo': 'fAQMVNp'}, {'id': 2697, 'name': 'Acorn TV', 'logo': 'fSWB5gB'},
{'id': 1709, 'name': 'CBS All Access', 'logo': 'ZvaWMuU'}, {'id': 3186, 'name': 'HBO Max', 'logo': 'mmRMG75'}, {'id': 2243, 'name': 'DC Universe', 'logo': 'bhWIubn'},
{'id': 2076, 'name': 'Paramount Network', 'logo': 'ez3U6NV'}, {'id': 4330, 'name': 'Paramount+', 'logo': 'dmUjWmU'}, {'id': 3353, 'name': 'Peacock', 'logo': '1JXFkSM'},
{'id': 4353, 'name': 'Discovery+', 'logo': 'ukz1nOG'}, {'id': 132, 'name': 'Oxygen', 'logo': 'uFCQvbR'}, {'id': 244, 'name': 'Discovery ID', 'logo': '07w7BER'}
	], key=lambda k: k['name'], reverse=True)

def watch_providers_movies():
	return [
{'id': 337, 'name': 'Disney Plus', 'logo': '/97yvRBw1GzX7fXprcF80er19ot.jpg'}, {'id': 3, 'name': 'Google Play Movies', 'logo': '/8z7rC8uIDaTM91X0ZfkRf04ydj2.jpg'},
{'id': 2, 'name': 'Apple TV', 'logo': '/SPnB1qiCkYfirS2it3hZORwGVn.jpg'}, {'id': 309, 'name': 'Sun Nxt', 'logo': '/6KEQzITx2RrCAQt5Nw9WrL1OI8z.jpg'},
{'id': 8, 'name': 'Netflix', 'logo': '/pbpMk2JmcoNnQwx5JGpXngfoWtp.jpg'}, {'id': 9, 'name': 'Amazon Prime Video', 'logo': '/pvske1MyAoymrs5bguRfVqYiM9a.jpg'},
{'id': 10, 'name': 'Amazon Video', 'logo': '/qR6FKvnPBx2O37FDg8PNM7efwF3.jpg'}, {'id': 100, 'name': 'GuideDoc', 'logo': '/eKVmLFHW5PeNhuR7Nedd8OIxW2M.jpg'},
{'id': 175, 'name': 'Netflix Kids', 'logo': '/kwVegvKCinXTPuzZmYT1J3i1HJz.jpg'}, {'id': 350, 'name': 'Apple TV', 'logo': '/mcbz1LgtErU9p4UdbZ0rG6RTWHX.jpg'},
{'id': 15, 'name': 'Hulu', 'logo': '/bxBlRPEPpMVDc4jMhSrTf2339DW.jpg'}, {'id': 257, 'name': 'fuboTV', 'logo': '/9BgaNQRMDvVlji1JBZi6tcfxpKx.jpg'},
{'id': 190, 'name': 'Curiosity Stream', 'logo': '/oR1aNm1Qu9jQBkW4VrGPWhqbC3P.jpg'}, {'id': 583, 'name': 'MGM+ Amazon Channel', 'logo': '/efu1Cqc63XrPBoreYnf2mn0Nizj.jpg'},
{'id': 1968, 'name': 'Crunchyroll Amazon Channel', 'logo': '/pgjz7bzfBq4nFDu8JJDLBoUVAX8.jpg'}, {'id': 386, 'name': 'Peacock Premium', 'logo': '/2aGrp1xw3qhwCYvNGAJZPdjfeeX.jpg'},
{'id': 192, 'name': 'YouTube', 'logo': '/pTnn5JwWr4p3pG8H6VrpiQo7Vs0.jpg'}, {'id': 1855, 'name': 'Starz Apple TV Channel', 'logo': '/1C5EVCWyQD798CE1DFfcm6oAbxP.jpg'},
{'id': 1854, 'name': 'AMC Plus Apple TV Channel ', 'logo': '/oTQdXIqM9iewlN4MC2nhKB0gHw.jpg'}, {'id': 430, 'name': 'HiDive', 'logo': '/iCV9oPBeoLDC5okFRZEgQkx7je0.jpg'},
{'id': 1852, 'name': 'Britbox Apple TV Channel ', 'logo': '/bzEv2wssRqVgl12IVBfYhCIvvG.jpg'}, {'id': 444, 'name': 'Dekkoo', 'logo': '/x6nRFzF32hCzMHaVM4RHRo7lsgS.jpg'},
{'id': 582, 'name': 'Paramount+ Amazon Channel', 'logo': '/hExO4PtimLIYn3kBOrzsejNv7cT.jpg'}, {'id': 457, 'name': 'VIX ', 'logo': '/jwRPknT20dfU1GeVqbcDXFyvtdG.jpg'},
{'id': 584, 'name': 'Discovery+ Amazon Channel', 'logo': '/lgudHqEtTOzkMWlpTjU1oUyoUSZ.jpg'}, {'id': 528, 'name': 'AMC+ Amazon Channel', 'logo': '/2ino0WmHA4GROB7NYKzT6PGqLcb.jpg'},
{'id': 283, 'name': 'Crunchyroll', 'logo': '/fzN5Jok5Ig1eJ7gyNGoMhnLSCfh.jpg'}, {'id': 207, 'name': 'The Roku Channel', 'logo': '/wQzSN83BnWVgO7xEh0SeTVqtrFv.jpg'},
{'id': 1853, 'name': 'Paramount Plus Apple TV Channel ', 'logo': '/tJqmTmQ8jp9WfyaZfApHK8lSywA.jpg'}, {'id': 251, 'name': 'ALLBLK', 'logo': '/4cKdiYEPW1BsWLb9UmNzAyUlD5p.jpg'},
{'id': 633, 'name': 'Paramount+ Roku Premium Channel', 'logo': '/ywIoxSjoYJGUIbR6BfxUiCHdPi3.jpg'}, {'id': 300, 'name': 'Pluto TV', 'logo': '/dB8G41Q6tSL5NBisrIeqByfepBc.jpg'},
{'id': 634, 'name': 'Starz Roku Premium Channel', 'logo': '/9laPF1MAiUxlqM8T98F3Gj0bhzd.jpg'}, {'id': 446, 'name': 'Retrocrush', 'logo': '/5zUnCq0pvixEtQafzOBBWqxNRvX.jpg'},
{'id': 635, 'name': 'AMC+ Roku Premium Channel', 'logo': '/gAGrSQCTAisxy2CsWbijVvJEnRo.jpg'}, {'id': 2285, 'name': 'JustWatch TV', 'logo': '/g2IaWyo6jCY0rIFjb4qgZ0bSmm3.jpg'},
{'id': 526, 'name': 'AMC+', 'logo': '/ovmu6uot1XVvsemM2dDySXLiX57.jpg'}, {'id': 636, 'name': 'MGM Plus Roku Premium Channel', 'logo': '/lD7HKUmXDvUya58DceiTA809Zbf.jpg'},
{'id': 188, 'name': 'YouTube Premium', 'logo': '/rMb93u1tBeErSYLv79zSTR07UdO.jpg'}, {'id': 11, 'name': 'MUBI', 'logo': '/x570VpH2C9EKDf1riP83rYc5dnL.jpg'},
{'id': 83, 'name': 'The CW', 'logo': '/spcwROYevucLluqZZ8Fv75UuTBt.jpg'}, {'id': 191, 'name': 'Kanopy', 'logo': '/rcBwnERpNfPfWB5DaSTyEMCZbCA.jpg'},
{'id': 212, 'name': 'Hoopla', 'logo': '/j7D006Uy3UWwZ6G0xH6BMgIWTzH.jpg'}, {'id': 7, 'name': 'Fandango At Home', 'logo': '/19fkcOz0xeUgCVW8tO85uOYnYK9.jpg'},
{'id': 2528, 'name': 'YouTube TV', 'logo': '/x9zOHTUkQzt3PgPVKbMH9CKBwLK.jpg'}, {'id': 43, 'name': 'Starz', 'logo': '/yIKwylTLP1u8gl84Is7FItpYLGL.jpg'},
{'id': 332, 'name': 'Fandango at Home Free', 'logo': '/19fkcOz0xeUgCVW8tO85uOYnYK9.jpg'}, {'id': 258, 'name': 'Criterion Channel', 'logo': '/yhrtzYd43pFIhRq0ruO8umJPuyn.jpg'},
{'id': 209, 'name': 'PBS', 'logo': '/iLjStQKQwzyxXJb3jyNpvDmW9mx.jpg'}, {'id': 123, 'name': 'FXNow', 'logo': '/m4KUe3UoTnLgN4g6txYMnBqeUI5.jpg'},
{'id': 2239, 'name': 'FlixHouse', 'logo': '/69eoIMVggmpyY7Aa8qeN4jsREfd.jpg'}, {'id': 80, 'name': 'AMC', 'logo': '/92Kx25Od0habmgRBTqT6XWgwgKt.jpg'},
{'id': 25, 'name': 'Fandor', 'logo': '/45lSM3J7Ts4TXTtDv0EuTPL0eH5.jpg'}, {'id': 79, 'name': 'NBC', 'logo': '/6hFf3sIdmXSAczy3i6tLSmy6gwK.jpg'},
{'id': 34, 'name': 'MGM Plus', 'logo': '/ctiRpS16dlaTXQBSsiFncMrgWmh.jpg'}, {'id': 211, 'name': 'Freeform', 'logo': '/4cHGd32hhEHmFjDGJcjVEAwFQg0.jpg'},
{'id': 2383, 'name': 'Philo', 'logo': '/ptmbGSttkyzawLbxx9MElmxKuVo.jpg'}, {'id': 156, 'name': 'A&E', 'logo': '/pA4qJFsD4lUFxJzwOE7U4FAxK7v.jpg'},
{'id': 157, 'name': 'Lifetime', 'logo': '/tWq6XvHqPjBW1BZTpf4Nziy8CDD.jpg'}, {'id': 99, 'name': 'Shudder', 'logo': '/vEtdiYRPRbDCp1Tcn3BEPF1Ni76.jpg'},
{'id': 87, 'name': 'Acorn TV', 'logo': '/doCc555FPPgGtuaZJxf9QZVpIp5.jpg'}, {'id': 143, 'name': 'Sundance Now', 'logo': '/1Edma9SrJnqkQW3BqFd2rJNHZvX.jpg'},
{'id': 151, 'name': 'BritBox', 'logo': '/8oA7IcDNNUtBa9JYB5kQ8hrDz5o.jpg'},
{'id': 268, 'name': 'History Vault', 'logo': '/z5jtxEEeJEK1kYDqbyXzfquolC9.jpg'}, {'id': 260, 'name': 'WWE Network', 'logo': '/7Wo1H7YMmRy7S56sz6HJAMYRdGq.jpg'},
{'id': 278, 'name': 'Pure Flix', 'logo': '/7L4eXQD0yFVDKZ2qwYtxcV5gm6n.jpg'}, {'id': 284, 'name': 'Lifetime Movie Club', 'logo': '/m4ofXxkTOj04N8df5KJGCIjnWii.jpg'}
	]

def watch_providers_tvshows():
	return [
{'id': 337, 'name': 'Disney Plus', 'logo': '/97yvRBw1GzX7fXprcF80er19ot.jpg'}, {'id': 3, 'name': 'Google Play Movies', 'logo': '/8z7rC8uIDaTM91X0ZfkRf04ydj2.jpg'},
{'id': 2, 'name': 'Apple TV', 'logo': '/SPnB1qiCkYfirS2it3hZORwGVn.jpg'}, {'id': 309, 'name': 'Sun Nxt', 'logo': '/6KEQzITx2RrCAQt5Nw9WrL1OI8z.jpg'},
{'id': 8, 'name': 'Netflix', 'logo': '/pbpMk2JmcoNnQwx5JGpXngfoWtp.jpg'}, {'id': 9, 'name': 'Amazon Prime Video', 'logo': '/pvske1MyAoymrs5bguRfVqYiM9a.jpg'},
{'id': 10, 'name': 'Amazon Video', 'logo': '/qR6FKvnPBx2O37FDg8PNM7efwF3.jpg'}, {'id': 175, 'name': 'Netflix Kids', 'logo': '/kwVegvKCinXTPuzZmYT1J3i1HJz.jpg'},
{'id': 350, 'name': 'Apple TV', 'logo': '/mcbz1LgtErU9p4UdbZ0rG6RTWHX.jpg'}, {'id': 15, 'name': 'Hulu', 'logo': '/bxBlRPEPpMVDc4jMhSrTf2339DW.jpg'},
{'id': 257, 'name': 'fuboTV', 'logo': '/9BgaNQRMDvVlji1JBZi6tcfxpKx.jpg'}, {'id': 190, 'name': 'Curiosity Stream', 'logo': '/oR1aNm1Qu9jQBkW4VrGPWhqbC3P.jpg'},
{'id': 583, 'name': 'MGM+ Amazon Channel', 'logo': '/efu1Cqc63XrPBoreYnf2mn0Nizj.jpg'}, {'id': 1968, 'name': 'Crunchyroll Amazon Channel', 'logo': '/pgjz7bzfBq4nFDu8JJDLBoUVAX8.jpg'},
{'id': 386, 'name': 'Peacock Premium', 'logo': '/2aGrp1xw3qhwCYvNGAJZPdjfeeX.jpg'}, {'id': 192, 'name': 'YouTube', 'logo': '/pTnn5JwWr4p3pG8H6VrpiQo7Vs0.jpg'},
{'id': 1855, 'name': 'Starz Apple TV Channel', 'logo': '/1C5EVCWyQD798CE1DFfcm6oAbxP.jpg'}, {'id': 191, 'name': 'Kanopy', 'logo': '/rcBwnERpNfPfWB5DaSTyEMCZbCA.jpg'},
{'id': 1854, 'name': 'AMC Plus Apple TV Channel ', 'logo': '/oTQdXIqM9iewlN4MC2nhKB0gHw.jpg'}, {'id': 528, 'name': 'AMC+ Amazon Channel', 'logo': '/2ino0WmHA4GROB7NYKzT6PGqLcb.jpg'},
{'id': 1852, 'name': 'Britbox Apple TV Channel ', 'logo': '/bzEv2wssRqVgl12IVBfYhCIvvG.jpg'},{'id': 283, 'name': 'Crunchyroll', 'logo': '/fzN5Jok5Ig1eJ7gyNGoMhnLSCfh.jpg'},
{'id': 582, 'name': 'Paramount+ Amazon Channel', 'logo': '/hExO4PtimLIYn3kBOrzsejNv7cT.jpg'},{'id': 207, 'name': 'The Roku Channel', 'logo': '/wQzSN83BnWVgO7xEh0SeTVqtrFv.jpg'},
{'id': 584, 'name': 'Discovery+ Amazon Channel', 'logo': '/lgudHqEtTOzkMWlpTjU1oUyoUSZ.jpg'}, {'id': 2285, 'name': 'JustWatch TV', 'logo': '/g2IaWyo6jCY0rIFjb4qgZ0bSmm3.jpg'},
{'id': 1853, 'name': 'Paramount Plus Apple TV Channel ', 'logo': '/tJqmTmQ8jp9WfyaZfApHK8lSywA.jpg'}, {'id': 526, 'name': 'AMC+', 'logo': '/ovmu6uot1XVvsemM2dDySXLiX57.jpg'},
{'id': 633, 'name': 'Paramount+ Roku Premium Channel', 'logo': '/ywIoxSjoYJGUIbR6BfxUiCHdPi3.jpg'}, {'id': 188, 'name': 'YouTube Premium', 'logo': '/rMb93u1tBeErSYLv79zSTR07UdO.jpg'},
{'id': 634, 'name': 'Starz Roku Premium Channel', 'logo': '/9laPF1MAiUxlqM8T98F3Gj0bhzd.jpg'}, {'id': 11, 'name': 'MUBI', 'logo': '/x570VpH2C9EKDf1riP83rYc5dnL.jpg'},
{'id': 635, 'name': 'AMC+ Roku Premium Channel', 'logo': '/gAGrSQCTAisxy2CsWbijVvJEnRo.jpg'}, {'id': 83, 'name': 'The CW', 'logo': '/spcwROYevucLluqZZ8Fv75UuTBt.jpg'},
{'id': 636, 'name': 'MGM Plus Roku Premium Channel', 'logo': '/lD7HKUmXDvUya58DceiTA809Zbf.jpg'},{'id': 212, 'name': 'Hoopla', 'logo': '/j7D006Uy3UWwZ6G0xH6BMgIWTzH.jpg'},
{'id': 7, 'name': 'Fandango At Home', 'logo': '/19fkcOz0xeUgCVW8tO85uOYnYK9.jpg'}, {'id': 2528, 'name': 'YouTube TV', 'logo': '/x9zOHTUkQzt3PgPVKbMH9CKBwLK.jpg'},
{'id': 43, 'name': 'Starz', 'logo': '/yIKwylTLP1u8gl84Is7FItpYLGL.jpg'}, {'id': 332, 'name': 'Fandango at Home Free', 'logo': '/19fkcOz0xeUgCVW8tO85uOYnYK9.jpg'},
{'id': 258, 'name': 'Criterion Channel', 'logo': '/yhrtzYd43pFIhRq0ruO8umJPuyn.jpg'}, {'id': 209, 'name': 'PBS', 'logo': '/iLjStQKQwzyxXJb3jyNpvDmW9mx.jpg'},
{'id': 123, 'name': 'FXNow', 'logo': '/m4KUe3UoTnLgN4g6txYMnBqeUI5.jpg'}, {'id': 80, 'name': 'AMC', 'logo': '/92Kx25Od0habmgRBTqT6XWgwgKt.jpg'},
{'id': 79, 'name': 'NBC', 'logo': '/6hFf3sIdmXSAczy3i6tLSmy6gwK.jpg'}, {'id': 34, 'name': 'MGM Plus', 'logo': '/ctiRpS16dlaTXQBSsiFncMrgWmh.jpg'},
{'id': 211, 'name': 'Freeform', 'logo': '/4cHGd32hhEHmFjDGJcjVEAwFQg0.jpg'}, {'id': 2383, 'name': 'Philo', 'logo': '/ptmbGSttkyzawLbxx9MElmxKuVo.jpg'},
{'id': 156, 'name': 'A&E', 'logo': '/pA4qJFsD4lUFxJzwOE7U4FAxK7v.jpg'}, {'id': 157, 'name': 'Lifetime', 'logo': '/tWq6XvHqPjBW1BZTpf4Nziy8CDD.jpg'},
{'id': 99, 'name': 'Shudder', 'logo': '/vEtdiYRPRbDCp1Tcn3BEPF1Ni76.jpg'}, {'id': 87, 'name': 'Acorn TV', 'logo': '/doCc555FPPgGtuaZJxf9QZVpIp5.jpg'},
{'id': 143, 'name': 'Sundance Now', 'logo': '/1Edma9SrJnqkQW3BqFd2rJNHZvX.jpg'}, {'id': 151, 'name': 'BritBox', 'logo': '/8oA7IcDNNUtBa9JYB5kQ8hrDz5o.jpg'},
{'id': 251, 'name': 'ALLBLK', 'logo': '/4cKdiYEPW1BsWLb9UmNzAyUlD5p.jpg'}, {'id': 264, 'name': 'MyOutdoorTV', 'logo': '/bSmoVepHvK0ijBAWGx3QlIeTtsu.jpg'},
{'id': 260, 'name': 'WWE Network', 'logo': '/7Wo1H7YMmRy7S56sz6HJAMYRdGq.jpg'}, {'id': 278, 'name': 'Pure Flix', 'logo': '/7L4eXQD0yFVDKZ2qwYtxcV5gm6n.jpg'},
{'id': 293, 'name': 'PBS Kids Amazon Channel', 'logo': '/lIXDKV7LrZfF3SR2m8EQrMVRI5C.jpg'}, {'id': 289, 'name': 'Cinemax Amazon Channel', 'logo': '/ohcwolMl8E743CkS8MnhmJKOlRj.jpg'},
{'id': 290, 'name': 'Hallmark+ Amazon Channel', 'logo': '/wVxA3Rw87917VEXChiVKZpXUjSm.jpg'}, {'id': 2129, 'name': 'BYUtv', 'logo': '/9YYuvhTfMuBR7keJ7DPa1GFlDrF.jpg'},
{'id': 294, 'name': 'PBS Masterpiece Amazon Channel', 'logo': '/xN1vKpcypShJrWmf1t3dyGJM7sO.jpg'}, {'id': 300, 'name': 'Pluto TV', 'logo': '/dB8G41Q6tSL5NBisrIeqByfepBc.jpg'},
{'id': 291, 'name': 'MZ Choice Amazon Channel', 'logo': '/hTAIgvUnmu1Yv0wFVJRu9KKAPtJ.jpg'}, {'id': 430, 'name': 'HiDive', 'logo': '/iCV9oPBeoLDC5okFRZEgQkx7je0.jpg'},
{'id': 457, 'name': 'VIX ', 'logo': '/jwRPknT20dfU1GeVqbcDXFyvtdG.jpg'}, {'id': 446, 'name': 'Retrocrush', 'logo': '/5zUnCq0pvixEtQafzOBBWqxNRvX.jpg'},
{'id': 444, 'name': 'Dekkoo', 'logo': '/x6nRFzF32hCzMHaVM4RHRo7lsgS.jpg'}, {'id': 439, 'name': 'Shout! Factory TV', 'logo': '/y9jFndski0fRO4MHh3yg5PIL9ZI.jpg'},
{'id': 438, 'name': 'Chai Flicks', 'logo': '/qesugDq8sUCixmOOsqDM1xAnBYz.jpg'}, {'id': 427, 'name': 'Mhz Choice', 'logo': '/tnxLjN2lLYpkTIX8NPSId6bgqh8.jpg'},
{'id': 204, 'name': 'Shudder Amazon Channel', 'logo': '/qb6Lj5BhNJavdmRVDzAqAjd4Tj3.jpg'}, {'id': 458, 'name': 'Vice TV ', 'logo': '/zU75skIWNQ06SeFkmbFoaqhg069.jpg'},
{'id': 201, 'name': 'MUBI Amazon Channel', 'logo': '/a4IDLKjvP5gvq7tNlg2Xw5YyEkI.jpg'}, {'id': 196, 'name': 'AcornTV Amazon Channel', 'logo': '/1wYmvbAuVZz2JnKvYfYN8Qolnb.jpg'},
{'id': 197, 'name': 'BritBox Amazon Channel', 'logo': '/49qepIM2KqtRwENEmfskTGShD7G.jpg'}, {'id': 199, 'name': 'Fandor Amazon Channel', 'logo': '/3eVIcUeRXji5SBV7gEv4f5U4CqV.jpg'},
{'id': 202, 'name': 'Screambox Amazon Channel', 'logo': '/vmXC3D9Kqtt9TEohDEmcaxnLYA5.jpg'}, {'id': 318, 'name': 'Adult Swim', 'logo': '/da2dkyeFe4GCRaKxpsW4mzt2UPl.jpg'},
{'id': 205, 'name': 'Sundance Now Amazon Channel', 'logo': '/i8PzzzOVJfXWLE1v5Up7nGTWWhp.jpg'}, {'id': 328, 'name': 'Fox', 'logo': '/fpLJgEK68o2ATtz2gEdYkevUYIF.jpg'},
{'id': 331, 'name': 'FlixFling', 'logo': '/yFGu4sSzwUMfhwmSsZgez8QhaVl.jpg'}, {'id': 235, 'name': 'YouTube Free', 'logo': '/4tJBhJcuF1ZstI5Yqu82G0yroLa.jpg'},
{'id': 343, 'name': 'Bet+ Amazon Channel', 'logo': '/2AvUqoIHAq2lLxRy2IxOBUgCYef.jpg'}, {'id': 344, 'name': 'Rakuten Viki', 'logo': '/73uV3YooOA8gD9YQTXFj2XakZWA.jpg'},
{'id': 365, 'name': 'Bravo TV', 'logo': '/uGOba5AB0URrJd5gelWGinaVR2h.jpg'}, {'id': 363, 'name': 'TNT', 'logo': '/76CvnJAKAPbJuiXYwQGN7PFqOci.jpg'},
{'id': 366, 'name': 'Food Network', 'logo': '/b5umeBN4kFf5KJ6FZiBkftA4q5q.jpg'}, {'id': 397, 'name': 'BBC America', 'logo': '/jfXLhMzHHmBYrtE9ZaW7as2RA98.jpg'},
{'id': 412, 'name': 'TLC', 'logo': '/veArLGnRXZEGkjpkJrhfMeasODk.jpg'}, {'id': 406, 'name': 'HGTV', 'logo': '/5Vp8QzvrVsWDIBWgoTm0cNdeSgc.jpg'},
{'id': 408, 'name': 'Investigation Discovery', 'logo': '/1oxTHsIcxJwVcubHLnHwl0g60EI.jpg'}, {'id': 411, 'name': 'Science Channel', 'logo': '/28cQ8Ux0pauEHyeZ7J9MTNF4RBP.jpg'},
{'id': 399, 'name': 'Animal Planet', 'logo': '/uW87WpK4Zfz4zCf224vvFhn3ZJc.jpg'}, {'id': 403, 'name': 'Discovery', 'logo': '/w8uX5FHY01CmODT0QvGv5CBGbPS.jpg'},
{'id': 413, 'name': 'Travel Channel', 'logo': '/8NwVgZlX4Nh3WCebkaKtbSmdDn1.jpg'}, {'id': 417, 'name': 'Here TV', 'logo': '/kiNWL1wGBg3z2FBXJcd8R8MaZrV.jpg'},
{'id': 422, 'name': 'VH1', 'logo': '/zH8mZ7YV2WHuVuLyOjtnIjar3Zn.jpg'}, {'id': 263, 'name': 'DreamWorksTV Amazon Channel', 'logo': '/hDoYXuGJtGwpvgPjmgx4jQFil01.jpg'},
{'id': 506, 'name': 'TBS', 'logo': '/cZvP3XsDKlHFhNIyHYCVPStXT5l.jpg'}, {'id': 514, 'name': 'AsianCrush', 'logo': '/jCgWMxqGaq0h0VOxyJPfQdTqmii.jpg'},
{'id': 473, 'name': 'Revry', 'logo': '/llQ8zV50Wqh4gYCYfr52R1b9gfD.jpg'}, {'id': 475, 'name': 'DOCSVILLE', 'logo': '/5zqbck5mo8PuVbGu2ngBUdn5Yga.jpg'},
{'id': 486, 'name': 'Spectrum On Demand', 'logo': '/aAb9CUHjFe9Y3O57qnrJH0KOF1B.jpg'}, {'id': 507, 'name': 'tru TV', 'logo': '/mMJ6AQUpHDsD5s2Q2dnbpX1NFwp.jpg'},
{'id': 508, 'name': 'DisneyNOW', 'logo': '/d8HzRaIa5aGE5mJB1SsIA9hODdx.jpg'}, {'id': 509, 'name': 'WeTV', 'logo': '/9abwIEW9wZ12RavyKnInlK684xm.jpg'},
{'id': 538, 'name': 'Plex', 'logo': '/vLZKlXUNDcZR7ilvfY9Wr9k80FZ.jpg'}, {'id': 2077, 'name': 'Plex Channel', 'logo': '/27WMfRN7pQE3j5Khm8fPM7vYyLV.jpg'},
{'id': 546, 'name': 'WOW Presents Plus', 'logo': '/6dET59jNU0ADysghEjl8Unuc7Ca.jpg'}, {'id': 551, 'name': 'Magellan TV', 'logo': '/mSH24WQcRDJ2fsL5iucXqqRnSRb.jpg'},
{'id': 555, 'name': 'The Oprah Winfrey Network', 'logo': '/z4MqXgpzqxVy7GF8mlPOe8VOx82.jpg'}, {'id': 575, 'name': 'OnDemandKorea', 'logo': '/gR8rrj71VCLjlF1LJpplo72MXf0.jpg'},
{'id': 2308, 'name': 'Darkroom', 'logo': '/8G7qvHF7hdmXpfxxqtF1WT9ib68.jpg'}, {'id': 315, 'name': 'Hoichoi', 'logo': '/u7dwMceEbjxd1N3TLEUBILSK2x6.jpg'},
{'id': 581, 'name': 'iQIYI', 'logo': '/c4eVkfMna2VzHzZ8N2vWXUnMrlD.jpg'}, {'id': 613, 'name': 'Amazon Prime Video Free with Ads', 'logo': '/gZlCYHPx9a0TRUCEeTvHXBf9ibX.jpg'},
{'id': 2411, 'name': 'Eternal Family', 'logo': '/in4AaJPqO6wCquDcXsirin7UQBb.jpg'}, {'id': 2409, 'name': 'Fawesome', 'logo': '/pSUa7lMYLoQAU00ikXoHxmOfTZ9.jpg'},
{'id': 692, 'name': 'Cultpix', 'logo': '/uauVx3dGWt0GICqdMCBYJObd3Mo.jpg'}, {'id': 701, 'name': 'FilmBox+', 'logo': '/fbveJTcro9Xw2KuPIIoPPePHiwy.jpg'},
{'id': 532, 'name': 'aha', 'logo': '/8WerMI8XcZXqPpkHTZNtzMzousF.jpg'}, {'id': 1794, 'name': 'Starz Amazon Channel', 'logo': '/esiLBRzDUwodjfN8gA4qj7l3ZF7.jpg'}
	]

def movie_sorts():
	return [
{'name': 'Popularity (asc)', 'id': '&sort_by=popularity.asc'}, {'name': 'Popularity (desc)', 'id': '&sort_by=popularity.desc'},
{'name': 'Release Date (asc)', 'id': '&sort_by=primary_release_date.asc'}, {'name': 'Release Date (desc)', 'id': '&sort_by=primary_release_date.desc'},
{'name': 'Total Revenue (asc)', 'id': '&sort_by=revenue.asc'}, {'name': 'Total Revenue (desc)', 'id': '&sort_by=revenue.desc'},
{'name': 'Title (asc)', 'id': '&sort_by=original_title.asc'}, {'name': 'Title (desc)', 'id': '&sort_by=original_title.desc'},
{'name': 'Rating (asc)', 'id': '&sort_by=vote_average.asc'}, {'name': 'Rating (desc)', 'id': '&sort_by=vote_average.desc'},
{'name': 'Random', 'id': '[random]'}]

def tvshow_sorts():
	return [
{'name': 'Popularity (asc)', 'id': '&sort_by=popularity.asc'}, {'name': 'Popularity (desc)', 'id': '&sort_by=popularity.desc'},
{'name': 'First Aired (asc)', 'id': '&sort_by=first_air_date.asc'}, {'name': 'First Aired (desc)', 'id': '&sort_by=first_air_date.desc'},
{'name': 'Rating (asc)', 'id': '&sort_by=vote_average.asc'}, {'name': 'Rating (desc)', 'id': '&sort_by=vote_average.desc'},
{'name': 'Random', 'id': '[random]'}]

def discover_items():
	return {
'with_year_start': {'label': 'Year Start', 'key': 'with_year_start', 'display_key': 'with_year_start_display', 'action': 'years',
'url_insert_movie': '&primary_release_date.gte=%s-01-01', 'url_insert_tvshow': '&first_air_date.gte=%s-01-01', 'name_value': ' | %s onwards', 'icon': 'calender'},
'with_year_end': {'label': 'Year End', 'key': 'with_year_end', 'display_key': 'with_year_end_display', 'action': 'years',
'url_insert_movie': '&primary_release_date.lte=%s-12-31', 'url_insert_tvshow': '&first_air_date.lte=%s-12-31', 'name_value': ' | up to %s', 'icon': 'calender'},
'with_genres': {'label': 'With Genres', 'key': 'with_genres', 'display_key': 'with_genres_display', 'action': 'genres',
'url_insert': '&with_genres=%s', 'name_value': ' | %s', 'icon': 'genres'},
'without_genres': {'label': 'Without Genres', 'key': 'without_genres', 'display_key': 'without_genres_display', 'action': 'genres',
'url_insert': '&without_genres=%s', 'name_value': ' | exclude %s', 'icon': 'genres'},
'with_network': {'label': 'Network', 'key': 'with_network', 'display_key': 'with_network_display', 'action': 'network',
'url_insert': '&with_networks=%s', 'name_value': ' | %s', 'limited': 'tvshow', 'icon': 'networks'},
'with_provider': {'label': 'Provider', 'key': 'with_provider', 'display_key': 'with_provider_display', 'action': 'provider',
'url_insert': '&with_watch_providers=%s', 'name_value': ' | %s', 'icon': 'providers'},
'with_certification': {'label': 'Certification', 'key': 'with_certification', 'display_key': 'with_certification_display', 'action': 'certifications',
'url_insert': '&certification_country=US&certification=%s', 'name_value': ' | %s', 'limited': 'movie', 'icon': 'certifications'},
'with_certification_and_lower': {'label': 'Certification (& lower)', 'key': 'with_certification_and_lower', 'display_key': 'with_certification_and_lower_display',
'action': 'certification_and_lowers', 'url_insert': '&certification_country=US&certification.lte=%s', 'name_value': ' | %s', 'limited': 'movie', 'icon': 'certifications'},
'with_language': {'label': 'Language', 'key': 'with_language', 'display_key': 'with_language_display', 'action': 'languages',
'url_insert': '&with_original_language=%s', 'name_value': ' | %s', 'icon': 'languages'},	
'with_keywords': {'label': 'With Keywords', 'key': 'with_keywords', 'display_key': 'with_keywords_display', 'action': 'keywords',
'url_insert': '&with_keywords=%s', 'name_value': ' | Keywords: %s', 'icon': 'fantasy'},
'with_rating': {'label': 'Minimum Rating', 'key': 'with_rating', 'display_key': 'with_rating_display', 'action': 'ratings',
'url_insert': '&vote_average.gte=%s', 'name_value': ' | %s+', 'icon': 'most_watched'},
'with_rating_votes': {'label': 'Minimum Number of Votes', 'key': 'with_rating_votes', 'display_key': 'with_rating_votes_display', 'action': 'votes',
'url_insert': '&vote_count.gte=%s', 'name_value': ' | %s votes', 'icon': 'most_voted'},
'with_cast': {'label': 'Include Cast', 'key': 'with_cast', 'display_key': 'with_cast_display', 'action': 'casts',
'url_insert': '&with_cast=%s', 'name_value': ' | with %s', 'limited': 'movie', 'icon': 'people'},
'with_sort': {'label': 'Sort By', 'key': 'with_sort', 'display_key': 'with_sort_display', 'action': 'sort',
'url_insert': '%s', 'name_value': ' | %s', 'icon': 'lists'},
'with_released': {'label': 'Released Only', 'key': 'with_released', 'display_key': 'with_released_display', 'action': 'released',
'url_insert_movie': '&primary_release_date.lte=%s', 'url_insert_tvshow': '&include_null_first_air_dates=false&first_air_date.lte=%s', 'name_value': ' | Released Only', 'icon': 'dvd'},
'with_adult': {'label': 'Include Adult', 'key': 'with_adult', 'display_key': 'with_adult_display', 'action': 'adult',
'url_insert': '&include_adult=%s', 'name_value': ' | Include Adult', 'limited': 'movie', 'icon': 'romance'},}

def color_palette():
	return [
'FFFFFFE3', 'FFFFFAE6', 'FFFEF5E6', 'FFFEF0E5', 'FFFEEBE5', 'FFFFEFEF', 'FFFFE6EA', 'FFFFE6F1', 'FFFEE6F4', 'FFFFE6FB', 'FFFEE6FE', 'FFFAE6FF', 'FFF4E6FF', 'FFF0E6FF', 'FFEAE7FC',
'FFE6E7FC', 'FFE6EBFF', 'FFE7F0FF', 'FFE7F5FF', 'FFE7FAFF', 'FFE6FFFF', 'FFE6FFFB', 'FFE7FEF4', 'FFE7FFF1', 'FFE6FFEA', 'FFE7FFE7', 'FFEBFFF3', 'FFF1FFE6', 'FFF5FFE6', 'FFFBFFE6',
'FFFFFFFF', 'FFFFFFCB', 'FFFEFACA', 'FFFFEACB', 'FFFFE0CC', 'FFFED6CC', 'FFFFCACD', 'FFFFCCD5', 'FFFFCDE0', 'FFFFCCEB', 'FFFFCBF5', 'FFFECCFD', 'FFF6CBFF', 'FFECCCFE', 'FFE0CCFF',
'FFD6CCFE', 'FFCCCCFE', 'FFCDD6FF', 'FFCAE1FF', 'FFCCEBFF', 'FFCEF4FD', 'FFCAFFFF', 'FFCCFFF6', 'FFCBFEEB', 'FFCCFFE0', 'FFCCFFD6', 'FFCDFFCC', 'FFD7FFCB', 'FFE1FFCD', 'FFEBFFCC',
'FFF5FFCB', 'FFEFEFEF', 'FFFEFFB3', 'FFFFF1B2', 'FFFFE0B2', 'FFFDD2B2', 'FFFFC2B3', 'FFFFB3B3', 'FFFFB2C2', 'FFFFB3D1', 'FFFFB3E1', 'FFFFB2F4', 'FFFFB3FE', 'FFF0B3FF', 'FFE1B2FF',
'FFD2B3FF', 'FFC1B3FE', 'FFB4B3FF', 'FFB3C1FE', 'FFB2D1FF', 'FFB3E0FF', 'FFB2F0FF', 'FFB3FFFF', 'FFB3FFF0', 'FFB4FFE0', 'FFB3FFD1', 'FFB4FEC3', 'FFB3FFB4', 'FFC2FFB2', 'FFD1FFB4',
'FFE0FFB3', 'FFF1FFB4', 'FFE0E0E0', 'FFFEFF99', 'FFFFEB9A', 'FFFED699', 'FFFFC299', 'FFFFAD98', 'FFFF9899', 'FFFF99AE', 'FFFF99C1', 'FFFE99D5', 'FFFF99EC', 'FFFF99FF', 'FFEB99FF',
'FFD699FF', 'FFC299FF', 'FFAE99FF', 'FF9A99FF', 'FF98ADFE', 'FF9AC2FF', 'FF98D6FF', 'FF99EBFF', 'FF99FFFF', 'FF99FFEA', 'FF99FFD7', 'FF9AFFC3', 'FF99FFAC', 'FF99FF99', 'FFADFF99',
'FFC2FF98', 'FFD6FF99', 'FFEAFF98', 'FFD0D0D0', 'FFFFFF80', 'FFFFE681', 'FFFFCC80', 'FFFFB381', 'FFFF9980', 'FFFE8081', 'FFFF8199', 'FFFF80B3', 'FFFF80CD', 'FFFF80E7', 'FFFC81FE',
'FFE680FF', 'FFCC7FFF', 'FFB380FF', 'FF9980FF', 'FF807FFE', 'FF8099FE', 'FF7FB3FF', 'FF80CCFE', 'FF80E6FF', 'FF7FFFFE', 'FF7FFEE0', 'FF80FFCC', 'FF80FFB2', 'FF80FF98', 'FF81FF81',
'FF99FF80', 'FFB3FF80', 'FFCCFF80', 'FFE6FF80', 'FFC0C0C0', 'FFFFFF6B', 'FFFEE066', 'FFFFC267', 'FFFFA366', 'FFFF8566', 'FFFF6766', 'FFFF6685', 'FFFF66A4', 'FFFF66C1', 'FFFF66E0',
'FFFF66FF', 'FFE166FF', 'FFC366FF', 'FFA366FF', 'FF8566FF', 'FF6665FE', 'FF6785FF', 'FF66A3FE', 'FF65C2FF', 'FF65E0FF', 'FF65FFFF', 'FF66FFE0', 'FF65FFC1', 'FF66FFA4', 'FF65FF85',
'FF66FF66', 'FF84FF66', 'FFA2FF66', 'FFC2FF66', 'FFE0FF66', 'FFAFAFAF', 'FFFFFF4D', 'FFFFDB4E', 'FFFFB84E', 'FFFF944C', 'FFFF714D', 'FFFF4D4D', 'FFFF4D6F', 'FFFE4D93', 'FFFE4DB7',
'FFFE4DDB', 'FFFF4DFF', 'FFDC4DFF', 'FFB84DFF', 'FF944EFF', 'FF704DFF', 'FF4D4CFF', 'FF4D70FE', 'FF4D94FE', 'FF4DB8FF', 'FF4DDBFF', 'FF4DFFFF', 'FF4DFFDB', 'FF4EFFB9', 'FF4EFF95',
'FF4DFE70', 'FF4CFF4C', 'FF70FF4D', 'FF94FF4D', 'FFB8FE4D', 'FFDAFF4D', 'FF8C8C8C', 'FFFFFF33', 'FFFFD634', 'FFFFAD33', 'FFFF8532', 'FFFF5C33', 'FFFF3334', 'FFFF335C', 'FFFF3287',
'FFFF33AE', 'FFFF33D6', 'FFFE33FF', 'FFD633FE', 'FFAD34FF', 'FF8534FF', 'FF5D33FF', 'FF3233FF', 'FF325CFE', 'FF3285FF', 'FF33ADFF', 'FF33D6FF', 'FF33FFFE', 'FF32FFD6', 'FF34FFAD',
'FF33FF84', 'FF32FF5C', 'FF34FF33', 'FF5CFF34', 'FF85FE33', 'FFADFE33', 'FFD5FF33', 'FF7C7C7C', 'FFFFFF19', 'FFFFD119', 'FFFFA418', 'FFFF751A', 'FFFF4719', 'FFFF1919', 'FFFF1947',
'FFFF1874', 'FFFF19A3', 'FFFF19D1', 'FFFF19FF', 'FFD019FF', 'FFA219FF', 'FF751AFE', 'FF4719FF', 'FF1819FF', 'FF1947FF', 'FF1974FF', 'FF19A3FE', 'FF18D1FF', 'FF19FFFF', 'FF19FFD1',
'FF19FFA4', 'FF18FF75', 'FF19FF47', 'FF19FF19', 'FF48FF19', 'FF76FF19', 'FFA3FE1A', 'FFD1FF19', 'FF6B6B6B', 'FFFFFF00', 'FFFFCC00', 'FFFE9900', 'FFFF6600', 'FFFF3300', 'FFFE0000',
'FFFE0032', 'FFFF0066', 'FFFF0198', 'FFFF00CC', 'FFFF00FE', 'FFCC00FF', 'FF9A00FF', 'FF6601FF', 'FF3300FF', 'FF0000FE', 'FF0033FF', 'FF0166FF', 'FF0097FE', 'FF00CCFF', 'FF00FFFF',
'FF01FFCD', 'FF00FF99', 'FF00FE67', 'FF00FF33', 'FF00FF01', 'FF33FF00', 'FF65FF00', 'FF99FE00', 'FFCCFF00', 'FF5D5D5D', 'FFE8E500', 'FFE6B800', 'FFE68B00', 'FFE65C01', 'FFE72E00',
'FFE60000', 'FFE6002E', 'FFE6005B', 'FFE80183', 'FFE600B8', 'FFE600E6', 'FFB700E6', 'FF8900E6', 'FF5C01E5', 'FF2E00E6', 'FF0000E6', 'FF012EE1', 'FF005BE7', 'FF008AE5', 'FF00B8E6',
'FF00E6E6', 'FF00E6B7', 'FF00E78B', 'FF00E65F', 'FF00E532', 'FF00E600', 'FF2FE600', 'FF5DE600', 'FF8AE501', 'FFB8E600', 'FF4F4F4F', 'FFCDCC00', 'FFCDA301', 'FFCA7B02', 'FFCC5200',
'FFCC2900', 'FFCC0001', 'FFCD0029', 'FFCE0052', 'FFCC007B', 'FFCD00A3', 'FFCB00CC', 'FFA300CB', 'FF7A01CC', 'FF5201CC', 'FF2A00D0', 'FF0000CC', 'FF0029CB', 'FF0052CC', 'FF007ACD',
'FF00A3CC', 'FF00CCCB', 'FF00CCA3', 'FF01CC7A', 'FF03CB51', 'FF00CC29', 'FF01CC00', 'FF29CC01', 'FF52CB00', 'FF7ACB00', 'FFA2CC00', 'FF434343', 'FFB4B300', 'FFB38E00', 'FFB36B00',
'FFB34700', 'FFB32501', 'FFB30101', 'FFB40025', 'FFB40047', 'FFB4006B', 'FFB5008B', 'FFB300B3', 'FF8F00B2', 'FF6B00B2', 'FF4700B4', 'FF2300B2', 'FF0000B2', 'FF0025B4', 'FF0047B3',
'FF006BB3', 'FF008EB2', 'FF00B3B2', 'FF00B38E', 'FF00B36C', 'FF00B346', 'FF00B324', 'FF00B300', 'FF24B301', 'FF47B200', 'FF6CB201', 'FF90B301', 'FF373737', 'FF999A00', 'FF987A00',
'FF995C01', 'FF9A3D00', 'FF9A1F00', 'FF990100', 'FF99001F', 'FF9A003E', 'FF99005B', 'FF9A007A', 'FF990099', 'FF7B0099', 'FF5D0099', 'FF3D0099', 'FF1F0099', 'FF000098', 'FF011F99',
'FF003D98', 'FF005C99', 'FF007A99', 'FF009999', 'FF00997A', 'FF00995B', 'FF00993E', 'FF00991F', 'FF009900', 'FF1E9900', 'FF3C9900', 'FF5C9900', 'FF7A9900', 'FF2E2E2E', 'FF7F8000',
'FF7F6601', 'FF804C00', 'FF803201', 'FF801A01', 'FF800000', 'FF800019', 'FF800033', 'FF80004B', 'FF810065', 'FF81007F', 'FF660080', 'FF4C007F', 'FF33007F', 'FF1A0080', 'FF010080',
'FF011A7F', 'FF003480', 'FF004C80', 'FF00667F', 'FF008081', 'FF008067', 'FF037F4B', 'FF008033', 'FF00801B', 'FF008001', 'FF1A8000', 'FF338000', 'FF4C8001', 'FF668100', 'FF242424',
'FF656600', 'FF675201', 'FF653D00', 'FF672900', 'FF661400', 'FF660000', 'FF660015', 'FF660028', 'FF65003C', 'FF660053', 'FF660066', 'FF550069', 'FF3D0067', 'FF290066', 'FF150067',
'FF010066', 'FF001465', 'FF012966', 'FF003D66', 'FF005267', 'FF006766', 'FF006651', 'FF00663E', 'FF01662A', 'FF006613', 'FF006600', 'FF146600', 'FF296600', 'FF3D6600', 'FF516600',
'FF181818', 'FF4B4C00', 'FF4C3E01', 'FF4D2E00', 'FF4C1F00', 'FF4D0F00', 'FF4C0000', 'FF4C000F', 'FF4B001F', 'FF4C002E', 'FF4C003E', 'FF4C004B', 'FF3D004D', 'FF2E004B', 'FF1F004C',
'FF0E004B', 'FF01004C', 'FF000E4B', 'FF001F4D', 'FF012E4D', 'FF003D4C', 'FF004C4C', 'FF004D3D', 'FF004C2E', 'FF004C1E', 'FF004C0E', 'FF004C01', 'FF0F4C00', 'FF204C01', 'FF2D4C00',
'FF3E4C01', 'FF000000']

def moods():
	return {
	'Restless & Hyperactive': {
		'High-Octane Blockbusters':
			{'description': 'You want a frantic heart rate, non-stop stunts, and massive cinematic momentum.',
			'thematic_anchors': ['car chases', 'high-speed racing', 'massive explosions', 'stunt-heavy set pieces'],
			'tonal_profile': ['adrenaline-fueled', 'fast-paced', 'spectacular', 'relentless'],
			'cinematic_benchmarks': ['Mad Max: Fury Road (2015)', 'Mission: Impossible - Fallout (2018)', 'Speed (1994)']},
		'Aggressive & Cathartic':
			{'description': 'Release bottled-up anger or frustration watching raw, bone-crunching physical combat.',
			'thematic_anchors': ['hand-to-hand combat', 'martial arts brawls', 'close-quarters violence', 'visceral choreography'],
			'tonal_profile': ['brutal', 'raw', 'intense', 'gritty', 'uncompromising'],
			'cinematic_benchmarks': ['John Wick (2014)', 'The Raid: Redemption (2011)', 'Fight Club (1999)']},
		'Competitive Rivalry':
			{'description': 'Feel driven by the intense stakes of winning, losing, tournaments, and underdogs.',
			'thematic_anchors': ['sports tournaments', 'bitter rivalries', 'underdog arcs', 'championship finals'],
			'tonal_profile': ['motivational', 'triumphant', 'high-stakes', 'passionate'],
			'cinematic_benchmarks': ['Whiplash (2014)', 'Warrior (2011)', 'Rush (2013)']},
		'Outlaw Escapism':
			{'description': 'Channel your rule-breaking energy into fast-paced, high-stakes heist thrillers and criminal runs.',
			'thematic_anchors': ['bank robberies', 'elaborate heists', 'getaway driving', 'criminal syndicates'],
			'tonal_profile': ['slick', 'thrilling', 'rebellious', 'clever', 'fast-moving'],
			'cinematic_benchmarks': ['Baby Driver (2017)', 'Heat (1995)', 'Ocean\'s Eleven (2001)']},
		'Unstoppable One-Man Army':
			{'description': 'Feel powerful and deeply confident tracking an unstoppable badass righting wrongs against impossible odds.',
			'thematic_anchors': ['lone vigilantes', 'elite assassins', 'retribution runs', 'one-vs-many combat'],
			'tonal_profile': ['empowering', 'badass', 'confident', 'ruthless'],
			'cinematic_benchmarks': ['Taken (2008)', 'The Equalizer (2014)', 'Man on Fire (2004)']},
		'Vengeful Payback':
			{'description': 'Harbor some spite and watch scores get settled with ruthless, calculated precision.',
			'thematic_anchors': ['vendettas', 'calculated revenge plots', 'score-settling', 'vigilante justice'],
			'tonal_profile': ['spiteful', 'calculated', 'cold', 'satisfying', 'grim'],
			'cinematic_benchmarks': ['Kill Bill: Vol. 1 (2003)', 'Promising Young Woman (2020)', 'The Count of Monte Cristo (2002)']},
		'High-Stakes Survival':
			{'description': 'Match your internal jitteriness with a nail-biting ticking clock and life-or-death survival scenarios.',
			'thematic_anchors': ['ticking-clock scenarios', 'trapped characters', 'hostage situations', 'countdown devices'],
			'tonal_profile': ['suspenseful', 'claustrophobic', 'frantic', 'anxiety-inducing'],
			'cinematic_benchmarks': ['Uncut Gems (2019)', 'Captain Phillips (2013)', '127 Hours (2010)']},
		'Kinetic Sensory Overload':
			{'description': 'Drown out your thoughts with chaotic, hyper-fast pacing and vibrant, stylized audio-visual frenzy.',
			'thematic_anchors': ['stylised audio-visuals', 'hyper-fast editing', 'neon aesthetics', 'frenetic pacing'],
			'tonal_profile': ['manic', 'vibrant', 'chaotic', 'dazzling', 'psychedelic'],
			'cinematic_benchmarks': ['Everything Everywhere All at Once (2022)', 'Spider-Man: Into the Spider-Verse (2018)', 'Crank (2006)']},
		'Dystopian Rebellion':
			{'description': 'Defy corrupt power structures and fight back against an oppressive, high-tech establishment.',
			'thematic_anchors': ['cyberpunk landscapes', 'anti-establishment uprisings', 'totalitarian regimes', 'underground resistance'],
			'tonal_profile': ['defiant', 'revolutionary', 'futuristic', 'gritty'],
			'cinematic_benchmarks': ['The Matrix (1999)', 'V for Vendetta (2005)', 'The Hunger Games (2012)']},
		'Mindless Popcorn Fun':
			{'description': 'Completely switch off your brain with campy, loud, high-energy disaster and monster spectacles.',
			'thematic_anchors': ['creature features', 'alien invasions', 'global disasters', 'city-level destruction'],
			'tonal_profile': ['campy', 'fun', 'loud', 'escapist', 'unpretentious'],
			'cinematic_benchmarks': ['Godzilla vs. Kong (2021)', 'Independence Day (1996)', '2012 (2009)']}
	},
	'Joyful & Comfort Seeking': {
		'Serene & Cozy':
			{'description': 'You want a warm blanket for the soul—low stakes, gentle humor, and maximum comfort.',
			'thematic_anchors': ['low stakes plots', 'slow-paced living', 'gentle humor', 'heartwarming slice-of-life'],
			'tonal_profile': ['cozy', 'wholesome', 'peaceful', 'charming', 'soothing'],
			'cinematic_benchmarks': ['Paddington 2 (2017)', 'Amélie (2001)', 'My Neighbor Totoro (1988)']},
		'Charming Rom-Coms':
			{'description': 'You want lighthearted romantic butterfly feelings, witty banter, and happy endings.',
			'thematic_anchors': ['witty banter', 'meet-cutes', 'romantic gestures', 'happily-ever-afters'],
			'tonal_profile': ['lighthearted', 'romantic', 'sparkling', 'sweet', 'flirtatious'],
			'cinematic_benchmarks': ['About Time (2013)', 'The Proposal (2009)', 'Notting Hill (1999)']},
		'Whimsical & Magical':
			{'description': 'Escape into a playful, imaginative world full of lighthearted wonder and quirky charm.',
			'thematic_anchors': ['playful magic', 'fairytale worlds', 'eccentric characters', 'childlike wonder'],
			'tonal_profile': ['whimsical', 'quirky', 'imaginative', 'fanciful', 'magical'],
			'cinematic_benchmarks': ['The Princess Bride (1987)', 'Hugo (2011)', 'Stardust (2007)']},
		'Heartwarming Coming-of-Age':
			{'description': 'Immerse yourself in the sweet, nostalgic safety of childhood memories and growing up.',
			'thematic_anchors': ['nostalgic settings', 'childhood friendships', 'retro eras', 'sentimental milestones'],
			'tonal_profile': ['nostalgic', 'sentimental', 'bittersweet', 'innocent', 'warm'],
			'cinematic_benchmarks': ['Stand by Me (1986)', 'The Way Way Back (2013)', 'Coda (2021)']},
		'Uplifting & Hopeful':
			{'description': 'You need a gentle, comforting reminder that kindness exists and humanity is inherently good.',
			'thematic_anchors': ['acts of kindness', 'emotional healing', 'second chances', 'unconditional compassion'],
			'tonal_profile': ['hopeful', 'positive', 'healing', 'profound', 'moving'],
			'cinematic_benchmarks': ['Ted Lasso (2020)', 'The Intouchables (2011)', 'Won\'t You Be My Neighbor? (2018)']},
		'Wholesome Found Family':
			{'description': 'Feel the warm embrace of tight-knit bonds, deep friendships, and absolute loyalty.',
			'thematic_anchors': ['found family tropes', 'unbreakable friendships', 'camaraderie', 'misfits banding together'],
			'tonal_profile': ['heartwarming', 'loyal', 'supportive', 'affectionate', 'comforting'],
			'cinematic_benchmarks': ['Parks and Recreation (2009)', 'Little Miss Sunshine (2006)', 'Brooklyn Nine-Nine (2013)']},
		'Amused & Ridiculous':
			{'description': 'You just want to switch off and laugh out loud at silly, goofy, low-effort nonsense.',
			'thematic_anchors': ['slapstick comedy', 'absurd scenarios', 'goofy gags', 'parodies and spoofs'],
			'tonal_profile': ['silly', 'goofy', 'hilarious', 'absurd', 'unpretentious'],
			'cinematic_benchmarks': ['Step Brothers (2008)', 'The Naked Gun (1988)', 'Airplane! (1980)']},
		'Triumph of the Spirit':
			{'description': 'Feel deeply motivated and inspired by characters overcoming adversity to achieve their dreams.',
			'thematic_anchors': ['overcoming adversity', 'underdog victories', 'pursuing dreams', 'inspiring true stories'],
			'tonal_profile': ['motivational', 'triumphant', 'inspiring', 'empowering', 'passionate'],
			'cinematic_benchmarks': ['The Pursuit of Happyness (2006)', 'Hidden Figures (2016)', 'Rocky (1976)']},
		'Tight-Knit Communities':
			{'description': 'Spend time in a comforting, familiar world centered around workplace antics or small-town life.',
			'thematic_anchors': ['small-town dynamics', 'workplace antics', 'eccentric neighbors', 'familiar recurring settings'],
			'tonal_profile': ['comforting', 'familiar', 'community-focused', 'witty'],
			'cinematic_benchmarks': ['Schitt\'s Creek (2015)', 'Gilmore Girls (2000)', 'The Office (2005)']},
		'Carefree Escapism':
			{'description': 'Ditch your responsibilities for a lighthearted, fun-filled journey, summer vacation, or road trip.',
			'thematic_anchors': ['summer vacations', 'road trips', 'lighthearted journeys', 'sun-drenched locations'],
			'tonal_profile': ['carefree', 'adventurous', 'vibrant', 'escapist', 'fun-filled'],
			'cinematic_benchmarks': ['Mamma Mia! (2008)', 'The Secret Life of Walter Mitty (2013)', 'Chef (2014)']}
	},
	'Sad & Introspective': {
		'Haunting Melancholy':
			{'description': 'You are navigating profound grief or loss and just need an atmospheric space to cry it out.',
			'thematic_anchors': ['profound grief', 'navigating loss', 'family tragedies', 'funerals and mourning'],
			'tonal_profile': ['melancholic', 'devastating', 'somber', 'heartbreaking', 'cathartic'],
			'cinematic_benchmarks': ['Manchester by the Sea (2016)', 'Ordinary People (1980)', 'Three Colors: Blue (1993)']},
		'Heartbroken Romances':
			{'description': 'Lean into the sharp, raw sting of romantic rejection, devastating breakups, or unrequited love.',
			'thematic_anchors': ['painful breakups', 'unrequited love', 'divorce and separation', 'fading relationships'],
			'tonal_profile': ['raw', 'unforgiving', 'romantically devastating', 'aching', 'bleak'],
			'cinematic_benchmarks': ['Blue Valentine (2010)', 'Marriage Story (2019)', 'Past Lives (2023)']},
		'Isolated & Disconnected':
			{'description': 'Find comfort and visibility in quiet stories of deep loneliness, alienation, and social disconnect.',
			'thematic_anchors': ['social isolation', 'profound loneliness', 'urban alienation', 'misunderstood outsiders'],
			'tonal_profile': ['lonely', 'detached', 'quiet', 'alienated', 'melancholic'],
			'cinematic_benchmarks': ['Her (2013)', 'Lost in Translation (2003)', 'Taxi Driver (1976)']},
		'Melancholic Sci-Fi':
			{'description': 'Ponder your purpose and the meaning of existence against a lonely, cold, or futuristic reality.',
			'thematic_anchors': ['existential dread', 'artificial intelligence loneliness', 'cosmic isolation', 'technological alienation'],
			'tonal_profile': ['existential', 'philosophical', 'cold', 'stark', 'introspective'],
			'cinematic_benchmarks': ['Blade Runner 2049 (2017)', 'Melancholia (2011)', 'Moon (2009)']},
		'Bittersweet Longing':
			{'description': 'Indulge in a beautiful, aching nostalgia for lost loves, missed opportunities, and times gone by.',
			'thematic_anchors': ['lost loves', 'missed opportunities', 'reminiscing on the past', 'yearning and nostalgia'],
			'tonal_profile': ['bittersweet', 'poignant', 'nostalgic', 'aching', 'romantic'],
			'cinematic_benchmarks': ['In the Mood for Love (2000)', 'Before Sunset (2004)', 'Brokeback Mountain (2005)']},
		'Poetic Slow Cinema':
			{'description': 'You feel completely drained and want a quiet, low-stimulus, deeply intimate character study.',
			'thematic_anchors': ['minimalist dialogue', 'meditative pacing', 'intimate character studies', 'subtle human interactions'],
			'tonal_profile': ['quiet', 'meditative', 'slow', 'minimalist', 'stark'],
			'cinematic_benchmarks': ['Drive My Car (2021)', 'Nomadland (2020)', 'Perfect Days (2023)']},
		'Haunted by the Past':
			{'description': 'Dwell quietly with characters frozen by intense regret, heavy guilt, and painful "what ifs."',
			'thematic_anchors': ['crushing guilt', 'secret shame', 'painful memories', 'unresolved mistakes'],
			'tonal_profile': ['haunted', 'regretful', 'repressed', 'tense', 'grim'],
			'cinematic_benchmarks': ['The Whispering Chorus (1918)', 'The Master (2012)', 'A History of Violence (2005)']},
		'Sombre Noir & Mystery':
			{'description': 'Sit quietly with a heavy, cold, rain-slicked atmosphere defined by bleak environments and moral decay.',
			'thematic_anchors': ['rain-slicked streets', 'cynical investigators', 'moral ambiguity', 'bleak urban landscapes'],
			'tonal_profile': ['cynical', 'bleak', 'cold', 'atmospheric', 'moody'],
			'cinematic_benchmarks': ['Se7en (1995)', 'Zodiac (2007)', 'Prisoners (2013)']},
		'Tragic Real-Life Stories':
			{'description': 'Walk intimately in the shoes of real historical figures enduring heartbreaking, monumental struggles.',
			'thematic_anchors': ['historical tragedies', 'war-time survival', 'biographical struggles', 'monumental human endurance'],
			'tonal_profile': ['profound', 'authentic', 'harrowing', 'dignified', 'heavy'],
			'cinematic_benchmarks': ['Schindler\'s List (1993)', '12 Years a Slave (2013)', 'The Pianist (2002)']},
		'Somber Melodies':
			{'description': 'Lose yourself in the bittersweet, melancholic world of troubled artists, musicians, and poetic struggles.',
			'thematic_anchors': ['troubled musicians', 'tortured artists', 'the cost of fame', 'creative self-destruction'],
			'tonal_profile': ['poetic', 'haunting', 'creative', 'obsessive', 'bittersweet'],
			'cinematic_benchmarks': ['Inside Llewyn Davis (2013)', 'Amadeus (1984)', 'Walk the Line (2005)']}
	},
	'Dreamy & Sensory Driven': {
		'Surreal Dream-Logic':
			{'description': 'Surrender your rational mind to hypnotic illusions, subconscious visions, and logic-bending journeys.',
			'thematic_anchors': ['subconscious visions', 'metaphorical journeys', 'non-linear storytelling', 'bizarre logic'],
			'tonal_profile': ['hypnotic', 'surreal', 'disorienting', 'dreamlike', 'hallucinatory'],
			'cinematic_benchmarks': ['Mulholland Drive (2001)', 'Inception (2010)', 'Eternal Sunshine of the Spotless Mind (2004)']},
		'Sleek Neon Noir':
			{'description': 'Immerse yourself in a ultra-stylised, dark, rain-slicked world of brooding loners and glowing city streets.',
			'thematic_anchors': ['neon aesthetics', 'rain-slicked streets', 'brooding antiheroes', 'underworld syndicates'],
			'tonal_profile': ['slick', 'atmospheric', 'moody', 'electronic', 'cynical'],
			'cinematic_benchmarks': ['Drive (2011)', 'Blade Runner (1982)', 'Chongqing Express (1994)']},
		'Eerie & Supernatural Creep':
			{'description': 'Seek out a quiet, skin-crawling gothic chill full of hidden curses, historic mansions, and creeping dread.',
			'thematic_anchors': ['gothic mansions', 'ancestral curses', 'ghostly apparitions', 'forbidden folklore'],
			'tonal_profile': ['unsettling', 'creepy', 'foreboding', 'gothic', 'sinister'],
			'cinematic_benchmarks': ['The Others (2001)', 'Crimson Peak (2015)', 'The Innocents (1961)']},
		'Sun-Drenched Memories':
			{'description': 'Drift aimlessly through hazy, warm summer memory sequences and beautiful romantic nostalgia.',
			'thematic_anchors': ['golden hour cinematography', 'summer romances', 'poetic memory sequences', 'hazy nostalgia'],
			'tonal_profile': ['sun-drenched', 'wistful', 'romantic', 'hazy', 'poetic'],
			'cinematic_benchmarks': ['Call Me by Your Name (2017)', 'The Virgin Suicides (1999)', 'Before Sunrise (1995)']},
		'Stark Minimalist Solitude':
			{'description': 'Escape to wide, clean, empty landscapes and isolated environments where silence dominates the frame.',
			'thematic_anchors': ['barren snowscapes', 'vast desert expanses', 'isolated characters', 'minimal dialogue'],
			'tonal_profile': ['stark', 'minimalist', 'remote', 'quiet', 'desolate'],
			'cinematic_benchmarks': ['Fargo (1996)', 'The Revenant (2015)', 'Paris, Texas (1984)']},
		'Psychedelic Mind-Melts':
			{'description': 'Intoxicate your vision with vibrant, kaleidoscopic colors, altered states of consciousness, and vivid hallucinations.',
			'thematic_anchors': ['altered states of consciousness', 'vivid hallucinations', 'kaleidoscopic color palettes', 'mind-bending imagery'],
			'tonal_profile': ['psychedelic', 'vibrant', 'trippy', 'manic', 'dazzling'],
			'cinematic_benchmarks': ['Enter the Void (2009)', 'Fear and Loathing in Las Vegas (1998)', 'Paprika (2006)']},
		'Dark Passion & Macabre Romance':
			{'description': 'Indulge in a morbid, deeply intense, and beautifully tragic romance dripping with gothic drama.',
			'thematic_anchors': ['morbid obsessions', 'vampiric lore', 'forbidden attraction', 'tragic romantic endings'],
			'tonal_profile': ['macabre', 'sensual', 'dark', 'intense', 'melodramatic'],
			'cinematic_benchmarks': ['Bram Stoker\'s Dracula (1992)', 'Only Lovers Left Alive (2013)', 'Phantom Thread (2017)']},
		'Cosmic & Space-Bound Dreams':
			{'description': 'Feel beautifully weightless and infinitely small drifting through stargazing, interstellar space-travel narratives.',
			'thematic_anchors': ['interstellar travel', 'cosmic silence', 'weightless drifting', 'existential stargazing'],
			'tonal_profile': ['cosmic', 'majestic', 'weightless', 'profound', 'ethereal'],
			'cinematic_benchmarks': ['2001: A Space Odyssey (1968)', 'Interstellar (2014)', 'Ad Astra (2019)']},
		'Atmospheric Slow-Burn Horror':
			{'description': 'Let yourself be slowly pulled under by a heavy, inescapable, cult-like mood with zero cheap jump scares.',
			'thematic_anchors': ['creeping dread', 'pagan or folk cults', 'unsettling isolation', 'inescapable heavy atmosphere'],
			'tonal_profile': ['slow-burn', 'oppressive', 'visceral', 'disturbing', 'hypnotic'],
			'cinematic_benchmarks': ['Midsommar (2019)', 'The Witch (2015)', 'The Shining (1980)']},
		'Ethereal High Adventures':
			{'description': 'Embark on sweeping, visually spectacular fantasy quests through unmapped, mythic, and breathtaking nature.',
			'thematic_anchors': ['sweeping fantasy quests', 'breathtaking natural landscapes', 'ancient civilizations', 'mythic journeys'],
			'tonal_profile': ['ethereal', 'majestic', 'epic', 'wondrous', 'spectacular'],
			'cinematic_benchmarks': ['The Lord of the Rings: The Fellowship of the Ring (2001)', 'Avatar (2009)', 'Princess Mononoke (1997)']}
	},
	'Curious & Intellectual': {
		'Morally Conflicted Dilemmas':
			{'description': 'Debate what is right and wrong with characters forced into impossible ethical choices.',
			'thematic_anchors': ['impossible ethical choices', 'moral grey areas', 'unintended consequences', 'crisis of conscience'],
			'tonal_profile': ['thought-provoking', 'tense', 'analytical', 'compromising'],
			'cinematic_benchmarks': ['Sophie\'s Choice (1982)', 'A Separation (2011)', 'Gone Baby Gone (2007)']},
		'Deep-Dive Psychological Profiles':
			{'description': 'Peel back the layers of complex, brilliant, or deeply flawed minds in intimate character studies.',
			'thematic_anchors': ['brilliant but flawed minds', 'uncompromising obsession', 'intimate character studies', 'eccentric geniuses'],
			'tonal_profile': ['intense', 'deeply psychological', 'fascinating', 'uncompromising'],
			'cinematic_benchmarks': ['There Will Be Blood (2007)', 'The Social Network (2010)', 'Tár (2022)']},
		'Conspiracy & Whistleblowers':
			{'description': 'Question authority and follow paranoiac paths to uncover hidden corporate or government cover-ups.',
			'thematic_anchors': ['government cover-ups', 'corporate whistleblowers', 'systemic paranoia', 'uncovering hidden truths'],
			'tonal_profile': ['paranoid', 'suspenseful', 'cynical', 'urgent'],
			'cinematic_benchmarks': ['All the President\'s Men (1976)', 'The Insider (1999)', 'Spotlight (2015)']},
		'Cerebral Crime Chronicles':
			{'description': 'Piece together intricate psychological and criminal puzzles where the intellect is the primary weapon.',
			'thematic_anchors': ['psychological profiling', 'serial killer behavioral analysis', 'fbi procedurals', 'intellectual cat-and-mouse games'],
			'tonal_profile': ['clinical', 'dark', 'methodical', 'intellectual'],
			'cinematic_benchmarks': ['Mindhunter (2017)', 'The Silence of the Lambs (1991)', 'Memories of Murder (2003)']},
		'Inquisitive Investigative Mysteries':
			{'description': 'Step into the shoes of a determined detective or journalist piecing together a real-world puzzle.',
			'thematic_anchors': ['journalistic investigation', 'uncovering puzzles', 'dogged investigative reporting', 'unravelling intricate clues'],
			'tonal_profile': ['methodical', 'engrossing', 'determined', 'grounded'],
			'cinematic_benchmarks': ['Zodiac (2007)', 'Chinatown (1974)', 'Knives Out (2019)']},
		'Philosophical Thought Experiments':
			{'description': 'Challenge your core assumptions about humanity, perception, and reality with deeply cerebral narratives.',
			'thematic_anchors': ['existential thought experiments', 'challenging perceptions of reality', 'nature of humanity', 'metaphysical paradoxes'],
			'tonal_profile': ['cerebral', 'philosophical', 'profound', 'perceptive'],
			'cinematic_benchmarks': ['The Truman Show (1998)', 'Synecdoche, New York (2008)', 'The Seventh Seal (1957)']},
		'Courtroom & Legal Battles':
			{'description': 'Weigh raw evidence and watch razor-sharp legal minds debate fairness, law, and ultimate justice.',
			'thematic_anchors': ['high-stakes legal trials', 'courtroom cross-examinations', 'debating legal fairness', 'unravelling raw evidence'],
			'tonal_profile': ['sharp', 'dramatic', 'eloquent', 'gripping'],
			'cinematic_benchmarks': ['12 Angry Men (1957)', 'A Few Good Men (1992)', 'Anatomy of a Fall (2023)']},
		'Cutting-Edge Tech Ethics':
			{'description': 'Ponder hard logic, artificial intelligence, and the deep ethical consequences of rapid human advancement.',
			'thematic_anchors': ['artificial intelligence consciousness', 'technological ethics', 'hard scientific logic', 'human advancement consequences'],
			'tonal_profile': ['clinical', 'futuristic', 'cautionary', 'sleek'],
			'cinematic_benchmarks': ['Ex Machina (2014)', 'Her (2013)', 'Black Mirror (2011)']},
		'Spiritually Searching':
			{'description': 'Grapple with deep questions of faith, existential doubt, theological mystery, and the human soul.',
			'thematic_anchors': ['existential faith crisis', 'theological mystery', 'grappling with the human soul', 'religious devotion and doubt'],
			'tonal_profile': ['spiritual', 'reverent', 'searching', 'profound'],
			'cinematic_benchmarks': ['First Reformed (2017)', 'The Tree of Life (2011)', 'Silence (2016)']},
		'Sociopolitical Commentary':
			{'description': 'Absorb the raw, thought-provoking realities of deep cultural divides, wealth inequality, and class struggles.',
			'thematic_anchors': ['wealth inequality', 'class warfare dynamics', 'sociopolitical satire', 'systemic cultural divides'],
			'tonal_profile': ['sharp', 'satirical', 'uncomfortable', 'revealing'],
			'cinematic_benchmarks': ['Parasite (2019)', 'Triangle of Sadness (2022)', 'Snowpiercer (2013)']}
	},
	'Time Travelling Escapism': {
		'Regal & Elite':
			{'description': 'You want to feel the opulence and high-society drama of royalty.',
			'thematic_anchors': ['royal court intrigue', 'monarchies and empires', 'palace life', 'aristocratic power struggles'],
			'tonal_profile': ['opulent', 'dramatic', 'stately', 'prestigious'],
			'cinematic_benchmarks': ['The Crown (2016)', 'The Favourite (2018)', 'The King\'s Speech (2010)']},
		'Gritty & Primal':
			{'description': 'You want to strip away modern life for mud, swords, and survival.',
			'thematic_anchors': ['medieval combat', 'castle sieges', 'brutal survival instincts', 'feudal warrior culture'],
			'tonal_profile': ['brutal', 'visceral', 'muddy', 'raw', 'uncompromising'],
			'cinematic_benchmarks': ['The Northman (2022)', 'Gladiator (2000)', 'The Last Kingdom (2015)']},
		'Gilded Glamour & High Society':
			{'description': 'Escape into a world of dazzling wealth, lavish parties, and elite social scandals.',
			'thematic_anchors': ['high society scandals', 'lavish costume balls', 'generational wealth', 'forbidden class romance'],
			'tonal_profile': ['glamorous', 'scandalous', 'lavish', 'elegant'],
			'cinematic_benchmarks': ['Downton Abbey (2010)', 'The Great Gatsby (2013)', 'Bridgerton (2020)']},
		'Swashbuckling & High Adventure':
			{'description': 'You want the classic romantic thrill of high-seas voyages, hidden treasure, and daring escapes.',
			'thematic_anchors': ['high-seas seafaring voyages', 'hidden treasure maps', 'pirate lore', 'daring high-stakes escapes'],
			'tonal_profile': ['adventurous', 'thrilling', 'romantic', 'escapist'],
			'cinematic_benchmarks': ['Pirates of the Caribbean: The Curse of the Black Pearl (2003)', 'Master and Commander (2003)', 'Black Sails (2014)']},
		'Lawless & Untamed':
			{'description': 'You want to escape into a wild, unmapped frontier where raw survival and grit rule the land.',
			'thematic_anchors': ['wild west frontiers', 'bounty hunting runs', 'outlaw syndicates', 'desert ranch skirmishes'],
			'tonal_profile': ['gritty', 'lawless', 'stark', 'rugged'],
			'cinematic_benchmarks': ['1883 (2021)', 'True Grit (2010)', 'Unforgiven (1992)']},
		'Wartime Camaraderie':
			{'description': 'You want to feel the intense brotherly bonds born of crisis.',
			'thematic_anchors': ['battlefield frontline brotherhood', 'military tactics', 'trench warfare conditions', 'wartime survival'],
			'tonal_profile': ['intense', 'harrowing', 'loyal', 'profound'],
			'cinematic_benchmarks': ['Band of Brothers (2001)', '1917 (2019)', 'Saving Private Ryan (1998)']},
		'Ancient Mysticism':
			{'description': 'You want to feel the mythic weight of lost empires.',
			'thematic_anchors': ['ancient lost empires', 'mythological lore', 'roman or greek civilizations', 'gods and pharaohs'],
			'tonal_profile': ['epic', 'mythic', 'monumental', 'majestic'],
			'cinematic_benchmarks': ['Rome (2005)', 'Troy (2004)', 'Spartacus (2010)']},
		'Retro-Cool Noir':
			{'description': 'Step into a slick, stylized mid-century world of hard-boiled detectives, neon streets, and dark secrets.',
			'thematic_anchors': ['mid-century jazz lounges', 'hard-boiled investigators', 'mob underworld operations', 'vintage detective investigations'],
			'tonal_profile': ['slick', 'stylized', 'cynical', 'moody'],
			'cinematic_benchmarks': ['L.A. Confidential (1997)', 'Chinatown (1974)', 'Perry Mason (2020)']},
		'Biographical Empathy':
			{'description': 'You want to intimately walk in the shoes of a real historical figure.',
			'thematic_anchors': ['real historical life accounts', 'grounded biological portraits', 'monumental real-life struggles', 'historical journals'],
			'tonal_profile': ['authentic', 'intimate', 'revelatory', 'grounded'],
			'cinematic_benchmarks': ['Oppenheimer (2023)', 'The King (2019)', 'Lincoln (2012)']},
		'Nostalgic Vintage Charm':
			{'description': 'Escape into the sweet, romanticized warmth and stylistic flair of bygone early-to-mid 20th century decades.',
			'thematic_anchors': ['retro mid-century fashion', 'vintage lifestyle aesthetic', 'small-town nostalgia', 'classic golden-age pacing'],
			'tonal_profile': ['warm', 'nostalgic', 'charming', 'wistful'],
			'cinematic_benchmarks': ['The Notebook (2004)', 'Midnight in Paris (2011)', 'The Marvelous Mrs. Maisel (2017)']}
	},
	'Rebellious & Edgy': {
		'Absurdist':
			{'description': 'You feel like nothing makes sense, so you want to embrace total surreal nonsense.',
			'thematic_anchors': ['existential nonsense', 'bizarre logic-bending scenarios', 'surreal imagery', 'eccentric world-building'],
			'tonal_profile': ['absurd', 'surreal', 'weird', 'unpredictable', 'disorienting'],
			'cinematic_benchmarks': ['Everything Everywhere All at Once (2022)', 'Swiss Army Man (2016)', 'Being John Malkovich (1999)']},
		'Wicked Black Comedy':
			{'description': 'Satisfy your inner cynic with razor-sharp satire, pitch-black irony, and terrible people misbehaving.',
			'thematic_anchors': ['pitch-black humor', 'terrible human behavior', 'cynical social satires', 'subversive greed plots'],
			'tonal_profile': ['cynical', 'razor-sharp', 'subversive', 'wicked', 'hilarious'],
			'cinematic_benchmarks': ['The Wolf of Wall Street (2013)', 'Succession (2018)', 'The Banshees of Inisherin (2022)']},
		'Cringe-Seeking':
			{'description': 'You want to squirm in hilariously awkward discomfort and second-hand embarrassment.',
			'thematic_anchors': ['social humiliation', 'extreme awkwardness', 'deadpan comedy setups', 'uncomfortable confrontations'],
			'tonal_profile': ['cringe-inducing', 'awkward', 'uncomfortable', 'hilarious', 'excruciating'],
			'cinematic_benchmarks': ['The Curse (2023)', 'Borat (2006)', 'Fleabag (2016)']},
		'Guns-Blazing Outlaws':
			{'description': 'Ride along with slick, rule-breaking anti-heroes, criminal crews, and high-stakes heist masterminds.',
			'thematic_anchors': ['criminal underworld syndicates', 'charismatic bank robbers', 'mafia power dynamics', 'elaborate street hustles'],
			'tonal_profile': ['slick', 'rebellious', 'high-stakes', 'badass', 'thrilling'],
			'cinematic_benchmarks': ['The Gentlemen (2019)', 'Snatch (2000)', 'Breaking Bad (2008)']},
		'Gritty Counter-Culture':
			{'description': 'Tap into raw, uncompromising street-level rebellion against corporate greed and conventional rules.',
			'thematic_anchors': ['anti-establishment uprisings', 'cyberpunk underground hackers', 'corporate subversion', 'anarchist movements'],
			'tonal_profile': ['gritty', 'uncompromising', 'anarchic', 'raw', 'edgy'],
			'cinematic_benchmarks': ['Mr. Robot (2015)', 'Fight Club (1999)', 'Trainspotting (1996)']},
		'Macabre Curiosity':
			{'description': 'You are fascinated by the grotesque, weird, forbidden, and deliciously dark.',
			'thematic_anchors': ['grotesque mysteries', 'morbid fascination plots', 'gothic family aesthetics', 'twisted physical scenarios'],
			'tonal_profile': ['macabre', 'morbid', 'darkly artistic', 'creepy', 'fascinating'],
			'cinematic_benchmarks': ['The Addams Family (1991)', 'Beetlejuice (1988)', 'What We Do in the Shadows (2014)']},
		'Campy':
			{'description': 'You want to enjoy things that are intentionally trashy, loud, theatrical, and cult-classic material.',
			'thematic_anchors': ['b-movie visual choices', 'intentionally cheesy effects', 'theatrical monster performances', 'trashy plot points'],
			'tonal_profile': ['campy', 'cult-classic', 'loud', 'theatrical', 'unpretentious'],
			'cinematic_benchmarks': ['The Rocky Horror Picture Show (1975)', 'Evil Dead II (1987)', 'M3GAN (2022)']},
		'Shock-Seeking':
			{'description': 'You want to see social taboos and boundaries pushed to their absolute limits.',
			'thematic_anchors': ['provocative social experiments', 'breaking cultural taboos', 'disturbing psychological insights', 'boundary-pushing narrative twists'],
			'tonal_profile': ['provocative', 'shocking', 'disturbing', 'intense', 'polarizing'],
			'cinematic_benchmarks': ['Saltburn (2023)', 'Parasite (2019)', 'The Skin I Live In (2011)']},
		'Unapologetically Weird':
			{'description': 'Celebrate eccentric, bizarre outsiders who completely refuse to fit into normal society.',
			'thematic_anchors': ['unconventional lifestyle choices', 'eccentric misfit dynamics', 'quirky personal paths', 'proudly odd protagonists'],
			'tonal_profile': ['unapologetic', 'quirky', 'endearing', 'bizarre', 'eccentric'],
			'cinematic_benchmarks': ['Napoleon Dynamite (2004)', 'The Lobster (2015)', 'Wednesday (2022)']},
		'Slick & Stylized Neon Thrills':
			{'description': 'Immerse yourself in a high-octane world of hyper-vibrant crime, driving soundswells, and beautiful violence.',
			'thematic_anchors': ['neon cinematography', 'pulse-pounding soundtracks', 'stylized action choreography', 'criminal antiheroes'],
			'tonal_profile': ['slick', 'vibrant', 'kinetic', 'stylish', 'hypnotic'],
			'cinematic_benchmarks': ['Drive (2011)', 'John Wick (2014)', 'Nightcrawler (2014)']}
	},
	'Mind Boggled & Disoriented': {
		'Paranoid Thriller':
			{'description': 'You feel like eyes are everywhere and you absolutely cannot trust anyone around you.',
			'thematic_anchors': ['covert surveillance networks', 'systemic paranoia', 'hidden conspiracies', 'spied-on protagonists'],
			'tonal_profile': ['paranoid', 'suspenseful', 'cynical', 'claustrophobic'],
			'cinematic_benchmarks': ['The Conversation (1974)', 'Enemy of the State (1998)', 'Shutter Island (2010)']},
		'The Illusion of Reality':
			{'description': 'Question everything around you as characters discover their world is a simulation, dream, or illusion.',
			'thematic_anchors': ['virtual reality simulations', 'manufactured illusions', 'altered sensory perceptions', 'matrix structures'],
			'tonal_profile': ['existential', 'surreal', 'disorienting', 'mind-bending'],
			'cinematic_benchmarks': ['The Matrix (1999)', 'The Truman Show (1998)', 'Dark City (1998)']},
		'Ticking Time Loops':
			{'description': 'Live, die, repeat. Escape the exhausting nightmare of being stuck in a cyclical temporal loop.',
			'thematic_anchors': ['temporal time loops', 'cyclical paradoxes', 'rewinding timelines', 'preventing future events'],
			'tonal_profile': ['frantic', 'exhausting', 'clever', 'repetitive-by-design'],
			'cinematic_benchmarks': ['Groundhog Day (1993)', 'Edge of Tomorrow (2014)', 'Source Code (2011)']},
		'Claustrophobic Survival':
			{'description': 'Feel the walls closing in with characters trapped in single-room puzzles and tight, inescapable spaces.',
			'thematic_anchors': ['single-room survival puzzles', 'tight confined bunkers', 'inescapable physical traps', 'claustrophobic set pieces'],
			'tonal_profile': ['claustrophobic', 'anxiety-inducing', 'tense', 'urgent'],
			'cinematic_benchmarks': ['Cube (1997)', 'Room (2015)', 'Buried (2010)']},
		'Gaslit & Manipulated':
			{'description': 'Experience the suffocating tension of malicious psychological games and calculated deception.',
			'thematic_anchors': ['calculated psychological gaslighting', 'malicious mind games', 'deceptive relationships', 'unravelling lies'],
			'tonal_profile': ['suffocating', 'tense', 'unsettling', 'psychological'],
			'cinematic_benchmarks': ['Gaslight (1944)', 'The Invisible Man (2020)', 'Gone Girl (2014)']},
		'Vertigo Timelines':
			{'description': 'Intoxicate your brain with non-linear, fragmented puzzles and dizzying time jumps.',
			'thematic_anchors': ['non-linear timeline fragmentation', 'dizzying flashbacks', 'interwoven chronological puzzles', 'unreliable timelines'],
			'tonal_profile': ['fragmented', 'dizzying', 'intricate', 'analytical'],
			'cinematic_benchmarks': ['Memento (2000)', 'Inception (2010)', 'Arrival (2016)']},
		'Obsessive Descent':
			{'description': 'Track the brilliant, terrifying downward spiral of a mind completely consumed by a single fixation.',
			'thematic_anchors': ['destructive creative fixations', 'downward mental spirals', 'uncompromising obsession', 'loss of structural sanity'],
			'tonal_profile': ['manic', 'terrifying', 'obsessive', 'intense'],
			'cinematic_benchmarks': ['Pi (1998)', 'Black Swan (2010)', 'The Number 23 (2007)']},
		'Fractured Mind':
			{'description': 'See the world through a deeply unstable lens where your own narrator cannot be trusted.',
			'thematic_anchors': ['unreliable narrators', 'severe identity crises', 'amnesia and memory loss', 'shattered personality states'],
			'tonal_profile': ['unstable', 'fractured', 'disorienting', 'untrustworthy'],
			'cinematic_benchmarks': ['Fight Club (1999)', 'American Psycho (2000)', 'The Machinist (2004)']},
		'Surreal Cosmic Madness':
			{'description': 'Surrender your understanding of physics to terrifying extra-dimensional anomalies and logic-breaking cosmic forces.',
			'thematic_anchors': ['extra-dimensional anomalies', 'cosmic entities', 'breaking physical dimensions', 'unfathomable geometric spaces'],
			'tonal_profile': ['cosmic', 'overwhelming', 'existential', 'hallucinatory'],
			'cinematic_benchmarks': ['Annihilation (2018)', 'Interstellar (2014)', 'Coherence (2013)']},
		'The Twisted Final Act':
			{'description': 'Watch a carefully built narrative paradigm get completely shattered by a single, reality-altering plot twist.',
			'thematic_anchors': ['reality-altering plot twists', 'shattered assumptions', 'subverted audience expectations', 'deep conceptual secrets'],
			'tonal_profile': ['shocking', 'subversive', 'clever', 'mind-boggling'],
			'cinematic_benchmarks': ['The Sixth Sense (1999)', 'The Usual Suspects (1995)', 'The Prestige (2006)']}
	},
	'Thrill Seeking & Terrified': {
		'Visceral Survival Horror':
			{'description': 'Face your most primal fears tracking desperate characters hunted by unrelenting, physical monsters.',
			'thematic_anchors': ['monster features', 'unrelenting pursuits', 'gory survival setups', 'creature encounters'],
			'tonal_profile': ['visceral', 'terrifying', 'gory', 'pulse-pounding'],
			'cinematic_benchmarks': ['Alien (1979)', 'A Quiet Place (2018)', 'The Descent (2005)']},
		'Slow-Burn Psychological Dread':
			{'description': 'Let a heavy, invisible panic slowly crawl under your skin with zero cheap jump scares.',
			'thematic_anchors': ['creeping panic', 'implied threats', 'unsettling audio design', 'domestic paranoia'],
			'tonal_profile': ['unsettling', 'dread-inducing', 'slow-burn', 'heavy'],
			'cinematic_benchmarks': ['It Follows (2014)', 'Hereditary (2018)', 'The Babadook (2014)']},
		'Paranormal & Demonic Chills':
			{'description': 'Turn off the lights for a classic, terrifying encounter with hidden spirits, curses, and malicious entities.',
			'thematic_anchors': ['haunted houses', 'demonic possessions', 'malevolent spirits', 'occult investigations'],
			'tonal_profile': ['frightening', 'gothic', 'sinister', 'eerie'],
			'cinematic_benchmarks': ['The Conjuring (2013)', 'The Exorcist (1973)', 'Insidious (2010)']},
		'Found-Footage Realism':
			{'description': 'Immerse yourself in the raw, terrifying illusion of real, first-person panic caught on shaky cameras.',
			'thematic_anchors': ['first-person cameras', 'lost footage tropes', 'shaky camera realism', 'mock documentary setups'],
			'tonal_profile': ['raw', 'immersive', 'frantic', 'authentic'],
			'cinematic_benchmarks': ['The Blair Witch Project (1999)', 'Paranormal Activity (2007)', 'REC (2007)']},
		'Home Invasion Panic':
			{'description': 'Experience the terrifying violation of your safest spaces being breached by malicious forces.',
			'thematic_anchors': ['masked intruders', 'trapped in a house', 'defending your home', 'silent stalkers'],
			'tonal_profile': ['intense', 'suffocating', 'terrifying', 'grounded'],
			'cinematic_benchmarks': ['The Strangers (2008)', 'Don\'t Breathe (2016)', 'Hush (2016)']},
		'Splatter & Gore Spectacle':
			{'description': 'Indulge a morbid appetite for over-the-top, highly theatrical, and deliciously bloody survival chaos.',
			'thematic_anchors': ['extreme physical gore', 'creative trap devices', 'uncompromising body horror', 'blood splatters'],
			'tonal_profile': ['visceral', 'shocking', 'theatrical', 'grotesque'],
			'cinematic_benchmarks': ['Saw (2004)', 'The Fly (1986)', 'Evil Dead (2013)']},
		'Tense Cat-and-Mouse Chase':
			{'description': 'Match your heart rate to a relentless, high-stakes hunt where one wrong move means instant death.',
			'thematic_anchors': ['cunning serial killers', 'dogged pursuits', 'highway stalkers', 'survival tactics'],
			'tonal_profile': ['suspenseful', 'relentless', 'gripping', 'anxiety-inducing'],
			'cinematic_benchmarks': ['No Country for Old Men (2007)', 'Joy Ride (2001)', 'The Invisible Man (2020)']},
		'Folk Horror & Cult Isolation':
			{'description': 'Get lost in remote, tight-knit communities harboring deeply sinister, ancient pagan secrets.',
			'thematic_anchors': ['isolated pagan villages', 'sinister community rituals', 'ancient folklore', 'sacrificial plots'],
			'tonal_profile': ['creepy', 'atmospheric', 'deceptive', 'bizarre'],
			'cinematic_benchmarks': ['Midsommar (2019)', 'The Wicker Man (1973)', 'The Ritual (2017)']},
		'Claustrophobic Survival Traps':
			{'description': 'Feel the crushing weight of being physically pinned down or trapped in an inescapable environment.',
			'thematic_anchors': ['buried alive setups', 'confined survival rooms', 'submerged environments', 'tight spaces'],
			'tonal_profile': ['claustrophobic', 'suffocating', 'tense', 'urgent'],
			'cinematic_benchmarks': ['Buried (2010)', 'Crawl (2019)', '127 Hours (2010)']},
		'Sci-Fi Techno-Horror':
			{'description': 'Watch humanity get absolute crushed by its own hubris, rogue technology, or cold alien encounters.',
			'thematic_anchors': ['rogue artificial intelligence', 'body mutations', 'cold deep-space terror', 'failed scientific breakthroughs'],
			'tonal_profile': ['clinical', 'bleak', 'futuristic', 'stark'],
			'cinematic_benchmarks': ['The Thing (1982)', 'Ex Machina (2014)', 'Event Horizon (1997)']}
	},
	'Empowered & Social Seeking': {
		'Corporate Cutthroats & Ambition':
			{'description': 'Feed your inner drive watching ruthless, hyper-articulate power players climb to the top of the financial world.',
			'thematic_anchors': ['corporate boardroom takeovers', 'hyper-articulate business negotiations', 'insane greed arcs', 'financial schemes'],
			'tonal_profile': ['sharp', 'ambitious', 'cynical', 'fast-paced'],
			'cinematic_benchmarks': ['Succession (2018)', 'The Wolf of Wall Street (2013)', 'Margin Call (2011)']},
		'Political Chess & Intrigue':
			{'description': 'Indulge in a cold, tactical world of strategic backstabbing, hidden leverage, and systemic manipulation.',
			'thematic_anchors': ['political backstabbing', 'hidden government manipulation', 'campaign strategy operations', 'blackmail networks'],
			'tonal_profile': ['tactical', 'cold', 'sharp', 'engrossing'],
			'cinematic_benchmarks': ['House of Cards (2013)', 'The Ides of March (2011)', 'The West Wing (1999)']},
		'The Underdog Rise & Hustle':
			{'description': 'Feel a surge of motivation watching clever outcasts scratch, claw, and outsmart the system to build an empire.',
			'thematic_anchors': ['street hustling operations', 'clever entrepreneurial startups', 'outsmarting corrupt authorities', 'rags-to-riches arcs'],
			'tonal_profile': ['motivational', 'clever', 'energetic', 'empowering'],
			'cinematic_benchmarks': ['The Social Network (2010)', 'Moneyball (2011)', 'Joy (2015)']},
		'High-Society Scandals & Gossip':
			{'description': 'Peer behind the pristine curtain of extreme wealth to watch elite families tear each other apart over secrets.',
			'thematic_anchors': ['elite social gossip', 'extravagant family dynasties', 'reputation destruction', 'forbidden wealthy romances'],
			'tonal_profile': ['glamorous', 'scandalous', 'dramatic', 'addictive'],
			'cinematic_benchmarks': ['Gossip Girl (2007)', 'The White Lotus (2021)', 'Big Little Lies (2017)']},
		'Mafia & Criminal Empires':
			{'description': 'Witness the grand, operatic rise and tragic fall of highly structured family crime syndicates.',
			'thematic_anchors': ['organized crime syndicates', 'mafia family loyalty', 'underworld territory wars', 'criminal enterprise management'],
			'tonal_profile': ['operatic', 'gritty', 'prestigious', 'intense'],
			'cinematic_benchmarks': ['The Godfather (1972)', 'Goodfellas (1990)', 'The Sopranos (1999)']},
		'Elite Sports Competitions':
			{'description': 'Channel high-stakes competitive energy through the blood, sweat, and tears of elite athletes chasing glory.',
			'thematic_anchors': ['championship athletic training', 'high-stakes tournament finals', 'locker-room camaraderie', 'bitter sporting rivalries'],
			'tonal_profile': ['triumphant', 'passionate', 'motivational', 'dramatic'],
			'cinematic_benchmarks': ['Formula 1: Drive to Survive (2019)', 'The Last Dance (2020)', 'Creed (2015)']},
		'Witty Workplace Banter':
			{'description': 'Relax into a sharp, highly social environment defined by fast-talking professionals who love their jobs.',
			'thematic_anchors': ['fast-talking workplace antics', 'witty ensemble dynamics', 'professional chemistry', 'competent characters'],
			'tonal_profile': ['witty', 'smart', 'engaging', 'comforting'],
			'cinematic_benchmarks': ['Suits (2011)', 'The Newsroom (2012)', 'Mad Men (2007)']},
		'Military Tactical Operations':
			{'description': 'Feel the intense, quiet competence of hyper-focused elite units executing complex real-world missions.',
			'thematic_anchors': ['elite special forces operations', 'high-stakes tactical planning', 'brotherhood under fire', 'military rescue missions'],
			'tonal_profile': ['clinical', 'intense', 'competent', 'patriotic'],
			'cinematic_benchmarks': ['Zero Dark Thirty (2012)', 'Sicario (2015)', 'Black Hawk Down (2001)']},
		'Legal & Investigative Strategy':
			{'description': 'Watch brilliant legal and journalistic teams combine their brains to outmaneuver massive, corrupt entities.',
			'thematic_anchors': ['uncovering systematic corruption', 'high-stakes legal strategy', 'investigative newsroom operations', 'depositions'],
			'tonal_profile': ['methodical', 'gripping', 'righteous', 'sharp'],
			'cinematic_benchmarks': ['Spotlight (2015)', 'Erin Brockovich (2000)', 'Michael Clayton (2007)']},
		'Epic Historical Conquests':
			{'description': 'Witness monumental, sweeping human history shaped by legendary leaders commanding entire civilizations.',
			'thematic_anchors': ['sweeping battlefield conquests', 'empire-building strategies', 'legendary historical leaders', 'monumental legacy plots'],
			'tonal_profile': ['epic', 'monumental', 'prestigious', 'majestic'],
			'cinematic_benchmarks': ['Alexander (2004)', 'Kingdom of Heaven (2005)', 'Napoleon (2023)']}
	} 
	}

def mood_colors():
	return {
	'Restless & Hyperactive': 'FFFF4500',
	'Joyful & Comfort Seeking': 'FFFFC125',
	'Sad & Introspective': 'FF00E5FF',
	'Dreamy & Sensory Driven': 'FFD9A6FF',
	'Curious & Intellectual': 'FFFF7F00',
	'Time Travelling Escapism': 'FFDFFF00',
	'Rebellious & Edgy': 'FF00FF66',
	'Mind Boggled & Disoriented': 'FF7B00FF',
	'Thrill Seeking & Terrified': 'FFFF003F',
	'Empowered & Social Seeking': 'FFFE019A'
	}
