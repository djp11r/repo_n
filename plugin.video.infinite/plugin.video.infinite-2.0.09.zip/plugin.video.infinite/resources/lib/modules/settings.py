# -*- coding: utf-8 -*-
from caches.base_cache import database_snyc_items
from caches.settings_cache import get_setting, set_setting, default_setting_values
from modules.kodi_utils import translate_path, get_property, extras_order_default, context_menu_defaults, logger


def tmdb_api_key():
	return get_setting('infinite.tmdb_api', '')

def playback_settings():
	return (int(get_setting('infinite.playback.watched_percent', '90')), int(get_setting('infinite.playback.resume_percent', '5')))

def limit_resolve():
	return get_setting('infinite.playback.limit_resolve', 'false') == 'true'

def movies_directory():
	return translate_path(get_setting('infinite.movies_directory'))

def tv_show_directory():
	return translate_path(get_setting('infinite.tv_shows_directory'))

def download_directory(media_type=None):
	download_directories_dict = {'movie': 'infinite.movie_download_directory', 'episode': 'infinite.tvshow_download_directory', 'thumb_url': 'infinite.image_download_directory',
		'image_url': 'infinite.image_download_directory','image': 'infinite.image_download_directory', 'premium': 'infinite.premium_download_directory',
		None: 'infinite.premium_download_directory', 'None': False}
	return translate_path(get_setting(download_directories_dict[media_type]))

def download_speed_limit():
	return int(get_setting('infinite.download.max_speed', '0'))

def download_concurrent_limit():
	return int(get_setting('infinite.download.max_active', '2'))

def show_unaired_watchlist():
	return get_setting('infinite.show_unaired_watchlist', 'true') == 'true'

def source_folders_directory(media_type, source):
	setting = f'infinite.{source}.movies_directory' if media_type == 'movie' else f'infinite.{source}.tv_shows_directory'
	if get_setting(setting) not in ('', 'None', None): return translate_path( get_setting(setting))
	else: return False

def paginate(is_home):
	paginate_lists = int(get_setting('infinite.paginate.lists', '0'))
	return paginate_lists in (2, 3) if is_home else paginate_lists in (1, 3)

def page_limit(is_home):
	return int(get_setting({True: 'infinite.paginate.limit_widgets', False: 'infinite.paginate.limit_addon'}[is_home], '20'))

def ignore_results_filter():
	return int(get_setting('infinite.results.ignore_filter', '0'))

def quality_filter(setting):
	return get_setting(f'infinite.{setting}').split(', ')

def sort_to_top_filter(autoplay):
	return {0: False, 1: False if autoplay else True, 2: True if autoplay else False, 3: True}[int(get_setting('infinite.filter.sort_to_top', '0'))]

def preferred_filters():
	setting = get_setting('infinite.filter.preferred_filters')
	if setting in ('empty_setting', ''): return []
	return setting.split(', ')

def include_prerelease_results():
	return int(get_setting('infinite.filter.include_prerelease', '0')) == 0

def skip_episode_intros():
	return int(get_setting('infinite.skip_episode_intros', '0'))

def stingers_show():
	return get_setting('infinite.stinger_alert.show', 'false') == 'true'

def auto_play(media_type):
	return get_setting(f'infinite.auto_play_{media_type}', 'false') == 'true'

def autoplay_next_episode():
	return bool(auto_play('episode') and get_setting('infinite.autoplay_next_episode', 'false') == 'true')

def filter_status(filter_type):
	return int(get_setting(f'infinite.filter.{filter_type}', '0'))


def lists_sort_order(setting):
	return int(get_setting(f'infinite.sort.{setting}', '0'))

def single_ep_display_format(is_external):
	if is_external: setting, default = 'infinite.single_ep_display_widget', '1'
	else: setting, default = 'infinite.single_ep_display', ''
	return int(get_setting(setting, default))

def extras_enable_extra_ratings():
	return get_setting('infinite.extras.enable_extra_ratings', 'true') == 'true'

def extras_enable_item_ratings():
	return get_setting('infinite.extras.enable_item_ratings', 'false') =='true'

def extras_enabled():
	defaults = extras_order_default()
	setting = get_setting('infinite.extras.enabled')
	if setting in ('', None, 'noop', []): return defaults
	split_setting = setting.split(',')
	return [int(i) for i in split_setting]

def extras_order():
	defaults = extras_order_default()
	setting = get_setting('infinite.extras.order')
	if setting in ('', None, 'noop', []): return defaults
	split_setting = setting.split(',')
	return [int(i) for i in split_setting]

def check_prescrape_sources(scraper, media_type):
	if scraper in ('folders'): return get_setting(f'infinite.check.{scraper}') == 'true'
	if get_setting(f'infinite.check.{scraper}') == 'true' and auto_play(media_type): return True
	else: return False

def external_scraper_info():
	module = get_setting('infinite.external_scraper.module')
	if module in ('empty_setting', ''): return None, ''
	return module, module.split('.')[-1]

def filter_by_name(scraper):
	if get_property('fs_filterless_search') == 'true': return False
	return get_setting(f'infinite.{scraper}.title_filter', 'false') == 'true'

def results_sort_order():
	return (
			lambda k: (k['quality_rank'], k['provider_rank'], -k['size']), #Quality, Provider, Size
			lambda k: (k['quality_rank'], -k['size'], k['provider_rank']), #Quality, Size, Provider
			lambda k: (k['provider_rank'], k['quality_rank'], -k['size']), #Provider, Quality, Size
			lambda k: (k['provider_rank'], -k['size'], k['quality_rank']), #Provider, Size, Quality
			lambda k: (-k['size'], k['quality_rank'], k['provider_rank']), #Size, Quality, Provider
			lambda k: (-k['size'], k['provider_rank'], k['quality_rank'])  #Size, Provider, Quality
			)[int(get_setting('infinite.results.sort_order', '1'))]

def active_internal_scrapers():
	settings = ['provider.external', 'provider.folders']
	# settings_append = settings.append
	# for item in internal_scrapers_clouds_list:
		# if enabled_debrids_check(item[0]): settings_append(item[1])
	return [i.split('.')[1] for i in settings if get_setting(f'infinite.{i}') == 'true']

def provider_sort_ranks():
	return {'folders': 0, 'gdrive': 1, 'external': 2}

def auto_resume(media_type, autoplay_status):
	return {0: False, 1: True, 2: autoplay_status}[int(get_setting('infinite.auto_resume_%s' % media_type))]

def scraping_settings():
	highlight_type = int(get_setting('infinite.highlight.type', '0'))
	if highlight_type == 2:
		highlight = get_setting('infinite.scraper_single_highlight', 'FF008EB2')
		return {'highlight_type': 1, '4k': highlight, '1080p': highlight, '720p': highlight, 'sd': highlight}
	folders_highlight = ''
	highlight_4K, highlight_1080P, highlight_720P, highlight_SD = '', '', '', ''
	if highlight_type == 0:
		folders_highlight = get_setting('infinite.provider.folders_highlight', 'FFB36B00')
	else:
		highlight_4K = get_setting('infinite.scraper_4k_highlight', 'FFFF3334')
		highlight_1080P = get_setting('infinite.scraper_1080p_highlight', 'FFE6B800')
		highlight_720P = get_setting('infinite.scraper_720p_highlight', 'FF3C9900')
		highlight_SD = get_setting('infinite.scraper_SD_highlight', 'FFCAFFFF')
	return {'highlight_type': highlight_type, 'folders': folders_highlight,
			'4k': highlight_4K, '1080p': highlight_1080P, '720p': highlight_720P, 'sd': highlight_SD}

def omdb_api_key():
	return get_setting('infinite.omdb_api', 'dd7e2fc7')

def max_threads():
	if not get_setting('infinite.limit_concurrent_threads', 'false') == 'true': return 20
	return int(get_setting('infinite.max_threads', '20'))

def widget_hide_next_page():
	return get_setting('infinite.widget_hide_next_page', 'false') == 'true'

def date_offset():
	return int(get_setting('infinite.datetime.offset', '0')) + 5

def media_open_action(media_type):
	return int(get_setting('infinite.media_open_action_%s' % media_type, '0'))

def fen_online_user_active():
	if get_setting('infinite.fen_online.user_active', 'false') != 'true': return False
	key_test = (None, 'empty_setting', '')
	user_hex = get_setting('infinite.fen_online.user_hex')
	return user_hex not in key_test

def fen_online_interval():
	return int(get_setting('infinite.fen_online.sync_interval', '60')) * 60

def nextep_limit():
	return int(get_setting('infinite.nextep.limit', '20'))

def nextep_include_favorites():
	return get_setting('infinite.nextep.include_favorites', 'false') == 'true'

def update_delay():
	return int(get_setting('infinite.update.delay', '45'))

def update_action():
	return int(get_setting('infinite.update.action', '2'))

def rpdb_info(media_type):
	if media_type == 'extras': active = extras_enable_item_ratings()
	else: active = int(get_setting('infinite.rpdb_enabled', '0')) in {'movie': (1, 3), 'tvshow': (2, 3)}[media_type]
	if active: return {'rpdb_api_key': get_setting('infinite.rpdb_api'), 'rpdb_format': get_setting('infinite.rpdb_format')}
	else: return {'rpdb_api_key': None, 'rpdb_format': None}




def cm_enabled():
	defaults = context_menu_defaults()
	setting = get_setting('infinite.context_menu.enabled', defaults)
	if setting in ('', None, 'noop', '[]'): return defaults.split(',')
	return setting.split(',')

def cm_current_order():
	defaults = context_menu_defaults()
	setting = get_setting('infinite.context_menu.order', defaults)
	if setting in ('', None, 'noop', '[]'): return defaults.split(',')
	return setting.split(',')

def cm_sort_order():
	try: setting = {i: c for c, i in enumerate([i for i in cm_current_order() if i in cm_enabled()])}
	except: setting = cm_default_order()
	return setting

def cm_default_order():
	return {i: c for c, i in enumerate(default_setting_values('context_menu.order')['setting_default'].split(','))}

def tmdblist_user_active():
	return get_setting('infinite.tmdb.account_id', 'empty_setting') not in (None, 'empty_setting', '')

def results_format():
	results_window_numbers_dict = {'List': 2000, 'Rows': 2001, 'WideList': 2002}
	window_format = str(get_setting('infinite.results.list_format', 'List'))
	if not window_format in results_window_numbers_dict:
		window_format = 'List'
		set_setting('results.list_format', window_format)
	window_number = results_window_numbers_dict[window_format]
	return window_format.lower(), window_number

def lists_cache_duraton():
	return int(get_setting('infinite.lists_cache_duraton', '48'))

def auto_start_infinite():
	return get_setting('infinite.auto_start_infinite', 'false') == 'true'

def avoid_episode_spoilers():
	return get_setting('infinite.avoid_episode_spoilers', 'false') == 'true'

def audio_filters():
	setting = get_setting('infinite.filter_audio')
	return [] if setting in ('empty_setting', '') else setting.split(', ')

def autoscrape_next_episode():
	if not auto_play('episode') and get_setting('infinite.autoscrape_next_episode', 'false') == 'true': return True
	else: return False

def autoscrape_confirm():
	return get_setting('infinite.autoscrape_confirm', 'false') == 'true'

def autoplay_prescrape(scrape_provider):
	return get_setting('infinite.autoplay.%s' % scrape_provider, 'false') == 'true'

def auto_nextep_settings(play_type):
	play_type = 'autoplay' if play_type == 'autoplay_nextep' else 'autoscrape'
	window_percentage = 100 - int(get_setting('infinite.%s_next_window_percentage' % play_type, '95'))
	use_chapters = get_setting('infinite.%s_use_chapters' % play_type, 'true') == 'true'
	watching_check = int(get_setting('infinite.autoplay_watching_check', '3'))
	scraper_time = int(get_setting('infinite.results.timeout', '60')) + 90
	if play_type == 'autoplay':
		alert_method = int(get_setting('infinite.autoplay_alert_method', '0'))
		default_action = {'0': 'play', '1': 'cancel', '2': 'pause'}[get_setting('infinite.autoplay_default_action', '1')]
	else: alert_method, default_action = '', ''
	return {'scraper_time': scraper_time, 'window_percentage': window_percentage, 'alert_method': alert_method, 'default_action': default_action, 'use_chapters': use_chapters, 'watching_check': watching_check}

def limit_number_quality():
	return int(get_setting('infinite.results.limit_number_quality', '0'))

def limit_number_total():
	return int(get_setting('infinite.results.limit_number_total', '0'))

def tmdblists_sort_order(setting):
	if setting == 'recommendations': return None
	return str(get_setting('infinite.tmdbsort.%s' % setting, '4'))

def show_specials():
	return get_setting('infinite.show_specials', 'false') == 'true'

def single_ep_unwatched_episodes():
	return get_setting('infinite.single_ep_unwatched_episodes', 'false') == 'true'

def recommend_service():
	return int(get_setting('infinite.recommend_service', '0'))

def recommend_seed():
	return int(get_setting('infinite.recommend_seed', '5'))

def tv_progress_location():
	return int(get_setting('infinite.tv_progress_location', '0'))

def external_filter_sources():
	return get_setting('infinite.external.filter_sources', 'true') == 'true'

def size_sort_weighted():
	return get_setting('infinite.results.size_sort_weighted', 'false') == 'true'

def sort_to_top(provider):
	return get_setting({'folders': 'infinite.results.sort_folders_first', }[provider]) == 'true'

def external_cache_check():
	return get_setting('infinite.external.cache_check') == 'true'

def default_all_episodes():
	return int(get_setting('infinite.default_all_episodes', '0'))

def get_meta_filter():
	return get_setting('infinite.meta_filter', 'true')

def widget_hide_watched():
	return get_setting('infinite.widget_hide_watched', 'false') == 'true'

def ignore_articles():
	return get_setting('infinite.ignore_articles', 'false') == 'true'

def jump_to_enabled():
	return get_setting('infinite.paginate.jump_to', 'true') == 'true'

def watched_indicators():
	return int(get_setting('infinite.watched_indicators', '0'))

def nextep_limit_history():
	return get_setting('infinite.nextep.limit_history', 'false') == 'true'

def nextep_include_airdate():
	return get_setting('infinite.nextep.include_airdate', 'false') == 'true'

def nextep_airing_today():
	return get_setting('infinite.nextep.airing_today', 'false') == 'true'

def nextep_include_unaired():
	return get_setting('infinite.nextep.include_unaired', 'false') == 'true'

def nextep_include_unwatched():
    return int(get_setting('infinite.nextep.include_unwatched', '0'))

def nextep_sort_key():
	return {0: 'last_played', 1: 'first_aired', 2: 'name'}[int(get_setting('infinite.nextep.sort_type', '0'))]

def nextep_sort_direction():
	return int(get_setting('infinite.nextep.sort_order', '0')) == 0

def rescrape_settings():
	rescrapes = [('cache_ignored', '1', '0'), ('imdb_year', '0', '1'), ('with_all', '0', '2'), ('episode_group', '0', '3'), ('ignore_filters', '0', '4')]
	return sorted([(i[0], int(get_setting('infinite.rescrape.%s' % i[0], i[1])), int(get_setting('infinite.rescrape.%s.order' % i[0], i[2]))  ) \
					for i in rescrapes if int(get_setting('infinite.rescrape.%s' % i[0], i[1])) in (1, 2)], key=lambda x: x[2])

def use_season_name():
	return get_setting('infinite.use_season_name', 'false') == 'true'

def get_folderscraper_info(media_type='movie', all_avilable=False):
	if all_avilable:
		folder_info = [(get_setting(f'infinite.{i}.display_name'), i, source_folders_directory('movie', i)) for i in ('folder1', 'folder2', 'folder3', 'folder4', 'folder5')]
		folder_info += [(get_setting(f'infinite.{i}.display_name'), i, source_folders_directory('tv_shows', i)) for i in ('folder1', 'folder2', 'folder3', 'folder4', 'folder5')]
	else: folder_info = [(get_setting(f'infinite.{i}.display_name'), i, source_folders_directory(media_type, i)) for i in ('folder1', 'folder2', 'folder3', 'folder4', 'folder5')]
	return [i for i in folder_info if i[0] not in (None, 'None', '') and i[2]], [i[0] for i in folder_info if i[2]]

def get_source_sorting_list():
	return get_setting('infinite.source_sorting').split(', ')

def get_source_filter_by_size(vid_type, duration):
	from modules.utils import string_to_float
	# logger(f'get_source_filter_by_size results.filter_size_method: {repr(get_setting("results.filter_size_method"))}')
	if get_setting('infinite.results.filter_size_method') == '2': max_size = string_to_float(get_setting(f'infinite.results.{vid_type}_size_max'), '2500')/1000
	else: max_size = ((0.125 * (0.90 * string_to_float(get_setting('infinite.results.line_speed', '20'), '20'))) * duration)/1000
	return max_size

def get_git_url():
	return f'https://raw.githubusercontent.com/{get_setting("infinite.git_repo")}/data_dir/mayb'

def get_use_inputstream():
	return get_setting('infinite.use_inputstream') == 'true'
