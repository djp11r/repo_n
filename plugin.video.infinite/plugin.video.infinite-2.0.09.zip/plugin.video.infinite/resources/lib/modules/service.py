# -*- coding: utf-8 -*-

import json
import inspect
from time import time
from threading import Thread
from caches.settings_cache import get_setting, set_setting
from modules import kodi_utils

pause_services_prop = 'infinite.pause_services'
firstrun_update_prop = 'infinite.firstrun_update'
current_skin_prop = 'infinite.current_skin'


class SetAddonConstants:
	def run(self):
		# kodi_utils.logger('SetAddonConstants Service Starting')
		_info = kodi_utils.addon_info
		addon_items = [('infinite.addon_version', _info('version')),
					('infinite.addon_path', _info('path')),
					('infinite.addon_profile', kodi_utils.translate_path(_info('profile'))),
					('infinite.addon_icon', kodi_utils.translate_path(_info('icon'))),
					('infinite.addon_fanart', kodi_utils.translate_path(_info('fanart')))]
		for item in addon_items: kodi_utils.set_property(*item)
		return kodi_utils.logger('SetAddonConstants Service Finished')

class DatabaseMaintenance:
	def run(self):
		# kodi_utils.logger('Database integrity Service Starting')
		from caches.base_cache import check_databases_integrity
		check_databases_integrity(silent=True)
		return kodi_utils.logger('Database integrity Service Finished')

class SettingsSync:
	def run(self):
		# logger('SettingsSync Service Starting')
		from caches.settings_cache import sync_settings
		sync_settings()
		return kodi_utils.logger('SettingsSync Service Finished')

class OnUpdateChanges:
	def run(self):
		kodi_utils.logger('OnUpdateChanges Service Starting')
		try:
			for method in list(filter(lambda x: x[0] != 'run', inspect.getmembers(OnUpdateChanges, predicate=inspect.isfunction))):
				if not get_setting('infinite.updatechecks.%s' % method[0], 'false') == 'true':
					method[1](self)
					set_setting('updatechecks.%s' % method[0], 'true')
		except: pass
		kodi_utils.sync_accounts('infinite retry:')
		return kodi_utils.logger('OnUpdateChanges Service Finished')

	# def update_personal_lists_schema(self):
		# kodi_utils.logger('update_personal_lists_schema', 'enacted')
		# from caches.base_cache import connect_database, check_and_insert_new_columns
		# check_and_insert_new_columns('personal_lists_db', 'personal_lists', 'id', 'TEXT')
		# dbcon = connect_database('personal_lists_db')
		# dbcon.execute('SELECT name FROM personal_lists WHERE id IS NULL')
		# rows_without_id = dbcon.execute('SELECT name FROM personal_lists WHERE id IS NULL').fetchall()
		# if rows_without_id:
			# import uuid
			# for (name,) in rows_without_id:
				# list_id = str(uuid.uuid4())
				# dbcon.execute('UPDATE personal_lists SET id = ? WHERE name = ?', (list_id, name))

	# def add_columns_watched(self):
		# kodi_utils.logger('add_columns_watched', 'launching')
		# from caches.base_cache import check_and_insert_new_columns
		# for table in ('watched', 'progress', 'watched_status'): check_and_insert_new_columns('watched_db', table, 'last_updated', 'INTEGER DEFAULT 0')

	# def set_default_setting(self):
		# from caches.settings_cache import default_setting_values
		# set_setting('context_menu.order', default_setting_values('context_menu.order')['setting_default'])
		# set_setting('extras.enabled', default_setting_values('extras.enabled')['setting_default'])
		# set_setting('update.username', default_setting_values('update.username')['setting_default'])
		# set_setting('update.location', default_setting_values('update.location')['setting_default'])

	# def update_users_tmdblist_authentication(self):
		# For update 2.1.94 - 96.
		# from openscrapers.modules.tmdb_utils import tmdb_list_api
		# empty_setting_check = ('', 'None', None, 'empty_setting')
		# account_id = get_setting('infinite.tmdb.account_id', 'empty_setting')
		# if account_id in empty_setting_check: return
		# access_token = get_setting('infinite.tmdb.token', 'empty_setting')
		# if access_token in empty_setting_check: return
		# account_session_id = get_setting('infinite.tmdb.account_session_id', 'empty_setting')
		# if account_session_id not in empty_setting_check: return
		# kodi_utils.sleep(10000)
		# text = 'You currently have an authorized TMDb account with infinite. New features (Adding/Removing items from Watchlist & Favorites) requires infinite to link this to ' \
		# 'v3 of the TMDb API.'
		# kodi_utils.ok_dialog(heading='TMDb Account Information', text=text, ok_label='Continue..')
		# text = 'Would you like infinite to do that now (automatically)? If you choose not to do this now, you will have to revoke your TMDb authorization and then ' \
		# 're-authorize it in the settings.'
		# if not kodi_utils.confirm_dialog(heading='TMDb Account Information', text=text, ok_label='Do Now', cancel_label='Do Later', default_control=10): return
		# success = tmdb_list_api.get_session_id()
		# if success: text = 'Success!![CR]Your TMDb account can now use the v3 features for Watchlist & Favorites'
		# else: text = 'Something went wrong[CR]Please revoke your TMDb authorization in settings and then re-authorize'
		# kodi_utils.ok_dialog(heading='TMDb Account Information', text=text)

class CustomWindowsPrepare:
	def run(self):
		# kodi_utils.logger('CustomWindowsPrepare Service Starting')
		from windows.base_window import FontUtils, ExtrasUtils
		monitor = kodi_utils.kodi_monitor()
		wait_for_abort = monitor.waitForAbort
		kodi_utils.clear_property(current_skin_prop)
		ExtrasUtils().run()
		font_utils = FontUtils()
		while not monitor.abortRequested():
			font_utils.execute_custom_fonts()
			wait_for_abort(20)
		try: del monitor
		except: pass
		return kodi_utils.logger('CustomWindowsPrepare Service Finished')

class UpdateCheck:
	def run(self):
		if kodi_utils.get_property(firstrun_update_prop) == 'true': return
		kodi_utils.logger('UpdateCheck Service Starting')
		from modules.updater import update_check
		from modules.settings import update_action, update_delay
		end_pause = time() + update_delay()
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing, get_visibility = monitor.waitForAbort, player.isPlayingVideo, kodi_utils.get_visibility
		while not monitor.abortRequested():
			while time() < end_pause: wait_for_abort(1)
			while kodi_utils.get_property(pause_services_prop) == 'true' or is_playing() or get_visibility('Container().isUpdating'): wait_for_abort(1)
			# update_check(update_action())
			Maintenance().run()
			break
		kodi_utils.set_property(firstrun_update_prop, 'true')
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('UpdateCheck Service Finished')

class FenOnlineMonitor:
	def run(self):
		from modules.utils import epoch_to_datetime
		kodi_utils.logger('FenOnlineMonitor Service Starting')
		from apis.fen_online_api import run_sync
		from modules.settings import fen_online_interval, fen_online_user_active
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing, get_visibility = monitor.waitForAbort, player.isPlayingVideo, kodi_utils.get_visibility
		while not monitor.abortRequested():
			while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true' or get_visibility('Container().isUpdating'): wait_for_abort(60)
			if not fen_online_user_active():
				wait_for_abort(60)
				continue
			try: last_sync = int(kodi_utils.get_property('infinite.fen_online.last_sync'))
			except: last_sync = 0
			wait_time = fen_online_interval()
			do_sync = int(time()) >= last_sync + wait_time
			if do_sync:
				kodi_utils.logger('FenOnlineMonitor last_sync %s' % epoch_to_datetime(last_sync))
				status_text = '!!'
				try:
					response = run_sync()
					if response != None:
						status_code = response.status_code
						sync_success = status_code == 200
						if sync_success:
							status_text = 'Success!!'
							if get_setting('infinite.fen_online.refresh_widgets', 'true') == 'true': kodi_utils.run_plugin({'mode': 'kodi_refresh'})
						else: status_text = 'Failed! The following Error Occured: %s - %s' % (status_code, response.text)
				except Exception as e: status_text = 'Failed! The following Error Occured: %s' % str(e)
				kodi_utils.logger('FenOnlineMonitor Service: Sync Status: %s' % status_text)
			wait_for_abort(60)
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('FenOnlineMonitor Service Finished')

class WidgetRefresher:
	def run(self):
		kodi_utils.logger('WidgetRefresher Service Starting')
		from time import time
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, self.is_playing, self.get_visibility = monitor.waitForAbort, player.isPlayingVideo, kodi_utils.get_visibility
		wait_for_abort(10)
		self.set_next_refresh(time())
		while not monitor.abortRequested():
			try:
				wait_for_abort(10)
				offset = int(get_setting('infinite.widget_refresh_timer', '60'))
				if offset != self.offset:
					self.set_next_refresh(time())
					continue
				if self.condition_check(): continue
				if self.next_refresh < time():
					kodi_utils.logger('WidgetRefresher Service - Widgets Refreshed')
					kodi_utils.refresh_widgets()
					self.set_next_refresh(time())
			except: pass
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('WidgetRefresher Service Finished')

	def condition_check(self):
		if not self.external(): return True
		if self.next_refresh == None or self.is_playing() or kodi_utils.get_property(pause_services_prop) == 'true' or self.get_visibility('Container().isUpdating'): return True
		if kodi_utils.get_property('infinite.window_loaded') == 'true': return True
		try:
			window_stack = json.loads(kodi_utils.get_property('infinite.window_stack'))
			if window_stack or window_stack == []: return True
		except: pass
		return False

	def set_next_refresh(self, _time):
		self.offset = int(get_setting('infinite.widget_refresh_timer', '60'))
		if self.offset: self.next_refresh = _time + (self.offset*60)
		else: self.next_refresh = None

	def external(self):
		return 'plugin' not in kodi_utils.get_infolabel('Container.PluginName')

class MainMonitor:
	def __init__(self):
		# Monitor.__init__(self)
		self.monitor = kodi_utils.kodi_monitor()
		self.threads = []
		self.startServices()

	def __enter__(self):
		# self.threads = (Thread(target=SettingsMonitor().run()), Thread(target=premAccntNotification))
		# for t in self.threads:
			# t.daemon = True
			# t.start()
		return self

	def __exit__(self, exc_type, exc_value, traceback):
		try: 
			for i in self.threads: i.join()
		except: pass
		try: del self.monitor
		except: pass

	def startServices(self):
		logger = kodi_utils.logger
		try: SetAddonConstants().run()
		except Exception as e: logger(f'SetAddonConstants Error: {str(e)}')
		try: DatabaseMaintenance().run()
		except Exception as e: logger(f'DatabaseMaintenance Error: {str(e)}')
		try: SettingsSync().run()
		except Exception as e: logger(f'SettingsSync Error: {str(e)}')
		try: OnUpdateChanges().run()
		except Exception as e: logger(f'OnUpdateChanges Error: {str(e)}')
		# try: AddonXMLCheck().run()
		# except Exception as e: logger(f'AddonXMLCheck Error: {str(e)}')
		# Thread(target=DataSync().run).start()
		# Thread(target=CustomWindowsPrepare().run).start()
		Thread(target=UpdateCheck().run).start()
		Thread(target=FenOnlineMonitor().run).start()
		Thread(target=WidgetRefresher().run).start()
		# try: AutoStart().run()
		# except Exception as e: logger(f'AutoStart Error: {str(e)}')
		kodi_utils.notification('Runing')

	def onNotification(self, sender, method, data):
		if method in ('GUI.OnScreensaverActivated', 'System.OnSleep'):
			kodi_utils.set_property(pause_services_prop, 'true')
			# kodi_utils.logger('OnNotificationActions PAUSING infinite Services Due to Device Sleep')
		elif method in ('GUI.OnScreensaverDeactivated', 'System.OnWake'):
			kodi_utils.clear_property(pause_services_prop)
			# kodi_utils.logger('OnNotificationActions UNPAUSING infinite Services Due to Device Awake')

class Maintenance:
	def run(self):
		from caches.settings_cache import get_setting, set_setting
		from caches.base_cache import get_timestamp
		from modules.kodi_utils import logger
		current_time = get_timestamp()
		due_clean = int(get_setting('infinite.database.maintenance.due', '0'))
		do_cleaning = current_time >= due_clean
		# from caches.settings_cache import default_setting_values
		# set_setting('context_menu.order', default_setting_values('context_menu.order')['setting_default'])
		if do_cleaning:
			from caches.base_cache import clean_databases
			clean_databases()
			next_clean = str(int(get_timestamp(168))) # 168 for 7 days
			logger(f'Maintenance Service Run: {do_cleaning} current_time: {current_time} due_clean: {due_clean}')
			return set_setting('database.maintenance.due', next_clean)
		else: return logger(f'Maintenance Service Run: {do_cleaning}')

class AutoStart:
	def run(self):
		# kodi_utils.logger('AutoStart Service Starting')
		from modules.settings import auto_start_infinite
		if auto_start_infinite(): kodi_utils.run_addon()
		return kodi_utils.logger('AutoStart Service Finished')

class AddonXMLCheck:
	def run(self):
		kodi_utils.logger('ReuseLanguageInvokerCheck Service Starting')
		from xml.dom.minidom import parse as mdParse
		self.addon_xml = kodi_utils.translate_path('special://home/addons/plugin.video.infinite/addon.xml')
		self.root = mdParse(self.addon_xml)
		self.change_list = []
		self.check_property('reuse_language_invoker', 'reuselanguageinvoker')
		# self.check_property('addon_icon_choice', 'icon')
		self.change_xml_file()
		return kodi_utils.logger('AddonXMLCheck Service Finished')

	def check_property(self, setting, tag_name):
		current_addon_setting = get_setting('infinite.%s' % setting, None)
		if current_addon_setting is None: return
		tag_instance = self.root.getElementsByTagName(tag_name)[0].firstChild
		current_property = tag_instance.data
		if current_property != current_addon_setting:
			tag_instance.data = current_addon_setting
			self.change_list.append(tag_name)

	def change_xml_file(self):
		if not self.change_list: return
		if 'icon' in self.change_list: self.reassign_addon_icon()
		kodi_utils.notification('Refreshing Addon XML. Restarting Addons')
		new_xml = str(self.root.toxml()).replace('<?xml version="1.0" ?>', '')
		with open(self.addon_xml, 'w') as f: f.write(new_xml)
		kodi_utils.logger('AddonXMLCheck Service - Change Detected. Restarting Addons')
		kodi_utils.execute_builtin('ActivateWindow(Home)', True)
		kodi_utils.update_local_addons()
		kodi_utils.disable_enable_addon()

	def reassign_addon_icon(self):
		from indexers.dialogs import addon_icon_choice
		addon_icon_choice({'set_icon': get_setting('addon_icon_choice_name', 'infinite_icon.png')})

class PlaybackKeymaker:
	def run(self):
		kodi_utils.logger('PlaybackKeymaker Service Starting')
		from caches.main_cache import cache_object
		monitor = kodi_utils.kodi_monitor()
		wait_for_abort = monitor.waitForAbort
		while not monitor.abortRequested():
			kodi_utils.set_property('infinite.playback_key', cache_object(self.make_key, 'playback_key', ('foo',), False, 1))
			wait_for_abort(1800)
		try: del monitor
		except: pass
		return kodi_utils.logger('PlaybackKeymaker Service Finished')

	def make_key(self, dummy_arg):
		import random
		new_key = str(random.randint(1000, 10000))
		kodi_utils.set_property('infinite.playback_key', new_key)
		kodi_utils.logger('PlaybackKeymaker Service - New Key Made: %s' % new_key)
		kodi_utils.kodi_refresh()
		return new_key

class DataSync:
	def run(self):
		kodi_utils.logger('DataSync Service Starting')
		from modules.settings import database_autosync, database_autosync_interval
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		while not monitor.abortRequested():
			sync_interval = database_autosync_interval()
			wait_for_abort(sync_interval)
			if database_autosync():
				while kodi_utils.get_property(pause_services_prop) == 'true' or is_playing(): wait_for_abort(10)
				full_sync()
				kodi_utils.notification('DataSync: Incremental Data Sync Performed')
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('DataSync Service Finished')
