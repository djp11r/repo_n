# -*- coding: utf-8 -*-

from modules import kodi_utils
from modules.service import infiniteMonitor


if __name__ == '__main__':
	with infiniteMonitor() as omain:
		while not omain.monitor.abortRequested():
			if omain.monitor.waitForAbort(1):
				break
	kodi_utils.logger('Main Monitor Service Finished')
