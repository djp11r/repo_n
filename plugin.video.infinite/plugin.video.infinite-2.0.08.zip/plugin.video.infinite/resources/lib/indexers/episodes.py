# -*- coding: utf-8 -*-
import sys
from traceback import print_exc
from apis.trakt_api import trakt_watchlist, trakt_get_my_calendar
from caches.favorites_cache import favorites_cache
from modules.metadata import tvshow_meta, episodes_meta, all_episodes_meta
from modules.utils import jsondate_to_datetime, adjust_premiered_date, make_day, get_datetime, get_current_timestamp, title_key, date_difference, TaskPool
from modules.kodi_utils import logger, get_icon, addon_fanart, set_view_mode, external, home, add_items, set_content, set_sort_method, end_directory, make_listitem, build_url, set_category, get_property, set_info, empty_poster
from modules.settings import rpdb_info as rpdb_i, date_offset, default_all_episodes, nextep_include_unwatched, nextep_airing_today, nextep_sort_key, nextep_sort_direction, nextep_include_unaired, single_ep_display_format, widget_hide_watched, nextep_limit_history, nextep_limit, tmdb_api_key, mpaa_region, watched_indicators as w_indi, nextep_method, show_specials, flatten_episodes, single_ep_unwatched_episodes, nextep_include_airdate, calendar_sort_order, cm_sort_order as cm_sort, ignore_articles as ignore_a, cm_default_order, playback_key as pb_key, avoid_episode_spoilers
from modules.watched_status import get_watched_status_episode, get_bookmarks_episode, get_progress_status_episode, get_in_progress_episodes, get_next_episodes, get_recently_watched, get_bookmarks_all_episode, get_progress_status_all_episode, get_hidden_progress_items, get_database, watched_info_episode, get_next, get_watched_status_tvshow, watched_info_tvshow


def build_episode_list(params):
	def _process():
		for item in episodes_data:
			try:
				cm = []
				cm_append = cm.append
				listitem = make_listitem()
				set_properties = listitem.setProperties
				item_get = item.get
				season, episode, ep_name = item_get('season'), item_get('episode'), item_get('title')
				season_special = season == 0
				episode_date, premiered = adjust_premiered_date(item_get('premiered'), adjust_hours)
				episode_type = item_get('episode_type') or ''
				episode_id = item_get('episode_id') or None
				if season_special: playcount, progress = 0, None
				else:
					playcount = get_watched_status_episode(watched_info, (season, episode))
					if playcount and hide_watched: continue
					if total_seasons: progress = get_progress_status_all_episode(bookmarks, season, episode)
					else: progress = get_progress_status_episode(bookmarks, episode)
				if no_spoilers and not playcount: thumb, plot = show_landscape or show_fanart, tvshow_plot or '* Hidden to Prevent Spoilers *'
				else: thumb, plot = item_get('thumb', None) or show_landscape or show_fanart, item_get('plot') or tvshow_plot
				try: year = premiered.split('-')[0]
				except: year = show_year or '2050'
				if not item_get('duration'): item['duration'] = show_duration
				if not episode_date or current_date < episode_date:
					display, unaired = '[COLOR red][I]%s[/I][/COLOR]' % ep_name, True
					item['title'] = display
				else: display, unaired = ep_name, False
				item.update({'plot': plot, 'trailer': trailer, 'cast': cast, 'tvshowtitle': title, 'premiered': premiered, 'genre': genre, 'mpaa': mpaa, 'studio': studio, 'playcount': playcount, 'playback_percent': progress, 'year': year})
				extras_params = build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'episode', 'is_external': is_external})
				options_params = build_url({'mode': 'options_menu_choice', 'content': 'episode', 'tmdb_id': tmdb_id, 'poster': show_poster, 'is_external': is_external})
				playback_options_params = build_url({'mode': 'playback_choice', 'media_type': 'episode', 'meta': tmdb_id, 'season': season, 'playcount': playcount, 'episode': episode, 'episode_id': episode_id})
				data = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode, 'playcount': playcount, 'episode_id': episode_id, playback_key: playback_key, 'ep_name': ep_name}
				play_params = build_url(data)
				#logger(f'build_episode_list unaired: {unaired} ep_name: {ep_name} item: {item}')
				if not unaired:
					data['mode'] = 'scrape_select'
					cm_append(['select', ('Select Source', 'RunPlugin(%s)' % build_url(data))])
					data['mode'] = 'rescrape_select'
					cm_append(['rescrape', ('Rescrape & Select Source', 'RunPlugin(%s)' % build_url(data))])
				cm_append(['extras', ('[B]Extras...[/B]', 'RunPlugin(%s)' % extras_params)])
				cm_append(['options', ('[B]Options...[/B]', 'RunPlugin(%s)' % options_params)])
				cm_append(['playback_options', ('[B]Play Options...[/B]', 'RunPlugin(%s)' % playback_options_params)])
				if not unaired and not season_special:
					if playcount:
						cm_append(['mark_watched', ('[B]Mark Unwatched %s[/B]' % watched_title, 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_unwatched',
													'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season, 'episode': episode,  'title': title}))])
					else: cm_append(['mark_watched', ('[B]Mark Watched %s[/B]' % watched_title, 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_watched',
													'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season, 'episode': episode,  'title': title}))])
					if progress: cm_append(['mark_watched', ('[B]Clear Progress[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.erase_bookmark', 'media_type': 'episode', 'tmdb_id': tmdb_id,
								'season': season, 'episode': episode, 'refresh': 'true'}))])
				if is_external:
					cm.extend([['refresh', ('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'refresh_widgets'}))],
							['reload', ('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'kodi_refresh'}))]])
				if custom_cm_menu:
					try: cm = sorted([i for i in cm if i[0] in cm_sort_order], key=lambda k: cm_sort_order[k[0]])
					except: pass
				cm = [i[1] for i in cm]
				listitem = set_info(listitem, item, {'imdb': imdb_id, 'tmdb': str(tmdb_id), 'tvdb': str(tvdb_id)}, progress)
				if progress and not unaired: set_properties({'WatchedProgress': progress})
				listitem.setLabel(display)
				listitem.addContextMenuItems(cm)
				listitem.setArt({'poster': show_poster, 'fanart': show_fanart, 'thumb': thumb, 'icon':thumb, 'clearlogo': show_clearlogo, 'landscape': show_landscape,
								'season.poster': season_poster, 'tvshow.poster': show_poster, 'tvshow.clearlogo': show_clearlogo})
				set_properties({
					'episode_type': episode_type,
					'infinite.extras_params': extras_params,
					'infinite.options_params': options_params,
					'infinite.playback_options_params': playback_options_params
					})
				yield play_params, listitem, False
			except: logger(f'build_episode_list item: {item}\nError: {print_exc()}')
	poster_empty, fanart_empty = get_icon('box_office'), addon_fanart()
	handle, is_external, category_name = int(sys.argv[1]), external(), 'Episodes'
	no_spoilers = avoid_episode_spoilers()
	item_list = []
	# append = item_list.append
	watched_indicators, adjust_hours = w_indi(), date_offset()
	current_date, hide_watched = get_datetime(), is_external and widget_hide_watched()
	cm_sort_order = cm_sort()
	custom_cm_menu = cm_sort_order != cm_default_order()
	#logger(f'build_episode_list perform_cm_sort: {perform_cm_sort} cm_sort_order: {cm_sort_order}')
	rpdb_info = rpdb_i('tvshow')
	rpdb_api_key, rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
	playback_key = pb_key()
	play_mode = 'playback.%s' % playback_key
	watched_title = 'Trakt' if watched_indicators == 1 else 'infinite'
	meta = tvshow_meta('tmdb_id', params.get('tmdb_id'), tmdb_api_key(), mpaa_region(), current_date)
	meta_get = meta.get
	tmdb_id, tvdb_id, imdb_id, tvshow_plot, orig_title = meta_get('tmdb_id'), meta_get('tvdb_id'), meta_get('imdb_id'), meta_get('plot'), meta_get('original_title')
	title, show_year, rootname, show_duration, show_status = meta_get('title'), meta_get('year') or '2050', meta_get('rootname'), meta_get('duration'), meta_get('status')
	mpaa, trailer, genre, studio, country = meta_get('mpaa'), str(meta_get('trailer')), meta_get('genre'), meta_get('studio'), meta_get('country')
	cast = meta_get('short_cast', []) or meta_get('cast', []) or []
	season = params['season']
	if rpdb_api_key:
		try: show_poster = meta_get('rpdb_poster') % rpdb_api_key + rpdb_format
		except: show_poster = meta_get('poster') or poster_empty
	else: show_poster = meta_get('poster') or poster_empty
	show_fanart = meta_get('fanart') or empty_poster
	show_clearlogo = meta_get('clearlogo') or ''
	show_landscape = meta_get('landscape') or ''
	watched_db = get_database(watched_indicators)
	watched_info = watched_info_episode(tmdb_id, watched_db)
	if season == 'all':
		total_seasons = meta_get('total_seasons') or meta_get('seasons', 1)
		episodes_data = sorted(all_episodes_meta(meta, show_specials()), key=lambda x: (x['season'], x['episode']))
		bookmarks = get_bookmarks_all_episode(tmdb_id, total_seasons, watched_db)
		season_poster = show_poster
		category_name = 'Season %s' % season if total_seasons == 1 else 'Seasons 1-%s' % total_seasons
	else:
		total_seasons = None
		episodes_data = episodes_meta(season, meta)
		bookmarks = get_bookmarks_episode(tmdb_id, season, watched_db)
		try:
			season_data = meta_get('season_data')
			poster_path = next((i['poster_path'] for i in season_data if i['season_number'] == int(season)), None)
			season_poster = 'https://image.tmdb.org/t/p/w780%s' % poster_path if poster_path is not None else show_poster
		except: season_poster = show_poster
		category_name = 'Season %s' % season
	add_items(handle, list(_process()))
	set_sort_method(handle, 'episodes')
	set_content(handle, 'episodes')
	set_category(handle, category_name)
	end_directory(handle, cacheToDisc=not is_external)
	set_view_mode('view.episodes', 'episodes', is_external)

def build_single_episode(list_type, params={}):
	def _get_category_name():
		try:
			cat_name = {'episode.progress': 'In Progress Episodes',
						'episode.recently_watched': 'Recently Watched Episodes',
						'episode.next_trakt': 'Next Episodes', 'episode.next_infinite': 'Next Episodes',
						'episode.trakt': {'true': 'Recently Aired Episodes', None: 'Trakt Calendar'}}[list_type]
			if isinstance(cat_name, dict): cat_name = cat_name[params.get('recently_aired')]
		except: cat_name = 'Episodes'
		return cat_name
	def _process(_position, ep_data):
		try:
			ep_data_get = ep_data.get
			meta = tvshow_meta('trakt_dict', ep_data_get('media_ids'), api_key, mpaa_region_value, current_date)
			if not meta: return
			meta_get = meta.get
			cm = []
			cm_append = cm.append
			listitem = make_listitem()
			set_properties = listitem.setProperties
			orig_season, orig_episode = ep_data_get('season'), ep_data_get('episode')
			unwatched = ep_data_get('unwatched', False)
			_position = ep_data_get('custom_order', _position)
			tmdb_id, tvdb_id, imdb_id, title, show_year = meta_get('tmdb_id'), meta_get('tvdb_id'), meta_get('imdb_id'), meta_get('title'), meta_get('year') or '2050'
			season_data = meta_get('season_data')
			playcount = 0
			watched_info = watched_info_episode(meta_get('tmdb_id'), watched_db)
			if list_type_starts_with('next'):
				orig_season, orig_episode = get_next(orig_season, orig_episode, watched_info, season_data, nextep_content)
				if not orig_season or not orig_episode: logger(f'build_single_episode get_next error not found for : {title} meta: {meta}'); return
			episodes_data = episodes_meta(orig_season, meta)
			if not episodes_data: return
			item = next((i for i in episodes_data if i['episode'] == orig_episode), None)
			if not item: return
			item_get = item.get
			season, episode, ep_name = item_get('season'), item_get('episode'), item_get('title')
			episode_date, premiered = adjust_premiered_date(item_get('premiered'), adjust_hours)
			episode_type = item_get('episode_type') or ''
			episode_id = item_get('episode_id') or None
			if not episode_date or current_date < episode_date:
				if list_type_starts_with('next_'):
					if not episode_date: return
					if not include_unaired: return
					if not date_difference(current_date, episode_date, 7): return
				unaired = True
			else: unaired = False
			orig_title, rootname, trailer, genre = meta_get('original_title'), meta_get('rootname'), str(meta_get('trailer')), meta_get('genre')
			mpaa, tvshow_plot, studio, show_status = meta_get('mpaa'), meta_get('plot'), meta_get('studio'), meta_get('status')
			cast = meta_get('short_cast', []) or meta_get('cast', []) or []
			if rpdb_api_key:
				try: show_poster = meta_get('rpdb_poster') % rpdb_api_key + rpdb_format
				except: show_poster = meta_get('poster') or poster_empty
			else: show_poster = meta_get('poster') or poster_empty
			show_fanart = meta_get('fanart') or fanart_empty
			show_clearlogo = meta_get('clearlogo') or ''
			show_landscape = meta_get('landscape') or ''
			try: year = premiered.split('-')[0]
			except: year = show_year or '2050'
			try:
				poster_path = next((i['poster_path'] for i in season_data if i['season_number'] == int(season)), None)
				season_poster = 'https://image.tmdb.org/t/p/w780%s' % poster_path if poster_path is not None else show_poster
			except: season_poster = show_poster
			str_season_zfill2, str_episode_zfill2 = str(season).zfill(2), str(episode).zfill(2)
			if display_format == 0: title_str = '%s: ' % title
			else: title_str = ''
			if display_format in (0, 1): seas_ep = '%sx%s - ' % (str_season_zfill2, str_episode_zfill2)
			else: seas_ep = ''
			duration = item_get('duration')
			if not duration:
				duration = meta_get('duration')
				item['duration'] = duration
			bookmarks = get_bookmarks_episode(tmdb_id, season, watched_db)
			if not list_type_starts_with('next_'): playcount = get_watched_status_episode(watched_info, (season, episode))
			if playcount and hide_watched: return
			#logger(f'build_single_episode unaired: {unaired} ep_name: {ep_name} meta : {meta}')
			progress = get_progress_status_episode(bookmarks, episode)
			if list_type_starts_with('next_'):
				if include_airdate:
					if episode_date: display_premiered = '[%s] ' % make_day(current_date, episode_date)
					else: display_premiered = '[UNKNOWN] '
				else: display_premiered = ''
				if unwatched: highlight_start, highlight_end = '[COLOR darkgoldenrod]', '[/COLOR]'
				elif unaired: highlight_start, highlight_end = '[COLOR red]', '[/COLOR]'
				else: highlight_start, highlight_end = '', ''
				display = '%s%s%s%s%s%s' % (display_premiered, title_str, highlight_start, seas_ep, ep_name, highlight_end)
			elif list_type_compare == 'trakt_calendar':
				if episode_date: display_premiered = make_day(current_date, episode_date)
				else: display_premiered = 'UNKNOWN'
				display = '[%s] %s%s%s' % (display_premiered, title_str, seas_ep, ep_name)
			else: display = '%s%s%s' % (title_str, seas_ep, ep_name)
			if no_spoilers and not playcount: thumb, plot = show_landscape or show_fanart, tvshow_plot or '* Hidden to Prevent Spoilers *'
			else: thumb, plot = item_get('thumb', None) or show_landscape or show_fanart, item_get('plot') or tvshow_plot
			if not item_get('duration'): item['duration'] = meta_get('duration')
			item.update({'plot': plot, 'trailer': trailer, 'cast': cast, 'tvshowtitle': title, 'premiered': premiered, 'genre': genre, 'mpaa': mpaa, 'studio': studio, 'playcount': playcount, 'title': display, 'playback_percent': progress, 'year': year})
			url_parm = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode, 'playcount': playcount,'episode_id': episode_id, playback_key: playback_key, 'ep_name': ep_name}
			play_params = build_url(url_parm)
			extras_params = build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'episode', 'is_external': is_external})
			options_params = build_url({'mode': 'options_menu_choice', 'content': list_type, 'tmdb_id': tmdb_id, 'poster': show_poster, 'is_external': is_external})
			playback_options_params = build_url({'mode': 'playback_choice', 'media_type': 'episode', 'meta': tmdb_id, 'season': season, 'playcount': playcount, 'episode': episode, 'episode_id': episode_id})
			if not unaired:
				url_parm['mode'] = 'scrape_select'
				cm_append(['select', ('Select Source', 'RunPlugin(%s)' % build_url(url_parm))])
				url_parm['mode'] = 'rescrape_select'
				cm_append(['rescrape', ('Rescrape & Select Source', 'RunPlugin(%s)' % build_url(url_parm))])
			cm_append(['extras', ('[B]Extras...[/B]', 'RunPlugin(%s)' % extras_params)])
			cm_append(['options', ('[B]Options...[/B]', 'RunPlugin(%s)' % options_params)])
			cm_append(['playback_options', ('[B]Play Options[/B]', 'RunPlugin(%s)' % build_url({'mode': 'playback_choice', 'media_type': 'episode', 'meta': tmdb_id, 'season': season, 'episode': episode, 'episode_id': episode_id}))])
			cm_append(['browse_seasons', ('Browse All Seasons', window_command % build_url({'mode': 'build_season_list', 'tmdb_id': tmdb_id}))])
			cm_append(['browse', (f'Browse Season {season} Epis:', 'Container.Update(%s)' % build_url({'mode': 'build_episode_list', 'tmdb_id': tmdb_id, 'season': season}))])
			if not unaired:
				if playcount:
					cm_append(['mark_watched', ('[B]Mark Unwatched %s[/B]' % watched_title, 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_unwatched',
												'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season, 'episode': episode,  'title': title}))])
				else: cm_append(['mark_watched', ('[B]Mark Watched %s[/B]' % watched_title, 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_watched',
												'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season, 'episode': episode,  'title': title}))])
				if progress:
					cm_append(['mark_watched', ('[B]Clear Progress[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.erase_bookmark', 'media_type': 'episode', 'tmdb_id': tmdb_id,
												'season': season, 'episode': episode, 'refresh': 'true'}))])
					set_properties({'WatchedProgress': progress})
			if unwatched_info:
				total_aired_eps = meta_get('total_aired_eps')
				total_unwatched = get_watched_status_tvshow(watched_info_tvshow(watched_db).get(str(tmdb_id), None), total_aired_eps)[2]
				if total_aired_eps != total_unwatched: set_properties({'watchedepisodes': '1', 'unwatchedepisodes': str(total_unwatched)})
			if list_type_starts_with('next_') and (season, episode) != (1, 1):
				cm_append(['unmark_previous_episode', ('[B]Unmark Previous Watched[/B]', 'RunPlugin(%s)' % \
								build_url({'mode': 'watched_status.unmark_previous_episode', 'action': 'mark_as_unwatched', 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id,
											'season': season, 'episode': episode, 'title': title, 'refresh': 'true'}))])
			if is_external:
				cm.extend([['refresh', ('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'refresh_widgets'}))],
						['reload', ('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'kodi_refresh'}))]])
			if custom_cm_menu:
				try: cm = sorted([i for i in cm if i[0] in cm_sort_order], key=lambda k: cm_sort_order[k[0]])
				except: pass
			cm = [i[1] for i in cm]
			listitem = set_info(listitem, item, {'imdb': imdb_id, 'tmdb': str(tmdb_id), 'tvdb': str(tvdb_id)}, progress)
			listitem.setLabel(display)
			listitem.addContextMenuItems(cm)
			listitem.setArt({'poster': show_poster, 'fanart': show_fanart, 'thumb': thumb, 'icon':thumb, 'clearlogo': show_clearlogo, 'landscape': show_landscape,
							'season.poster': season_poster, 'tvshow.poster': show_poster, 'tvshow.clearlogo': show_clearlogo})
			set_properties({
				'episode_type': episode_type,
				'infinite.extras_params': extras_params,
				'infinite.options_params': options_params,
				'infinite.playback_options_params': playback_options_params
				})
			item_list_append({'list_items': (play_params, listitem, False), 'first_aired': premiered, 'name': '%s - %sx%s' % (title, str_season_zfill2, str_episode_zfill2),
							'unaired': unaired, 'last_played': ep_data_get('last_played', resinsert), 'sort_order': str(_position), 'unwatched': ep_data_get('unwatched')})
		except: logger(f'build_single_episode ep_data: {ep_data} Error: {print_exc()}')
	poster_empty, fanart_empty = get_icon('box_office'), addon_fanart()
	handle, is_external, category_name = int(sys.argv[1]), external(), 'Episodes'
	item_list, airing_today, unwatched, return_results = [], [], [], False
	resinsert = ''
	item_list_append = item_list.append
	window_command = 'ActivateWindow(Videos,%s,return)' if is_external else 'Container.Update(%s)'
	no_spoilers = avoid_episode_spoilers()
	browse_season = True
	watched_indicators, display_format = w_indi(), single_ep_display_format(is_external)
	current_date, adjust_hours = get_datetime(), date_offset()
	unwatched_info = single_ep_unwatched_episodes()
	hide_watched = is_external and widget_hide_watched() and list_type != 'episode.recently_watched'
	api_key, mpaa_region_value = tmdb_api_key(), mpaa_region()
	cm_sort_order, ignore_articles = cm_sort(), ignore_a()
	custom_cm_menu = cm_sort_order != cm_default_order()
	#logger(f'build_single_episode perform_cm_sort: {perform_cm_sort} cm_sort_order: {cm_sort_order}')
	rpdb_info = rpdb_i('tvshow')
	rpdb_api_key, rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
	playback_key = pb_key()
	play_mode = 'playback.%s' % playback_key
	watched_db = get_database(watched_indicators)
	watched_title = 'Trakt' if watched_indicators == 1 else 'infinite'
	if list_type == 'episode.next':
		include_unwatched, include_unaired, nextep_content = nextep_include_unwatched(), nextep_include_unaired(), nextep_method()
		sort_key, sort_direction = nextep_sort_key(), nextep_sort_direction()
		include_airdate = nextep_include_airdate()
		data = get_next_episodes(nextep_content)
		if nextep_limit_history(): data = data[:nextep_limit()]
		hidden_list = get_hidden_progress_items(watched_indicators)
		if hidden_list: data = [i for i in data if not i['media_ids']['tmdb'] in hidden_list]
		if watched_indicators == 1: resformat, resinsert, list_type = '%Y-%m-%dT%H:%M:%S.%fZ', '2000-01-01T00:00:00.000Z', 'episode.next_trakt'
		else: resformat, resinsert, list_type = '%Y-%m-%d %H:%M:%S', '2000-01-01 00:00:00', 'episode.next_infinite'
		if include_unwatched != 0:
			if include_unwatched in (1, 3):
				from apis.trakt_api import trakt_watchlist
				try:
					watchlist = trakt_watchlist('tvshow', '')
					unwatched.extend([{'media_ids': i['media_ids'], 'season': 1, 'episode': 0, 'unwatched': True, 'title': i['title']} for i in watchlist])
				except: pass
			if include_unwatched in (2, 3):
				try:
					favorites = favorites_cache.get_favorites('tvshow')
					unwatched.extend([{'media_ids': {'tmdb': int(i['tmdb_id'])}, 'season': 1, 'episode': 0, 'unwatched': True, 'title': i['title']} \
									for i in favorites if not int(i['tmdb_id']) in [x['media_ids']['tmdb'] for x in data]])
				except: pass
			data += unwatched
	elif list_type == 'episode.progress': data = get_in_progress_episodes()
	elif list_type == 'episode.recently_watched': data = get_recently_watched('episode', short_list=True)
	elif list_type == 'episode.trakt':
		from apis.trakt_api import trakt_get_my_calendar
		recently_aired = params.get('recently_aired', None)
		data = trakt_get_my_calendar(recently_aired, get_datetime())
		hidden_list = get_hidden_progress_items(watched_indicators)
		if hidden_list: data = [i for i in data if not i['media_ids']['tmdb'] in hidden_list]
		list_type = 'episode.trakt_recently_aired' if recently_aired else 'episode.trakt_calendar'
		if flatten_episodes():
			try:
				duplicates = set()
				data.sort(key=lambda i: i['sort_title'])
				data = [i for i in data if not ((i['media_ids']['tmdb'], i['first_aired'].split('T')[0]) in duplicates
						or duplicates.add((i['media_ids']['tmdb'], i['first_aired'].split('T')[0])))]
			except: pass
		else:
			try: data = sorted(data, key=lambda i: (i['sort_title'], i.get('first_aired', '2100-12-31')), reverse=True)
			except: data = sorted(data, key=lambda i: i['sort_title'], reverse=True)
	else: data, return_results = sorted(params, key=lambda i: i['custom_order']), True
	list_type_compare = list_type.split('episode.')[1]
	list_type_starts_with = list_type_compare.startswith
	threads = TaskPool().tasks_enumerate(_process, data)
	[i.join() for i in threads]
	if return_results: return [(i['list_items'], i['sort_order']) for i in item_list]
	if list_type_starts_with('next_'):
		def func(function):
			if sort_key == 'name': return title_key(function, ignore_articles)
			elif sort_key == 'last_played': return jsondate_to_datetime(function, resformat)
			else: return function
		if nextep_airing_today():
			airing_today = sorted([i for i in item_list if date_difference(current_date, jsondate_to_datetime(i.get('first_aired', '2100-12-31'), '%Y-%m-%d').date(), 0)],
									key=lambda i: func(i[sort_key]), reverse=sort_direction)
			item_list = [i for i in item_list if not i in airing_today]
		else: airing_today = []
		if sort_key == 'last_played':
			unwatched = sorted([i for i in item_list if i['unwatched']], key=lambda i: title_key(i['name'], ignore_articles))
			item_list = sorted([i for i in item_list if not i['unwatched']], key=lambda i: func(i[sort_key]), reverse=sort_direction) + unwatched
		else: item_list = sorted(item_list, key=lambda i: func(i[sort_key]), reverse=sort_direction)
		item_list = airing_today + item_list
	else:
		item_list.sort(key=lambda i: i['sort_order'])
		if list_type_compare in ('trakt_calendar', 'trakt_recently_aired'):
			if list_type_compare == 'trakt_calendar': reverse = calendar_sort_order() == 0
			else: reverse = True
			try: item_list = sorted(item_list, key=lambda i: i.get('first_aired', '2100-12-31'), reverse=reverse)
			except:
				item_list = [i for i in item_list if i.get('first_aired') not in (None, 'None', '')]
				item_list = sorted(item_list, key=lambda i: i.get('first_aired'), reverse=reverse)
			if list_type_compare == 'trakt_calendar':
				airing_today = sorted([i for i in item_list if date_difference(current_date, jsondate_to_datetime(i.get('first_aired', '2100-12-31'), '%Y-%m-%d').date(), 0)],
										key=lambda i: i['first_aired'])
				item_list = [i for i in item_list if not i in airing_today]
				item_list = airing_today + item_list
	add_items(handle, [i['list_items'] for i in item_list])
	set_content(handle, 'episodes')
	set_category(handle, _get_category_name())
	end_directory(handle, cacheToDisc=False)
	set_view_mode('view.episodes_single', 'episodes', is_external)
