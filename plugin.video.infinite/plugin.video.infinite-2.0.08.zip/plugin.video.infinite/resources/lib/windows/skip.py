# -*- coding: utf-8 -*-
import time
from windows.base_window import BaseDialog


class Skip(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.closed, self.selected = False, 'close'
		self.skip_option = kwargs.get('skip_option')
		self.window_style, self.swin_duration = kwargs.get('window_style') or self.skip_option.get('skip_style'), kwargs.get('swin_duration') or self.skip_option.get('swin_duration')
		self.focus_button, self.skip_win_no = kwargs.get('focus_button', 201), kwargs.get('skip_win_no', 1)
		self.test = kwargs.get('test', False)
		self.media_type = kwargs.get('media_type', 'movie')
		self.a_skip_t = int(self.skip_option.get('skip')) + 10
		self.skipLabel = 'Skip:'
		self.start_time = time.time()
		self.set_properties()

	def onInit(self):
		try: self.setFocusId(self.focus_button)
		except: pass
		self.monitor()

	def run(self):
		self.doModal()
		self.clearProperties()
		return self.selected

	def skip_close_dialogs(self):
		self.closed = True
		self.close()

	def onAction(self, action):
		if action in self.closing_actions:
			self.skip_close_dialogs()

	def onClick(self, controlID):
		if controlID == 201:
			self.selected = 'True'
			try:
				if self.window_style == 'end_skip': self.player.stop()
				else: self.player.seekTime(self.player.getTime() + self.act_skip_time)
			except: pass
			self.skip_close_dialogs()
		elif controlID in self.closing_actions or controlID == 202: self.skip_close_dialogs()

	def set_properties(self):
		self.setProperty('window_style', str(self.window_style))
		if self.window_style != 'end_skip': self.skipLabel = f'Skip Intro: {self.skip_win_no}~{self.skip_option.get("skip", "0")}'
		self.setProperty('skip_title', self.skipLabel)
		self.setProperty('update_skip', 'Time laps: ')
		self.setProperty('media_type', self.media_type)

	def monitor(self):
		try:
			if self.test: return
			while not self.player.isPlayingVideo():
				self.skip_close_dialogs()
				self.sleep(1000)
			total_time = self.player.getTotalTime()
			end_close = total_time - 4
			while self.player.isPlaying():
				try:
					if self.closed: break
					current_time = self.player.getTime()
					elapsed_time = max((time.time() - self.start_time), 0)
					if float(current_time) >= float(self.swin_duration) or float(current_time) >= float(end_close): self.skip_close_dialogs()
					if self.window_style == 'end_skip':
						self.act_skip_time = int(total_time - current_time) - 2
						self.setProperty('skip_title', f'Skip to End: {self.act_skip_time}')
					else:
						if self.skip_win_no == 1 and self.window_style != 'end_skip':
							if current_time > self.a_skip_t: self.act_skip_time = 0
							else: self.act_skip_time = self.a_skip_t - current_time - 1
						else: self.act_skip_time = int(self.skip_option.get('skip'))
						if self.media_type != 'movie':
							self.setProperty('update_skip', f'Time laps: {int(elapsed_time)}')
							self.setProperty('skip_title', f'Skip Intro: {self.skip_win_no}~{int(self.act_skip_time)}')
					# logger(f'1: {float(current_time) >= float(self.swin_duration)} 2: {float(current_time) >= float(end_close)}')
					self.sleep(1000)
				except: pass
			if not self.player.isPlayingVideo(): self.skip_close_dialogs()
		except: self.skip_close_dialogs()
