# -*- coding: utf-8 -*-
import json
import requests
import shutil

from caches.settings_cache import get_setting, set_setting
from modules.utils import string_alphanum_to_num, unzip
from modules.kodi_utils import logger, refresh_widgets, translate_path, osPath, path_join, delete_file, execute_builtin, get_icon, update_kodi_addons_db, notification, show_text, confirm_dialog, addon_version, confirm_dialog, ok_dialog, update_local_addons, disable_enable_addon, close_all_dialog, select_dialog, show_busy_dialog, hide_busy_dialog

def get_location(insert=''):
	return 'https://github.com/%s/%s/raw/main/packages/%s' % (get_setting('infinite.update.username'), get_setting('update.location'), insert)

def get_versions():
	try:
		result = requests.get(get_location('infinite_version'))
		if result.status_code != 200: return None, None
		online_version = result.text.replace('\n', '')
		current_version = addon_version()
		return current_version, online_version
	except: return None, None

def get_changes(online_version=None):
	d_icon = get_icon('downloads')
	try:
		if not online_version:
			current_version, online_version = get_versions()
			if not version_check(current_version, online_version): return ok_dialog(heading='Infinite Updater', text='You are running the current version of Infinite.[CR][CR]There is no new version changelog to view.')
		show_busy_dialog()
		result = requests.get(get_location('infinite_changes'))
		hide_busy_dialog()
		if result.status_code != 200: return notification('Error', icon=d_icon)
		changes = result.text
		return show_text('New Online Release (v.%s) Changelog' % online_version, text=changes, font_size='large')
	except:
		hide_busy_dialog()
		return notification('Error', icon=d_icon)

def version_check(current_version, online_version):
	return string_alphanum_to_num(current_version) != string_alphanum_to_num(online_version)

def update_check(action=4):
	if action == 3: return
	current_version, online_version = get_versions()
	if not current_version: return
	show_after_action = True
	if not version_check(current_version, online_version):
		if action == 4: return ok_dialog(heading='Infinite Updater', text='Installed Version: [B]%s[/B][CR]Online Version: [B]%s[/B][CR][CR] %s' % (current_version, online_version, '[B]No Update Available[/B]'))
		return
	if action in (0, 4):
		if not confirm_dialog(heading='Infinite Updater', text='Installed Version: [B]%s[/B][CR]Online Version: [B]%s[/B][CR][CR] %s' \
			% (current_version, online_version, '[B]An Update is Available[/B][CR]Perform Update?'), ok_label='Yes', cancel_label='No'): return
		if confirm_dialog(heading='Infinite Updater', text='Do you want to view the changelog for the new release before installing?', ok_label='Yes', cancel_label='No'):
			get_changes(online_version)
			if not confirm_dialog(heading='Infinite Updater', text='Continue with Update After Viewing Changes?', ok_label='Yes', cancel_label='No'): return
			show_after_action = False
	if action == 1: notification('Infinite Update Occuring', icon=get_icon('downloads'))
	elif action == 2: return notification('Infinite Update Available', icon=get_icon('downloads'))
	return update_addon(online_version, action, show_after_action)

def rollback_check():
	current_version = get_versions()[0]
	url = 'https://api.github.com/repos/%s/%s/contents/packages' % (get_setting('update.username'), get_setting('update.location'))
	show_busy_dialog()
	results = requests.get(url)
	hide_busy_dialog()
	if results.status_code != 200: return ok_dialog(heading='Infinite Updater', text='Error rolling back.[CR]Please install rollback manually')
	results = results.json()
	results = [i['name'].split('-')[1].replace('.zip', '') for i in results if 'plugin.video.infinite' in i['name'] \
				and not i['name'].split('-')[1].replace('.zip', '') == current_version]
	if not results: return ok_dialog(heading='Infinite Updater', text='No previous versions found.[CR]Please install rollback manually')
	results.sort(reverse=True)
	list_items = [{'line1': item, 'icon': get_icon('downloads')} for item in results]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Choose Rollback Version'}
	rollback_version = select_dialog(results, **kwargs)
	if rollback_version == None: return
	if not confirm_dialog(heading='Infinite Updater',
		text='Are you sure?[CR]Version [B]%s[/B] will overwrite your current installed version.[CR]Infinite will set your update action to [B]OFF[/B] if rollback is successful' \
		% rollback_version): return
	update_addon(rollback_version, 5)

def update_addon(new_version, action, show_after_action=True):
	close_all_dialog()
	execute_builtin('ActivateWindow(Home)', True)
	notification('Infinite Performing Rollback' if action == 5 else 'Infinite Performing Update', icon=get_icon('downloads'))
	zip_name = 'plugin.video.infinite-%s.zip' % new_version
	url = get_location('%s') % zip_name
	show_busy_dialog()
	result = requests.get(url, stream=True)
	hide_busy_dialog()
	if result.status_code != 200: return ok_dialog(heading='Infinite Updater', text='Error Updating.[CR]Please install new update manually')
	zip_location = path_join(translate_path('special://home/addons/packages/'), zip_name)
	with open(zip_location, 'wb') as f: shutil.copyfileobj(result.raw, f)
	shutil.rmtree(path_join(translate_path('special://home/addons/'), 'plugin.video.infinite'))
	success = unzip(zip_location, translate_path('special://home/addons/'), translate_path('special://home/addons/plugin.video.infinite/'))
	delete_file(zip_location)
	if not success: return ok_dialog(heading='Infinite Updater', text='Error Updating.[CR]Please install new update manually')
	if action == 5:
		set_setting('update.action', '3')
		ok_dialog(heading='Infinite Updater', text='[CR]Success.[CR]Infinite rolled back to version [B]%s[/B]' % new_version)
	elif action in (0, 4):
		if show_after_action:
			if confirm_dialog(heading='Infinite Updater', text='[CR]Success.[CR]Infinite updated to version [B]%s[/B]' % new_version, ok_label='Changelog', cancel_label='Exit', default_control=10) != False:
				show_text('Changelog', file=translate_path('special://home/addons/plugin.video.infinite/resources/text/changelog.txt'), font_size='large')
		else:
			ok_dialog(heading='Infinite Updater', text='[CR]Success.[CR]Infinite updated to version [B]%s[/B]' % new_version)
	update_local_addons()
	disable_enable_addon()
	update_kodi_addons_db()
	refresh_widgets()