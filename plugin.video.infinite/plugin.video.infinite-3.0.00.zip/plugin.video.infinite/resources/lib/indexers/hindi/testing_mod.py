# -*- coding: utf-8 -*-

import datetime
import time
from traceback import print_exc

from apis.trakt_api import trakt_sync_activities
from caches.base_cache import clean_databases, clrcache_version_update
from caches.main_cache import main_cache
from caches.settings_cache import get_setting
from indexers.hindi.lists import youtube_m3u
from modules.kodi_utils import Thread, close_all_dialog, confirm_dialog, logger, monitor, notification, ok_dialog, show_text, sleep, tmdb_default_api
from modules.metadata import tvshow_meta
from modules.watched_status import get_progress_percent, get_bookmarks
from modules.settings import auto_nextep_settings, get_folderscraper_info
from windows.base_window import create_window, open_window
from windows.skip import updateskip_data

from modules.source_utils import get_external_sources
from modules.utils import get_datetime
from scrapers import folders

meta = {'tmdb_id': 92830, 'tvdb_id': 393199, 'imdb_id': 'tt8466564', 'rating': 7.167, 'plot': 'Obi-Wan’s mission brings him to a crime-ridden world, home to all manner of scum and villainy.', 'tagline': 'Between darkness and defeat, hope survives.', 'votes': 1483, 'premiered': '2022-05-26', 'year': '2022', 'poster': 'https://image.tmdb.org/t/p/w780/qJRB789ceLryrLvOKrZqLKr2CGf.jpg', 'fanart': 'https://image.tmdb.org/t/p/w1280/vNPm1WG15IJHpsemb9ZRurm4ZC4.jpg', 'genre': ['Sci-Fi & Fantasy, Action & Adventure'], 'title': 'Obi-Wan Kenobi', 'original_title': 'Obi-Wan Kenobi', 'english_title': '', 'season_data': [{'air_date': '2022-05-26', 'episode_count': 6, 'id': 130857, 'name': 'Miniseries', 'overview': '', 'poster_path': '/oPkm7vwYCa1McT8jEIFWLj393s4.jpg', 'season_number': 1, 'vote_average': 6.5}], 'alternative_titles': ['Star Wars: Obi-Wan Kenobi'], 'duration': 1800, 'rootname': 'Obi-Wan Kenobi (2022)', 'imdbnumber': 'tt8466564', 'country': ['United States of America'], 'mpaa': 'TV-14', 'trailer': 'plugin://plugin.video.youtube/play/?video_id=3Yh_6_zItPU', 'country_codes': ['US'], 'writer': ['George Lucas'], 'director': [], 'all_trailers': [{'iso_639_1': 'en', 'iso_3166_1': 'US', 'name': 'A Series of Firsts', 'key': 'ZHEDtlCcnrs', 'site': 'YouTube', 'size': 1080, 'type': 'Featurette', 'official': True, 'published_at': '2022-05-18T21:16:49.000Z', 'id': '62856a201f3e600052df73ba'}, {'iso_639_1': 'en', 'iso_3166_1': 'US', 'name': 'Official Trailer', 'key': '3Yh_6_zItPU', 'site': 'YouTube', 'size': 1080, 'type': 'Trailer', 'official': True, 'published_at': '2022-05-04T12:46:12.000Z', 'id': '6272b0dd162bc317ab034744'}, {'iso_639_1': 'en', 'iso_3166_1': 'US', 'name': 'Announcement', 'key': 'gEuirQWecEw', 'site': 'YouTube', 'size': 1080, 'type': 'Featurette', 'official': True, 'published_at': '2022-03-31T15:00:24.000Z', 'id': '6245f95d5a991500484dd25f'}, {'iso_639_1': 'en', 'iso_3166_1': 'US', 'name': 'Teaser Trailer', 'key': 'TWTfhyvzTx0', 'site': 'YouTube', 'size': 1080, 'type': 'Trailer', 'official': True, 'published_at': '2022-03-09T18:47:16.000Z', 'id': '6228f8a22f79150045aff054'}], 'cast': [{'name': 'Ewan McGregor', 'role': 'Obi-Wan Kenobi', 'thumbnail': 'https://image.tmdb.org/t/p/h632/aEmyadfRXTmmR7UW7OXsm5a6smS.jpg'}], 'studio': ['Disney+'], 'extra_info': {'status': 'Ended', 'type': 'Miniseries', 'homepage': 'https://www.disneyplus.com/series/obi-wan-kenobi/2JYKcHv9fRJb', 'created_by': 'N/A', 'next_episode_to_air': None, 'last_episode_to_air': {'id': 3635495, 'name': 'Part VI', 'overview': "Obi-Wan is drawn into a confrontation with Vader, as Luke's fate hangs in the balance.", 'vote_average': 6.897, 'vote_count': 58, 'air_date': '2022-06-22', 'episode_number': 6, 'episode_type': 'finale', 'production_code': '', 'runtime': 52, 'season_number': 1, 'show_id': 92830, 'still_path': '/ncyGm7Ge1dYUMNN5Un336MsEVkr.jpg'}}, 'total_aired_eps': 6, 'mediatype': 'tvshow', 'total_seasons': 1, 'tvshowtitle': 'Obi-Wan Kenobi', 'status': 'Ended', 'clearlogo': 'https://image.tmdb.org/t/p/original/7EsXcf5WLT2vDXIR86tHlHA3qlB.png', 'season': 1, 'episode': 2, 'episode_type': 'season_finale', 'ep_name': 'Part II', 'ep_thumb': 'https://image.tmdb.org/t/p/original/7NvWnQmdBKRfMtKGcdik6NLH7MX.jpg', 'tvshow_plot': 'During the reign of the Galactic Empire, former Jedi Master, Obi-Wan Kenobi, embarks on a crucial mission to confront allies turned enemies and face the wrath of the Empire.', 'custom_season': None, 'custom_episode': None, 'media_type': 'episode', 'background': True, 'custom_title': None, 'custom_year': None, 'skip_option': {'title': 'ObiWan Kenobi', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '300'}, 'skip_style': '0', 'display_name': 'Obi-Wan Kenobi S1E2'}
# meta = {'mediatype': 'episode', 'year': 2022, 'plot': 'The Kapil Sharma Show, also known as TKSS, is an Indian Hindi-language stand-up comedy and talk show broadcast by Sony Entertainment Television. Hosted by Kapil Sharma The series revolved around Sharma and his neighbours in the Shantivan Non Co-operative Housing Society.', 'title': 'The Kapil Sharma Show Season 4', 'studio': ['Sony'], 'poster': 'https://www.desi-serials.cc/wp-content/uploads/2022/08/The-Kapil-Sharma-Show-300x169.jpg', 'homepage': 'https://www.desi-serials.cc/watch-online/sony-tv/the-kapil-sharma-show-season-4/', 'genre': ['Saturday  Sunday.', 'Comedy', 'Talk-Show'], 'cast': [], 'tmdb_id': 'Sony|The Kapil Sharma Show Season 4', 'imdb_id': 'tt5747326', 'rating': 7.3, 'clearlogo': '', 'trailer': '', 'votes': 50, 'tagline': '', 'director': [], 'writer': [], 'episodes': 390, 'seasons': '1, 2, 3, 4', 'extra_info': {'status': '', 'collection_id': ''}, 'tvdb_id': 'Sony|the kapil sharma show', 'duration': 3600, 'mpaa': 'TV-MA', 'season': 4, 'episode': 910, 'tvshowtitle': 'The Kapil Sharma Show Season 4', 'playcount': 0, 'original_title': 'The Kapil Sharma Show Season 4', 'total_seasons': '4', 'url': 'https://www.desi-serials.cc/the-kapil-sharma-show-season-4-episode-10th-september-2022-watch-online/441968/', 'fanart': 'https://www.desi-serials.cc/wp-content/uploads/2022/08/The-Kapil-Sharma-Show-300x169.jpg', 'premiered': '2022-09-10', 'ep_name': '10th September 2022', 'overlay': 4, 'media_type': 'episode', 'background': False, 'skip_option': {'title': 'The Kapil Sharma Show', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '300'}, 'skip_style': 'netflix'}

def testting():
    test_window()


def test_window(win='nextep_win'):
    if win == 'nextep_win': # windows.next_episode <<<<<<<<<
        action = open_window(('windows.next_episode', 'NextEpisode'), 'next_episode.xml', meta=meta, default_action='cancel', test=True)
        if action == 'cancel':
            action = open_window(('windows.skip', 'Skip'), 'skipmulti.xml', skip_option=meta.get('skip_option'), test=True, focus_button=201, window_style='end_skip')
    elif win == 'infopop': # windows.infopop <<<<<<<<<
        action = open_window(('windows.extras', 'Extras'), 'extras.xml', options_media_type=meta.get('media_type'), meta=meta, is_external='false')
    elif win in ('skip_win', 'updateskip', 'end_skip'): # windows.skip <<<<<<<<<<
        skip_option = {'title': 'The Blacklist', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '300'}
        windowstyle = 'netflix'#'Regular'
        # logger(f'windowstyle: {windowstyle.lower()}')
        if win == 'updateskip': updateskip_data(skip_option)
        elif win == 'skip_win': buttonskip = open_window(('windows.skip', 'Skip'), 'skipmulti.xml', test=True, skip_option=skip_option, focus_button=201, media_type='episode', window_style=windowstyle.lower())
        else: buttonskip = open_window(('windows.skip', 'Skip'), 'skipmulti.xml', test=True, skip_option=skip_option, focus_button=201, window_style='end_skip')
    elif win in ('playback', 'resolver', 'resume', 'progress'): # playback && resolver etc<<<<<<<
        # kwargs = {'meta': meta, 'text': 'ok i see', 'enable_buttons': True, 'true_button': 'Yes', 'false_button': 'No', 'focus_button': 11}
        kwargs = {'meta': meta, 'text': 'ok i see', 'enable_fullscreen': True}
        _threads = []
        start_time = time.time()
        scraper_timeout = int(get_setting('results.timeout', '30'))
        sleep_time = 100
        end_time = start_time + scraper_timeout
        from modules.kodi_utils import monitor
        if win in ('playback', 'resolver', 'resume'): progress_dialog = create_window(('windows.sources', 'SourcesPlayback'), 'sources_playback.xml', meta=meta)
        if win == 'progress': progress_dialog = create_window(('windows.progress', 'Progress'), 'progress.xml', heading='progress', icon=meta.get('poster'))
        Thread(target=progress_dialog.run).start()
        if win == 'resolver': progress_dialog.enable_resolver()
        if win == 'resume': progress_dialog.enable_resume(15)
        remaining_providers = ['freeworldnews.tv', 'playersb.com', 'vedshare.com', 'voeunblock8.com', 'youtu.be']
        try:
            while not progress_dialog.iscanceled() and not monitor.abortRequested():
                if progress_dialog.iscanceled(): break
                sources_total = sources_4k = sources_1080p = sources_720p = sources_sd = 5
                current_time = time.time()
                elapsed_time = current_time - start_time
                line1 = ', '.join(remaining_providers).upper()
                percent = int((elapsed_time / float(scraper_timeout)) * 100)
                try:
                    if win == 'playback': progress_dialog.update_scraper(sources_sd, sources_720p, sources_1080p, sources_4k, sources_total, line1, percent)
                    elif win == 'resolver': progress_dialog.update_resolver(percent=elapsed_time)
                    elif win == 'resume': progress_dialog.update_resumer()
                    elif win == 'progress': progress_dialog.update(percent=elapsed_time)
                except: pass
                sleep(10)
                # logger(f'percent: {percent} elapsed_time: {elapsed_time}')
                if percent >= 100: break
                if current_time >= end_time: break
        except: logger(f'error: {print_exc()}')
        progress_dialog.close()
        try: del monitor
        except: pass
    elif win == 'sources_results': # windows.select_ok <<<<<<<<<<<<
        results = [{'source': 'tvarticles', 'quality': 'SD', 'info': 'All part: Single', 'url': 'https://tvarticles.org/vidd.php?id=2239785', 'direct': False, 'name': 'The Kapil Sharma Show S1E226', 'name_info': '', 'display_name': 'The Kapil Sharma Show S1E226', 'provider_site': 'tvarticles', 'scrape_provider': 'external', 'extraInfo': 'All part: Single', 'module_path': 'openscrapers.sources_openscrapers.en.desiserials', 'size_label': None, 'size': 0, 'provider_rank': 2, 'quality_rank': 4 }, {'source': 'gdrive', 'name': 'Modern.Family.S11E08.720p.WEB-HD.x264-Pahe.in.mkv', 'name_info': '.720p.web.hd.x264.pahe.in.mkv.', 'quality': '720p', 'url': 'https://gd.djp97s.workers.dev/Modern.Family.S11E08.720p.WEB-HD.x264-Pahe.in.mkv', 'info': 'AVC | WEB | MKV', 'direct': True, 'size': 0.15, 'display_name': 'Modern Family S11E8', 'provider_site': 'gdrive', 'scrape_provider': 'external', 'extraInfo': 'AVC | WEB | MKV', 'module_path': 'openscrapers.sources_openscrapers.en.gdrive', 'size_label': '0.15 GB', 'provider_rank': 2, 'quality_rank': 3 }, {'source': 'mixdrop.co', 'quality': 'SD', 'info': 'MP4 | ', 'url': 'https://mixdrop.co/e/wn6dpeo6szdwlx', 'direct': False, 'name': 'Modern Family S11E8', 'name_info': '', 'display_name': 'Modern Family S11E8', 'provider_site': '123moviestv_me', 'scrape_provider': 'external', 'extraInfo': '', 'module_path': 'openscrapers.sources_openscrapers.en.123moviestv_me', 'size_label': None, 'size': 0, 'provider_rank': 2, 'quality_rank': 4 }]
        scraper_settings = {'highlight_type': 2, 'hoster_highlight': '', 'torrent_highlight': '', 'real-debrid': '', 'premiumize': '', 'alldebrid': '', 'rd_cloud': '', 'pm_cloud': '', 'ad_cloud': '', 'furk': '', 'easynews': '', 'folders': '', '4k': 'FFFF3334', '1080p': 'FFE6B800', '720p': 'FF3C9900', 'sd': 'FFCAFFFF'}
        action = open_window(('windows.sources', 'SourcesResults'), 'sources_results.xml', window_format='list', window_style='non_contrast', window_id=2000, results=results, meta=meta, scraper_settings=scraper_settings, prescrape=False, filters_ignored=False, uncached_results=[])
        if not action: close_all_dialog()
    elif win == 'select_ok_win': # windows.select_ok <<<<<<<<<<<<
        confirm_dialog()
        ok_dialog()
        show_text(heading='Infinite', text='ok i c')

def cache_test():
    ctime = datetime.datetime.now()
    current_time = int(time.mktime(ctime.timetuple()))
    clean_databases(current_time, database_check=False, silent=True)
    youtube_m3u()
    main_cache.clean_hindi_lists()
    clrcache_version_update(clr_cache=True, clr_navigator=False)
    status = trakt_sync_activities()
    logger(f'status: {status}')

def get_meta():
    current_date = get_datetime
    ep_data_get = {'media_ids': {'tmdb': 93812}, 'season': 2}
    meta = tvshow_meta('trakt_dict', ep_data_get['media_ids'], tmdb_default_api, current_date)
    logger(f'meta: {meta}')

def get_folders():
    folder_info, internal_scraper_names = get_folderscraper_info()
    # logger(f'folder_info: {folder_info}\ninternal_scraper_names: {internal_scraper_names}')
    prescrape_scrapers = []
    info = {'media_type': 'movie', 'title': 'Star Wars: The Last Jedi', 'year': '2017', 'tmdb_id': 181808, 'imdb_id': 'tt2527336', 'aliases': [{'title': 'Star Wars: Episode VIII', 'country': ''}, {'title': 'Star Wars: Episode VIII – The Last Jedi', 'country': ''}, {'title': 'The Last Jedi', 'country': ''}, {'title': 'Star Wars - The Last Jedi - 3D', 'country': ''}, {'title': 'Star Wars: Episode VIII - The Last Jedi: Legendary', 'country': ''}, {'title': 'Star Wars: Episode 8 - The Last Jedi', 'country': ''}, {'title': 'Star Wars Episode VIII - The Last Jedi', 'country': ''}, {'title': 'Star Wars: Episode VIII - The Last Jedi 3D', 'country': ''}, {'title': 'Star Wars։ Episode VIII - The Last Jedi', 'country': ''}, {'title': 'Star Wars 8 - The Last Jedi', 'country': ''}, {'title': 'Star Wars: Episode VIII - The Last Jedi', 'country': ''}, {'title': 'Star Wars։ The Last Jedi (Episode VIII)', 'country': ''}, {'title': 'TLJ', 'country': ''}, {'title': 'Star Wars: The Last Jedi', 'country': ''}, {'title': 'Star Wars: The Last Jedi US', 'country': ''}], 'season': None, 'episode': None, 'tvdb_id': 'None', 'ep_name': None, 'expiry_times': (336, 0, 0), 'total_seasons': 1}
    scrape_provider, scraper_name, folder_path = 'folder1', 'English Enet', 'smb://cp:srusty@ENET/Media/ENet/English Movies/'
    info = {'media_type': 'episode', 'title': '24', 'year': '2001', 'tmdb_id': 1973, 'imdb_id': 'tt0285331', 'aliases': [{'title': 'Twenty Four', 'country': ''}, {'title': '24: Live Another Day', 'country': ''}, {'title': '24', 'country': ''}, {'title': '24 US', 'country': ''}], 'season': 8, 'episode': 6, 'tvdb_id': 76290, 'ep_name': 'Day 8: 12:00 A.M.-1:00 A.M.', 'expiry_times': (240, 720, 720), 'total_seasons': 9}
    scrape_provider, scraper_name, folder_path = 'folder4', 'D drive TV Shows', 'D:/My Media/TV Shows/'
    folders_sraper = folders.source(scrape_provider, scraper_name, folder_path)
    results = folders_sraper.results(info)
    logger(f'folder_results: {results}')
    scraper_settings = {'highlight_type': 2, 'hoster_highlight': '', 'torrent_highlight': '', 'real-debrid': '', 'premiumize': '', 'alldebrid': '', 'rd_cloud': '', 'pm_cloud': '', 'ad_cloud': '', 'furk': '', 'easynews': '', 'folders': '', '4k': 'FFFF3334', '1080p': 'FFE6B800', '720p': 'FF3C9900', 'sd': 'FFCAFFFF'}
    if not results: notification('no result'); return
    action = open_window(('windows.sources', 'SourcesResults'), 'sources_results.xml',
            window_format='list', window_style='non_contrast', window_id=2000, results=results, meta=meta,
            scraper_settings=scraper_settings, prescrape=False, filters_ignored=False, uncached_torrents=[])
    if not action: close_all_dialog()

def get_next_ep():
    from modules.episode_tools import EpisodeTools
    nextep_settings = auto_nextep_settings('autoplay_nextep')
    # nextep_settings = {'scraper_time': 70, 'window_percentage': 10, 'alert_method': 0, 'default_action': 'play', 'use_chapters': True, 'play_type': 'autoscrape_nextep'}
    nextep_settings.update({'window_time': 100, 'play_type': 'autoplay_nextep'})
    logger(f'nextep_settings: {nextep_settings}')
    url_params = EpisodeTools(meta, nextep_settings).next_episode_info()
    logger(f'url_params: {url_params}')

def get_yt_dl():
    from modules.downloader import yt_dl
    yt_dl()

def get_sources():
    ret_all, media_type, vid_type = False, 'episode', None
    external_providers = get_external_sources(ret_all, media_type, vid_type)
    logger(f'get_external_sources: {len(external_providers)} :: {external_providers}')


def get_percent():
    watched_indicators = 1
    media_type = 'movie'
    tmdb_id = 1051
    season = episode = ''
    percent = get_progress_percent(get_bookmarks(watched_indicators, media_type), tmdb_id, season, episode)
    logger(f'percent: {percent}')