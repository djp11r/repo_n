# -*- coding: utf-8 -*-
from traceback import print_exc
from caches.base_cache import connect_database, get_timestamp
from modules.kodi_utils import confirm_dialog
from modules.kodi_utils import logger

SELECT_RESULTS = 'SELECT results, expires FROM results_data WHERE provider = ? AND db_type = ? AND tmdb_id = ? AND title = ? AND year = ? AND season = ? AND episode = ?'
DELETE_RESULTS = 'DELETE FROM results_data WHERE provider = ? AND db_type = ? AND tmdb_id = ? AND title = ? AND year = ? AND season = ? AND episode = ?'
INSERT_RESULTS = 'INSERT OR REPLACE INTO results_data VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
SINGLE_DELETE = 'DELETE FROM results_data WHERE db_type=? AND tmdb_id=?'
FULL_DELETE = 'DELETE FROM results_data'
CLEAN = 'DELETE from results_data WHERE CAST(expires AS INT) <= ?'

class ExternalCache(object):
	def get(self, source, media_type, tmdb_id, title, year, season, episode):
		result = None
		try:
			cache_data = self._execute(SELECT_RESULTS, (source, media_type, tmdb_id, title, year, season, episode)).fetchone()
			if cache_data:
				if cache_data[1] > get_timestamp(): result = eval(cache_data[0])
				else: self.delete(source, media_type, tmdb_id, title, season, episode)
		except: pass
		return result

	def set(self, source, media_type, tmdb_id, title, year, season, episode, results, expire_time):
		try:
			expires = get_timestamp(expire_time)
			self._execute(INSERT_RESULTS, (source, media_type, tmdb_id, title, year, season, episode, repr(results or []), int(expires)))
		except: pass

	def delete(self, source, media_type, tmdb_id, title, season, episode):
		try: self._execute(DELETE_RESULTS, (source, media_type, tmdb_id, title, season, episode))
		except: return

	def delete_cache(self, silent=False):
		try:
			if not silent and not confirm_dialog(): return 'cancelled'
			self._execute(FULL_DELETE, ())
			self._vacuum()
			return 'success'
		except: return 'failure'

	def delete_cache_single(self, media_type, tmdb_id):
		try:
			self._execute(SINGLE_DELETE, (media_type, tmdb_id))
			self._vacuum()
			return True
		except: return False

	def _execute(self, command, params):
		dbcon = connect_database('external_db')
		return dbcon.execute(command, params)

	def clean_database(self):
		try:
			dbcon = connect_database('external_db')
			dbcon.execute(CLEAN, (get_timestamp(),))
			dbcon.close()
			self._vacuum()
			return True
		except: return False

	def _vacuum(self):
		dbcon = connect_database('external_db')
		dbcon.execute('VACUUM')
		dbcon.close()

	def _executemany(self, command, insert_list):
		dbcon = connect_database('external_db')
		return dbcon.executemany(command, insert_list)

	def get_all_data(self, table_name='scr_perf'):
		try:
			dbcon = connect_database('external_db')
			if cache_data := dbcon.execute(f'SELECT * FROM {table_name}').fetchall():
				# logger(f'ExternalCache get_all_data cache_data: {cache_data}')
				return cache_data
		except Exception as e:
			logger(f'ExternalCache get_all_data Error: {print_exc()} e: {e}')
		return []

external_cache = ExternalCache()



def get_provider():
	try:
		scraper_stats = external_cache.get_all_data('prov_perf')
		scraper_stats.sort(key=lambda a: a[1], reverse=True)
		return [str(i[0]) for i in scraper_stats]
	except: return ['meomeo', 'bestarticles', 'streamtape', 'upstream', 'mlions', 'doods', 'streamwish', 'tvarticles', 'furher', 'dood', 'embedwish', 'wishfast', 'ds2play', 'vidoza', 'gdrive', 'vidmoly', 'youtube', 'streamvid', 'mdbekjwqa', 'obeywish', 'filelions', 'server4', 'eplayvid', 'mwish', '2embed', 'doodstream', 'vtube', 'filemoon', 'youdbox', 'credits', 'tvpost', 'bollyfunmaza']

def external_scrapers_fail_stats():
	results = external_cache.get_all_data()
	results = sorted([(str(i[0]), i[1], i[2]) for i in results], key=lambda k: k[2] - k[1], reverse=False)
	return results

def sourcesstats(sourcedict, sources):
	try:
		insert_list = []
		all_sources = [i[0] for i in sourcedict if all(x not in i[0] for x in ('season', 'show'))]
		working_scrapers = sorted(list({i['provider_site'] for i in sources}))
		non_working_scrapers = sorted([i for i in all_sources if i not in working_scrapers])
		scraper_stats = external_cache.get_all_data()
		if scraper_stats:
			for i in scraper_stats:
				try:
					scraper, success, fail = str(i[0]), i[1], i[2]
					if scraper in working_scrapers:
						insert_list.append((scraper, success + 1, fail))
						working_scrapers.remove(scraper)
					else:
						insert_list.append((scraper, success, fail + 1))
						non_working_scrapers.remove(scraper)
				except: pass
		if len(working_scrapers) > 0: insert_list.extend((scraper, 1, 0) for scraper in working_scrapers)
		if len(non_working_scrapers) > 0: insert_list.extend((scraper, 0, 1) for scraper in non_working_scrapers)
		if insert_list: external_cache._executemany("INSERT OR REPLACE INTO scr_perf VALUES (?, ?, ?)", insert_list)
	except: logger(f'sourcesstats Error: {print_exc()}')

def providerstats(info):
	try:
		insert_list = []
		working_source = str(info).split('.')[0]
		if 'Folder' in working_source: return
		c_data = external_cache._execute("SELECT success FROM prov_perf WHERE source = ?", (working_source,)).fetchone()
		# logger(f'c_data {c_data}', __name__)
		if c_data: insert_list.append((working_source, c_data[0] + 1, ''))
		else: insert_list.append((working_source, 1, ''))
		if insert_list: external_cache._executemany("INSERT OR REPLACE INTO prov_perf VALUES (?, ?, ?)", insert_list)
	except: logger(f'providerstats Error: {print_exc()}')

def external_scrapers_reset_stats():
	try:
		def reset_data(scraper_stats):
			insert_list = []
			for i in scraper_stats:
				success = 1
				try:
					if i[1] > 1: success = 1 if i[1]//2 < 1 else int(i[1]//2)
				except: pass
				insert_list.append((i[0], success, 1))
			return insert_list
		external_cache._execute("DELETE FROM scr_perf WHERE success IS NULL OR success = '0'", ())
		if scraper_stats := external_cache.get_all_data():
			insert_list = reset_data(scraper_stats)
			if insert_list: external_cache._executemany("INSERT OR REPLACE INTO scr_perf VALUES (?, ?, ?)", insert_list)
		if scraper_stats := external_cache.get_all_data('prov_perf'):
			insert_list = reset_data(scraper_stats)
			if insert_list: external_cache._executemany("INSERT OR REPLACE INTO prov_perf VALUES (?, ?, ?)", insert_list)
		return True
	except:
		logger(f'external_scrapers_reset_stats Error: {print_exc()}')
		return False