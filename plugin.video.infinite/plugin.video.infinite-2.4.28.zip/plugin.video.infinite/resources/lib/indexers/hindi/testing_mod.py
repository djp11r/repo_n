# -*- coding: utf-8 -*-

from modules.kodi_utils import logger
from modules.settings_reader import get_setting
from windows.skip import Skip
from windows import open_window, create_window
import datetime
import time
# from caches import clean_databases


def testting():
    test_window()


def test_window():
    # nextep_meta = {'title': 'The Blacklist', 'season': 5, 'episode': 5, 'ep_name': 'ZZZZ'}
    # action = open_window(('windows.next_episode', 'NextEpisode'), 'next_episode.xml', meta=nextep_meta, function='next_ep')
    # logger(f'action: {action}')
    # location = skin_location()
    # skip_option = {'title': 'The Blacklist', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '300'}

    # open_window(('windows.next_episode', 'NextEpisode'), 'next_episode.xml', meta=nextep_meta, function='next_ep')
    # if get_setting('skip.dialog') == "Regular":
        # buttonskip = open_window(('windows.skip', 'Skip'), 'skip_dialog.xml', skip_option=skip_option)
        # # buttonskip = Skip("skip_dialog.xml", location, "default", "1080i", skip_option=self.skip_option)
    # else:
        # buttonskip = open_window(('windows.skip', 'Skip'), 'skip.xml', skip_option=skip_option)
    # # buttonskip = open_window(('windows.skip', 'UpdateSkip'), 'skipupdate.xml', skip_option=skip_option)
    # logger(f'buttonskip: {buttonskip}')
    close_dialog = False
    start_time = time.time()
    end_time = start_time + 60

    meta = {'mediatype': 'episode', 'year': 2022, 'plot': 'Monday   Friday\nCrime Patrol is an Indian Hindi crime anthology series created by Subramanian S.lyer for Sony Entertainment Television India and Sony Entertainment Television Asia. The Series Currently airing its fifth season.', 'title': 'Crime Patrol', 'studio': 'Sony', 'poster': 'https://www.desi-serials.cc/wp-content/uploads/2020/08/Crime-Patrol-300x169.jpg', 'homepage': 'https://www.desi-serials.cc/watch-online/sony-tv/crime-patrol-season-4-updateslatest/', 'genre': 'Monday   Friday, Crime, Drama, Mystery, Reality-TV', 'cast': [], 'tmdb_id': 'Sony|Crime Patrol', 'imdb_id': 'tt1921518', 'rating': 7.9, 'clearlogo': '', 'trailer': '', 'votes': 50, 'tagline': '', 'director': '', 'writer': '', 'episodes': 764, 'seasons': '1, 2, 3, 4, 23', 'extra_info': {'status': '', 'collection_id': ''}, 'tvdb_id': 'Sony|crime patrol', 'duration': 2520, 'mpaa': 'TV-MA', 'episode': 428, 'tvshowtitle': 'Crime Patrol', 'playcount': 0, 'original_title': 'Crime Patrol', 'total_seasons': 1, 'url': 'https://www.desi-serials.cc/crime-patrol-episode-28th-april-2022-watch-online/424912/', 'fanart': 'https://www.desi-serials.cc/wp-content/uploads/2020/08/Crime-Patrol-300x169.jpg', 'premiered': 2003, 'season': 1, 'ep_name': '28th April 2022', 'media_type': 'episode', 'background': False, 'skip_option': {'title': 'Crime Patrol', 'service': 'True', 'skip': '15', 'start': '10', 'eskip': '300'}}
    # meta = {'tmdb_id': 66732, 'tvdb_id': 305288, 'imdb_id': 'tt4574334', 'rating': 8.6, 'plot': "After Will sees something terrible on trick-or-treat night, Mike wonders whether Eleven's still out there. Nancy wrestles with the truth about Barb.", 'tagline': 'It only gets stranger…', 'votes': 10430, 'premiered': '2017-10-27', 'year': '2016', 'poster': 'https://image.tmdb.org/t/p/w342/49WJfeN0moxb9IPfGn8AIqMGskD.jpg', 'fanart': 'https://image.tmdb.org/t/p/w780/56v2KjBlU4XaOv9rVYEQypROD7P.jpg', 'genre': ['Sci-Fi & Fantasy', 'Drama', 'Mystery'], 'title': 'Stranger Things', 'original_title': 'Stranger Things', 'english_title': '', 'season_data': [{'air_date': '2016-07-15', 'episode_count': 8, 'id': 77680, 'name': 'Season 1', 'overview': "Strange things are afoot in Hawkins, Indiana, where a young boy's sudden disappearance unearths a young girl with otherworldly powers.", 'poster_path': '/zka9GTG4QQhLmN4NR18KEjxICtt.jpg', 'season_number': 1}, {'air_date': '2017-10-27', 'episode_count': 9, 'id': 83248, 'name': 'Stranger Things 2', 'overview': "It's been nearly a year since Will's strange disappearance. But life's hardly back to normal in Hawkins. Not even close.", 'poster_path': '/lXS60geme1LlEob5Wgvj3KilClA.jpg', 'season_number': 2}, {'air_date': '2019-07-04', 'episode_count': 8, 'id': 115216, 'name': 'Stranger Things 3', 'overview': "Budding romance. A brand-new mall. And rabid rats running toward danger. It's the summer of 1985 in Hawkins ... and one summer can change everything.", 'poster_path': '/x2LSRK2Cm7MZhjluni1msVJ3wDF.jpg', 'season_number': 3}, {'air_date': '2022-05-27', 'episode_count': 9, 'id': 163313, 'name': 'Stranger Things 4', 'overview': "It’s been six months since the Battle of Starcourt, which brought terror and destruction to Hawkins. Struggling with the aftermath, our group of friends are separated for the first time – and navigating the complexities of high school hasn't made things any easier. In this most vulnerable time, a new and horrifying supernatural threat surfaces, presenting a gruesome mystery that, if solved, might finally put an end to the horrors of the Upside Down.", 'poster_path': '/49WJfeN0moxb9IPfGn8AIqMGskD.jpg', 'season_number': 4}], 'alternative_titles': ['Stranger Things 2', 'Stranger Things 3'], 'duration': 3000, 'rootname': 'Stranger Things (2016)', 'imdbnumber': 'tt4574334', 'country': ['United States of America'], 'mpaa': 'TV-14', 'trailer': 'plugin://plugin.video.youtube/play/?video_id=mnd7sFt5c3A', 'country_codes': ['US'], 'writer': [], 'director': [], 'all_trailers': [{'iso_639_1': 'en', 'iso_3166_1': 'US', 'name': 'Stranger Things Season 1 Trailer 1 | Rotten Tomatoes TV', 'key': 'mnd7sFt5c3A', 'site': 'YouTube', 'size': 1080, 'type': 'Trailer', 'official': False, 'published_at': '2018-03-06T16:58:29.000Z', 'id': '61d875b73344c6001d527dbc'}, {'iso_639_1': 'en', 'iso_3166_1': 'US', 'name': 'Title Sequence', 'key': '-RcPZdihrp4', 'site': 'YouTube', 'size': 1080, 'type': 'Opening Credits', 'official': True, 'published_at': '2016-08-06T00:24:44.000Z', 'id': '5d272738caab6d0012974c66'}, {'iso_639_1': 'en', 'iso_3166_1': 'US', 'name': 'Trailer 2', 'key': 'b9EkMc79ZSU', 'published_at': '2016-06-30T14:30:02.000Z', 'site': 'YouTube', 'size': 1080, 'type': 'Trailer', 'official': True, 'id': '579b5e61c3a368703800104b'}], 'cast': [{'name': 'Winona Ryder', 'role': 'Joyce Byers', 'thumbnail': 'https://image.tmdb.org/t/p/w342/8fxYCop2U74EWzm7tjOXM5Xrr7L.jpg'}, {'name': 'Millie Bobby Brown', 'role': 'Eleven', 'thumbnail': 'https://image.tmdb.org/t/p/w342/yzfxLMcBMusKzZp9f1Z9Ags8WML.jpg'}, {'name': 'Finn Wolfhard', 'role': 'Mike Wheeler', 'thumbnail': 'https://image.tmdb.org/t/p/w342/p0ayyuQWPnTvbCaN7E2ROetuLVs.jpg'}, {'name': 'Caleb McLaughlin', 'role': 'Lucas Sinclair', 'thumbnail': 'https://image.tmdb.org/t/p/w342/6YjorSZyqFBl3f4sgcCQmOc1yoi.jpg'}, {'name': 'Gaten Matarazzo', 'role': 'Dustin Henderson', 'thumbnail': 'https://image.tmdb.org/t/p/w342/gfxSa9pwafFEyzok6N4sIVbJLS.jpg'}, {'name': 'David Harbour', 'role': 'Jim Hopper', 'thumbnail': 'https://image.tmdb.org/t/p/w342/chPekukMF5SNnW6b22NbYPqAStr.jpg'}, {'name': 'Sadie Sink', 'role': 'Max Mayfield', 'thumbnail': 'https://image.tmdb.org/t/p/w342/qouCh22I7LZtEJ2THaDsSv0W0ma.jpg'}, {'name': 'Noah Schnapp', 'role': 'Will Byers', 'thumbnail': 'https://image.tmdb.org/t/p/w342/3GSWWrqQjio6G8L42ugGBGNks37.jpg'}, {'name': 'Natalia Dyer', 'role': 'Nancy Wheeler', 'thumbnail': 'https://image.tmdb.org/t/p/w342/abiDpvKQy5yqa8BazNx3nb0aD8c.jpg'}, {'name': 'Matthew Modine', 'role': 'Martin Brenner', 'thumbnail': 'https://image.tmdb.org/t/p/w342/z974QEHL12qUvLyk6hlWGAmDgom.jpg'}, {'name': 'Charlie Heaton', 'role': 'Jonathan Byers', 'thumbnail': 'https://image.tmdb.org/t/p/w342/lTFj22o0odUj9MfzjLvBtjfGyOT.jpg'}, {'name': 'Joe Keery', 'role': 'Steve Harrington', 'thumbnail': 'https://image.tmdb.org/t/p/w342/8B45gAoJx4OvrYqCWid51MBXfeK.jpg'}, {'name': 'Priah Ferguson', 'role': 'Erica Sinclair', 'thumbnail': 'https://image.tmdb.org/t/p/w342/pz4gTE1DLr8dr2n0tocQpraWDmv.jpg'}, {'name': 'Maya Hawke', 'role': 'Robin Buckley', 'thumbnail': 'https://image.tmdb.org/t/p/w342/x5uO7gRm7dMvrqNtrRBoW4vqVi3.jpg'}, {'name': 'Paul Reiser', 'role': 'Sam Owens', 'thumbnail': 'https://image.tmdb.org/t/p/w342/v3e5TClep4ugMdU4qSRiKbvLr3B.jpg'}, {'name': 'Brett Gelman', 'role': 'Murray Bauman', 'thumbnail': 'https://image.tmdb.org/t/p/w342/ub2IuMWFNQGYghHTPq0lpmn2Ue0.jpg'}], 'studio': ['Netflix'], 'extra_info': {'status': 'Returning Series', 'type': 'Scripted', 'homepage': 'https://www.netflix.com/title/80057281', 'created_by': 'Matt Duffer, Ross Duffer', 'next_episode_to_air': {'air_date': '2022-07-01', 'episode_number': 8, 'id': 3325041, 'name': 'Chapter Eight: Papa', 'overview': '', 'production_code': '', 'runtime': 85, 'season_number': 4, 'still_path': None, 'vote_average': 0.0, 'vote_count': 0}, 'last_episode_to_air': {'air_date': '2022-05-27', 'episode_number': 7, 'id': 3325040, 'name': 'Chapter Seven: The Massacre at Hawkins Lab', 'overview': "As Hopper braces to battle a monster, Dustin dissects Vecna's motives — and decodes a message from beyond. El finds strength in a distant memory.", 'production_code': '', 'runtime': 100, 'season_number': 4, 'still_path': '/qCNQuBaxcgN26e79kLAofWV8LP6.jpg', 'vote_average': 9.235, 'vote_count': 17}}, 'total_aired_eps': 32, 'mediatype': 'tvshow', 'total_seasons': 4, 'tvshowtitle': 'Stranger Things', 'status': 'Returning Series', 'poster2': 'http://assets.fanart.tv/fanart/tv/305288/tvposter/stranger-things-578c9b2cb3497.jpg', 'fanart2': 'http://assets.fanart.tv/fanart/tv/305288/showbackground/stranger-things-5ccf1cdcc82b6.jpg', 'banner': 'http://assets.fanart.tv/fanart/tv/305288/tvbanner/stranger-things-57bafc53b9a18.jpg', 'clearart': 'http://assets.fanart.tv/fanart/tv/305288/hdclearart/stranger-things-57bafc0c3c60f.png', 'clearlogo': 'http://assets.fanart.tv/fanart/tv/305288/hdtvlogo/stranger-things-575abc2aba154.png', 'landscape': 'http://assets.fanart.tv/fanart/tv/305288/tvthumb/stranger-things-5a62665fea007.jpg', 'discart': '', 'fanart_added': True, 'media_type': 'episode', 'season': 2, 'episode': 2, 'ep_name': 'Chapter Two: Trick or Treat, Freak', 'background': False, 'skip_option': {'title': 'Stranger Things', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '60'}}
    progress_dialog = create_window(('windows.yes_no_progress_media', 'YesNoProgressMedia'), 'yes_no_progress_media.xml', meta=meta)
    logger(f'progress_dialog: {progress_dialog}')
    
    progress_dialog.run()

    for i in range(0, 100, 5):
        current_time = time.time()
        current_progress = max((current_time - start_time), 0)
        percent = (current_progress/float(30))*100
        logger(f'progress_dialog percent: {percent}')
        progress_dialog.update('%s[CR]%s[CR]%s' % ('line1', 'line2', 'line3'), percent)
        if percent >= 100: close_dialog = True; break
    if close_dialog:
        try: progress_dialog.close()
        except: pass


def cache_test():
    ctime = datetime.datetime.now()
    current_time = int(time.mktime(ctime.timetuple()))
    clean_databases(current_time, database_check=False, silent=True)
    from modules.source_utils import sources
    providers = sources('true', 'episode')
    from indexers.hindi.lists import youtube_m3u
    youtube_m3u()
    from caches.h_cache import MainCache
    MainCache().clean_hindi_lists()
    logger(providers)
    from caches import clrCache_version_update
    clrCache_version_update(clr_cache=True, clr_navigator=False)
    from apis.trakt_api import trakt_sync_activities
    status = trakt_sync_activities()
    logger(f'status: {status}')


def dl_db_file():
    params = {
    'mode': 'downloader',
    'action': 'cloud_file',
    'name': 'metacache_test',
    'url': 'https://github.com/djp11r/repojp/blob/master/etc/allxml/metacache.db?raw=true',
    'media_type': 'file'}
    from modules.downloader import runner
    runner(params)