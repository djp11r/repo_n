# -*- coding: utf-8 -*-

from modules.kodi_utils import logger
from modules.settings_reader import get_setting
from windows.skip import Skip
from windows import open_window, create_window
import datetime
import time
# from caches import clean_databases


def testting():
    dl_db_file()


def test_window():
    # nextep_meta = {'title': 'The Blacklist', 'season': 5, 'episode': 5, 'ep_name': 'ZZZZ'}
    # action = open_window(('windows.next_episode', 'NextEpisode'), 'next_episode.xml', meta=nextep_meta, function='next_ep')
    # logger(f'action: {action}')
    # location = skin_location()
    # skip_option = {'title': 'The Blacklist', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '300'}

    # open_window(('windows.next_episode', 'NextEpisode'), 'next_episode.xml', meta=nextep_meta, function='next_ep')
    # if get_setting('skip.dialog') == "Regular":
        # buttonskip = open_window(('windows.skip', 'Skip'), 'skip_dialog.xml', skip_option=skip_option)
        # # buttonskip = Skip("skip_dialog.xml", location, "default", "1080i", skip_option=self.skip_option)
    # else:
        # buttonskip = open_window(('windows.skip', 'Skip'), 'skip.xml', skip_option=skip_option)
    # # buttonskip = open_window(('windows.skip', 'UpdateSkip'), 'skipupdate.xml', skip_option=skip_option)
    # logger(f'buttonskip: {buttonskip}')
    close_dialog = False
    start_time = time.time()
    end_time = start_time + 60

    meta = {'mediatype': 'episode', 'year': 2022, 'plot': 'Monday   Friday\nCrime Patrol is an Indian Hindi crime anthology series created by Subramanian S.lyer for Sony Entertainment Television India and Sony Entertainment Television Asia. The Series Currently airing its fifth season.', 'title': 'Crime Patrol', 'studio': 'Sony', 'poster': 'https://www.desi-serials.cc/wp-content/uploads/2020/08/Crime-Patrol-300x169.jpg', 'homepage': 'https://www.desi-serials.cc/watch-online/sony-tv/crime-patrol-season-4-updateslatest/', 'genre': 'Monday   Friday, Crime, Drama, Mystery, Reality-TV', 'cast': [], 'tmdb_id': 'Sony|Crime Patrol', 'imdb_id': 'tt1921518', 'rating': 7.9, 'clearlogo': '', 'trailer': '', 'votes': 50, 'tagline': '', 'director': '', 'writer': '', 'episodes': 764, 'seasons': '1, 2, 3, 4, 23', 'extra_info': {'status': '', 'collection_id': ''}, 'tvdb_id': 'Sony|crime patrol', 'duration': 2520, 'mpaa': 'TV-MA', 'episode': 428, 'tvshowtitle': 'Crime Patrol', 'playcount': 0, 'original_title': 'Crime Patrol', 'total_seasons': 1, 'url': 'https://www.desi-serials.cc/crime-patrol-episode-28th-april-2022-watch-online/424912/', 'fanart': 'https://www.desi-serials.cc/wp-content/uploads/2020/08/Crime-Patrol-300x169.jpg', 'premiered': 2003, 'season': 1, 'ep_name': '28th April 2022', 'media_type': 'episode', 'background': False, 'skip_option': {'title': 'Crime Patrol', 'service': 'True', 'skip': '15', 'start': '10', 'eskip': '300'}}
    progress_dialog = create_window(('windows.yes_no_progress_media', 'YesNoProgressMedia'), 'yes_no_progress_media.xml', meta=meta)
    logger(f'progress_dialog: {progress_dialog}')
    
    progress_dialog.run()

    for i in range(0, 100, 5):
        current_time = time.time()
        current_progress = max((current_time - start_time), 0)
        percent = (current_progress/float(30))*100
        logger(f'progress_dialog percent: {percent}')
        progress_dialog.update('%s[CR]%s[CR]%s' % ('line1', 'line2', 'line3'), percent)
        if percent >= 100: close_dialog = True; break
    if close_dialog:
        try: progress_dialog.close()
        except: pass


def cache_test():
    ctime = datetime.datetime.now()
    current_time = int(time.mktime(ctime.timetuple()))
    clean_databases(current_time, database_check=False, silent=True)
    from modules.source_utils import sources
    providers = sources('true', 'episode')
    from indexers.hindi.lists import youtube_m3u
    youtube_m3u()
    from caches.h_cache import MainCache
    MainCache().clean_hindi_lists()
    logger(providers)
    from caches import clrCache_version_update
    clrCache_version_update(clr_cache=True, clr_navigator=False)
    from apis.trakt_api import trakt_sync_activities
    status = trakt_sync_activities()
    logger(f'status: {status}')


def dl_db_file():
    params = {
    'mode': 'downloader',
    'action': 'cloud_file',
    'name': 'metacache_test',
    'url': 'https://github.com/djp11r/repojp/blob/master/etc/allxml/metacache.db?raw=true',
    'media_type': 'file'}
    from modules.downloader import runner
    runner(params)