# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcvfs
from xbmcaddon import Addon
import sqlite3 as database
from urllib.parse import urlencode
import traceback
import inputstreamhelper

__addon__ = Addon(id='plugin.video.infinite')
addon_version = __addon__.getAddonInfo('version')
monitor, window, dialog, progressDialog, progressDialogBG = xbmc.Monitor(), xbmcgui.Window(10000), xbmcgui.Dialog(), xbmcgui.DialogProgress(), xbmcgui.DialogProgressBG()
player, xbmc_player, numeric_input, xbmc_monitor = xbmc.Player(), xbmc.Player, xbmcgui.INPUT_NUMERIC, xbmc.Monitor
get_infolabel, get_visibility, execute_JSON, window_xml_dialog = xbmc.getInfoLabel, xbmc.getCondVisibility, xbmc.executeJSONRPC, xbmcgui.WindowXMLDialog
window_xml_info_action = 11 # ACTION_SHOW_INFO
window_xml_closing_actions = (9, 10, 13, 92) # (ACTION_PARENT_DIR=9, ACTION_PREVIOUS_MENU=10, ACTION_STOP=13, ACTION_NAV_BACK=92)
window_xml_selection_actions = (7, 100)# (ACTION_SELECT_ITEM=7, ACTION_MOUSE_START=100)
window_xml_context_actions = (117, 101, 108) # (ACTION_CONTEXT_MENU=117, ACTION_MOUSE_RIGHT_CLICK=101, ACTION_MOUSE_LONG_CLICK=108)
window_xml_left_action = 1 # ACTION_MOVE_LEFT
window_xml_right_action = 2 # ACTION_MOVE_RIGHT
window_xml_up_action = 3 # ACTION_MOVE_UP
window_xml_down_action = 4 # ACTION_MOVE_DOWN
translatePath = xbmcvfs.translatePath
icon_directory = 'special://home/addons/plugin.video.infinite/resources/media/%s'
fanart = translatePath('special://home/addons/plugin.video.infinite/fanart.png')
icon = translatePath('special://home/addons/plugin.video.infinite/icon.png')
db_directory = 'special://profile/addon_data/plugin.video.infinite/databases/%s'
databases_path = translatePath('special://profile/addon_data/plugin.video.infinite/databases/')
hindi_db = translatePath(db_directory % 'hindi_maincache.db')
hindi_meta_db = translatePath(db_directory % 'hindi_metacache.db')
navigator_db = translatePath(db_directory % 'navigator.db')
watched_db = translatePath(db_directory % 'watched.db')
favorites_db = translatePath(db_directory % 'favourites.db')
views_db = translatePath(db_directory % 'views.db')
trakt_db = translatePath(db_directory % 'traktcache4.db')
maincache_db = translatePath(db_directory % 'maincache.db')
metacache_db = translatePath(db_directory % 'metacache.db')
debridcache_db = translatePath(db_directory % 'debridcache.db')
external_db = translatePath(db_directory % 'providerscache2.db')
current_dbs = ('debridcache.db', 'favourites.db', 'maincache.db', 'metacache.db', 'navigator.db', 'providerscache2.db', 'traktcache4.db', 'views.db', 'watched.db', 'hindi_maincache.db', 'hindi_metacache.db', 'skipintro.json')
myvideos_db_paths = {18: '116', 19: '119', 20: '119'}


def logger(function):
	xbmc.log('###Infinite###: %s' % (function), 1)
	#import xbmc
	# from datetime import datetime
	# from modules.kodi_utils import translate_path
	# notice = 1 if py_tools.isPY3 else 2
	# import os
	# log_file = os.path.join(translate_path('special://logpath/'), 'infinite.log')
	# with open(log_file, 'a', encoding='utf-8') as f:
		# # with open_file(log_file, 'a') as f:
		# # line = '###%s###:\n %s' % (heading, function)
		# line = "[%s %s] %s\n %s" % (datetime.now().date(), str(datetime.now().time())[:8], heading, function)
		# f.write(line.rstrip('\r\n')+'\n')


def get_property(prop):
	return window.getProperty(prop)

def set_property(prop, value):
	return window.setProperty(prop, value)

def clear_property(prop):
	return window.clearProperty(prop)

def addon(addon_id='plugin.video.infinite'):
	return Addon(id=addon_id)

def addon_installed(addon_id):
	return get_visibility('System.HasAddon(%s)' % addon_id)

def add_item(handle, url, listitem, isFolder):
	xbmcplugin.addDirectoryItem(handle, url, listitem, isFolder)

def add_items(handle, item_list):
	xbmcplugin.addDirectoryItems(handle, item_list)

def set_content(handle, content):
	xbmcplugin.setContent(handle, content)

def set_category(handle, category):
	xbmcplugin.setPluginCategory(handle, category)

def set_sort_method(handle, method):
	if method == 'episodes': sort_method = xbmcplugin.SORT_METHOD_EPISODE
	elif method == 'files': sort_method = xbmcplugin.SORT_METHOD_FILE
	else: sort_method = xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE#label
	xbmcplugin.addSortMethod(handle, sort_method)

def end_directory(handle, cacheToDisc=None):
	if cacheToDisc == None: cacheToDisc = get_property('infinite_kodi_menu_cache') == 'true'
	xbmcplugin.endOfDirectory(handle, cacheToDisc=cacheToDisc)

def set_resolvedurl(handle, item):
	xbmcplugin.setResolvedUrl(handle, True, item)

def make_playlist(_type='video'):
	return xbmc.PlayList(xbmc.PLAYLIST_VIDEO) if _type == 'video' else xbmc.PlayList(xbmc.PLAYLIST_MUSIC)

def convert_language(lang):
	return xbmc.convertLanguage(lang, xbmc.ISO_639_2)

def supported_media():
	return xbmc.getSupportedMedia('video')

def path_exists(path):
	return xbmcvfs.exists(path)

def make_directory(path):
	xbmcvfs.mkdir(path)

def make_directorys(path):
	xbmcvfs.mkdirs(path)

def open_file(_file, mode='r'):
	return xbmcvfs.File(_file, mode)

def copy_file(source, destination):
	return xbmcvfs.copy(source, destination)

def delete_file(_file):
	try: xbmcvfs.delete(_file)
	except Exception as e:
		logger(f'1 delete_file error: {repr(e)}')
		from os import unlink, remove
		try:
			unlink(_file)
			remove(_file)
		except Exception as e: logger(f'2 delete_file error: {repr(e)}')

def rename_file(old, new):
	xbmcvfs.rename(old, new)

def list_dirs(location):
	return xbmcvfs.listdir(location)

def make_listitem():
	return xbmcgui.ListItem(offscreen=True)

def local_string(string):
	try: string = int(string)
	except: return string
	try: string = str(__addon__.getLocalizedString(string))
	except: string = __addon__.getLocalizedString(string)
	return string

def translate_path(path):
	return translatePath(path)

def sleep(time):
	return xbmc.sleep(time)

def execute_builtin(command):
	return xbmc.executebuiltin(command)

def get_kodi_version():
	return int(get_infolabel('System.BuildVersion')[0:2])

def current_skin():
	return xbmc.getSkinDir()

def current_window_id():
	return xbmcgui.Window(xbmcgui.getCurrentWindowId())

def get_video_database_path():
	return translate_path('special://profile/Database/MyVideos%s.db' % myvideos_db_paths[get_kodi_version()])

def show_busy_dialog():
	return execute_builtin('ActivateWindow(busydialognocancel)')

def hide_busy_dialog():
	execute_builtin('Dialog.Close(busydialognocancel)')
	execute_builtin('Dialog.Close(busydialog)')

def close_all_dialog():
	execute_builtin('Dialog.Close(all,true)')

def container_content():
	return get_infolabel('Container.Content')

def external_browse():
	return 'infinite' not in get_infolabel('Container.PluginName')

def widget_refresh():
	return execute_builtin('UpdateLibrary(video,special://skin/foo)')

def container_refresh():
	return execute_builtin('Container.Refresh')

def ok_dialog(heading='Infinite', text='', highlight='royalblue', ok_label=local_string(32839), top_space=False):
	from windows import open_window
	if isinstance(heading, int): heading = local_string(heading)
	if isinstance(text, int): text = local_string(text)
	if not text: text = '[CR][CR]%s' % local_string(32760)
	elif top_space: text = '[CR][CR]%s' % text
	kwargs = {'heading': heading, 'text': text, 'highlight': highlight, 'ok_label': ok_label}
	return open_window(('windows.select_ok', 'OK'), 'ok.xml', **kwargs)

def confirm_dialog(heading='Infinite', text='', highlight='royalblue', ok_label=local_string(32839), cancel_label=local_string(32840), top_space=False, default_control=11):
	from windows import open_window
	if isinstance(heading, int): heading = local_string(heading)
	if isinstance(text, int): text = local_string(text)
	if isinstance(ok_label, int): ok_label = local_string(ok_label)
	if isinstance(cancel_label, int): cancel_label = local_string(cancel_label)
	if not text: text = '[CR][CR]%s' % local_string(32580)
	elif top_space: text = '[CR][CR]%s' % text
	kwargs = {'heading': heading, 'text': text, 'highlight': highlight, 'ok_label': ok_label, 'cancel_label': cancel_label, 'default_control': default_control}
	return open_window(('windows.select_ok', 'YesNo'), 'yesno.xml', **kwargs)

def select_dialog(function_list, **kwargs):
	from windows import open_window
	selection = open_window(('windows.select_ok', 'Select'), 'select.xml', **kwargs)
	if selection in ([], None): return None
	if kwargs.get('multi_choice', 'false') == 'true': return [function_list[i] for i in selection]
	return function_list[selection]

def show_text(heading, text=None, file=None, font_size='small', kodi_log=False):
	from windows import open_window
	if isinstance(heading, int): heading = local_string(heading)
	heading = heading.replace('[B]', '').replace('[/B]', '')
	if file:
		with open(file, encoding='utf-8') as r: text = r.read()
	if kodi_log and confirm_dialog(heading='Infinite', text=local_string(32855), ok_label=local_string(32824), cancel_label=local_string(32828), top_space=True):
		import re
		# with open(file, encoding='utf-8') as r: text = r.readlines()
		# texts1 = [i for i in text if any(x in i.lower() for x in ('exception', 'error'))]
		try: 
			texts1 = re.compile("error(.*?)[\t ]*\r?\n[\t ]*", flags=re.DOTALL | re.IGNORECASE).findall(str(text))
			# logger(f'texts1: {type(texts1)} {texts1}')
			texts2 = re.compile("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--", flags=re.DOTALL | re.IGNORECASE).findall(str(text))
			# logger(f'texts2: {type(texts2)} {texts2}')
			text = texts1 + texts2
			# logger(f'texts2:{type(text)} {text}')
			with open(file, 'w', encoding='utf-8') as r: r.writelines(''.join(text))
		except: logger(f'error: {traceback.format_exc()}')
	text = ''.join(text)
	return open_window(('windows.textviewer', 'TextViewer'), 'textviewer.xml', heading=heading, text=text, font_size=font_size)

def notification(line1, time=5000, icon=icon, sound=False):
	if isinstance(line1, int): line1 = local_string(line1)
	# icon = icon or translate_path('special://home/addons/plugin.video.infinite/icon.png')
	if 'error' in line1.lower():
		import inspect
		func = inspect.currentframe().f_back
		funcat = 'not found'
		if 'plugin.video.infinite' in func.f_code.co_filename:
			funcat = func.f_code.co_filename.split('plugin.video.infinite')[1]
		logger("line_number: %s func name: %s func file: %s" % (func.f_lineno, func.f_code.co_name, funcat))
	xbmcgui.Dialog().notification('Infinite', line1, icon, time, sound)

def choose_view(view_type, content):
	from sys import argv
	__handle__ = int(argv[1])
	set_view_str = local_string(32547)
	settings_icon = translate_path(icon_directory % 'settings.png')
	listitem = make_listitem()
	listitem.setLabel(set_view_str)
	params_url = build_url({'mode': 'set_view', 'view_type': view_type})
	listitem.setArt({'icon': settings_icon, 'poster': settings_icon, 'thumb': settings_icon, 'fanart': fanart, 'banner': settings_icon})
	add_item(__handle__, params_url, listitem, False)
	set_content(__handle__, content)
	end_directory(__handle__)
	set_view_mode(view_type, content)

def set_view(view_type):
	view_id = str(current_window_id().getFocusId())
	dbcon = database.connect(views_db, timeout=40.0, isolation_level=None)
	dbcur = dbcon.cursor()
	dbcur.execute('''PRAGMA synchronous = OFF''')
	dbcur.execute('''PRAGMA journal_mode = OFF''')
	dbcur.execute("INSERT OR REPLACE INTO views VALUES (?, ?)", (view_type, view_id))
	set_view_property(view_type, view_id)
	notification(get_infolabel('Container.Viewmode').upper(), time=1500)

def set_view_property(view_type, view_id):
	set_property('infinite_%s' % view_type, view_id)

def set_view_properties():
	dbcon = database.connect(views_db, timeout=40.0, isolation_level=None)
	dbcur = dbcon.cursor()
	dbcur.execute('''PRAGMA synchronous = OFF''')
	dbcur.execute('''PRAGMA journal_mode = OFF''')
	dbcur.execute("SELECT * FROM views")
	view_ids = dbcur.fetchall()
	for item in view_ids: set_property('infinite_%s' % item[0], item[1])

def set_view_mode(view_type, content='files'):
	if external_browse(): return
	view_id = get_property('infinite_%s' % view_type)
	# logger('set_view_mode paview_typerams: {} view_id: {}'.format(view_type, view_id))
	hold = 0
	if not view_id:
		try:
			dbcon = database.connect(views_db, timeout=40.0, isolation_level=None)
			dbcur = dbcon.cursor()
			dbcur.execute("SELECT view_id FROM views WHERE view_type = ?", (str(view_type),))
			view_id = dbcur.fetchone()[0]
		except: return
	try:
		sleep(100)
		while not container_content() == content:
			hold += 1
			if hold < 5000: sleep(1)
			else: return
		if view_id: execute_builtin('Container.SetViewMode(%s)' % view_id)
	except: return

def timeIt(func):
	# Thanks to 123Venom
	import time
	fnc_name = func.__name__
	def wrap(*args, **kwargs):
		started_at = time.time()
		result = func(*args, **kwargs)
		logger('%s.%s' % (__name__ , fnc_name), (time.time() - started_at))
		return result
	return wrap

def build_url(url_params):
	return ''.join(['plugin://plugin.video.infinite/?', urlencode(url_params)])

def add_dir(url_params, list_name, __handle__, iconImage='DefaultFolder.png', fanart=fanart, isFolder=True):
	icon = translate_path(icon_directory % iconImage)
	url = build_url(url_params)
	listitem = make_listitem()
	listitem.setLabel(list_name)
	listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': fanart, 'banner': icon})
	add_item(__handle__, url, listitem, isFolder)

# def remove_meta_keys(dict_item, dict_removals=''):
	# from modules.utils import make_dicts_value_tuple
	# dict_removals += ('homepage', 'query', 'ch_name', 'pg_no', 'url', 'ch_no', 'vid_url', 'action', 'group_title', 'tvg_id')
	# for k in dict_removals: dict_item.pop(k, None)
	# return make_dicts_value_tuple(dict_item)

def volume_checker(volume_setting):
	# 0% == -60db, 100% == 0db
	try:
		if get_visibility('Player.Muted'): return
		from modules.utils import string_alphanum_to_num
		max_volume = int(min(int(volume_setting), 100))
		current_volume_db = int(string_alphanum_to_num(get_infolabel('Player.Volume').split('.')[0]))
		current_volume_percent = int(100 - ((float(current_volume_db)/60)*100))
		if current_volume_percent > max_volume: execute_builtin('SetVolume(%d)' % int(max_volume))
	except: pass

def focus_index(index, sleep_time=100):
	sleep(sleep_time)
	current_window = current_window_id()
	focus_id = current_window.getFocusId()
	try: current_window.getControl(focus_id).selectItem(index)
	except: logger("focus_index Error: {}".format(traceback.format_exc()))

def clear_settings_window_properties():
	clear_property('infinite_settings')
	notification(32576, 2500)

def fetch_kodi_imagecache(image):
	result = None
	try:
		dbcon = database.connect(translate_path('special://database/Textures13.db'), timeout=40.0)
		dbcur = dbcon.cursor()
		dbcur.execute("SELECT cachedurl FROM texture WHERE url = ?", (image,))
		result = dbcur.fetchone()[0]
	except: pass
	return result

def get_skip_database_file():
	# database_file = translate_path('special://home/addons/plugin.video.infinite/resources/lib/indexers/hindi/list_data/skipintro.json')
	database_file = translatePath(db_directory % 'skipintro.json')
	# if not path_exists(database_file):
		# import json
		# data = []
		# with open(database_file, mode='w', encoding='utf-8') as f:
			# json.dump(data, f)#, indent=2)
	return database_file

def decorate_log_error(log_lines):
	import re
	text = ''
	for line in log_lines:
		if not any(re.findall(r'INFO|NOTICE', line)):
			line = line.replace('ERROR', '[COLOR red]ERROR[/COLOR]:').replace('WARNING', '[COLOR gold]WARNING[/COLOR]:')
		text += line
	return text


def metadataClean(metadata):
	if not metadata: return metadata
	allowed = ('genre', 'country', 'year', 'episode', 'season', 'sortepisode', 'sortseason', 'episodeguide', 'showlink',
					'top250', 'setid', 'tracknumber', 'rating', 'userrating', 'watched', 'playcount', 'overlay', 'cast', 'castandrole',
					'director', 'mpaa', 'plot', 'plotoutline', 'title', 'originaltitle', 'sorttitle', 'duration', 'studio', 'tagline', 'writer',
					'tvshowtitle', 'premiered', 'status', 'set', 'setoverview', 'tag', 'imdbnumber', 'code', 'aired', 'credits', 'lastplayed',
					'album', 'artist', 'votes', 'path', 'trailer', 'dateadded', 'mediatype', 'dbid')
	return {k: v for k, v in metadata.items() if k in allowed}

def set_info(item, meta, setUniqueIDs, resumetime=0):
	if get_kodi_version() == 19:
		item.setUniqueIDs(setUniqueIDs)
		item.setCast(meta.get('cast', []) + meta.get('guest_stars', []))
		meta = metadataClean(meta)
		try: meta.pop('cast')
		except: pass
		item.setInfo('Video', meta)
		item.setProperty('resumetime', str(resumetime))
	else:
		# logger(f'meta : {meta}')
		meta_get = meta.get
		videoInfoTag = item.getVideoInfoTag()

		videoInfoTag.setMediaType(meta_get('mediatype'))
		videoInfoTag.setUniqueIDs(setUniqueIDs)
		videoInfoTag.setPath(meta_get('path'))
		videoInfoTag.setFilenameAndPath(meta_get('filenameandpath'))
		videoInfoTag.setTitle(item.getLabel() or meta_get('title'))
		videoInfoTag.setSortTitle(meta_get('sorttitle'))
		videoInfoTag.setOriginalTitle(meta_get('originaltitle'))
		videoInfoTag.setPlot(meta_get('plot'))
		videoInfoTag.setPlotOutline(meta_get('plotoutline'))
		videoInfoTag.setDateAdded(meta_get('dateadded'))
		videoInfoTag.setPremiered(meta_get('premiered'))
		videoInfoTag.setYear(int(meta_get('year', 0)))
		rating = meta_get('rating')
		if not rating: rating = 0.0
		videoInfoTag.setRating(float(rating))
		videoInfoTag.setMpaa(meta_get('mpaa'))
		videoInfoTag.setDuration(meta_get('duration', 0))
		videoInfoTag.setPlaycount(int(meta_get('playcount', 0)))
		videoInfoTag.setVotes(int(meta_get('votes', 0)))
		videoInfoTag.setLastPlayed(meta_get('lastplayed'))
		videoInfoTag.setAlbum(meta_get('album'))
		videoInfoTag.setGenres(meta_get('genre', []))
		videoInfoTag.setCountries(meta_get('country', []))
		videoInfoTag.setTags(meta_get('tag', []))
		videoInfoTag.setTrailer(meta_get('trailer'))
		videoInfoTag.setTagLine(meta_get('tagline'))
		videoInfoTag.setStudios(meta_get('studio', []))
		videoInfoTag.setWriters(meta_get('writer', []))
		videoInfoTag.setDirectors(meta_get('director', []))
		videoInfoTag.setIMDBNumber(meta_get('imdb_id'))
		videoInfoTag.setResumePoint(float(resumetime), meta_get('duration', 0))
		if meta_get('mediatype') in ['tvshow', 'season']:
			videoInfoTag.setTvShowTitle(meta_get('tvshowtitle'))
			videoInfoTag.setTvShowStatus(meta_get('status'))
		if meta_get('mediatype') in ['episodes', 'episode']:
			videoInfoTag.setTvShowTitle(meta_get('tvshowtitle'))
			videoInfoTag.setEpisode(meta_get('episode'))
			videoInfoTag.setSeason(meta_get('season'))
		cast_list = cast_tuple(meta_get('cast', []) + meta_get('guest_stars', []))
		videoInfoTag.setCast(cast_list)
	return item

def set_inputstream(url, listitem):
	if 'm3u8' in url.lower() and inputstreamhelper.Helper('hls').check_inputstream():
		inputstream = 'inputstream.adaptive'
		listitem.setProperty('inputstream', inputstream)
		listitem.setProperty('%s.manifest_type'%(inputstream), 'hls')
		listitem.setProperty('http-reconnect', 'true')
		listitem.setMimeType('application/vnd.apple.mpegurl')
	return listitem

def cast_tuple(cast_list):
	cast = []
	for actor in cast_list:
		if isinstance(actor, dict):
			thumbnail = ''
			if 'thumbnail' in actor:
				thumbnail = actor.get('thumbnail', '')
			cast.append(xbmc.Actor(actor.get('name', ''), actor.get('role', ''), actor.get('order', 0), thumbnail))
		if isinstance(actor, list):
			cast.append(xbmc.Actor(actor, '', 0, ''))
	# logger(f'cast : {type(cast)}  {cast}')
	return cast

def list_to_string(_list):
	if isinstance(_list, list):
		_list = ', '.join([i for i in _list])
	return _list

def print_out_infoteg(listitem):
	videoInfoTag = listitem.getVideoInfoTag()
	logger(f'getMediaType       : {videoInfoTag.getMediaType()}')
	logger(f'getPath            : {videoInfoTag.getPath()}')
	logger(f'getFilenameAndPath : {videoInfoTag.getFilenameAndPath()}')
	logger(f'getTitle           : {videoInfoTag.getTitle()}')
	logger(f'getOriginalTitle   : {videoInfoTag.getOriginalTitle()}')
	logger(f'getPlot            : {videoInfoTag.getPlot()}')
	logger(f'getPlotOutline     : {videoInfoTag.getPlotOutline()}')
	logger(f'getYear            : {videoInfoTag.getYear()}')
	logger(f'getRating          : {videoInfoTag.getRating()}')
	logger(f'getDuration        : {videoInfoTag.getDuration()}')
	logger(f'getAlbum           : {videoInfoTag.getAlbum()}')
	logger(f'getTagLine         : {videoInfoTag.getTagLine()}')
	logger(f'getEpisode         : {videoInfoTag.getEpisode()}')
	logger(f'getSeason          : {videoInfoTag.getSeason()}')
	logger(f'getCast            : {videoInfoTag.getCast()}')
	try:
		logger(f'getPremieredAsW3C  : {videoInfoTag.getPremieredAsW3C()}')
		logger(f'getLastPlayedAsW3C : {videoInfoTag.getLastPlayedAsW3C()}')
		logger(f'getVotesAsInt      : {videoInfoTag.getVotesAsInt()}')
		logger(f'getGenres          : {videoInfoTag.getGenres()}')
		logger(f'getWriters         : {videoInfoTag.getWriters()}')
		logger(f'getDirectors       : {videoInfoTag.getDirectors()}')
		logger(f'getUniqueIDs       : {videoInfoTag.getUniqueIDs()}')
		logger(f'getSortTitle       : {videoInfoTag.getSortTitle()}')
		logger(f'getDateAdded       : {videoInfoTag.getDateAdded()}')
		logger(f'getMpaa            : {videoInfoTag.getMpaa()}')
		logger(f'getPlaycount       : {videoInfoTag.getPlaycount()}')
		logger(f'getCountries       : {videoInfoTag.getCountries()}')
		logger(f'getTags            : {videoInfoTag.getTags()}')
		logger(f'getStudios         : {videoInfoTag.getStudios()}')
		logger(f'getResumePoint     : {videoInfoTag.getResumePoint()}')
		logger(f'getTvShowTitle     : {videoInfoTag.getTvShowTitle()}')
		logger(f'getTvShowStatus    : {videoInfoTag.getTvShowStatus()}')
	except: pass
