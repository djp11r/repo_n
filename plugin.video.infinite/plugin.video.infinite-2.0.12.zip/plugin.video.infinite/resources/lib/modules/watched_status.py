# -*- coding: utf-8 -*-
import json
from datetime import datetime
from traceback import print_exc
from modules.fen_online_utils import single_sync
from caches.base_cache import connect_database, database, get_timestamp
from modules.kodi_utils import kodi_progress_background, sleep, get_video_database_path, notification, kodi_refresh
from modules.utils import get_datetime, adjust_premiered_date, sort_for_article, TaskPool
from modules import metadata, settings, kodi_utils
from modules.kodi_utils import logger

def get_last_played_value():
	return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

def get_database():
	return connect_database('watched_db')

def get_hidden_progress_items():
	try:
		watched_db = get_database()
		watched_info = watched_db.execute('SELECT status FROM watched_status WHERE db_type = ?', ('hidden_progress_items',)).fetchone()[0]
		return json.loads(watched_info) or []
	except: return []

def update_hidden_progress(media_id):
	if not str(media_id).isdigit(): return
	current_hidden = get_hidden_progress_items()
	new_hidden = [i for i in current_hidden if i != int(media_id)]
	if new_hidden == current_hidden: return
	hide_unhide_progress_items({'action': 'undrop', 'media_type': 'shows', 'media_id': media_id, 'refresh': 'false'})

def hide_unhide_progress_items(params):
	action, media_id, refresh = params['action'], int(params.get('media_id', '0')), params.get('refresh', 'true') == 'true'
	current_items = get_hidden_progress_items() or []
	if action == 'drop': current_items.append(media_id)
	else: current_items.remove(media_id)
	watched_db = get_database()
	watched_info = watched_db.execute('INSERT OR REPLACE INTO watched_status VALUES (?, ?, ?, ?)', ('hidden_progress_items', 'hidden', json.dumps(current_items), get_timestamp()))
	if refresh: kodi_refresh()

def make_batch_insert(action, media_type, media_id, season, episode, title, last_played, timestamp):
	if action == 'mark_as_watched': return (media_type, media_id, season, episode, last_played, title, timestamp)
	else: return (media_type, media_id, season, episode)

def refresh_container(refresh=True):
	if refresh: kodi_refresh()

def active_tvshows_information(status_type):
	def _process(item):
		media_id = item['media_id']
		meta = metadata.tvshow_meta('tmdb_id', media_id, api_key, get_datetime())
		watched_status = get_watched_status_tvshow(watched_info[media_id], meta.get('total_aired_eps'))[0]
		if status_type == 'watched':
			if watched_status == 1: results_append(item)
		elif watched_status == 0: results_append(item)
	results = []
	results_append = results.append
	watched_info = watched_info_tvshow()
	if status_type == 'progress':
		hidden_items = get_hidden_progress_items()
		for k in hidden_items: watched_info.pop(str(k), None)
	api_key = settings.tmdb_api_key()
	watched_items = watched_info.items()
	data = [v for k, v in watched_items]
	threads = TaskPool().tasks(_process, data)
	[i.join() for i in threads]
	return results

def watched_info_movie(watched_db=None):
	if not watched_db: watched_db = get_database()
	try:
		watched_info = watched_db.execute('SELECT media_id, title, last_played FROM watched WHERE db_type = ?', ('movie',)).fetchall()
		return dict([(i[0], {'media_id': i[0], 'title': i[1], 'last_played': i[2]}) for i in watched_info])
	except: return {}

def get_bookmarks_movie(watched_db=None):
	if not watched_db: watched_db = get_database()
	try:
		info = watched_db.execute('SELECT media_id, resume_point, curr_time, resume_id FROM progress WHERE db_type = ?', ('movie',)).fetchall()
		info = dict([(i[0], {'media_id': i[0], 'resume_point': i[1], 'curr_time': i[2], 'resume_id': i[3]}) for i in info])
	except: info = {}
	return info

def get_watched_status_movie(watched_info, media_id):
	if not watched_info: return 0
	try:
		watched = 1 if media_id in watched_info else 0
		return watched
	except: return 0

def get_progress_status_movie(progress_info, media_id):
	try: percent = str(round(float(progress_info[media_id]['resume_point'])))
	except: percent = None
	return percent

def watched_info_tvshow(watched_db=None):
	if not watched_db: watched_db = get_database()
	try:
		data = watched_db.execute('SELECT media_id, season, episode, title, MAX(last_played), COUNT(*) AS COUNTER FROM watched WHERE db_type = ? GROUP BY media_id',
								('episode',)).fetchall()
		return dict([(i[0], {'media_id': i[0], 'season': i[1], 'episode': i[2], 'title': i[3], 'last_played': i[4], 'total_played': i[5]}) for i in data])
	except: return {}

def get_watched_status_tvshow(watched_info, aired_eps):
	if not watched_info: return 0, 0, aired_eps
	try:
		watched = min(watched_info['total_played'], aired_eps)
		unwatched = aired_eps - watched
		if watched >= aired_eps: playcount = 1
		else: playcount = 0
		return playcount, watched, unwatched
	except: return 0, 0, aired_eps

def get_progress_status_tvshow(watched, aired_eps):
	try: progress = int((float(watched)/aired_eps)*100) or 1
	except: progress = 1
	return progress

def watched_info_season(media_id, watched_db=None):
	if not watched_db: watched_db = get_database()
	try: watched_info = dict(watched_db.execute('SELECT season, COUNT(*) AS COUNTER FROM watched WHERE db_type = ? AND media_id = ? GROUP BY media_id, season',
							('episode', str(media_id))).fetchall())
	except: watched_info = {}
	return watched_info

def get_watched_status_season(watched_info, aired_eps):
	if not watched_info: return 0, 0, aired_eps
	try:
		watched = min(watched_info, aired_eps)
		unwatched = aired_eps - watched
		if watched >= aired_eps: playcount = 1
		else: playcount = 0
		return playcount, watched, unwatched
	except: return 0, 0, aired_eps

def get_progress_status_season(watched, aired_eps):
	try: progress = int((float(watched)/aired_eps)*100)
	except: progress = 0
	return progress

def watched_info_episode(media_id, watched_db=None):
	if not watched_db: watched_db = get_database()
	try: watched_info = watched_db.execute('SELECT season, episode FROM watched WHERE db_type = ? AND media_id = ?', ('episode', str(media_id))).fetchall()
	except: watched_info = []
	return watched_info

def get_watched_status_episode(watched_info, season_episode):
	if season_episode in watched_info: return 1
	return 0

def get_bookmarks_episode(media_id, season, watched_db=None):
	if not watched_db: watched_db = get_database()
	try:
		info = watched_db.execute('SELECT resume_point, curr_time, resume_id, episode FROM progress WHERE db_type = ? AND media_id = ? AND season = ?',
			('episode', str(media_id), int(season))).fetchall()
		info = dict([(i[3], {'resume_point': i[0], 'curr_time': i[1], 'resume_id': i[2]}) for i in info])
	except: info = {}
	return info

def get_bookmarks_all_episode(media_id, total_seasons, watched_db=None):
	if not watched_db: watched_db = get_database()
	all_seasons_info = {}
	for season in range(1, total_seasons + 1):
		try:
			season_info = get_bookmarks_episode(media_id, season, watched_db)
			all_seasons_info[season] = season_info
		except: pass
	return all_seasons_info

def get_progress_status_episode(progress_info, episode):
	try: percent = str(float(progress_info[episode]['resume_point']))
	except: percent = None
	return percent

def get_progress_status_all_episode(progress_info, season, episode):
	try: percent = str(round(float(progress_info[season][episode]['resume_point'])))
	except: percent = None
	return percent

def get_resume_seconds(progress, duration):
	return float(int(float(progress)/100 * duration))

def clear_local_bookmarks():
	try:
		dbcon = database.connect(get_video_database_path())
		file_ids = dbcon.execute("SELECT idFile FROM files WHERE strFilename LIKE 'plugin.video.infinite%'").fetchall()
		for i in ('bookmark', 'streamdetails', 'files'): dbcon.executemany("DELETE FROM %s WHERE idFile=?" % i, file_ids)
	except: pass

def mark_movie(params):
	# logger(f'mark_movie params: {params}')
	action, media_type = params.get('action'), 'movie'
	refresh, from_playback = params.get('refresh', 'true') == 'true', params.get('from_playback', 'false') == 'true'
	if from_playback: refresh = False
	tmdb_id, title = params.get('tmdb_id'), params.get('title')
	last_played = get_last_played_value()
	watched_status_mark(media_type, tmdb_id, action, title, last_played)
	refresh_container(refresh)

def mark_tvshow(params):
	# logger(f'mark_tvshow params: {params}')
	title, action, tmdb_id = params.get('title', ''), params.get('action'), params.get('tmdb_id')
	progress_backround = kodi_progress_background()
	progress_backround.create('[B]Please Wait..[/B]', '')
	current_date = get_datetime()
	insert_list = []
	insert_append = insert_list.append
	meta = metadata.tvshow_meta('tmdb_id', tmdb_id, settings.tmdb_api_key(), get_datetime())
	season_data = meta['season_data']
	season_data = [i for i in season_data if i['season_number'] > 0]
	total = len(season_data)
	last_played = get_last_played_value()
	for count, item in enumerate(season_data, 1):
		season_number = item['season_number']
		ep_data = metadata.episodes_meta(season_number, meta)
		for ep in ep_data:
			season_number = ep['season']
			ep_number = ep['episode']
			display = '%s - S%.2dE%.2d' % (title, int(season_number), int(ep_number))
			progress_backround.update(int(float(count)/float(total)*100), '[B]Please Wait..[/B]', display)
			episode_date, premiered = adjust_premiered_date(ep['premiered'], settings.date_offset())
			if episode_date and current_date < episode_date: continue
			insert_append(make_batch_insert(action, 'episode', tmdb_id, season_number, ep_number, title, last_played, get_timestamp()))
	batch_watched_status_mark(insert_list, action)
	progress_backround.close()
	refresh_container()

def mark_season(params):
	# logger(f'mark_season params: {params}')
	season = int(params.get('season'))
	if season == 0: return notification('Failed')
	insert_list = []
	insert_append = insert_list.append
	action, title, tmdb_id = params.get('action'), params.get('title'), params.get('tmdb_id')
	heading = '[B]Mark Watched %s[/B]' if action == 'mark_as_watched' else '[B]Mark Unwatched %s[/B]'
	progress_backround = kodi_progress_background()
	progress_backround.create('[B]Please Wait..[/B]', '')
	current_date = get_datetime()
	meta = metadata.tvshow_meta('tmdb_id', tmdb_id, settings.tmdb_api_key(), get_datetime())
	ep_data = metadata.episodes_meta(season, meta)
	last_played = get_last_played_value()
	for count, item in enumerate(ep_data, 1):
		season_number = item['season']
		ep_number = item['episode']
		display = '%s - S%.2dE%.2d' % (title, season_number, ep_number)
		episode_date, premiered = adjust_premiered_date(item['premiered'], settings.date_offset())
		if episode_date and current_date < episode_date: continue
		progress_backround.update(int(float(count) / float(len(ep_data)) * 100), '[B]Please Wait..[/B]', display)
		insert_append(make_batch_insert(action, 'episode', tmdb_id, season_number, ep_number, title, last_played, get_timestamp()))
	batch_watched_status_mark(insert_list, action)
	progress_backround.close()
	refresh_container()

def mark_episode(params):
	# logger(f'mark_episode params: {params}')
	season, episode, title = int(params.get('season')), int(params.get('episode')), params.get('title')
	if season == 0: return notification('Failed')
	action, media_type = params.get('action'), 'episode'
	refresh, from_playback = params.get('refresh', 'true') == 'true', params.get('from_playback', 'false') == 'true'
	if from_playback: refresh = False
	tmdb_id = params.get('tmdb_id')
	last_played = get_last_played_value()
	watched_status_mark(media_type, tmdb_id, action, title, last_played, season, episode)
	refresh_container(refresh)

def get_next_episodes():
	watched_db = get_database()
	data = watched_db.execute('''WITH cte AS (SELECT *, ROW_NUMBER() OVER (PARTITION BY media_id ORDER BY season DESC, episode DESC) rn FROM watched WHERE db_type == ?)
								SELECT media_id, season, episode, title, last_played FROM cte WHERE rn = 1''', ('episode',)).fetchall()
	# logger(f'build_single_episode data: {repr(data)}')
	data = [{'media_ids': {'tmdb': int(i[0])}, 'season': int(i[1]), 'episode': int(i[2]), 'title': i[3], 'last_played': i[4]} for i in data if str(i[0]).isdigit()]
	data.sort(key=lambda x: (x['last_played']), reverse=True)
	return data

def get_next(season, episode, watched_info, season_data):
	if episode == 0: episode = 1
	else:
		try:
			episode_count = next((i['episode_count'] for i in season_data if i['season_number'] == season), None)
			season = season if episode < episode_count else season + 1
			episode = episode + 1 if episode < episode_count else 1
		except: pass
	return season, episode

def get_in_progress_movies(dummy_arg, page_no):
	dbcon = get_database()
	data = dbcon.execute('SELECT media_id, title, last_played FROM progress WHERE db_type = ?', ('movie',)).fetchall()
	data = [{'media_id': i[0], 'title': i[1], 'last_played': i[2]} for i in data if not i[0] == '']
	if settings.lists_sort_order('progress') == 0: data = sort_for_article(data, 'title')
	else: data = sorted(data, key=lambda x: x['last_played'], reverse=True)
	return data

def get_in_progress_tvshows(dummy_arg, page_no):
	# results = cache_watched_tvshow_status(active_tvshows_information, 'progress')
	results = active_tvshows_information('progress')
	# hidden_items = get_hidden_progress_items(watched_indicators())
	# results = [i for i in results if not int(i['media_id']) in hidden_items]
	if settings.lists_sort_order('progress') == 0: results = sort_for_article(results, 'title')
	else: results = sorted(results, key=lambda x: x['last_played'], reverse=True)
	return results

def get_in_progress_episodes():
	dbcon = get_database()
	data = dbcon.execute('SELECT media_id, season, episode, resume_point, last_played, title FROM progress WHERE db_type = ?', ('episode',)).fetchall()
	episode_list = [{'media_ids': {'tmdb': i[0]}, 'season': int(i[1]), 'episode': int(i[2]), 'resume_point': float(i[3]), 'date': i[4], 'title': i[5]} for i in data]
	if settings.lists_sort_order('progress') == 0: episode_list = sort_for_article(episode_list, 'title')
	else: episode_list.sort(key=lambda k: k['date'], reverse=True)
	return episode_list

def get_watched_items(media_type, page_no):
	if media_type == 'tvshow': results = active_tvshows_information('watched')
	else: results = [v for k,v in watched_info_movie().items()]
	if settings.lists_sort_order('watched') == 0: results = sort_for_article(results, 'title')
	else: results = sorted(results, key=lambda x: x['last_played'], reverse=True)
	return results

@single_sync('watched_db', ['watched', 'progress'])
def erase_bookmark(media_type, media_id, season='', episode='', refresh='false'):
	try:
		watched_db = get_database()
		result = watched_db.execute('DELETE FROM progress where db_type = ? and media_id = ? and season = ? and episode = ?', (media_type, media_id, season, episode))
		refresh_container(refresh == 'true')
		return True if result.rowcount > 0 else None
	except: return None

def batch_erase_bookmark(insert_list, action, dbcon=None):
	try:
		changes_made = False
		dbcon = dbcon or get_database()
		modified_list = [(i[0], i[1], i[2], i[3]) for i in insert_list] if action == 'mark_as_watched' else insert_list
		for item in modified_list: result = dbcon.execute('DELETE FROM progress where db_type = ? and media_id = ? and season = ? and episode = ?', item)
		return True
	except: return None

@single_sync('watched_db', ['watched', 'progress'])
def set_bookmark(params):
	try:
		media_type, tmdb_id, curr_time, total_time = params.get('media_type'), params.get('tmdb_id') or params.get('media_id'), params.get('curr_time'), params.get('total_time')
		resume_point, title, season, episode = params.get('resume_point'), params.get('title'), params.get('season'), params.get('episode')
		refresh = False if params.get('from_playback', 'false') == 'true' else True
		if not resume_point:
			adjusted_current_time = float(curr_time) - 5
			resume_point = round(adjusted_current_time/float(total_time)*100,1)
		last_played = get_last_played_value()
		last_updated = get_timestamp()
		dbcon = get_database()
		dbcon.execute('INSERT OR REPLACE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
					(media_type, tmdb_id, season, episode, str(resume_point), str(curr_time), last_played, 0, title, last_updated))
		refresh_container(refresh)
		return True
	except: return None

@single_sync('watched_db', ['watched', 'progress'])
def watched_status_mark(media_type, media_id, action, title, last_played, season='', episode=''):
	try:
		last_played = last_played or get_last_played_value()
		last_updated = get_timestamp()
		dbcon = get_database()
		if action == 'mark_as_watched':
			dbcon.execute('INSERT OR REPLACE INTO watched VALUES (?, ?, ?, ?, ?, ?, ?)', (media_type, media_id, season, episode, last_played, title, last_updated))
		elif action == 'mark_as_unwatched':
			dbcon.execute('DELETE FROM watched WHERE (db_type = ? and media_id = ? and season = ? and episode = ?)', (media_type, media_id, season, episode))
		dbcon.execute('DELETE FROM progress where db_type = ? and media_id = ? and season = ? and episode = ?', (media_type, media_id, season, episode))
		return True
	except: notification('Error')
	return None

@single_sync('watched_db', ['watched', 'progress'])
def batch_watched_status_mark(insert_list, action):
	try:
		dbcon = get_database()
		initial_changes = dbcon.total_changes
		if action == 'mark_as_watched':
			dbcon.executemany('INSERT OR IGNORE INTO watched VALUES (?, ?, ?, ?, ?, ?, ?)', insert_list)
		elif action == 'mark_as_unwatched':
			dbcon.executemany('DELETE FROM watched WHERE (db_type = ? and media_id = ? and season = ? and episode = ?)', insert_list)
		success = dbcon.total_changes > initial_changes
		batch_erase_bookmark(insert_list, action, dbcon)
		return True if success else None
	except: notification('Error')
	return None


def unmark_previous_episode(params):
	try:
		season, episode = int(params.get('season')), int(params.get('episode'))
		if episode == 1:
			season = params['season'] = season - 1
			meta = metadata.tvshow_meta('tmdb_id', params.get('tmdb_id'), kodi_utils.tmdb_api_key(), get_datetime())
			params['episode'] = episode = next((i for i in meta['season_data'] if i['season_number'] == season))['episode_count']
		else: episode = params['episode'] = episode - 1
		return mark_episode(params)
	except: notification('Error')

def get_recently_watched(media_type, short_list=0):
	w_indi = settings.watched_indicators()
	if media_type == 'movie':
		watched_movies = watched_info_movie().items()
		data = sorted([v for k,v in watched_movies], key=lambda x: x['last_played'], reverse=True)
		if short_list: data = data[:20]
	elif media_type == 'tvshow':
		watched_tvshows = watched_info_tvshow().items()
		data = sorted([v for k,v in watched_tvshows], key=lambda x: x['last_played'], reverse=True)
		if short_list: data = data[:20]
	else:
		dbcon = get_database(w_indi)
		data = dbcon.execute('SELECT media_id, season, episode, title, last_played FROM watched WHERE db_type = ? ORDER BY last_played DESC', ('episode',)).fetchall()
		data = [{'media_ids': {'tmdb': int(i[0])}, 'season': int(i[1]), 'episode': int(i[2]), 'title': i[3], 'last_played': i[4]}
					for i in data]
		if short_list: data = data[:20]
	return data





def ishindi(tvdb_id):
	try:
		return '|' in str(tvdb_id)
	except: return False

def get_media_info(media_type, media_id=None, season=None, watched_indicators_dict=True):
	watched_db = get_database()
	try:
		if media_id: watched_info = watched_db.execute('SELECT season, episode FROM watched WHERE db_type = ? AND media_id = ?', (media_type, str(media_id))).fetchall()
		else:
			if watched_indicators_dict:
				watched_info = watched_db.execute('SELECT media_id, title, last_played, season, episode FROM watched WHERE db_type = ?', (media_type,)).fetchall()
				watched_info = dict([(i[0], {'media_id':i[0], 'title': i[1], 'last_played': i[2]}) for i in watched_info])
			else: watched_info = watched_db.execute('SELECT media_id, season, episode FROM watched WHERE db_type = ?', (media_type,)).fetchall()
	except: watched_info = []
	try:
		if media_type == 'movie':
			bookmarks = watched_db.execute('SELECT media_id, resume_point, curr_time, resume_id FROM progress WHERE db_type = ?', ('movie',)).fetchall()
			if watched_indicators_dict: bookmarks = dict([(i[0], {'media_id': i[0], 'resume_point': i[1], 'curr_time': i[2], 'resume_id': i[3]}) for i in bookmarks])
		else:
			if media_id: bookmarks = watched_db.execute('SELECT resume_point, curr_time, season, episode, resume_id FROM progress WHERE db_type = ? AND media_id = ?', (media_type, str(media_id))).fetchall()
			elif season: bookmarks = watched_db.execute('SELECT resume_point, curr_time, resume_id, episode FROM progress WHERE db_type = ? AND media_id = ? AND season = ?', ('episode', str(media_id), season)).fetchall()
			else: bookmarks = watched_db.execute('SELECT media_id, resume_point, curr_time, season, episode, resume_id FROM progress WHERE db_type = ?', (media_type,)).fetchall()
			# logger(f'from media_id: {media_id} season: {season} watched_indicators_dict: {watched_indicators_dict} bookmarks : {bookmarks}')
			if watched_indicators_dict:
				try: bookmarks = dict([(i[3], {'resume_point': i[0], 'curr_time': i[1], 'resume_id': i[2]}) for i in bookmarks])
				except: bookmarks = {}
	except: bookmarks = []
	return watched_info, bookmarks

def detect_bookmark(bookmarks, tmdb_id, season='', episode=''):
	if season == '': return [(i[1], i[2], i[3]) for i in bookmarks if i[0] == str(tmdb_id)][0]
	else: return [(i[1], i[2], i[5]) for i in bookmarks if i[0] == str(tmdb_id) and i[3] == season and i[4] == episode][0]

def get_progress_percent(bookmarks, tmdb_id, season='', episode=''):
	try: percent = str(float(detect_bookmark(bookmarks, tmdb_id, season, episode)[0]))
	except: percent = None
	return percent

def get_watched_status(watched_info, tmdb_id, season, episode):
	try:
		if season == '':
			if watched := [i for i in watched_info if i[0] == tmdb_id]: return 1
		else:
			if watched := [i for i in watched_info if i == (tmdb_id, season, episode)]:
				# logger(f'from watched_info : {watched_info} (tmdb_id, season, episode): {(tmdb_id, season, episode)}')
				return 1
		return 0
	except: return 0

def mark_as_watched_unwatched_extra(params):
	# logger(f'params: {params}')
	tmdb_id, action, media_type = params.get('tmdb_id'), params.get('action'), params.get('media_type')
	season, episode, title = params.get('season'), params.get('episode'), params.get('title')
	watched_status_mark(media_type, tmdb_id, action, title, None, season, episode)
	refresh_container()