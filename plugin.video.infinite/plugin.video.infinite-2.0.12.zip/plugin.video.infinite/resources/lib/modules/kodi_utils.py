# -*- coding: utf-8 -*-
import os, re
import xbmc, xbmcgui, xbmcplugin, xbmcvfs, xbmcaddon
from urllib.parse import urlencode, unquote
from modules import icons
from traceback import print_exc, format_stack

opensettings_params = {'mode': 'open_settings', 'query': '0.0'}
img_url = 'https://i.imgur.com/%s.png'
invoker_switch_dict = {'true': 'false', 'false': 'true'}
empty_poster, nextpage = img_url % icons.box_office, img_url % icons.nextpage
nextpage_landscape = img_url % icons.nextpage_landscape
item_jump_landscape = img_url % icons.item_jump_landscape
# sort_method_dict = {'episodes': 24, 'files': 5, 'label': 2, 'none': 0}
playlist_type_dict = {'music': 0, 'video': 1}
scraper_names = ['EXTERNAL SCRAPERS' 'FOLDERS 1-5']


def addon_themes():
	return [{'name': 'Light', 'value': ('FF434343', 'FF2E2E2E'), 'icon': 'light'}, {'name': 'Medium', 'value': ('FF373737', 'FF4a4347'), 'icon': 'medium'},
			{'name': 'Dark', 'value': ('FF1F2020', 'FF4F4F4F'), 'icon': 'dark'}]

def addon_themes_opacity():
	return [{'name': '100%', 'value': 'FF'}, {'name': '95%', 'value': 'F2'}, {'name': '90%', 'value': 'E6'}, {'name': '85%', 'value': 'D9'}, {'name': '80%', 'value': 'CC'},
			{'name': '75%', 'value': 'BF'}, {'name': '70%', 'value': 'B3'}, {'name': '65%', 'value': 'A6'}, {'name': '60%', 'value': '99'}, {'name': '55%', 'value': '8C'},
			{'name': '50%', 'value': '80'}]

def random_valid_type_check():
	return {'build_movie_list': 'movie', 'build_tvshow_list': 'tvshow', 'build_season_list': 'season', 'build_episode_list': 'episode',
	'build_in_progress_episode': 'single_episode', 'build_next_episode': 'single_episode', 'personal_lists.build_personal_list': 'personal_list',
	'build_personal_lists_contents': 'personal_list'}

def random_episodes_check():
	return {'build_in_progress_episode': 'episode.progress', 'build_next_episode': 'episode.next'}

def extras_buttons_items(media_type):
	return {'movie':
				[{'name': 'Play', 'value': 'movies_play'},
				{'name': 'Trailer', 'value': 'show_trailers'},
				{'name': 'Keywords', 'value': 'show_keywords'},
				{'name': 'Images', 'value': 'show_images'},
				{'name': 'Extra Info', 'value': 'show_extrainfo'},
				{'name': 'Genres', 'value': 'show_genres'},
				{'name': 'Director', 'value': 'show_director'},
				{'name': 'Options', 'value': 'show_options'},
				{'name': 'Cast', 'value': 'show_cast'},
				{'name': 'Recommended', 'value': 'show_recommended'},
				{'name': 'Related', 'value': 'show_related'},
				{'name': 'More Like This', 'value': 'show_more_like_this'},
				{'name': 'Reviews', 'value': 'show_reviews'},
				{'name': 'User Comments', 'value': 'show_user_comments'},
				{'name': 'Comments', 'value': 'show_comments'},
				{'name': 'Trivia', 'value': 'show_trivia'},
				{'name': 'Blunders', 'value': 'show_blunders'},
				{'name': 'FAQs', 'value': 'show_faqs'},
				{'name': 'Quotes', 'value': 'show_quotes'},
				{'name': 'More Year', 'value': 'show_year'},
				{'name': 'More Genres', 'value': 'show_genre'},
				{'name': 'Personal Lists', 'value': 'show_personallists_manager'},
				{'name': 'Favorites Lists', 'value': 'show_favorites_manager'},
				{'name': 'Play Options', 'value': 'playback_choice'},
				{'name': 'Plot', 'value': 'show_plot'},
				{'name': 'Close', 'value': 'close_all'}],
			'tvshow':
				[{'name': 'Browse', 'value': 'tvshow_browse'},
				{'name': 'Trailer', 'value': 'show_trailers'},
				{'name': 'Keywords', 'value': 'show_keywords'},
				{'name': 'Images', 'value': 'show_images'},
				{'name': 'Extra Info', 'value': 'show_extrainfo'},
				{'name': 'Genres', 'value': 'show_genres'},
				{'name': 'Play Next', 'value': 'play_nextep'},
				{'name': 'Options', 'value': 'show_options'},
				{'name': 'Cast', 'value': 'show_cast'},
				{'name': 'Recommended', 'value': 'show_recommended'},
				{'name': 'Related', 'value': 'show_related'},
				{'name': 'More Like This', 'value': 'show_more_like_this'},
				{'name': 'Reviews', 'value': 'show_reviews'},
				{'name': 'User Comments', 'value': 'show_user_comments'},
				{'name': 'Comments', 'value': 'show_comments'},
				{'name': 'Trivia', 'value': 'show_trivia'},
				{'name': 'Blunders', 'value': 'show_blunders'},
				{'name': 'FAQs', 'value': 'show_faqs'},
				{'name': 'Quotes', 'value': 'show_quotes'},
				{'name': 'More Year', 'value': 'show_year'},
				{'name': 'More Genres', 'value': 'show_genre'},
				{'name': 'Personal Lists', 'value': 'show_personallists_manager'},
				{'name': 'Favorites Lists', 'value': 'show_favorites_manager'},
				{'name': 'Play Random', 'value': 'play_random_episode'},
				{'name': 'Plot', 'value': 'show_plot'},
				{'name': 'Close', 'value': 'close_all'}]}[media_type]

def extras_button_defaults(media_type):
	return {'movie': 'movies_play,show_trailers,show_keywords,show_images,show_extrainfo,show_genres,show_director,show_options,show_cast,show_recommended,show_related,' \
			'show_more_like_this,show_reviews,show_user_comments,show_comments,show_trivia,show_blunders,show_faqs,show_quotes,show_year,' \
			'show_genre,show_personallists_manager,show_favorites_manager,playback_choice,show_plot,close_all',
			'tvshow': 'tvshow_browse,show_trailers,show_keywords,show_images,show_extrainfo,show_genres,play_nextep,show_options,show_cast,show_recommended,show_related,' \
			'show_more_like_this,show_reviews,show_user_comments,show_comments,show_trivia,show_blunders,show_faqs,show_quotes,show_year,' \
			'show_genre,show_personallists_manager,show_favorites_manager,play_random_episode,show_plot,close_all'}[media_type]

def extras_button_display_defaults(media_type):
	return {'movie': 'Play,Trailer,Keywords,Images,Extra Info,Genres,Director,Options',
			'tvshow': 'Browse,Trailer,Keywords,Images,Extra Info,Genres,Play Next,Options'}[media_type]

def extras_items():
	return [{'name': 'Plot', 'value': 2050},
	{'name': 'Cast', 'value': 2051},
	{'name': 'Recommended', 'value': 2052},
	{'name': 'Related', 'value': 2053},
	{'name': 'More Like This', 'value': 2054},
	{'name': 'Reviews', 'value': 2060},
	{'name': 'User Comments', 'value': 2067},
	{'name': 'Comments', 'value': 2061},
	{'name': 'Trivia', 'value': 2062},
	{'name': 'Blunders', 'value': 2063},
	{'name': 'FAQs', 'value': 2064},
	{'name': 'Quotes', 'value': 2065},
	{'name': 'Parental Guide', 'value': 2066},
	{'name': 'IMDb Videos', 'value': 2080},
	{'name': 'Youtube Videos', 'value': 2081},
	{'name': 'More from Year', 'value': 2082},
	{'name': 'More from Genres', 'value': 2083},
	{'name': 'More from Collection', 'value': 2084}]

def extras_defaults():
	return '2050,2051,2052,2053,2054,2060,2067,2061,2062,2063,2064,2065,2066,2080,2081,2082,2083,2084'

def extras_display_defaults():
	return 'Plot,Cast,Recommended,Related,More Like This,Reviews,User Comments,Comments,Trivia,Blunders,Quotes,Parental Guide,IMDb Videos,Youtube Videos,' \
			'More from Year,More from Genres,More from Collection'

def context_menu_items():
	return [{'name': 'Select', 'value': 'select'}, {'name': 'Rescrape', 'value': 'rescrape'}, {'name': 'Browse', 'value': 'browse'},
	{'name': 'Extras', 'value': 'extras'},
	{'name': 'More Info', 'value': 'more_info'},
	{'name': 'Options', 'value': 'options'},
	{'name': 'Browse More', 'value': 'browse_more'},
	{'name': 'Play Options', 'value': 'playback_options'},
	{'name': 'TMDb Lists Manager', 'value': 'tmdb_manager'},
	{'name': 'Unmark Previous Watched Episode', 'value': 'unmark_previous_episode'},
	{'name': 'Personal Lists Manager', 'value': 'personal_manager'},
	{'name': 'Favorites Manager', 'value': 'favorites_manager'},
	{'name': 'Mark Watched/Unwatched', 'value': 'mark_watched'},
	{'name': 'Exit List', 'value': 'exit'},
	{'name': 'Refresh Widgets', 'value': 'refresh'},
	{'name': 'Reload Widgets', 'value': 'reload'}]

def context_menu_defaults():
	return 'select,rescrape,browse,extras,more_info,options,browse_more,personal_manager,favorites_manager,mark_watched,exit,refresh,reload'

def context_menu_display_defaults():
	return 'Select,Rescrape,Browse,Extras,More Info,Options,Browse More,Personal Manager,Favorites Manager,Mark Watched,Exit,Refresh,Reload'

def rescrape_items():
	return [
	{'name': 'Rescrape with IMDb Year Data', 'value': 'imdb_year'},
	{'name': 'Rescrape with All Scrapers', 'value': 'all_scrapers'},
	{'name': 'Rescrape With Episode Group', 'value': 'episode_group'},
	{'name': 'Rescrape with Filters Ignored', 'value': 'ignore_filters'}]

def rescrape_defaults():
	return 'imdb_year,all_scrapers,episode_group,ignore_filters'

def rescrape_display_defaults():
	return 'IMDb Year,All Scrapers,Episode Group,Ignore Filters'

def filter_mappings():
	return {
	'D/VISION': 'DOLBY VISION',
	'HDR': 'HIGH DYNAMIC RANGE (HDR)',
	'SDR': 'SDR',
	'3D': '3D',
	'IMAX': 'IMAX',
	'HYBRID': 'HYBRID',
	'AI ENHANCED/UPSCALED': 'AI ENHANCED/UPSCALED',
	'AV1': 'AV1',
	'HEVC': 'HEVC (X265)',
	'REMUX': 'REMUX',
	'BLURAY': 'BLURAY',
	'WEB': 'WEB SOURCE',
	'DVD': 'DVD SOURCE',
	'ATMOS': 'DOLBY ATMOS',
	'TRUEHD': 'DOLBY TRUEHD',
	'DTS-X': 'DTS-X',
	'DTS-HD MA': 'DTS-HD MASTER AUDIO',
	'DTS-HD': 'DTS-HD',
	'DD+': 'DOLBY DIGITAL PLUS',
	'DD-EX': 'DOLBY DIGITAL EX',
	'DD': 'DOLBY DIGITAL',
	'DTS': 'DTS',
	'AAC': 'AAC',
	'OPUS': 'OPUS',
	'MP3': 'MP3',
	'8CH': '8CH AUDIO',
	'7CH': '7CH AUDIO',
	'6CH': '6CH AUDIO',
	'2CH': '2CH AUDIO',
	'MULTI-LANG': 'MULTIPLE LANGUAGES',
	'SUBS': 'SUBTITLES'}

def filters_items():
	return [{'name': display_name, 'value': tag} for tag, display_name in filter_mappings().items()]

def filters_defaults():
	return ','.join(list(filter_mappings().keys()))

def filters_display_defaults():
	return ','.join(list(filter_mappings().values()))


def episode_status():
	return {
	'series_premiere': ('Series Premiere', 'b30385b5'), 'season_premiere': ('Season Premiere', 'b30385b5'), 'mid_season_premiere': ('Mid-Season Premiere', 'b385b503'),
	'series_finale': ('Series Finale', 'b38503b5'), 'season_finale': ('Season Finale', 'b3b50385'), 'mid_season_finale': ('Mid-Season Finale', 'b3b58503'), '':  (None, None)}

def imdb_type_filters():
	return {'movie': ['movie', 'tv movie', 'video', 'tv special'], 'tvshow': ['tv series', 'tv mini-series']}

def video_extensions():
	return ('m4v', '3g2', '3gp', 'nsv', 'tp', 'ts', 'ty', 'pls', 'rm', 'rmvb', 'mpd', 'ifo', 'mov', 'qt', 'divx', 'xvid', 'bivx', 'vob', 'nrg', 'img', 'iso', 'udf', 'pva',
			'wmv', 'asf', 'asx', 'ogm', 'm2v', 'avi', 'bin', 'dat', 'mpg', 'mpeg', 'mp4', 'mkv', 'mk3d', 'avc', 'vp3', 'svq3', 'nuv', 'viv', 'dv', 'fli', 'flv', 'wpl',
			'xspf', 'vdr', 'dvr-ms', 'xsp', 'mts', 'm2t', 'm2ts', 'evo', 'ogv', 'sdp', 'avs', 'rec', 'url', 'pxml', 'vc1', 'h264', 'rcv', 'rss', 'mpls', 'mpl', 'webm',
			'bdmv', 'bdm', 'wtv', 'trp', 'f4v', 'pvr', 'disc')

def image_extensions():
	return ('jpg', 'jpeg', 'jpe', 'jif', 'jfif', 'jfi', 'bmp', 'dib', 'png', 'gif', 'webp', 'tiff', 'tif',
			'psd', 'raw', 'arw', 'cr2', 'nrw', 'k25', 'jp2', 'j2k', 'jpf', 'jpx', 'jpm', 'mj2')

def make_legal_filename(filename):
	return xbmcvfs.makeLegalFilename(filename)

def kodi_progress_background():
	return xbmcgui.DialogProgressBG()

def get_visibility(obj):
	return xbmc.getCondVisibility(obj)

def get_infolabel(label):
	return xbmc.getInfoLabel(label)

def kodi_actor():
	return xbmc.Actor

def translate_path(_path):
	return xbmcvfs.translatePath(_path)

def kodi_monitor():
	return xbmc.Monitor()

def kodi_dialog():
	return xbmcgui.Dialog()

def addon_info(info):
	return xbmcaddon.Addon('plugin.video.infinite').getAddonInfo(info)

def addon_version():
	return get_property('infinite.addon_version') or addon_info('version')

def addon_path():
	return get_property('infinite.addon_path') or addon_info('path')

def addon_profile():
	return get_property('infinite.addon_profile') or translate_path(addon_info('profile'))

def addon_icon():
	return get_property('infinite.addon_icon') or translate_path(addon_info('icon'))

def addon_fanart():
	return get_property('infinite.addon_fanart') or translate_path(addon_info('fanart'))

def get_icon(image_name, image_folder='icons', image_type='png'):
	try: return img_url % getattr(icons, image_name)
	except: return 'https://raw.githubusercontent.com/%s/%s/main/packages/media/%s/%s.%s' % (get_property('infinite.update.username'), get_property('infinite.update.location'), image_folder, image_name, image_type)

def get_addon_fanart():
	return get_property('infinite.default_addon_fanart') or addon_fanart()

def build_main_url(url_params, is_external=None):
	if is_external == None: is_external = external()
	url_params['is_widget'] = 'true' if is_external else 'false'
	return 'plugin://plugin.video.infinite/?%s' % urlencode(url_params)

def build_url(url_params):
	return f'plugin://plugin.video.infinite/?{urlencode(url_params)}'

def add_dir(handle, url_params, list_name, icon_image='folder', fanart_image=None, isFolder=True):
	fanart = fanart_image or get_addon_fanart()
	icon = get_icon(icon_image)
	url = build_url(url_params)
	listitem = make_listitem()
	listitem.setLabel(list_name)
	listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': fanart, 'banner': fanart})
	info_tag = listitem.getVideoInfoTag()
	info_tag.setPlot(' ')
	add_item(handle, url, listitem, isFolder)

def make_listitem():
	return xbmcgui.ListItem(offscreen=True)

def add_item(handle, url, listitem, isFolder):
	xbmcplugin.addDirectoryItem(handle, url, listitem, isFolder)

def add_items(handle, item_list):
	xbmcplugin.addDirectoryItems(handle, item_list)

def set_content(handle, content):
	xbmcplugin.setContent(handle, content)

def set_category(handle, label):
	xbmcplugin.setPluginCategory(handle, label)

def end_directory(handle, cacheToDisc=True):
	xbmcplugin.endOfDirectory(handle, cacheToDisc=cacheToDisc)

def set_view_mode(view_type, content='files', is_external=None):
	if not get_property('infinite.use_viewtypes') == 'true': return
	if is_external is None: is_external = external()
	if is_external: return
	view_id = get_property('infinite.%s' % view_type) or None
	if not view_id: return
	try:
		hold = 0
		sleep(100)
		while not container_content() == content:
			hold += 1
			if hold < 3000: sleep(1)
			else: return
		execute_builtin('Container.SetViewMode(%s)' % view_id)
	except: return

def remove_keys(dict_item, dict_removals):
	for k in dict_removals: dict_item.pop(k, None)
	return dict_item

def append_path(_path):
	import sys
	sys.path.append(translate_path(_path))

def logger(heading, function=''):
	xbmc.log(f'~~~Infinite~~~: {heading} {function}', 1)

def kodi_window():
	return xbmcgui.Window(10000)

def get_property(prop):
	return kodi_window().getProperty(prop)

def set_property(prop, value):
	return kodi_window().setProperty(prop, value)

def clear_property(prop):
	return kodi_window().clearProperty(prop)

def clear_all_properties():
	return kodi_window().clearProperties()

def addon(addon_id='plugin.video.infinite'):
	return xbmcaddon.Addon(id=addon_id)

def addon_installed(addon_id):
	return get_visibility(f'System.HasAddon({addon_id})')

def addon_enabled(addon_id):
	return get_visibility(f'System.AddonIsEnabled({addon_id})')

def container_content():
	return get_infolabel('Container.Content')

def set_sort_method(handle, method):
	xbmcplugin.addSortMethod(handle, {'episodes': 24, 'files': 5, 'label': 2, 'none': 0}[method])

def make_session(url='https://'):
	import requests
	from requests.adapters import HTTPAdapter, Retry
	session = requests.Session()
	retries = Retry(total=2, status=1, backoff_factor=1, status_forcelist=(429, 500, 502, 503, 504, 520, 521, 522, 524, 530))
	session.mount(url, HTTPAdapter(max_retries=retries, pool_maxsize=100))
	return session

def make_playlist(playlist_type='video'):
	return xbmc.PlayList({'music': 0, 'video': 1}[playlist_type])

def supported_media():
	return xbmc.getSupportedMedia('video')

def path_exists(path):
	return xbmcvfs.exists(str(path))

def open_file(_file, mode='r'):
	return xbmcvfs.File(_file, mode)

def copy_file(source, destination):
	return xbmcvfs.copy(source, destination)

def delete_file(_file):
	try: xbmcvfs.delete(_file)
	except Exception as e:
		logger(f'delete_file error: {repr(e)}')
		from os import unlink, remove
		try:
			unlink(_file)
			remove(_file)
		except Exception as e: logger(f'2 delete_file error: {repr(e)}')

def delete_folder(_folder, force=False):
	xbmcvfs.rmdir(_folder, force)

def rename_file(old, new):
	xbmcvfs.rename(old, new)

def last_modified_time_for_file(_file, as_datetime_object=False):
	modification_timestamp = int(xbmcvfs.Stat(_file).st_mtime())
	if as_datetime_object: 
		from datetime import datetime, timezone
		return datetime.fromtimestamp(modification_timestamp, tz=timezone.utc)
	else: return modification_timestamp

def update_timestamp_for_file(_file):
	with open_file(_file) as f_read: binary_content = f_read.readBytes()
	with open_file(_file, mode='w') as f_write: f_write.write(binary_content)

def list_dirs(location):
	return xbmcvfs.listdir(location)

def make_directory(path):
	xbmcvfs.mkdir(path)

def make_directories(path):
	xbmcvfs.mkdirs(path)

def sleep(time):
	return xbmc.sleep(time)

def execute_builtin(command, block=False):
	return xbmc.executebuiltin(command, block)

def current_skin():
	return xbmc.getSkinDir()

def get_window_id():
	return xbmcgui.getCurrentWindowId()

def current_window_object():
	return xbmcgui.Window(get_window_id())

def kodi_version():
	return int(get_infolabel('System.BuildVersion')[0:2])

def get_video_database_path():
	return find_new_db('MyVideos')[0]

def show_busy_dialog():
	return execute_builtin('ActivateWindow(busydialognocancel)')

def hide_busy_dialog():
	execute_builtin('Dialog.Close(busydialognocancel)')
	execute_builtin('Dialog.Close(busydialog)')

def close_dialog(dialog, block=False):
	execute_builtin(f'Dialog.Close({dialog},true)', block)

def close_all_dialog():
	execute_builtin('Dialog.Close(all,true)')

def run_addon(addon='plugin.video.infinite', block=False):
	return execute_builtin(f'RunAddon({addon})', block)

def external():
	return 'infinite' not in get_infolabel('Container.PluginName')

def home():
	return xbmcgui.getCurrentWindowId() == 10000

def folder_path():
	return get_infolabel('Container.FolderPath')

def path_check(string):
	return string in unquote(folder_path())

def reload_skin():
	execute_builtin('ReloadSkin()')

def kodi_refresh():
	execute_builtin('UpdateLibrary(video,special://skin/foo)')

def refresh_widgets():
	from caches.settings_cache import get_setting
	from caches.random_widgets_cache import RandomWidgets
	RandomWidgets().delete_like('random_list.%')
	kodi_refresh()
	if get_setting('infinite.widget_refresh_notification', 'true') == 'true': notification('Widgets Refreshed', 2500)

def run_plugin(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin(f'RunPlugin({params})', block)

def container_update(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin(f'Container.Update({params})', block)

def activate_window(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin(f'ActivateWindow(Videos,{params},return)', block)

def container_refresh():
	return execute_builtin('Container.Refresh')

def container_refresh_input(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin(f'Container.Refresh({params})', block)

def replace_window(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin(f'ReplaceWindow(Videos,{params})', block)

def disable_enable_addon(addon_name='plugin.video.infinite'):
	import json
	try:
		xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled', 'params': {'addonid': addon_name, 'enabled': False}}))
		xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled', 'params': {'addonid': addon_name, 'enabled': True}}))
	except: pass

def update_local_addons():
	execute_builtin('UpdateLocalAddons', True)
	sleep(2500)

def update_kodi_addons_db(addon_name='plugin.video.infinite'):
	import time
	import sqlite3 as database
	try:
		date = time.strftime('%Y-%m-%d %H:%M:%S')
		dbcon = database.connect(find_new_db('Addons')[0], timeout=40.0)
		dbcon.execute("INSERT OR REPLACE INTO installed (addonID, enabled, lastUpdated) VALUES (?, ?, ?)", (addon_name, 1, date))
		dbcon.close()
	except Exception as e: logger(f'error update_kodi_addons_db {str(e)}')

def get_jsonrpc(request):
	import json
	response = xbmc.executeJSONRPC(json.dumps(request))
	result = json.loads(response)
	return result.get('result', None)

def jsonrpc_get_directory(directory, properties=['title', 'file', 'thumbnail']):
	command = {'jsonrpc': '2.0', 'id': 1, 'method': 'Files.GetDirectory', 'params': {'directory': directory, 'media': 'files', 'properties': properties}}
	try: results = [i for i in get_jsonrpc(command).get('files') if i['file'].startswith('plugin://') and i['filetype'] == 'directory']
	except: results = None
	return results

def jsonrpc_get_addons(_type, properties=['thumbnail', 'name']):
	command = {'jsonrpc': '2.0', 'method': 'Addons.GetAddons','params':{'type':_type, 'properties': properties}, 'id': '1'}
	results = get_jsonrpc(command).get('addons')
	return results

def jsonrpc_get_system_setting(setting_id, setting_value=''):
	command = {'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.GetSettingValue', 'params': {'setting': setting_id}}
	try: result = get_jsonrpc(command)['value']
	except: result = setting_value
	return result

def open_settings(params={}):
	from windows.base_window import open_window
	menu_focus, submenu_focus = params.get('menu_focus', 0), params.get('submenu_focus', None)
	open_window(('windows.settings_manager', 'SettingsManager'), 'settings_manager.xml', menu_focus=menu_focus, submenu_focus=submenu_focus)

def external_scraper_settings(params=None):
	try:
		external = get_property('infinite.external_scraper.module')
		if external in ('empty_setting', ''): return
		execute_builtin('Addon.OpenSettings(%s)' % external)
		if params and 'openscrapers' in external:
			#force_update = sync_accounts('infinite retry:')
			#sleep(100)
			notification('sync accounts data')
	except: pass

def progress_dialog(heading='Infinite', icon=None):
	from threading import Thread
	from windows.base_window import create_window
	progress_dialog = create_window(('windows.progress', 'Progress'), 'progress.xml', heading=heading, icon=icon or addon_icon())
	Thread(target=progress_dialog.run).start()
	return progress_dialog

def select_dialog(function_list, **kwargs):
	from windows.base_window import open_window
	selection = open_window(('windows.default_dialogs', 'Select'), 'select.xml', **kwargs)
	if selection in (None, []): return selection
	if kwargs.get('multi_choice', 'false') == 'true': return [function_list[i] for i in selection]
	return function_list[selection]

def confirm_dialog(heading='Infinite', text='Are you sure?', ok_label='OK', cancel_label='Cancel', default_control=11):
	from windows.base_window import open_window
	kwargs = {'heading': heading, 'text': text, 'ok_label': ok_label, 'cancel_label': cancel_label, 'default_control': default_control}
	return open_window(('windows.default_dialogs', 'Confirm'), 'confirm.xml', **kwargs)

def ok_dialog(heading='Infinite', text='No Results', ok_label='OK'):
	from windows.base_window import open_window
	kwargs = {'heading': heading, 'text': text, 'ok_label': ok_label}
	return open_window(('windows.default_dialogs', 'OK'), 'ok.xml', **kwargs)

def list_editor_dialog(**kwargs):
	from windows.base_window import open_window
	return open_window(('windows.default_dialogs', 'ListEditor'), 'list_editor.xml', **kwargs)

def show_text(heading='Infinite', text=None, file=None, font_size='small', kodi_log=False):
	import textwrap
	from windows.base_window import open_window
	heading = heading.replace('[B]', '').replace('[/B]', '')
	if file:
		t_file = file
		try:
			if file.startswith('special://'): t_file = translate_path(file)
			logger(f't_file: {t_file}')
		except: pass
		if kodi_log:
			confirm = confirm_dialog(text='Show Log Errors Only?', ok_label='Yes', cancel_label='No')
			if confirm is None: return
			if confirm: text = truncate_log_file(t_file, only_error=True)
			else: text = truncate_log_file(t_file)
		else:
			with open(t_file, encoding='utf-8') as r: text = r.readlines()
	if isinstance(text, str): text = text.splitlines()
	processed_lines, max_characters = [], 105
	for line in text:
		clean_line = line.rstrip('\r\n')
		if len(clean_line) > max_characters:
			wrapped_chunks = textwrap.wrap(line, width=max_characters, break_long_words=False)
			if wrapped_chunks: processed_lines.append(wrapped_chunks[0])
			for chunk in wrapped_chunks[1:]: processed_lines.append(chunk)
		else: processed_lines.append(clean_line)
	return open_window(('windows.textviewer', 'TextViewer'), 'textviewer.xml', heading=heading, text=processed_lines, font_size=font_size)

def notification(line1, time=3000, icon=None, sound=False):
	if 'error' in line1.lower(): get_traceback()
	kodi_dialog().notification('Infinite', line1, icon or addon_icon(), time, sound)

def timeIt(func):
	import time
	fnc_name = func.__name__
	def wrap(*args, **kwargs):
		started_at = time.perf_counter()
		result = func(*args, **kwargs)
		logger(f'{__name__}.{fnc_name} {time.perf_counter() - started_at}')
		return result
	return wrap

def volume_checker():
	try: # 0% == -60db, 100% == 0db
		if get_property('infinite.playback.volumecheck_enabled') == 'false' or get_visibility('Player.Muted'): return
		from modules.utils import string_alphanum_to_num
		max_volume = min(int(get_property('infinite.playback.volumecheck_percent') or '50'), 100)
		if int(100 - (float(string_alphanum_to_num(get_infolabel('Player.Volume').split('.')[0]))/60)*100) > max_volume: execute_builtin('SetVolume(%d)' % max_volume)
	except: pass

def focus_index(index):
	current_window = current_window_object()
	focus_id = current_window.getFocusId()
	try: current_window.getControl(focus_id).selectItem(index)
	except: logger(f'focus_index Error: {print_exc()}')

def get_all_icons(include_values=False):
	try:
		return get_icon_name(include_values=False)
	except:
		import requests
		from caches.main_cache import cache_object
		def _process(dummy):
			try:
				results = requests.get('https://api.github.com/repos/%s/%s/contents/packages/media/icons' % (username, location))
				results = [i['name'].replace('.png', '') for i in results.json()]
				return results
			except: return ['folder.png']
		username, location = get_property('infinite.update.username'), get_property('infinite.update.location')
		return cache_object(_process, 'all_icons', 'foo', False, 168)

def upload_logfile(params):
	import json
	import requests
	from modules.utils import copy2clip, make_qrcode
	log_files = [('Current Kodi Log', 'kodi.log'), ('Previous Kodi Log', 'kodi.old.log')]
	list_items = [{'line1': i[0]} for i in log_files]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Choose Which Log File to Upload', 'narrow_window': 'true'}
	log_file = select_dialog(log_files, **kwargs)
	if log_file is None: return
	log_name, log_file = log_file
	if not confirm_dialog(heading=log_name): return
	show_busy_dialog()
	url = 'https://paste.kodi.tv/'
	log_file = translate_path(f'special://logpath/{log_file}')
	if not path_exists(log_file): return ok_dialog(text='Error. Log Upload Failed')
	try:
		with open_file(log_file) as f: text = f.read()
		text = senitized_log(text)
		UserAgent = 'script.kodi.loguploader: 1.0'
		response = requests.post('%s%s' % (url, 'documents'), data=text.encode('utf-8', errors='ignore'), headers={'User-Agent': UserAgent}).json()
		if 'key' in response:
			user_code = response['key']
			url = '%s%s' % (url, user_code)
			copy2clip(url)
			qr_code = make_qrcode(url) or ''
			progressDialog = progress_dialog(heading='Kodi Log Uploader', icon=qr_code)
			count, success = 20, None
			while not progressDialog.iscanceled() and count >= 0 and success == None:
				try:
					count -= 1
					progressDialog.update('Share or Access with this url: [B]%s[/B][CR]Or Access using this QR Code' % url, count)
					sleep(2500)
				except: success = False
		else: ok_dialog(text='Error. Log Upload Failed')
	except: ok_dialog(text='Error. Log Upload Failed')
	hide_busy_dialog()

def fetch_kodi_imagecache(image):
	import sqlite3 as database
	result = None
	try:
		dbcon = database.connect(find_new_db('Textures')[0], timeout=40.0)
		dbcur = dbcon.cursor()
		dbcur.execute("SELECT cachedurl FROM texture WHERE url = ?", (image,))
		result = dbcur.fetchone()[0]
	except: pass
	return result

def get_traceback():
	import inspect
	func = inspect.currentframe().f_back
	# allframs = inspect.getouterframes(inspect.currentframe())
	# logger(f'allframs: {allframs}')
	funcat = 'not found'
	if 'plugin.video.infinite' in func.f_code.co_filename:
		funcat = func.f_code.co_filename.split('plugin.video.infinite')[1]
	logger(f'line_number: {func.f_lineno} func name: {func.f_code.co_name} func file: {funcat}\n{"".join(format_stack())}')
	return

def external_playback_check(params):
	from modules.settings import playback_key
	if not playback_key() in params:
		ok_dialog('External Playback Detected', 'Playback through external addons is not supported')
		return False
	return True

def get_all_addon_icons(include_values=False):
	try:
		return get_icon_name(include_values=False)
	except:
		import requests
		from caches.main_cache import cache_object
		def _process(dummy):
			try:
				results = requests.get('https://api.github.com/repos/%s/%s/contents/packages/addon_icons' % (username, location))
				return results
			except: return []
		username, location = get_property('infinite.update.username'), get_property('infinite.update.location')
		return cache_object(_process, 'all_addon_icons', 'foo', True, 168)

def get_icon_name(include_values=False):
	if include_values: return [(k, v) for k, v in vars(icons).items() if not k.startswith('__')]
	else: return [k for k, v in vars(icons).items() if not k.startswith('__')]

def find_new_db(pattern):
	_path = translate_path('special://profile/Database/')
	result = []
	for root, dirs, files in os.walk(_path):
		for name in files:
			if pattern in name and name.endswith('.db'):
				result.append(os.path.join(root, name))
	return result

def set_info(item, meta, setUniqueIDs=None, resumetime=''):
	try:
		if resumetime: resumetime = float(resumetime)
		meta_get = meta.get
		media_type = meta_get('mediatype') or meta_get('media_type')
		info_tag = item.getVideoInfoTag()
		info_tag.setMediaType(media_type)
		if setUniqueIDs: info_tag.setUniqueIDs(setUniqueIDs)
		info_tag.setPath(meta_get('path'))
		info_tag.setFilenameAndPath(meta_get('filenameandpath'))
		info_title = item.getLabel() if meta_get('title') == '' else meta_get('title')
		info_tag.setTitle(info_title)
		info_tag.setSortTitle(meta_get('sorttitle'))
		info_tag.setOriginalTitle(meta_get('originaltitle') or meta_get('original_title'))
		info_tag.setPlot(meta_get('plot') or '')
		info_tag.setPlotOutline(meta_get('plotoutline') or '')
		info_tag.setDateAdded(meta_get('dateadded'))
		info_tag.setPremiered(meta_get('premiered') or '2026-1-1')
		info_tag.setYear(convert_type(int, meta_get('year') or 2026))
		info_tag.setRating(convert_type(float, meta_get('rating') or 4.5))
		info_tag.setMpaa(meta_get('mpaa'))
		info_tag.setDuration(meta_get('duration') or 1320)
		info_tag.setPlaycount(convert_type(int , meta_get('playcount') or 0))
		if isinstance(meta_get('votes'), str): meta_votes = str(meta_get('votes')).replace(',', '')
		else: meta_votes = meta_get('votes')
		if meta_votes: info_tag.setVotes(convert_type(int, meta_votes))
		info_tag.setLastPlayed(meta_get('lastplayed'))
		info_tag.setAlbum(meta_get('album'))
		info_tag.setTags(meta_get('tag', []))
		info_tag.setTagLine(meta_get('tagline'))
		try:
			info_tag.setGenres(meta_get('genre') or [])
			info_tag.setWriters(meta_get('writer') or [])
			info_tag.setDirectors(meta_get('director') or [])
			info_tag.setCountries(meta_get('country') or [])
			info_tag.setTrailer(meta_get('trailer') or '')
			info_tag.setStudios(meta_get('studio') or [])
		except: logger(f'set_info meta : {meta} error: {print_exc()}')
		info_tag.setIMDBNumber(meta_get('imdb_id') or '')
		if resumetime and meta_get('duration'): info_tag.setResumePoint(resumetime, meta_get('duration'))
		elif resumetime: info_tag.setResumePoint(resumetime)
		if media_type in ('tvshow', 'season', 'episode'):
			info_tag.setTvShowTitle(meta_get('tvshowtitle'))
			info_tag.setTvShowStatus(meta_get('status'))
		if media_type in ('episodes', 'episode'):
			info_tag.setFirstAired(meta_get('premiered') or '2026-1-1')
			info_tag.setEpisode(convert_type(int, meta_get('episode')))
			info_tag.setSeason(convert_type(int, meta_get('season')))
		try: info_tag.setCast([kodi_actor()(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in meta_get('cast', [])])
		except: pass#info_tag.setCast([kodi_actor()(name=item, role='', thumbnail='') for item in meta_get('cast', [])])
	except: logger(f'set_info meta : {meta} error: {print_exc()}')
	return item

def convert_type(_type, _value):
	if _type == str and isinstance(_value, list): return ', '.join(list(_value))
	try: return _type(_value)
	except TypeError as Err: return _type()
	except Exception as Err: logger(f'convert_type error: {Err}')

def set_inputstream(url, litem, is_type='adaptive'):
	if is_type == 'adaptive':
		adaptive_plugin = translate_path('special://home/addons/inputstream.adaptive')
		if not path_exists(adaptive_plugin):
			try:
				execute_builtin('InstallAddon(script.module.inputstreamhelper)', True)
				execute_builtin('InstallAddon(inputstream.adaptive)', True)
			except: return litem
		litem.setProperty('inputstream', 'inputstream.adaptive')
		litem.setProperty('inputstream.adaptive.max_bandwidth', '100000000000')
		litem.setProperty('http-reconnect', 'true')
		# if '.m3u8' in url.lower(): litem.setMimeType('application/vnd.apple.mpegurl') #and inputstreamhelper.Helper('hls').check_inputstream():
		# elif '.ism' in url.lower(): litem.setMimeType('application/vnd.ms-sstr+xml')
		# elif '.mpd' in url.lower(): litem.setMimeType('application/dash+xml')
		if '|' in url: # and ('m3u8' in url.lower() or '.mpd' in url.lower()):
			url, strhdr = url.split('|')
			litem.setProperty('inputstream.adaptive.stream_headers', strhdr)
			litem.setProperty('inputstream.adaptive.common_headers', strhdr)
			# litem.setProperty('inputstream.adaptive.manifest_headers', strhdr)
		# litem.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
		# license_headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0', 'Content-Type': 'application/octet-stream', 'Origin': 'https://www.somesite.com'}
		# from urllib.parse import urlencode
		# license_config = {'license_server_url': 'https://license.server.com/licenserequest', 'headers': urlencode(license_headers), 'post_data': 'R{SSM}', 'response_data': 'R'}
		# litem.setProperty('inputstream.adaptive.license_key', '|'.join(license_config.values()))
	else: #if is_type == 'ffmpeg':
		ffmpeg_plugin = translate_path('special://home/addons/inputstream.ffmpegdirect')
		if not path_exists(ffmpeg_plugin):
			try: execute_builtin('InstallAddon(inputstream.ffmpegdirect)', True)
			except: return litem
		litem.setProperty('inputstream', 'inputstream.ffmpegdirect')
		litem.setMimeType('application/x-mpegURL')# litem.setMimeType('application/vnd.apple.mpegurl')
		litem.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
		litem.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift')
		litem.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
	return litem

def kodi_player(url=None, channel='NO LABLE', direct_player=False):
	# logger(f'Common play:: channel: {channel} type(url): {type(url)} url: {url}')
	if not url: return xbmc.Player()
	if direct_player:
		try:
			execute_builtin('PlayMedia(%s)' % url)
			hide_busy_dialog()
		except: logger(f'Common play:: {channel} Error {print_exc()}')
	else:
		from modules.player import infinitePlayer
		try: infinitePlayer().run(url, 'video', {'title': channel})
		except: logger(f'Common play:: {channel} Error {print_exc()}')
	return None


def set_resolvedurl(url, title='resolv', use_adaptive=None):
	from sys import argv
	handle = int(argv[1])
	play_item = xbmcgui.ListItem(path=url)
	info_tag = play_item.getVideoInfoTag()
	info_tag.setPath(url)
	info_tag.setTitle(title)
	if use_adaptive in ('adaptive', 'ffmpeg'): set_inputstream(url, play_item, is_type=use_adaptive)
	xbmcplugin.setResolvedUrl(handle, True, play_item)

def senitized_log(text):
	regex = re.compile(r'Users\\+(\w+)|Users%5c(\w+)%5c', re.IGNORECASE)
	return regex.sub(r'special://', text)

LOG_PREFIX_RE = re.compile(r"^\s*\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\.\d+\s+T:\d+\s+", re.MULTILINE)

def strip_log_prefix(text: str) -> str:
	"""Remove timestamp + thread ID prefix from Kodi log lines.Pattern matches ` 2026-06-05 13:00:15.168 T:17916 `"""
	return LOG_PREFIX_RE.sub("", text)

def truncate_log_file(lfile, only_error=False):
	text = ''
	with open(lfile, 'r', encoding='utf-8', errors='ignore') as f:
		Lines = f.readlines()
	head = Lines[:24] # first 24 lines
	tail = Lines[100:] # line 350 → end (0‑indexed)
	total_line = len(Lines)
	# log(f'total_line: {total_line}')
	if total_line >= 440: tail = Lines[440:]
	if total_line >= 335: tail = Lines[335:]
	if total_line >= 800: tail = Lines[(total_line // 2):]
	kept = head + tail
	result = []
	r_append = result.append
	for line in kept:
		line = strip_log_prefix(line)
		# line = apply_replacements(line)
		r_append(line)
	result = ' '.join(result)
	text = senitized_log(result)
	if only_error:
		with open(lfile, 'w', encoding='utf-8', errors='ignore') as r: r.writelines(text)
	return text

def get_list_item(list_data, provider='', isFolder=False):
	for item in list_data:
		get_item = item.get
		cm = []
		cm_append = cm.append
		# logger(f'lists _process item: {item}')
		title, poster, action, isfolder = get_item('title', get_item('name')) , get_item('poster', get_item('image', addon_icon())), get_item('mode', 'ltp_play'), get_item('isfolder') or isFolder
		if provider == 'watchonline': action = item.get('mode') or 'watchonline_s'
		elif provider == 'youtube_r': action, poster = 'geetm_list', f'https://www.hindigeetmala.net{poster}' if poster.startswith('/') else poster
		url_params = dict(item, **{'mode': action, 'title': title, 'poster': poster, 'imdb_id': title, 'provider': provider, 'rescrap': 'false', 'mediatype': 'episode', 'episode': 1, 'season': 1})
		url = build_url(url_params)
		if isfolder:
			rescrape_params = dict(url_params, **{'rescrap': 'true'})
			cm_append((f'Reload {title}', f'RunPlugin({build_url(rescrape_params)})'))
			cm_append(('Add to a Shortcut Folder', 'RunPlugin(%s)' % build_url({'mode': 'menu_editor.shortcut_folder_add_item', 'name': title, 'iconImage': poster})))
		cm_append(('Open Settings', f'RunPlugin({build_url(opensettings_params)})'))
		listitem = make_listitem()
		listitem.setLabel(title)
		listitem.addContextMenuItems(cm)
		listitem.setArt({'thumb': poster})
		listitem = set_info(listitem, url_params, {'imdb': str(title)})
		yield url, listitem, isfolder
	return

def sync_accounts(silent=''):
	from openscrapers import get_creden
	from caches.settings_cache import get_setting, set_setting
	force_update = False
	try:
		all_acct = get_creden(silent)
		set_setting('urls', str(all_acct.get('urls')))
		api_keys = all_acct.get('api_keys')
		if get_setting('infinite.rpdb_api') == 'empty_setting':
			set_setting('rpdb_api', api_keys.get('rpdb_api'))
		if get_setting('infinite.omdb_api') == 'empty_setting':
			set_setting('omdb_api', api_keys.get('omdb_api'))
		if get_setting('infinite.tmdb.account_id') != api_keys.get('tmdb.account_id'):
			set_setting('tmdb_api', api_keys.get('tmdb'))
			set_setting('tmdb.token', api_keys.get('tmdb.token'))
			set_setting('tmdb.username', api_keys.get('tmdb.user'))
			set_setting('tmdb.account_id', api_keys.get('tmdb.account_id'))
			set_setting('tmdb.session_id', api_keys.get('tmdb.session_id'))
			set_setting('tmdb.account_session_id', api_keys.get('tmdb.session_account_id'))
		if get_setting('infinite.trakt.client') != api_keys.get('trakt.client'):
			set_setting('trakt.client', api_keys.get('trakt.client'))
			set_setting('trakt.secret', api_keys.get('trakt.secret'))
	except:
		# set_setting('watched_indicators', '0')
		logger(f'Error: {print_exc()}')
	if 'retry' not in silent: notification('Settings Updated')
	return force_update

def update_metadb():
	try:
		from modules.downloader import runner
		from modules.settings import get_git_url
		custom_files_path = get_git_url()
		urls = ['watched.db', 'personal_lists.db']
		# urls = ['/skipintro.json?raw=true']
		for url in urls:
			runner({'mode': 'downloader', 'url': f'{custom_files_path}/{url}?raw=true', 'action': 'hindi_file', 'name': f'download file: {url}', 'silent': True, 'media_type': 'file'})
			notification('Files updated')
	except:
		logger(f'Error: {print_exc()}')
		notification('Error')
