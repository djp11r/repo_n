# -*- coding: utf-8 -*-

import re
from traceback import print_exc
from modules.kodi_utils import json, logger, select_dialog, skipintro_db


def clean_title(title):
    if title is None: return
    exctract_date = re.compile(r'(\d{1,2}[th|st|nd|rd]* [Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|August|Sep|September|Oct|October|Nov|November|Dec|December]* \d{2,4})', flags=re.I)
    episode_data = re.compile(r'[Ee]pisode.+?(\d+)|[Ee]p (\d+)|[Ee](\d+)|[sS]eason.+?(\d+)|[sS]eason(\d+)|[sS](\d+)|[Cc]hapter (\d+)', flags=re.I)
    ascii_char = re.compile(r'(\x9B|\x1B\[)[0-?]*[ -\/]*[@-~]', flags=re.I)
    non_ascii_char = re.compile(r'[^\x00-\x7f]', flags=re.I)
    color_data = re.compile(r'\[COLOR.+?\].+?\[\/COLOR\]|\(.*?\)+', flags=re.I)
    try:
        title = re.sub(color_data, '', title)  # remove date like [COLOR yellow]1x1[/COLOR] OR [COLOR cyan]July 10, 2017[/COLOR] or ( any thing( #)
        title = re.sub(exctract_date, '', title) # remove date like 18th April 2021
        title = re.sub(episode_data, '', title) # remove episode 12 or season 1 etc
        title = re.sub(ascii_char, '', title)  # remove ascii_char
        title = re.sub(non_ascii_char, '', title)  # remove non_ascii_char
        title = re.sub(r'&#(\d+);', '', title)
        title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
        title = title.replace('&quot;', '\"').replace('&amp;', '&')
        title = re.sub(r'([:;\-"\',!#`_.?~$@])', '', title) # remove all characters in bracket
        title = re.sub(r'\<[^>]*\>|\([^)]*\)', '', title) # remove like this <any thing> or (any thing)
        # title = re.sub(r'\([^>]*\)', '', title) # remove in bracket like (any thing) etcx
        # title = re.sub(r'\n|([[].+?[]])|([(].+?[)])|\s(vs|v[.])\s|(:|;|-|"|,|\'|\_|\.|\?)|\(|\)|\[|\]|\{|\}|\s', '', title).lower()
        # title = re.sub(r'\n|([\[({].+?[})\]])|([:;\-"\',!_.?~$@])|\s', '', title)
        title = re.sub(r'\s+', ' ', title) # remove Multiple Spaces
    except: pass
    return title.strip()


def updateSkip(skip_option):
    logger(f'updateSkip skip_option: {skip_option}')
    with open(skipintro_db, mode='r', encoding='utf-8') as file:
        json_data = json.load(file)
    for item in json_data:
        if item['title'] == skip_option.get('title'):
            item['service'] = skip_option.get('service')
            item['skip'] = skip_option.get('skip')
            item['eskip'] = skip_option.get('eskip')
            item['start'] = skip_option.get('start')
    with open(skipintro_db, mode='w', encoding='utf-8') as file:
        json.dump(json_data, file) #, indent=2)


def newskip(title):
    try:
        with open(skipintro_db, mode='r', encoding='utf-8') as f:
            data = json.load(f)
    except: data = []
    newIntro = {'title': title, 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '300'}
    data.append(newIntro)
    with open(skipintro_db, mode='w', encoding='utf-8') as f:
        json.dump(data, f) #, indent=2)
    return newIntro


def enable_show():
    with open(skipintro_db, mode='r', encoding='utf-8') as file:
        json_data = json.load(file)

    if choices_list := [item for item in json_data if item['service'] == 'False']:
        try:
            # from xbmcgui import Dialog
            # dialog = Dialog()
            # choice = dialog.select("Select to Update.", [f'{i["title"]}' for i in choices_list], autoclose=4000)
            # logger(f'choice: {choice}')
            # choice_option = choices_list[int(choice)]
            # title = choices_list[int(choice)]['title']
            # logger(f'choice: type: {type(choice_option)} choice_option: {choice_option}')
            # choice_option.update({'service': 'True'})
            # logger(f'enable_show after upd: {choice_option}')

            list_items = [{'line1': item['title'], 'line2': str(item)} for item in choices_list]
            kwargs = {'items': json.dumps(list_items), 'heading': 'Select item to Enable.', 'multi_line': 'true', 'narrow_window': 'true'}
            choice_option = select_dialog(choices_list, **kwargs)
            if choice_option is None: return
            # logger(f'enable_show after choice_option: {choice_option}')
            choice_option.update({'service': 'True'})
            # logger(f'enable_show after choice_option: {choice_option}')
            updateSkip(choice_option)
        except: logger(f'Error: {print_exc()}')

def get_skip_option(title):
    title = clean_title(title)
    try:
        with open(skipintro_db, mode='r', encoding='utf-8') as f: data = json.load(f)
        start = [i for i in data if i['title'] == title][0]
    except: start = newskip(title)
    return start