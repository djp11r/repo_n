# -*- coding: utf-8 -*-
import traceback
from modules.kodi_utils import logger, get_setting, sleep
from windows.skip import Skip
from windows import open_window, create_window
import sys, time, datetime
# from caches import clean_databases


def testting():
    test_window()


def test_window(win='yes_no_progress_win'):
    meta = {'tmdb_id': 96488, 'tvdb_id': 371242, 'imdb_id': 'tt9310136', 'rating': 6.7, 'plot': 'Based on a true story that spanned more than 30 years in which a young man was charged and convicted of brutally murdering his mother. Each episode is structured around an interrogation taken directly from the real police case files, with the goal of turning the viewer into a detective.', 'tagline': 'Justice is a matter of perspective.', 'votes': 20, 'premiered': '2020-02-05', 'year': '2020', 'poster': 'https://image.tmdb.org/t/p/w185/oJAvkzejtQzqwsDjkd8Y0m2oDL9.jpg', 'fanart': 'https://image.tmdb.org/t/p/w300/mvUvM6MLriYmmzAuuOznpPjbVSO.jpg', 'genre': ['Drama', 'Crime'], 'title': 'Interrogation', 'original_title': 'Interrogation', 'english_title': '', 'season_data': [{'air_date': '2020-02-05', 'episode_count': 10, 'id': 138202, 'name': 'Season 1', 'overview': '', 'poster_path': '/rC9T7UGmRKPK0C0BRcQUywVE6ZU.jpg', 'season_number': 1}], 'alternative_titles': [], 'duration': 2700, 'rootname': 'Interrogation (2020)', 'imdbnumber': 'tt9310136', 'country': ['United States of America'], 'mpaa': 'TV-MA', 'trailer': 'plugin://plugin.video.youtube/play/?video_id=bIGBrzjbtks', 'country_codes': ['US'], 'writer': [], 'director': [], 'all_trailers': [{'iso_639_1': 'en', 'iso_3166_1': 'US', 'name': 'Official Trailer', 'key': 'bIGBrzjbtks', 'site': 'YouTube', 'size': 1080, 'type': 'Trailer', 'official': True, 'published_at': '2020-01-12T23:38:05.000Z', 'id': '5e63b121459ad60018570747'}], 'cast': [{'name': 'Peter Sarsgaard', 'role': 'David Russell', 'thumbnail': 'https://image.tmdb.org/t/p/w185/jOc4VjxPaOkWOqnLCxd8BJy9g5i.jpg'}, {'name': 'Kyle Gallner', 'role': 'Eric Fisher', 'thumbnail': 'https://image.tmdb.org/t/p/w185/xY40mgzeGCJrV6P5Vlh2TgIOmkR.jpg'}, {'name': 'David Strathairn', 'role': 'Henry Fisher', 'thumbnail': 'https://image.tmdb.org/t/p/w185/fhkvTcrCDPTAclTnE7sqQS1NZKq.jpg'}, {'name': 'Kodi Smit-McPhee', 'role': 'Chris Keller', 'thumbnail': 'https://image.tmdb.org/t/p/w185/sesCWba9NwPDYDZzbVLs7OgLOti.jpg'}], 'studio': ['CBS All Access'], 'extra_info': {'status': 'Canceled', 'type': 'Scripted', 'homepage': 'https://www.paramountplus.com/shows/interrogation/', 'created_by': 'John Mankiewicz, Anders Weidemann', 'next_episode_to_air': None, 'last_episode_to_air': {'air_date': '2020-02-05', 'episode_number': 10, 'id': 2071848, 'name': 'I.A. Sgt. Ian Lynch & Det. Brian Chen vs Trey Carano 2003', 'overview': "Twenty years after Mary Fisher's death, Internal Affairs Sgt. Lynch and Det. Chen fly to Texas to interview Trey Carano, a former friend of Eric's, who shares his account of Eric's whereabouts in the days and hours leading up to the murder.", 'production_code': '', 'runtime': 45, 'season_number': 1, 'show_id': 96488, 'still_path': '/yGgL588X4eF6vuAaMeDMiyRxAKQ.jpg', 'vote_average': 8.0, 'vote_count': 1}}, 'total_aired_eps': 10, 'mediatype': 'tvshow', 'total_seasons': 1, 'tvshowtitle': 'Interrogation', 'status': 'Canceled', 'poster2': 'https://assets.fanart.tv/fanart/tv/371242/tvposter/interrogation-5e3f0a6ff1c62.jpg', 'fanart2': 'https://assets.fanart.tv/fanart/tv/371242/showbackground/interrogation-5eb26359e9234.jpg', 'banner': 'https://assets.fanart.tv/fanart/tv/371242/tvbanner/interrogation-5edcd09889554.jpg', 'clearart': '', 'clearlogo': '', 'landscape': 'https://assets.fanart.tv/fanart/tv/371242/tvthumb/interrogation-5e3f0a8a0bb17.jpg', 'discart': '', 'keyart': '', 'fanart_added': True, 'clearlogo2': 'https://assets.fanart.tv/fanart/tv/371242/hdtvlogo/interrogation-5eb265b6c946e.png', 'ep_name': None, 'media_type': 'episode', 'season': 1, 'episode': 5, 'background': False, 'skip_option': {'title': 'Interrogation', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '60'}, 'skip_style': 'netflix'}
    if win == 'nextep_win': # windows.next_episode <<<<<<<<<
        action = open_window(('windows.next_episode', 'NextEpisode'), 'next_episode.xml', meta=meta, function='confirm')
        action = open_window(('windows.next_episode', 'NextEpisode'), 'next_episode.xml', meta=meta, function='next_ep')
    elif win == 'infopop': # windows.next_episode <<<<<<<<<
        action = open_window(('windows.infopopup', 'InfoPopup'), 'infopopup.xml', meta=meta, is_widget='false')
    elif win == 'skip_win': # windows.skip <<<<<<<<<<
        skip_option = {'title': 'The Blacklist', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '300'}
        # if get_setting('skip.dialog') == "Regular":
            # buttonskip = open_window(('windows.skip', 'Skip'), 'skip_dialog.xml', skip_option=skip_option)
            # # buttonskip = Skip("skip_dialog.xml", location, "default", "1080i", skip_option=self.skip_option)
        # else:
            # buttonskip = open_window(('windows.skip', 'Skip'), 'skip.xml', skip_option=skip_option)
        windowstyle = get_setting('skip.dialog')
        logger(f'windowstyle: {windowstyle.lower()}')
        buttonskip = open_window(('windows.skip', 'Skip'), 'skipmulti.xml', skip_option=skip_option, focus_button=201, window_style=windowstyle.lower())
        logger(f'buttonskip: {buttonskip}')
    elif win == 'yes_no_progress_win': # yes_no_progress_media <<<<<<<
        from threading import Thread
        from modules import kodi_utils, settings
        meta = {'mediatype': 'episode', 'year': 2022, 'plot': 'The Kapil Sharma Show, also known as TKSS, is an Indian Hindi-language stand-up comedy and talk show broadcast by Sony Entertainment Television. Hosted by Kapil Sharma The series revolved around Sharma and his neighbours in the Shantivan Non Co-operative Housing Society.', 'title': 'The Kapil Sharma Show Season 4', 'studio': ['Sony'], 'poster': 'https://www.desi-serials.cc/wp-content/uploads/2022/08/The-Kapil-Sharma-Show-300x169.jpg', 'homepage': 'https://www.desi-serials.cc/watch-online/sony-tv/the-kapil-sharma-show-season-4/', 'genre': ['Saturday  Sunday.', 'Comedy', 'Talk-Show'], 'cast': [], 'tmdb_id': 'Sony|The Kapil Sharma Show Season 4', 'imdb_id': 'tt5747326', 'rating': 7.3, 'clearlogo': '', 'trailer': '', 'votes': 50, 'tagline': '', 'director': [], 'writer': [], 'episodes': 390, 'seasons': '1, 2, 3, 4', 'extra_info': {'status': '', 'collection_id': ''}, 'tvdb_id': 'Sony|the kapil sharma show', 'duration': 3600, 'mpaa': 'TV-MA', 'season': 4, 'episode': 910, 'tvshowtitle': 'The Kapil Sharma Show Season 4', 'playcount': 0, 'original_title': 'The Kapil Sharma Show Season 4', 'total_seasons': '4', 'url': 'https://www.desi-serials.cc/the-kapil-sharma-show-season-4-episode-10th-september-2022-watch-online/441968/', 'fanart': 'https://www.desi-serials.cc/wp-content/uploads/2022/08/The-Kapil-Sharma-Show-300x169.jpg', 'premiered': '2022-09-10', 'ep_name': '10th September 2022', 'overlay': 4, 'media_type': 'episode', 'background': False, 'skip_option': {'title': 'The Kapil Sharma Show', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '300'}, 'skip_style': 'netflix'}
        # kwargs = {'meta': meta, 'text': 'ok i see', 'enable_buttons': True, 'true_button': "Yes", 'false_button': "No", 'focus_button': 11}
        kwargs = {'meta': meta, 'text': 'ok i see', 'enable_fullscreen': True}
        _threads = []
        start_time = time.time()
        timeout = 20
        sleep_time = settings.display_sleep_time()
        end_time = start_time + timeout
        line1 = '[COLOR %s][B]%s[/B][/COLOR]'
        main_line = '%s[CR]%s[CR]%s'
        dialog_format, remaining_format = '[COLOR %s][B]%s[/B][/COLOR] 4K: %s | 1080p: %s | 720p: %s | SD: %s | Total: %s', kodi_utils.local_string(32676)
        # progress_dialog = kodi_utils.confirm_progress_media(meta=meta, enable_fullscreen=False, enable_buttons=True)
        progress_dialog = kodi_utils.confirm_progress_media(meta=meta, enable_fullscreen=True)
        # progress_dialog = kodi_utils.confirm_progress_media(meta=meta, enable_fullscreen=False)
        while not progress_dialog.iscanceled():
            try:
                if kodi_utils.monitor.abortRequested(): break
                if progress_dialog.iscanceled(): 
                    progress_dialog.close()
                    break
                remaining_providers = ['freeworldnews.tv', 'playersb.com', 'vedshare.com', 'voeunblock8.com', 'youtu.be', 'playdrive.xyz', 'fplayer.info', 'vedpom.com', 'userload.co', 'megogo.ru', 'goload.pro', 'javplaya.com', 'bigclatterhomesguideservice.com', 'bp.blogspot.com', 'slwatch.co', 'vidcloud.pro', 'streamingcommunity.xyz', 'vudeo.io', 'yadi.sk', 'fembad.org', 'rutube.ru', 'mixdrop.to', 'streamz.ws', 'mcloud.to', 'videoslala.net', 'vidstore.me', 'dood.so', 'tubesb.com', '24hd.club', 'voe-un-block.com', 'youdbox.com', 'vizcloud.digital', 'ndrama.xyz', 'mzzcloud.life', 'my.mail.ru', 'tudou.com', 'lbry.tv', 'vidnext.net', 'voeunblock10.com', 'vidohd.com', 'streamingcommunity.space', 'mixdrop.sx', 'ncdnstm.com', 'sbembed1.com', 'reputationsheriffkennethsand.com', 'eplayvid.com', 'dood.watch', 'truhd.xyz', 'vadbom.com', 'sendvid.com', 'upvideo.to', 'streamtape.net', 'moviemaniac.org', 'streamingcommunity.site', 'vidstreaming.io', 'goload.io', 'dood.la', 'streamingcommunity.video', 'plus.google.com', 'streamruby.com', 'sbembed.com', 'tusfiles.com', 'streamtape.com', 'asianclub.tv', 'dood.wf', 'letsupload.io', 'un-block-voe.net', 'watchsb.com', 'streamingcommunity.vip', 'voeunblock6.com', 'tusfiles.net', 'file.fm', 'play44.net', 'streamsb.net', 'byzoo.org', 'upstream.to', 'streamrapid.ru', 'userscloud.com', 'vtube.to', 'vipss.club', 'vidpiz.xyz', 'myviid.net', 'videa.hu', 'vidembed.me', 'v-o-e-unblock.com', 'xstreamcdn.com', 'streamingcommunity.bar', 'stream.lewd.host', 'myfeminist.com', 'dembed2.com', 'voe-unblock.com', 'tubitv.com', 'filemoon.to', 'vidbm.com', 'vidoza.net', 'voeunblock1.com', 'youdbox.net', 'gamovideo.com', 'p1ayerjavseen.com', 'fastplay.cc', 'cloudvideo.tv', 'voeunblock5.com', 'fastplay.sx', 'sbplay2.xyz', 'vadshar.com', 'doodstream.com', 'youvideos.ru', 'googledrive.com', 'sbspeed.com', 'housecardsummerbutton.com', 'vidsrc.xyz', 'vk.com', 'hxfile.co', 'letsupload.org', 'videozoo.me', 'voeunblock2.com', 'easyvideo.me', 'hdvid.tv', 'pixeldrain.com', 'embedojo.com', 'voe-unblock.net', 'sbthe.com', 'videowood.tv', 'myupload.co', 'gcloud.live', 'streamingcommunity.cc', 'streamlare.com', 'doodstream.co', 'turboviplay.com', 'vidshare.com', 'youdbox.org', 'streamz.vg', 'cloudemb.com', 'files.im', 'streamtape.cc', 'strcloud.link', 'votrefiles.club', 'odnoklassniki.ru', 'vanfem.com', 'streamhub.to', 'evoload.io', 'pandafiles.com', 'videooo.news', 'ebd.cda.pl', 'ok.ru', 'rovideo.net', 'googlevideo.com', 'videos.sapo.pt', 'votrefilms.xyz', 'emturbovid.com', 'mixdrop.bz', 'streamingcommunity.bond', 'vidnode.net', 'voeunblock4.com', 'vidflare.net', 'vidmovie.xyz', 'ezsubz.com', 'drive.google.com', 'player.vimeo.com', 'vidshar.org', 'example.com', 'zidiplay.com', 'voeunblck.com', 'gomoplayer.com', 'videoloca.xyz', 'vtplay.net', 'vedbom.com', 'vidmojo.net', 'filerio.in', 'streamoupload.com', 'albavido.xyz', 'vidbom.com', 'superembeds.com', 'lbry.science', 'filmvi.xyz', 'streamm4u.club', 'newtube.app', 'makaveli.xyz', 'launchreliantcleaverriver.com', 'm.cda.pl', 'm.my.mail.ru', 'fembed9hd.com', 'eplayvid.net', 'playwire.com', 'mixdrop.ch', 'vidcloud.is', 'slmaxed.com', 'moviepl.xyz', 'adultswim.com', 'speedostream.com', 'vidembed.cc', 'mixdrop.co', 'uploadbaz.me', 'facebook.com', 'vidhdthe.online', 'youtube-nocookie.com', 'vidcloud.co', 'fittingcentermondaysunday.com', 'videakid.hu', 'sbfast.com', 'tezfiles.com', 'megogo.net', 'yucache.net', 'vidsource.me', 'streamingcommunity.host', 'veoh.com', 'shavetape.cash', 'redload.co', 'vupload.com', 'googleusercontent.com', 'streamzz.to', 'vizcloud.cloud', 'tnaket.xyz', 'myviid.com', 'vidmx.xyz', 'streamingcommunity.agency', 'gofile.io', 'diampokusy.com', 'downace.com', 'dailymotion.com', 'uploadraja.com', 'filepup.net', 'streamani.net', 'fastplay.to', 'theinfowar.tv', 'hexupload.net', 'scloud.online', 'gogo-play.net', 'peertube.co.uk', 'vidfast.co', 'videoapne.co', 'dood.ws', 'publish2.me', 'embedo.co', 'streamingcommunity.icu', 'streamoupload.xyz', 'vido.lol', 'vudeo.net', 'streamingcommunity.name', 'videoseyred.in', 'videovard.to', 'vidoza.co', 'vidmoly.net', 'highload.to', 'fembed-hd.com', 'streamingcommunity.website', 'send.cm', 'dailyplanet.pw', 'get.google.com', 'embedsito.com', 'holavid.com', 'vedshar.com', 'sltube.org', 'strtape.cloud', 'anonfiles.com', 'wolfstream.tv', 'cloudb.me', 'cda.pl', 'votrefile.xyz', 'xvideosharing.com', 'there.to', 'i18n.pw', 'strtpe.link', 'vidmoly.to', 'vidcloud9.com', 'avideo.host', 'playhd.one', 'voeun-block.net', 'vkprime.com', 'vidzstore.com', 'streamingcommunity.work', 'zplayer.live', 'peertube.tv', 'sbfull.com', 'sibnet.ru', 'mrdhan.com', 'bitchute.com', 'mediashore.org', 'neohd.xyz', 'streamsss.net', 'mightyupload.com', 'fastdrive.io', 'videowing.me', 'battleplan.news', 'youtube.googleapis.com', 'vcdnplay.com', 'ssbstream.net', 'streamingcommunity.best', 'streamta.pe', 'vidembed.net', 'chromecast.video', 'sbplay.one', 'amazon.com', 'anime789.com', 'files.fm', 'brighteon.com', 'dutrag.com', 'streamvid.co', 'japopav.tv', 'voeunblock7.com', 'fraudclatterflyingcar.com', 'speedwatch.us', 'cinegrabber.com', 'vedbom.org', 'entervideo.net', 'filemoon.sx', 'embedsb.com', 'gamatotv.site', 'audaciousdefaulthouse.com', 'voeunblock3.com', 'suzihaza.com', 'fembed.net', 'racaty.net', 'voeunbl0ck.com', 'ani-stream.com', 'videobin.co', 'streamingcommunity.press', 'k2s.cc', 'streamingcommunity.top', 'diasfem.com', 'sendit.cloud', 'fembed.com', 'rumble.com', 'voe.sx', 'rabbitstream.net', 'streamingcommunity.fun', 'mycloud.to', 'sharinglink.club', 'jplayer.net', 'tubeload.co', 'sruby.xyz', 'membed.net', 'voeunblk.com', 'sbvideo.net', 'cos.tv', 'banned.video', 'vidmoly.me', 'streamingcommunity.live', 'streamz.cc', 'vidcloud.fun', 'uploadingsite.com', 'mail.ru', 'streamingcommunity.business', 'peertube.uno', 'cloudb2.me', 'megaup.net', 'solidfiles.com', 'tvlogy.to', 'aparat.cam', 'voeunblock9.com', 'streamingcommunity.org', 'mp4upload.com', 'www.cda.pl', 'sbplay1.com', 'liivideo.com', 'superitu.com', 'reeoov.tube', 'streamingcommunity.monster', 'vimeo.com', 'tunestream.net', 'dood.pm', 'vcdn.io', 'vidorg.net', 'superplayxyz.club', 'playbb.me', 'disk.yandex.com', 'bayfiles.com', 'myvid.com', 'fcdn.stream', 'uploadever.in', 'sexhd.co', 'saruch.co', 'electionnight.news', 'streamingcommunity.art', 'playpanda.net', 'vidbob.com', 'mvidoo.com', 'liiivideo.com', 'vidbam.org', 'cloud.mail.ru', 'dood.to', 'video44.net', 'supervideo.tv', 'pkspeed.net', 'stape.fun', 'femoload.xyz', 'blogger.com', 'streamingcommunity.one', 'futurenews.news', 'uqload.com', 'indavideo.hu', 'javstream.top', 'odysee.com', 'hdvid.website', 'yourupload.com', 'vidbem.com', 'vidembed.io', 'feurl.com', 'disk.yandex.ru', 'vkspeed.com', 'api.video.mail.ru', 'viplayer.cc', 'dood.cx', 'streamadblockplus.com', 'castamp.com', 'youtube.com', 'yodbox.com', 'daxab.com', 'sbplay2.com', 'javpoll.com', 'femax20.com', 'vedsharr.com', 'videoslala.com', 'videovard.sx', 'videoapi.my.mail.ru', 'sbplay.org', 'voeunblock.com', 'docs.google.com', 'viewsb.com', 'madiator.com', 'dood.sh', 'hdvid.fun', 'dai.ly', 'itemfix.com', 'streamtape.site', 'streamingcommunity.tv', 'streamable.com', 'aliez.me', 'uploadflix.org', 'uploadever.com']
                # self._process_internal_results()
                s4k_label, s1080_label = 5, 10
                s720_label, ssd_label, stotal_label = 7, 10, 25
                try:
                    current_time = time.time()
                    current_progress = current_time - start_time
                    line2 = dialog_format % ('dodgerblue', 'Int:', s4k_label, s1080_label, s720_label, ssd_label, stotal_label)
                    line3 = remaining_format % ', '.join(remaining_providers).upper()
                    percent = int((current_progress/float(timeout))*100)
                    progress_dialog.update(main_line % (line1, line2, line3), percent)
                    kodi_utils.sleep(10)
                    # if len(remaining_providers) == 0: break
                    # if percent >= 100: 
                        # progress_dialog.close()
                        # break
                except: 
                    logger(f'error: {traceback.format_exc()}')
                    progress_dialog.close()
            except: 
                logger(f'error: {traceback.format_exc()}')
                progress_dialog.close()
        # progress_dialog.close()

    elif win == 'select_ok_win': # windows.select_ok <<<<<<<<<<<<
        from modules.kodi_utils import local_string, confirm_dialog, ok_dialog
        confirm_dialog(heading='Infinite', text=local_string(32855), ok_label=local_string(32824), cancel_label=local_string(32828), top_space=True)
        ok_dialog(heading='Infinite', text=local_string(32855))

def cache_test():
    ctime = datetime.datetime.now()
    current_time = int(time.mktime(ctime.timetuple()))
    clean_databases(current_time, database_check=False, silent=True)
    from modules.source_utils import sources
    providers = sources('true', 'episode')
    from indexers.hindi.lists import youtube_m3u
    youtube_m3u()
    from caches.h_cache import MainCache
    MainCache().clean_hindi_lists()
    logger(providers)
    from caches import clrCache_version_update
    clrCache_version_update(clr_cache=True, clr_navigator=False)
    from apis.trakt_api import trakt_sync_activities
    status = trakt_sync_activities()
    logger(f'status: {status}')


def dl_db_file():
    params = {
    'mode': 'downloader',
    'action': 'cloud_file',
    'name': 'metacache_test',
    'url': 'https://github.com/djp11r/repojp/blob/master/etc/allxml/metacache.db?raw=true',
    'media_type': 'file'}
    from modules.downloader import runner
    runner(params)