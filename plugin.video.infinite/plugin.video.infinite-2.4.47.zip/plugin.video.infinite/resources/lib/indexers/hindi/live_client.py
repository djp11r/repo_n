# -*- coding: utf-8 -*-

import os
import re
import sys
import traceback
from string import printable

from modules.kodi_utils import translate_path, logger, addon_fanart, addon_icon

# joinPath = os.path.join
# addon_dir = translate_path('special://home/addons/plugin.video.infinite')
# hindi_dir = joinPath(addon_dir, "resources", "lib", "indexers", "hindi")

from openscrapers.modules.client import r_request, agent, request

def unescape(text):
    text = text.replace('&amp;',  '&').replace('&Amp;', '&').replace('&#038;', '&')
    text = text.replace('&quot;', '"').replace('&#8220;', '"').replace('&#8221;', '"').replace('\\x80\\x9c', '"').replace('\\x80\\x9d', '"')
    text = text.replace('\\x80\\x89', "")
    text = text.replace('&apos;', "'").replace("\\'", "'").replace("&#39;'", "'")
    text = text.replace('&#8216;', "'").replace('&#8217;', "'").replace('\\x80\\x99', "'").replace('\\x80\\x98', "'")
    text = text.replace('&#8230;', ' ') # '...'
    text = text.replace('&#8211;', '').replace('&#8212;', '').replace('&nbsp;', '').replace('\\u2013', '').replace('\\u2009', '').replace('\\u2009', '')
    text = text.replace('&gt;',   '>').replace('&lt;',   '<')
    text = text.replace('\\n', '\n')
    text = text.replace('\\x80\\x93', '-').replace('\\x89', '').replace('\\x8e', '').replace('\\xa', 'a')
    text = text.replace('&raquo;', '').replace('&#187;', '')
    text = text.replace('<span class="st">', '').replace('</span>', '')
    # text = text.encode('ascii', 'ignore').decode('unicode_escape').strip()
    return text.strip()


exctract_date = re.compile(r'(\d{1,2}[th|st|nd|rd]* [Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|August|Sep|September|Oct|October|Nov|November|Dec|December]* \d{2,4})')
# exctract_date = re.compile(r'(?:\d{1,2}[-/th|st|nd|rd\s]*)?(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)?[a-z\s,.]*(?:\d{1,2}[-/th|st|nd|rd)\s,]*)+(?:\d{2,4})+')
exctract_episod = re.compile(r'Episode \d{1,2}')
# month_comp = re.compile(r'[Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|August|Sep|September|Oct|October|Nov|November|Dec|December]')


def get_episode_date(text, title=''):
    name = unescape(text)
    # logger(f"ep_name In: {name}")
    episode_name = xname = ''
    if 'watch online' in name.lower():
        xname = name.replace(title, '').replace('Watch Online', '').replace('-', '').replace('  ', ' ')
    try:
        episode_name = exctract_date.findall(xname)[0]
        episode_name = re.sub(r"(\w)([A-Z])", r"\1 \2", episode_name)
    except:
        episode_name = exctract_episod.findall(xname)
    if type(episode_name) is list:
        try:
            episode_name = episode_name[0]
            episode_name = episode_name
        except: episode_name = ''
    if episode_name == '' and 'watch online' in name.lower():
        episode_name = name.replace(title, '').replace('Watch Online', '').replace('-', '').replace('  ', ' ')
        episode_name = re.sub(r"(\w)([A-Z])", r"\1 \2", episode_name)
        # logger(f'{episode_name}')
    # logger(f"ep_name Out: {episode_name}")
    # episode_name = episode_name.title()
    return episode_name.strip()


monthdict = {
    'January': '01',
    'February': '02',
    'March': '03',
    'April': '04',
    'May': '05',
    'June': '06',
    'July': '07',
    'August': '08',
    'September': '09',
    'October': '10',
    'November': '11',
    'December': '12'}


def get_int_epi(episode):
    episode_int = re.search(r'(\d{1,2}(st|nd|rd|th))(.*?)(\d{2,4})', episode)
    if episode_int:
        episode_int = episode_int.group()
        month = monthdict.get(episode_int.split(' ')[1])
        try:
            d = re.search(r'^\d+(st|nd|rd|th)', episode).group()
            day = re.sub(r"(st|nd|rd|th)", "", d)
            day = day.rjust(2, '0')
            # day = re.search(r'\d{2}', episode).group()
            year = re.search(r'\d{4}$', episode).group()
        except:
            day = '0'
            year = '0'
        if month is None: season = day
        else: season = f'{month}{day}'
        # logger(f'{season}, {year}')
        return season, year
    else:
        epis_no = re.search(r'\d{1,2}', episode)
        if epis_no: epis_no = epis_no.group()
        else: epis_no = 0
        # logger(f'day: {epis_no}')
        return epis_no, 0


def find_season_in_title(release_title):
    match = 1
    release_title = re.sub(r'\d{4}', '', release_title)  # remove year from title
    regex_list = [r'.+?(\d{1,2})', r'[sS]eason.+?(\d+)', r'[sS]eason(\d+)', r'[sS](\d+)', r'[cC]hapter.+?(\d+)']
    for item in regex_list:
        try:
            match = re.search(item, release_title)
            if match:
                match = int(str(match.group(1)).lstrip('0'))
                break
            else: match = 1
            # logger(f'not match: {item}')
        except: pass
    return match


def string_date_to_num(string):
    # logger(f'string: {string} ')
    # date_str = re.search(r'(\d{1,2}(st|nd|rd|th))(.*?)(\d{2,4})', string).group()
    date_str = re.search(exctract_date, string)
    # logger(f'date_str: {date_str}')
    if date_str:
        date_str = date_str.group()
        month = monthdict.get(date_str.split(' ')[1])
        d = re.search('^\d+(st|nd|rd|th)', date_str).group()
        day = re.sub("(st|nd|rd|th)", "", d)
        year = re.search('\d{4}$', date_str).group()
        date = f"{year}-{month:0>2}-{day:0>2}"
        # logger(f'date: {date}')
        return date
    else: return "2022-01-01"


def clean_title(title):
    cleanup = ['Watch', 'Online', 'Movie', 'Full', 'Hit', 'Telly', 'TombDoc',
               'Hindi', 'Thriller', 'Comedy', 'Super', 'Film', 'HD', '720p',
               '1080', '1080p', 'Free', 'Super', 'Complete', 'HDRip', 'Classic',
               'Old', 'Historical', 'ESubs', 'ESub', 'ExtraMovies', 'MoviePirate',
               'WebRip', 'www.','TamilRockers.ws', 'Torrenting.org', 'HEVC',
               'BD', 'SUBS', 'Multi-', 'Pirate', 'uploads', 'DVDrip', 'NTSC',
               'WEB-DL', 'romantic',
               '..', '...', '{', '}', '[', ']', '[.', ' -', '/',
               '+-+-', '| ', ' |', '-.', '.-.',  '(', ')', '~']

    title = title.lower()
    for word in cleanup:
        word = word.lower()
        # logger(f'cling word: {word} title :{title}')
        if word in title: title = title.replace(word, '')
    title = title.replace('&quot;', '').replace('&amp;', '&').replace('&apos;', "'")
    # title = title.encode('utf8')
    return title.strip()


def keepclean_title(title):
    if title is None: return
    episode_data = re.compile(r'[Ee]pisodes.+?(\d+)|[Ee]p (\d+)|[Ee](\d+)|[sS]eason.+?(\d+)|[sS]eason(\d+)|[sS](\d+)')
    # ansi_pattern = re.compile(r"(\x9B|\x1B\[)[0-?]*[ -\/]*[@-~]")
    ansi_pattern = re.compile(r'[^\x00-\x7f]')
    try:
        if ':' in title: title = title.split(':')[0]
        title = re.sub(exctract_date, '', title)  # remove date like 18th April 2021
        title = re.sub(episode_data, '', title)  # remove episod 12 or season 1 etc
        title = re.sub(ansi_pattern, '', title)  # remove ansi_pattern
        title = re.sub(r'&#(\d+);', '', title)
        title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
        title = title.replace('&quot;', '\"').replace('&amp;', '&')
        title = re.sub(r'([:;\-"\',!_.?~$@])', '', title)  # remove all characters in bracket
        title = re.sub(r'\<[^>]*\>|\([^>]*\)', '', title) # remove like this <any thing> or (any thing)
        # title = re.sub(r'\([^>]*\)', '', title)  # remove in bracket like (any thing) etc
        # title = re.sub(r'\n|([[].+?[]])|([(].+?[)])|\s(vs|v[.])\s|(:|;|-|"|,|\'|\_|\.|\?)|\(|\)|\[|\]|\{|\}|\s', '', title).lower()
        # title = re.sub(r'\n|([\[({].+?[})\]])|([:;\-"\',!_.?~$@])|\s', '', title)
        return title.strip()
    except: return title


def multiple_replace(dict, text):
    """

    :type dict: object
    dict = {
        "&amp;": "&",
        "&quot;": '"',
        "&apos;": "\'",
        "&#8217;": "\'",
        "&#8211;": "",
        "&gt;": ">",
        "&lt;": "<", }
    """
    # Create a regular expression  from the dictionary keys
    regex = re.compile("(%s)" % "|".join(map(re.escape, dict.keys())))
    # For each match, look-up corresponding value in dictionary
    return regex.sub(lambda mo: dict[mo.string[mo.start():mo.end()]], text)


def wrigtht_json(file_path, data):
    # file_path = translate_path(file_path)
    with open(file_path, mode='w', encoding='utf-8') as f:
        f.write(data)


# def get_json_file(h_addon_dir, ch_name):
#     """ h_addon_dir: path
#         ch_name : file name
#         return plain data to load in json & json_file path
#     """
#     filename = f"{ch_name.lower()}.json"
#     json_file = joinPath(h_addon_dir, "resources", "lib", "indexers", "hindi", "list_data", filename)
#     try:
#         try:
#             with open(json_file, 'r', encoding='utf8') as f:
#                 page = f.read()
#         except:
#             with open(json_file, 'rb') as f:
#                 page = f.read().decode(errors='ignore')
#         # jdata = json.loads(page)
#         return page, json_file
#     except IOError: return "", json_file


def keep_readable(text):
    text = text.replace('&#8216;', "'")
    text = text.replace('&#8217;', "'")
    text = text.replace('&#8220;', '"')
    text = text.replace('&#8221;', '"')
    text = text.replace('&#8211;', ' ')
    text = text.replace('&#8230;', ' ')
    text = text.replace("&amp;", "&")
    text = text.replace("-", "")
    # text = text.encode('ascii', 'ignore').decode('unicode_escape').strip()
    return text


def strip_non_ascii_and_unprintable(text):
    try:
        result = ''.join(char for char in text if char in printable)
        return result.encode('ascii', errors='ignore').decode('ascii', errors='ignore')
    except: return str(text)


def stringify_nodes(data):
    if isinstance(data, list): return [stringify_nodes(x) for x in data]
    elif isinstance(data, dict):
        dkeys = list(data.keys())
        for i, k in enumerate(dkeys):
            try: dkeys[i] = k.decode()
            except: pass
        data = dict(zip(dkeys, list(data.values())))
        return {stringify_nodes(key): stringify_nodes(val) for key, val in data.items()}
    elif isinstance(data, bytes):
        try: return data.decode()
        except: return data
    else: return data


def getcontent(crawl_response):
    #logger(crawl_response.getheaders())
    content = crawl_response.content

    encoding = crawl_response.headers.get("Content-Encoding")
    # response.headers.get('Content-Encoding') == "deflate":
    #charest and content_type
    # message = crawl_response.info()
    content_type = crawl_response.headers.get("Content-Type")
    if content_type != 'text/html': pass

    if not encoding: pass
    else:
        # Decompress
        try:
            if encoding == 'gzip':
                import gzip
                content = gzip.decompress(content)
        except Exception as e: logger(f"Error: decompress: {e}")

    #charset
    charset = None
    charset = crawl_response.headers.get("charset")

    if not charset:
        charset = crawl_response.headers.get("charset")
        if not charset:
            import chardet
            result = chardet.detect(content)
            charset = result['encoding']
        else: charset = charset[0]
    if not charset:  charset = 'utf-8' # default set utf-8
    # logger(f"charset: {charset}")

    # if charset != 'utf-8':  content = content.encode('utf-8', errors = 'ignore').decode("utf-8")# convert utf-8
    # else: content = content.decode(charset, errors = 'ignore').encode('utf-8', errors = 'ignore')
    # content = content.decode('iso-8859-1')
    # # content = content.decode("utf-8")
    # content = content.replace('\n', '').replace('\t', '').replace('\r', '')
    # # OR
    # content = replace_html_codes(content)
    return content


def read_write_file(file_n='test.html', read=True, result=''):
    """
    :useged:
    from openscrapers.modules.hindi_sources import read_write_file
    read_write_file('test_%s.html' % hdlr, read=False, result=r)
    :param file_n:
    :param read:
    :param result:
    :return:

    """
    if read:
        with open(file_n, mode='r', encoding='utf-8', errors='ignore') as f:
            result = f.read()
        return result
    else:
        try:
            result = result.replace('\n', ' ').replace('\t', '').replace('&nbsp;', '').replace('&#8211;', '')
            with open(file_n, mode='w', encoding='utf-8') as f:
                f.write(result)
        except: logger(f'error: {traceback.print_exc()}')


def convert_time_str_to_seconds(timestr):
    # pattern = r'\d{1,2}:\d{2}:\d{2}'
    # logger(re.findall(pattern, timestr))
    if re.findall(r'\d{1,2}:\d{2}:\d{2}', timestr): timestr = timestr
    elif re.findall(r'\d{2}:\d{2}', timestr): timestr = f"00:{timestr}"
    ftr = [3600, 60, 1]
    seconds = sum([a*b for a, b in zip(ftr, map(int, timestr.split(':')))])
    return seconds


def removeNonAscii(s):
    return "".join(filter(lambda x: ord(x) < 128, s))


def string_escape(s, encoding='utf-8'):
    return s.encode('latin1', 'backslashreplace').decode('unicode-escape')
    # return (s.encode('latin1')         # To bytes, required by 'unicode-escape'
    #          .decode('unicode-escape') # Perform the actual octal-escaping decode
    #          .encode('latin1')         # 1:1 mapping back to bytes
    #          .decode(encoding))        # Decode original encoding


def get_by_id(dict_list, expid=False):
    """
    :param dict_list:
    :param expid:
    :return: dict list with key service is False
    """
    filter_list = [item for item in dict_list if item['service'] == expid] # all items which macht condition
    # filter_list = next(x for x in vals if x['service'] == expid) # fist mathc of condition
    return filter_list


def _get_timefrom_timestamp(timestamp):
    from datetime import datetime
    return datetime.utcfromtimestamp(timestamp)
