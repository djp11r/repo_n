# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcvfs, xbmcaddon
from os import path as osPath, walk
from urllib.parse import urlencode, unquote
from modules import icons
from traceback import print_exc, format_stack

from xbmc import Monitor, Player, executeJSONRPC, executebuiltin, getSupportedMedia, PlayList, getSkinDir, log
from xbmcvfs import File, exists, copy, delete, rmdir, rename, listdir, mkdir, mkdirs
from xbmcgui import WindowXMLDialog, ListItem, getCurrentWindowId, Window, DialogProgressBG
from xbmcplugin import setResolvedUrl, setPluginCategory, endOfDirectory, addSortMethod, addDirectoryItem, addDirectoryItems, setContent

xbmc_player, xbmc_monitor = Player, Monitor
execute_JSON, window_xml_dialog = executeJSONRPC, WindowXMLDialog
xbmc_sleep = xbmc.sleep
progressDialogBG = DialogProgressBG
setCategory, resolve = setPluginCategory, setResolvedUrl

opensettings_params = {'mode': 'open_settings', 'query': '0.0'}
path_join = osPath.join
img_url = 'https://i.imgur.com/%s.png'
invoker_switch_dict = {'true': 'false', 'false': 'true'}
empty_poster, nextpage = img_url % icons.box_office, img_url % icons.nextpage
nextpage_landscape = img_url % icons.nextpage_landscape
item_jump_landscape = img_url % icons.item_jump_landscape
tmdb_default_api = 'b370b60447737762ca38457bd77579b3'
trakt_default_id = '1038ef327e86e7f6d39d80d2eb5479bff66dd8394e813c5e0e387af0f84d89fb'
trakt_default_secret = '8d27a92e1d17334dae4a0590083a4f26401cb8f721f477a79fd3f218f8534fd1'

sort_method_dict = {'episodes': 24, 'files': 5, 'label': 2, 'none': 0}
playlist_type_dict = {'music': 0, 'video': 1}

single_ep_list = ('episode.progress', 'episode.recently_watched', 'episode.next_trakt', 'episode.next_infinite', 'episode.trakt_recently_aired', 'episode.trakt_calendar')
scraper_names = ['EXTERNAL SCRAPERS' 'FOLDERS 1-5']


def random_valid_type_check():
	return {'build_movie_list': 'movie', 'build_tvshow_list': 'tvshow', 'build_season_list': 'season', 'build_episode_list': 'episode',
	'build_in_progress_episode': 'single_episode', 'build_recently_watched_episode': 'single_episode', 'build_next_episode': 'single_episode',
	'build_my_calendar': 'single_episode', 'build_trakt_lists': 'trakt_list',
	'trakt.list.build_trakt_list': 'trakt_list', 'build_trakt_lists_contents': 'trakt_list', 'personal_lists.build_personal_list': 'personal_list',
	'build_personal_lists_contents': 'personal_list', 'tmdblist.build_tmdb_list': 'tmdb_list', 'build_tmdb_lists_contents': 'tmdb_list'}

def random_episodes_check():
	return {'build_in_progress_episode': 'episode.progress', 'build_recently_watched_episode': 'episode.recently_watched',
	'build_next_episode': 'episode.next', 'build_my_calendar': 'episode.trakt'}

def extras_button_label_values():
	return {'movie':
				{'movies_play': 'Playback', 'show_trailers': 'Trailer', 'show_images': 'Images',  'show_extrainfo': 'Extra Info', 'show_genres': 'Genres',
				'show_director': 'Director', 'show_options': 'Options', 'show_recommended': 'Recommended', 'show_more_like_this': 'More Like This',
				'show_trakt_manager': 'Trakt Lists', 'show_personallists_manager': 'Personal Lists', 'show_tmdb_manager': 'TMDb Lists', 'show_favorites_manager': 'Favorites Lists',
				'playback_choice': 'Playback Options', 'show_plot': 'Plot', 'show_keywords': 'Keywords', 'show_in_trakt_lists': 'In Trakt Lists', 'close_all': 'Close All Dialogs'},
			'tvshow':
				{'tvshow_browse': 'Browse', 'show_trailers': 'Trailer', 'show_images': 'Images', 'show_extrainfo': 'Extra Info', 'show_genres': 'Genres',
				'play_nextep': 'Play Next', 'show_options': 'Options', 'show_recommended': 'Recommended', 'show_more_like_this': 'More Like This',
				'show_trakt_manager': 'Trakt Lists', 'show_personallists_manager': 'Personal Lists', 'show_tmdb_manager': 'TMDb Lists', 'show_favorites_manager': 'Favorites Lists',
				'play_random_episode': 'Play Random', 'show_plot': 'Plot', 'show_keywords': 'Keywords', 'show_in_trakt_lists': 'In Trakt Lists', 'close_all': 'Close All Dialogs'}}

def extras_items():
	return ('Plot', 'Cast', 'Recommended', 'Related', 'More Like This', 'Similar', 'Reviews', 'Comments', 'Trivia', 'Blunders', 'Parental Guide', 'In Trakt Lists', 'Videos',
			'More from Year', 'More from Genres', 'More from Networks', 'More from Collection')

def context_menu_items():
	return {'select': 'Select Source', 'rescrape': 'Rescrape & Select Source', 'browse': 'Browse', 'extras': 'Extras', 'options': 'Options', 'playback_options': 'Play Options', 'browse_movie_set': 'Browse Movie Set', 'browse_seasons': 'Browse TV Seasons',
			'browse_episodes': 'Browse Season Episodes', 'recommended': 'Browse Recommended', 'related': 'Browse Related', 'more_like_this': 'Browse More Like This',
			'similar': 'Browse Similar', 'in_trakt_list': 'In Trakt Lists', 'trakt_manager':'Trakt Lists Manager', 'personal_manager': 'Personal Lists Manager',
			'tmdb_manager': 'TMDb Lists Manager', 'favorites_manager': 'Favorites Manager', 'mark_watched': 'Mark Watched/Unwatched',
			'unmark_previous_episode': 'Unmark Previous Watched Episode', 'exit': 'Exit List', 'refresh': 'Refresh Widgets', 'reload': 'Reload Widgets'}

def video_extensions():
	return ('m4v', '3g2', '3gp', 'nsv', 'tp', 'ts', 'ty', 'pls', 'rm', 'rmvb', 'mpd', 'ifo', 'mov', 'qt', 'divx', 'xvid', 'bivx', 'vob', 'nrg', 'img', 'iso', 'udf', 'pva',
			'wmv', 'asf', 'asx', 'ogm', 'm2v', 'avi', 'bin', 'dat', 'mpg', 'mpeg', 'mp4', 'mkv', 'mk3d', 'avc', 'vp3', 'svq3', 'nuv', 'viv', 'dv', 'fli', 'flv', 'wpl',
			'xspf', 'vdr', 'dvr-ms', 'xsp', 'mts', 'm2t', 'm2ts', 'evo', 'ogv', 'sdp', 'avs', 'rec', 'url', 'pxml', 'vc1', 'h264', 'rcv', 'rss', 'mpls', 'mpl', 'webm',
			'bdmv', 'bdm', 'wtv', 'trp', 'f4v', 'pvr', 'disc')

def image_extensions():
	return ('jpg', 'jpeg', 'jpe', 'jif', 'jfif', 'jfi', 'bmp', 'dib', 'png', 'gif', 'webp', 'tiff', 'tif',
			'psd', 'raw', 'arw', 'cr2', 'nrw', 'k25', 'jp2', 'j2k', 'jpf', 'jpx', 'jpm', 'mj2')

def kodi_progress_background():
	return xbmcgui.DialogProgressBG()

def get_visibility(obj):
	return xbmc.getCondVisibility(obj)

def get_infolabel(label):
	return xbmc.getInfoLabel(label)

def kodi_actor():
	return xbmc.Actor

def translate_path(_path):
	return xbmcvfs.translatePath(_path)

def kodi_monitor():
	return xbmc.Monitor()

def kodi_dialog():
	return xbmcgui.Dialog()

def addon_info(info):
	return xbmcaddon.Addon('plugin.video.infinite').getAddonInfo(info)

def addon_version():
	return get_property('infinite.addon_version') or addon_info('version')

def addon_path():
	return get_property('infinite.addon_path') or addon_info('path')

def addon_profile():
	return get_property('infinite.addon_profile') or translate_path(addon_info('profile'))

def addon_icon():
	return get_property('infinite.addon_icon') or addon_info('icon')

def addon_fanart():
	return get_property('infinite.addon_fanart') or addon_info('fanart')

def get_icon(image_name, image_folder='icons'):
	try: return img_url % getattr(icons, image_name)
	except: return 'https://raw.githubusercontent.com/%s/%s/main/packages/media/%s/%s.png' % (get_property('infinite.update.username'), get_property('infinite.update.location'), image_folder, image_name)

def get_addon_fanart():
	return get_property('infinite.default_addon_fanart') or addon_fanart()

def build_url(url_params):
	return f'plugin://plugin.video.infinite/?{urlencode(url_params)}'

def add_dir(handle, url_params, list_name, icon_image='folder', fanart_image=None, isFolder=True):
	fanart = fanart_image or get_addon_fanart()
	icon = get_icon(icon_image)
	url = build_url(url_params)
	listitem = make_listitem()
	listitem.setLabel(list_name)
	listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': fanart, 'banner': fanart})
	info_tag = listitem.getVideoInfoTag(True)
	info_tag.setPlot(' ')
	add_item(handle, url, listitem, isFolder)

def make_listitem():
	return ListItem(offscreen=True)

def add_item(handle, url, listitem, isFolder):
	addDirectoryItem(handle, url, listitem, isFolder)

def add_items(handle, item_list):
	addDirectoryItems(handle, item_list)

def set_content(handle, content):
	setContent(handle, content)

def set_category(handle, label):
	setCategory(handle, label)

def end_directory(handle, cacheToDisc=True):
	endOfDirectory(handle, cacheToDisc=cacheToDisc)

def set_view_mode(view_type, content='files', is_external=None):
	if not get_property('infinite.use_viewtypes') == 'true': return
	if is_external is None: is_external = external()
	if is_external: return
	view_id = get_property('infinite.%s' % view_type) or None
	if not view_id: return
	try:
		hold = 0
		sleep(100)
		while not container_content() == content:
			hold += 1
			if hold < 3000: sleep(1)
			else: return
		execute_builtin('Container.SetViewMode(%s)' % view_id)
	except: return

def random_integer(start=1, end=1000000):
	from random import randint
	return randint(start, end)

def remove_keys(dict_item, dict_removals):
	for k in dict_removals: dict_item.pop(k, None)
	return dict_item

def append_path(_path):
	import sys
	sys.path.append(translate_path(_path))

def logger(heading, function=''):
	log(f'###Infinite###: {heading} {function}', 1)

def kodi_window():
	return Window(10000)

def get_property(prop):
	return kodi_window().getProperty(prop)

def set_property(prop, value):
	return kodi_window().setProperty(prop, value)

def clear_property(prop):
	return kodi_window().clearProperty(prop)

def clear_all_properties():
	return kodi_window().clearProperties()

def addon(addon_id='plugin.video.infinite'):
	return xbmcaddon.Addon(id=addon_id)

def addon_installed(addon_id):
	return get_visibility(f'System.HasAddon({addon_id})')

def addon_enabled(addon_id):
	return get_visibility(f'System.AddonIsEnabled({addon_id})')

def container_content():
	return get_infolabel('Container.Content')

def set_sort_method(handle, method):
	addSortMethod(handle, sort_method_dict[method])

def make_session(url='https://'):
	import requests
	from requests.adapters import HTTPAdapter, Retry
	session = requests.Session()
	retries = Retry(total=2, status=1, backoff_factor=1, status_forcelist=(429, 502, 503, 504))
	session.mount(url, HTTPAdapter(max_retries=retries, pool_maxsize=100))
	return session

def make_playlist(playlist_type='video'):
	return PlayList(playlist_type_dict[playlist_type])

def supported_media():
	return getSupportedMedia('video')

def path_exists(path):
	return exists(str(path))

def open_file(_file, mode='r'):
	return File(_file, mode)

def copy_file(source, destination):
	return copy(source, destination)

def delete_file(_file):
	try: delete(_file)
	except Exception as e:
		logger(f'delete_file error: {repr(e)}')
		from os import unlink, remove
		try:
			unlink(_file)
			remove(_file)
		except Exception as e: logger(f'2 delete_file error: {repr(e)}')

def delete_folder(_folder, force=False):
	rmdir(_folder, force)

def rename_file(old, new):
	rename(old, new)

def list_dirs(location):
	return listdir(location)

def make_directory(path):
	mkdir(path)

def make_directories(path):
	mkdirs(path)

def sleep(time):
	return xbmc_sleep(time)

def execute_builtin(command, block=False):
	return executebuiltin(command, block)

def current_skin():
	return getSkinDir()

def get_window_id():
	return getCurrentWindowId()

def current_window_object():
	return Window(get_window_id())

def kodi_version():
	return int(get_infolabel('System.BuildVersion')[0:2])

def get_video_database_path():
	return find_new_db('MyVideos')[0]

def show_busy_dialog():
	return execute_builtin('ActivateWindow(busydialognocancel)')

def hide_busy_dialog():
	execute_builtin('Dialog.Close(busydialognocancel)')
	execute_builtin('Dialog.Close(busydialog)')

def close_dialog(dialog, block=False):
	execute_builtin(f'Dialog.Close({dialog},true)', block)

def close_all_dialog():
	execute_builtin('Dialog.Close(all,true)')

def run_addon(addon='plugin.video.infinite', block=False):
	return execute_builtin(f'RunAddon({addon})', block)

def external():
	return 'infinite' not in get_infolabel('Container.PluginName')

def home():
	return getCurrentWindowId() == 10000

def folder_path():
	return get_infolabel('Container.FolderPath')

def path_check(string):
	return string in unquote(folder_path())

def reload_skin():
	execute_builtin('ReloadSkin()')

def kodi_refresh():
	execute_builtin('UpdateLibrary(video,special://skin/foo)')

def refresh_widgets():
	from caches.settings_cache import get_setting
	from caches.random_widgets_cache import RandomWidgets
	RandomWidgets().delete_like('random_list.%')
	kodi_refresh()
	if get_setting('infinite.widget_refresh_notification', 'true') == 'true': notification('Widgets Refreshed', 2500)

def run_plugin(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin(f'RunPlugin({params})', block)

def container_update(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin(f'Container.Update({params})', block)

def activate_window(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin(f'ActivateWindow(Videos,{params},return)', block)

def container_refresh():
	return execute_builtin('Container.Refresh')

def container_refresh_input(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin(f'Container.Refresh({params})', block)

def replace_window(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin(f'ReplaceWindow(Videos,{params})', block)

def disable_enable_addon(addon_name='plugin.video.infinite'):
	import json
	try:
		execute_JSON(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled', 'params': {'addonid': addon_name, 'enabled': False}}))
		execute_JSON(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled', 'params': {'addonid': addon_name, 'enabled': True}}))
	except: pass

def update_local_addons():
	execute_builtin('UpdateLocalAddons', True)
	sleep(2500)

def update_kodi_addons_db(addon_name='plugin.video.infinite'):
	import time
	import sqlite3 as database
	try:
		date = time.strftime('%Y-%m-%d %H:%M:%S')
		dbcon = database.connect(find_new_db('Addons')[0], timeout=40.0)
		dbcon.execute("INSERT OR REPLACE INTO installed (addonID, enabled, lastUpdated) VALUES (?, ?, ?)", (addon_name, 1, date))
		dbcon.close()
	except Exception as e: logger(f'error update_kodi_addons_db {str(e)}')

def get_jsonrpc(request):
	import json
	response = execute_JSON(json.dumps(request))
	result = json.loads(response)
	return result.get('result', None)

def jsonrpc_get_directory(directory, properties=['title', 'file', 'thumbnail']):
	command = {'jsonrpc': '2.0', 'id': 1, 'method': 'Files.GetDirectory', 'params': {'directory': directory, 'media': 'files', 'properties': properties}}
	try: results = [i for i in get_jsonrpc(command).get('files') if i['file'].startswith('plugin://') and i['filetype'] == 'directory']
	except: results = None
	return results

def jsonrpc_get_addons(_type, properties=['thumbnail', 'name']):
	command = {'jsonrpc': '2.0', 'method': 'Addons.GetAddons','params':{'type':_type, 'properties': properties}, 'id': '1'}
	results = get_jsonrpc(command).get('addons')
	return results

def jsonrpc_get_system_setting(setting_id, setting_value=''):
	command = {'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.GetSettingValue', 'params': {'setting': setting_id}}
	try: result = get_jsonrpc(command)['value']
	except: result = setting_value
	return result

def open_settings():
	from windows.base_window import open_window
	open_window(('windows.settings_manager', 'SettingsManager'), 'settings_manager.xml')

def external_scraper_settings(params=None):
	try:
		external = get_property('infinite.external_scraper.module')
		if external in ('empty_setting', ''): return
		execute_builtin('Addon.OpenSettings(%s)' % external)
		if params and 'openscrapers' in external:
			force_trakt_update = sync_accounts('infinite retry:')
			sleep(100)
			notification('sync accounts data')
			if force_trakt_update:
				from apis.trakt_api import trakt_sync_activities
				trakt_sync_activities(force_update=True)
			execute_builtin('RunPlugin(plugin://script.module.openscrapers/?action=cleanSettings)')
			sleep(200)
	except: pass

def progress_dialog(heading='Infinite', icon=None):
	from threading import Thread
	from windows.base_window import create_window
	progress_dialog = create_window(('windows.progress', 'Progress'), 'progress.xml', heading=heading, icon=icon or addon_icon())
	Thread(target=progress_dialog.run).start()
	return progress_dialog

def select_dialog(function_list, **kwargs):
	from windows.base_window import open_window
	selection = open_window(('windows.default_dialogs', 'Select'), 'select.xml', **kwargs)
	if selection in (None, []): return selection
	if kwargs.get('multi_choice', 'false') == 'true': return [function_list[i] for i in selection]
	return function_list[selection]

def confirm_dialog(heading='Infinite', text='Are you sure?', ok_label='OK', cancel_label='Cancel', default_control=11):
	from windows.base_window import open_window
	kwargs = {'heading': heading, 'text': text, 'ok_label': ok_label, 'cancel_label': cancel_label, 'default_control': default_control}
	return open_window(('windows.default_dialogs', 'Confirm'), 'confirm.xml', **kwargs)

def ok_dialog(heading='Infinite', text='No Results', ok_label='OK'):
	from windows.base_window import open_window
	kwargs = {'heading': heading, 'text': text, 'ok_label': ok_label}
	return open_window(('windows.default_dialogs', 'OK'), 'ok.xml', **kwargs)

def show_text(heading='Infinite', text=None, file=None, font_size='small', kodi_log=False):
	from windows.base_window import open_window
	heading = heading.replace('[B]', '').replace('[/B]', '')
	if not text:
		if kodi_log:
			confirm = confirm_dialog(text='Show Log Errors Only?', ok_label='Yes', cancel_label='No')
			if confirm is None: return
			if confirm: text = decorate_log_error(file, only_error=True)
			else: text = decorate_log_error(file)
		else:
			with open(file, encoding='utf-8', errors='ignore') as r: text = r.read() #with open(file, encoding='utf-8') as r: text = r.readlines()
	return open_window(('windows.textviewer', 'TextViewer'), 'textviewer.xml', heading=heading, text=text, font_size=font_size)

def notification(line1, time=3000, icon=None, sound=False):
	if 'error' in line1.lower():
		import inspect
		func = inspect.currentframe().f_back
		# allframs = inspect.getouterframes(inspect.currentframe())
		# logger(f'allframs: {allframs}')
		funcat = 'not found'
		if 'plugin.video.infinite' in func.f_code.co_filename:
			funcat = func.f_code.co_filename.split('plugin.video.infinite')[1]
		logger(f'line_number: {func.f_lineno} func name: {func.f_code.co_name} func file: {funcat}\n{"".join(format_stack())}')
	kodi_dialog().notification('Infinite', line1, icon or addon_icon(), time, sound)

def player_check(mode, params):
	from modules.settings import playback_key
	if mode == 'playback.%s' % playback_key():
		from modules.sources import Sources
		Sources().playback_prep(params)
	elif mode == 'playback.video':
		from modules.player import infinitePlayer
		infinitePlayer().run(params.get('url', None), params.get('obj', None))
	else: ok_dialog('External Playback Detected', 'Playback through external addons is not supported')

def external_playback_check(params):
	from modules.settings import playback_key
	if not playback_key() in params:
		ok_dialog('External Playback Detected', 'Playback through external addons is not supported')
		return False
	return True

def timeIt(func):
	import time
	fnc_name = func.__name__
	def wrap(*args, **kwargs):
		started_at = time.perf_counter()
		result = func(*args, **kwargs)
		logger(f'{__name__}.{fnc_name} {time.perf_counter() - started_at}')
		return result
	return wrap

def volume_checker():
	try: # 0% == -60db, 100% == 0db
		if get_property('infinite.playback.volumecheck_enabled') == 'false' or get_visibility('Player.Muted'): return
		from modules.utils import string_alphanum_to_num
		max_volume = min(int(get_property('infinite.playback.volumecheck_percent') or '50'), 100)
		if int(100 - (float(string_alphanum_to_num(get_infolabel('Player.Volume').split('.')[0]))/60)*100) > max_volume: execute_builtin('SetVolume(%d)' % max_volume)
	except: pass

def focus_index(index):
	current_window = current_window_object()
	focus_id = current_window.getFocusId()
	try: current_window.getControl(focus_id).selectItem(index)
	except: logger(f'focus_index Error: {print_exc()}')

def get_all_icons(include_values=False):
	try:
		return get_icon_name(include_values=False)
	except:
		import requests
		from caches.main_cache import cache_object
		def _process(dummy):
			try:
				results = requests.get('https://api.github.com/repos/%s/%s/contents/packages/media/icons' % (username, location))
				results = [i['name'].replace('.png', '') for i in results.json()]
				return results
			except: return ['folder.png']
		username, location = get_property('infinite.update.username'), get_property('infinite.update.location')
		return cache_object(_process, 'all_icons', 'foo', False, 168)

def get_all_addon_icons(include_values=False):
	try:
		return get_icon_name(include_values=False)
	except:
		import requests
		from caches.main_cache import cache_object
		def _process(dummy):
			try:
				results = requests.get('https://api.github.com/repos/%s/%s/contents/packages/addon_icons' % (username, location))
				return results
			except: return []
		username, location = get_property('infinite.update.username'), get_property('infinite.update.location')
		return cache_object(_process, 'all_addon_icons', 'foo', True, 168)

def upload_logfile(params):
	import json
	import requests
	from modules.utils import copy2clip, make_qrcode
	log_files = [('Current Kodi Log', 'kodi.log'), ('Previous Kodi Log', 'kodi.old.log')]
	list_items = [{'line1': i[0]} for i in log_files]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Choose Which Log File to Upload', 'narrow_window': 'true'}
	log_file = select_dialog(log_files, **kwargs)
	if log_file is None: return
	log_name, log_file = log_file
	if not confirm_dialog(heading=log_name): return
	show_busy_dialog()
	url = 'https://paste.kodi.tv/'
	log_file = translate_path(f'special://logpath/{log_file}')
	if not path_exists(log_file): return ok_dialog(text='Error. Log Upload Failed')
	try:
		with open_file(log_file) as f: text = f.read()
		UserAgent = 'script.kodi.loguploader: 1.0'
		response = requests.post('%s%s' % (url, 'documents'), data=text.encode('utf-8', errors='ignore'), headers={'User-Agent': UserAgent}).json()
		if 'key' in response:
			user_code = response['key']
			url = '%s%s' % (url, user_code)
			copy2clip(url)
			qr_code = make_qrcode(url) or ''
			progressDialog = progress_dialog(heading='Kodi Log Uploader', icon=qr_code)
			count, success = 20, None
			while not progressDialog.iscanceled() and count >= 0 and success == None:
				try:
					count -= 1
					progressDialog.update('Share or Access with this url: [B]%s[/B][CR]Or Access using this QR Code' % url, count)
					sleep(2500)
				except: success = False
		else: ok_dialog(text='Error. Log Upload Failed')
	except: ok_dialog(text='Error. Log Upload Failed')
	hide_busy_dialog()

def fetch_kodi_imagecache(image):
	import sqlite3 as database
	result = None
	try:
		dbcon = database.connect(find_new_db('Textures')[0], timeout=40.0)
		dbcur = dbcon.cursor()
		dbcur.execute("SELECT cachedurl FROM texture WHERE url = ?", (image,))
		result = dbcur.fetchone()[0]
	except: pass
	return result

def get_icon_name(include_values=False):
	if include_values: return [(k, v) for k, v in vars(icons).items() if not k.startswith('__')]
	else: return [k for k, v in vars(icons).items() if not k.startswith('__')]

def find_new_db(pattern):
	_path = translate_path('special://profile/Database/')
	result = []
	for root, dirs, files in walk(_path):
		for name in files:
			if pattern in name and name.endswith('.db'):
				result.append(osPath.join(root, name))
	return result

def set_info(item, meta, setUniqueIDs=None, resumetime=''):
	try:
		if resumetime: resumetime = float(resumetime)
		meta_get = meta.get
		media_type = meta_get('mediatype') or meta_get('media_type')
		info_tag = item.getVideoInfoTag(True)
		info_tag.setMediaType(media_type)
		if setUniqueIDs: info_tag.setUniqueIDs(setUniqueIDs)
		info_tag.setPath(meta_get('path'))
		info_tag.setFilenameAndPath(meta_get('filenameandpath'))
		info_title = item.getLabel() if meta_get('title') == '' else meta_get('title')
		info_tag.setTitle(info_title)
		info_tag.setSortTitle(meta_get('sorttitle'))
		info_tag.setOriginalTitle(meta_get('originaltitle') or meta_get('original_title'))
		info_tag.setPlot(meta_get('plot'))
		info_tag.setPlotOutline(meta_get('plotoutline'))
		info_tag.setDateAdded(meta_get('dateadded'))
		info_tag.setPremiered(meta_get('premiered', '2025-1-1'))
		info_tag.setYear(convert_type(int, meta_get('year') or 2026))
		info_tag.setRating(convert_type(float, meta_get('rating') or 4.5))
		info_tag.setMpaa(meta_get('mpaa'))
		info_tag.setDuration(meta_get('duration', 1320))
		info_tag.setPlaycount(convert_type(int , meta_get('playcount') or 0))
		if isinstance(meta_get('votes'), str): meta_votes = str(meta_get('votes')).replace(',', '')
		else: meta_votes = meta_get('votes')
		if meta_votes: info_tag.setVotes(convert_type(int, meta_votes))
		info_tag.setLastPlayed(meta_get('lastplayed'))
		info_tag.setAlbum(meta_get('album'))
		info_tag.setTags(meta_get('tag', []))
		info_tag.setTagLine(meta_get('tagline'))
		try:
			info_tag.setGenres(meta_get('genre') or [])
			info_tag.setWriters(meta_get('writer') or [])
			info_tag.setDirectors(meta_get('director') or [])
			info_tag.setCountries(meta_get('country') or [])
			info_tag.setTrailer(meta_get('trailer') or '')
			info_tag.setStudios(meta_get('studio') or [])
		except: logger(f'set_info meta : {meta} error: {print_exc()}')
		info_tag.setIMDBNumber(meta_get('imdb_id'))
		if resumetime and meta_get('duration'): info_tag.setResumePoint(resumetime, meta_get('duration'))
		elif resumetime: info_tag.setResumePoint(resumetime)
		if media_type in ('tvshow', 'season', 'episode'):
			info_tag.setTvShowTitle(meta_get('tvshowtitle'))
			info_tag.setTvShowStatus(meta_get('status'))
		if media_type in ('episodes', 'episode'):
			info_tag.setFirstAired(meta_get('premiered', '2025-1-1'))
			info_tag.setEpisode(convert_type(int, meta_get('episode')))
			info_tag.setSeason(convert_type(int, meta_get('season')))
		try: info_tag.setCast([kodi_actor()(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in meta_get('cast', [])])
		except: info_tag.setCast([kodi_actor()(name=item, role='', thumbnail='') for item in meta_get('cast', [])])
	except: logger(f'set_info meta : {meta} error: {print_exc()}')
	return item

def convert_type(_type, _value):
	if _type == str and isinstance(_value, list): return ', '.join(list(_value))
	try: return _type(_value)
	except TypeError as Err: return _type()
	except Exception as Err: logger(f'convert_type error: {Err}')

def set_inputstream(url, litem, is_type='adaptive'):
	if is_type == 'adaptive':
		adaptive_plugin = translate_path('special://home/addons/inputstream.adaptive')
		if not path_exists(adaptive_plugin):
			try:
				execute_builtin('InstallAddon(script.module.inputstreamhelper)', True)
				execute_builtin('InstallAddon(inputstream.adaptive)', True)
			except: return litem
		litem.setProperty('inputstream', 'inputstream.adaptive')
		litem.setProperty('inputstream.adaptive.max_bandwidth', '100000000000')
		litem.setProperty('http-reconnect', 'true')
		# if '.m3u8' in url.lower(): litem.setMimeType('application/vnd.apple.mpegurl') #and inputstreamhelper.Helper('hls').check_inputstream():
		# elif '.ism' in url.lower(): litem.setMimeType('application/vnd.ms-sstr+xml')
		# elif '.mpd' in url.lower(): litem.setMimeType('application/dash+xml')
		if '|' in url: # and ('m3u8' in url.lower() or '.mpd' in url.lower()):
			url, strhdr = url.split('|')
			litem.setProperty('inputstream.adaptive.stream_headers', strhdr)
			litem.setProperty('inputstream.adaptive.common_headers', strhdr)
			# litem.setProperty('inputstream.adaptive.manifest_headers', strhdr)
		# litem.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
		# license_headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0', 'Content-Type': 'application/octet-stream', 'Origin': 'https://www.somesite.com'}
		# from urllib.parse import urlencode
		# license_config = {'license_server_url': 'https://license.server.com/licenserequest', 'headers': urlencode(license_headers), 'post_data': 'R{SSM}', 'response_data': 'R'}
		# litem.setProperty('inputstream.adaptive.license_key', '|'.join(license_config.values()))
	else: #if is_type == 'ffmpeg':
		ffmpeg_plugin = translate_path('special://home/addons/inputstream.ffmpegdirect')
		if not path_exists(ffmpeg_plugin):
			try: execute_builtin('InstallAddon(inputstream.ffmpegdirect)', True)
			except: return litem
		litem.setProperty('inputstream', 'inputstream.ffmpegdirect')
		litem.setMimeType('application/x-mpegURL')# litem.setMimeType('application/vnd.apple.mpegurl')
		litem.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
		litem.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift')
		litem.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
	return litem

def kodi_player(url, channel='NO LABLE', direct_player=False):
	# logger(f'Common play:: channel: {channel} type(url): {type(url)} url: {url}')
	if direct_player:
		try:
			execute_builtin('PlayMedia(%s)' % url)
			hide_busy_dialog()
		except: logger(f'Common play:: {channel} Error {print_exc()}')
	else:
		from modules.player import infinitePlayer
		try: infinitePlayer().run(url, 'video', {'title': channel})
		except: logger(f'Common play:: {channel} Error {print_exc()}')

def set_resolvedurl(url, title='resolv', use_adaptive=None):
	from sys import argv
	handle = int(argv[1])
	play_item = xbmcgui.ListItem(path=url)
	info_tag = play_item.getVideoInfoTag(True)
	info_tag.setPath(url)
	info_tag.setTitle(title)
	if use_adaptive in ('adaptive', 'ffmpeg'): set_inputstream(url, play_item, is_type=use_adaptive)
	resolve(handle, True, play_item)

def decorate_log_error(lfile, only_error=False):
	import re
	text = ''
	with open(lfile, 'r', encoding='utf-8', errors='ignore') as f:
		Lines = f.readlines()
	if len(Lines) >= 300:
		last_lines = len(Lines) // 2
		Lines = Lines[last_lines:]
	regex = re.compile(r'Users\\(?<!\w)(.+?)[\\|\/]', re.IGNORECASE)
	for line in Lines:
		line = regex.sub(r'special://', line)
		if only_error:
			if not any(re.findall(r'INFO|NOTICE', line)):
				line = line.replace('ERROR', '[COLOR red]ERROR[/COLOR]:').replace('WARNING', '[COLOR gold]WARNING[/COLOR]:')
				text += line
		else: text += line
	if only_error:
		with open(lfile, 'w', encoding='utf-8', errors='ignore') as r: r.writelines(text)
	return text

def get_list_item(list_data, provider='', isFolder=False):
	for item in list_data:
		get_item = item.get
		cm = []
		cm_append = cm.append
		# logger(f'lists _process item: {item}')
		title, poster, action, isfolder = get_item('title', get_item('name')) , get_item('poster', get_item('image', addon_icon())), get_item('mode', 'ltp_play'), get_item('isfolder') or isFolder
		if provider == 'watchonline': action = item.get('mode') or 'watchonline_s'
		elif provider == 'youtube_r': action, poster = 'geetm_list', f'https://www.hindigeetmala.net{poster}' if poster.startswith('/') else poster
		url_params = dict(item, **{'mode': action, 'title': title, 'poster': poster, 'imdb_id': title, 'provider': provider, 'rescrap': 'false', 'mediatype': 'episode', 'episode': 1, 'season': 1})
		url = build_url(url_params)
		if isfolder:
			rescrape_params = dict(url_params, **{'rescrap': 'true'})
			cm_append((f'Reload {title}', f'RunPlugin({build_url(rescrape_params)})'))
			cm_append(('Add to a Shortcut Folder', 'RunPlugin(%s)' % build_url({'mode': 'menu_editor.shortcut_folder_add_item', 'name': title, 'iconImage': poster})))
		cm_append(('Open Settings', f'RunPlugin({build_url(opensettings_params)})'))
		listitem = make_listitem()
		listitem.setLabel(title)
		listitem.addContextMenuItems(cm)
		listitem.setArt({'thumb': poster})
		listitem = set_info(listitem, url_params, {'imdb': str(title)})
		yield url, listitem, isfolder
	return

def sync_accounts(silent=''):
	from openscrapers import get_creden
	from caches.settings_cache import get_setting, set_setting
	force_update = False
	try:
		all_acct = get_creden(silent, get_setting('infinite.trakt.expires'))
		set_setting('urls', str(all_acct.get('urls')))
		trakt_acct = all_acct.get('trakt')
		api_keys = all_acct.get('api_keys')
		if get_setting('infinite.google_api') == 'empty_setting':
			set_setting('google_api', api_keys.get('gemini_api'))
		if get_setting('infinite.groq_api') == 'empty_setting':
			set_setting('groq_api', api_keys.get('groq_api'))
		if get_setting('infinite.imdb_user') == '0':
			set_setting('imdb_user', api_keys.get('imdbuser'))
		if get_setting('infinite.tmdb.account_id') != api_keys.get('tmdb.account_id'):
			set_setting('tmdb_api', api_keys.get('tmdb'))
			set_setting('tmdb.token', api_keys.get('tmdb.token'))
			set_setting('tmdb.account_id', api_keys.get('tmdb.account_id'))
		if get_setting('infinite.trakt.expires') != trakt_acct.get('expires'):
			force_update = True
			set_setting('trakt.client', api_keys.get('trakt.client'))
			set_setting('trakt.secret', api_keys.get('trakt.secret'))
			set_setting('trakt.user', trakt_acct.get('user'))
			set_setting('trakt.expires', trakt_acct.get('expires'))
			set_setting('trakt.refresh', trakt_acct.get('refresh'))
			set_setting('trakt.token', trakt_acct.get('token'))
			set_setting('watched_indicators', '1')
		elif not trakt_acct.get('token'): set_setting('watched_indicators', '0')
	except:
		set_setting('watched_indicators', '0')
		logger(f'Error: {print_exc()}')
	if 'retry' not in silent: notification('Settings Updated')
	return force_update

def update_metadb():
	try:
		from modules.downloader import runner
		from modules.settings import get_git_url
		custom_files_path = get_git_url()
		urls = ['metacache.db', 'personal_lists.db', 'tmdb_lists.db', 'settings.db']
		# urls = ['/skipintro.json?raw=true']
		for url in urls:
			runner({'mode': 'downloader', 'url': f'{custom_files_path}/{url}?raw=true', 'action': 'hindi_file', 'name': f'download file: {url}', 'silent': True, 'media_type': 'file'})
			notification('Files updated')
	except:
		logger(f'Error: {print_exc()}')
		notification('Error')
