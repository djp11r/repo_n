# -*- coding: utf-8 -*-
import time
import sqlite3 as database
from traceback import print_exc
from modules.kodi_utils import logger, kodi_refresh, sleep, path_join, translate_path, addon_profile, delete_file, get_property, set_property, clear_property, notification, confirm_dialog, ok_dialog, open_file, show_text, path_exists, list_dirs, progress_dialog, make_directory, delete_folder

userdata_path = addon_profile()
databases_path = path_join(userdata_path, 'databases/')

integrity_check = {
'settings_db': ('settings',),
'navigator_db': ('navigator',),
'watched_db': ('watched_status', 'progress', 'watched'),
'favorites_db': ('favourites',),
'trakt_db': ('trakt_data', 'watched_status', 'progress', 'watched'),
'maincache_db': ('maincache',),
'metacache_db': ('metadata', 'season_metadata', 'function_cache'),
'lists_db': ('lists',),
'discover_db': ('discover',),
'external_db': ('results_data',),
'episode_groups_db': ('groups_data',),
'tmdb_lists_db': ('tmdb_lists',),
'personal_lists_db': ('personal_lists',),
'random_widgets_db': ('random_widgets',)
}

def table_creators():
	return {
'navigator_db': (
'CREATE TABLE IF NOT EXISTS navigator (list_name text, list_type text, list_contents text, unique (list_name, list_type))',),
'watched_db': (
'CREATE TABLE IF NOT EXISTS watched (db_type text not null, media_id text not null, season integer, episode integer, last_played text, title text, unique (db_type, media_id, season, episode))',
'CREATE TABLE IF NOT EXISTS progress (db_type text not null, media_id text not null, season integer, episode integer, resume_point text, curr_time text, last_played text, resume_id integer, title text, unique (db_type, media_id, season, episode))',
'CREATE TABLE IF NOT EXISTS watched_status (db_type text not null, media_id text not null, status text, unique (db_type, media_id))'),
'favorites_db': (
'CREATE TABLE IF NOT EXISTS favourites (db_type text not null, tmdb_id text not null, title text not null, unique (db_type, tmdb_id))',),
'settings_db': (
'CREATE TABLE IF NOT EXISTS settings (setting_id text not null unique, setting_type text, setting_default text, setting_value text)',),
'trakt_db': (
'CREATE TABLE IF NOT EXISTS trakt_data (id text unique, data text)',
'CREATE TABLE IF NOT EXISTS watched (db_type text not null, media_id text not null, season integer, episode integer, last_played text, title text, unique (db_type, media_id, season, episode))',
'CREATE TABLE IF NOT EXISTS progress (db_type text not null, media_id text not null, season integer, episode integer, resume_point text, curr_time text, last_played text, resume_id integer, title text, unique (db_type, media_id, season, episode))',
'CREATE TABLE IF NOT EXISTS watched_status (db_type text not null, media_id text not null, status text, unique (db_type, media_id))'),
'maincache_db': (
'CREATE TABLE IF NOT EXISTS maincache (id text unique, data text, expires integer)',),
'metacache_db': (
'CREATE TABLE IF NOT EXISTS metadata (db_type text not null, tmdb_id text not null, imdb_id text, tvdb_id text, meta text, expires integer, unique (db_type, tmdb_id))',
'CREATE TABLE IF NOT EXISTS season_metadata (tmdb_id text not null unique, meta text, expires integer)',
'CREATE TABLE IF NOT EXISTS function_cache (string_id text not null unique, data text, expires integer)'),
'lists_db': (
'CREATE TABLE IF NOT EXISTS lists (id text unique, data text, expires integer)',),
'external_db': (
'CREATE TABLE IF NOT EXISTS results_data (provider text not null, db_type text not null, tmdb_id text not null, title text, year integer, season text, episode text, results text, \
expires integer, unique (provider, db_type, tmdb_id, title, year, season, episode))',),
'discover_db': (
'CREATE TABLE IF NOT EXISTS discover (id text not null unique, db_type text not null, data text)',),
'episode_groups_db': (
'CREATE TABLE IF NOT EXISTS groups_data (tmdb_id text not null unique, data text)',),
'personal_lists_db': (
'CREATE TABLE IF NOT EXISTS personal_lists (name text, contents text, total integer, created text, sort_order integer, description text, seen text, poster text, fanart text, author text, updated text, unique (name, author))',),
'tmdb_lists_db': (
'CREATE TABLE IF NOT EXISTS tmdb_lists (id text unique, data text, expires integer)',),
'random_widgets_db': (
'CREATE TABLE IF NOT EXISTS random_widgets (id text unique, data text, expires integer)',)
}

def locations():
	return {'navigator_db': 'navigator.db', 'watched_db': 'watched.db', 'favorites_db': 'favourites.db', 'settings_db': 'settings.db', 'trakt_db': 'traktcache.db',
'maincache_db': 'maincache.db', 'metacache_db': 'metacache.db', 'lists_db': 'lists.db', 'tmdb_lists_db': 'tmdb_lists.db',
'discover_db': 'discover.db', 'external_db': 'external.db', 'episode_groups_db': 'episode_groups.db', 'personal_lists_db': 'personal_lists.db', 'random_widgets_db': 'random_widgets.db'}

def database_locations(database_name):
	return translate_path(path_join(userdata_path, locations()[database_name]))

def make_database(database_name):
	try:
		dbcon = database.connect(database_locations(database_name))
		for command in table_creators()[database_name]: dbcon.execute(command)
		dbcon.close()
	except:
		notification(f'Error Checking Database : {database_name}')
		logger(f'error make_database: {database_name}: {print_exc()}')


def make_databases():
	for database_name in locations():
		try:
			make_database(database_name)
		except:
			if not path_exists(userdata_path): make_directory(userdata_path)


def connect_database(database_name):
	dbcon = database.connect(database_locations(database_name), timeout=20, isolation_level=None, check_same_thread=False)
	dbcon.execute('PRAGMA synchronous = OFF')
	dbcon.execute('PRAGMA journal_mode = OFF')
	return dbcon

def get_timestamp(offset=0):
	# Offset is in HOURS multiply by 3600 to get seconds
	return int(time.time()) + (offset*3600)

def remove_old_databases():
	try:
		files = list_dirs(databases_path)[1]
		current_dbs = locations()
		for item in files:
			if item not in current_dbs:
				try: delete_file(databases_path + item)
				except: pass
	except: pass

def check_databases_integrity(silent=False):
	def _process(database_name, tables):
		cursor, error = None, False
		try:
			database_location = database_locations(database_name)
			dbcon = database.connect(database_location)
			cursor = dbcon.cursor()
		except: error = True
		if cursor:
			try:
				cursor.execute('PRAGMA integrity_check')
				result = cursor.fetchone()
				if not 'ok' in result: error = True
			except: error = True
			try:
				tables_in_db = cursor.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
				# logger(f'db_file tables_in_db: {tables_in_db}')
				if len(tables_in_db) != len(tables): error = True
				for table in tables_in_db:
					if table[0] not in tables:
						logger(f'from database_name: {database_name} DROP TABLE: {table}')
						_drop_table(cursor, table)
			except: error = True
		if error:
			database_errors.append(database_name)
			try: dbcon.close()
			except: pass
			if path_exists(database_location): delete_file(database_location)
			logger(f'Error in: {database_name}  so make one')
			make_database(database_name)
	database_errors = []
	for database_name, tables in integrity_check.items(): _process(database_name, tables)
	if database_errors and not silent: ok_dialog(text='[B]Following Databases Rebuilt:[/B][CR][CR]%s' % ', '.join(database_errors))
	elif not silent: notification('No Corrupt or Missing Databases')

def get_size(file):
	with open_file(file) as f: s = f.size()
	return s

def clean_databases(silent=False):
	from caches.external_cache import external_cache
	from caches.main_cache import main_cache
	from caches.lists_cache import lists_cache
	from caches.meta_cache import meta_cache
	clean_cache_list = (('EXTERNAL CACHE', external_cache, 'external_db'), ('MAIN CACHE', main_cache, 'maincache_db'), ('LISTS CACHE', lists_cache, 'lists_db'), ('META CACHE', meta_cache, 'metacache_db'))
	results = []
	append = results.append
	success = True
	db_re_table()
	for item in clean_cache_list:
		name, function, location = item
		location = database_locations(location)
		start_bytes = get_size(location)
		result = function.clean_database()
		if not result:
			append('[B]%s: [COLOR red]FAILED[/COLOR][/B]' % name)
			success = False
			continue
		end_bytes = get_size(location)
		saved_bytes = start_bytes - end_bytes
		append('[B]%s: [COLOR green]SUCCESS[/COLOR][/B][CR]    [B]Saved Size: %sMB[/B][CR]    Start Size/End Size: %sMB/%sMB' \
		% (name, round(float(saved_bytes)/1024/1024, 2), round(float(start_bytes)/1024/1024, 2), round(float(end_bytes)/1024/1024, 2)))
	if not silent: return notification('Success: clean cache' if success else 'Fail: clean cache')
	else: return show_text('Cache Clean Results', text='[CR]----------------------------------[CR]'.join(results), font_size='large')

def clear_cache(cache_type, silent=False):
	def _confirm(): return silent or confirm_dialog()
	success = True
	if cache_type == 'meta':
		from caches.meta_cache import delete_meta_cache
		success = delete_meta_cache(silent=silent)
	elif cache_type == 'internal_scrapers':
		if not _confirm(): return
		results = []
		for item in ('folders'): results.append(clear_cache(item, silent=True))
		success = False not in results
	elif cache_type == 'external_scrapers':
		from caches.external_cache import external_cache
		success = external_cache.clear_cache()
	elif cache_type == 'external_scrapers_statistics':
		from openscrapers import external_scrapers_reset_stats
		success = external_scrapers_reset_stats()
	elif cache_type == 'trakt':
		from caches.trakt_cache import clear_all_trakt_cache_data
		success = clear_all_trakt_cache_data(silent=silent)
	elif cache_type == 'imdb':
		if not _confirm(): return
		from apis.imdb_api import clear_imdb_cache
		success = clear_imdb_cache()
	elif cache_type == 'folders':
		if not _confirm(): return
		from caches.main_cache import main_cache
		success = main_cache.delete_all_folderscrapers()
	elif cache_type == 'list':
		if not _confirm(): return
		from caches.lists_cache import lists_cache
		success = lists_cache.delete_all_lists()
	elif cache_type == 'ai_functions':
		if not _confirm(): return
		from caches.lists_cache import lists_cache
		success = lists_cache.delete_all_ai_lists()
	elif cache_type == 'tmdb_list':
		if not _confirm(): return
		from caches.tmdb_lists import tmdb_lists_cache
		success = tmdb_lists_cache.clear_all()
	elif 'h_' in cache_type:
		from caches.main_cache import main_cache
		if cache_type == 'h_list': main_cache.delete_all_lists()
		elif cache_type == 'h_content': main_cache.delete_like('content_%')
		elif cache_type == 'h_shows': main_cache.delete_like('shows_%')
		elif cache_type == 'h_episodes': main_cache.delete_like('episodes_%')
		elif cache_type == 'h_movies': main_cache.delete_like('movies_%')
		elif cache_type == 'h_meta':
			from caches.meta_cache import meta_cache
			meta_cache.delete_like('%|%')
	elif cache_type == 'local_bookmark':
		resets_db_tables(('watched_db'))
	else:# main
		if not _confirm(): return
		from caches.main_cache import main_cache
		main_cache.delete_all()
	if not silent: notification('Success:' if success else 'Fail:')

def clear_all_cache():
	if not confirm_dialog(): return
	progressDialog = progress_dialog()
	line = 'Clearing....[CR]%s'
	caches = (('meta', 'Meta Cache'), ('internal_scrapers', 'Internal Scrapers Cache'), ('external_scrapers', 'External Scrapers Cache'),
			('trakt', 'Trakt Cache'), ('imdb', 'IMDb Cache'), ('list', 'List Data Cache'), ('ai_functions', 'AI Data Cache'), ('tmdb_list', 'TMDb Personal List Cache'), ('main', 'Main Cache'))
	for count, cache_type in enumerate(caches, 1):
		try:
			progressDialog.update(line % (cache_type[1]), int(float(count) / float(len(caches)) * 100))
			clear_cache(cache_type[0], silent=True)
			sleep(1000)
		except: pass
	progressDialog.close()
	sleep(100)
	ok_dialog(text='Success')

def refresh_cached_data(meta):
	from caches.meta_cache import meta_cache
	media_type, tmdb_id, imdb_id = meta['mediatype'], meta['tmdb_id'], meta['imdb_id']
	try: meta_cache.delete(media_type, 'tmdb_id', tmdb_id, meta)
	except: return notification('Error')
	# from apis.imdb_api import refresh_imdb_meta_data
	# refresh_imdb_meta_data(imdb_id)
	notification('Success')
	kodi_refresh()

def columns_in_table(database, table, check_existence=''):
	dbcon = connect_database(database)
	all_columns = [i[1] for i in dbcon.execute('PRAGMA table_info(%s);' % table).fetchall()]
	if check_existence: return check_existence in all_columns
	return all_columns

def insert_new_column_in_table(database, table, new_column, new_column_properties):
	try:
		dbcon = connect_database(database)
		dbcon.execute('ALTER TABLE %s ADD COLUMN %s %s;' % (table, new_column, new_column_properties))
		return True
	except: return False

def check_and_insert_new_columns(database, table, new_column, new_column_properties):
	#Check for existence of any column in databases and insert if not present
	try:
		if not columns_in_table(database, table, new_column):
			success = insert_new_column_in_table(database, table, new_column, new_column_properties)
			if not success: notification('Error with [B]%s[/B] Database. Missing Column [B]%s[/B]' % (database.upper(), new_column.upper()))
	except: notification('Error Checking Database Table/s: %s' % database)

class BaseCache(object):
	def __init__(self, dbfile, table):
		self.table = table
		self.dbfile = dbfile

	def get(self, string):
		result = None
		try:
			current_time = get_timestamp()
			dbcon = connect_database(self.dbfile)
			if cache_data:= dbcon.execute('SELECT expires, data FROM %s WHERE id = ?' % self.table, (string,)).fetchone():
				if cache_data[0] > current_time:
					result = eval(cache_data[1])
				else: self.delete(string)
		except: pass
		return result

	def set(self, string, data, expiration=720):
		try:
			dbcon = connect_database(self.dbfile)
			expires = get_timestamp(expiration)
			dbcon.execute('INSERT OR REPLACE INTO %s(id, data, expires) VALUES (?, ?, ?)' % self.table, (string, repr(data), int(expires)))
		except: return None

	def delete(self, string):
		try:
			dbcon = connect_database(self.dbfile)
			dbcon.execute('DELETE FROM %s WHERE id = ?' % self.table, (string,))
		except: pass

	def delete_like(self, string):
		try:
			dbcon = connect_database(self.dbfile)
			dbcon.execute('DELETE FROM %s WHERE id LIKE ?' % self.table, (string,))
		except: pass

	def manual_connect(self, dbfile):
		return connect_database(dbfile)


def db_re_table(db_name='watched_db', days=90):
	try:
		from datetime import datetime, timedelta
		olddate = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d %H:%M:%S')
		dbcon = connect_database(db_name)
		for table in ('progress', 'watched'):
			dbcon.execute('DELETE from %s WHERE CAST(last_played AS TEXT) <= ?' % table, (olddate,))
		dbcon.commit()
		dbcon.execute('VACUUM')
		dbcon.close()
	except: logger(f'db_re_table Error {print_exc()}')

def resets_db_tables(db_name):
	try:
		db_tables = integrity_check[db_name]
		dbcon = connect_database(db_name)
		tables_in_db = dbcon.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
		# logger(f'db_file tables_in_db: {tables_in_db}')
		for table in tables_in_db:
			if table[0] not in db_tables:
				logger(f'DROP TABLE: {table}')
				_drop_table(dbcon, table)
			else:
				logger(f'DELETE FROM {table[0]}')
				try:
					dbcon.execute(f'''DELETE FROM {table[0]}''')
					dbcon.commit() # added this for what looks like a 19 bug not found in 18, normal commit is at end
					dbcon.execute('VACUUM')
				except:
					_drop_table(dbcon, table)
		dbcon.commit()
		dbcon.execute('VACUUM')
		dbcon.close()
	except: logger(f'resets_db_tables Error {print_exc()}')


def _drop_table(dbcur, table):
	dbcur.execute(f'''DROP TABLE IF EXISTS {table[0]}''')
	dbcur.execute('''VACUUM''')
	dbcur.commit()

def clrcache_version_update(clr_providers=False, clr_metacache=False, clr_cache=False, clr_navigator=False, clr_bookmarks=False, clr_localbookmarks=False):
	from modules.utils import make_thread_list
	db_file_list = []
	db_file_list_append = db_file_list.append
	if clr_providers: db_file_list_append('external_db')
	if clr_metacache: db_file_list_append('metacache_db')
	if clr_cache: db_file_list_append('maincache_db')
	if clr_navigator: db_file_list_append('navigator_db')
	if clr_bookmarks: db_file_list_append('trakt_db')
	if clr_localbookmarks: db_file_list_append('watched_db')
	logger(f'clrCache_version total : {len(db_file_list)} db_file_list: {db_file_list}')
	threads = list(make_thread_list(resets_db_tables, db_file_list))
	[i.join() for i in threads]

def check_cache_location():
	import shutil
	# logger(f'check_cache_location: {path_exists(translate_path(databases_path))}')
	if path_exists(translate_path(databases_path)):
		try:
			all_db_file = locations()
			for item in all_db_file:
				from_db = translate_path(path_join(databases_path[:-1], item))
				to_db = translate_path(path_join(userdata_path, item))
				try: shutil.move(from_db, to_db)
				except: pass
			# shutil.rmtree(translate_path(databases_path))#, ignore_errors=True)
			# delete_folder(translate_path(databases_path))
		except: logger(f'check_cache_location Error: {print_exc()}')

def change_column_schema():
	# dbcon = connect_database('personal_lists_db')
	dbcon = database.connect(database_locations('personal_lists_db'))
	dbcur = dbcon.cursor()
	logger('change_column_schema', dbcon)
	# try:
	dbcur.execute('PRAGMA foreign_keys = OFF;')
	dbcur.execute('BEGIN TRANSACTION;')

	# Example: Changing 'age' column from INTEGER to TEXT
	dbcur.execute('CREATE TABLE personal_lists_new \
		(name text, contents text, total integer, created text, sort_order integer, description text, seen text, poster text, \
		fanart text, author text, updated text, unique (name, author))',)
	dbcur.execute('INSERT INTO personal_lists_new \
		(name, contents, total, created, sort_order, description, seen, poster, fanart, author, updated) \
		SELECT name, contents, total, created, sort_order, description, seen, poster, fanart, author, updated FROM personal_lists;')
	# dbcur.execute('DROP TABLE personal_lists_new;')
	# dbcur.execute('ALTER TABLE personal_lists_new RENAME TO personal_lists;')

	dbcon.commit()
	# print("Column schema modified successfully.")
	dbcur.execute('PRAGMA foreign_keys = ON;')
	dbcon.close()

	# except database.Error as e:
	#     conn.rollback()
	#     print(f"Error modifying column schema: {e}")

	# finally:
	#     cursor.execute("PRAGMA foreign_keys = ON;")
	#     conn.close()
