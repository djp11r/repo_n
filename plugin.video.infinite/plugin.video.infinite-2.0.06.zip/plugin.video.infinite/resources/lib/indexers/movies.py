# -*- coding: utf-8 -*-
import sys
import json
from traceback import print_exc
from modules.metadata import movie_meta, movieset_meta
from modules.utils import manual_function_import, get_datetime, TaskPool, get_current_timestamp, paginate_list, jsondate_to_datetime
from modules.watched_status import get_database, watched_info_movie, get_watched_status_movie, get_bookmarks_movie, get_progress_status_movie
from modules.kodi_utils import logger, make_listitem, build_url, nextpage_landscape,external, add_items, add_dir, get_property,set_content, end_directory, set_view_mode, folder_path, addon_fanart, set_property, sleep, set_category, add_item, home, set_info, kodi_actor, get_icon
from modules.settings import watched_indicators, widget_hide_next_page,widget_hide_watched, media_open_action, page_limit, paginate,tmdb_api_key, mpaa_region, cm_sort_order, cm_default_order, playback_key as pb_key, jump_to_enabled


class Movies:
	main = ('tmdb_movies_popular', 'tmdb_movies_popular_today', 'tmdb_movies_blockbusters', 'tmdb_movies_in_theaters', 'tmdb_movies_upcoming', 'tmdb_movies_latest_releases', 'tmdb_movies_premieres', 'tmdb_movies_oscar_winners')
	special = ('tmdb_movies_languages', 'tmdb_movies_providers', 'tmdb_movies_year', 'tmdb_movies_decade', 'tmdb_movies_certifications', 'tmdb_movies_recommendations', 'tmdb_movies_genres', 'tmdb_movies_search', 'tmdb_movie_keyword_results', 'tmdb_movie_keyword_results_direct', 'ai_similar')
	personal = {'in_progress_movies': ('modules.watched_status', 'get_in_progress_movies'), 'favorites_movies': ('modules.favorites', 'get_favorites'), 'watched_movies': ('modules.watched_status', 'get_watched_items'), 'recent_watched_movies': ('modules.watched_status', 'get_recently_watched')}
	trakt_main = ('trakt_movies_trending', 'trakt_movies_trending_recent', 'trakt_movies_most_watched', 'trakt_movies_most_favorited', 'trakt_movies_top10_boxoffice')
	trakt_personal = ('trakt_collection', 'trakt_watchlist', 'trakt_collection_lists', 'trakt_watchlist_lists', 'trakt_favorites')
	tmdb_personal = ('tmdb_watchlist', 'tmdb_favorite', 'tmdb_recommendations')
	imdb_personal = ('imdb_watchlist', 'imdb_user_list_contents', 'imdb_keywords_list_contents')

	def __init__(self, params):
		self.params = params
		self.params_get = self.params.get
		self.category_name = self.params_get('category_name', None) or self.params_get('name', None) or 'Movies'
		self.id_type, self.list = self.params_get('id_type', 'tmdb_id'), self.params_get('list', [])
		self.mode, self.action = self.params_get('mode', None), self.params_get('action', None)
		self.items, self.new_page, self.total_pages, self.is_external = [], {}, None, external()
		if self.is_external:
			self.widget_hide_next_page = widget_hide_next_page()
			self.widget_hide_watched = self.action not in ('watched_movies', 'recent_watched_movies') and widget_hide_watched()
		else: self.widget_hide_next_page, self.widget_hide_watched = False, False
		self.playback_key = pb_key()
		self.play_mode = 'playback.%s' % self.playback_key
		self.custom_order = self.params_get('custom_order', 'false') == 'true'
		self.fromtmbd = self.params_get('fromtmbd', 'false') == 'true'
		self.paginate_start = int(self.params_get('paginate_start', '0'))
		self.append = self.items.append
		self.movieset_list_active = False
		self.tmdb_api_key, self.mpaa_region = tmdb_api_key(), mpaa_region()
		self.current_date, self.current_time, self.watched_indicators = get_datetime(), get_current_timestamp(), watched_indicators()
		self.watched_title = 'Trakt' if self.watched_indicators == 1 else 'infinite'
		watched_db = get_database(self.watched_indicators)
		self.watched_info, self.bookmarks = watched_info_movie(watched_db), get_bookmarks_movie(watched_db)
		open_action = media_open_action('movie')
		self.open_movieset = open_action in (2, 3) and not self.movieset_list_active
		self.open_extras = open_action in (1, 3)
		self.window_command = 'ActivateWindow(Videos,%s,return)' if self.is_external else 'Container.Update(%s)'
		self.cm_sort_order = cm_sort_order()
		self.perform_cm_sort = self.cm_sort_order != cm_default_order()
		self.kodi_actor, self.make_listitem, self.build_url = kodi_actor(), make_listitem, build_url
		self.poster_empty, self.fanart_empty = get_icon('box_office'), addon_fanart()


	def fetch_list(self):
		handle = int(sys.argv[1])
		try:
			try: page_no = int(self.params_get('new_page', '1'))
			except: page_no = self.params_get('new_page')
			if page_no == 1 and not self.is_external: set_property('infinite.exit_params', folder_path())
			if self.action in self.personal: var_module, import_function = self.personal[self.action]
			else: var_module, import_function = 'apis.%s_api' % self.action.split('_')[0], self.action
			try: function = manual_function_import(var_module, import_function)
			except: pass
			if self.action in self.main:
				data = function(page_no)
				self.list = [i['id'] for i in data['results']]
				if data['total_pages'] > page_no: self.new_page = {'new_page': str(data['page'] + 1)}
			elif self.action in self.special:
				key_id = self.params_get('key_id') or self.params_get('query')
				if not key_id: return
				data = function(key_id, page_no)
				self.list = [i['id'] for i in data['results']]
				if data['total_pages'] > page_no: self.new_page = {'new_page': str(data['page'] + 1), 'key_id': key_id}
			elif self.action in self.personal:
				data = function('movie', page_no)
				c_data, total_pages = self.paginate_list(data, page_no)
				self.list = [i['media_id'] for i in c_data]
				if total_pages > 2: self.total_pages = total_pages
				if total_pages > page_no: self.new_page = {'new_page': str(page_no + 1), 'paginate_start': self.paginate_start}
			elif self.action in self.trakt_main:
				self.id_type = 'trakt_dict'
				data = function(page_no)
				try: self.list = [i['movie']['ids'] for i in data]
				except: self.list = [i['ids'] for i in data]
				if self.action not in ('trakt_movies_top10_boxoffice', 'trakt_recommendations'): self.new_page = {'new_page': str(page_no + 1)}
			elif self.action in self.tmdb_personal:
				data, total_pages = function('movie', page_no, 1)
				self.list = [i['id'] for i in data]
				if total_pages > page_no: self.new_page = {'new_page': str(page_no + 1), 'new_letter': 1}
			elif self.action in self.trakt_personal:
				self.id_type = 'trakt_dict'
				data = function('movies', page_no)
				if self.action in ('trakt_collection_lists', 'trakt_watchlist_lists', 'trakt_favorites'): total_pages, c_data = 1, data
				else: c_data, total_pages = self.paginate_list(data, page_no)
				self.list = [i['media_ids'] for i in c_data]
				if total_pages > 2: self.total_pages = total_pages
				try:
					if total_pages > page_no: self.new_page = {'new_page': str(page_no + 1), 'paginate_start': self.paginate_start}
				except: pass
			elif self.action == 'trakt_recommendations':
				self.id_type = 'trakt_dict'
				data = function('movies')
				c_data, total_pages = self.paginate_list(data, page_no)
				self.list = [i['ids'] for i in c_data]
				if total_pages > 2: self.total_pages = total_pages
				try:
					if total_pages > page_no: self.new_page = {'new_page': str(page_no + 1), 'paginate_start': self.paginate_start}
				except: pass
			elif self.action in self.imdb_personal:
				self.id_type = 'imdb_id'
				list_id = self.params_get('list_id', None)
				data, next_page = function('movie', list_id, page_no)
				self.list = [i['imdb_id'] for i in data]
				if next_page: self.new_page = {'list_id': list_id, 'new_page': str(page_no + 1), 'new_letter': 1}
			elif self.action == 'tmdb_movies_discover':
				url = self.params_get('url')
				data = function(url, page_no)
				self.list = [i['id'] for i in data['results']]
				if data['total_pages'] > page_no: self.new_page = {'url': url, 'new_page': str(data['page'] + 1)}
			elif self.action  == 'tmdb_movies_sets':
				self.movieset_list_active = True
				data = sorted(movieset_meta(self.params_get('key_id'), self.tmdb_api_key)['parts'], key=lambda k: k['release_date'] or '2050')
				self.list = [i['id'] for i in data]
			elif self.action == 'trakt_movies_related':
				self.id_type = 'trakt_dict'
				key_id = self.params_get('key_id')
				if not key_id.startswith('tt'): key_id = movie_meta('tmdb_id', key_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())['imdb_id']
				data = function(key_id)
				self.list = [i['ids'] for i in data]
			elif self.action == 'imdb_more_like_this':
				from apis.imdb_api import imdb_more_like_this
				self.id_type = 'imdb_id'
				key_id = self.params_get('key_id')
				if self.params_get('get_imdb'):
					key_id = movie_meta('tmdb_id', key_id, tmdb_api_key(), mpaa_region(), get_datetime(), get_current_timestamp())['imdb_id']
				self.list = imdb_more_like_this(key_id)
				self.list = data = function(self.params_get('key_id'))
			add_items(handle, self.worker())
			if self.new_page and not self.widget_hide_next_page:
				self.new_page.update({'mode': 'build_movie_list', 'action': self.action, 'category_name': self.category_name})
				add_dir(handle, self.new_page, 'Next Page (%s) >>' % self.new_page['new_page'], 'nextpage', get_icon('nextpage_landscape'))
			if self.total_pages and self.total_pages > 2 and jump_to_enabled() and not self.is_external:
				add_dir(handle, {'mode': 'navigate_to_page_choice', 'current_page': page_no, 'total_pages': self.total_pages, 'url_params': json.dumps(self.new_page), 'all_pages': data}, 'Jump To...', 'item_jump', get_icon('item_jump_landscape'), isFolder=False)
		except: logger(f'fetch_list self.list: {self.list}\nError: {print_exc()}')
		set_content(handle, 'movies')
		set_category(handle, self.category_name)
		end_directory(handle, cacheToDisc=not self.is_external)
		if not self.is_external:
			if self.params_get('refreshed') == 'true': sleep(1000)
			set_view_mode('view.movies', 'movies', self.is_external)

	def build_movie_content(self, _position, _id):
		try:
			if isinstance(_id, dict):
				if _id.get('tmdb', None): self.id_type, _id = 'tmdb_id', _id['tmdb']
				elif _id.get('imdb', None): self.id_type, _id = 'imdb_id', _id['imdb']
			# logger(f'build_movie_content _position: {repr(_position)} _id: {repr(_id)}')
			meta = movie_meta(self.id_type, _id, self.tmdb_api_key, self.mpaa_region, self.current_date, self.current_time)
			if not meta or 'blank_entry' in meta: return
			# logger(f'build_movie_content meta: {repr(meta)}')
			listitem = self.make_listitem()
			cm = []
			cm_append = cm.append
			set_properties = listitem.setProperties
			meta_get = meta.get
			premiered = meta_get('premiered')
			title, year = meta_get('title'), meta_get('year') or '2050'
			cast = meta_get('short_cast', []) or meta_get('cast', []) or []
			tmdb_id, imdb_id = meta_get('tmdb_id'), meta_get('imdb_id')
			str_tmdb_id = str(tmdb_id)
			poster, fanart, clearlogo, landscape = meta_get('poster') or self.poster_empty, meta_get('fanart') or self.poster_empty, meta_get('clearlogo') or '', meta_get('landscape') or ''
			thumb = poster or landscape or fanart
			movieset_id, movieset_name = meta_get('extra_info').get('collection_id', None), meta_get('extra_info').get('collection_name', None)
			first_airdate = jsondate_to_datetime(premiered, '%Y-%m-%d', True)
			duration = meta_get('duration')
			if not first_airdate or self.current_date < first_airdate: unaired = True
			else: unaired = False
			progress = get_progress_status_movie(self.bookmarks, str_tmdb_id)
			playcount = get_watched_status_movie(self.watched_info, str_tmdb_id)
			url_parm = {'mode': self.play_mode, 'media_type': 'movie', 'tmdb_id': tmdb_id, self.playback_key: self.playback_key, 'imdb_id': imdb_id, 'tvdb_id': 'None', 'icon': poster, 'title': title}
			play_params = self.build_url(url_parm)
			extras_params = self.build_url({'mode': 'extras_menu_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'is_external': self.is_external})
			options_params = self.build_url({'mode': 'options_menu_choice', 'content': 'movie', 'tmdb_id': tmdb_id, 'poster': poster, 'is_external': self.is_external})
			playback_options_params = self.build_url({'mode': 'playback_choice', 'media_type': 'movie', 'meta': tmdb_id})
			browse_recommended_params = self.build_url({'mode': 'build_movie_list', 'action': 'tmdb_movies_recommendations', 'is_external': self.is_external, 'key_id': tmdb_id, 'name': 'Recommended based on %s' % title})
			browse_related_params = self.build_url({'mode': 'build_movie_list', 'action': 'trakt_movies_related', 'key_id': imdb_id, 'is_external': self.is_external,
										'name': 'Related to %s' % title})
			browse_more_like_this_params = self.build_url({'mode': 'build_movie_list', 'action': 'imdb_more_like_this', 'key_id': imdb_id, 'is_external': self.is_external, 'name': 'More Like This based on %s' % title})
			browse_similar_params = self.build_url({'mode': 'build_movie_list', 'action': 'ai_similar', 'is_external': self.is_external, 'key_id': 'movie|%s' % tmdb_id, 'name': 'AI Similar based on %s' % title})
			browse_in_trakt_list_params = self.build_url({'mode': 'trakt.list.in_trakt_lists', 'media_type': 'movie', 'imdb_id': imdb_id, 'is_external': self.is_external, 'category_name': '%s In Trakt Lists' % title})
			trakt_manager_params = self.build_url({'mode': 'trakt_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': 'None', 'media_type': 'movie', 'icon': poster})
			personal_manager_params = self.build_url({'mode': 'personallists_manager_choice', 'list_type': 'movie', 'tmdb_id': tmdb_id, 'title': title, 'premiered': premiered, 'current_time': self.current_time, 'icon': poster})
			tmdb_manager_params = self.build_url({'mode': 'tmdblists_manager_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'icon': poster})
			favorites_manager_params = self.build_url({'mode': 'favorites_manager_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'title': title})
			########
			url_parm['mode'] = 'scrape_select'
			cm_append(['select', ('Select Source', 'RunPlugin(%s)' % build_url(url_parm))])
			url_parm['mode'] = 'rescrape_select'
			cm_append(['rescrape', ('Rescrape & Select Source', 'RunPlugin(%s)' % build_url(url_parm))])
			########
			belongs_to_movieset = 'true' if all([movieset_id, movieset_name]) else 'false'
			movieset_active = self.open_movieset and belongs_to_movieset == 'true'
			if self.open_extras or movieset_active: cm_append(['extras', ('[B]Playback[/B]', 'RunPlugin(%s)' % play_params)])
			if not self.open_extras or movieset_active: cm_append(['extras', ('[B]Extras[/B]', 'RunPlugin(%s)' % extras_params)])
			if movieset_active: url_params = self.build_url({'mode': 'open_movieset_choice', 'key_id': movieset_id, 'name': movieset_name, 'is_external': self.is_external})
			elif self.open_extras: url_params = extras_params
			else: url_params = play_params
			cm_append(['options', ('[B]Options[/B]', 'RunPlugin(%s)' % options_params)])
			cm_append(['playback_options', ('[B]Play Options[/B]', 'RunPlugin(%s)' % playback_options_params)])
			if belongs_to_movieset == 'true' and not self.movieset_list_active and not self.open_movieset:
				browse_movie_set_params = self.build_url({'mode': 'build_movie_list', 'action': 'tmdb_movies_sets', 'key_id': movieset_id,
										'name': movieset_name, 'is_external': self.is_external})
				cm_append(['browse_movie_set', ('[B]Browse Movie Set[/B]', self.window_command % browse_movie_set_params)])
			else: browse_movie_set_params = ''
			cm_append(['recommended', ('[B]Browse Recommended[/B]', self.window_command % browse_recommended_params)])
			cm_append(['related', ('[B]Browse Related[/B]', self.window_command % browse_related_params)])
			cm_append(['more_like_this', ('[B]Browse More Like This[/B]', self.window_command % browse_more_like_this_params)])
			cm_append(['similar', ('[B]Browse AI Similar[/B]', self.window_command % browse_similar_params)])
			cm_append(['in_trakt_list', ('[B]In Trakt Lists[/B]', self.window_command % browse_in_trakt_list_params)])
			cm_append(['trakt_manager', ('[B]Trakt Lists Manager[/B]', 'RunPlugin(%s)' % trakt_manager_params)])
			cm_append(['personal_manager', ('[B]Personal Lists Manager[/B]', 'RunPlugin(%s)' % personal_manager_params)])
			url_parm['mode'] = 'tmdblists_manager_choice'
			cm_append(['tmdb_manager', ('TMDb Lists Manager', 'RunPlugin(%s)' % self.build_url(url_parm))])
			url_parm['mode'] = 'favorites_choice'
			cm_append(['favorites_manager', ('[B]Favorites Manager[/B]', 'RunPlugin(%s)' % self.build_url(url_parm))])
			if playcount:
				if self.widget_hide_watched: return
				cm_append(['mark_watched', ('[B]Mark Unwatched %s[/B]' % self.watched_title, 'RunPlugin(%s)' % self.build_url({'mode': 'watched_status.mark_movie', 'action': 'mark_as_unwatched', 'tmdb_id': tmdb_id, 'title': title}))])
			elif not unaired:
				cm_append(['mark_watched', ('[B]Mark Watched %s[/B]' % self.watched_title, 'RunPlugin(%s)' % self.build_url({'mode': 'watched_status.mark_movie', 'action': 'mark_as_watched', 'tmdb_id': tmdb_id, 'title': title}))])
			if progress:
				cm_append(['mark_watched', ('[B]Clear Progress[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'watched_status.erase_bookmark', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'refresh': 'true'}))])
				set_properties({'WatchedProgress': progress})
			if self.is_external:
				cm.extend([['refresh', ('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'refresh_widgets'}))],
						['reload', ('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'kodi_refresh'}))]])
			else: cm_append(['exit', ('[B]Exit Movie List[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'navigator.exit_media_menu'}))])
			cm = self.sort_context_menu(cm)
			meta.update({'playcount': playcount, 'playback_percent': progress, 'cast': cast})
			listitem = set_info(listitem, meta, {'imdb': imdb_id, 'tmdb': str_tmdb_id}, progress)
			listitem.setLabel(title)
			listitem.addContextMenuItems(cm)
			listitem.setArt({'poster': poster, 'fanart': fanart, 'icon': poster, 'clearlogo': clearlogo, 'landscape': landscape, 'thumb': thumb})
			set_properties({
				'belongs_to_collection': belongs_to_movieset,
				'infinite.extras_params': extras_params,
				'infinite.options_params': options_params,
				'infinite.playback_options_params': playback_options_params,
				'infinite.browse_movie_set_params': browse_movie_set_params,
				'infinite.browse_recommended_params': browse_recommended_params,
				'infinite.browse_related_params': browse_related_params,
				'infinite.browse_more_like_this_params': browse_more_like_this_params,
				'infinite.browse_similar_params': browse_similar_params,
				'infinite.browse_in_trakt_list_params': browse_in_trakt_list_params,
				'infinite.trakt_manager_params': trakt_manager_params,
				'infinite.personal_manager_params': personal_manager_params,
				'infinite.tmdb_manager_params': tmdb_manager_params,
				'infinite.favorites_manager_params': favorites_manager_params
				})
			if self.fromtmbd: self.append((url_params, listitem, False))
			else:self.append(((url_params, listitem, False), _position))
		except: logger(f'build_movie_content _id: {_id} meta: {meta}\nError: {print_exc()}')#pass

	def worker(self):
		if self.custom_order:
			threads = TaskPool().tasks(self.build_movie_content, self.list)
			[i.join() for i in threads]
		else:
			threads = TaskPool().tasks_enumerate(self.build_movie_content, self.list)
			[i.join() for i in threads]
			self.items.sort(key=lambda k: k[1])
			self.items = [i[0] for i in self.items]
		return self.items

	def sort_context_menu(self, context_menu_items):
		if self.perform_cm_sort:
			try: context_menu_items = sorted([i for i in context_menu_items if i[0] in self.cm_sort_order], key=lambda k: self.cm_sort_order[k[0]])
			except: pass
		return [i[1] for i in context_menu_items]

	def paginate_list(self, data, page_no):
		if paginate(self.is_external):
			limit = page_limit(self.is_external)
			data, total_pages = paginate_list(data, page_no, limit, self.paginate_start)
			if self.is_external: self.paginate_start = limit
		else: total_pages = 1
		return data, total_pages
