# -*- coding: utf-8 -*-

from urllib.parse import parse_qsl
from modules.kodi_utils import external, get_property, logger


def sys_exit_check():
	if get_property('infinite.reuse_language_invoker') == 'false': return False
	return external()

def routing(sys):
	params = dict(parse_qsl(sys.argv[2][1:], keep_blank_values=True))
	_get = params.get
	# logger(f'params>>>> {params}')
	mode = _get('mode', 'navigator.main')
	if 'navigator.' in mode:
		from indexers.navigator import Navigator
		return exec('Navigator(params).%s()' % mode.split('.')[1])
	elif 'menu_editor.' in mode:
		from modules.menu_editor import MenuEditor
		return exec('MenuEditor(params).%s()' % mode.split('.')[1])
	elif 'personal_lists.' in mode:
		from indexers import personal_lists
		return exec('personal_lists.%s(params)' % mode.split('.')[1])
	elif 'tmdblist.' in mode:
		from indexers import tmdb_lists
		return exec('tmdb_lists.%s(params)' % mode.split('.')[1])
	elif 'playback.' in mode:
		from modules.kodi_utils import player_check
		return player_check(mode, params)
	elif 'choice' in mode:
		from indexers import dialogs
		return exec('dialogs.%s(params)' % mode)
	elif 'custom_key.' in mode:
		from modules import custom_keys
		return exec('custom_keys.%s()' % mode.split('custom_key.')[1])
	elif 'trakt.' in mode:
		if '.list' in mode:
			from indexers import trakt_lists
			return exec('trakt_lists.%s(params)' % mode.split('.')[2])
		else:
			from apis import trakt_api
			return exec('trakt_api.%s(params)' % mode.split('.')[1])
	elif 'build' in mode:
		if mode == 'build_movie_list':
			from indexers.movies import Movies
			return Movies(params).fetch_list()
		elif mode == 'build_tvshow_list':
			from indexers.tvshows import TVShows
			return TVShows(params).fetch_list()
		elif mode == 'build_season_list':
			from indexers.seasons import build_season_list
			return build_season_list(params)
		elif mode == 'build_episode_list':
			from indexers.episodes import build_episode_list
			return build_episode_list(params)
		elif mode == 'build_in_progress_episode':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.progress', params)
		elif mode == 'build_recently_watched_episode':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.recently_watched', params)
		elif mode == 'build_next_episode':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.next', params)
		elif mode == 'build_my_calendar':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.trakt', params)
		elif mode == 'build_next_episode_manager':
			from modules.episode_tools import build_next_episode_manager
			return build_next_episode_manager()
		elif mode == 'build_tmdb_people':
			from indexers.people import tmdb_people
			return tmdb_people(params)
		elif mode == 'build_imdb_list':
			from indexers.personal_lists import build_imdb_list
			return build_imdb_list(params)
		elif 'random.' in mode:
			from indexers.random_lists import RandomLists
			return RandomLists(params).run_random()
	elif 'watched_status.' in mode:
		if mode == 'watched_status.mark_episode':
			from modules.watched_status import mark_episode
			return mark_episode(params)
		elif mode == 'watched_status.mark_season':
			from modules.watched_status import mark_season
			return mark_season(params)
		elif mode == 'watched_status.mark_tvshow':
			from modules.watched_status import mark_tvshow
			return mark_tvshow(params)
		elif mode == 'watched_status.mark_movie':
			from modules.watched_status import mark_movie
			return mark_movie(params)
		elif mode == 'watched_status.erase_bookmark':
			from modules.watched_status import erase_bookmark
			return erase_bookmark(params.get('media_type'), params.get('tmdb_id'), params.get('season', ''), params.get('episode', ''), params.get('refresh', 'false'))
		elif mode == 'watched_status.unmark_previous_episode':
			from modules.watched_status import unmark_previous_episode
			return unmark_previous_episode(params)
		elif mode == 'watched_status.extra':
			from modules.watched_status import mark_as_watched_unwatched_extra
			return mark_as_watched_unwatched_extra(params)
	elif 'search.' in mode:
		if mode == 'search.get_key_id':
			from modules.search import get_key_id
			return get_key_id(params)
		elif mode == 'search.clear_search':
			from modules.search import clear_search
			return clear_search()
		elif mode == 'search.remove':
			from modules.search import remove_from_search
			return remove_from_search(params)
		elif mode == 'search.clear_all':
			from modules.search import clear_all
			return clear_all(params.get('setting_id'), params.get('refresh', 'false'))
	elif 'tmdblist_api' in mode:
		if mode == 'tmdblist_api.authenticate':
			from openscrapers.modules.tmdb_utils import TMDbListAPI
			return TMDbListAPI().auth()
		elif mode == 'tmdblist_api.revoke_authentication':
			from openscrapers.modules.tmdb_utils import TMDbListAPI
			return TMDbListAPI().revoke()
	elif '_cache' in mode:
		from caches import base_cache
		if mode == 'clear_cache':
			return base_cache.clear_cache(params.get('cache'))
		elif mode == 'clear_all_cache':
			return base_cache.clear_all_cache()
		elif mode == 'clean_databases_cache':
			return base_cache.clean_databases()
		elif mode == 'check_databases_integrity_cache':
			return base_cache.check_databases_integrity()
		elif mode == 'resolveurl_cacheclear':
			from modules.kodi_utils import clear_cache_resolveurl
			return clear_cache_resolveurl()
	elif '_image' in mode:
		from indexers.images import Images
		return Images().run(params)
	elif '_text' in mode:
		from modules.kodi_utils import show_text
		if mode == 'show_text':
			return show_text(params.get('heading'), params.get('text', None), params.get('file', None),
							params.get('font_size', 'small'), params.get('kodi_log', 'false') == 'true')
		elif mode == 'show_text_media':
			return show_text(params.get('heading'), params.get('text', None), params.get('file', None), params.get('meta'), {})
	elif 'settings_manager.' in mode:
		from caches import settings_cache
		return exec('settings_cache.%s(params)' % mode.split('.')[1])
	elif 'downloader.' in mode:
		from modules import downloader
		return exec('downloader.%s(params)' % mode.split('.')[1])
	elif mode == 'download_and_watch':
		from modules.downloader import download_and_watch_runner
		return download_and_watch_runner(params)
	elif 'updater' in mode:
		from modules import updater
		return exec('updater.%s()' % mode.split('.')[1])
	##EXTRA modes##
	elif mode == 'set_view':
		from modules.kodi_utils import set_view
		return set_view(params.get('view_type'))
	elif mode == 'sync_settings':
		from caches.settings_cache import sync_settings
		return sync_settings(params)
	elif mode == 'person_direct.search':
		from indexers.people import person_direct_search
		return person_direct_search(params.get('key_id') or params.get('query'))
	elif mode == 'kodi_refresh':
		from modules.kodi_utils import kodi_refresh
		return kodi_refresh()
	elif mode == 'refresh_widgets':
		from modules.kodi_utils import refresh_widgets
		return refresh_widgets()
	elif mode == 'person_data_dialog':
		from indexers.people import person_data_dialog
		return person_data_dialog(params)
	elif mode == 'favorite_people':
		from indexers.people import favorite_people
		return favorite_people()
	elif mode == 'upload_logfile':
		from modules.kodi_utils import upload_logfile
		return upload_logfile(params)
	elif mode == 'downloader':
		from modules.downloader import runner
		return runner(params)
	elif mode == 'open_settings':
		from modules.kodi_utils import open_settings
		return open_settings()
	elif mode == 'hide_unhide_progress_items':
		from modules.watched_status import hide_unhide_progress_items
		return hide_unhide_progress_items(params)
	elif mode == 'external_scraper_settings':
		from modules.kodi_utils import external_scraper_settings
		return external_scraper_settings(params)
	elif mode == 'clean_settings':
		from modules.kodi_utils import clean_settings
		return clean_settings()
	elif mode == 'refresh_artwork':
		from modules.kodi_utils import refresh_artwork
		return refresh_artwork()
	elif 'myaccounts_sync' in mode: # myaccounts
		from modules.kodi_utils import sync_myaccounts
		return sync_myaccounts()
	elif mode == 'set_filter_sort':
		from indexers.dialogs import set_filter_sort
		return set_filter_sort(_get('settint_id'))
	elif '_select' in mode: # Context option Select or Rescrape episodes or Movies Sources
		from indexers.dialogs import clear_and_rescrape
		if mode == 'scrape_select': return clear_and_rescrape(params, False)
		elif mode == 'rescrape_select': return clear_and_rescrape(params)
	elif mode == 'vod_movies': # Scrape Indian Movies
		from indexers.desirulez import movies
		return movies(params)
	elif mode == 'vod_shows': # Scrape Hindi Shows
		from indexers.desirulez import tv_shows
		return tv_shows(params)
	elif mode == 'vod_episode': # Scrape Hindi episode
		from indexers.desirulez import tv_episo
		return tv_episo(params)
	elif mode == 'geetm':
		from indexers.elists import geetm_root
		return geetm_root(params)
	elif mode == 'geetm_list':
		from indexers.elists import get_song_list
		return get_song_list(params)
	elif mode == 'geetm_vid_list':
		from indexers.elists import get_yt_links
		return get_yt_links(params)
	elif mode == 'geetm_plvid':
		from modules.kodi_utils import kodi_player
		return kodi_player(_get('url'), _get('title'))
	elif 'ltv' in mode: # Live TV
		from indexers.elists import get_c_list
		return get_c_list(params)
	elif 'jsonlist' in mode: # Live TV
		from indexers.elists import dd_events_get
		return dd_events_get(params)
	elif mode == 'watchonline':
		from indexers.elists2 import root
		root(params)
	elif mode == 'watchonline_s':
		from indexers.elists2 import scrape_seasons
		return scrape_seasons(params)
	elif mode == 'watchonline_e':
		from indexers.elists2 import scrape_episodes
		return scrape_episodes(_get('url'))
	elif mode == 'watchonline_source':
		from indexers.elists2 import scrape_source
		return scrape_source(params)
	elif mode == 'watchonline_ltp':
		from indexers.elists2 import play
		return play(params)
	elif mode == 'docu':
		from indexers.elists2 import doc_root
		return doc_root(params)
	elif mode == 'docu_get_items':
		from indexers.elists2 import docu_list
		return docu_list(params)
	elif mode == 'docu_pls':
		from indexers.elists2 import docu_play
		return docu_play(params)
	elif mode == 'ltp_play':
		from indexers.elists import play
		return play(params)
	elif mode == 'tubi_main':
		from indexers.tubi import Channels
		return Channels.section_list(_get('rescrape'))
	elif 'tubi-content' in mode:
		from indexers.tubi import Channels
		return Channels.content_list(mode, _get('rescrape'))
	elif mode == 'tubi-search':
		from indexers.tubi import Channels
		return Channels.search_tubi()
	elif 'tubi-episodes' in mode:
		from indexers.tubi import Channels
		return Channels.episode_list(params)
	elif 'tubi_play' in mode:
		from indexers.tubi import Common
		return Common.play_tubi(params)
	elif mode == 'update_metadb': # update_metadb
		from modules.kodi_utils import update_metadb
		return update_metadb()
	elif 'testhindi' in mode: # for testing Mode
		from modules.testing_mod import testting
		return testting()
