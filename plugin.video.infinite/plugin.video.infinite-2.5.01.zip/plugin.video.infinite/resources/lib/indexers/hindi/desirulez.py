# -*- coding: utf-8 -*-

import json
import re
from traceback import print_exc

from urllib.parse import urlencode, urljoin

try:
    from modules.kodi_utils import logger, build_url, nextpage, set_info, make_listitem, add_items, set_content, end_directory, set_view_mode, get_infolabel, notification, external, set_category
    from caches.main_cache import main_cache
    from modules.watched_status import get_watched_info_movie, get_watched_status_movie, get_progress_percent, get_bookmarks, get_watched_info_tv, get_watched_status_episode
    from caches.settings_cache import get_setting
    thumb = 'https://i.imgur.com/p18A3dF.png'
    fanart = 'https://i.imgur.com/p18A3dF.png'  # 'https://i.imgur.com/aYEzi5o.jpg'
    opensettings_params = build_url({'mode': 'open_settings', 'query': '0.0'})
    old_hindi_shows = get_setting('infinite.old.hindi_shows', 'false') == 'true'
except:
    # logger(f'Error: {print_exc()}')
    from modules.utils import logger
    from modules.main_cache import main_cache

    old_hindi_shows = 'true'

from modules.dom_parser import parseDOM
from modules.hindi_utils import fetch_meta, gettmdb_id, request, get_int_epi, keepclean_title, get_episode_date, find_season_in_title, string_date_to_num, additional_title_cleaner

desirule_url = 'https://www.desirulez.cc:443'
run_plugin = 'RunPlugin(%s)'


def movies(params):
    # logger(f'from : movies params: {params}')
    def _process():
        for item in movies_data:
            # logger(f'desirulez _process item: {item}')
            try:
                listitem = make_listitem()
                set_properties = listitem.setProperties
                cm = []
                cm_append = cm.append
                title, year, meta = item['title'], item['year'], item['meta']
                meta_get = meta.get
                poster, tmdb_id = meta_get('poster'), meta_get('tmdb_id', item['tmdb_id'])
                imdb_id = meta_get('imdb_id', tmdb_id)
                playcount = get_watched_status_movie(watched_info, str(tmdb_id))
                progress = get_progress_percent(bookmarks, tmdb_id)
                # logger(f'from : _process tmdb_id: {tmdb_id} playcount: {playcount}')
                meta.update({'mediatype': 'movie', 'premiered': str(year), 'original_title': title, 'playcount': playcount, 'url': item['url'], 'fanart': poster, 'playback_percent': progress})
                meta_json = json.dumps(meta)
                setUniqueIDs = {'imdb': str(imdb_id), 'tmdb': str(tmdb_id)}
                listitem.setLabel(title.title())
                if 'Next Page:' in title:
                    url = build_url({'mode': 'vod_movies_list', 'list_name': params['list_name'], 'url': item['url'], 'pg_no': item['pg_no'], 'rescrape': 'false', 'iconImage': params['iconImage']})
                    listitem.setArt({'icon': nextpage, 'fanart': fanart})
                    set_properties({'SpecialSort': 'bottom', 'infinite_listitem_meta': meta_json})
                    listitem = set_info(listitem, meta, setUniqueIDs)
                    isfolder = True
                else:
                    url = build_url({'mode': 'playback.media', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'hindi_': 'true'})
                    cm_append(('Select Source', run_plugin % build_url({'mode': 'scrape_select', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'hindi_': 'true'})))
                    cm_append(('Rescrape & Select Source', run_plugin % build_url({'mode': 'rescrape_select', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'hindi_': 'true'})))
                    if progress:
                        cm_append(('[B]Clear Progress[/B]', run_plugin % build_url({'mode': 'watched_status.erase_bookmark', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'refresh': 'true'})))
                        set_properties({'WatchedProgress': progress})
                    if playcount: cm_append(('[B]Mark Unwatched Infinite[/B]', run_plugin % build_url({'mode': 'watched_status.mark_movie', 'action': 'mark_as_unwatched', 'tmdb_id': tmdb_id, 'title': title, 'year': year})))
                    else: cm_append(('[B]Mark Watched Infinite[/B]', run_plugin % build_url({'mode': 'watched_status.mark_movie', 'action': 'mark_as_watched', 'tmdb_id': tmdb_id, 'title': title, 'year': year})))
                    extras_params = {'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'movie', 'is_external': is_external}
                    cm_append(('[B]Extras[/B]', run_plugin % build_url(extras_params)))
                    cm_append(('[B]Open Settings[/B]', run_plugin % opensettings_params))
                    listitem.addContextMenuItems(cm)
                    listitem.setArt({'poster': poster, 'icon': poster, 'thumb': poster, 'clearart': poster, 'banner': '', 'fanart': fanart, 'clearlogo': '', 'landscape': ''})
                    listitem = set_info(listitem, meta, setUniqueIDs, progress)
                    set_properties({'infinite.extras_params': json.dumps(extras_params), 'infinite_listitem_meta': meta_json})
                    isfolder = False
                yield url, listitem, isfolder
            except: logger(f'desirulez movies {print_exc()}')

    cache_name = f'movies_{urlencode(params)}'
    movies_data = main_cache.get(cache_name)
    if not movies_data:
        if 'desirulez' in params['url']: movies_data = get_movies(params)
        else: movies_data = get_movies_desicinemas(params)
        if movies_data:
            main_cache.set(cache_name, movies_data, expiration=14)  # 14 days cache
    from sys import argv  # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    if movies_data:
        bookmarks = get_bookmarks(0, 'movie')
        watched_info = get_watched_info_movie(0)
        # logger(f'from movies len(bookmarks): {len(bookmarks)} bookmarks: {bookmarks}')
        # logger(f'from movies len(watched_info): {len(watched_info)} watched_info: {watched_info}')
        is_external = external()
        add_items(handle, list(_process()))
        set_content(handle, 'movies')
        set_category(handle, 'movies')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.movies', 'movies', is_external)
    else:
        notification(f'No movies Found for: :{params["list_name"]} Retry')
        end_directory(handle)
        return


def get_movies(params):
    non_str_list = ['+', 'season', 'episode']
    movies = results = next_p = []
    if movies_page := request(params['url']):
        results = parseDOM(movies_page, 'h3', attrs={'class': 'threadtitle'})
        next_p = parseDOM(movies_page, 'span', attrs={'class': 'prev_next'})
    for item in results:
        # logger(f'item: {item}')
        try:
            try: title = parseDOM(item, 'a', attrs={'class': 'title threadtitle_unread'})[0]
            except:
                title = parseDOM(item, 'a', attrs={'class': 'title'})
                title = title[0] if title else parseDOM(item, 'a')[0]
            # logger(f'title: {title} type(title): {type(title)}')
            try: parsed = re.compile(r'(.+) [{(](\d+|\w+ \d+|\w+)[})]').findall(str(title))[0]
            except: parsed = '', ''
            # logger(f'type title: {type(parsed[0])} parsed[0]: {parsed[0]} parsed[1] {parsed[1]}')
            title = parsed[0]
            year = parsed[1]
            if not re.search(r'\d{4}', year):
                try: year = re.search(r'\d{4}', title).group()
                except: year = 2022
            url = parseDOM(item, 'a', ret='href') or parseDOM(item, 'a', attrs={'class': 'title'}, ret='href')
            if isinstance(url, list) and len(url) > 0: url = str(url[0])
            url = url if url.startswith(desirule_url) else urljoin(desirule_url, url)
            if title and all(x not in title for x in non_str_list):
                title = keepclean_title(title)
                tmdb_id = gettmdb_id('movie', title, year, None)
                meta = fetch_meta(mediatype='movie', title=title, tmdb_id=tmdb_id, homepage=url, year=year)
                movies.append({'year': year, 'list_name': params['list_name'], 'url': url, 'tmdb_id': tmdb_id, 'meta': meta, 'pg_no': params['pg_no'], 'title': title})
        except: logger(f'desirulez get_movies {print_exc()}')

    if next_p:
        next_p_url = parseDOM(next_p, 'a', attrs={'rel': 'next'}, ret='href')[0]
        url = next_p_url.split('?')[0] if '?' in next_p_url else next_p_url
        try:
            pg_no = re.compile(r'page\d{1,2}').findall(url)[0]
            pg_no = pg_no.replace('page', '')
        except: pg_no = '1'
        title = f'Next Page: {pg_no}'
        if url.startswith('forumdisplay'): url = f'https://www.desirulez.cc:443/{url}'
        movies.append({'year': '', 'list_name': params['list_name'], 'url': url, 'tmdb_id': '', 'meta': {'poster': nextpage, 'plot': f'For More: {params["list_name"]} Movies Go To: {title}', 'genre': []}, 'pg_no': pg_no, 'title': title})
    # logger(f'len(movies): {len(movies)} movies :  {movies}')
    return movies


def get_movies_desicinemas(params):
    movies = results = next_p = []
    if movies_page := request(params['url']):
        # logger(f'movies_page: {movies_page}')
        # results = parseDOM(movies_page, 'div', attrs={'class': 'Main Container'})
        results = parseDOM(movies_page, 'li', attrs={'class': 'TPostMv post-.+?'})
        next_p = parseDOM(movies_page, 'div', attrs={'class': 'nav-links'})
    # logger(f'total episodes: {len(results)} results: {results}')
    # r = [(parseDOM(i, 'a', ret='href'), parseDOM(i, 'a', ret='title'), parseDOM(i, 'a')[0]) for i in results]
    for i in results:
        try:
            url = parseDOM(i, 'a', ret='href')[0]
            title = parseDOM(i, 'h2', attrs={'class': 'Title'})[0]
            try:
                year = parseDOM(i, 'span', attrs={'class': 'Qlty Yr'})[0] or parseDOM(i, 'span', attrs={'class': 'Date'})[0]
            except: year = 2023
            if '(Punjabi)' in title: continue
            if '(Marathi)' in title: continue
            title = keepclean_title(title)
            tmdb_id = gettmdb_id('movie', title, year, None)
            imgurl = parseDOM(i, 'img', ret='data-src')[0]
            Descri = parseDOM(i, 'div', attrs={'class': 'Description'})[0]
            plot = parseDOM(Descri, 'p')[0]
            genre = parseDOM(Descri, 'p', attrs={'class': 'Genre'})
            genre = parseDOM(genre, 'a')
            cast = parseDOM(Descri, 'p', attrs={'class': 'Cast'})
            cast = parseDOM(cast, 'a')
            meta = fetch_meta(mediatype='movie', title=title, tmdb_id=tmdb_id, homepage=url, poster=imgurl, year=year, plot=plot, genre=genre, cast=cast)
            movies.append({'year': year, 'list_name': params['list_name'], 'url': url, 'tmdb_id': tmdb_id, 'meta': meta, 'pg_no': params['pg_no'], 'title': title})
        except:
            logger(f'get_movies_desicinemas {print_exc()}')

    # logger(f'total movies: {len(movies)} next_p: {next_p}\nmovies: {movies}')
    if not movies: return
    if next_p:
        try:
            # next_p_u = parseDOM(next_p, 'a', attrs={'class': 'page-link'}, ret='href')[1]
            next_p_u = parseDOM(next_p, 'a', ret='href')[-1]
            pg_no = re.compile('/([0-9]+)/').findall(next_p_u)[0]
            title = f'Next Page: {pg_no}'
            movies.append({'year': '', 'list_name': params['list_name'], 'url': next_p_u, 'tmdb_id': '', 'meta': {'poster': nextpage, 'plot': f'For More: {params["list_name"]} Movies Go To: {title}', 'genre': ['-']}, 'pg_no': pg_no, 'title': title})
        except: logger(f'get_movies_desicinemas {print_exc()}')
    # logger(f'total movies: {len(movies)} movies: {movies}')
    return movies


def tv_shows(params):
    # logger(f'from : tv_shows params: {params}')
    b_url, list_name, iconImage = params['url'], params['list_name'], params['iconImage']
    cache_name = f'shows_{urlencode(params)}'
    shows = main_cache.get(cache_name)
    # logger(f'For shows: {shows} params: {params}')
    if not shows:
        if 'desirulez' in b_url: shows = get_tv_shows(params)
        elif 'yodesi' in b_url: shows = get_tv_shows_yo(params)
        else: shows = get_tv_shows_desitelly(params)
        if shows: main_cache.set(cache_name, shows, expiration=14)  # 14 days cache

    def _process():
        for item in shows:
            try:
                if old_hindi_shows == 'false' and '-archive' in item['url']:
                    # logger(f'meta For show old_hindi_shows: {old_hindi_shows} item[\'url\']: {item['url']}')
                    continue
                cm = []
                cm_append = cm.append
                title, meta = item['title'], item['meta']
                meta_get = meta.get
                # logger(f'meta For show title: {title} meta: {repr(meta)}')
                poster, tmdb_id, total_seasons, season, imdb_id = meta_get('poster', iconImage), meta_get('tmdb_id'), int(meta_get('seasons', 1)), meta_get('season', 1), meta_get('imdb_id')
                playcount = item['playcount'] if item.get('playcount', None) else 0
                meta.update({'mediatype': 'tvshow', 'playcount': playcount, 'original_title': title, 'season': season, 'total_seasons': total_seasons, 'url': item['url'], 'fanart': poster, 'premiered': str(meta_get('year'))})
                # logger(f'meta For show title: {title} info: {meta}')
                meta_json = json.dumps(meta)
                url = build_url({'mode': 'vod_tvepis_dr', 'title': title, 'list_name': list_name, 'url': item['url'], 'iconImage': poster, 'season': season, 'imdb_id': imdb_id, 'meta': meta_json, 'pg_no': '1', 'rescrape': 'false'})
                listitem = make_listitem()
                set_properties = listitem.setProperties
                listitem.setLabel(title.title())
                listitem.setArt({'icon': poster, 'poster': poster, 'thumb': poster, 'fanart': fanart, 'banner': poster})
                cm_append((f'[B]Reload[/B] {title.title()}', run_plugin % build_url({'mode': 'vod_tvepis_dr', 'title': title, 'list_name': list_name, 'url': item['url'], 'thumb': poster, 'meta': meta_json, 'pg_no': '1', 'rescrape': 'true'})))
                extras_params = {'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'tvshow', 'is_external': is_external}
                cm_append(('[B]Extras[/B]', run_plugin % build_url(extras_params)))
                cm_append(('[B]Add to a Shortcut Folder[/B]', run_plugin % build_url({'mode': 'menu_editor.shortcut_folder_add_item', 'name': title, 'iconImage': poster})))
                cm_append(('[B]Open Settings[/B]', run_plugin % opensettings_params))
                listitem.addContextMenuItems(cm, replaceItems=False)
                imdb_id = meta_get('imdb_id', tmdb_id)
                setUniqueIDs = {'imdb': str(imdb_id), 'tmdb': str(tmdb_id), 'tvdb': ''}
                listitem = set_info(listitem, meta, setUniqueIDs)
                set_properties({'infinite.extras_params': json.dumps(extras_params), 'totalepisodes': str(meta_get('episodes', '1')), 'totalseasons': str(total_seasons), 'infinite_listitem_meta': meta_json})
                yield url, listitem, True
            except: logger(f'desirulez tv_shows item: {item} Error: {print_exc()}')

    from sys import argv  # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    if shows:
        is_external = external()
        add_items(handle, list(_process()))
        set_content(handle, 'tvshows')
        set_category(handle, 'tvshows')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.main', 'tvshows', is_external)
    else:
        notification(f'No Shows Found for: {list_name} Retry or change the Hindi provider in setting.')
        end_directory(handle)
        return


def get_tv_shows(params):
    list_name, iconImage = params['list_name'], params['iconImage']
    shows = results = []
    if show_page := request(params['url']):
        results = parseDOM(show_page, 'figure', attrs={'class': 'gallery-item'})
    # results += parseDOM(show_page, 'li', attrs={'class': 'forumbit_post.+?'})
    # logger(f'items total: {len(results)} shows: {results}')
    for item in results:
        try: title = parseDOM(item, 'a')
        except:
            title = parseDOM(item, 'a', attrs={'class': 'title'})
            title = title or parseDOM(item, 'a')
        if isinstance(title, list): title = title[0]
        season = find_season_in_title(title)
        title = keepclean_title(title)
        url = parseDOM(item, 'a', ret='href') or parseDOM(item, 'a', attrs={'class': 'title'}, ret='href')
        if isinstance(url, list) and len(url) > 0: url = str(url[0])
        if 'Past Shows' not in title:
            genre = parseDOM(item, 'figcaption', attrs={'class': '.*?gallery-caption'})[0]
            imgurl = parseDOM(item, 'img', ret='src')
            try: imgurl = imgurl[0]
            except: imgurl = iconImage
            tmdb_id = gettmdb_id('tvshow', title, None, list_name)
            url = url if url.startswith(desirule_url) else urljoin(desirule_url, url)
            meta = fetch_meta(mediatype='tvshow', title=title, tmdb_id=tmdb_id, homepage=url, season=season, studio=list_name, poster=imgurl, genre=genre)
            shows.append({'url': url, 'title': title, 'list_name': list_name, 'tmdb_id': tmdb_id, 'meta': meta})
    # logger(f'len(shows): {len(shows)} shows :  {shows}')
    return shows


def get_tv_shows_yo(params):
    list_name, iconImage = params['list_name'], params['iconImage']
    shows = results = []
    if show_page := request(params['url']):
        rawResult = parseDOM(show_page, 'div', attrs={'id': 'content_box'})[0]
        # result = parseDOM(rawResult, 'div', attrs={'class': re.compile('^one_')})
        results = parseDOM(rawResult, 'div', attrs={'class': 'one_fourth  '})
        results += parseDOM(rawResult, 'div', attrs={'class': 'one_fourth  column-last '})
    # logger(f'results total: {len(results)} results: {results}')
    for item in results:
        title = parseDOM(item, 'p', attrs={'class': 'small-title'})[0]
        url = parseDOM(item, 'a', ret='href')[0]
        title = parseDOM(title, 'a')[0]
        season = find_season_in_title(title)
        title = keepclean_title(title)
        if 'concert' in title.lower(): continue
        if isinstance(url, list) and len(url) > 0: url = str(url[0])
        tmdb_id = gettmdb_id('tvshow', title, None, list_name)
        show = {'url': url, 'title': title, 'list_name': list_name, 'tmdb_id': f'{list_name}|{title.lower()}'}
        if '-archive' not in url:
            meta = fetch_meta(mediatype='tvshow', title=title, tmdb_id=tmdb_id, homepage=url, season=season, studio=list_name, poster=iconImage)
            show['meta'] = meta
            shows.append(show)
        if old_hindi_shows == 'true':
            meta = fetch_meta(mediatype='tvshow', title=title, tmdb_id=tmdb_id, homepage=url, season=season, studio=list_name, poster=iconImage)
            show['meta'] = meta
            shows.append(show)
    # logger(f'len(shows): {len(shows)} shows :  {shows}')
    return shows


def get_tv_shows_desitelly(params):
    b_url, list_name, iconImage = params['url'], params['list_name'], params['iconImage']
    shows = results = []
    if show_page := request(b_url):
        results = parseDOM(show_page, 'div', attrs={'class': 'vc_column_container col-md-3'})
        results += parseDOM(show_page, 'div', attrs={'class': 'vc_column_container col-md-4'})
    # logger(f'results shows: {results}')

    for i in results:
        if not i: continue
        url = parseDOM(i, 'a', ret='href')[0]
        imgurl = parseDOM(i, 'img', ret='src')
        try: imgurl = imgurl[0]
        except: imgurl = iconImage
        if 'www.desi-serials.cc' in b_url:
            if imgurl.startswith('/images'): imgurl = f'https://www.desi-serials.cc{imgurl}'
            try:
                title = parseDOM(i, 'a', attrs={'class': 'porto-sicon-title-link'})[0]
                title_overview = parseDOM(i, 'div', attrs={'class': 'porto-sicon-header'})[0]
                genre = re.findall(r'<\/h5>\s+(.+?)$', title_overview)
                # logger(f' 1 desi-serials: title: {title} genre: {genre}')
            except:
                title_overview = parseDOM(i, 'div', attrs={'class': 'porto-sicon-header'})[0]
                title_overview = re.findall(r'porto-sicon-title-link.+>(.+?)<\/a><\/h5>(.+?)$', title_overview)[0]
                title = title_overview[0]
                genre = title_overview[1]
                logger(f'2 desi-serials title: {title} genre: {genre} ')
        else:
            if imgurl.startswith('/images'): imgurl = f'https://playdesi.tv{imgurl}'
            genre = parseDOM(i, 'p')  #[0]
            title = parseDOM(i, 'h4', attrs={'class': 'porto-sicon-title'})[0]
        season = find_season_in_title(title)
        title = keepclean_title(title)
        tmdb_id = gettmdb_id('tvshow', title, None, list_name)
        # logger(f'get_tv_shows_desitelly: title: {title} genre: {genre}')
        meta = fetch_meta(mediatype='tvshow', title=title, tmdb_id=tmdb_id, homepage=url, season=season, studio=list_name, poster=imgurl, genre=genre)
        shows.append({'url': url, 'title': title, 'list_name': list_name, 'tmdb_id': tmdb_id, 'meta': meta})
    # logger(f'len(shows): {len(shows)} shows :  {shows}')
    return shows


def tv_episo(params):
    # logger(f'from : tv_episo params: {params}')
    def _process():
        for item in episodes_data:
            try:
                # logger(f'desirulez _process item: {item}')
                listitem = make_listitem()
                set_properties = listitem.setProperties
                cm = []
                cm_append = cm.append
                tmdb_id = f'{list_name}|{title.lower()}'
                season, poster, imdb_id = params_get('season', 1), params_get('iconImage', None), params_get('imdb_id', tmdb_id)
                int_epi, year, ep_name, premiered = item['episode'], item['year'], item['title'], item['premiered']
                # logger(f'title: {title} int_epi: {int_epi} ep_name: {ep_name}')
                meta.update({'mediatype': 'episode', 'trailer': '', 'premiered': premiered, 'episode': int_epi, 'year': year, 'ep_name': ep_name, 'url': item['url']})
                setUniqueIDs = {'imdb': str(imdb_id), 'tmdb': str(tmdb_id), 'tvdb': ''}
                listitem.setLabel(ep_name)
                if 'Next Page:' in ep_name:
                    url = build_url({'mode': 'vod_tvepis_dr', 'title': title, 'list_name': list_name, 'url': item['url'], 'iconImage': poster, 'meta': json.dumps(meta), 'pg_no': item['pg_no'], 'rescrape': 'false'})
                    item.update({'plot': f'For More:[CR]{title} [CR]Go To: {ep_name}'})
                    listitem.setArt({'icon': nextpage, 'fanart': fanart})
                    set_properties({'SpecialSort': 'bottom'})
                    listitem = set_info(listitem, item, setUniqueIDs)
                    isfolder = True
                else:
                    # logger(f'tmdb_id: {repr(tmdb_id)} season: {repr(season)} , int_epi: {repr(int_epi)}')
                    playcount = get_watched_status_episode(watched_info, tmdb_id, int(season), int(int_epi))
                    progress = get_progress_percent(bookmarks, tmdb_id, int(season), int(int_epi))
                    # logger(f'tmdb_id: {tmdb_id} playcount: {playcount}')
                    meta.update({'playcount': playcount, 'playback_percent': progress})
                    meta_json = json.dumps(meta)
                    # logger(f'desirulez tv_episo _process meta_json: {meta_json}')
                    url = build_url({'mode': 'playback.media', 'media_type': 'episode', 'tmdb_id': tmdb_id, 'tvshowtitle': title, 'season': season, 'episode': int_epi, 'ep_name': ep_name, 'hindi_': 'true'})
                    cm_append(('Select Source', run_plugin % build_url({'mode': 'scrape_select', 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': int_epi, 'ep_name': ep_name, 'hindi_': 'true'})))
                    cm_append(('Rescrape & Select Source', run_plugin % build_url({'mode': 'rescrape_select', 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': int_epi, 'ep_name': ep_name, 'hindi_': 'true'})))
                    cm_append(('[B]Open Settings[/B]', run_plugin % opensettings_params))
                    # logger(f'desirulez _process progress: {repr(progress)} playcount: {repr(playcount)} ep_name: {ep_name}')
                    if progress:
                        cm_append(('[B]Clear Progress[/B]', run_plugin % build_url({'mode': 'watched_status.erase_bookmark', 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': int_epi, 'refresh': 'true'})))
                        set_properties({'WatchedProgress': progress})
                    if playcount: cm_append(('[B]Mark Unwatched Infinite[/B]', run_plugin % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_unwatched', 'tmdb_id': tmdb_id, 'tvdb_id': '', 'season': season, 'episode': int_epi, 'title': title})))
                    else: cm_append(('[B]Mark Watched Infinite[/B]', run_plugin % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_watched', 'tmdb_id': tmdb_id, 'tvdb_id': '', 'season': season, 'episode': int_epi, 'title': title})))
                    listitem.addContextMenuItems(cm)
                    listitem.setArt({'poster': poster, 'fanart': fanart, 'icon': poster, 'thumb': poster, 'clearart': poster, 'banner': '', 'clearlogo': '', 'landscape': ''})
                    listitem = set_info(listitem, meta, setUniqueIDs, progress)
                    isfolder = False
                list_items_append({'listitem': (url, listitem, isfolder), 'display': ep_name})
            except: logger(f'desirulez tv_episo item: {item} Error: {print_exc()}')

    from sys import argv  # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    list_items = []
    list_items_append = list_items.append
    url, rescrape, meta, title, list_name = params['url'], params['rescrape'], params['meta'], params['title'], params['list_name']
    meta = json.loads(meta)
    params_get = params.get
    cache_name = f'episodes_{urlencode({"url": url, "pg_no": params["pg_no"]})}'
    if rescrape == 'true':
        main_cache.delete(cache_name)
        episodes_data = None
    else:
        episodes_data = main_cache.get(cache_name)
    if not episodes_data:
        if 'desirulez' in url: episodes_data = get_tv_episo(params)
        elif 'yodesi' in url: episodes_data = get_tv_episo_yo(params)
        elif 'playdesi' in url or 'serials' in url: episodes_data = get_tv_episo_desitelly(params)
        if episodes_data: main_cache.set(cache_name, episodes_data, expiration=0.75)  # 12 hrs cache
    # logger(f'len(episodes_data): {len(episodes_data)} episodes_data: {episodes_data}')
    if episodes_data:
        bookmarks = get_bookmarks(0, 'episode')
        watched_info = get_watched_info_tv(0)
        # logger(f'from tv_episo len(bookmarks): {len(bookmarks)} bookmarks: {bookmarks}')
        # logger(f'from tv_episo len(watched_info): {len(watched_info)} watched_info: {watched_info}')
        _process()
        if 'Episode' in list_items[0]['display']: list_items.sort(key=lambda x: x['display'])
        # logger(f'len(list_items): {len(list_items)} list_items: {list_items}')
        item_list = [i['listitem'] for i in list_items]
        is_external = external()
        add_items(handle, item_list)
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.episode_lists', 'episodes', is_external)
    else:
        notification(f'No Episode Found for: {title} Retry or change the Hindi provider in setting.')
        end_directory(handle)
        return


def get_tv_episo(params):
    try:
        url, title, list_name, pg_no = params['url'], params['title'], params['list_name'], params['pg_no']
        # logger(f'title: {title} url: {url}')
        episo_page = request(url)
        results = parseDOM(episo_page, 'div', attrs={'class': 'post-details'})
        # results += parseDOM(episo_page, 'h3', attrs={'class': 'threadtitle'})
        episodes = []
        for item in results:
            ep_name = parseDOM(item, 'a', attrs={'class': 'title'})
            ep_name += parseDOM(item, 'a')
            if isinstance(ep_name, list): ep_name = ep_name[0]
            url = parseDOM(item, 'a', ret='href')
            if isinstance(url, list): url = url[0]
            if 'Online' not in ep_name: continue
            if title != 'Awards': ep_name = get_episode_date(ep_name, title)
            if '?' in url: url = url.split('?')[0]
            url = url if url.startswith(desirule_url) else urljoin(desirule_url, url)
            int_epi, year = get_int_epi(ep_name)
            premiered = string_date_to_num(ep_name)
            episodes.append({'url': url, 'title': ep_name, 'list_name': list_name, 'episode': int_epi, 'premiered': premiered, 'year': int(year), 'pg_no': pg_no})

        if next_p := parseDOM(episo_page, 'div', attrs={'class': 'pages-nav'}):
            if next_p_url := next_pagination_dict(next_p, title, list_name):
                episodes.append(next_p_url)
        # logger(f'len(episodes): {len(episodes)} episodes :  {episodes}')
        return episodes
    except: logger(f'get_tv_episo episodes {print_exc()}')


def get_tv_episo_yo(params):
    try:
        url, title, list_name, pg_no = params['url'], params['title'], params['list_name'], params['pg_no']
        # logger(f'title: {title} url: {url}')
        episo_page = request(url)
        results = parseDOM(episo_page, 'article')
        # logger(f'total episodes: {len(results)} result: {results}')
        episodes = []
        for item in results:
            if 'promo' in item or '(Day' in item: continue
            item = parseDOM(item, 'h2')[0]
            ep_name = parseDOM(item, 'a', ret='title')
            if isinstance(ep_name, list): ep_name = ep_name[0]
            url = parseDOM(item, 'a', ret='href')
            if isinstance(url, list): url = url[0]
            if 'Online' not in ep_name: continue
            ep_name = get_episode_date(ep_name, title)
            int_epi, year = get_int_epi(ep_name)
            premiered = string_date_to_num(ep_name)
            episodes.append({'url': url, 'title': ep_name, 'list_name': list_name, 'episode': int_epi, 'premiered': premiered, 'year': int(year), 'pg_no': pg_no})
        if next_p := parseDOM(episo_page, 'div', attrs={'class': 'nav-links'}):
            if next_p_url := next_pagination_dict(next_p, title, list_name):
                episodes.append(next_p_url)
        # logger(f'len(episodes): {len(episodes)} episodes :  {episodes}')
        return episodes
    except: logger(f'get_tv_episo_yo episodes {print_exc()}')


def get_tv_episo_desitelly(params):
    try:
        url, title, list_name, pg_no = params['url'], params['title'], params['list_name'], params['pg_no']
        episo_page = request(url)
        # logger(f'episo_page: {episo_page}')
        results = parseDOM(episo_page, 'div', attrs={'class': 'main-content col-lg-9'}) or parseDOM(episo_page, 'div', attrs={'class': 'blog-posts posts-large posts-container'})
        # logger(f'results: {results}')
        results = parseDOM(results, 'h2', attrs={'class': 'entry-title'})
        # logger(f'total episodes: {len(results)} results: {results}')
        episodes = []
        for i in results:
            url = parseDOM(i, 'a', ret='href')[0]
            ep_name = parseDOM(i, 'a')[0]
            ep_name = additional_title_cleaner(ep_name)
            if 'watch online' in ep_name.lower() and 'episode' in ep_name.lower():
                if 'Awards' in title:
                    ep_name = ep_name.lower().replace('watch online', '').replace('hd', '').replace('telecast', '')
                    ep_name = ep_name.title()
                elif 'Episode' in ep_name: ep_name = get_episode_date(ep_name, title)
                if ep_name:
                    int_epi, year = get_int_epi(ep_name)
                    premiered = string_date_to_num(ep_name)
                    episodes.append({'url': url, 'title': ep_name, 'list_name': list_name, 'episode': int_epi, 'premiered': premiered, 'year': int(year), 'pg_no': pg_no})
        if next_p := parseDOM(episo_page, 'div', attrs={'class': 'pagination-wrap'}):
            if next_p_url := next_pagination_dict(next_p, title, list_name):
                episodes.append(next_p_url)
        # logger(f'len(shows): {len(episodes)} episodes :  {episodes}')
        return episodes
    except: logger(f'get_tv_episo_desitelly episodes {print_exc()}')


def next_pagination_dict(next_p, title, list_name):
    if next_p_u := parseDOM(next_p, 'a', attrs={'class': 'next page-numbers'}, ret='href'):
        next_p_url = next_p_u[0]
    elif next_p_u := parseDOM(next_p, 'a', attrs={'class': 'pages-nav-item'}, ret='href'):
        next_p_url = next_p_u[0]
    else: next_p_url = ''
    # logger(f'{repr(next_p_url)}')
    if next_p_url:
        pg_no = re.compile('/([0-9]+)/').findall(next_p_url)[0] or re.compile(r'page\d{1,2}').findall(next_p_url)[0]
        name = f'Next Page: {pg_no}'
        return {'url': next_p_url, 'title': name, 'list_name': list_name, 'premiered': '', 'plot': f'For More {title} Go To {name} ....', 'episode': pg_no, 'season': 0, 'year': 0, 'pg_no': pg_no, }
    else: return