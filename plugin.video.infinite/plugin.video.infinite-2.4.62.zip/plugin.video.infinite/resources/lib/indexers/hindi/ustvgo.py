# -*- coding: utf-8 -*-

import datetime
import base64
import binascii
import hashlib
import random
import re
import traceback
import requests
import json
from urllib.parse import quote_plus, urljoin

try:
    from indexers.hindi.live_client import scrapePage, agent, R_Session, pyaes
    from modules.kodi_utils import notification, logger, build_url, set_info, make_listitem, add_items, set_content, end_directory, set_view_mode, get_infolabel, addon_icon, execute_builtin
    from caches.h_cache import main_cache, cache_object
except:
    from modules.live_client import scrapePage, agent, read_write_file, R_Session, pyaes
    from modules.utils import logger
    from modules.h_cache import main_cache, cache_object
    addon_icon = ''

from modules.dom_parser import parseDOM


def ustv_root(params):
    base_link = 'https://123tv.live'
    uri = 'https://raw.githubusercontent.com/djp11r/repo_n/mayb/etc/allxml/tv123_channels.json'
    if params['list_name'] == 'ustv247':
        base_link = 'https://ustv247.tv'
        uri = 'https://raw.githubusercontent.com/djp11r/repo_n/mayb/etc/allxml/ustv247_channels.json'
    elif params['list_name'] == 'ustvgo':
        base_link = 'https://ustvgo.tv'
        # uri = 'https://raw.githubusercontent.com/djp11r/repo_n/mayb/etc/allxml/ustvgo_new.json'
        uri = 'https://raw.githubusercontent.com/djp11r/repo_n/mayb/etc/allxml/ustvgo_channels.json'
    cache_name = 'content_%s' % params['list_name']
    if params['rescrape'] == 'true':
        main_cache.delete(cache_name)
        list_data = None
    else: list_data = main_cache.get(cache_name)
    if not list_data:
        data = scrapePage(uri).text
        list_data = json.loads(data)
        # logger(f"new list_data: {list_data}")
        if list_data: main_cache.set(cache_name, list_data, expiration=datetime.timedelta(hours=168))

    from sys import argv  # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    # list_data = sorted(list_data, key=lambda k: k['ch_no'])
    add_items(handle, list(_process(list_data, base_link)))
    set_content(handle, 'episodes')
    end_directory(handle)
    # set_view_mode('view.episodes', 'episodes')


def _process(list_data, base_link):
    for item in list_data:
        # logger(f"desirulez _process item: {item}")
        try:
            listitem = make_listitem()
            cm = []
            cm_append = cm.append
            title = item['title']
            url = item['url']
            thumb = item.get('image')
            if thumb in ('', None): thumb = addon_icon
            if not url.startswith('http'): url = f'{base_link}{url}'
            url_params = {'mode': item['mode'], 'title': title, 'url': url}
            url = build_url(url_params)
            options_params = {'mode': 'options_menu_choice', 'suggestion': title, 'play_params': json.dumps(url_params)}
            cm_append(("[B]Options...[/B]", f'RunPlugin({build_url(options_params)})'))
            cm_append(("[B]Add to a Shortcut Folder[/B]", 'RunPlugin(%s)' % build_url({'mode': 'menu_editor.shortcut_folder_add_item', 'name': title, 'iconImage': thumb})))
            listitem.setLabel(title)
            listitem.addContextMenuItems(cm)
            listitem.setArt({'thumb': thumb})
            item.update({'imdb_id': title, 'mediatype': 'episode', 'episode': 1, 'season': 0})
            setUniqueIDs = {'imdb': str(title)}
            listitem = set_info(listitem, item, setUniqueIDs)
            yield url, listitem, False
        except: logger(f'item: {item} ---USTVgo _process - Exception: {traceback.print_exc()}')
    return


def retrieve_new_token(argf=None):
    renew_token_node = 'https://ustvgo.tv/data.php'
    renew_token_node_post_data = {"stream": "NFL"}
    # logger("retrieve_new_token Working some black magic..")
    stream_url = requests.post(renew_token_node, headers={"User-Agent": agent()}, data=renew_token_node_post_data, ).text
    # auth_token = stream_url.split("wmsAuthSign=")[1]
    # logger("stream_url: %s"% stream_url)
    result = re.compile('https://(.+?)/.+?wmsAuthSign=(.+?)$', re.MULTILINE | re.DOTALL).findall(stream_url)
    # logger("auth_token: %s"% result)
    return {"cdn_nodes": result[0][0], "auth_token": result[0][1]}


def play(params):
    # logger(f"params : {params}")
    title = params['title']
    # auth_token = cache_object(function=retrieve_new_token, string='content_list_ustvgo_auth_token', url='', json=False, expiration=3)
    auth_token = retrieve_new_token()
    try:
        if title == "The Weather Channel": link = params['url']
        else: link = params['vid_url'] % (auth_token['cdn_nodes'], auth_token['auth_token'])
        link = f'{link}|User-Agent={agent()}&Referer={params["url"]}'
        logger(f"ltp_ustv play link: {link}")
        from modules.player import infinitePlayer
        infinitePlayer().run(link, 'video', {'title': title})
    except:
        # auth_token = cache_object(function=retrieve_new_token, string='content_list_ustvgo_auth_token', url='', json=False, expiration=0.1)
        logger(f'---USTVgo - Exception: {traceback.print_exc()}')
        notification('USTVgo - VPN Locked Or The Code Has Changed:', 2000)
    return


def play_old(params):
    try:
        # logger(f"params : {params}")
        title = params['title']
        url = params['url']
        headers = {'User-Agent': agent(), 'Referer': base_link}
        link = scrapePage(url, headers=headers).text
        # link = base_link + str([item for item in re.findall("<iframe src='(.+?)'", link)][0].split("'")[0])
        # link = str([item for item in re.findall("<iframe src='(.+?)'", link)][0].split("'")[0])
        link = parseDOM(link, 'iframe', ret='src')[0]
        # logger("link: %s"% link)
        if not link.startswith('http'): link = urljoin(base_link, link)
        # logger("link: %s"% link)
        link = scrapePage(link, headers=headers).text
        try:
            # code = link[link.find("encrypted"):]
            # code = code[:code.find("</script>")]
            # file_code = re.findall(r"file.+", code)[0]
            # file_code = "var link = " + file_code[file_code.find(":") + 1: file_code.find(",")]
            # code = code[:code.find("var player")]
            # code = code + file_code
            # crypto_min = base_link + "/Crypto/crypto.min.js"
            # addional_code = scrapePage(crypto_min, headers = headers).text
            # code = addional_code + code
            # context = js2py.EvalJs(enable_require=True)
            # link = context.eval(code)
            # logger('link1: %s' % link.replace("\r","").replace("\n",""))
            # link = ''.join(['{}'.format(line.rstrip('\n')) for line in str(link)])
            # link = link.replace("\r","").replace("\n","")
            # logger(f'link2: {link}')
            # logger("code: %s"% link)
            # code = re.findall(r'atob\(\'(.+?)\'', link)
            code = re.findall(r'var hls_src=\'(.+?)\';', link)
            # logger("urls: %s"% code)
            # link = base64.b64decode(code[0])
            # if not isinstance(link, str):
            # link = link.decode('utf-8')
            link = f'{code[0]}|User-Agent={agent()}&Referer={base_link}'
            # logger(f"link to play: {link}")
            from modules.player import infinitePlayer
            infinitePlayer().run(link, 'video', {'title': title})
        except:
            notification('USTVgo - VPN Locked Or The Code Has Changed:', 900)
    except:
        logger(f'---USTVgo - Exception: \n{traceback.print_exc()}\n')
        notification('USTVgo - Exception:', 900)


def get_dict_per_name(list_of_dict, key_value):
    my_item = None
    for item in list_of_dict:
        if item['title'] == key_value:
            my_item = item
            list_of_dict.remove(my_item)
            break
    return list_of_dict, my_item


def get_ch_data():
    uri = "https://bitbucket.org/jai_s/repojp/raw/HEAD/etc/allxml/ustvgo_new.json"
    data = scrapePage(uri).text
    list_of_dict = json.loads(data)
    ch_lists = []
    result = scrapePage(base_link).text
    # read_write_file(file_n='ustv.html', read=False, result=result)
    # result = read_write_file(file_n='ustv.html')
    ch_url = re.findall('<li><strong><a href="(.+?)">(.+?)</a>', result)
    # logger(f">>> nos of url : {len(ch_url)}")
    ch_no = 3
    for item in ch_url:
        # logger(f">>> nos of item : {item}")
        ch_name = item[1].replace('#038;', '').replace('&amp;', '&').replace('Animal', 'Animal Planet').replace('CW', 'The CW').strip()
        # ch_name = ch_name.replace('Animal', 'Animal Planet').replace('CW', 'The CW').strip()
        list_of_dict, ch_dict = get_dict_per_name(list_of_dict, ch_name)
        # logger(f">>> item: {ch_dict}")
        if ch_name == 'FoxNews': ch_no = 1
        elif ch_name == 'FoxBusiness': ch_no = 2
        else: ch_no += 1

        if ch_dict:
            ch_dict.update({'url': item[0], 'ch_no': ch_no})
            ch_lists.append(ch_dict)
        else:
            result = scrapePage(item[0]).text
            # read_write_file(file_n='ustv2.html', read=False, result=result)
            # result = read_write_file(file_n='ustv2.html')
            ch_stub = re.findall(r'<iframe src=[\'|"]\/clappr\.php\?stream=(.+?)[\'|"] allowfullscreen', result)
            if ch_stub: vid_url = f'https://%s/{ch_stub[0]}/myStream/playlist.m3u8?wmsAuthSign=%s'
            else: vid_url = "https://%s/Boomerang/myStream/playlist.m3u8?wmsAuthSign=%s"
            ch_lists.append({'ch_no': ch_no, 'action': 'ltp_ustv', 'poster': '', 'title': ch_name, 'url': item[0], 'vid_url': vid_url})
    # logger(f">>> nos of item in local but not found new : {len(list_of_dict)} list_of_dict: {list_of_dict}")
    ch_lists += list_of_dict
    ch_lists = sorted(ch_lists, key=lambda k: k['ch_no'])
    # ch_lists = json.loads(str(ch_lists))
    # logger(f">>> list_of_dict: {json.dumps(ch_lists)}")
    # logger(f">>> nos of item in ch_lists : {len(ch_lists)}")
    return ch_lists


def play123(params):
    # logger(f"params : {params}")
    title = params['title']
    # auth_token = cache_object(function=retrieve_new_token, string='content_list_ustvgo_auth_token', url='', json=False, expiration=3)
    link = retrieve_stream_url(params['url'])
    try:
        logger(f"ltp_ustv play link: {link}")
        execute_builtin('PlayMedia(%s)' % link)
        # from modules.player import infinitePlayer
        # infinitePlayer().run(link, 'video', {'title': title})
    except:
        # auth_token = cache_object(function=retrieve_new_token, string='content_list_ustvgo_auth_token', url='', json=False, expiration=0.1)
        logger(f'---USTVgo - Exception: {traceback.print_exc()}')
        notification('USTVgo - VPN Locked Or The Code Has Changed:', 2000)
    return


def append_headers(headers):
    return '%s' % '&'.join([f'{key}={quote_plus(headers[key])}' for key in headers])


def retrieve_stream_url(url, max_retries: int = 1):
    """Retrieve stream URL from web player with retries."""
    if not url.startswith('http'): url = 'https://123tv.live/watch/' + url
    timeout, max_timeout = 4, 10
    USER_AGENT = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                  '(KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36')
    HEADERS = {'User-Agent': USER_AGENT}
    # print(f'url: {url}')
    # return

    def extract_obfuscated_link(content: str) -> str:
        """Extract and decode obfuscated stream URL from 123TV channel page."""
        start_text = """
                    var post_id = parseInt($('#'+'v'+'i'+'d'+'eo'+'-i'+'d').val());
                    $(document).ready(function(){
                """

        data_part, key = '', ''
        # content = content.replace("\'", '')
        try:
            # ob_line = content[content.index(start_text) + len(start_text):].splitlines()[0]
            content = re.split(r'var\spost_id\s*=\s*parseInt', content)
            # logger(f'content: {repr(content)}')
            ob_line = re.findall(r'(?<=\.ready\(function\(\){)(.*?)(?=var options)', content[1], re.DOTALL)[0]
            # logger(f'ob_line: {repr(ob_line)}')
            items = ob_line.split('};')
            # logger(f'items: {repr(items)}')
            a, b, c = ob_line.split('};')
        except (ValueError, IndexError):
            logger(f'ValueError extract_obfuscated_link content: {repr(content)}')
            return ''

        # logger(f'a: {repr(a)}\nb: {repr(b)}\nc: {repr(c)}')
        # Parse data
        arr = re.search(r'(?<=\[)[^\]]+(?=\])', a)
        # logger(f'arr: {repr(arr)}')
        if arr:
            for part in arr.group().split(','):
                data_part += part.strip('\'')

        # logger(f'data_part: {repr(data_part)}')
        try:
            data = json.loads(base64.b64decode(data_part))
        except (binascii.Error, json.JSONDecodeError): return ''

        # logger(f'data: {repr(data)}')
        # Parse key
        for arr in re.findall(r'(?<=\[)[\d+\,]+(?=\])', b):
            for dig in arr.split(','):  # type: ignore
                key = chr(int(dig)) + key
        # logger(f'key: {repr(key)}')
        # Decode playlist data
        data['iterations'] = 999 if data['iterations'] <= 0 else data['iterations']
        dec_key = hashlib.pbkdf2_hmac('sha512', key.encode('utf8'), bytes.fromhex(data['salt']),
                data['iterations'], dklen=256 // 8)
        # logger(f'dec_key: {repr(dec_key)}')
        aes = pyaes.AESModeOfOperationCBC(dec_key, iv=bytes.fromhex(data['iv']))
        ciphertext = base64.b64decode(data['ciphertext'])
        # logger(f'ciphertext: {repr(ciphertext)}')
        decrypted = b''
        for idx in range(0, len(ciphertext), 16):
            decrypted += aes.decrypt(ciphertext[idx: idx + 16])
        # logger(f'decrypted: {repr(decrypted)}')
        target_link: str = pyaes.util.strip_PKCS7_padding(decrypted).decode('utf8')
        # logger(f'target_link: {repr(target_link)}')
        path = re.search(r'(?<=\')\S+(?=\';}$)', c)
        # logger(f'path: {repr(path)}')
        if path: target_link += path.group()
        # logger(f'>>> target_link: {repr(target_link)}')
        return target_link

    def retrieve_regular_channel(html_content: str, url=url) -> bool:
        iframe_match = re.search(r'"(?P<iframe_url>https?://.*?\.m3u8\?embed=true)"', html_content)
        if not iframe_match: return False
        # Get channel playlist URL
        headers = {**HEADERS, 'Referer': url}
        embed_url = iframe_match.group('iframe_url')
        # logger(f'embed_url: {embed_url}')
        with session.get(url=embed_url, timeout=timeout, headers=headers) as response:
            html_frame = response.text
            # logger(f'html_frame: {html_frame}')
            playlist_match = re.search(r'\'(?P<playlist_url>https?://.*?\.m3u8)\'', html_frame)
            # logger(f'playlist_match: {playlist_match}')
            if not playlist_match: return False
            # Check if it's a valid playlist
            if playlist_match:
                playlist_url = playlist_match.group('playlist_url')
                # logger(f'playlist_url: {playlist_url}')
                referer_url = 'http://azureedge.xyz/'
                headers = {**HEADERS, 'Referer': referer_url}
                if playlist_url: return f'{playlist_url}|{append_headers(headers)}'
        return False

    def retrieve_obfuscated_channel(html_content: str, url=url) -> bool:
        decoded_url = extract_obfuscated_link(html_content)
        if not decoded_url: return False
        referer_url = url.rstrip('/') + '/'
        headers = {**HEADERS, 'Referer': referer_url}
        # logger(f'referer_url: {referer_url} decoded_url: {decoded_url}')
        with session.get(url=decoded_url, timeout=timeout, headers=headers) as response:
            master_playlist_obj = response.json()
            # logger(f'master_playlist_obj: {master_playlist_obj}')
            master_playlist_url = master_playlist_obj[0]['file']
            if master_playlist_url: return f'{master_playlist_url}|{append_headers(headers)}'
            # with session.get(url=master_playlist_url, timeout=timeout, headers=headers) as response:
                # master_playlist_content = response.text
                # logger(f'master_playlist_content: {master_playlist_content}')
                # playlist_match = re.search(r'(?P<playlist_url>^[^#].*\.m3u8.*$)', master_playlist_content, re.M)
                # if playlist_match:
                    # playlist_url = playlist_match.group('playlist_url')
                    # if playlist_url: return f'{playlist_url}|{append_headers(headers)}'
        return False

    while True:
        try:
            session = R_Session()
            html_content = scrapePage(url).text
            #read_write_file(file_n='list_data/123live.html', read=False, result=html_content)
            # logger(f'html_content: {repr(html_content)}')
            for retriever in (retrieve_regular_channel, retrieve_obfuscated_channel):
                stream_url = retriever(html_content, url=url)
                if stream_url: return stream_url
            # logger(f'No stream URL found for channel "{url}".')
            return None
        except Exception as e:
            timeout = min(timeout + 1, max_timeout)
            max_retries -= 1
            if max_retries <= 0:
                logger(f'After max_retries: {max_retries} Failed to retrieve channel ({url}).')
                logger(f'No stream URL found for channel Error: "{e}"')
                raise
