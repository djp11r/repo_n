# -*- coding: utf-8 -*-
import time
from traceback import print_exc
from xbmcgui import Dialog, INPUT_NUMERIC
from windows.base_window import BaseDialog
from modules.kodi_utils import logger
from modules.notroparser import enable_show, updateSkip as updateSkip_database


class Skip(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.closed, self.selected = False, 'close'
		self.window_style, self.skip_option = kwargs.get('window_style', '0'), kwargs.get('skip_option')
		self.focus_button, self.skip_win_time, self.skip_win_no = kwargs.get('focus_button', 201), kwargs.get('skip_win_time', 300), kwargs.get('skip_win_no', 1)
		self.test = kwargs.get('test', False)
		self.media_type = kwargs.get('media_type', 'movie')
		self.a_skip_t = int(self.skip_option.get('skip')) + int(self.skip_option.get('start')) - 2
		self.skipLabel = 'Skip to End:'
		self.start_time = time.time()
		self.set_properties()

	def onInit(self):
		try: self.setFocusId(self.focus_button)
		except: pass
		self.monitor()

	def run(self):
		self.doModal()
		self.clearProperties()
		return self.selected

	def skip_close_dialogs(self):
		self.closed = True
		self.close()

	def onAction(self, action):
		if action in self.closing_actions:
			self.skip_close_dialogs()

	def onClick(self, controlID):
		if controlID == 201:
			self.selected = 'True'
			try:
				if self.window_style == 'end_skip': self.player.stop()
				else: self.player.seekTime(self.player.getTime() + self.act_skip_time)
			except: pass
			self.skip_close_dialogs()
		elif controlID == 202:
			try:
				self.player.pause()
				updateskip_data(self.skip_option)
				self.player.pause()
			except: pass
		elif controlID in self.closing_actions: self.skip_close_dialogs()

	def set_properties(self):
		self.setProperty('skip.window_style', str(self.window_style))
		if self.window_style != 'end_skip': self.skipLabel = f'SKIP INTRO: {self.skip_win_no}~{self.skip_option.get("skip", "0")}'
		self.setProperty('skip_title', self.skipLabel)
		self.setProperty('update_skip', 'Update skip: ')
		self.setProperty('media_type', self.media_type)

	def monitor(self):
		try:
			if self.test: return
			while not self.player.isPlayingVideo():
				self.skip_close_dialogs()
				self.sleep(1000)
			total_time = self.player.getTotalTime()
			end_close = total_time - 4
			while self.player.isPlaying():
				try:
					if self.closed: break
					current_time = self.player.getTime()
					elapsed_time = max((time.time() - self.start_time), 0)
					if float(current_time) >= float(self.skip_win_time) or float(current_time) >= float(end_close): self.skip_close_dialogs()
					if self.window_style == 'end_skip':
						self.act_skip_time = self.skip_win_time - 3
						self.setProperty('skip_title', f'Skip to End: {int(total_time - current_time)}')
					else:
						if self.skip_win_no == 1 and self.window_style != 'end_skip':
							if current_time > self.a_skip_t: self.act_skip_time = 0
							else: self.act_skip_time = current_time + (self.a_skip_t - current_time)
						else: self.act_skip_time = int(self.skip_option.get('skip'))
						if self.media_type != 'movie': self.setProperty('update_skip', f'Update skip: {int(elapsed_time)}')
					# logger(f'1: {float(current_time) >= float(self.skip_win_time)} 2: {float(current_time) >= float(end_close)}')
					self.sleep(1000)
				except: pass
			if not self.player.isPlayingVideo(): self.skip_close_dialogs()
		except: self.skip_close_dialogs()

class UpdateSkip(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		""""""
		self.skip_option = kwargs['skip_option']

	def onInit(self):
		self.show_dialog()

	def run(self):
		self.doModal()

	def show_dialog(self):
		tvshow = self.skip_option.get('title')
		skip = int(self.skip_option.get('skip'))
		start = int(self.skip_option.get('start'))
		eskip = int(self.skip_option.get('eskip'))
		# logger(f"skip: {skip}")
		self.getControl(111).setLabel(f'Title: {tvshow}')
		if self.skip_option.get('service') == 'True': self.getControl(112).setSelected(True)
		else: self.getControl(112).setSelected(False)
		self.setFocus(self.getControl(114))
		self.getControl(113).setLabel(f'Skip old value   : {skip}')
		self.getControl(114).setLabel(f'{skip}')
		self.getControl(115).setLabel(f'Skip start value : {start}')
		self.getControl(116).setLabel(f'{start}')
		self.getControl(117).setLabel(f'Exit Skip value  : {eskip}')
		self.getControl(118).setLabel(f'{eskip}')

	def onClick(self, controlid):
		if controlid == 121:
			try:
				# logger(f"slider_305: {self.getControl(115).getInt()}")
				self.skip_option.update({'service': str(self.getControl(112).isSelected()), 'skip': f'{self.getControl(114).getLabel()}', 'start': f'{self.getControl(116).getLabel()}', 'eskip': f'{self.getControl(118).getLabel()}'})
				# logger(f"spincontrolex_302: {self.getControl(114).getLabel()}")
				# logger(f"slider_305: {self.skip_option}")
				updateSkip_database(self.skip_option)
				# logger(f"radiobutton_301: {self.getControl(301).isSelected()}")
			except: logger(f'Error: {print_exc()}')
			self.close()
		elif controlid in [114, 116, 118]:
			text = self.InputNos()
			if text is not None:
				self.getControl(controlid).setLabel(f'{str(text)}')
		elif controlid == 122:
			enable_show()
			self.close()

	def onAction(self, action):
		if action.getId() in self.closing_actions:
			self.close()

	def InputNos(self):
		dialog = Dialog()
		return dialog.input('Value in (seconds)', type=INPUT_NUMERIC)


def updateskip_data(skip_option=None):
	try:
		from windows.base_window import open_window
		open_window(('windows.skip', 'UpdateSkip'), 'skipupdate.xml', skip_option=skip_option)
	except: logger(f'Error: {print_exc()}')
