# -*- coding: utf-8 -*-

import json
import re
from traceback import print_exc
from modules.kodi_utils import logger, select_dialog
from caches.base_cache import skipintro_db


def clean_title(title):
    if title is None: return
    exctract_date = re.compile(r'(\d{1,2}[th|st|nd|rd]* [Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|August|Sep|September|Oct|October|Nov|November|Dec|December]* \d{2,4})', flags=re.I)
    season_episode_data = re.compile(r'[Ee]pisode.+?(\d+)|[Ee]p (\d+)|[Ee](\d+)|[sS]eason.+?(\d+)|[sS]eason(\d+)|[sS](\d+)|[Cc]hapter (\d+)', flags=re.I)
    ascii_char = re.compile(r'(\x9B|\x1B\[)[0-?]*[ -\/]*[@-~]', flags=re.I)
    non_ascii_char = re.compile(r'[^\x00-\x7f]', flags=re.I)
    color_data = re.compile(r'\[COLOR.+?\].+?\[\/COLOR\]|\(.*?\)+', flags=re.I)
    try:
        title = re.sub(color_data, '', title)  # remove date like [COLOR yellow]1x1[/COLOR] OR [COLOR cyan]July 10, 2017[/COLOR] or ( any thing( #)
        title = re.sub(exctract_date, '', title) # remove date like 18th April 2021
        title = re.sub(season_episode_data, '', title) # remove episode 12 or season 1 etc
        title = re.sub(ascii_char, '', title)  # remove ascii_char
        title = re.sub(non_ascii_char, '', title)  # remove non_ascii_char
        title = re.sub(r'&#(\d+);', '', title)
        title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
        title = title.replace('&quot;', '\"').replace('&amp;', '&')
        title = re.sub(r'([:;\-"\',!#`_.?~$@])', '', title) # remove all characters in bracket
        title = re.sub(r'\<[^>]*\>|\([^)]*\)', '', title) # remove in bracket like this <any thing> or (any thing)
        # title = re.sub(r'\n|([[].+?[]])|([(].+?[)])|\s(vs|v[.])\s|(:|;|-|"|,|\'|\_|\.|\?)|\(|\)|\[|\]|\{|\}|\s', '', title).lower()
        # title = re.sub(r'\n|([\[({].+?[})\]])|([:;\-"\',!_.?~$@])|\s', '', title)
        title = re.sub(r'\s+', ' ', title) # remove Multiple Spaces
        title = title.lower()
    except: pass
    return title.strip()


def get_json_data(json_data=None):
    if json_data:
        try:
            with open(skipintro_db, mode='w', encoding='utf-8') as file:
                json.dump(json_data, file) #, indent=2)
        except: return []
    else:
        try:
            with open(skipintro_db, mode='r', encoding='utf-8') as file:
                json_data = json.load(file)
            return json_data
        except: return []


def updateSkip(skip_option):
    logger(f'updateSkip skip_option: {skip_option}')
    json_data = get_json_data()
    for item in json_data:
        if item['title'] == skip_option.get('title'):
            item['service'] = skip_option.get('service')
            item['skip'] = skip_option.get('skip')
            item['eskip'] = skip_option.get('eskip')
            item['start'] = skip_option.get('start')
    get_json_data(json_data)


def newskip(title, keep):
    newIntro = {'title': title, 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '300'}
    if keep:
        data = get_json_data()
        data.append(newIntro)
        get_json_data(data)
    return newIntro


def enable_show():
    json_data = get_json_data()

    if choices_list := [item for item in json_data if item['service'] == 'False']:
        try:
            list_items = [{'line1': item['title'], 'line2': str(item)} for item in choices_list]
            kwargs = {'items': json.dumps(list_items), 'heading': 'Select item to Enable.', 'multi_line': 'true', 'narrow_window': 'true'}
            choice_option = select_dialog(choices_list, **kwargs)
            if choice_option is None: return
            # logger(f'enable_show after choice_option: {choice_option}')
            choice_option.update({'service': 'True'})
            # logger(f'enable_show after choice_option: {choice_option}')
            updateSkip(choice_option)
        except: logger(f'Error: {print_exc()}')

def get_skip_option(title, keep=False):
    title = clean_title(title)
    try:
        data = get_json_data()
        start = [i for i in data if i['title'] == title][0]
    except: start = newskip(title, keep)
    return start