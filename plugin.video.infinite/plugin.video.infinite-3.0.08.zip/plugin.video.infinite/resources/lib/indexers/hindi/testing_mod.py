# -*- coding: utf-8 -*-

import datetime
import time
from traceback import print_exc

from apis.trakt_api import trakt_sync_activities
from caches.base_cache import clean_databases, clrcache_version_update
from caches.main_cache import main_cache
from caches.settings_cache import get_setting
from modules.kodi_utils import close_all_dialog, select_dialog, confirm_dialog, logger, notification, ok_dialog, show_text, sleep, tmdb_default_api
from modules.metadata import tvshow_meta
from modules.watched_status import get_progress_percent
from modules.settings import auto_nextep_settings, get_folderscraper_info, mpaa_region
from windows.base_window import create_window, open_window
from windows.skip import updateskip_data
from modules.notroparser import get_skip_option
from modules.source_utils import external_sources, source_filters
from modules.utils import get_datetime
from scrapers import folders


def testting():
    test_window()


def test_window(win='infopop'):
    # tmdb_id = 'Sony|The Kapil Sharma Show Season 4'
    tmdb_id = 1433 # 'American Dad!'
    meta = tvshow_meta('tmdb_id', 1433, tmdb_default_api, mpaa_region, get_datetime())
    if win == 'nextep_win': # windows.next_episode <<<<<<<<<
        action = open_window(('windows.next_episode', 'NextEpisode'), 'next_episode.xml', meta=meta, default_action='cancel', test=True)
        if action in ('cancel', 'close'):
            skip_option = get_skip_option(meta.get('title'), True)
            action = open_window(('windows.skip', 'Skip'), 'skipmulti.xml', skip_option=skip_option, test=True, focus_button=201, window_style='end_skip')
    elif win == 'infopop': # windows.infopop <<<<<<<<<
        action = open_window(('windows.extras', 'Extras'), 'extras.xml', options_media_type=meta.get('media_type'), meta=meta, is_external='false')
    elif win in ('skip_win', 'updateskip', 'end_skip'): # windows.skip <<<<<<<<<<
        # logger(f'windowstyle: {windowstyle.lower()}')
        skip_option = get_skip_option(meta.get('title'), True)
        if win == 'updateskip': updateskip_data(skip_option)
        elif win == 'skip_win': action = open_window(('windows.skip', 'Skip'), 'skipmulti.xml', skip_option=skip_option, test=True, focus_button=201, media_type='episode', window_style=0)
        else: action = open_window(('windows.skip', 'Skip'), 'skipmulti.xml', skip_option=skip_option, test=True, focus_button=201, window_style='end_skip')
    elif win in ('playback', 'resolver', 'resume', 'progress'): # playback && resolver etc<<<<<<<
        # kwargs = {'meta': meta, 'text': 'ok i see', 'enable_buttons': True, 'true_button': 'Yes', 'false_button': 'No', 'focus_button': 11}
        kwargs = {'meta': meta, 'text': 'ok i see', 'enable_fullscreen': True}
        _threads = []
        start_time = time.time()
        scraper_timeout = int(get_setting('results.timeout', '30'))
        sleep_time = 100
        end_time = start_time + scraper_timeout
        from modules.kodi_utils import monitor
        if win in ('playback', 'resolver', 'resume'): progress_dialog = create_window(('windows.sources', 'SourcesPlayback'), 'sources_playback.xml', meta=meta)
        if win == 'progress': progress_dialog = create_window(('windows.progress', 'Progress'), 'progress.xml', heading='progress', icon=meta.get('poster'))
        Thread(target=progress_dialog.run).start()
        if win == 'resolver': progress_dialog.enable_resolver()
        if win == 'resume': progress_dialog.enable_resume(15)
        remaining_providers = ['freeworldnews.tv', 'playersb.com', 'vedshare.com', 'voeunblock8.com', 'youtu.be']
        try:
            while not progress_dialog.iscanceled() and not monitor.abortRequested():
                if progress_dialog.iscanceled(): break
                sources_total = sources_4k = sources_1080p = sources_720p = sources_sd = 5
                current_time = time.time()
                elapsed_time = current_time - start_time
                line1 = ', '.join(remaining_providers).upper()
                percent = int((elapsed_time / float(scraper_timeout)) * 100)
                try:
                    if win == 'playback': progress_dialog.update_scraper(sources_sd, sources_720p, sources_1080p, sources_4k, sources_total, line1, percent)
                    elif win == 'resolver': progress_dialog.update_resolver(percent=elapsed_time)
                    elif win == 'resume': progress_dialog.update_resumer()
                    elif win == 'progress': progress_dialog.update(percent=elapsed_time)
                except: pass
                sleep(10)
                # logger(f'percent: {percent} elapsed_time: {elapsed_time}')
                if percent >= 100: break
                if current_time >= end_time: break
        except: logger(f'error: {print_exc()}')
        progress_dialog.close()
        try: del monitor
        except: pass
    elif win == 'sources_results': # windows.select_ok <<<<<<<<<<<<
        results = [{'source': 'tvarticles', 'quality': 'SD', 'info': 'All part: Single', 'url': 'https://tvarticles.org/vidd.php?id=2239785', 'direct': False, 'name': 'The Kapil Sharma Show S1E226', 'name_info': '', 'display_name': 'The Kapil Sharma Show S1E226', 'provider_site': 'tvarticles', 'scrape_provider': 'external', 'extraInfo': 'All part: Single', 'module_path': 'openscrapers.sources_openscrapers.en.desiserials', 'size_label': None, 'size': 0, 'provider_rank': 2, 'quality_rank': 4 }, {'source': 'gdrive', 'name': 'Modern.Family.S11E08.720p.WEB-HD.x264-Pahe.in.mkv', 'name_info': '.720p.web.hd.x264.pahe.in.mkv.', 'quality': '720p', 'url': 'https://gd.djp97s.workers.dev/Modern.Family.S11E08.720p.WEB-HD.x264-Pahe.in.mkv', 'info': 'AVC | WEB | MKV', 'direct': True, 'size': 0.15, 'display_name': 'Modern Family S11E8', 'provider_site': 'gdrive', 'scrape_provider': 'external', 'extraInfo': 'AVC | WEB | MKV', 'module_path': 'openscrapers.sources_openscrapers.en.gdrive', 'size_label': '0.15 GB', 'provider_rank': 2, 'quality_rank': 3 }, {'source': 'mixdrop.co', 'quality': 'SD', 'info': 'MP4 | ', 'url': 'https://mixdrop.co/e/wn6dpeo6szdwlx', 'direct': False, 'name': 'Modern Family S11E8', 'name_info': '', 'display_name': 'Modern Family S11E8', 'provider_site': '123moviestv_me', 'scrape_provider': 'external', 'extraInfo': '', 'module_path': 'openscrapers.sources_openscrapers.en.123moviestv_me', 'size_label': None, 'size': 0, 'provider_rank': 2, 'quality_rank': 4 }]
        scraper_settings = {'highlight_type': 2, 'hoster_highlight': '', 'torrent_highlight': '', 'real-debrid': '', 'premiumize': '', 'alldebrid': '', 'rd_cloud': '', 'pm_cloud': '', 'ad_cloud': '', 'furk': '', 'easynews': '', 'folders': '', '4k': 'FFFF3334', '1080p': 'FFE6B800', '720p': 'FF3C9900', 'sd': 'FFCAFFFF'}
        action = open_window(('windows.sources', 'SourcesResults'), 'sources_results.xml', window_format='list', window_style='non_contrast', window_id=2000, results=results, meta=meta, scraper_settings=scraper_settings, prescrape=False, filters_ignored=False, uncached_results=[])
        if not action: close_all_dialog()
    elif win == 'select_ok_win': # windows.select_ok <<<<<<<<<<<<
        confirm_dialog()
        ok_dialog()
        show_text(heading='Infinite', text='ok i c')

def cache_test():
    # main_cache.clean_hindi_lists()
    # clrcache_version_update(clr_cache=True, clr_navigator=False)
    # status = trakt_sync_activities()
    # logger(f'status: {status}')
    from caches.navigator_cache import navigator_cache
    list_contents = []
    #navigator_cache.set_list('Most', 'shortcut_folder', list_contents)


def get_folders(mtype='episode'):
    folder_info, internal_scraper_names = get_folderscraper_info()
    # logger(f'folder_info: {folder_info}\ninternal_scraper_names: {internal_scraper_names}')
    prescrape_scrapers = []
    if mtype == 'movie':
        info = {'media_type': 'movie', 'title': 'Star Wars: The Last Jedi', 'year': '2017', 'tmdb_id': 181808, 'imdb_id': 'tt2527336', 'aliases': [{'title': 'Star Wars: Episode VIII', 'country': ''}, {'title': 'Star Wars: Episode VIII – The Last Jedi', 'country': ''}, {'title': 'The Last Jedi', 'country': ''}, {'title': 'Star Wars - The Last Jedi - 3D', 'country': ''}, {'title': 'Star Wars: Episode VIII - The Last Jedi: Legendary', 'country': ''}, {'title': 'Star Wars: Episode 8 - The Last Jedi', 'country': ''}, {'title': 'Star Wars Episode VIII - The Last Jedi', 'country': ''}, {'title': 'Star Wars: Episode VIII - The Last Jedi 3D', 'country': ''}, {'title': 'Star Wars։ Episode VIII - The Last Jedi', 'country': ''}, {'title': 'Star Wars 8 - The Last Jedi', 'country': ''}, {'title': 'Star Wars: Episode VIII - The Last Jedi', 'country': ''}, {'title': 'Star Wars։ The Last Jedi (Episode VIII)', 'country': ''}, {'title': 'TLJ', 'country': ''}, {'title': 'Star Wars: The Last Jedi', 'country': ''}, {'title': 'Star Wars: The Last Jedi US', 'country': ''}], 'season': None, 'episode': None, 'tvdb_id': 'None', 'ep_name': None, 'expiry_times': (336, 0, 0), 'total_seasons': 1}
        scrape_provider, scraper_name, folder_path = 'folder1', 'English Enet', 'smb://cp:srusty@ENET/Media/ENet/English Movies/'
    else:
        info = {'media_type': 'episode', 'title': '24', 'year': '2001', 'tmdb_id': 1973, 'imdb_id': 'tt0285331', 'aliases': [{'title': 'Twenty Four', 'country': ''}, {'title': '24: Live Another Day', 'country': ''}, {'title': '24', 'country': ''}, {'title': '24 US', 'country': ''}], 'season': 1, 'episode': 2, 'tvdb_id': 76290, 'ep_name': 'Day 1 12:00 A.M.-1:00 A.M.', 'expiry_times': (240, 720, 720), 'total_seasons': 9}
        info = {'media_type': 'episode', 'title': 'Mirzapur Season 2', 'year': '2024', 'tmdb_id': 'Amazon Prime|mirzapur season 2', 'imdb_id': 'None', 'aliases': [{'title': 'Mirzapur Season 2', 'country': '', 'url': ''}], 'season': 2, 'episode': 1, 'tvdb_id': 'Amazon Prime|mirzapur season 2', 'ep_name': 'Episode 1', 'expiry_times': (72, 72, 240), 'total_seasons': 1}
        scrape_provider, scraper_name, folder_path = 'folder2', 'Folder 2', 'smb://cp:srusty@ENET/Media/ENet/TV Shows/'
    folders_sraper = folders.source(scrape_provider, scraper_name, folder_path)
    results = folders_sraper.results(info)
    logger(f'folder_results: {results}')
    scraper_settings = {'highlight_type': 2, 'hoster_highlight': '', 'torrent_highlight': '', 'real-debrid': '', 'premiumize': '', 'alldebrid': '', 'rd_cloud': '', 'pm_cloud': '', 'ad_cloud': '', 'furk': '', 'easynews': '', 'folders': '', '4k': 'FFFF3334', '1080p': 'FFE6B800', '720p': 'FF3C9900', 'sd': 'FFCAFFFF'}
    if not results: notification('no result'); return
    action = open_window(('windows.sources', 'SourcesResults'), 'sources_results.xml',
            window_format='list', window_style='non_contrast', window_id=2000, results=results, meta=meta,
            scraper_settings=scraper_settings, prescrape=False, filters_ignored=False, uncached_torrents=[])
    if not action: close_all_dialog()

def get_next_ep():
    from modules.episode_tools import EpisodeTools
    nextep_settings = auto_nextep_settings('autoplay_nextep')
    # nextep_settings = {'scraper_time': 70, 'window_percentage': 10, 'alert_method': 0, 'default_action': 'play', 'use_chapters': True, 'play_type': 'autoscrape_nextep'}
    nextep_settings.update({'window_time': 100, 'play_type': 'autoplay_nextep'})
    logger(f'nextep_settings: {nextep_settings}')
    url_params = EpisodeTools(meta, nextep_settings).next_episode_info()
    logger(f'url_params: {url_params}')

def get_yt_dl():
    from modules.downloader import yt_dl
    yt_dl()

def get_sources():
    ret_all, media_type, vid_type = False, 'episode', None
    external_providers = external_sources(ret_all, media_type, vid_type)
    logger(f'external_sources: {len(external_providers)} :: {external_providers}')


def get_percent():
    watched_indicators = 1
    media_type = 'movie'
    tmdb_id = 1051
    season = episode = ''
    percent = get_progress_percent(get_bookmarks(watched_indicators, media_type), tmdb_id, season, episode)
    logger(f'percent: {percent}')