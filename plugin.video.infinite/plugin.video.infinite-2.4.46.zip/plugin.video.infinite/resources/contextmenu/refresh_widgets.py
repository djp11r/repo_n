# -*- coding: utf-8 -*-
from xbmc import executebuiltin

executebuiltin('RunAddon(plugin.video.infinite)')
executebuiltin('UpdateLibrary(video,special://skin/foo)')
