# -*- coding: utf-8 -*-
import time
from caches.external_cache import external_cache, sourcesstats
from caches.settings_cache import get_setting
from modules import kodi_utils, source_utils
logger = kodi_utils.logger
from traceback import print_exc
from modules.source_utils import get_host_dict

normalize, get_file_info, pack_enable_check, int_window_prop = source_utils.normalize, source_utils.get_file_info, source_utils.pack_enable_check, kodi_utils.int_window_prop
sleep, monitor, get_property, set_property, random = kodi_utils.sleep, kodi_utils.monitor, kodi_utils.get_property, kodi_utils.set_property, kodi_utils.random
json, Thread, notification, hide_busy_dialog = kodi_utils.json, kodi_utils.Thread, kodi_utils.notification, kodi_utils.hide_busy_dialog
pack_display = '%s (%s)'
pack_check = ('Season', 'Show')
host_dict = get_host_dict()
sd_check = ('SD', 'CAM', 'TELE', 'SYNC')
correct_pack_sizes = ('torrentio', 'elfhosted', 'selfhosted')

class source:
	def __init__(self, meta, source_dict, active_debrid, internal_scrapers, prescrape_sources, progress_dialog, disabled_ext_ignored=False):
		# logger(f'external source __init__: meta: {meta}\nsource_dict: {source_dict}\nactive_debrid: {active_debrid} internal_scrapers: {internal_scrapers} prescrape_sources: {prescrape_sources}\nprogress_dialog: {progress_dialog} disabled_ext_ignored: {disabled_ext_ignored}')
		self.scrape_provider = 'external'
		self.progress_dialog = progress_dialog
		self.meta = meta
		self.background = self.meta.get('background', False)
		self.active_debrid = active_debrid
		self.source_dict, self.host_dict = source_dict, host_dict
		self.sources, self.all_internal_sources, self.processed_internal_scrapers = [], [], []
		self.processed_internal_scrapers_append = self.processed_internal_scrapers.append
		self.internal_scrapers, self.prescrape_sources = internal_scrapers, prescrape_sources
		self.internal_activated, self.internal_prescraped = len(self.internal_scrapers) > 0, len(self.prescrape_sources) > 0
		self.processed_prescrape, self.threads_completed = False, False
		self.sleep_time = 100
		self.finish_early = get_setting('infinite.search.finish.early') == 'true'
		self.timeout = 60 if disabled_ext_ignored else int(get_setting('infinite.results.timeout', '20'))
		self.sources_total = self.sources_4k = self.sources_1080p = self.sources_720p = self.sources_sd = 0
		self.final_total = self.final_4k = self.final_1080p = self.final_720p = self.final_sd = 0
		self.count_tuple = (('sources_4k', '4K', self._quality_length), ('sources_1080p', '1080p', self._quality_length), ('sources_720p', '720p', self._quality_length),
							('sources_sd', '', self._quality_length_sd), ('sources_total', '', self.quality_length_final))
		self.count_tuple_final = (('final_4k', '4K', self._quality_length), ('final_1080p', '1080p', self._quality_length), ('final_720p', '720p', self._quality_length),
									('final_sd', '', self._quality_length_sd), ('final_total', '', self.quality_length_final))

	def results(self, info):
		# logger(f'>>> results info: {info}')
		if not self.source_dict: return
		try:
			self.media_type, self.tmdb_id, self.orig_title = info['media_type'], str(info['tmdb_id']), info['title']
			self.season, self.episode, self.total_seasons = info['season'], info['episode'], info['total_seasons']
			self.title, self.year = normalize(info['title']), info['year']
			ep_name, self.aliases = normalize(info['ep_name']), info['aliases']
			self.display_name, self.imdb_id, self.tvdb_id = self.meta['display_name'], str(info['imdb_id']), str(info['tvdb_id'])
			# logger(f'>>> results ep_name: {repr(self.display_name)} ep_name: {repr(ep_name)}')
			self.single_expiry, self.season_expiry, self.show_expiry = info['expiry_times']
			if self.media_type == 'movie':
				self.season_divider, self.show_divider = 0, 0
				self.title, self.tvshowtitle, self.total_seasons = self.title, None, None
			else:
				try:
					self.season_divider = [int(x['episode_count']) for x in self.meta['season_data'] if int(x['season_number']) == int(self.meta['season'])][0]
					self.show_divider = int(self.meta['total_aired_eps'])
				except: self.season_divider, self.show_divider = 1, 1
				self.title, self.tvshowtitle, self.total_seasons = ep_name, self.title, self.total_seasons
		except: return []
		return self.get_sources()

	def get_sources(self):
		def _scraperDialog():
			hide_busy_dialog()
			sleep(200)
			start_time = time.time()
			while not self.progress_dialog.iscanceled() and not monitor.abortRequested():
				try:
					alive_threads = [x.getName() for x in self.threads if x.is_alive()]
					if self.internal_activated or self.internal_prescraped: alive_threads.extend(self.process_internal_results())
					line1 = ', '.join(alive_threads).upper()
					percent = (max((time.time() - start_time), 0)/float(self.timeout))*100
					self.progress_dialog.update_scraper(self.sources_sd, self.sources_720p, self.sources_1080p, self.sources_4k, self.sources_total, line1, percent)
					if len(alive_threads) == 0: break
					if self.finish_early and percent >= 50 or len(self.sources) >= 40: break
					if percent >= 100: break
					sleep(self.sleep_time)
				except: logger(f'_scraperDialog Error: {print_exc()}')
			return
		def _background():
			sleep(1500)
			end_time = time.time() + self.timeout
			while time.time() < end_time:
				# alive_threads = [x for x in self.threads if x.is_alive()]
				sleep(1000)
				# if len(alive_threads) <= 5: return
				if len(self.sources) >= 100: return
		self.threads = []
		self.threads_append = self.threads.append
		if self.media_type == 'movie':
			#self.source_dict = [i for i in self.source_dict if i[1]().movie]
			Thread(target=self.process_movie_threads).start()
		else:
			#self.source_dict = [i for i in self.source_dict if i[1]().tvshow]
			self.season_packs, self.show_packs = [], []
			if self.season_packs:
				self.source_dict = [(i[0], i[1], '') for i in self.source_dict]
				pack_capable = []
				if pack_capable:
					self.source_dict.extend([(i[0], i[1], 'Season') for i in pack_capable])
					if self.show_packs: self.source_dict.extend([(i[0], i[1], 'Show') for i in pack_capable])
					random.shuffle(self.source_dict)
			Thread(target=self.process_episode_threads).start()
		if self.background: _background()
		else: _scraperDialog()
		# logger(f'get_sources b4 total return {len(self.sources)} self.sources: {self.sources}')
		current_results = list(self.sources)
		if current_results: Thread(target=sourcesstats, args=(self.source_dict, current_results)).start()
		return self.process_results(current_results) if current_results else []

	def process_movie_threads(self):
		for i in self.source_dict:
			provider, module = i[0], i[1]
			threaded_object = Thread(target=self.get_movie_source, args=(provider, module), name=provider)
			threaded_object.start()
			self.threads_append(threaded_object)
		self.threads_completed = True

	def process_episode_threads(self):
		for i in self.source_dict:
			provider, module = i[0], i[1]
			try: pack_arg = i[2]
			except: pack_arg = ''
			provider_display = pack_display % (i[0], i[2]) if pack_arg else provider
			threaded_object = Thread(target=self.get_episode_source, args=(provider, module, pack_arg), name=provider_display)
			threaded_object.start()
			self.threads_append(threaded_object)
		self.threads_completed = True

	def get_movie_source(self, provider, module):
		sources = external_cache.get(provider, self.media_type, self.tmdb_id, self.title, self.year, '', '')
		if sources is None:
			self.activate_display = True
			url = None
			try:
				url = module().movie(self.tmdb_id, self.title, self.title, self.aliases, self.year)
			except: logger(f'get_movie_source provider: {provider} module().movie Error: {print_exc()}')
			if url is None: return
			sources = module().sources(url, self.host_dict)
			expiry_hours = self.single_expiry if sources else 1
			if sources:
				sources = self.process_sources(provider, sources)
				external_cache.set(provider, self.media_type, self.tmdb_id, self.title, self.year, '', '', sources, expiry_hours)
		if sources:
			if not self.background: self.process_quality_count(sources)
			self.sources.extend(sources)

	def get_episode_source(self, provider, module, pack):
		# logger(f'get_episode_source provider: {provider} module: {module} pack: {pack}')
		if pack in pack_check:
			s_check = '' if pack == 'Show' else self.season
			e_check = ''
		else: s_check, e_check = self.season, self.episode
		sources = external_cache.get(provider, self.media_type, self.tmdb_id, self.tvshowtitle, self.year, s_check, e_check)
		if sources is None:
			self.activate_display = True
			url = None
			try:
				url = module().tvshow(self.imdb_id, self.tvdb_id, self.tvshowtitle, self.tvshowtitle, self.aliases, self.year)
			except: logger(f'get_episode_source provider: {provider} module().tvshow Error: {print_exc()}')
			if url is None: return
			try:
				url = module().episode(url, self.imdb_id, self.tvdb_id, self.title, self.year, self.season, self.episode)
			except: logger(f'get_episode_source provider: {provider} module().episode Error: {print_exc()}')
			if url is None: return
			if pack == 'Show':
				expiry_hours = self.show_expiry
				sources = module().sources_packs(url, self.host_dict, search_series=True, total_seasons=self.total_seasons)
			elif pack == 'Season':
				expiry_hours = self.season_expiry
				sources = module().sources_packs(url, self.host_dict)
			else:
				expiry_hours = self.single_expiry
				sources = module().sources(url, self.host_dict)
			if not sources: expiry_hours = 1
			if sources:
				sources = self.process_sources(provider, sources)
				external_cache.set(provider, self.media_type, self.tmdb_id, self.tvshowtitle, self.year, s_check, e_check, sources, expiry_hours)
		if sources:
			# logger(f'get_episode_source b4 provider: {provider} total return {len(sources)} sources: {sources}')
			if pack == 'Season': sources = [i for i in sources if 'episode_start' not in i or i['episode_start'] <= self.episode <= i['episode_end']]
			elif pack == 'Show': sources = [i for i in sources if i['last_season'] >= self.season]
			if not self.background: self.process_quality_count(sources)
			self.sources.extend(sources)

	def process_results(self, results):
		def _process_duplicates(all_results):
			unique_urls, unique_hashes = set(), set()
			unique_urls_add, unique_hashes_add = unique_urls.add, unique_hashes.add
			for provider in all_results:
				try:
					url = provider['url'].lower()
					if url not in unique_urls:
						unique_urls_add(url)
						if 'hash' in provider:
							if provider['hash'] not in unique_hashes:
								unique_hashes_add(provider['hash'])
								yield provider
						else: yield provider
				except: yield provider
		try:
			if not self.background and self.all_internal_sources: self.process_quality_count_final(self.all_internal_sources)
			final_results = list(_process_duplicates(results))
			# logger(f'process_results {len(results)} results: {results}')
			return final_results
		except: return results

	def process_sources(self, provider, sources):
		try:
			for i in sources:
				try:
					i_get = i.get
					size, size_label, divider = 0, None, None
					if 'hash' in i:
						_hash = i_get('hash').lower()
						i['hash'] = str(_hash)
					info = i_get('info') or ''
					if 'name' not in i: i.update({'name': self.display_name})
					if 'name_info' in i: quality, extraInfo = get_file_info(name_info=i_get('name_info'))
					else: quality, extraInfo = get_file_info(url=i_get('url'))
					quality = i_get('quality') or quality
					try:
						size = i_get('size')
						if 'package' in i and provider not in correct_pack_sizes:
							if i_get('package') == 'season': divider = self.season_divider
							else: divider = self.show_divider
							size = float(size) / divider
						size_label = '%.2f GB' % size
					except: pass
					extraInfo = extraInfo or info
					if not size: size = 0
					i.update({'scrape_provider': self.scrape_provider, 'extraInfo': extraInfo, 'provider_site': provider,
							'quality': quality, 'size_label': size_label, 'size': round(size, 2)})
				except: logger(f'process_sources i: {i}\nError: {print_exc()}')
		except: pass
		return sources

	def process_quality_count(self, sources):
		for item in self.count_tuple: setattr(self, item[0], getattr(self, item[0]) + item[2](sources, item[1]))

	def process_quality_count_final(self, sources):
		for item in self.count_tuple_final: setattr(self, item[0], getattr(self, item[0]) + item[2](sources, item[1]))

	def process_internal_results(self):
		if self.internal_prescraped and not self.processed_prescrape:
			self.all_internal_sources += self.prescrape_sources
			self.process_quality_count(self.prescrape_sources)
			self.processed_prescrape = True
		for i in self.internal_scrapers:
			win_property = get_property(int_window_prop % i)
			if win_property in ('checked', '', None): continue
			try: internal_sources = json.loads(win_property)
			except: continue
			set_property(int_window_prop % i, 'checked')
			self.all_internal_sources += internal_sources
			self.processed_internal_scrapers_append(i)
			self.process_quality_count(internal_sources)
		return [i for i in self.internal_scrapers if i not in self.processed_internal_scrapers]

	def _quality_length(self, items, quality):
		return len([i for i in items if i['quality'] == quality])

	def _quality_length_sd(self, items, dummy):
		return len([i for i in items if i['quality'] in sd_check])

	def quality_length_final(self, items, dummy):
		return len(items)
