# -*- coding: utf-8 -*-

import random
import re
import string
from json import dumps, loads
from sys import argv
from traceback import print_exc


# stream_plug = 'https://m7lib.dev/api/v1/channels/'
# explore_org_base = 'https://omega.explore.org/api/get_cam_group_info.json?id=79'
# tubi_tv_base = 'https://tubitv.com/oz'
try:
    from xbmcgui import INPUT_ALPHANUM
    from modules.player import infinitePlayer
    from modules.kodi_utils import logger, build_url, make_listitem, add_item, notification, dialog, set_info, set_resolvedurl, default_addon_fanart, add_items, set_content, end_directory, set_view_mode, get_infolabel, player, set_category, external, kodi_player, select_dialog
    from caches.main_cache import main_cache
    from modules.settings import get_git_url
    from modules.watched_status import get_media_info, get_progress_percent, get_watched_status
    from modules.source_utils import request
    testing = False
    git_url = get_git_url()
except:
    from modules.utils import logger
    from main_cache import main_cache
    testing, default_addon_fanart = True, ''
    git_url = 'https://raw.githubusercontent.com/djp11r/data_dir/may'
    from modules.hindi_utils import request
aicon = 'https://i.imgur.com/iOllLYX.png' # 'hindi_tubi.png')
run_plugin = 'RunPlugin(%s)'
item_cleaner = re.compile(r'espanol|Español|lgbt|Doblado|k_drama|cj_enm|ganadores_y_nominados|telenovelas_y_series|para_los_nios_y_familias', re.I)


def get_clean_title(title):
    title = title.replace('&amp;', '&').replace('-', '').replace('  ', ' ')
    return title.strip()

def get_skip_option(title):
    return {'title': title, 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '300'}

def get_itemtype(itemtype, duration):
    m_type = 'movie'
    if itemtype == 's': m_type = 'tvshow'
    elif itemtype == 'v':
        if duration <= 3650: m_type = 'episode'
    return m_type

def plot_clean(plot):
    return re.sub(r'([:;\-"\',!_.?~$@])', '', plot)


class LiveChannels:

    @staticmethod
    def channel_list():
        try:
            channels_list = main_cache.get('content_tubi_livech_root')
            if not channels_list:
                channels_list = Common.get_channels()
                if channels_list: main_cache.set('content_tubi_livech_root', channels_list, expiration=336) # 336 == 14 days cache

            # Generate Channel List
            # logger(f'LiveChannels channels_list {channels_list}')
            ch_slugs = ['bloomberg', 'cbs-sports-hq', 'pbs-kids', 'stirr-news-247', 'stirr-bloomberg-tv', 'stirr-law-crime', 'stirr-nasatv', 'stirr-comet', 'stirr-contv', 'stirr-comedy-dynamics', 'stirr-failarmy', 'stirr-afv', 'stirr-johnny-carson-tv', 'stirr-unsolved-mysteries', 'stirr-forensics-files', 'stirr-greatest-american-hero', 'stirr-wiseguy', 'stirr-the-commish', 'stirr-hunter', 'stirr-crime-story', 'stirr-filmrise-free-movies', 'stirr-stirr-movies', 'stirr-cinehouse', 'stirr-docurama', 'stirr-stirr-sports', 'stirr-edgesport', 'stirr-wpt', 'stirr-filmrise-classic-tv', 'stirr-american-classics', 'stirr-britcom', 'stirr-the-lucy-show', 'stirr-the-lone-ranger', 'stirr-stirr-westerns', 'stirr-movie-mix', 'stirr-stirr-comedy', 'stirr-stirr-documentaries', 'stirr-stirr-travel', 'vuit-investigate-tv', 'vuit-wgcl-atlanta-ga', 'vuit-wtvm-columbus-ga', 'vuit-wagt-augusta-ga', 'vuit-wrdw-augusta-ga', 'vuit-politics-uncut', 'vuit-walb-albany-ga', 'vuit-wtoc-savannah-ga', 'xumo-nbc-news-now', 'xumo-abc-news-live', 'xumo-cbs-news', 'xumo-comedy-dynamics', 'xumo-cinelife', 'xumo-docurama', 'pluto-tv-kids', 'pluto-tv-news', 'pluto-cnn', 'pluto-bloomberg-tv', 'pluto-classic-movies-channel', 'pluto-tv-action', 'pluto-tv-science', 'pluto-tv-animals', 'pluto-funny-af', 'pluto-tv-true-crime', 'pluto-buzzr', 'pluto-xive-tv', 'pluto-tv-travel', 'pluto-tv-history', 'pluto-tv-comedy', 'pluto-tv-romance', 'pluto-fox-sports', 'pluto-the-new-detectives', 'pluto-tv-thrillers', 'pluto-tv-drama', 'pluto-cmt-westerns', 'pluto-unsolved-mysteries', 'pluto-tv-sci-fi', 'pluto-tv-fantastic', 'pluto-british-tv', 'pluto-tv-documentaries', 'pluto-tv-spotlight', 'pluto-forensic-files', 'pluto-tv-military', 'pluto-weather-nation', 'pluto-tv-land-sitcoms', 'pluto-cold-case-files', 'pluto-tv-cult-films', 'pluto-tv-terror', 'pluto-bet-tv', 'pluto-comedy-central-tv', 'pluto-nick-jr-tv', 'pluto-tv-backcountry', 'pluto-paramount-movie-channel', 'pluto-doctor-who-classic', 'pluto-nfl-channel', 'pluto-tv-land-drama', 'pluto-american-gladiators', 'pluto-baywatch', 'pluto-tv-lives', 'pluto-cmt-tv', 'pluto-pga-tour', 'pluto-bein-sports-xtra', 'pluto-nbc-news-now', 'pluto-cops', 'pluto-blaze-live', 'pluto-johnny-carson-tv', 'pluto-stories-by-amc', 'pluto-the-walking-dead-esp', 'pluto-western-tv', 'pluto-cbs-sports-hq', 'pluto-csi', 'pluto-star-trek-1', 'pluto-tv-suspense', 'pluto-classic-tv-comedy', 'pluto-classic-tv-drama-ptv1', 'pluto-the-amazing-race', 'pluto-tv-drama-life', 'pluto-tv-crime-drama', 'pluto-90210', 'pluto-tv-crime-movies', 'pluto-tv-staff-picks', 'pluto-narcos', 'pluto-showtime-selects', 'pluto-dr-oz', 'pluto-bbc-home']
            Common.add_section('tubitv_livesearch', aicon, default_addon_fanart, 'Search Channel')
            for channel in channels_list:
                try:
                    if channel['slug'] in ch_slugs: Common.add_channel(f'{channel["slug"]}tubitv_liveget_channel', channel['poster'], default_addon_fanart, channel['title'], {}, True)
                except: logger(f'LiveChannels channel_list channel Error: {print_exc()}')
            handle = int(argv[1])
            set_content(handle, 'episodes')
            set_category(handle, 'episodes')
            end_directory(handle, cacheToDisc=True)
        except:
            logger(f'LiveChannels channel_list Error {print_exc()}')
            Common.dlg_failed('Oops something went wrong.')

    @staticmethod
    def search_list():
        try:
            # Generate Channel List from search query
            retval = dialog.input('Search...', type=INPUT_ALPHANUM)
            if retval and len(retval) > 0:
                search_list = main_cache.get(f'content_tubi_livech_search_{retval}')
                if not search_list:
                    search_list = Common.search_channels(retval)
                    if search_list: main_cache.set(f'content_tubi_livech_search_{retval}', search_list, expiration=14) # 336 == 14 days cache
                if len(search_list) > 0:
                    for channel in search_list:
                        Common.add_channel(f'{channel["slug"]}tubitv_liveget_channel', channel['poster'], default_addon_fanart, channel['title'], {}, True)
                    handle = int(argv[1])
                    is_external = external()
                    set_content(handle, 'episodes')
                    set_category(handle, 'episodes')
                    end_directory(handle, cacheToDisc=not is_external)
                    set_view_mode('view.episodes', 'episodes', is_external)
                else: Common.dlg_failed('No results.')
            else: Common.dlg_failed('Please enter something to search for.')
        except:
            logger(f'LiveChannels search_list Error {print_exc()}')
            Common.dlg_failed('Oops something went wrong.')

    @staticmethod
    def get_channel(params):
        try:
            title = params['title']
            mode = params['mode']
            mode = mode.split('tubitv_liveget_channel')[0]
            Common.get_stream_and_play(mode)
        except: logger(f'LiveChannels get_channel Error {print_exc()}')


class Channels:

    @staticmethod
    def section_list(rescrape):
        try:
            # Common.add_section('tubitv-search', aicon, default_addon_fanart, 'Search Tubi')
            # logger(f'section_list rescrape: {rescrape}')
            if rescrape == 'true': main_cache.delete_like('content_tubi_root%')
            section_list = main_cache.get('content_tubi_root')
            if not section_list:
                # logger(f'Updating section_list: {section_list}')
                section_list = Stream.get_tubi_tv_categories()
                if section_list: main_cache.set('content_tubi_root', section_list, expiration=336) # 14 days cache

            for category in section_list:
                try:
                    Common.add_section(f'{category["id"]}tubitv-content', category['poster'], default_addon_fanart, category['title'], category)
                except Exception as e: logger(f'Channels section_list category Error: {print_exc()}')
            handle = int(argv[1])
            is_external = external()
            set_content(handle, 'tvshows')
            set_category(handle, 'tvshows')
            end_directory(handle, cacheToDisc=not is_external)
            set_view_mode('view.tvshows', 'tvshows', is_external)
        except Exception as e:
            logger(f'Channels section_list Error {print_exc()}')
            Common.dlg_failed('Oops something went wrong.')

    @staticmethod
    def content_list(mode, rescrape):
        try:
            category = mode.split('tubitv-content')[0]
            cache_name = f'content_tubi_{category}'
            if rescrape == 'true': main_cache.delete_like(cache_name + '%')
            content_list = main_cache.get(cache_name)
            if not content_list:
                content_list = Stream.get_tubi_tv_content(category)
                if content_list: main_cache.set(cache_name, content_list, expiration=168)  # 7 days cache

            for entry in content_list:
                try:
                    if re.search(item_cleaner, str(entry)): continue
                    if entry['type'] == 'v': Common.add_channel(f'{entry["id"]}play-tubitv', entry['poster'], default_addon_fanart, entry['title'], entry, live=False)
                    elif entry['type'] == 's': Common.add_section(f'{entry["id"]}tubitv-episodes{category}', entry['poster'], default_addon_fanart, entry['title'], entry)
                except Exception as e: logger(f'Channels content_list entry Error {print_exc()}')
            handle = int(argv[1])
            is_external = external()
            set_content(handle, 'tvshows')
            set_category(handle, 'tvshows')
            end_directory(handle, cacheToDisc=not is_external)
            set_view_mode('view.tvshows', 'tvshows', is_external)
        except Exception as e:
            logger(f'Channels content_list mode: {mode} Error {print_exc()}')
            Common.dlg_failed('content_list Oops something went wrong.')

    @staticmethod
    def episode_list(params):
        try:
            show = params['title']
            mode = params['mode']
            mode = mode.split('tubitv-episodes')
            # logger(f'Channels episode_list mode {mode}')
            cache_name = f'episodes_{show}_tubi_{mode[1]}'
            episode_list = main_cache.get(cache_name)
            if not episode_list:
                episode_list = Stream.get_tubi_tv_episodes(mode, show)
                if episode_list: main_cache.set(cache_name, episode_list, expiration=72)  # 3 days cache

            if not episode_list: Common.dlg_failed('episode_list not avilable.')
            else:
                for entry in episode_list:
                    try: Common.add_channel(f'{entry["id"]}play-tubitv', entry['poster'], default_addon_fanart, entry['title'], entry, live=False)
                    except Exception as e: logger(f'Channels episode_list entry Error {print_exc()}')
            handle = int(argv[1])
            is_external = external()
            set_content(handle, 'episodes')
            set_category(handle, 'episodes')
            end_directory(handle, cacheToDisc=not is_external)
            set_view_mode('view.episodes', 'episodes', is_external)
        except Exception as e:
            logger(f'Channels episode_list Error {print_exc()}')
            Common.dlg_failed('episode_list Oops something went wrong.')

    @staticmethod
    def search_tubi():
        try:
            retval = dialog.input('Search Tubi', type=INPUT_ALPHANUM)
            if retval and len(retval) > 0:
                search_list = main_cache.get(f'content_tubi_search_{retval}')
                if not search_list:
                    search_list = Stream.get_tubi_tv_search(retval)
                    if search_list: main_cache.set(f'content_tubi_search_{retval}', search_list, expiration=336) # 336 == 14 days cache

                if len(search_list) > 1:
                    for entry in search_list:
                        try:
                            if re.search(item_cleaner, str(entry)): continue
                            if entry['type'] == 'v': Common.add_channel(f'{entry["id"]}play-tubitv', entry['poster'], default_addon_fanart, entry['title'], entry['meta'], live=False)
                            elif entry['type'] == 's': Common.add_section(f'{entry["id"]}tubitv-episodes', entry['poster'], default_addon_fanart, entry['title'], entry['meta'])
                        except Exception as e: logger(f'Channels search_tubi entry Error {print_exc()}')
                    handle = int(argv[1])
                    is_external = external()
                    set_content(handle, 'tvshows')
                    set_category(handle, 'tvshows')
                    end_directory(handle, cacheToDisc=not is_external)
                    set_view_mode('view.tvshows', 'tvshows', is_external)
                else: Common.dlg_failed('No results.')
            else: Common.dlg_failed('Please enter something to search for.')
        except Exception as e:
            logger(f'Channels search_tubi Error {print_exc()}')
            Common.dlg_failed('search_tubi Oops something went wrong.')

    @staticmethod
    def play_tubi(params):
        try:
            title = params['title']
            mode = params['mode']
            meta = params['meta']
            # logger(f'play_tubi:: meta: {meta}')
            stream_id = mode.split('play-tubitv')[0]
            Common.get_tubi_tv_stream(stream_id, meta)
        except Exception as e:
            logger(f'Channels play_tubi Error {print_exc()}')
            Common.dlg_failed('play_tubi Oops something went wrong.')


class Common:
    try:
        watched_info_movie, bookmarks_movie = get_media_info(0, 'movie', None, False)
        watched_info_episode, bookmarks_episode = get_media_info(0, 'episode', None, False)
    except:
        watched_info_movie, watched_info_episode, bookmarks_movie, bookmarks_episode = [], [], [], []
    # logger(f'Common watched_info: {watched_info_movie}\nbookmarks_movie: {bookmarks_movie}\nbookmarks_episode: {bookmarks_episode}')

    @staticmethod
    def dlg_failed(mode):
        notification(mode, time=2000)
        # exit()

    @staticmethod
    def random_generator(size=6, chars=string.ascii_uppercase + string.digits):
        # Added '# nosec' to suppress bandit warning since this is not used for security/cryptographic purposes.
        return ''.join(random.choice(chars) for _ in range(size))  # nosec

    @staticmethod
    # Parse string and extracts first match as a string
    # The default is to find the first match. Pass a 'number' if you want to match a specific match. So 1 would match
    # the second and so forth
    def find_single_match(text, pattern, number=0):
        try:
            matches = re.findall(pattern, text, flags=re.DOTALL)
            result = matches[number]
        except AttributeError: result = ''
        return result

    @staticmethod
    # Parse string and extracts multiple matches using regular expressions
    def find_multiple_matches(text, pattern):
        return re.findall(pattern, text, re.DOTALL)

    @staticmethod
    # Open URL
    def open_url(url):
        return request(url)

    @staticmethod
    # Available channels
    def get_channels():
        url = 'https://m7lib.dev/api/v1/channels/index.json'
        # logger(f'get_channels url: {url}')
        data = Common.open_url(url)
        return loads(data)

    @staticmethod
    def search_channels(query):
        url = 'https://tubitv.com/search/{query}'
        # logger(f'search_channels url: {url}')
        data = Common.open_url(url)
        return loads(data)

    @staticmethod
    def add_streams(streams):
        coll = []
        for stream in streams:
            icon = stream['icon']
            mode = stream['mode']
            u = f'{argv[0]}?mode={str(mode)}&pvr=.pvr'
            title = stream['title'] if stream['title'] is not None else stream['id']
            item = make_listitem()
            item.setLabel(str(title))
            item.setProperty('skipPlayCount', 'true')
            item.setProperty('IsPlayable', 'true')
            item.setContentLookup(False)
            item.setIsFolder(False)
            item.setArt({'thumb': icon, 'poster': icon})
            stream.update({'imdb_id': str(title), 'media_type': 'episode', 'episode': 1, 'season': 0})
            item = set_info(item, stream, {'imdb': str(title)})
            coll.append((u, item, False))
        return add_items(int(argv[1]), coll)

    @staticmethod
    def add_channel(mode, icon, fanart, title=None, meta=None, live=True):
        if meta is None: meta = {}
        title = str(title) if title is not None else str(mode)
        if icon == '': icon = aicon
        cm = []
        cm_append = cm.append
        meta_get = meta.get
        item = make_listitem()
        set_properties = item.setProperties
        item.setLabel(title)
        item.setArt({'thumb': icon, 'poster': icon, 'fanart': fanart})
        tmdb_id = str(meta_get('tmdb_id'))
        m_type, season, episode = meta_get('media_type') or meta_get('mediatype'), meta_get('season', ''), meta_get('episode', '')
        if m_type == 'movie': watched_info, bookmarks = Common.watched_info_movie, Common.bookmarks_movie
        else: watched_info, bookmarks = Common.watched_info_episode, Common.bookmarks_episode
        playcount = get_watched_status(watched_info, tmdb_id, season, episode)
        progress = get_progress_percent(bookmarks, tmdb_id, season, episode)
        # logger(f'get_channels tmdb_id: {tmdb_id} progress: {progress} playcount: {playcount}')
        meta.update({'title': title, 'playcount': playcount, 'playback_percent': progress, 'skip_style': '0', 'skip_option': get_skip_option(tmdb_id)})
        item = set_info(item, meta, {'imdb': tmdb_id, 'tmdb': tmdb_id, 'tvdb': ''}, progress)
        if progress:
            cm_append(('[B]Clear Progress[/B]', run_plugin % build_url({'mode': 'watched_status.erase_bookmark', 'media_type': m_type, 'tmdb_id': tmdb_id, 'season': season, 'episode': episode, 'refresh': 'true', 'watched_indicators': '0'})))
            set_properties({'WatchedProgress': progress})
        if playcount: cm_append(('[B]Mark Unwatched Infinite[/B]', run_plugin % build_url({'mode': 'watched_status.extra', 'action': 'mark_as_unwatched', 'media_type': m_type, 'tmdb_id': tmdb_id, 'tvdb_id': '', 'season': season, 'episode': episode, 'title': title})))
        else: cm_append(('[B]Mark Watched Infinite[/B]', run_plugin % build_url({'mode': 'watched_status.extra', 'action': 'mark_as_watched', 'media_type': m_type, 'tmdb_id': tmdb_id, 'tvdb_id': '', 'season': season, 'episode': episode, 'title': title})))
        item.addContextMenuItems(cm)
        if live is True: u = build_url({'mode': str(mode), 'pvr': '.pvr', 'title': title, 'meta': dumps(meta, ensure_ascii=False)})
        else: u = build_url({'mode': str(mode), 'title': title, 'meta': dumps(meta, ensure_ascii=False)})
        # logger(f'get_channels 2meta: {meta}')
        set_properties({'IsPlayable': 'false'})
        return add_item(handle=int(argv[1]), url=u, listitem=item, isFolder=False)

    @staticmethod
    def add_section(mode, icon, fanart, title=None, meta=None):
        # logger(f'Common add_section mode: {mode} title: {title}')
        if meta is None: meta = {}
        cm = []
        cm_append = cm.append
        title = title if title is not None else mode
        if icon == '': icon = aicon
        meta_get = meta.get
        item = make_listitem()
        item.setLabel(str(title))
        item.setArt({'thumb': icon, 'poster': icon, 'fanart': fanart})
        meta.update({'title': title})
        recrape_ = 'true' if 'tubitv-content' in mode else ''
        cm_append((f'[B]Reload[/B] {title}', run_plugin % build_url({'mode': str(mode), 'title': title, 'rand': Common.random_generator(), 'meta': dumps(meta, ensure_ascii=False), 'rescrape': recrape_})))
        cm_append(('[B]Add to a Shortcut Folder[/B]', run_plugin % build_url({'mode': 'menu_editor.shortcut_folder_add_item', 'name': title, 'iconImage': icon, 'meta': dumps(meta, ensure_ascii=False), 'rescrape': 'false'})))
        item.addContextMenuItems(cm)
        u = build_url({'mode': str(mode), 'title': title, 'rand': Common.random_generator(), 'meta': dumps(meta, ensure_ascii=False), 'rescrape': 'false'})
        item = set_info(item, meta, {'imdb': str(meta_get('tmdb_id')), 'tmdb': str(meta_get('tmdb_id')), 'tvdb': ''})
        return add_item(handle=int(argv[1]), url=u, listitem=item, isFolder=True)

    @staticmethod
    # Return the Channel ID from YouTube URL
    def get_youtube_channel_id(url):
        return url.split('?v=')[-1].split('/')[-1].split('?')[0].split('&')[0]

    @staticmethod
    # Return the full YouTube plugin url
    def get_playable_youtube_url(channel_id):
        return f'plugin://plugin.video.youtube/play/?video_id={channel_id}'

    @staticmethod
    # Play stream
    # Optional: set xbmc_player to True to use xbmc.Player() instead of xbmcplugin.setResolvedUrl()
    def play(stream, channel='NO LABLE', xbmc_player=False):
        # logger(f'Common play:: channel: {channel} type(stream): {type(stream)} stream: {stream}')
        if xbmc_player:
            item = make_listitem()
            item.setLabel(channel)
            # xbmc.Player().play(stream, item, False)
            player.play(stream, item, False)
        else:
            try: infinitePlayer().run(stream, 'video', {'title': channel})
            except: logger(f'Common play:: {channel} Error {print_exc()}')

    @staticmethod
    # Get and Play stream
    def get_stream_and_play(mode):
        stream = None
        title, stream = 'Not Found', ''
        url = f'https://tubitv.com/oz?slug={mode}'
        try:
            data = loads(Common.open_url(url))
            title = data['title']
            # logger(f'Common get_stream_and_play data: {data}')
            stream = data['stream']
            if 'm3u8' in stream: infinitePlayer().run(stream, 'video', {'title': title})
            else: Common.dlg_failed(f'Can not found url for: {title}')
        except: logger(f'get_stream_and_play Error {print_exc()}')

    @staticmethod
    def meta_update(meta, data):
        subtitles, duration, ratings = '', 3600, 'R'
        try: meta = loads(meta)
        except: return meta
        if subtitles := data.get('subtitles'):
            # logger(f'Common get_tubi_tv_stream subtitles: {repr(subtitles)} data: {repr(data)}')
            try: meta['subtitles'] = [i['url'] for i in subtitles if 'English' in str(i)][0]
            except: pass
        if duration := data.get('duration'):
            try: meta['duration'] = int(duration)
            except: pass
        if ratings := data.get('ratings'):
            try: meta['mpaa'] = ratings[0]['code']
            except: pass
        if imdb_id := data.get('imdb_id'):
            try: meta['imdb_id'] = imdb_id
            except: pass
        return meta

    @staticmethod
    def get_tubi_tv_stream(stream_id, meta):
        url = f'https://tubitv.com/oz/videos/{stream_id}/content'
        # logger(f'type: {type(meta)} meta: {repr(meta)}')
        title, stream = 'Not Found', ''
        try:
            data = loads(Common.open_url(url))
            title = data['title']
            # logger(f'Common get_tubi_tv_stream data: {type(data)} {repr(data)}\n {type(meta)} meta: {repr(meta)}')
            stream = data.get('url')
            meta = Common.meta_update(meta, data)
            if not stream:
                manifest_type = ('hlsv3', 'hlsv6_fairplay', 'hlsv6_playready_psshv0', 'hlsv6_widevine_nonclearlead')
                try:
                    video_resources = data['video_resources']
                    if len(video_resources) > 1:
                        logger(f'video_resources data: {data}')
                        list_items = [{'line1': 'url Type:  ' + i['type'] + ' ' + i['resolution']} for i in video_resources]
                        kwargs = {'items': dumps(list_items), 'heading': 'Set source to play.', 'narrow_window': 'true'}
                        choice = select_dialog(video_resources, **kwargs)
                        stream = choice['manifest'].get('url')
                    else: stream = [d['manifest'].get('url') for d in video_resources if d['manifest'].get('url') and d['type'] in manifest_type][0]
                except:
                    logger(f'no video_resources data: {data}')
                    stream = data.get('video_preview_url')
                    Common.dlg_failed(f'preview url for: {title}')
                    # duration = data.get('duration')
                    # stream = re.sub(r'start(\d+)-end(\d+)', f'start0-end{duration}', stream)
            # logger(f'get_tubi_tv_stream stream: {stream}\ndumps(meta): {dumps(meta)}')
            if 'm3u8' in stream: infinitePlayer().run(stream, dumps(meta))
            elif '.mp4' in stream: kodi_player(stream, channel=title, direct_player=True)
            else: logger(f'error data: {data}'); Common.dlg_failed(f'Can not found url for: {title}')
        except: logger(f'get_tubi_tv_stream url: {url}\nerror data: {data}\nError {print_exc()}'); Common.dlg_failed(f'Can not found url for: {title}')


class Stream:

    @staticmethod
    def get_explore_org_streams():
        stream_list = []
        url = 'https://omega.explore.org/api/get_cam_group_info.json?id=79' # base64.b64decode(explore_org_base).decode('UTF-8')
        data = Common.open_url(url)
        json_results = loads(data)['data']['feeds']
        for stream in sorted(json_results, key=lambda k: k['title']):
            if stream['is_inactive'] is False and stream['is_offline'] is False and stream['video_id'] is not None:
                if stream['thumb'] == '': icon = f'https://i.ytimg.com/vi/{stream["video_id"]}/hqdefault.jpg'
                else: icon = stream['thumb']
                if stream['thumbnail_large_url'] == '': fanart = f'https://i.ytimg.com/vi/{stream["video_id"]}/hqdefault.jpg'
                else: fanart = stream['thumbnail_large_url']
                meta = {'duration': 10, 'title': stream['title']}
                stream_list.append({'id': stream['video_id'], 'poster': icon, 'fanart': fanart, 'title': stream['title'], 'meta': dumps(meta, ensure_ascii=False)})
        if stream_list: return stream_list

    @staticmethod
    def get_tubi_tv_categories():
        url = f'{git_url}/json_data/categories.json'
        # logger(f'url {url}')
        if testing:
            data = main_cache.get('content_get_tubi_tv_categories')
            if not data:
                data = Common.open_url(url)
                if data: main_cache.set('content_get_tubi_tv_categories', data, expiration=336)  # 14 days cache
        else: data = Common.open_url(url)
        if data: return eval(str(data))

    @staticmethod
    def get_tubi_tv_content(category):
        url = f'{git_url}/json_data/{category}.json'
        if testing:
            cache_name = f'shows_tubi_{category}'
            data = main_cache.get(cache_name)
            if not data:
                data = Common.open_url(url)
                if data: main_cache.set(cache_name, data, expiration=168)  # 7 days cache
        else: data = Common.open_url(url)
        if data: return eval(str(data))

    @staticmethod
    def get_tubi_tv_episodes(show, show_name):
        episode_list = []
        url = f'https://tubitv.com/oz/videos/0{show[0]}/content'
        tvshowtitle = str(show_name)
        if testing:
            cache_name = f'episodes_tubi_{url}'
            data = main_cache.get(cache_name)
            if not data:
                data = Common.open_url(url)
                if data: main_cache.set(cache_name, data, expiration=72)  # 3 days cache
        else: data = Common.open_url(url)
        try: json_results = loads(data)
        except: logger(f'Stream get_tubi_tv_episodes category: {show} url: {url} data: {data} Error {print_exc()}'); return []

        for season in range(len(json_results['children'])):
            try:
                for episode in range(len(json_results['children'][season]['children'])):
                    if re.search(item_cleaner, str(json_results['children'][season]['children'][episode])): continue
                    try: duration = int(json_results['children'][season]['children'][episode]['duration'])
                    except: duration = 1
                    try: year = json_results['children'][season]['children'][episode]['year']
                    except: year = '2024'
                    try: genre = json_results['children'][season]['children'][episode]['tags']
                    except: genre = []
                    try: plot = plot_clean(json_results['children'][season]['children'][episode]['description'])
                    except: plot = ''
                    try: icon = json_results['children'][season]['children'][episode]['thumbnails'][0]
                    except: icon = aicon
                    try: season_no = int(json_results['children'][season]['id'])
                    except: season_no = 1
                    try: episode_no = int(json_results['children'][season]['children'][episode]['episode_number'])
                    except: episode_no = 1
                    title = str(json_results['children'][season]['children'][episode]['title'])
                    # itemtype = json_results['children'][season]['children'][episode]['type']
                    title = get_clean_title(title)
                    tvshowtitle = get_clean_title(tvshowtitle)
                    title_id = tvshowtitle.replace("'", '').replace(':', '').lower()
                    itemtype = 'episode'
                    dur_min = duration // 60
                    plot = f'{tvshowtitle}: From: {show[1]}\nYear: {year}\nDuration: {dur_min} mins\nPlot: {plot}'
                    tmdb_id = f'{title_id}|{year}'
                    tvshowtitle = tvshowtitle if itemtype in {'tvshow', 'episode'} else ''
                    episode_list.append({'id': json_results['children'][season]['children'][episode]['id'],
                                         'title': title, 'tmdb_id': tmdb_id, 'imdb_id': tmdb_id, 'poster': icon, 'year': year, 'genre': genre, 'plot': plot, 'duration': duration,
                                         'media_type': itemtype, 'season': season_no, 'episode': episode_no, 'disply_name': f'{title} S{season_no}E{episode_no}',
                                         'tvshowtitle': tvshowtitle, 'ep_name': title})
            except: logger(f'Stream get_tubi_tv_episodes category: {show} Error {print_exc()}')
        return episode_list

    @staticmethod
    def get_tubi_tv_search(query):
        search_list = []
        url = f'https://tubitv.com/oz/search/{query}'
        data = Common.open_url(url)
        try: json_results = loads(data)
        except: return []
        logger(f'Stream search json_results {json_results}')

        for result in json_results:
            try:
                if re.search(item_cleaner, str(result)): continue
                try: duration = int(result['duration'])
                except: duration = 1
                try: year = result['year']
                except: year = '2024'
                try: genre = result['tags']
                except: genre = []
                try: plot = plot_clean(result['description'])
                except: plot = ''
                try: icon = result['posterarts'][0]
                except: icon = aicon
                # logger(f'Stream search result {result}')
                dur_min = duration // 60
                plot = f'Year: {year}\nDuration: {dur_min} mins\nPlot: {plot}'
                title = str(result['title'])
                itemtype = result['type']
                itemtype = get_itemtype(itemtype, duration)
                tmdb_id = f'{get_clean_title(title)}|{year}'
                tvshowtitle = title if itemtype in ('tvshow', 'episode') else ''
                search_list.append({'id': result['id'], 'title': title, 'tmdb_id': tmdb_id, 'poster': icon, 'year': year, 'genre': genre, 'plot': plot, 'duration': duration, 'media_type': itemtype,
                                    'tvshowtitle': tvshowtitle})
            except: logger(f'Stream get_tubi_tv_search result: {result} Error {print_exc()}')
        if search_list: return search_list