# -*- coding: utf-8 -*-
from modules import service_functions
from modules.kodi_utils import Thread, get_property, xbmc_monitor, make_settings_dict, get_setting, logger, local_string as ls

# infinite_str = ls(32036).upper()
OnNotificationActions = service_functions.OnNotificationActions()

class infiniteMonitor(xbmc_monitor):
	def __init__ (self):
		xbmc_monitor.__init__(self)
		self.startUpServices()

	def startUpServices(self):
		try: service_functions.InitializeDatabases().run()
		except: pass
		Thread(target=service_functions.DatabaseMaintenance().run).start()
		try: service_functions.CheckSettingsFile().run()
		except: pass
		try: service_functions.CheckUpdateActions().run()
		except: pass
		try: service_functions.ReuseLanguageInvokerCheck().run()
		except: pass
		Thread(target=service_functions.TraktMonitor().run).start()
		try: service_functions.ClearSubs().run()
		except: pass
		try: service_functions.AutoRun().run()
		except: pass

	def onSettingsChanged(self):
		if get_property('infinite_pause_onSettingsChanged') != 'true': make_settings_dict()

	def onNotification(self, sender, method, data):
		OnNotificationActions.run(sender, method, data)


infiniteMonitor().waitForAbort()

logger('Settings Monitor Service Finished')
logger('Main Monitor Service Finished')
