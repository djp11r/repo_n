# -*- coding: utf-8 -*-
"""
    Venom Add-on
"""

import re
import json
from datetime import timedelta
import traceback

import requests
from urllib.parse import urlencode, urljoin
try:
    from indexers.hindi.live_client import scrapePage, wrigtht_json, request
    from modules.kodi_utils import logger, build_url, addon_icon, notification, set_info, execute_builtin, addon_fanart, item_next, add_items, set_content, end_directory, set_view_mode, get_infolabel, make_listitem
    from caches.h_cache import main_cache
    from modules.player import infinitePlayer
except:
    import os, sys
    file = os.path.realpath(__file__)
    sys.path.append(os.path.join(os.path.dirname(file), "modules"))
    from modules.live_client import scrapePage, wrigtht_json, request
    from modules.h_cache import main_cache
    from modules.utils import logger

from modules.dom_parser import parseDOM

docu_link = 'https://topdocumentaryfilms.com/'
docu_cat_list = 'https://topdocumentaryfilms.com/watch-online/'


def _process(list_data):
    for item in list_data:
        # logger(f"lists _process item: {item}")
        listitem = make_listitem()
        title = item['title']
        poster = item.get('image', '')
        thumb = item['image'] if poster.startswith('http') else addon_icon
        url_params = {'mode': item['action'], 'title': title, 'url': item['url'], 'thumb': thumb}
        if item['action'] == 'docu_get_items': isfolder = True
        else: isfolder = False
        url = build_url(url_params)
        options_params = {'mode': 'options_menu_choice', 'suggestion': title, 'play_params': json.dumps(url_params)}
        cm = [("[B]Options...[/B]", f'RunPlugin({build_url(options_params)})')]
        listitem.setLabel(title)
        listitem.addContextMenuItems(cm)
        listitem.setArt({'thumb': thumb})
        item.update({'imdb_id': title, 'mediatype': 'episode', 'episode': 1, 'season': 0})
        setUniqueIDs = {'imdb': str(title)}
        listitem = set_info(listitem, item, setUniqueIDs)
        yield url, listitem, isfolder
    return


def doc_root(params):
    rescrape = params['rescrape']
    iconImage = params['iconImage']
    string = f'docu_list_root'
    params = {'iconImage': iconImage, 'rescrape': rescrape}
    cache_name = string + urlencode(params)
    if rescrape == 'true':
        main_cache.delete(cache_name)
        docu_data = None
    else: docu_data = main_cache.get(cache_name)
    if not docu_data:
        docu_data = get_root_items()
        if docu_data: main_cache.set(cache_name, docu_data, expiration=timedelta(hours=336))  # 14 days cache

    # docu_data = list(reversed(docu_data))
    # logger(f'total: {len(docu_data)} item_list: {docu_data}')
    from sys import argv
    handle = int(argv[1])
    if docu_data:
        # is_widget = external_browse()
        add_items(handle, list(_process(docu_data)))
        set_content(handle, 'tvshows')
        end_directory(handle)
        set_view_mode('view.main', 'tvshows')
    else:
        notification(f'No Shows Found for: {ch_name} Retry or change the Hindi provider in setting.')
        end_directory(handle)
        return


def get_root_items():
	item_list = []
	html = request(docu_cat_list)
	# html = requests.get(docu_cat_list, headers=headers).text
	# logger(f'html: {html}')
	cat_list = parseDOM(html, 'div', attrs={'class': 'sitemap-wraper'})
	# logger(f'total: {len(cat_list)} cat_list: {cat_list}')
	for content in cat_list:
		try:
			cat_info = parseDOM(content, 'h2')[0]
			# logger(f'cat_info: {cat_info}')
			cat_url = parseDOM(cat_info, 'a', ret='href')[0]
			# cat_title = parseDOM(cat_info, 'a')[0].encode('utf-8', 'ignore').decode('utf-8').replace("&amp;","&").replace('&#39;',"'").replace('&quot;','"').replace('&#39;',"'").replace('&#8211;',' - ').replace('&#8217;',"'").replace('&#8216;',"'").replace('&#038;','&').replace('&acirc;','')
			cat_title = parseDOM(cat_info, 'a')[0].replace("&amp;", "&").replace('&#39;', "'").replace('&quot;', '"').replace('&#39;', "'").replace('&#8211;', ' - ').replace('&#8217;', "'").replace('&#8216;', "'").replace('&#038;', '&').replace('&acirc;', '')
			try: cat_icon = parseDOM(content, 'img', ret='data-src')[0]
			except:
				try: cat_icon = parseDOM(content, 'img', ret='src')[0]
				except: cat_icon = iconImage
			# cat_action = 'docuHeaven&docuCat=%s' % cat_url
			item_list.append({'title': cat_title, 'url': cat_url, 'image': cat_icon, 'action': 'docu_get_items'})
		except: logger(f'root() Exception: {traceback.print_exc()}')
	return item_list


def docu_list(params):
    rescrape = 'false'#params['rescrape']
    iconImage = params['thumb']
    url = params['url']
    string = f'docu_list_item'
    params = {'url': url, 'thumb': iconImage}
    cache_name = string + urlencode(params)
    if rescrape == 'true':
        main_cache.delete(cache_name)
        docu_data = None
    else: docu_data = main_cache.get(cache_name)
    if not docu_data:
        docu_data = docu_list_items(url)
        if docu_data: main_cache.set(cache_name, docu_data, expiration=timedelta(hours=36))  # 14 days cache

    # docu_data = list(reversed(docu_data))
    # logger(f'total: {len(docu_data)} item_list: {docu_data}')
    from sys import argv
    handle = int(argv[1])
    if docu_data:
        add_items(handle, list(_process(docu_data)))
        set_content(handle, 'episodes')
        end_directory(handle)
        set_view_mode('view.main', 'episodes')
    else:
        notification(f'No Shows Found for: {ch_name} Retry or change the Hindi provider in setting.')
        end_directory(handle)
        return


def docu_list_items(url):
    item_list = []
    try:
        html = request(url)
        # logger(f'html: {html}')
        cat_list = parseDOM(html, 'article', attrs={'class': 'module clearfix'})
        # logger(f'cat_list: {cat_list}')
        for content in cat_list:
            try:
                docu_info = parseDOM(content, 'h2')[0]
                # logger(f'docu_info: {docu_info}')
                docu_url = parseDOM(docu_info, 'a', ret='href')[0]
                docu_title = parseDOM(docu_info, 'a')[0].replace("&amp;", "&").replace('&#39;', "'").replace('&quot;', '"').replace('&#39;', "'").replace('&#8211;', ' - ').replace('&#8217;', "'").replace('&#8216;', "'").replace('&#038;', '&').replace('&acirc;', '')
                try: docu_icon = parseDOM(content, 'img', ret='data-src')[0]
                except:
                    try: docu_icon = parseDOM(content, 'img', ret='src')[0]
                    except: cat_icon = iconImage
                # docu_action = 'docuHeaven&docuPlay=%s' % docu_url
                item_list.append({'title': docu_title, 'url': docu_url, 'image': docu_icon, 'action': 'docu_pls'})
            except: logger(f'docu_list() url:: {url} Error {traceback.print_exc()}')
        try:
            navi_content = parseDOM(html, 'div', attrs={'class': 'pagination module'})[0]
            links = parseDOM(navi_content, 'a', ret='href')
            link = links[(len(links) - 1)]
            # docu_action = 'docuHeaven&docuCat=%s' % link
            item_list.append({'title': 'Next Page', 'url': link, 'image': item_next, 'action': 'docu_get_items'})
        except: logger(f'docu_list() url:: {url} Error {traceback.print_exc()}')
    except: logger(f'docu_list() Exception: {traceback.print_exc()}')
    # self.addDirectory(self.list)
    # logger(f'total: {len(item_list)} item_list: {item_list}')
    return item_list


def docu_play(params):
    try:
        url = params['url']
        html = request(url)
        # logger(f'html: {html}')
        docu_item = parseDOM(html, 'meta', attrs={'itemprop': 'embedUrl'}, ret='content')[0]
        if 'http:' not in docu_item and 'https:' not in docu_item: docu_item = 'https:' + docu_item
        url = docu_item
        # docu_title = parseDOM(docu_page, 'meta', attrs={'property':'og:title'}, ret='content')[0].encode('utf-8', 'ignore').decode('utf-8').replace("&amp;","&").replace('&#39;',"'").replace('&quot;','"').replace('&#39;',"'").replace('&#8211;',' - ').replace('&#8217;',"'").replace('&#8216;',"'").replace('&#038;','&').replace('&acirc;','')
        docu_title = parseDOM(html, 'meta', attrs={'property': 'og:title'}, ret='content')[0].replace("&amp;", "&").replace('&#39;', "'").replace('&quot;', '"').replace('&#39;', "'").replace('&#8211;', ' - ').replace('&#8217;', "'").replace('&#8216;', "'").replace('&#038;', '&').replace('&acirc;', '')
        # logger(f'docu_title: {docu_title} url: {url}')
        if 'youtube' in url:
            if 'videoseries' not in url:
                try: video_id = parseDOM(html, 'div', attrs={'class': 'youtube-player'}, ret='data-id')[0]
                except: video_id = url.split('/')[-1]
                url = 'plugin://plugin.video.youtube/play/?video_id=%s' % video_id
        elif 'dailymotion' in url:
            video_id = parseDOM(html, 'div', attrs={'class': 'youtube-player'}, ret='data-id')[0]
            url = getDailyMotionStream(video_id)
        else:
            logger(f'Play Documentary: Unknown Host: url: {repr(url)}')
            url = check_hosted_media(url)
        logger(f'Play Documentary: docu_title: {docu_title} url: {repr(url)}')
        # execute_builtin(f'RunPlugin({url})')
        try: infinitePlayer().run(url, 'video', {'title': docu_title})
        except: logger(f'docu_play() docu_title:: {docu_title} Error {traceback.print_exc()}')
        # control.notification(message='Unknown Host - Report To Developer: ' + str(url)
        # control.execute('PlayMedia(%s)' % url)
        # item = xbmcgui.ListItem(str(docu_title), iconImage='DefaultVideo.png', thumbnailImage='DefaultVideo.png')
        # iconImage and thumb nailImage removed in Kodi Matrix
        # item.setInfo(type='video', infoLabels={'Title': str(docu_title), 'Plot': str(docu_title)})
        # item.setProperty('IsPlayable','true')
        # item.setPath(url)
        # control.resolve(int(sys.argv[1]), True, item)
    except: logger(f'docu_play() Exception: {traceback.print_exc()}')


def sort_key(elem):
    if elem[0] == "auto": return 1
    else: return int(elem[0].split("@")[0])


def check_hosted_media(vid_url):
    from resolveurl import HostedMediaFile
    hmf = HostedMediaFile(url=vid_url)
    if hmf.valid_url() is True:
        return hmf.resolve()
    return


# Code originally written by gujal, as part of the DailyMotion Addon in the official Kodi Repo. Modified to fit the needs here.
def getDailyMotionStream(id):
    headers = {'User-Agent': 'Android'}
    cookie = {'Cookie': "lang=en_US; ff=off"}
    r = requests.get("http://www.dailymotion.com/player/metadata/video/%s" % id, headers=headers, cookies=cookie)
    content = r.json()
    if content.get('error') is not None:
        Error = (content['error']['title'])
        logger(f'getDailyMotionStream() Error: {Error}')
        return  #xbmc.executebuiltin('XBMC.Notification(Info:,'+ Error +' ,5000)')
    else:
        cc = content['qualities']
        cc = cc.items()
        cc = sorted(cc, key=sort_key, reverse=True)
        m_url = ''
        other_playable_url = []
        for source, json_source in cc:
            source = source.split("@")[0]
            for item in json_source:
                m_url = item.get('url', None)
                if m_url:
                    if source == "auto": continue
                    elif int(source) <= 2:
                        if 'video' in item.get('type', None): return m_url
                    elif '.mnft' in m_url: continue
                    other_playable_url.append(m_url)
        if len(other_playable_url) > 0:  # probably not needed, only for last resort
            for m_url in other_playable_url:
                if '.m3u8?auth' in m_url:
                    rr = requests.get(m_url, cookies=r.cookies.get_dict(), headers=headers)
                    if rr.headers.get('set-cookie'):
                        logger('adding cookie to url')
                        strurl = re.findall(r'(http.+)', rr.text)[0].split('#cell')[0] + '|Cookie=' + rr.headers['set-cookie']
                    else:
                        strurl = re.findall(r'(http.+)', rr.text)[0].split('#cell')[0]
                    return strurl


# if __name__ == "__main__":
    # import random
    # type = 'docu_play'
    # if type == 'root': doc_root()
    # elif type == 'docu_list':
        # item_list = [{'name': '9/11', 'url': 'https://topdocumentaryfilms.com/category/911/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2018/09/9-11-war-games-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/911/'}, {'name': 'Art and Artists', 'url': 'https://topdocumentaryfilms.com/category/art-artists/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2022/03/grand-night-story-aardman-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/art-artists/'}, {'name': 'Biography', 'url': 'https://topdocumentaryfilms.com/category/biography/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2022/12/dark-hollywood-charlie-sheen-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/biography/'}, {'name': 'Conspiracy', 'url': 'https://topdocumentaryfilms.com/category/crime-conspiracy/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2022/08/constantly-wrong-case-against-conspiracy-theories-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/crime-conspiracy/'}, {'name': 'Crime', 'url': 'https://topdocumentaryfilms.com/category/crime/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2022/11/unforgivable-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/crime/'}, {'name': 'Drugs', 'url': 'https://topdocumentaryfilms.com/category/drugs/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2022/09/cannabis-question-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/drugs/'}, {'name': 'Economics', 'url': 'https://topdocumentaryfilms.com/category/economics/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2022/09/big-four-accounting-firms-under-scrutiny-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/economics/'}, {'name': 'Environment', 'url': 'https://topdocumentaryfilms.com/category/environment/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2022/12/last-resources-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/environment/'}, {'name': 'Health', 'url': 'https://topdocumentaryfilms.com/category/health/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2022/11/spanish-flu-invisible-enemy-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/health/'}, {'name': 'History', 'url': 'https://topdocumentaryfilms.com/category/history/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2022/12/saving-temples-nile-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/history/'}, {'name': 'Media', 'url': 'https://topdocumentaryfilms.com/category/media/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2021/01/futurama-retrospective-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/media/'}, {'name': 'Military and War', 'url': 'https://topdocumentaryfilms.com/category/military-war/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2022/06/battlespace-future-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/military-war/'}, {'name': 'Mystery', 'url': 'https://topdocumentaryfilms.com/category/mystery/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2022/12/strangest-structures-ancient-peru-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/mystery/'}, {'name': 'Nature', 'url': 'https://topdocumentaryfilms.com/category/nature-wildlife/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2022/10/key-life-evolution-fungi-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/nature-wildlife/'}, {'name': 'Performing Arts', 'url': 'https://topdocumentaryfilms.com/category/music-performing-arts/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2022/07/defense-nicolas-cage-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/music-performing-arts/'}, {'name': 'Philosophy', 'url': 'https://topdocumentaryfilms.com/category/philosophy/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2020/02/effortless-action-art-spontaneity-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/philosophy/'}, {'name': 'Politics', 'url': 'https://topdocumentaryfilms.com/category/politics/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2022/10/labour-files-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/politics/'}, {'name': 'Psychology', 'url': 'https://topdocumentaryfilms.com/category/psychology/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2018/02/alone-past-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/psychology/'}, {'name': 'Religion', 'url': 'https://topdocumentaryfilms.com/category/religion/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2022/09/secrets-opus-dei-faith-power-manipulation-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/religion/'}, {'name': 'Science', 'url': 'https://topdocumentaryfilms.com/category/science-technology/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2023/01/first-animals-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/science-technology/'}, {'name': 'Sexuality', 'url': 'https://topdocumentaryfilms.com/category/sex/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2022/04/raised-on-porn-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/sex/'}, {'name': 'Society', 'url': 'https://topdocumentaryfilms.com/category/society/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2023/01/discover-uzbekistan-traveling-silk-road-train-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/society/'}, {'name': 'Sports', 'url': 'https://topdocumentaryfilms.com/category/sports/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2022/01/madness-make-believe-martial-arts-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/sports/'}, {'name': 'Technology', 'url': 'https://topdocumentaryfilms.com/category/technology/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2023/01/great-toilet-battle-150x198.jpg', 'action': 'docuHeaven&docuCat=https://topdocumentaryfilms.com/category/technology/'}]
        # item = random.choice(item_list)
        # logger(item['url'])
        # docu_list(item['url'])
    # else:
        # item_list = [{'name': 'The Secrets of Opus Dei: Faith, Power and Manipulation', 'url': 'https://topdocumentaryfilms.com/secrets-opus-dei-faith-power-manipulation/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2022/09/secrets-opus-dei-faith-power-manipulation-150x198.jpg', 'action': 'docu_item'}, {'name': 'The Strange World of Breatharianism', 'url': 'https://topdocumentaryfilms.com/strange-world-breatharianism/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2021/11/strange-world-breatharianism-150x198.jpg', 'action': 'docu_item'}, {'name': "America's New Gurus", 'url': 'https://topdocumentaryfilms.com/americas-new-gurus/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2021/04/americas-new-gurus-150x198.jpg', 'action': 'docu_item'}, {'name': 'The Dead Sea Scrolls', 'url': 'https://topdocumentaryfilms.com/dead-sea-scrolls/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2020/09/dead-sea-scrolls-150x198.jpg', 'action': 'docu_item'}, {'name': 'The Church: Code of Silence', 'url': 'https://topdocumentaryfilms.com/church-code-silence/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2020/06/church-code-silence-150x198.jpg', 'action': 'docu_item'}, {'name': "Jesus' Female Disciples: The New Evidence", 'url': 'https://topdocumentaryfilms.com/jesus-female-disciples-new-evidence/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2019/08/jesus-female-disciples-new-evidence-150x198.jpg', 'action': 'docu_item'}, {'name': 'The Exodus Decoded', 'url': 'https://topdocumentaryfilms.com/exodus-decoded/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2018/12/exodus-decoded-150x198.jpg', 'action': 'docu_item'}, {'name': 'Iron Kingdom', 'url': 'https://topdocumentaryfilms.com/iron-kingdom/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2018/11/iron-kingdom-150x198.jpg', 'action': 'docu_item'}, {'name': 'The Real Jesus Christ', 'url': 'https://topdocumentaryfilms.com/real-jesus-christ/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2018/10/real-jesus-christ-150x198.jpg', 'action': 'docu_item'}, {'name': 'Exorcisms: The Battle for Young Minds', 'url': 'https://topdocumentaryfilms.com/exorcisms-battle-young-minds/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2018/10/exorcisms-battle-young-minds-150x198.jpg', 'action': 'docu_item'}, {'name': 'Islamophobia Inc.', 'url': 'https://topdocumentaryfilms.com/islamophobia-inc/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2018/06/islamophobia-inc-150x198.jpg', 'action': 'docu_item'}, {'name': 'Rajneeshpuram', 'url': 'https://topdocumentaryfilms.com/rajneeshpuram/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2018/02/rajneeshpuram-150x198.jpg', 'action': 'docu_item'}, {'name': 'Rise and Decline of Science in Islam', 'url': 'https://topdocumentaryfilms.com/rise-decline-science-islam/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2018/01/rise-decline-science-islam-150x198.jpg', 'action': 'docu_item'}, {'name': 'Children of Abraham', 'url': 'https://topdocumentaryfilms.com/children-abraham/', 'image': 'https://topdocumentaryfilms.com/wp-content/uploads/2018/01/children-abraham-150x198.jpg', 'action': 'docu_item'}]
        # item = random.choice(item_list)
        # logger(item['url'])
        # docu_play(item['url'])