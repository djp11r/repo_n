# -*- coding: utf-8 -*-
import json
import re
from sys import argv
from traceback import print_exc
from urllib.parse import urlencode

import requests

try:
    from modules.kodi_utils import logger, build_url, add_items, addon_icon, end_directory, set_content, set_view_mode, get_infolabel, notification, add_item, make_listitem, external, set_category, set_info, get_list_item
    from modules.source_utils import get_host_dict, request, agent, replace_html_codes, get_host, process
    from caches.main_cache import main_cache
    from modules.settings import get_git_url
    import resolveurl
    opensettings_params = build_url({'mode': 'open_settings', 'query': '0.0'})
except:
    from modules.utils import logger
    from modules.main_cache import main_cache
    logger(f'import Exception: \n{print_exc()}')
    from modules.hindi_utils import request, agent, replace_html_codes, get_host, process
    get_host_dict = ['oyohd.one', 'file.fm']

from modules.dom_parser import parseDOM

odd_domains = ['iwatchamericandadonline.com', 'watchcriminalminds.com', 'watchfamilyguyonline.com', 'watchgreysanatomy.com', 'watchhawaiifive0online.com', 'watchmodernfamilyonline.com', 'watchroseanneonline.com', 'watchspongebobsquarepantsonline.com']

ajax_link = '/wp-admin/admin-ajax.php'
hostDict = get_host_dict()


def get_image(ele):
    try:
        try: image = parseDOM(ele, 'img', ret='data-src')[0]
        except: image = parseDOM(ele, 'img', ret='src')[0]
    except: image = 'DefaultFolder.png'
    if image.startswith('//'): image = f'https:{image}'
    return image


def root(params):
    try:
        cache_name = f'content_{urlencode(params)}'
        list_data = main_cache.get(cache_name)
        if not list_data:
            uri = f'{get_git_url()}/watchonline.json'
            data = request(uri)
            list_data = eval(str(data))
            main_cache.set(cache_name, list_data, expiration=336)
        handle = int(argv[1])
        is_external = external()
        add_items(handle, list(get_list_item(list_data, 'watchonline', True)))
        set_content(handle, '')
        set_category(handle, '')
        end_directory(handle, cacheToDisc=not is_external)
    except: logger(f'root Exception: \n{print_exc()}')


def scrape_seasons(params):
    # logger(f'scrape_seasons params: {params}')
    base_link = params['url']
    # self.list.append({'title': 'Random Episode (Sometimes Fails)', 'url': base_link+'/?redirect_to', 'poster': None, 'mode': 'watchonline_scrape_episode'})
    itemlist = [{'title': 'Random Episode (Sometimes Fails)', 'url': f'{base_link}/?redirect_to', 'poster': None, 'mode': 'watchonline_source'}]
    ends = params.get('endings')
    # logger(f'scrape_seasons site_link: {base_link} type {type(ends)} repr(ends): {repr(ends)}')
    cache_name = f'shows_{urlencode(params)}'
    item_list = main_cache.get(cache_name)
    if not item_list:
        item_list = get_seasons(itemlist, base_link, ends)
        main_cache.set(cache_name, item_list, expiration=336)  # 14 days cache
    handle = int(argv[1])
    is_external = external()
    add_items(handle, list(get_list_item(item_list, 'watchonline', True)))
    set_content(handle, 'seasons')
    set_category(handle, 'seasons')
    end_directory(handle, cacheToDisc=not is_external)


def get_seasons(item_list, base_link, ends):

    for end in eval(ends):
        site_link = base_link + end
        # logger(f'scrape_seasons site_link: {site_link}')
        try:
            site_html = request(site_link, timeout='30')
            if '<div class="pagination">' in site_html:
                try:
                    pagination = parseDOM(site_html, 'div', attrs={'class': 'pagination'})[0]
                    page2_link = parseDOM(pagination, 'a', ret='href')[0]
                except: page2_link = None
                if page2_link: site_html += request(page2_link, timeout='30')
            if '/series/' in site_link:
                image = get_image(site_html)
                seasons = parseDOM(site_html, 'li', attrs={'id': r'menu-item-.*?'})
                for i in seasons:
                    try:
                        title = parseDOM(i, 'a')[0]
                        title = replace_html_codes(title)
                        if title in ['Home', 'TV Shows', 'Seasons', 'Season List', 'Other', 'Other Websites', ]:
                            continue
                        link = parseDOM(i, 'a', ret='href')[0]
                        if not link.startswith(base_link): link = f'{base_link}{link}'
                        item_list.append({'title': title.title(), 'url': link, 'poster': image, 'mode': 'watchonline_e'})
                    except: logger(f'1 scrape_seasons Exception: {print_exc()}')
            else:
                seasons = parseDOM(site_html, 'article')
                for i in seasons:
                    try:
                        title = parseDOM(i, 'img', ret='alt')[0]
                        title = replace_html_codes(title)
                        link = parseDOM(i, 'a', ret='href')[0]
                        if not link.startswith(base_link): link = f'{base_link}{link}'
                        image = get_image(i)
                        item_list.append({'title': title.title(), 'url': link, 'poster': image, 'mode': 'watchonline_e'})
                    except: logger(f'2 scrape_seasons Exception: {print_exc()}')
        except: logger(f'scrape_seasons Exception: {print_exc()}')
        return item_list


def scrape_episodes(url):
    try:
        cache_name = f'episodes_{url}'
        item_list = main_cache.get(cache_name)
        if not item_list:
            item_list = get_episodes(url)
            main_cache.set(cache_name, item_list, expiration=336)  # 14 days cache
        handle = int(argv[1])
        add_items(handle, list(get_list_item(item_list, 'watchonline', True)))
        is_external = external()
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.episode_lists', 'episodes', is_external)
    except: logger(f'scrape_episodes Exception: {print_exc()}')


def get_episodes(url):
    episodes_list = []
    base_host = get_host(url)
    base_link = f'https://{base_host}'
    html = request(url, timeout='30')
    if any(i in url for i in odd_domains):
        episodes = parseDOM(html, 'article')
        for i in episodes:
            try:
                title = parseDOM(i, 'h2', attrs={'class': 'entry-title'})[0]
                title = replace_html_codes(title)
                link = parseDOM(i, 'a', ret='href')[0]
                if not link.startswith(base_link): link = f'{base_link}{link}'
                image = get_image(i)
                episodes_list.append({'title': title, 'url': link, 'poster': image, 'mode': 'watchonline_source'})
            except: logger(f'1 scrape_episodes Exception: \n{print_exc()}')
    else:
        episodes = parseDOM(html, 'li', attrs={'class': r'mark-.*?'})
        for i in episodes:
            try:
                title1 = parseDOM(i, 'div', attrs={'class': 'numerando'})[0]
                title2 = parseDOM(i, 'div', attrs={'class': 'episodiotitle'})[0]
                title2 = parseDOM(title2, 'a')[0]
                title_layout = f'[B]{title1}[/B] ({title2})'
                title = replace_html_codes(title_layout)
                link = parseDOM(i, 'a', ret='href')[0]
                if not link.startswith(base_link): link = f'{base_link}{link}'
                image = get_image(i)
                episodes_list.append({'title': title, 'url': link, 'poster': image, 'mode': 'watchonline_source'})
            except: logger(f'2 scrape_episodes Exception: \n{print_exc()}')
    return episodes_list


def scrape_source(params):
    try:
        cache_name = f'content_{urlencode(params)}'
        item_list = main_cache.get(cache_name)
        if not item_list:
            item_list = get_sources(params)
            main_cache.set(cache_name, item_list, expiration=6) # 6hrs
        handle = int(argv[1])
        is_external = external()
        add_items(handle, list(get_list_item(item_list, 'watchonline')))
        set_content(handle, '')
        set_category(handle, '')
        end_directory(handle, cacheToDisc=not is_external)
    except: logger(f'outter scrape_source Exception: {print_exc()}')


def get_sources(params):
    sources_list = []
    url = params['url']
    title = params.get('title')
    thumb = params.get('poster')
    base_host = get_host(url)
    base_link = f'https://{base_host}'
    if '/?redirect_to' in url: url += '=random&post_type=episodes'
    # logger(f'Scraper Testing starting url: {repr(url)}')
    # logger(f'Scraper Testing base_link: {repr(base_link)}')
    html = request(url, timeout='30')
    if any(i in url for i in odd_domains):
        results = parseDOM(html, 'iframe', ret='data-src')
        for result in results:
            try:
                result_url = replace_html_codes(result)
                result_html = request(result_url, timeout='30')
                result_link = parseDOM(result_html, 'iframe', ret='src')[0]
                for source in process(hostDict, result_link):
                    title = f'{title} {source["source"]} ( {source["quality"]} {source["info"]})'
                    link = source['url']
                    sources_list.append({'title': title, 'url': link, 'poster': thumb, 'mode': 'watchonline_ltp'})
            except: logger(f'1 scrape_source Exception: {print_exc()}')
    else:
        session = requests.Session()
        customheaders = {
            'Host': base_host,
            'Accept': '*/*',
            'Origin': base_link,
            'X-Requested-With': 'XMLHttpRequest',
            'User-Agent': agent(),
            'Referer': url,
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'en-US,en;q=0.9'
            }
        post_link = base_link + ajax_link
        results = re.compile('''class=['"]dooplay_player_option['"] data-type=['"](.+?)['"] data-post=['"](.+?)['"] data-nume=['"](\d+)['"]>''', re.DOTALL).findall(html)
        for data_type, data_post, data_nume in results:
            try:
                # logger(f'Scraper Testing data_post: {repr(data_post)} data_type: {data_type}')
                payload = {'action': 'doo_player_ajax', 'post': data_post, 'nume': data_nume, 'type': data_type}
                r = session.post(post_link, headers=customheaders, data=payload)
                i = r.text
                p = i.replace('\\', '')
                link = parseDOM(p, 'iframe', ret='src')[0]
                for source in process(hostDict, link):
                    # logger(f'Scraper Testing source: {repr(source)}')
                    title = f'{title} {source["source"]} ( {source["quality"]} {source["info"]})'
                    link = source['url']
                    sources_list.append({'title': title, 'url': link, 'poster': thumb, 'mode': 'watchonline_ltp'})
            except: logger(f'2 scrape_source Exception: {print_exc()}')
    return sources_list


def play(params):
    try:
        # logger(f'play params: {params}')
        hmf = resolveurl.HostedMediaFile(url=params['url'], include_disabled=True, include_universal=False)
        url = None
        if hmf.valid_url() is True:
            url = hmf.resolve()
            logger(f'watchonline play url: {url}')
        from modules.player import infinitePlayer
        if url: infinitePlayer().run(url, 'video', {'title': str(params['title'])})
        else: notification('Error : No Stream Available.:')
    except:
        logger(f'play Exception: \n{print_exc()}')
        notification('Error : No Stream Available.:')