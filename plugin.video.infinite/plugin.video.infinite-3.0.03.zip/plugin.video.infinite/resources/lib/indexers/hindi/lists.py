# -*- coding: utf-8 -*-

import base64
import re
from json import dumps, loads
from traceback import print_exc
from urllib.parse import urlencode, urlparse

try:
    from modules.kodi_utils import logger, build_url, addon_icon, select_dialog, make_listitem, set_info,  notification, add_items, set_content, end_directory, set_view_mode, get_infolabel, set_category, external, get_list_item
    from modules.settings import get_git_url
    from modules.utils import normalize
    from modules.source_utils import request, agent, uh_detect, unhunt
    from caches.main_cache import main_cache
    from caches.settings_cache import get_setting
    ddurl = get_setting('infinite.live_url', '')
    chnnel_filter = get_setting('infinite.live_channels', 'DAZN, Movistar').split(', ')
except:
    # logger(f'import Exception: {print_exc()}')
    from modules.utils import logger, normalize
    from modules.main_cache import main_cache
    from modules.client import request, agent
    from modules.jsunhunt import detect as uh_detect, unhunt
    import os
    ddurl = 'https://dlhd.so'
    chnnel_filter = ['DAZN', 'Movistar', 'Espa', 'Alkass', 'Greece', 'Netherland', 'Germany', 'SUR', 'Deportes', 'Galavisi', 'Latino', 'Russia', 'Campeones', 'ES', 'Romania', 'DSTV', 'Italy', 'Argentina', 'Afrique', 'Denmark', 'Brasil', 'Sweden', 'Cosmote', 'Israe', 'Israel', 'Poland', 'Bulgaria', 'Spain', 'Qatar', 'Turkey', 'France', 'MENA', 'DE', 'Portugal', 'Croatia', 'Astro', 'Serbia']
from modules.dom_parser import parseDOM

tvappurl = 'https://thetvapp.to'
regex_pattern = re.compile(r'''(?:source|src)['"]*:\s*(?:"|')(.+?)(?:"|')''', flags=re.DOTALL+re.I)
header = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7', 'Accept-Encoding': 'gzip, deflate', 'Accept-Language': 'en,en-US;q=0.9', 'Cache-Control': 'no-cache', 'Pragma': 'no-cache', 'Sec-Ch-Ua': '"Not(A:Brand";v="24", "Chromium";v="122"', 'Sec-Ch-Ua-Mobile': '?0', 'Sec-Ch-Ua-Platform': "Windows", 'Sec-Fetch-Dest': 'document', 'Sec-Fetch-Mode': 'navigate', 'Sec-Fetch-Site': 'same-site', 'Sec-Fetch-User': '?1', 'Upgrade-Insecure-Requests': '1', 'DNT': '1', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'}
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0'


def get_c_list(params):
    ch_name = params['list_name']
    cache_name = f'content_{ch_name}{urlencode(params)}'
    list_data = main_cache.get(cache_name)
    if not list_data:
        git_url = get_git_url()
        if ch_name == 'youtube': data = request(f'{git_url}/youtub_live.json')
        elif ch_name == 'pluto': data = request(f'{git_url}/pluto.json')
        elif ch_name == 'indianlive': data = request(f'{git_url}/indian_live.json')
        elif ch_name == 'daddy': list_data = ch_dl()
        elif ch_name == 'theapp': list_data = ch_tvapp()
        if ch_name not in ('daddy', 'theapp'): list_data = eval(str(data)) # loads(data)
        if list_data: main_cache.set(cache_name, list_data, expiration=168) # 7days
    # logger(f'from cache list_data: {list_data}')
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_external = external()
    if list_data:
        add_items(handle, list(get_list_item(list_data, ch_name)))
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.episodes', 'episodes', is_external)
    else:
        notification(f'No links Found for: :{ch_name} Retry')
        end_directory(handle)
        return


def play(params):
    # logger(f'play params {params}')
    url = params['url']
    try:
        info = {'title': params['title']}
        if params['provider'] == 'daddy':
            ourl = relv_daddy(url)
            info['use_inputstream'] = 'not use_inputstream'
        elif params['provider'] == 'theapp': ourl = relv_theapp(url)
        elif params['provider'] == 'youtube': ourl = get_m3u8_url(url)
        elif params['provider'] == 'pluto' and 'm3u8' in url: ourl = f'{url}|User-Agent={agent()}&Referer={url}'
        elif params['provider'] == 'crick_live': ourl = url
        else: ourl = f'{url}|User-Agent={agent()}'
        if ourl is None:
            logger(f'--- Playing url: {ourl} info: {info}\nparams: {params}')
            return notification(f'No links Found for: :{params["title"]} Retry')
        from modules.player import infinitePlayer
        infinitePlayer().run(ourl, 'video', info)
    except:
        logger(f'play provider: {params} - Exception: {print_exc()}')
        return


def get_videoId(from_func, response):
    vars_ = re.compile(r'var ytInitialData =.*?[\'|"|{](.+)[\'|"|}][,;]</script>').findall(response)
    # logger(f'vars_>>> : {vars_}')
    ytInitialData = str(vars_[0])
    # logger(f'ytInitialData: {ytInitialData}')
    # logger(f'ytInitialData: {string_escape(vars_[0])}')
    return re.findall(r'(compactvideoRenderer|videoRenderer)\":\{\"videoId\":\"(.+?)\",', ytInitialData, re.IGNORECASE,)


def get_m3u8_url(url):
    # logger(f'get_m3u8_url url: {url}')
    furl = None
    if 'https://www.youtube.com/channel' in url: response = request(url)
    else: response = request(f'{url}/videos')
    # logger(response)
    videoIds = get_videoId('get_m3u8_url', response)
    videoId_counter = 0
    for videoId in videoIds:
        furl = None
        videoId_counter += 1
        live_yturl = f'https://www.youtube.com/watch?v={videoId[1]}'
        # logger(f'live_yturl: {live_yturl}')
        response = request(live_yturl)
        # logger(f'<<<--->>> \n{response}\n<<<--->>>')
        if '.m3u8' in response:
            # logger(f'get_m3u8_url response: {response}')
            furl = extract_m3u8(response)
            if furl: break
    logger(f'Total videoId: {len(videoIds)} get link from videoId_counter: {videoId_counter} from: {url}')
    return furl or None


def extract_m3u8(response, m3u8_extension='.m3u8', https_prefix='https://', tuner_increment=5, initial_tuner=200):
    end = response.find(m3u8_extension)
    if end == -1: raise ValueError('No .m3u8 found in the response')
    end += len(m3u8_extension)
    tuner = initial_tuner
    # logger(f'extract_m3u8 tuner: {tuner} end: {end}')

    while True:
        # logger(f'extract_m3u8 response[{end - tuner}: {end}]')
        potential_link = response[end - tuner: end]
        if https_prefix in potential_link:
            link = potential_link
            start = link.find(https_prefix)
            end = link.find(m3u8_extension) + len(m3u8_extension)
            break
        else: tuner += tuner_increment
    logger(f'extract_m3u8 length of links: {len(link[start: end])}')
    # logger(f'extract_m3u8  type: {type(link)} length of links: {len(link[start: end])}  : repr {repr(link)} : {link[start: end]}')
    return link[start: end]


def get_ltv_link(resp):
    links = regex_pattern.findall(resp)
    # logger(f'play provider links: {links}')
    links = [x for x in links if '.m3u8' in x]
    link = None
    if len(links) > 1:
        list_items = [{'line1': f'url:  {i}'} for i in links]
        kwargs = {'items': dumps(list_items), 'heading': 'Select source to play.', 'narrow_window': 'true'}
        link = select_dialog(links, **kwargs)
    elif len(links) > 0: link = links[0]
    return link


def ch_dl():
    url = f'{ddurl}/24-7-channels.php'
    do_adult = False  #xbmcaddon.Addon().getSetting('adult_pw')
    hea = {'Referer': f'{ddurl}/', 'user-agent': UA}
    resp = request(url, headers=hea)
    # logger(f'resp: {resp}')
    ch_block = re.compile('<center><h1(.+?)tab-2', re.MULTILINE | re.DOTALL).findall(str(resp))
    chan_data = re.compile('href=\"(.*)\" target(.*)<strong>(.*)</strong>').findall(str(ch_block[0]))
    # logger(f'chan_data: {chan_data}')
    ch_list = []
    for item in chan_data:
        try:
            url, title = str(item[0]), str(item[2])
            if any(x in title for x in chnnel_filter): continue
            # logger(f'item: {repr(item)}')
            url_params = {'title': title, 'url': url}
            if "18+" not in title: ch_list.append(url_params)
            if do_adult and "18+" in title: ch_list.append(url_params)
        except: logger(f'item: {repr(item)} error: {print_exc()}')
    # logger(f'ch_list: {ch_list}')
    return ch_list


def relv_daddy(link):
    url = f'{ddurl}{link}'
    hea = {'Referer': f'{ddurl}/', 'user-agent': UA}
    resp = request(url, headers=hea)
    url_1 = re.compile('iframe src="(.*?)"').findall(resp)[0]
    hea = {'Referer': url, 'user-agent': UA, }
    # logger(f'play provider url_1: {url_1}')
    resp = request(url_1, headers=hea)
    # logger(f'play provider resp: {resp}')
    furl = get_ltv_link(resp)
    if not furl:
        link = base64.b64decode(unhunt(resp))
        iurl = link.decode('utf-8', errors='ignore')
        url = str(iurl).split('https')
        # logger(f'play provider url: {url}') # ['ޝ\x1dyԨ\x1e', '://webhdrunns.mizhls.ru/lb/premium347/index.m3u8']
        furl = f'https{url[1]}'
        # logger(f'play provider furl: {repr(furl)}') # 'https://webhdrunns.mizhls.ru/lb/premium347/index.m3u8'
    if not furl: return
    parsed_url = urlparse(url_1)
    referer = f'{parsed_url.scheme}://{(parsed_url.netloc or parsed_url.furl)}'
    return f'{furl}|Referer={referer}/&Origin={referer}&Keep-Alive=true&User-Agent={UA}'


def ch_tvapp():
    url = f'{tvappurl}/tv'
    hea = {'user-agent': UA, }
    resp = request(url, headers=hea, verify=False)
    # logger(f'resp: {resp}')
    html = parseDOM(resp, 'ol', attrs={'class': "list.*?"})[0]#.replace('<span>', '').replace('</span>', '').replace('\n', '').replace('  ', '').replace('@', ' @')
    chan_data = re.findall('href\s*=\s*"([^"]+)"\s*class.*?>([^<]+)<\/a>', html, re.DOTALL)

    ch_list = []
    for url, title in chan_data:
        try:
            url = url[:-1] if url.endswith('/') else url
            url = url.replace('/tv/', '')
            # href = f'https://thetvapp.to{url}' if url.startswith('/') else url
            if any(x in title for x in chnnel_filter): continue
            # logger(f'item: {repr(item)}')
            url_params = {'title': title.replace('&amp;', '&'), 'url': url}
            ch_list.append(url_params)
        except: logger(f'chan_data: {repr(chan_data)} error: {print_exc()}')
    # logger(f'ch_list: {ch_list}')
    return ch_list


def relv_theapp(id_):
    stream_url = ''
    # id_ = re.findall('tv\/(.+?)$', url, re.DOTALL)
    # id_ = id_[0] if id_ else ''
    # if id_: id_ = id_[:-1] if id_.endswith('/') else id_
    # url_api = b64decode(''.join(chr(int(c)) for c in '118O0O107O0O71O0O99O0O104O0O57O0O67O0O99O0O119O0O70O0O109O0O76O0O115O0O86O0O50O0O89O0O121O0O86O0O109O0O100O0O117O0O119O0O87O0O89O0O108O0O82O0O88O0O76O0O121O0O86O0O71O0O90O0O117O0O86O0O72O0O97O0O48O0O82O0O88O0O97O0O105O0O74O0O87O0O89O0O121O0O57O0O121O0O76O0O54O0O77O0O72O0O99O0O48O0O82O0O72O0O97'.split('O0O'))[::-1]).decode('utf-8')
    url_api = 'https://rabbitthunder-teal.vercel.app/api/mzc'
    ft = {'id': id_}
    header.update({'Origin': 'https://thetvapp.to', 'Referer': 'https://thetvapp.to/',})

    response = request(url_api, post=ft, verify=False)
    if 'source":"' in response:
        link = get_ltv_link(response)
        if link: return f'{link}|{urlencode(header)}'
    return stream_url
