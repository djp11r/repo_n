# -*- coding: utf-8 -*-

import json
import re
from traceback import print_exc
from urllib.parse import quote_plus, urlencode

import requests

try:
    from modules.kodi_utils import logger, build_url, notification, set_info, execute_builtin, default_addon_fanart, nextpage, add_items, set_content, end_directory, set_view_mode, get_infolabel, make_listitem, set_category, external, get_list_item
    from modules.settings import get_git_url
    from modules.source_utils import normalize, request, convert_youtube_duration_to_minutes
    from caches.main_cache import main_cache
except:
    import os, sys

    from modules.utils import logger
    from modules.main_cache import main_cache
    from modules.hindi_utils import request, convert_youtube_duration_to_minutes
    from modules.source_utils import normalize
    default_addon_fanart = ''

from modules.dom_parser import parseDOM
play_youtube_url = 'plugin://plugin.video.youtube/play/?video_id'


def geetm_root(params):
    cache_name = 'content_geetmala'
    list_data = main_cache.get(cache_name)
    # logger(f'from cache list_data: {list_data}')
    if not list_data:
        uri = f'{get_git_url()}/geetmala.json'
        data = request(uri)
        list_data = eval(str(data))
        # list_data = json.loads(data)
        # logger(f'new list_data: {list_data}')
        if list_data: main_cache.set(cache_name, list_data, expiration=168) # 7days

    from sys import argv  # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_external = external()
    add_items(handle, list(get_list_item(list_data, 'youtube_r', True)))
    set_content(handle, 'tvshows')
    set_category(handle, 'tvshows')
    end_directory(handle, cacheToDisc=not is_external)
    set_view_mode('view.tvshows', 'tvshows', is_external)


def get_song_list(params):
    ourl = params['url']
    rescrape = params.get('rescrape', 'false')
    if ourl.endswith('value=') or ourl == 'YouTube':
        search_text = get_SearchQuery('Hindi Geetmala')
        ourl += quote_plus(search_text)

    cache_name = f'content_{urlencode(params)}'
    song_list = None
    if rescrape == 'true': main_cache.delete(cache_name)
    else: song_list = main_cache.get(cache_name)
    if not song_list:
        if ourl.startswith('YouTube'):
            song_list = Movie_search().search(search_text, [])
        else: song_list = make_song_list(params)
        if song_list:
            main_cache.set(cache_name, song_list, expiration=24)  # 1 days cache

    # logger(f'get_song_list item_list: {list(_process())}')
    from sys import argv  # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_external = external()
    if ourl.startswith('YouTube'):
        add_items(handle, list(get_list_item(song_list, 'youtube')))
        set_content(handle, 'videos')
        set_category(handle, 'videos')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.videos', 'videos', is_external)
    else:
        add_items(handle, list(get_list_item(song_list, 'youtube', True)))
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.episodes', 'episodes', is_external)


def get_SearchQuery(sitename):
    import xbmc
    keyboard = xbmc.Keyboard()
    keyboard.setHeading(f'Search {sitename}')
    keyboard.doModal()
    return keyboard.getText() if keyboard.isConfirmed() else ''


def make_song_list(params):
    url, rtitle, pg_no = params['url'], params.get('title', ''), params.get('pg_no', '1')
    base_link = 'https://www.hindigeetmala.net'
    find_data = re.compile('itemprop="name">(.+?)</span>')
    song_perpage = 25
    songs = []
    nextpg = True
    while len(songs) < song_perpage and nextpg:
        song_page = request(url)
        result = parseDOM(song_page, 'tr', attrs={'itemprop': 'track'})
        for item in result:
            try:
                title = parseDOM(item, 'span', attrs={'itemprop': 'name'})[0]
                vid_url = parseDOM(item, 'a', ret='href')[0]
                img = parseDOM(item, 'img', ret='src')[0]
                try:
                    album = parseDOM(item, 'span', attrs={'itemprop': 'inAlbum'})[0]
                    m_name = find_data.findall(album)[0]
                    m_year = re.findall(r'\(.+?\)', album, re.MULTILINE)
                    m_year = m_year[0].replace('(', '').replace(')', '') if m_year else ''
                    album = f'{m_name} - {m_year}'
                except: album = ''
                try:
                    artist = parseDOM(item, 'span', attrs={'itemprop': 'byArtist'})[0]
                    artist = find_data.findall(artist)[0]
                except: artist = ''
                songs.append({'title': title, 'pg_no': pg_no, 'mode': 'geetm_vid_list', 'album': album, 'plot': f'album: {album}\nArtist: {artist}', 'url': base_link + vid_url, 'poster': base_link + img, 'isfolder': True})
            except: pass
        if nextpg:
            # logger(f'get_yt_vid_links pg_no {type(pg_no)} {repr(pg_no)}')
            pg_no = int(pg_no) + 1
            if '?page=' not in url: url += f'?page={pg_no}'
            else:
                url = url.split('=')[0]
                url += f'={pg_no}'
        else: nextpg = False

    if nextpg:
        xname = re.sub('Next Page: \d{1,2}', '', rtitle)
        title = f'{xname} Next Page: {pg_no}'
        next_pg_dict = {'title': title, 'pg_no': str(pg_no), 'mode': 'geetm_list', 'plot': 'Go To Next Page....', 'url': url, 'poster': nextpage, 'isfolder': True}
        songs.append(next_pg_dict)
    # logger('totle from url: %s pg_no: %s song: %s \n %s' % (params['url'], pg_no, len(songs), songs))
    return songs


def get_yt_vid_links(params):
    # logger(f'get_yt_vid_links params {params}')
    title, url, album, thumb = params.get('title'), params.get('url'), params.get('album'), params.get('poster')
    vid_page = request(url)
    # logger(f'search vid_page {vid_page}')
    result = parseDOM(vid_page, 'table', attrs={'class': 'b1 w760 alcen'})
    result += parseDOM(vid_page, 'table', attrs={'class': 'b1 allef w100p'})
    choices = []
    # logger(f'result: {result}')
    choice_param = {'title': f'Song : {title}', 'mode': 'geetm_plvid', 'poster': thumb, }
    try:
        link = parseDOM(result, 'iframe', ret='src')[0]
        if 'youtube.com/embed' in link:
            if v_id := link.replace('https://www.youtube.com/embed/', '').strip():
                v_link = f'{play_youtube_url}={v_id}'
                choices.append(dict(choice_param, **{'url': v_link}))
    except:
        for item in result:
            if r := re.findall(r'''<lite-youtube.+?videoid="([^"]+)''', item, re.DOTALL):
                choices.append(dict(choice_param, **{'url': f'{play_youtube_url}={r[0]}'}))
        song_item = parseDOM(vid_page, 'div', attrs={'class': 'yt_nt'})
        # logger(f'song_item: {song_item}')
        results = parseDOM(song_item, 'a', attrs={'class': 'yt_nt'})
        # logger(f'results: {results}')
        for item in results:
            if v_id := item.replace('https://www.youtube.com/watch?v=', '').strip():
                v_link = f'{play_youtube_url}={v_id}'
                choices.append(dict(choice_param, **{'url': v_link}))

    links = parseDOM(result, 'tr')
    find_data = re.compile('<td>(.+?)</td>')
    found_movie = False
    for link in links:
        # logger(f'from Movie link: \n{link}\n>>>>>\n')
        td_data = find_data.findall(link)
        try:
            if 'Watch Full Movie:' in td_data[0]:
                movie_link = parseDOM(td_data[1], 'a', ret='href')
                # logger(f'from youtube movie links: {movie_link}')
                for link_item in movie_link:
                    v_id = link_item.replace('https://www.youtube.com/watch?v=', '').strip()
                    if v_link := f'{play_youtube_url}={v_id}':
                        found_movie = True
                        choices.append(dict(choice_param, **{'url': v_link, 'title': f'Movie: {album}'}))
        except: pass
    if not found_movie: choices = Movie_search().search(album, choices)
    return choices


def get_yt_links(params):
    string = f'content_geetm_yt_links_{urlencode(params)}'
    choices = main_cache.get(string)
    if not choices or params.get('rescrap') == 'true':
        # logger(f'get_yt_links url: {url}\ntitle: {title}\nAlbum: {album}')
        choices = get_yt_vid_links(params)
        if choices: main_cache.set(string, choices, expiration=24) # 1 day

    # logger(f'rescrap: {rescrap} choices {choices}')
    from sys import argv
    handle = int(argv[1])
    is_external = external()
    add_items(handle, list(get_list_item(choices, 'youtube')))
    set_content(handle, 'videos')
    set_category(handle, 'videos')
    end_directory(handle, cacheToDisc=not is_external)
    set_view_mode('view.videos', 'videos', is_external)


def play(stream, channel=None, xbmc_player=False):
    # logger(f'play stream: {stream} channel: {channel}')
    execute_builtin(f'RunPlugin({stream})')


class Movie_search:
    def __init__(self):
        self.key = 'AIzaSyCjf8izIeXa1oFZo7_HeL0WgrOq1WF_I1k'
        self.search_link = f'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=15&q=%s&key={self.key}'

    def search(self, title, choices):
        try:
            query = f'{title} full|Full movie|Movie'
            query_url = self.search_link % quote_plus(query)
            # logger(f'query: {query}')
            # query_url += '&relevanceLanguage=en'
            headers = {'Accept': 'application/json'}
            response = requests.get(query_url, headers=headers).json()
            # logger(f'search json response {response}')
            if error := response.get('error', []):
                message = error.get('message', [])
                logger(f'message: {message}')
                return None

            json_items = response.get('items', [])
            # logger(f'search json_items {json_items} json_items {to_utf8(json_items)}')
            for search_result in json_items:
                try:
                    query = title.split('-')[0].lower().replace('.', '')
                    item_title = normalize(search_result['snippet']['title'].replace('.', ''))
                    if re.search('Full Movie|Movie', item_title, re.I) and re.search(query, item_title, re.I) and search_result['id']['kind'] == 'youtube#video':
                        vid_id = search_result['id']['videoId']
                        payload = {'id': vid_id, 'part': 'contentDetails', 'key': self.key}
                        url = f'https://www.googleapis.com/youtube/v3/videos/?&{urlencode(payload)}'
                        resp_dict = requests.get(url, headers=headers).json()
                        # resp_dict = self.session.get('https://www.googleapis.com/youtube/v3/videos', params=payload).json()
                        dur = resp_dict['items'][0]['contentDetails']['duration']
                        duration = convert_youtube_duration_to_minutes(dur)
                        # logger(f'dur: {dur} duration: {duration}')
                        if duration > 70:
                            v_link = f'{play_youtube_url}={vid_id}'
                            # logger(f'item_title: {item_title} v_link: {v_link}')
                            choices.append({'title': f'Movie: ({duration} minutes) {item_title}', 'mode': 'geetm_plvid', 'url': v_link})
                except: logger(f'Error: {print_exc()}')
        except: logger(f'Error: {print_exc()}')
        # logger(f'choices: {choices}')
        return choices