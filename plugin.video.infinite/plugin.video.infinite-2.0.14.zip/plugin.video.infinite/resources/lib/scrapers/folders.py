# -*- coding: utf-8 -*-
import os
import time
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from threading import Thread
from traceback import format_exc
from urllib.parse import urlparse

from caches.main_cache import cache_object
from modules.kodi_utils import file_stat, kodi_monitor, list_dirs, logger, open_file, path_exists
from modules.settings import filter_by_name

from modules import source_utils
from modules.utils import clean_file_name, normalize


class source:
	def __init__(self, scrape_provider, scraper_name, folder_path):
		self.scrape_provider = scrape_provider
		self.scraper_name = scraper_name
		self.folder_path = folder_path
		self.sources, self.scrape_results = [], []
		self.extensions = source_utils.supported_video_extensions()
		self.timeout = 30
		self.monitor = kodi_monitor()

	def results(self, info):
		try:
			# from traceback import print_stack
			# from modules.kodi_utils import logger
			# logger(f':> {self.scrape_provider}, {self.scraper_name}, {self.folder_path}\ninfo: {info}')
			if not self.folder_path:
				return source_utils.internal_results(self.scraper_name, self.sources)
			# ← fix #2: single call, no cache, raises on failure
			try:
				root_entries = self._make_dirs(self.folder_path, raise_on_error=True)
			except Exception as e:
				logger(f"ERROR: Cannot access {self.folder_path}: {e}")
				return
			if not root_entries:
				logger(f"WARNING: {self.folder_path} is accessible but empty")
				return
			filter_title = filter_by_name('folders')
			self.media_type = info.get('media_type')
			title = info.get('title')
			self.year = int(info['year']) if info.get('year') else None  # ← fix #1
			self.season, self.episode = info.get('season'), info.get('episode')
			self.tmdb_id = info.get('tmdb_id')
			self.title_query = source_utils.clean_title(normalize(title))
			# ← fix #3: compute ONCE here, not inside _crawl_folder
			self.folder_query = tuple(
				self._season_query_list() if self.media_type == 'episode' else self._year_query_list()
			)
			aliases = source_utils.get_aliases_titles(info.get('aliases', []))
			# Stream crawler results
			for item in self._scraper_worker(root_entries, root_folder=self.folder_path, timeout=self.timeout, max_workers=8):
				try:
					file_name = normalize(item[0])
					if filter_title and not source_utils.check_title(title, file_name, aliases, self.year, self.season, self.episode):
						continue
					url_dl = item[1]
					size = item[2]
					if size is None:
						if file_name.endswith('.strm'):
							size = 'strm'
						else:
							try:
								size = round(file_stat(url_dl).st_size() / 1073741824.0, 2)  # ← fix #4: only stat non-strm
							except Exception:
								size = 0.0

					display_name = clean_file_name(file_name).replace('html', ' ').replace('+', ' ').replace('-', ' ')
					quality, details = source_utils.get_file_info(name_info=source_utils.release_info_format(file_name))

					# ← fix #5: safe size label
					size_label = 'strm' if size == 'strm' else f'{size:.2f} GB'

					self.sources.append({
						'name': display_name, 'quality': quality,
						'size': size, 'size_label': size_label,
						'extraInfo': details, 'url_dl': url_dl, 'id': url_dl,
						self.scrape_provider: True, 'direct': True,
						'source': self.scraper_name, 'scrape_provider': 'folders',
					})
					if len(self.sources) >= 1:
						break
				except Exception:
						logger(f'Result processing:\n{format_exc()}')
			if self.sources:
				Thread(target=self.wake_drive, args=(self.sources[0]['url_dl'],), daemon=True).start()
				source_utils.internal_results(self.scrape_provider, self.sources)
			else:
				logger(f'No results found for {title} in SMB dir {self.folder_path}')
		except Exception:
			logger(f'folders results:\n{format_exc()}')
		return self.sources

	def _make_dirs(self, folder_name, raise_on_error=False):  # ← fix #6
		folder_files = []
		try:
			dirs, files = list_dirs(folder_name)
			folder_files.extend((d, 'folder', 0) for d in dirs)
			folder_files.extend((f, 'file', None) for f in files)
		except Exception as e:
			if raise_on_error:
				raise
			logger(f'_make_dirs:\n{format_exc()}')
		return folder_files


	def _scraper_worker(self, root_entries, root_folder, timeout=20, max_workers=4):
		"""
		Streaming folder crawler.
		Yields: (file_name, url, size)
		"""
		visited = {root_folder}
		start_time = time.time()
		# Process root folder entries directly (no executor needed for 1 folder)
		root_files, root_folders = self._process_entries(root_entries, root_folder)
		for item in root_files:
			yield item

		with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix='folderscraper') as executor:
			# Submit root's subfolders
			futures = {}
			for next_folder in root_folders:
				if next_folder not in visited:
					visited.add(next_folder)
					futures[executor.submit(self._crawl_folder, next_folder)] = next_folder

			while futures:
				if self.monitor.abortRequested():
					logger('Folder scrape aborted')
					for f in futures:
						f.cancel()
					break

				if (time.time() - start_time) >= timeout:
					logger(f'Folder scrape timeout ({timeout}s)')
					for f in futures:
						f.cancel()
					break
				done, _ = wait(futures, timeout=1, return_when=FIRST_COMPLETED)
				for future in done:
					folder = futures.pop(future, None)
					try:
						files, folders = future.result()
					except Exception:
						logger(f'{folder}:\n{format_exc()}')
						continue
					# Stream files immediately
					for item in files:
						yield item
					# Schedule new folders
					for next_folder in folders:
						if next_folder not in visited:
							visited.add(next_folder)
							futures[executor.submit(self._crawl_folder, next_folder)] = next_folder

	def _process_entries(self, entries, folder_name):
		"""Split raw entries into (files, folders) — extracted from _crawl_folder for reuse."""
		files, folders = [], []
		for item in entries:
			file_name, item_type = item[0], item[1]
			normalized = normalize(file_name)
			item_name = source_utils.clean_title(normalized)

			if item_type == 'file':
				ext = os.path.splitext(urlparse(file_name).path)[-1].lower()
				if ext not in self.extensions:
					continue
				if self.media_type == 'episode' and not source_utils.seas_ep_filter(self.season, self.episode, normalized):
					continue
				files.append((file_name, self.url_path(folder_name, file_name), item[2]))
			elif self.title_query in item_name or any(q in item_name for q in self.folder_query):
				folders.append(self.url_path(folder_name, file_name))
		return files, folders


	def _crawl_folder(self, folder_name):
		"""Called from worker threads. Returns (files, folders)."""
		try:
			cache_key = f'FOLDERSCRAPER_{self.scrape_provider}_{folder_name}'
			folder_files = cache_object(self._make_dirs, cache_key, (folder_name,), json=False, expiration=20)
			# ← fix #3: self.folder_query is set once in results(), read-only here
			return self._process_entries(folder_files, folder_name)
		except Exception:
			logger(f'_crawl_folder: {format_exc()}')
			return [], []

	def wake_drive(self, file_path):
		try:
			with open_file(file_path) as fh:
				fh.read(1)
		except Exception: pass

	def url_path(self, folder, name):
		return f'{folder.rstrip("/")}/{name}'

	def _year_query_list(self):
		year = self.year
		return str(year), str(year + 1), str(year - 1)

	def _season_query_list(self):
		season = int(self.season)
		return f'season{season:02d}', f'season{season}'
