# -*- coding: utf-8 -*-
import time
import json
from traceback import format_exc
from threading import Thread
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError
from threading import Lock, Event

from caches.external_cache import external_cache
from caches.settings_cache import get_setting
from modules.source_utils import sourcesstats, hosts_list, normalize, get_file_info
from modules.kodi_utils import logger, sleep, kodi_monitor, get_property, set_property, hide_busy_dialog



class source:
	def __init__(self, meta, source_dict, internal_scrapers, prescrape_sources, progress_dialog, disabled_ext_ignored=False):
		# logger(f'external source __init__: meta: {meta}\nsource_dict: {source_dict}\nactive_debrid: {active_debrid} internal_scrapers: {internal_scrapers} prescrape_sources: {prescrape_sources}\nprogress_dialog: {progress_dialog} disabled_ext_ignored: {disabled_ext_ignored}')
		self.monitor = kodi_monitor()
		self.scrape_provider = 'external'
		self.progress_dialog = progress_dialog
		self.meta = meta
		self.background = self.meta.get('background', False)
		self.source_dict, self.host_dict = source_dict, hosts_list
		self.sources, self.all_internal_sources, self.processed_internal_scrapers = [], [], []
		self.processed_internal_scrapers_append = self.processed_internal_scrapers.append
		self.internal_scrapers, self.prescrape_sources = internal_scrapers, prescrape_sources
		self.internal_activated, self.internal_prescraped = len(self.internal_scrapers) > 0, len(self.prescrape_sources) > 0
		self.processed_prescrape, self.threads_completed = False, False
		self.sleep_time = 100
		self.timeout = 60 if disabled_ext_ignored else int(get_setting('infinite.results.timeout', '20'))
		self.sources_total = self.sources_4k = self.sources_1080p = self.sources_720p = self.sources_sd = 0
		self.final_total = self.final_4k = self.final_1080p = self.final_720p = self.final_sd = 0
		self.count_tuple = (('sources_4k', '4K', self._quality_length), ('sources_1080p', '1080p', self._quality_length), ('sources_720p', '720p', self._quality_length),
							('sources_sd', '', self._quality_length_sd), ('sources_total', '', self.quality_length_final))
		self.count_tuple_final = (('final_4k', '4K', self._quality_length), ('final_1080p', '1080p', self._quality_length), ('final_720p', '720p', self._quality_length),
									('final_sd', '', self._quality_length_sd), ('final_total', '', self.quality_length_final))

	def results(self, info):
		# logger(f'>>> results info: {info}')
		if not self.source_dict: return
		try:
			self.media_type, self.tmdb_id, self.orig_title = info['media_type'], str(info['tmdb_id']), info['title']
			self.season, self.episode, self.total_seasons = info['season'], info['episode'], info['total_seasons']
			self.title, self.year, self.premiered = normalize(info['title']), info['year'], info['premiered']
			ep_name, self.aliases = normalize(info['ep_name']), info['aliases']
			self.display_name, self.imdb_id, self.tvdb_id = self.meta['display_name'], str(info['imdb_id']), str(info['tvdb_id'])
			# logger(f'>>> results ep_name: {repr(self.display_name)} ep_name: {repr(ep_name)}')
			self.single_expiry, self.season_expiry, self.show_expiry = info['expiry_times']
			if self.media_type == 'movie':
				self.season_divider, self.show_divider = 0, 0
				self.title, self.tvshowtitle, self.total_seasons = self.title, None, None
			else:
				try:
					self.season_divider = [int(x['episode_count']) for x in self.meta['season_data'] if int(x['season_number']) == int(self.meta['season'])][0]
					self.show_divider = int(self.meta['total_aired_eps'])
				except: self.season_divider, self.show_divider = 1, 1
				self.title, self.tvshowtitle, self.total_seasons = ep_name, self.title, self.total_seasons
		except: return []
		return self.get_sources()

	def get_sources(self):
		def _scraperDialog():
			hide_busy_dialog()
			sleep(200)
			start_time = time.time()
			while not self.progress_dialog.iscanceled() and not self.monitor.abortRequested():
				try:
					now = time.time()
					elapsed = now - start_time
					percent = min(100.0, elapsed * 100.0 / self.timeout)
					running = []
					if hasattr(self, 'provider_futures'):
						for future in self.provider_futures:
							if future.done(): continue
							provider_name = getattr(future, 'provider_display', '')
							if provider_name: running.append(provider_name)
					if self.internal_activated or self.internal_prescraped:
						running.extend(self.process_internal_results())
					self.progress_dialog.update_scraper(self.sources_sd, self.sources_720p, self.sources_1080p, self.sources_4k, self.sources_total, ', '.join(running).upper(), percent)
					running_count = len(running)
					if self.threads_completed:
						if running_count == 0: break
						if percent >= 100: break
						if running_count <= 1: break
						if self.sources_total >= 30: break
					elif percent >= 100: break
					sleep(self.sleep_time)
				except Exception: logger(f'_scraperDialog Error:\n{format_exc()}')

		def _background():
			sleep(1500)
			end_time = time.time() + self.timeout
			while time.time() < end_time:
				running_count = sum(1 for future in self.provider_futures if not future.done())
				if running_count <= 1: return
				if self.sources_total >= 100: return
				sleep(1000)
		self.sources = []
		self.threads_completed = False
		# Used by process_episode_threads() and process_movie_threads()
		self.running_providers = set()
		# Start scraping
		Thread(target=self.process_threads, name='process_threads', daemon=True).start()
		# UI handling
		if self.background: _background()
		else: _scraperDialog()
		# logger(f'get_sources b4 total return {len(self.sources)} self.sources: {self.sources}')
		current_results = list(self.sources)
		if current_results: # Final snapshot
			Thread(target=sourcesstats, args=(self.source_dict, current_results), daemon=True).start()
			return self.process_results(current_results)
		return []

	def process_threads(self):
		self.provider_futures = []
		self.running_providers = set()
		self.threads_completed = False
		max_workers = min(len(self.source_dict), 16)
		timeout = getattr(self, 'provider_timeout', self.timeout)
		is_episode = self.media_type == 'episode'
		# Resolve once before the loop
		if is_episode:
			submit_fn = self.get_episode_source
			cache_args = (self.tmdb_id, self.tvshowtitle, self.year, self.season, self.episode)
		else:
			submit_fn = self.get_movie_source
			cache_args = (self.tmdb_id, self.title, self.year, '', '')
		try:
			with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix='provider') as executor:
				for i in self.source_dict: # Submit Providers
					provider = i[0]
					module = i[1]
					try: pack_arg = i[2]
					except Exception: pack_arg = ''
					provider_display = f'{provider} ({pack_arg})' if pack_arg else provider
					try: # get Cache first
						sources = external_cache.get(provider, self.media_type, *cache_args)
					except Exception:
						logger(f'Cache lookup failed for {self.media_type} {provider}:\n{format_exc()}')
						sources = None
					if sources: # Cached result
						logger(f'process_threads for {self.media_type} provider={provider_display} Total: {len(sources)} got from cache')
						if not self.background: self.process_quality_count(sources)
						self.sources.extend(sources)
						continue
					# Submit provider
					self.running_providers.add(provider_display)
					future = executor.submit(submit_fn, provider, module, pack_arg)
					future.provider = provider
					future.provider_display = provider_display
					self.provider_futures.append(future)
				# No providers submitted
				if not self.provider_futures: return
				try: # Collect results as they finish
					for future in as_completed(self.provider_futures, timeout=timeout):
						provider_display = getattr(future, 'provider_display', 'Unknown')
						try:
							sources = future.result()
							if sources:
								if not self.background: self.process_quality_count(sources)
								self.sources.extend(sources)
						except Exception: logger(f'for {self.media_type} {provider_display} future error:\n{format_exc()}')
						finally: self.running_providers.discard(provider_display)
				except TimeoutError:
					cancelled_count = 0
					for future in self.provider_futures:
						if future.done(): continue
						provider_display = getattr(future, 'provider_display', 'Unknown')
						# Only cancels queued jobs., Running jobs cannot be killed.
						if future.cancel(): cancelled_count += 1
						self.running_providers.discard(provider_display)
					logger(f'for {self.media_type} Provider timeout ({timeout}s) so Cancelled {cancelled_count} pending providers')
				for future in self.provider_futures: # Drain completed futures after timeout
					provider_display = getattr(future, 'provider_display', 'Unknown')
					if future.cancelled(): logger(f'Provider {provider_display} Provider cancelled'); continue
					if not future.done(): logger(f'Provider {provider_display} still running'); continue
					try: future.result()
					except Exception: pass
		except Exception: logger(f'for {self.media_type} process_threads Fatal Error:\n{format_exc()}')
		finally:
			self.running_providers.clear()
			self.threads_completed = True

	def get_movie_source(self, provider, module, pack):
		"""
		Worker function executed by ThreadPoolExecutor.
		Returns:
			list: Sources for this provider.
		"""
		# logger(f'get_movie_source provider: {provider} module: {module} pack: {pack}')
		try:
			# logger(f'get_movie_source provider={provider} cache miss')
			self.activate_display = True
			try:
				url = module.movie(self.tmdb_id, self.title, self.title, self.aliases, self.year)
			except: 
				logger(f'get_movie_source provider: {provider} module().movie Error: {format_exc()}')
				return []
			if not url: return []
			expiry_hours = self.single_expiry
			try: # Provider scrape
				sources = module.sources(url, self.host_dict)
			except Exception:
				logger(f'get_movie_source provider={provider} module.sources error:\n{format_exc()}')
				return []
			if not sources: return []
			# Normalize/process
			sources = self.process_sources(provider, sources)
			try: # Cache result
				external_cache.set(provider, self.media_type, self.tmdb_id, self.title, self.year, '', '', sources, expiry_hours)
			except Exception: logger(f'get_movie_source provider={provider} cache set error:\n{format_exc()}')
			return sources or []
		except Exception:
			logger(f'get_movie_source provider={provider} fatal error:\n{format_exc()}')
			return []
		finally:
			try: del module
			except Exception: pass

	def get_episode_source(self, provider, module, pack):
		"""
		Worker function executed by ThreadPoolExecutor.
		Returns:
			list: Sources for this provider.
		"""
		# logger(f'get_episode_source provider: {provider} module: {module} pack: {pack}')
		try:
			if pack in ('Season', 'Show'):
				s_check = '' if pack == 'Show' else self.season
				e_check = ''
			else: s_check, e_check = self.season, self.episode
			# logger(f'get_episode_source provider={provider} cache miss')
			self.activate_display = True
			try: # TV Show URL
				url = module.tvshow(self.imdb_id, self.tvdb_id, self.tvshowtitle, self.tvshowtitle, self.aliases, self.year)
			except Exception:
				logger(f'get_episode_source provider={provider} module.tvshow error:\n{format_exc()}')
				return []
			if not url: return []
			try: # Episode URL
				url = module.episode(url, self.imdb_id, self.tvdb_id, self.title, self.year, self.season, self.episode)
			except Exception:
				logger(f'get_episode_source provider={provider} module.episode error:\n{format_exc()}')
				return []
			if not url: return []
			expiry_hours = self.single_expiry
			try: # Provider scrape
				sources = module.sources(url, self.host_dict)
			except Exception:
				logger(f'get_episode_source provider={provider} module.sources error:\n{format_exc()}')
				return []
			if not sources: return []
			# Normalize/process
			sources = self.process_sources(provider, sources)
			try: # Cache result
				external_cache.set(provider, self.media_type, self.tmdb_id, self.tvshowtitle, self.year, s_check, e_check, sources, expiry_hours)
			except Exception: logger(f'get_episode_source provider={provider} cache set error:\n{format_exc()}')
			return sources or []
		except Exception:
			logger(f'get_episode_source provider={provider} fatal error:\n{format_exc()}')
			return []
		finally:
			try: del module
			except Exception: pass

	def process_results(self, results):
		def _process_duplicates(all_results):
			unique_urls, unique_hashes = set(), set()
			unique_urls_add, unique_hashes_add = unique_urls.add, unique_hashes.add
			for provider in all_results:
				try:
					url = provider['url'].lower()
					if url not in unique_urls:
						unique_urls_add(url)
						if 'hash' in provider:
							if provider['hash'] not in unique_hashes:
								unique_hashes_add(provider['hash'])
								yield provider
						else: yield provider
				except: yield provider
		# def _process_cache_check(provider, function):
		# 	cached = function(self.data, hash_list, cached_hashes)
		# 	if not self.background: self.process_quality_count_final([i for i in results if i['hash'] in cached])
		# 	final_results.extend([dict(i, **{'cache_provider': provider if i['hash'] in cached else 'Uncached %s' % provider, 'debrid': provider}) for i in results])
		try:
			if not self.background and self.all_internal_sources: self.process_quality_count_final(self.all_internal_sources)
			final_results = list(_process_duplicates(results))
			# logger(f'process_results {len(results)} results: {results}')
			return final_results
		except: return results

	def process_sources(self, provider, sources):
		try:
			for i in sources:
				try:
					i_get = i.get
					size, size_label, divider = 0, None, None
					if 'hash' in i:
						_hash = i_get('hash').lower()
						i['hash'] = str(_hash)
					info = i_get('info') or ''
					if 'name' not in i: i.update({'name': self.display_name})
					if 'name_info' in i: quality, extraInfo = get_file_info(name_info=i_get('name_info'))
					else: quality, extraInfo = get_file_info(url=i_get('url'))
					quality = i_get('quality') or quality
					try:
						size = i_get('size')
						size_label = '%.2f GB' % size
					except: pass
					extraInfo = extraInfo or info
					if not size: size = 0
					i.update({'scrape_provider': self.scrape_provider, 'extraInfo': extraInfo, 'provider_site': provider,
							'quality': quality, 'size_label': size_label, 'size': round(size, 2)})
				except: logger(f'process_sources i: {i}\nError: {format_exc()}')
		except: pass
		return sources

	def process_quality_count(self, sources):
		for item in self.count_tuple: setattr(self, item[0], getattr(self, item[0]) + item[2](sources, item[1]))

	def process_quality_count_final(self, sources):
		for item in self.count_tuple_final: setattr(self, item[0], getattr(self, item[0]) + item[2](sources, item[1]))

	def process_internal_results(self):
		if self.internal_prescraped and not self.processed_prescrape:
			self.all_internal_sources += self.prescrape_sources
			self.process_quality_count(self.prescrape_sources)
			self.processed_prescrape = True
		for i in self.internal_scrapers:
			win_property = get_property('infinite.internal_results.%s' % i)
			if win_property in ('checked', '', None): continue
			try: internal_sources = json.loads(win_property)
			except: continue
			set_property('infinite.internal_results.%s' % i, 'checked')
			self.all_internal_sources += internal_sources
			self.processed_internal_scrapers_append(i)
			self.process_quality_count(internal_sources)
		return [i for i in self.internal_scrapers if i not in self.processed_internal_scrapers]

	def _quality_length(self, items, quality):
		return len([i for i in items if i['quality'] == quality])

	def _quality_length_sd(self, items, dummy):
		return len([i for i in items if i['quality'] in ('SD', 'CAM', 'TELE', 'SYNC')])

	def quality_length_final(self, items, dummy):
		return len(items)
