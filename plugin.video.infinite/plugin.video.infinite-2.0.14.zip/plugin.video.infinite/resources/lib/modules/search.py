# -*- coding: utf-8 -*-
import json
from urllib.parse import unquote
from caches.main_cache import main_cache
from indexers.images import Images
from modules.kodi_utils import close_all_dialog, external, build_url, kodi_dialog, execute_builtin, list_dialog, notification, kodi_refresh, logger


def get_key_id(params):
	close_all_dialog()
	params_key_id = params.get('key_id', None)
	key_id = params_key_id or kodi_dialog().input('')
	if not key_id: return
	key_id = unquote(key_id)
	media_type = params.get('media_type', '')
	search_type = params.get('search_type', 'media_title')
	string, url_params = None, {}
	if search_type == 'media_title':
		if media_type == 'movie': url_params, string = {'mode': 'build_movie_list', 'action': 'tmdb_movies_search'}, 'movie_queries'
		else: url_params, string = {'mode': 'build_tvshow_list', 'action': 'tmdb_tv_search'}, 'tvshow_queries'
	elif search_type == 'people': string = 'people_queries'
	elif search_type == 'tmdb_keyword':
		url_params, string = {'mode': 'navigator.keyword_results', 'media_type': media_type, 'search_type': 'tmdb'}, 'keyword_tmdb_%s_queries' % media_type
	elif search_type == 'imdb_keyword_movie':
		 url_params, string = {'mode': 'build_movie_list', 'action': 'imdb_keyword_movie'}, 'keyword_imdb_movie_queries'
	elif search_type == 'imdb_keyword_tvshow':
		url_params, string = {'mode': 'build_tvshow_list', 'action': 'imdb_keyword_tvshow'}, 'keyword_imdb_tvshow_queries'
	elif search_type == 'easynews_video':
		url_params, string = {'mode': 'easynews.search_easynews'}, 'easynews_video_queries'
	elif search_type == 'easynews_image':
		url_params, string = {'mode': 'easynews.search_easynews_image'}, 'easynews_image_queries'
	elif search_type == 'trakt_lists':
		url_params, string = {'mode': 'trakt.list.search_trakt_lists'}, 'trakt_list_queries'
	if string: add_to_search(key_id, string)
	if search_type == 'people': return Images().run({'mode': 'tmdb_people_search_image_results', 'key_id': key_id, 'page_no': 1})
	if search_type == 'easynews_image': return #search_easynews_image(key_id)
	url_params.update({'key_id': key_id, 'name': 'Search Results for %s' % key_id})
	return execute_builtin('ActivateWindow(Videos,%s,return)' if external() else 'Container.Update(%s)' % build_url(url_params))

def add_to_search(search_name, search_list):
	try:
		result = cache if (cache := main_cache.get(search_list)) else []
		if search_name in result: result.remove(search_name)
		result.insert(0, search_name)
		result = result[:50]
		main_cache.set(search_list, result, expiration=8760)
	except: return

def remove_from_search(params):
	try:
		result = main_cache.get(params['setting_id'])
		result.remove(params.get('key_id'))
		main_cache.set(params['setting_id'], result, expiration=8760)
		notification('Success', 2500)
		kodi_refresh()
	except: return

def clear_search():
	all_items = [
		{'name': 'Clear Movie Search History', 'value': 'movie_queries'},
		{'name': 'Clear TV Show Search History', 'value': 'tvshow_queries'},
		{'name': 'Clear People Search History', 'value': 'people_queries'},
		{'name': 'Clear Keywords Movie Search History', 'value': 'keyword_tmdb_movie_queries'},
		{'name': 'Clear Keywords TV Show Search History', 'value': 'keyword_tmdb_tvshow_queries'},
		{'name': 'Clear Trakt List Search History', 'value': 'trakt_list_queries'}]
	try:
		kwargs = {'all_items': all_items, 'mode': 'select', 'narrow_window': 'true'}
		choice = list_dialog(**kwargs)
		if choice == None: return
		setting_id = choice['value']
		clear_all(setting_id)
	except: return

def clear_all(setting_id, refresh='false'):
	main_cache.set(setting_id, '', expiration=365)
	notification('Success', 2500)
	if refresh == 'true': kodi_refresh()
