# -*- coding: utf-8 -*-
from caches.base_cache import open_db, serialize_db_value, deserialize_db_value
from modules.kodi_utils import logger, get_property, set_property, clear_property
from modules.fen_online_utils import single_sync

class NavigatorCache:
	root_list = [
	{'name': 'Most', 'mode': 'navigator.build_shortcut_folder_contents', 'iconImage': 'infinite'},
	{'name': 'Next Episodes', 'mode': 'build_single_episode', 'list_type': 'next', 'iconImage': 'next_episodes'},
	{'name': 'Hindi VOD', 'mode': 'navigator.vod_hindi', 'iconImage': 'h_icon'},
	{'name': 'Other Items', 'mode': 'navigator.vod_movies', 'iconImage': 'h_movies'},
	{'name': 'Movies', 'mode': 'navigator.main', 'action': 'MovieList', 'iconImage': 'movies'},
	{'name': 'TV Shows', 'mode': 'navigator.main', 'action': 'TVShowList', 'iconImage': 'tv'},
	{'name': 'My Lists', 'mode': 'navigator.my_lists', 'iconImage': 'lists'},
	{'name': 'Search', 'mode': 'navigator.search', 'iconImage': 'search'},
	{'name': 'Tools', 'mode': 'navigator.tools', 'iconImage': 'settings2'}]

	movie_list = [
	{'name': 'Trending', 'mode': 'build_movie_list', 'action': 'imdb_movies_trending', 'random_support': 'true', 'iconImage': 'trending'},
	{'name': 'Trending Recent', 'mode': 'build_movie_list', 'action': 'imdb_movies_trending_recent', 'random_support': 'true', 'iconImage': 'trending_recent'},
	{'name': 'Popular', 'mode': 'build_movie_list', 'action': 'tmdb_movies_popular', 'random_support': 'true', 'iconImage': 'popular'},
	{'name': 'Popular Today', 'mode': 'build_movie_list', 'action': 'tmdb_movies_popular_today', 'random_support': 'true', 'iconImage': 'popular_today'},
	{'name': 'Premieres', 'mode': 'build_movie_list', 'action': 'tmdb_movies_premieres', 'random_support': 'true', 'iconImage': 'fresh'},
	{'name': 'Oscar Winners', 'mode': 'build_movie_list', 'action': 'tmdb_movies_oscar_winners', 'random_support': 'true', 'iconImage': 'oscar_winners'},
	{'name': 'Decades', 'mode': 'navigator.decades', 'menu_type': 'movie', 'iconImage': 'calendar_decades'},
	{'name': 'Top Rated Recent', 'mode': 'build_movie_list', 'action': 'imdb_movies_top_rated_recent', 'random_support': 'true', 'iconImage': 'rated'},
	{'name': 'Blockbusters Recent', 'mode': 'build_movie_list', 'action': 'tmdb_movies_blockbusters_recent', 'random_support': 'true', 'iconImage': 'tickets'},
	{'name': 'Hidden Gems', 'mode': 'build_movie_list', 'action': 'imdb_movies_hidden_gems', 'random_support': 'true', 'iconImage': 'gem'},
	{'name': 'Upcoming', 'mode': 'build_movie_list', 'action': 'tmdb_movies_upcoming', 'random_support': 'true', 'iconImage': 'shorts'},
	{'name': 'True Crime', 'mode': 'build_movie_list', 'action': 'imdb_movies_true_crime', 'random_support': 'true', 'iconImage': 'genre_crime'},
	{'name': 'Genres', 'mode': 'navigator.genres', 'menu_type': 'movie', 'random_support': 'true', 'iconImage': 'genres'},
	{'name': 'Languages', 'mode': 'navigator.languages', 'menu_type': 'movie', 'random_support': 'true', 'iconImage': 'languages'},
	{'name': 'Years', 'mode': 'navigator.years', 'menu_type': 'movie', 'random_support': 'true', 'iconImage': 'calender'},
	{'name': 'Certifications', 'mode': 'navigator.certifications', 'menu_type': 'movie', 'random_support': 'true', 'iconImage': 'certifications'},
	{'name': 'Watched', 'mode': 'build_movie_list', 'action': 'watched_movies', 'iconImage': 'watched_1'},
	{'name': 'In Progress', 'mode': 'build_movie_list', 'action': 'in_progress_movies', 'iconImage': 'player'}]

	tvshow_list = [
	{'name': 'Trending', 'mode': 'build_tvshow_list', 'action': 'imdb_tv_trending', 'random_support': 'true', 'iconImage': 'trending'},
	{'name': 'Trending Recent', 'mode': 'build_tvshow_list', 'action': 'imdb_tv_trending_recent', 'random_support': 'true', 'iconImage': 'trending_recent'},
	{'name': 'Trending Reality', 'mode': 'build_tvshow_list', 'action': 'imdb_tv_trending_reality', 'random_support': 'true', 'iconImage': 'trending_reality'},
	{'name': 'Popular', 'mode': 'build_tvshow_list', 'action': 'tmdb_tv_popular', 'random_support': 'true', 'iconImage': 'popular'},
	{'name': 'Popular Today', 'mode': 'build_tvshow_list', 'action': 'tmdb_tv_popular_today', 'random_support': 'true', 'iconImage': 'popular_today'},
	{'name': 'Premieres', 'mode': 'build_tvshow_list', 'action': 'tmdb_tv_premieres', 'random_support': 'true', 'iconImage': 'fresh'},
	{'name': 'Languages', 'mode': 'navigator.languages', 'menu_type': 'tvshow', 'random_support': 'true', 'iconImage': 'languages'},
	{'name': 'Decades', 'mode': 'navigator.decades', 'menu_type': 'tvshow', 'iconImage': 'calendar_decades'},
	{'name': 'Top Rated Recent', 'mode': 'build_tvshow_list', 'action': 'imdb_tv_top_rated_recent', 'random_support': 'true', 'iconImage': 'rated'},
	{'name': 'Hidden Gems', 'mode': 'build_tvshow_list', 'action': 'imdb_tv_hidden_gems', 'random_support': 'true', 'iconImage': 'gem'},
	{'name': 'Upcoming', 'mode': 'build_tvshow_list', 'action': 'tmdb_tv_upcoming', 'random_support': 'true', 'iconImage': 'shorts'},
	{'name': 'True Crime', 'mode': 'build_tvshow_list', 'action': 'imdb_tv_true_crime', 'random_support': 'true', 'iconImage': 'genre_crime'},
	{'name': 'Genres', 'mode': 'navigator.genres', 'menu_type': 'tvshow', 'random_support': 'true', 'iconImage': 'genres'},
	{'name': 'Years', 'mode': 'navigator.years', 'menu_type': 'tvshow', 'random_support': 'true', 'iconImage': 'calender'},
	{'name': 'Watched', 'mode': 'build_tvshow_list', 'action': 'watched_tvshows', 'iconImage': 'watched_1'},
	{'name': 'In Progress', 'mode': 'build_tvshow_list', 'action': 'in_progress_tvshows', 'iconImage': 'in_progress_tvshow'},
	{'name': 'In Progress Episodes', 'mode': 'build_single_episode', 'list_type': 'progress', 'iconImage': 'player'},
	{'name': 'Next Episodes', 'mode': 'build_single_episode', 'list_type': 'next', 'iconImage': 'next_episodes'}
]

	main_menus = {'RootList': root_list, 'MovieList': movie_list, 'TVShowList': tvshow_list}

	def get_main_lists(self, list_name):
		default_contents = self.get_memory_cache(list_name, 'default')
		if not default_contents:
			default_contents = self.get_list(list_name, 'default')
			if default_contents is None:
				self.rebuild_database()
				return self.get_main_lists(list_name)
			try: edited_contents = self.get_list(list_name, 'edited')
			except: edited_contents = None
		else: edited_contents = self.get_memory_cache(list_name, 'edited')
		return default_contents, edited_contents

	def get_list(self, list_name, list_type):
		contents = None
		try:
			with open_db('navigator_db') as dbcon:
				contents = deserialize_db_value(dbcon.execute('SELECT list_contents FROM navigator WHERE list_name = ? AND list_type = ?', (list_name, list_type)).fetchone()[0])
			self.set_memory_cache(list_name, list_type, contents)
		except: pass
		return contents

	@single_sync('navigator_db', 'navigator')
	def set_list(self, list_name, list_type, list_contents):
		with open_db('navigator_db') as dbcon: dbcon.execute('INSERT OR REPLACE INTO navigator VALUES (?, ?, ?)', (list_name, list_type, serialize_db_value(list_contents)))
		self.set_memory_cache(list_name, list_type, list_contents)
		return 'Success'

	@single_sync('navigator_db', 'navigator')
	def delete_list(self, list_name, list_type):
		with open_db('navigator_db') as dbcon:
			dbcon.execute('DELETE FROM navigator WHERE list_name=? and list_type=?', (list_name, list_type))
			dbcon.execute('VACUUM')
		self.delete_memory_cache(list_name, list_type)
		return 'Success'

	def get_memory_cache(self, list_name, list_type):
		try: return deserialize_db_value(get_property(self._get_list_prop(list_type) % list_name))
		except: return None

	def set_memory_cache(self, list_name, list_type, list_contents):
		set_property(self._get_list_prop(list_type) % list_name, serialize_db_value(list_contents))

	def delete_memory_cache(self, list_name, list_type):
		clear_property(self._get_list_prop(list_type) % list_name)

	def get_shortcut_folders(self):
		try:
			with open_db('navigator_db') as dbcon: folders = dbcon.execute('SELECT list_name, list_contents FROM navigator WHERE list_type = ?', ('shortcut_folder',)).fetchall()
			folders = sorted([(str(i[0]), deserialize_db_value(i[1])) for i in folders], key=lambda s: s[0].lower())
		except: folders = []
		return folders

	def get_shortcut_folder_contents(self, list_name):
		try:
			with open_db('navigator_db') as dbcon:
				contents = deserialize_db_value(dbcon.execute('SELECT list_contents FROM navigator WHERE list_name = ? AND list_type = ?', (list_name, 'shortcut_folder')).fetchone()[0])
		except: contents = []
		return contents

	def currently_used_list(self, list_name):
		try: used_list = self.get_memory_cache(list_name, 'edited') or self.get_memory_cache(list_name, 'default') \
						or self.get_list(list_name, 'edited') or self.get_list(list_name, 'default')
		except: used_list = []
		if not used_list:
			self.rebuild_database()
			used_list = self.main_menus[list_name]
		return used_list

	def rebuild_database(self):
		main_items = self.main_menus.items()
		for list_name, list_contents in main_items: self.set_list(list_name, 'default', list_contents)

	def _get_list_prop(self, list_type):
		return {'default': 'infinite_%s_default', 'edited': 'infinite_%s_edited', 'shortcut_folder': 'infinite_%s_shortcut_folder'}[list_type]

	def random_movie_lists(self):
		movie_random_converts = {'navigator.genres': 'tmdb_movies_genres',  'navigator.languages': 'tmdb_movies_languages', 'navigator.years': 'tmdb_movies_year',
							'navigator.certifications': 'tmdb_movies_certifications'}
		return [dict(i, **{'mode': 'random.build_movie_list', 'action': i.get('action') or movie_random_converts[i['mode']],
							'random': 'true', 'name': 'Movies Random %s' % i['name'], 'menu_type': 'movie'}) for i in NavigatorCache.movie_list if 'random_support' in i]

	def random_tvshow_lists(self):
		tvshow_random_converts = {'navigator.genres': 'tmdb_tv_genres',  'navigator.languages': 'tmdb_tv_languages', 'navigator.years': 'tmdb_tv_year'}
		return [dict(i, **{'mode': 'random.build_tvshow_list', 'action': i.get('action') or tvshow_random_converts[i['mode']],
							'random': 'true', 'name': 'TV Shows Random %s' % i['name'], 'menu_type': 'tvshow'}) for i in NavigatorCache.tvshow_list if 'random_support' in i]

	def random_personal_lists(self):
		return [
			{'mode': 'personal_lists.get_personal_lists', 'name': 'Personal Lists (All)', 'iconImage': 'lists', 'random': 'true'},
			{'mode': 'random.build_personal_lists', 'name': 'Random Personal Lists (Single)', 'iconImage': 'lists', 'random': 'true'}
				]

	def random_tmdb_lists(self):
		return [
			{'mode': 'random.build_tmdb_lists_contents', 'list_id': 'watchlist', 'media_type': 'movie', 'name': 'Random TMDb Movie Watchlist', 'iconImage': 'tmdb', 'random': 'true'},
			{'mode': 'random.build_tmdb_lists_contents', 'list_id': 'watchlist', 'media_type': 'tv', 'name': 'Random TMDb TV Show Watchlist', 'iconImage': 'tmdb', 'random': 'true'},
			{'mode': 'random.build_tmdb_lists_contents', 'list_id': 'favorites', 'media_type': 'movie', 'name': 'Random TMDb Movie Favorites', 'iconImage': 'tmdb', 'random': 'true'},
			{'mode': 'random.build_tmdb_lists_contents', 'list_id': 'favorites', 'media_type': 'tv', 'name': 'Random TMDb TV Show Favorites', 'iconImage': 'tmdb', 'random': 'true'},
			{'mode': 'random.build_tmdb_lists_contents', 'list_id': 'recommendations', 'media_type': 'movie', 'name': 'Random TMDb Movie Recommendations', 'iconImage': 'tmdb', 'random': 'true'},
			{'mode': 'random.build_tmdb_lists_contents', 'list_id': 'recommendations', 'media_type': 'tv', 'name': 'Random TMDb TV Show Recommendations', 'iconImage': 'tmdb', 'random': 'true'},
			{'mode': 'tmdblist.get_tmdb_lists', 'name': 'Random Shuffled TMDb My Lists (All)', 'iconImage': 'tmdb', 'random': 'true', 'shuffle': 'true'},
			{'mode': 'random.build_tmdb_lists', 'name': 'Random TMDb My Lists (Single)', 'iconImage': 'tmdb', 'random': 'true'}
				]

navigator_cache = NavigatorCache()
