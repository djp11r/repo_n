# -*- coding: utf-8 -*-
import sys
import json
from traceback import format_exc
from modules.meta_lists import context_menu_defaults
from modules.metadata import movie_meta
from modules.utils import get_datetime, get_current_timestamp, paginate_list, TaskPool, manual_function_import, jsondate_to_datetime
from modules import kodi_utils, settings, watched_status
logger = kodi_utils.logger

class Movies:
	tmdb_main_set = {'tmdb_movies_popular', 'tmdb_movies_popular_today', 'tmdb_movies_premieres', 'tmdb_movies_trending', 'tmdb_movies_trending_recent',
					'tmdb_movies_upcoming', 'tmdb_movies_blockbusters_recent'}
	imdb_main_set = {'imdb_movies_trending', 'imdb_movies_trending_recent', 'imdb_movies_top_rated_recent', 'imdb_movies_hidden_gems', 'imdb_movies_true_crime'}
	special_set_tmdb = {'tmdb_movies_languages', 'tmdb_movies_year', 'tmdb_movies_certifications', 'tmdb_movies_recommendations', 'tmdb_movies_discover',
					'tmdb_movies_genres', 'tmdb_movies_search', 'tmdb_movie_keyword_results'}
	special_set_imdb = {'imdb_keyword_movie'}
	personal_set = {'in_progress_movies', 'favorites_movies', 'watched_movies'}
	trailer_url = 'plugin://plugin.video.infinite/?mode=default_trailer_choice&media_type=movie&tmdb_id=%s&imdb_id=%s'

	def __init__(self, params):
		self.params = params
		self.params_get = self.params.get
		self.category_name = self.params_get('category_name', None) or self.params_get('name', None) or 'Movies'
		self.id_type, self.list, self.action = self.params_get('id_type', 'tmdb_id'), self.params_get('list', []), self.params_get('action', None)
		self.tmdb_api_key = settings.tmdb_api_key()
		self.items, self.new_page, self.total_pages, self.is_external = [], {}, None, kodi_utils.external()
		if self.is_external: self.widget_hide_next_page = settings.widget_hide_next_page()
		else: self.widget_hide_next_page = False
		self.custom_order = self.params_get('custom_order', 'false') == 'true'
		self.paginate_start = int(self.params_get('paginate_start', '0'))
		self.append = self.items.append
		self.movieset_list_active = False

	def fetch_list(self):
		handle = int(sys.argv[1])
		try:
			try: page_no = int(self.params_get('new_page', '1'))
			except: page_no = self.params_get('new_page')
			if page_no == 1 and not self.is_external: kodi_utils.set_property('infinite.exit_params', kodi_utils.folder_path())
			if self.action in self.tmdb_main_set: function = self.fetch_tmdb_main
			elif self.action in self.imdb_main_set: function = self.fetch_imdb_main
			elif self.action in self.special_set_tmdb: function = self.fetch_tmdb_special
			elif self.action in self.special_set_imdb: function = self.fetch_imdb_special
			elif self.action in self.personal_set: function = self.fetch_personal
			elif self.action == 'movie_set': function = self.fetch_movie_set
			elif self.action == 'trakt_movies_related': function = self.fetch_trakt_movies_related
			else: function = None
			if function: function(page_no)
			if not self.list: kodi_utils.notification('No Results')
			kodi_utils.add_items(handle, self.worker())
			if self.new_page and not self.widget_hide_next_page:
				self.new_page = {**self.new_page, 'mode': 'build_movie_list', 'action': self.action, 'category_name': self.category_name}
				kodi_utils.add_dir(handle, self.new_page, 'Next Page (%s) >>' % self.new_page['new_page'], 'nextpage', kodi_utils.get_icon('nextpage_landscape'))
			if self.total_pages and self.total_pages > 2 and settings.jump_to_enabled() and not self.is_external:
				kodi_utils.add_dir(handle, {'mode': 'navigate_to_page_choice', 'current_page': page_no, 'total_pages': self.total_pages, 'url_params': json.dumps(self.new_page), 'all_pages': json.dumps(self.list)}, 'Jump To...', 'item_jump', kodi_utils.get_icon('item_jump_landscape'), isFolder=False)
		except: logger(f'MOVIES fetch_list self.params: {self.params}\ndata: {self.list}\nError: {format_exc()}')
		kodi_utils.set_content(handle, 'movies')
		kodi_utils.set_category(handle, self.category_name)
		kodi_utils.end_directory(handle, cacheToDisc=not self.is_external)
		if not self.is_external: kodi_utils.set_view_mode('view.movies', 'movies', self.is_external)

	def build_movie_content(self, _position, _id, dbcon):
		try:
			if isinstance(_id, dict):
				if _id.get('tmdb', None): self.id_type, _id = 'tmdb_id', _id['tmdb']
				elif _id.get('imdb', None): self.id_type, _id = 'imdb_id', _id['imdb']
			# logger(f'build_movie_content _position: {repr(_position)} _id: {repr(_id)}')
			meta = movie_meta(self.id_type, _id, self.tmdb_api_key, self.current_date, self.current_time, dbcon)
			if not meta or 'blank_entry' in meta: return
			# logger(f'build_movie_content meta: {repr(meta)}')
			meta_get = meta.get
			premiered = meta_get('premiered')
			tmdb_id, imdb_id = meta_get('tmdb_id'), meta_get('imdb_id')
			str_tmdb_id = str(tmdb_id)
			cm = []
			cm_append = cm.append
			cm_extend = cm.extend
			plugin_cmd = 'RunPlugin(%s)'
			build_url = self.build_url
			title = meta_get('title')
			try: year = int(meta_get('year') or 2050)
			except: year = 2050
			poster = meta_get('poster')
			if self.rpdb_api_key and poster:
				try: poster = (meta_get('rpdb_poster') % self.rpdb_api_key) + self.rpdb_format
				except: pass
			if not poster: poster = self.poster_empty
			fanart = meta_get('fanart') or self.fanart_empty
			clearlogo, landscape = meta_get('clearlogo') or '', meta_get('landscape') or ''
			extra_info = meta_get('extra_info', {})
			movieset_id, movieset_name = extra_info.get('collection_id', ''), extra_info.get('collection_name', '')
			# logger(f'build_movie_content premiered: {premiered} first_airdate: {repr(first_airdate)} self.current_date: {self.current_date}')
			tmdb_manager_params = self.build_url({'mode': 'tmdblists_manager_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'icon': poster})
			belongs_to_movieset = 'true' if (movieset_id and movieset_name) else 'false'
			movieset_active = self.open_movieset and belongs_to_movieset == 'true'
			progress = watched_status.get_progress_status_movie(self.bookmarks, str_tmdb_id)
			playcount = watched_status.get_watched_status_movie(self.watched_info, str_tmdb_id)
			play_params = {'mode': 'playback.media', 'media_type': 'movie', 'tmdb_id': tmdb_id}
			extras_params = {'mode': 'extras_menu_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id}
			url_params = extras_params if self.open_extras else play_params
			if movieset_active: url_params = {'mode': 'open_movieset_choice', 'key_id': movieset_id, 'name': movieset_name}
			url = self.build_url(url_params)
			########
			# url_parm = play_params.copy()
			play_params['mode'] = 'scrape_select'
			cm_append(['select',('Select Source', plugin_cmd % build_url(play_params))])
			play_params['mode'] = 'rescrape_select'
			cm_append(['rescrape',('Rescrape & Select Source', plugin_cmd % build_url(play_params))])
			########
			if self.open_extras or movieset_active: cm_append(['extras', ('[B]Play[/B]', plugin_cmd % build_url(play_params))])
			if not self.open_extras or movieset_active: cm_append(['extras', ('[B]Extras[/B]', plugin_cmd % build_url(extras_params))])
			play_params['mode'] = 'tmdblists_manager_choice'
			cm_extend([
				['tmdb_manager', ('TMDb Lists Manager', plugin_cmd % build_url(play_params))],
				['more_info', ('[B]More Info[/B]', plugin_cmd % build_url({'mode': 'media_info_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id}))],
					['options', ('[B]Options[/B]', plugin_cmd % build_url({'mode': 'options_menu_choice', 'content': 'movie', 'tmdb_id': tmdb_id, 'poster': poster}))],
					['browse_more', ('[B]Browse More[/B]', plugin_cmd % build_url({'mode': 'browse_more_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id,
								'imdb_id': imdb_id, 'title': title, 'poster': poster, 'movieset_name': movieset_name, 'movieset_id': movieset_id}))],
					['personal_manager', ('[B]Personal Lists Manager[/B]', plugin_cmd % build_url({'mode': 'personallists_manager_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id,
								'title': title, 'premiered': premiered, 'current_time': self.current_time, 'icon': poster}))],
					['favorites_manager', ('[B]Favorites Manager[/B]', plugin_cmd % build_url({'mode': 'favorites_manager_choice', 'media_type': 'movie',
								'tmdb_id': tmdb_id, 'title': title}))]])
			if playcount: cm_append(['mark_watched', ('[B]Mark Unwatched[/B]', plugin_cmd % build_url({'mode': 'watched_status.mark_movie', 'action': 'mark_as_unwatched',
									'tmdb_id': tmdb_id, 'title': title}))])
			else:
				unaired = not premiered or self.current_date_string < premiered
				if not unaired:cm_append(['mark_watched', ('[B]Mark Watched[/B]', plugin_cmd % build_url({'mode': 'watched_status.mark_movie', 'action': 'mark_as_watched',
											'tmdb_id': tmdb_id, 'title': title}))])
			if progress: cm_append(['mark_watched', ('[B]Clear Progress[/B]', plugin_cmd % build_url({'mode': 'watched_status.erase_bookmark', 'media_type': 'movie',
								'tmdb_id': tmdb_id, 'refresh': 'true'}))])
			if not self.is_external: cm_append(['exit', ('[B]Exit Movie List[/B]', plugin_cmd % build_url({'mode': 'navigator.exit_media_menu'}))])
			else: cm_extend([['refresh', ('[B]Refresh Widgets[/B]', plugin_cmd % build_url({'mode': 'refresh_widgets'}))],
					['reload', ('[B]Reload Widgets[/B]', plugin_cmd % build_url({'mode': 'kodi_refresh'}))]])
			cm = self.process_context_menu(cm)
			listitem = self.make_listitem()
			info_tag = listitem.getVideoInfoTag()
			info_tag.setMediaType('movie')
			info_tag.setTitle(title)
			info_tag.setOriginalTitle(meta_get('original_title'))
			info_tag.setGenres(meta_get('genre'))
			duration = meta_get('duration')
			info_tag.setDuration(duration)
			info_tag.setPlaycount(playcount)
			info_tag.setPlot(meta_get('plot'))
			info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': str_tmdb_id})
			info_tag.setIMDBNumber(imdb_id)
			info_tag.setPremiered(premiered)
			info_tag.setYear(year)
			info_tag.setRating(meta_get('rating'))
			info_tag.setVotes(meta_get('votes'))
			info_tag.setMpaa(meta_get('mpaa'))
			info_tag.setCountries(meta_get('country'))
			info_tag.setTrailer(meta_get('auto_trailer') or self.trailer_url % (tmdb_id, imdb_id))
			info_tag.setTagLine(meta_get('tagline'))
			info_tag.setStudios(meta_get('studio'))
			info_tag.setWriters(meta_get('writer'))
			info_tag.setDirectors(meta_get('director'))
			cast = meta_get('short_cast') or meta_get('cast') or []
			kodi_actor = self.kodi_actor
			info_tag.setCast([kodi_actor(item.get('name') or '', role=item.get('role') or '', thumbnail=item.get('thumbnail') or '') for item in cast])
			set_properties = listitem.setProperties
			if progress:
				info_tag.setResumePoint(watched_status.get_resume_seconds(progress, duration))
				set_properties({'WatchedProgress': progress})
			listitem.setLabel(title)
			listitem.addContextMenuItems(cm)
			listitem.setArt({'poster': poster, 'fanart': fanart, 'icon': poster, 'clearlogo': clearlogo, 'landscape': landscape, 'thumb': poster or landscape or fanart})
			set_properties({'belongs_to_collection': belongs_to_movieset})
			self.append(((url, listitem, False), _position))
		except: logger(f'build_movie_content _id: {_id} meta: {meta}\nError: {format_exc()}')#pass

	def worker(self):
		self.kodi_actor, self.make_listitem, self.build_url = kodi_utils.kodi_actor(), kodi_utils.make_listitem, kodi_utils.build_url
		self.poster_empty, self.fanart_empty = kodi_utils.get_icon('box_office'), kodi_utils.addon_fanart()
		self.current_date, self.current_date_string, self.current_time = get_datetime(), get_datetime(string=True), get_current_timestamp()
		context_menu_enabled = settings.context_menu_enabled()
		context_menu_order = [i for i in settings.context_menu_order() if i in context_menu_enabled]
		self.cm_ordered_items = context_menu_order if context_menu_order != context_menu_defaults().split(',') else None
		rpdb_info = settings.rpdb_info('movie')
		self.rpdb_api_key, self.rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
		self.watched_info, self.bookmarks = watched_status.watched_info_movie(), watched_status.get_bookmarks_movie()
		self.window_command = 'ActivateWindow(Videos,%s,return)' if self.is_external else 'Container.Update(%s)'
		open_action = settings.media_open_action('movie')
		self.open_movieset = open_action in (2, 3) and not self.movieset_list_active
		self.open_extras = open_action in (1, 3)
		if self.custom_order:
			pool = TaskPool(max_threads=8)
			pool.tasks(self.build_movie_content, self.list, 'metacache_db')
		else:
			pool = TaskPool(max_threads=8)
			pool.tasks_enumerate(self.build_movie_content, self.list, 'metacache_db')
			self.items.sort(key=lambda k: k[1])
			self.items = [i[0] for i in self.items]
		return self.items

	def fetch_tmdb_main(self, page_no):
		from apis import tmdb_api
		data = getattr(tmdb_api, self.action)(page_no)
		self.list = [i['id'] for i in data.get('results', [])]
		if data.get('total_pages', 0) > page_no: self.new_page = {'new_page': str(page_no + 1)}

	def fetch_tmdb_special(self, page_no):
		from apis import tmdb_api
		function = getattr(tmdb_api, self.action)
		if self.action == 'tmdb_movies_discover':
			url = self.params_get('url')
			data = function(url, page_no)
			page_meta = {'url': url}
		else:
			key_id = self.params_get('key_id') or self.params_get('query')
			if not key_id: return
			data = function(key_id, page_no)
			page_meta = {'key_id': key_id}
		self.list = [i['id'] for i in data.get('results', [])]
		if data.get('total_pages', 0) > page_no: self.new_page = dict(page_meta, **{'new_page': str(page_no + 1)})

	def fetch_imdb_main(self, page_no):
		from apis import imdb_api
		self.id_type = 'imdb_id'
		current_cursor = self.params_get('end_cursor', None)
		data = getattr(imdb_api, self.action)(current_cursor)
		self.list = [i['media_id'] for i in data.get('results', [])]
		if data.get('has_next_page'): self.new_page = {'new_page': str(page_no + 1), 'end_cursor': data['end_cursor']}

	def fetch_imdb_special(self, page_no):
		key_id = self.params_get('key_id') or self.params_get('query')
		if not key_id: return
		from apis import imdb_api
		self.id_type = 'imdb_id'
		current_cursor = self.params_get('end_cursor', None)
		function = getattr(imdb_api, self.action)
		data = function(key_id, current_cursor)
		self.list = [i['media_id'] for i in data.get('results', [])]
		if data['has_next_page']: self.new_page = {'key_id': key_id, 'end_cursor': data['end_cursor'], 'new_page': str(page_no + 1)}

	def fetch_personal(self, page_no):
		funcs = {'in_progress_movies': ('modules.watched_status', 'get_in_progress_movies'), 'watched_movies': ('modules.watched_status', 'get_watched_items'),
				'favorites_movies': ('caches.favorites_cache', 'get_favorites')}
		function = manual_function_import(*funcs[self.action])
		data = function('movie', page_no)
		data, total_pages = self.paginate_list(data, page_no)
		self.list = [i['media_id'] for i in data]
		if total_pages > 2: self.total_pages = total_pages
		if total_pages > page_no: self.new_page = {'new_page': str(page_no + 1), 'paginate_start': self.paginate_start}

	def fetch_movie_set(self, page_no):
		from modules.metadata import movieset_meta
		self.movieset_list_active = True
		data = sorted(movieset_meta(self.params_get('key_id'), self.tmdb_api_key)['parts'], key=lambda k: k['release_date'] or '2050')
		self.list = [i['id'] for i in data]

	def fetch_trakt_movies_related(self, page_no):
		from apis.trakt_api import trakt_movies_related
		self.id_type = 'multi_dict'
		key_id = self.params_get('key_id')
		if not key_id.startswith('tt'): key_id = movie_meta('tmdb_id', key_id, self.tmdb_api_key, get_datetime())['imdb_id']
		data = trakt_movies_related(key_id)
		self.list = [i['ids'] for i in data]

	def process_context_menu(self, context_menu_items):
		if not self.cm_ordered_items: return [i[1] for i in context_menu_items]
		return [i for x in self.cm_ordered_items for n, i in context_menu_items if x == n]

	def paginate_list(self, data, page_no):
		if settings.paginate(self.is_external):
			limit = settings.page_limit(self.is_external)
			data, total_pages = paginate_list(data, page_no, limit, self.paginate_start)
			if self.is_external: self.paginate_start = limit
		else: total_pages = 1
		return data, total_pages
