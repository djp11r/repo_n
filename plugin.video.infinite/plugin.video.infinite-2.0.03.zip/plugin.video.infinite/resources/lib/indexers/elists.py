# -*- coding: utf-8 -*-

import json
import re
from traceback import print_exc
from urllib.parse import urlencode, urlparse, quote_plus, parse_qs, quote

import requests

from modules.kodi_utils import make_session, set_resolvedurl, logger, kodi_player, build_url, select_dialog, make_listitem, set_info,  notification, add_items, set_content, end_directory, set_view_mode, get_infolabel, set_category, external, get_list_item, nextpage
from modules.settings import get_git_url
from modules.utils import normalize
from modules.source_utils import request, agent, get_page_server, get_link, convert_youtube_duration_to_minutes
from caches.main_cache import main_cache, cache_object
from caches.settings_cache import get_setting
from modules.dom_parser import parseDOM

ddurl = get_setting('infinite.live_url', '')
chnnel_filter = get_setting('infinite.live_channels', 'DAZN, Movistar').split(', ')
tvappurl = 'https://thetvapp.to'
header = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7', 'Accept-Encoding': 'gzip, deflate', 'Accept-Language': 'en,en-US;q=0.9', 'Cache-Control': 'no-cache', 'Pragma': 'no-cache', 'Sec-Ch-Ua': '"Not(A:Brand";v="24", "Chromium";v="122"', 'Sec-Ch-Ua-Mobile': '?0', 'Sec-Ch-Ua-Platform': "Windows", 'Sec-Fetch-Dest': 'document', 'Sec-Fetch-Mode': 'navigate', 'Sec-Fetch-Site': 'same-site', 'Sec-Fetch-User': '?1', 'Upgrade-Insecure-Requests': '1', 'DNT': '1', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'}
UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36'
play_yt_url = 'plugin://plugin.video.youtube/play/?video_id'


def get_c_list(params):
    ch_name = params['list_name']
    cache_name = f'content_{ch_name}{urlencode(params)}'
    list_data = main_cache.get(cache_name)
    if not list_data:
        git_url = get_git_url()
        if ch_name == 'youtube': data = request(f'{git_url}/youtub_live.json')
        elif ch_name == 'pluto': data = request(f'{git_url}/pluto.json')
        elif ch_name == 'indianlive': data = request(f'{git_url}/indian_live.json')
        elif ch_name == 'daddy': list_data = ch_dl()
        elif ch_name == 'theapp': list_data = ch_tvapp()
        elif ch_name == 'ddevent': list_data = sched_date()
        if ch_name in ('youtube', 'pluto', 'indianlive'): list_data = eval(str(data)) # loads(data)
        if list_data and ch_name != 'ddevent': main_cache.set(cache_name, list_data, expiration=168) # 7days
        else: main_cache.set(cache_name, list_data, expiration=4) # 6 hrs
    # logger(f'from cache list_data: {list_data}')
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_external = external()
    if list_data:
        add_items(handle, list(get_list_item(list_data, ch_name)))
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.episodes', 'episodes', is_external)
    else:
        notification(f'No links Found for: :{ch_name} Retry')
        end_directory(handle)
        return


def play(params):
    # logger(f'play params {params}')
    url = params['url']
    try:
        direct_player = False
        if params['provider'] in ('daddy', 'ddevent'): ourl = relv_daddy(url)
        elif params['provider'] == 'theapp': ourl = relv_theapp(url)
        elif params['provider'] == 'youtube':
            items = get_m3u8_url(url)
            list_items = [{'line1': i['title']} for i in items]
            kwargs = {'items': json.dumps(list_items), 'narrow_window': 'false'}
            choice = select_dialog(items, **kwargs)
            if choice == None: return
            ourl = choice['url']
        elif params['provider'] == 'pluto' and 'm3u8' in url: ourl = f'{url}|User-Agent={agent()}&Referer={url}'
        elif params['provider'] == 'crick_live': ourl = url
        else: ourl = f'{url}|User-Agent={agent()}'
        if ourl is None:
            logger(f'--- Playing url: {ourl} \nparams: {params}')
            return notification(f'No links Found for: :{params["title"]} Retry')
        kodi_player(ourl, params['title'], direct_player)
    except:
        logger(f'play provider: {params} - Exception: {print_exc()}')
        return


def splitter(item):
    split = item[0].split('","')
    return (split[0], item[1])

def get_videolist(url):
    if 'https://www.youtube.com/channel' in url: response = request(url)
    else: response = request(f'{url}/videos')
    # logger(response)
    vars_ = re.compile(r'var ytInitialData =.*?[\'|"|{](.+)[\'|"|}][,;]</script>').findall(response)
    # logger(f'>>> : {vars_[0]} \nvars_>>> : {type(vars_)} vars_: {vars_}')

    tab_items = re.findall(r'''(?:videoId|file)['"]*:\s*(?:"|')(.+?)(?:"|')\s*?label\s*["']?\s*[:=]\s*["'](.+?)(?:"|')''', str(vars_[0]), re.I | re.M)

    new_tabitem = tuple(splitter(item) for item in tab_items)
    choices = []
    for item in new_tabitem:
        # logger(f'tab_items>>> : {repr(item)}')
        furl = f'{play_yt_url}={item[0]}'
        if furl not in str(choices): choices.append({'title': f'{item[1]}', 'mode': 'geetm_plvid', 'url': furl})
        # logger(f'tab_items>>> : {item[0]}\n      {item[1]}')
    logger(f'Total videoId: {len(new_tabitem)} get link from total choices: {len(choices)}')
    return choices


def get_m3u8_url(url):
    # logger(f'get_m3u8_url url: {url}')
    # videolist = get_videolist(url)
    videolist = cache_object(get_videolist, url, [url], False, 4)

    return videolist


def extract_m3u8(response, m3u8_extension='.m3u8', https_prefix='https://', tuner_increment=5, initial_tuner=200):
    end = response.find(m3u8_extension)
    if end == -1: raise ValueError('No .m3u8 found in the response')
    end += len(m3u8_extension)
    tuner = initial_tuner
    # logger(f'extract_m3u8 tuner: {tuner} end: {end}')

    while True:
        # logger(f'extract_m3u8 response[{end - tuner}: {end}]')
        potential_link = response[end - tuner: end]
        if https_prefix in potential_link:
            link = potential_link
            start = link.find(https_prefix)
            end = link.find(m3u8_extension) + len(m3u8_extension)
            break
        else: tuner += tuner_increment
    logger(f'extract_m3u8 length of links: {len(link[start: end])}')
    # logger(f'extract_m3u8  type: {type(link)} length of links: {len(link[start: end])}  : repr {repr(link)} : {link[start: end]}')
    return link[start: end]


def ch_dl():
    url = f'{ddurl}/24-7-channels.php'
    do_adult = False  #xbmcaddon.Addon().getSetting('adult_pw')
    hea = {'Referer': f'{ddurl}/', 'User-Agent': UA}
    resp = request(url, headers=hea)
    # logger(f'resp: {resp}')
    ch_block = re.compile(r'<center><h1(.+?)tab-2', re.M | re.DOTALL).findall(str(resp))
    chan_data = re.compile(r'href=\"(.*)\" target(.*)<strong>(.*)</strong>').findall(str(ch_block[0]))
    # logger(f'chan_data: {chan_data}')
    ch_list = []
    for item in chan_data:
        try:
            url, title = str(item[0]), str(item[2])
            if any(x in title for x in chnnel_filter): continue
            # logger(f'item: {repr(item)}')
            url_params = {'title': title, 'url': url}
            if "18+" not in title: ch_list.append(url_params)
            if do_adult and "18+" in title: ch_list.append(url_params)
        except: logger(f'item: {repr(item)} error: {print_exc()}')
    # logger(f'ch_list: {ch_list}')
    return ch_list


def relv_daddy1(link):
    strmid = link.split('stream-')[1].replace('.php', '') or link.split('id=ch')[1] or link.split('id=')[1]# re.findall(r'.*?(\d+)\.php', link)[0]
    # UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
    if not link.startswith('http'): url = f'{ddurl}{link}'
    else: url = link
    urlb = None
    hea = {'Referer': f'{ddurl}/', 'User-Agent': UA}
    logger(f'url: {url}')
    resp = request(url, headers=hea, verify=False)
    if not resp: logger(f'Error str(resp): {str(resp)}')
    urla = parseDOM(resp, 'iframe', ret='src', attrs={'id': 'thatframe'})
    # urla = re.compile(r'''iframe\s+src="([^"]+)"''').findall(resp)[0]
    # m_iframe = re.search(r'''iframe\s+src="([^"]+)"''', str(resp), re.DOTALL)
    if urla is None:
        url = url.replace('/stream/', '/cast/')
        resp = request(url, headers=hea, verify=False)
        urla = parseDOM(resp, 'iframe', ret='src', attrs={'id': 'thatframe'})
    if not urla: return logger(f'Error str(resp): {str(resp)}')
    urla = urla[0]
    hea = {'Referer': url, 'User-Agent': UA, }
    if not urla.startswith('//'): urla = f'https:{urla}'
    logger(f'urla: {urla}')
    resp = request(urla, headers=hea, verify=False, timeout=10) # resp = session.get(urla, headers=hea, timeout=10).text
    ref = '{uri.scheme}://{uri.netloc}'.format(uri=urlparse(urla))
    ref = quote_plus(ref)
    channelKey = re.findall(r'''var channelKey\s*=\s*["'](.+?)['"]''', str(resp), re.DOTALL)
    server_info = re.findall(r'''var m3u8Url\s*=(.+?);''', str(resp), re.DOTALL)
    pattern = r'var\s+(\w+)\s*=\s*"([^"]+)"'
    matches = re.findall(pattern, str(resp))
    if matches:
        variables = dict(matches)
        channel_key = variables['channelKey']
        auth_ts = variables['authTs']
        auth_rnd = variables['authRnd']
        auth_sig = quote_plus(variables['authSig'])
    else: logger(f'Error str(resp): {str(resp)}')
    url_b = re.findall(r'''source\s*:\s*["']?(.+?)['"]?\,''', str(resp), re.DOTALL)
    logger(f'url_b: {url_b} matches: {repr(matches)}\nurl_b: {repr(url_b)}')
    if re.search(r'm3u8Url|m3u8', str(url_b)):
        # if url_b == "m3u8Url" or url_b == "m3u8":
        try:
            auth_host = re.findall(r'''(https?:\/\/[^\s]+/auth\.php\?channel_id=)''', str(resp), re.DOTALL)
            logger(f'auth_host: {auth_host}')
            if auth_host: auth_host = auth_host[0]
            else: auth_host = 'https://top2new.newkso.ru/auth.php?channel_id='
            try:
                authTs = re.findall(r'''var authTs\s*=\s*["'](.+?)['"]''', str(resp), re.DOTALL)[0]
                authRnd = re.findall(r'''var authRnd\s*=\s*["'](.+?)['"]''', str(resp), re.DOTALL)[0]
                authSig = re.findall(r'''var authSig\s*=\s*["'](.+?)['"]''', str(resp), re.DOTALL)[0]
                auth_url = auth_host + channelKey[0] + '&ts=' + authTs + '&rnd=' + authRnd + '&sig=' + quote(authSig)
            except:
                auth_a = re.findall(r'''var\s*__a\s*=\s*atob\(["'](.+?)['"]''', str(resp), re.DOTALL)[0]
                try: auth_a = b64decode(auth_a).decode('utf-8')
                except: pass
                auth_b = re.findall(r'''var\s*__b\s*=\s*atob\(["'](.+?)['"]''', str(resp), re.DOTALL)[0]
                try: auth_b = b64decode(auth_b).decode('utf-8')
                except: pass
                auth_c = re.findall(r'''var\s*__c\s*=\s*atob\(["'](.+?)['"]''', str(resp), re.DOTALL)[0]
                try: auth_c = b64decode(auth_c).decode('utf-8')
                except: pass
                auth_d = re.findall(r'''var\s*__d\s*=\s*atob\(["'](.+?)['"]''', str(resp), re.DOTALL)[0]
                try: auth_d = b64decode(auth_d).decode('utf-8')
                except: pass
                auth_e = re.findall(r'''var\s*__e\s*=\s*atob\(["'](.+?)['"]''', str(resp), re.DOTALL)[0]
                try: auth_e = b64decode(auth_e).decode('utf-8')
                except: pass
                auth_url = auth_a + auth_b + '?channel_id=' + quote(channelKey) + '&ts=' + quote(auth_c) + '&rnd=' + quote(auth_d) + '&sig=' + quote(auth_e)
            auth_hdr = {'Referer': ref+"/", 'Origin': ref, 'User-Agent':UA, 'Connection':'keep-alive',}
            auth_resp = request(auth_url, headers=auth_hdr, verify=False, timeout=10) # session.get(auth_url, headers=auth_hdr, verify=False, timeout=10).content.decode('utf-8')
            logger(f'auth_resp: {auth_resp}')
        except: logger(f'resp: {resp}\n error: {print_exc()}')
        if not server_info and "wikisport" in resp:  # 04-02-25
            try:
                iframe_src = re.findall(r'iframe src="(.+?)"', resp)[0]
                resp = request(iframe_src, headers=hea, verify=False, timeout=10) # r = session.get(iframe_src).text
                iframe_src = re.findall(r'iframe src="(.+?)"', resp)[0]
                resp = request(iframe_src, headers=hea, verify=False, timeout=10) # resp = session.get(iframe_src).text
            except: pass
            # channelKey = re.findall(r'var channelKey.+?\"(.+?)\"', resp, re.DOTALL)
            # server_info = re.findall(r'var m3u8Url\s*=(.+?);', r, re.DOTALL)
            ref = '{uri.scheme}://{uri.netloc}'.format(uri=urlparse(iframe_src))
            logger(f'2channelKey: {repr(channelKey)} server_info: {repr(server_info)}')
        if channelKey: channelid = channelKey[0]
        else: logger(f'play provider urla: {urla}\nresp2: {resp}'); return
        if channelid.startswith('bet'):
            if strmid.isdigit(): channelid = f'mono{strmid}'
            else: channelid = strmid

        server_lookup = f'{ref}/server_lookup.php?channel_id={channelid}'
        hea2 = {'Referer': urla, 'user-agent': UA, }
        # logger(f'server_lookup: {server_lookup}')
        server_resp = request(server_lookup, headers=hea2, verify=False, output='json') #server_resp = session.get(server_lookup, headers=hea2, verify=False).content.decode('utf-8')
        try:
            serverKey = server_resp.get("server_key")
            try:
                url_b = url_b[0]
                server = 'newkso.ru'
                fname = channelid
                if url_b == "m3u8Url":
                    server = re.findall(r'''serverKey\s*\+\s*["'](.+?)['"]\s*\+\s*serverKey''', str(resp), re.DOTALL)[0]
                    fname = re.findall(r'''channelKey\s*\+\s*["'](.+?)['"]''', str(resp), re.DOTALL)[-1]
                elif url_b == "m3u8":
                    server = re.findall(r'''sk\s*\+\s*["'](.+?)['"]\s*\+\s*sk''', str(resp), re.DOTALL)[0]
                    fname = re.findall(r'''channelKey\s*\+\s*["'](.+?)['"]''', str(resp), re.DOTALL)[-1]
                urlb = f'https://{serverKey}{server}{serverKey}/{channelid}{fname}'
            except:
                urlb = f'https://top1.newkso.ru/top1/cdn/{channelid}/mono.m3u8'
                # js_variables = ''
                # try:
                    # js_variables += '{}'.format(re.findall(r'''(var authTs\s*=\s*["'].+?['"];)''', str(resp), re.DOTALL)[0])
                    # js_variables += '{}'.format(re.findall(r'''(var authRnd\s*=\s*["'].+?['"];)''', str(resp), re.DOTALL)[0])
                    # js_variables += '{}'.format(re.findall(r'''(var authSig\s*=\s*["'].+?['"];)''', str(resp), re.DOTALL)[0])
                # except:
                    # pass
                # js_variables += 'var sk = "{}";'.format(serverKey)
                # js_variables += '{}'.format(re.findall(r'''(var channelKey\s*=\s*["'].+?['"];)''', str(resp), re.DOTALL)[0])
                # js_variables += '{}'.format(re.findall(r'''(var m3u8\s.+?;)''', str(resp), re.DOTALL)[0])
                # import js2py
                # js = js2py.EvalJs()
                # js.execute(js_variables)
                # urlb = js.m3u8
        except: logger(f'server_lookup: {server_lookup}\nserver_resp: {server_resp}')
    elif 'src' in url_b:
        urlb = re.findall(r'''src=\s*["'](.+?)['"]''', resp, re.DOTALL)[0]
    elif 'playbackURL' in url_b:
        from base64 import b64decode
        char_codes = json.loads(re.findall(r'''=\s*(\[\s*\[.+?\]\s*\])''', resp, re.DOTALL)[-1])
        char_codes.sort(key=lambda a: a[0])
        f1, f2 = re.findall(r'''return\s*(\d+);''', resp, re.DOTALL)
        k = int(f1) + int(f2)
        playbackURL = ''
        for e in char_codes:
            v = e[1]
            playbackURL += chr(int(re.sub(r'\D', '', b64decode(v).decode('utf-8'))) - k)
        urlb = playbackURL

    # urlb = get_link(resp)
    if not urlb: return logger(f'Error str(resp): {str(resp)}')
    return f'{urlb}|Referer={ref}/&Origin={ref}&Keep-Alive=true&User-Agent={quote_plus(UA)}'


def relv_daddy(link):
    # logger(f'link: {link}')
    if not link.startswith('http'): url = f'{ddurl}{link}'
    else: url = link
    if '/stream-' in url:
        ch_id = url.split('stream-')[1].replace('.php','')
        ch_id_digit_length = len(ch_id)
        if ch_id_digit_length==4:
            ch_id=ch_id[-2:] #last 2 chars of ch_id
            ch_id=str(int(ch_id)) #remove leading zero of ch_id
            url = 'https://wikisport.best/court/wik{}.php'.format(ch_id)
    elif 'bet.php?id=' in url:
        ch_id = url.split('bet.php?id=')[1]
    ref = ddurl
    # logger(f'ref: {ref}')
    with requests.session() as session:
        try:
            hea={'Referer':f'{ref}/24-7-channels.php', 'user-agent':UA,}
            session.headers.update(hea)
            resp=session.get(url, verify=False).content.decode('utf-8')
            if not resp: logger(f'resp1: {repr(resp)}')
            # url_a=re.compile(r'iframe src="(.*)" width').findall(resp)[0]
            if 's2watch.link' in url:
                ch_id = url.split('id=ch')[1]
                url_a = re.findall(r'''iframe.src\s*=\s*[`"'](.+?)['"`]''', str(resp), re.DOTALL)[0].replace('${query}', ch_id)
                # logger(f'url_a: {repr(url_a)}')
            elif 'https://antenaplanet.store/' in url:
                try:
                    ch_id = url.split('https://antenaplanet.store/')[1].replace('.php','')
                except:
                    pass
                url_a = parseDOM(resp, 'iframe', ret='src')[0]
                if url_a.startswith('//'):
                    url_a = 'https:'+url_a
                # logger(f'url_a: {repr(url_a)}')
            else:
                try:
                    url_a = parseDOM(resp, 'iframe', ret='src', attrs={'id': 'thatframe'})[0]
                except:
                    try:
                        url_a = parseDOM(resp, 'iframe', ret='src', attrs={'class': r'video\s*responsive'})[0]
                    except:
                        try:
                            url_a = re.findall(r'''iframe.src\s*=\s*[`"'](.+?)['"`]''', str(resp), re.DOTALL)[0].replace('${query}', ch_id)
                        except:
                            url_a = parseDOM(resp, 'iframe', ret='src')[0]
            logger(f'url_a: {repr(url_a)}')
            parsed_url_a = urlparse(url_a)
            logger(f'parsed_url_a: {repr(parsed_url_a)}')
            url_a_path = parsed_url_a.path
            if url_a_path.startswith('//stream/') or url_a_path.startswith('/stream/'):
                url_a = url_a.replace(parsed_url_a.netloc, 'www.vidembed.re')
                url_a = url_a.split('#')[0]
                parsed_url_a = urlparse(url_a)
                url_b = url_a.replace('//stream/', '/api/source/').replace('/stream/', '/api/source/')
                url_b += '?type=live'
                payload = {
                                "r": ref,
                                "d": parsed_url_a.netloc
                            }
                ref = '{uri.scheme}://{uri.netloc}/'.format(uri=urlparse(url_b))
                hdr = {
                                'Connection':'keep-alive',
                                'Origin': ref[:-1],
                                'Referer': url_a,
                                'User-Agent':UA,
                            }
                session.headers.update(hdr)
                resp = session.post(url_b, json=payload, timeout=20).content
                try:
                    url_b = json.loads(resp)["player"]["source_file"]
                    stream_ok = session.get(url_b, verify=False).ok
                    return f'{url_b}|Referer={ref}/&Origin={ref}&Keep-Alive=true&User-Agent={quote_plus(UA)}'
                except:
                    logger(f'Error: {repr(print_exc())}\nresp2: {repr(resp)} ')

            hea={
                'Referer':url,
                'user-agent':UA,
            }
            session.headers.update(hea)
            # url_a = url_a.replace(urlparse(url_a).netloc, 'pkpakiplay.xyz')
            resp=session.get(url_a, verify=False).content.decode('utf-8')
            if not resp: logger(f'resp3: {repr(resp)}')
            ref = '{uri.scheme}://{uri.netloc}/'.format(uri=urlparse(url_a))
            if 'new Clappr' in resp:
                url_b = re.findall(r'''source\s*:\s*["']?(.+?)['"]?\,''', str(resp), re.DOTALL)[0]
                logger(f'url_b: {repr(url_b)}')
                if url_b == "m3u8Url"or url_b == "m3u8":
                    logger(f'url_b: {repr(url_b)}')
                    channelKey = re.findall(r'''channelKey\s*=\s*["'](.+?)['"]''', str(resp), re.DOTALL)[0]
                    try:
                        auth_host = re.findall(r'''(https?:\/\/[^\s]+/auth\.php\?channel_id=)''', str(resp), re.DOTALL)
                        if auth_host:
                            auth_host = auth_host[0]
                        else:
                            auth_host = 'https://top2new.newkso.ru/auth.php?channel_id='
                        logger(f'auth_host: {repr(auth_host)}')
                        try:
                            authTs = re.findall(r'''var authTs\s*=\s*["'](.+?)['"]''', str(resp), re.DOTALL)[0]
                            authRnd = re.findall(r'''var authRnd\s*=\s*["'](.+?)['"]''', str(resp), re.DOTALL)[0]
                            authSig = re.findall(r'''var authSig\s*=\s*["'](.+?)['"]''', str(resp), re.DOTALL)[0]
                            auth_url = auth_host + channelKey[0] + '&ts=' + authTs + '&rnd=' + authRnd + '&sig=' + quote(authSig)
                        except:
                            auth_a = re.findall(r'''var\s*__a\s*=\s*atob\(["'](.+?)['"]''', str(resp), re.DOTALL)[0]
                            try: auth_a = b64decode(auth_a).decode('utf-8')
                            except: pass
                            auth_b = re.findall(r'''var\s*__b\s*=\s*atob\(["'](.+?)['"]''', str(resp), re.DOTALL)[0]
                            try: auth_b = b64decode(auth_b).decode('utf-8')
                            except: pass
                            auth_c = re.findall(r'''var\s*__c\s*=\s*atob\(["'](.+?)['"]''', str(resp), re.DOTALL)[0]
                            try: auth_c = b64decode(auth_c).decode('utf-8')
                            except: pass
                            auth_d = re.findall(r'''var\s*__d\s*=\s*atob\(["'](.+?)['"]''', str(resp), re.DOTALL)[0]
                            try: auth_d = b64decode(auth_d).decode('utf-8')
                            except: pass
                            auth_e = re.findall(r'''var\s*__e\s*=\s*atob\(["'](.+?)['"]''', str(resp), re.DOTALL)[0]
                            try: auth_e = b64decode(auth_e).decode('utf-8')
                            except: pass
                            auth_url = auth_a + auth_b + '?channel_id=' + quote(channelKey) + '&ts=' + quote(auth_c) + '&rnd=' + quote(auth_d) + '&sig=' + quote(auth_e)
                        auth_hdr = {
                                        'Referer': ref,
                                        'Origin': ref[:-1],
                                        'User-Agent':UA,
                                        'Connection':'keep-alive',
                                    }
                        auth_resp = session.get(auth_url, headers=auth_hdr, verify=False, timeout=10).content.decode('utf-8')
                        logger(f'auth_resp: {repr(auth_resp)}')
                    except: logger(f'resp: {resp}\n error: {print_exc()}')
                    if channelKey.startswith('bet'):
                        if ch_id.isdigit():
                            channelKey = 'mono{}'.format(ch_id)
                        else:
                            channelKey = ch_id
                    server_lookup = "{}server_lookup.php?channel_id={}".format(ref,quote(channelKey))
                    hea2 = {
                                'Referer':url_a,
                                'user-agent':UA,
                            }
                    session.headers.update(hea2)
                    server_resp = session.get(server_lookup, verify=False).content.decode('utf-8')
                    if not resp: logger(f'resp4: {repr(server_resp)}')
                    serverKey = json.loads(server_resp).get("server_key")
                    if url_b == "m3u8Url":
                        server = re.findall(r'''serverKey\s*\+\s*["'](.+?)['"]\s*\+\s*serverKey''', str(resp), re.DOTALL)[0]
                        fname = re.findall(r'''channelKey\s*\+\s*["'](.+?)['"]''', str(resp), re.DOTALL)[-1]
                        url_b = "https://{}{}{}/{}{}".format(serverKey,server,serverKey,channelKey,fname)
                    elif url_b == "m3u8":
                        server = re.findall(r'''sk\s*\+\s*["'](.+?)['"]\s*\+\s*sk''', str(resp), re.DOTALL)[0]
                        fname = re.findall(r'''channelKey\s*\+\s*["'](.+?)['"]''', str(resp), re.DOTALL)[-1]
                        url_b = "https://top1.newkso.ru/top1/cdn/{}/mono.m3u8".format(channelKey) if serverKey == "top1/cdn" else "https://{}{}{}/{}{}".format(serverKey,server,serverKey,channelKey,fname)
                        # url_b = "https://top1.newkso.ru/top1/cdn/" + channelKey + "/mono.m3u8" if serverKey == "top1/cdn" else "https://" + serverKey + "new.newkso.ru/" + serverKey + "/" + channelKey + "/mono.m3u8"
                        # js_variables = ''
                        # try:
                            # js_variables += '{}'.format(re.findall(r'''(var authTs\s*=\s*["'].+?['"];)''', str(resp), re.DOTALL)[0])
                            # js_variables += '{}'.format(re.findall(r'''(var authRnd\s*=\s*["'].+?['"];)''', str(resp), re.DOTALL)[0])
                            # js_variables += '{}'.format(re.findall(r'''(var authSig\s*=\s*["'].+?['"];)''', str(resp), re.DOTALL)[0])
                        # except:
                            # pass
                        # js_variables += 'var sk = "{}";'.format(serverKey)
                        # js_variables += '{}'.format(re.findall(r'''(channelKey\s*=\s*["'].+?['"];)''', str(resp), re.DOTALL)[0])
                        # js_variables += '{}'.format(re.findall(r'''(var m3u8\s.+?;)''', str(resp), re.DOTALL)[0])
                        # import js2py
                        # js = js2py.EvalJs()
                        # js.execute(js_variables)
                        # url_b = js.m3u8
                        # logger(f'url_b: {repr(url_b)}')
                elif url_b == "src":
                    url_b = re.findall(r'''src=\s*["'](.+?)['"]''', resp, re.DOTALL)[0]
                elif url_b == "playbackURL":
                    from base64 import b64decode
                    char_codes = json.loads(re.findall(r'''=\s*(\[\s*\[.+?\]\s*\])''', resp, re.DOTALL)[-1])
                    char_codes.sort(key=lambda a: a[0])
                    f1, f2 = re.findall(r'''return\s*(\d+);''', resp, re.DOTALL)
                    k = int(f1) + int(f2)
                    playbackURL = ''
                    for e in char_codes:
                        v = e[1]
                        playbackURL += chr(int(re.sub(r'\D', '', b64decode(v).decode('utf-8'))) - k)
                    url_b = playbackURL
                logger(f'url_b: {repr(url_b)}')
            else:
                try:
                    url_b = parseDOM(resp, 'iframe', ret='src')[-1]
                    # logger(f'url_b: {repr(url_b)}')
                    parsed_url_b = urlparse(url_b)
                    url_b_path = parsed_url_b.path
                    if 'embed.html?' in url_b:
                        ref = url_b
                        url_b = url_b.replace('embed.html?', 'index.fmp4.m3u8?')
                    if url_b_path.startswith('//stream/') or url_b_path.startswith('/stream/'):
                        url_b = url_b.replace(parsed_url_b.netloc, 'www.vidembed.re')
                        url_b = url_b.split('#')[0]
                        logger(f'url_b: {repr(url_b)}')
                        parsed_url_b = urlparse(url_b)
                        ur = url_b.replace('//stream/', '/api/source/').replace('/stream/', '/api/source/')
                        ur += '?type=live'
                        payload = {
                                        "r": ref,
                                        "d": parsed_url_b.netloc
                                    }
                        ref = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_url_b)
                        hdr = {
                                        'Connection':'keep-alive',
                                        'Origin': ref[:-1],
                                        'Referer': url_b,
                                        'User-Agent':UA,
                                    }
                        session.headers.update(hdr)
                        resp = session.post(ur, json=payload, timeout=20).content
                        url_b = json.loads(resp)["player"]["source_file"]
                except:
                    logger(f'Error: {repr(print_exc())}\nresp3: {repr(resp)}')
            # if not ref.endswith('/'):
            #     ref+='/'
            stream_ok = session.get(url_b, verify=False).ok
            logger(f'url_b: {repr(url_b)} ref: {repr(ref)} stream_ok: {repr(stream_ok)}')
            return f'{url_b}|Referer={ref}&Origin={ref[:-1]}&Keep-Alive=true&User-Agent={quote_plus(UA)}'
        except:
            logger(f'Error: {repr(print_exc())}')
    return relv_daddy1(link)

def ch_tvapp():
    url = f'{tvappurl}/tv'
    hea = {'User-Agent': UA, }
    resp = request(url, headers=hea, verify=False)
    # logger(f'resp: {resp}')
    html = parseDOM(resp, 'ol', attrs={'class': "list.*?"})[0]#.replace('<span>', '').replace('</span>', '').replace('\n', '').replace('  ', '').replace('@', ' @')
    chan_data = re.findall(r'href\s*=\s*"([^"]+)"\s*class.*?>([^<]+)<\/a>', html, re.DOTALL)

    ch_list = []
    for url, title in chan_data:
        try:
            url = url[:-1] if url.endswith('/') else url
            url = url.replace('/tv/', '')
            # href = f'https://thetvapp.to{url}' if url.startswith('/') else url
            if any(x in title for x in chnnel_filter): continue
            # logger(f'item: {repr(item)}')
            url_params = {'title': title.replace('&amp;', '&'), 'url': url}
            ch_list.append(url_params)
        except: logger(f'chan_data: {repr(chan_data)} error: {print_exc()}')
    # logger(f'ch_list: {ch_list}')
    return ch_list


def relv_theapp(id_):
    stream_url = ''
    header = {'Accept': '*/*', 'Accept-Encoding': 'gzip, deflate', 'Accept-Language': 'en,en-US;q=0.9', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive','Pragma': 'no-cache', 'Sec-Fetch-Dest': 'empty', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 'sec-ch-ua': '"Not(A:Brand";v="24", "Chromium";v="122"', 'sec-ch-ua-mobile': '?0', 'sec-ch-ua-platform': "Windows",
    'Host': 'v17.thetvapp.to',
    'Origin': 'https://tvpass.org',
    'Referer': 'https://tvpass.org/', }
    response = get_page_server(f'{tvappurl}/tv/{id_}/', '#loadVideoSD', 'thetvapp')
    if not response: response = get_page_server(f'{tvappurl}/tv/{id_}/', '#loadVideoHD', 'thetvapp')
    if not response: response = get_page_server(f'{tvappurl}/tv/{id_}/', '#loadVideoBtn', 'thetvapp')
    # logger(f'response: {repr(response)}')
    if 'source' in response:
        data = eval(response)
        if data:
            link = parse_qs(data["source"])
            # logger(f'link: {link}')
            link = link['mu'][0]
            # logger(f'link: {repr(link)}')
            return f'{link}|{urlencode(header)}'
    return stream_url




def geetm_root(params):
    cache_name = 'content_geetmala'
    list_data = main_cache.get(cache_name)
    # logger(f'from cache list_data: {list_data}')
    if not list_data:
        uri = f'{get_git_url()}/geetmala.json'
        data = request(uri)
        list_data = eval(str(data))
        # list_data = json.loads(data)
        # logger(f'new list_data: {list_data}')
        if list_data: main_cache.set(cache_name, list_data, expiration=168) # 7days

    from sys import argv
    handle = int(argv[1])
    is_external = external()
    add_items(handle, list(get_list_item(list_data, 'youtube_r', True)))
    set_content(handle, 'tvshows')
    set_category(handle, 'tvshows')
    end_directory(handle, cacheToDisc=not is_external)
    set_view_mode('view.tvshows', 'tvshows', is_external)


def get_song_list(params):
    ourl = params['url']
    rescrape = params.get('rescrape', 'false')
    if ourl.endswith('value=') or ourl == 'YouTube':
        search_text = get_SearchQuery('Hindi Geetmala')
        ourl += quote_plus(search_text)

    cache_name = f'content_{urlencode(params)}'
    song_list = None
    if rescrape == 'true': main_cache.delete(cache_name)
    else: song_list = main_cache.get(cache_name)
    if not song_list:
        if ourl.startswith('YouTube'):
            song_list = Movie_search().search(search_text, [])
        else: song_list = make_song_list(params)
        if song_list:
            main_cache.set(cache_name, song_list, expiration=24)  # 1 days cache

    # logger(f'get_song_list item_list: {list(_process())}')
    from sys import argv
    handle = int(argv[1])
    is_external = external()
    if ourl.startswith('YouTube'):
        add_items(handle, list(get_list_item(song_list, 'youtube')))
        set_content(handle, 'videos')
        set_category(handle, 'videos')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.videos', 'videos', is_external)
    else:
        add_items(handle, list(get_list_item(song_list, 'youtube', True)))
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.episodes', 'episodes', is_external)


def get_SearchQuery(sitename):
    import xbmc
    keyboard = xbmc.Keyboard()
    keyboard.setHeading(f'Search {sitename}')
    keyboard.doModal()
    return keyboard.getText() if keyboard.isConfirmed() else ''


def make_song_list(params):
    url, rtitle, pg_no = params['url'], params.get('title', ''), params.get('pg_no', '1')
    base_link = 'https://www.hindigeetmala.net'
    find_data = re.compile(r'itemprop="name">(.+?)</span>')
    song_perpage = 25
    songs = []
    nextpg = True
    while len(songs) < song_perpage and nextpg:
        song_page = request(url)
        result = parseDOM(song_page, 'tr', attrs={'itemprop': 'track'})
        for item in result:
            try:
                title = parseDOM(item, 'span', attrs={'itemprop': 'name'})[0]
                vid_url = parseDOM(item, 'a', ret='href')[0]
                img = parseDOM(item, 'img', ret='src')[0]
                try:
                    album = parseDOM(item, 'span', attrs={'itemprop': 'inAlbum'})[0]
                    m_name = find_data.findall(album)[0]
                    m_year = re.findall(r'\(.+?\)', album, re.MULTILINE)
                    m_year = m_year[0].replace('(', '').replace(')', '') if m_year else ''
                    album = f'{m_name} - {m_year}'
                except: album = ''
                try:
                    artist = parseDOM(item, 'span', attrs={'itemprop': 'byArtist'})[0]
                    artist = find_data.findall(artist)[0]
                except: artist = ''
                songs.append({'title': title, 'pg_no': pg_no, 'mode': 'geetm_vid_list', 'album': album, 'plot': f'album: {album}\nArtist: {artist}', 'url': base_link + vid_url, 'poster': base_link + img, 'isfolder': True})
            except: pass
        if nextpg:
            # logger(f'get_yt_vid_links pg_no {type(pg_no)} {repr(pg_no)}')
            pg_no = int(pg_no) + 1
            if '?page=' not in url: url += f'?page={pg_no}'
            else:
                url = url.split('=')[0]
                url += f'={pg_no}'
        else: nextpg = False

    if nextpg:
        xname = re.sub(r'Next Page: \d{1,2}', '', rtitle)
        title = f'{xname} Next Page: {pg_no}'
        next_pg_dict = {'title': title, 'pg_no': str(pg_no), 'mode': 'geetm_list', 'plot': 'Go To Next Page....', 'url': url, 'poster': nextpage, 'isfolder': True}
        songs.append(next_pg_dict)
    # logger('totle from url: %s pg_no: %s song: %s \n %s' % (params['url'], pg_no, len(songs), songs))
    return songs


def get_yt_vid_links(params):
    # logger(f'get_yt_vid_links params {params}')
    title, url, album, thumb = params.get('title'), params.get('url'), params.get('album'), params.get('poster')
    vid_page = request(url)
    # logger(f'search vid_page {vid_page}')
    result = parseDOM(vid_page, 'table', attrs={'class': 'b1 w760 alcen'})
    result += parseDOM(vid_page, 'table', attrs={'class': 'b1 allef w100p'})
    choices = []
    # logger(f'result: {result}')
    choice_param = {'title': f'Song : {title}', 'mode': 'geetm_plvid', 'plot': album, 'poster': thumb, }
    try:
        link = parseDOM(result, 'iframe', ret='src')[0]
        if 'youtube.com/embed' in link:
            if v_id := link.replace('https://www.youtube.com/embed/', '').strip():
                v_link = f'{play_yt_url}={v_id}'
                choices.append(dict(choice_param, **{'url': v_link}))
    except:
        for item in result:
            if r := re.findall(r'''<lite-youtube.+?videoid="([^"]+)''', item, re.DOTALL):
                choices.append(dict(choice_param, **{'url': f'{play_yt_url}={r[0]}'}))
        song_item = parseDOM(vid_page, 'div', attrs={'class': 'yt_nt'})
        # logger(f'song_item: {song_item}')
        results = parseDOM(song_item, 'a', attrs={'class': 'yt_nt'})
        # logger(f'results: {results}')
        for item in results:
            if v_id := item.replace('https://www.youtube.com/watch?v=', '').strip():
                v_link = f'{play_yt_url}={v_id}'
                choices.append(dict(choice_param, **{'url': v_link}))

    links = parseDOM(result, 'tr')
    find_data = re.compile(r'<td>(.+?)</td>')
    found_movie = False
    for link in links:
        # logger(f'from Movie link: \n{link}\n>>>>>\n')
        td_data = find_data.findall(link)
        try:
            if 'Watch Full Movie:' in td_data[0]:
                movie_link = parseDOM(td_data[1], 'a', ret='href')
                # logger(f'movie links: {movie_link}')
                for link_item in movie_link:
                    v_id = link_item.replace('https://www.youtube.com/watch?v=', '').strip()
                    if v_link:
                        found_movie = True
                        choices.append(dict(choice_param, **{'url': f'{play_yt_url}={v_id}', 'title': f'Movie: {album}'}))
        except: pass
    if not found_movie: choices = Movie_search().search(album, choices)
    return choices


def get_yt_links(params):
    string = f'content_geetm_yt_links_{urlencode(params)}'
    choices = main_cache.get(string)
    if not choices or params.get('rescrap') == 'true':
        # logger(f'get_yt_links url: {url}\ntitle: {title}\nAlbum: {album}')
        choices = get_yt_vid_links(params)
        if choices: main_cache.set(string, choices, expiration=24) # 1 day

    # logger(f'rescrap: {rescrap} choices {choices}')
    from sys import argv
    handle = int(argv[1])
    is_external = external()
    add_items(handle, list(get_list_item(choices, 'youtube')))
    set_content(handle, 'videos')
    set_category(handle, 'videos')
    end_directory(handle, cacheToDisc=not is_external)
    set_view_mode('view.videos', 'videos', is_external)


class Movie_search:
    def __init__(self):
        self.key = 'AIzaSyCjf8izIeXa1oFZo7_HeL0WgrOq1WF_I1k'
        self.search_link = f'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=15&q=%s&key={self.key}'

    def search(self, title, choices):
        try:
            query = f'{title} full|Full movie|Movie'
            query_url = self.search_link % quote_plus(query)
            # logger(f'query: {query}')
            # query_url += '&relevanceLanguage=en'
            headers = {'Accept': 'application/json'}
            response = request(query_url, headers=headers, output='json')# response = requests.get(query_url, headers=headers).json()
            # logger(f'search json response {response}')
            if error := response.get('error', []):
                message = error.get('message', [])
                logger(f'message: {message}')
                return None

            json_items = response.get('items', [])
            # logger(f'search json_items {json_items} json_items {to_utf8(json_items)}')
            for search_result in json_items:
                try:
                    query = title.split('-')[0].lower().replace('.', '')
                    item_title = normalize(search_result['snippet']['title'].replace('.', ''))
                    if re.search(r'Full Movie|Movie', item_title, re.I) and re.search(query, item_title, re.I) and search_result['id']['kind'] == 'youtube#video':
                        vid_id = search_result['id']['videoId']
                        payload = {'id': vid_id, 'part': 'contentDetails', 'key': self.key}
                        url = f'https://www.googleapis.com/youtube/v3/videos/?&{urlencode(payload)}'
                        resp_dict = request(url, headers=headers, output='json') # resp_dict = requests.get(url, headers=headers).json()
                        # resp_dict = self.session.get('https://www.googleapis.com/youtube/v3/videos', params=payload).json()
                        dur = resp_dict['items'][0]['contentDetails']['duration']
                        duration = convert_youtube_duration_to_minutes(dur)
                        # logger(f'dur: {dur} duration: {duration}')
                        if duration > 70:
                            choices.append({'title': f'Movie: ({duration} minutes) {item_title}', 'mode': 'geetm_plvid', 'url': f'{play_yt_url}={vid_id}'})
                except: logger(f'Error: {print_exc()}')
        except: logger(f'Error: {print_exc()}')
        # logger(f'choices: {choices}')
        return choices


def schedule_json():
    hea = {'User-Agent': UA, 'referer': ddurl, }
    data = request(f'{ddurl}/schedule/schedule-generated.json', headers=hea, output='json', verify=False)
    # logger(f'data: {repr(data)}')
    data_key = list(data.keys())[0]
    extra_schedule = {'EXTRA - ': f'{ddurl}/schedule/schedule-extra-generated.php'} #, 'EXTRA2 - ': f'{ddurl}/schedule/extra2-schedule.php', 'EXTRA3 - ': f'{ddurl}/schedule/extra2-schedule-2.php'}
    for item, url in extra_schedule.items():
        try:
            data_extra = request(url, headers=hea, output='json', verify=False)
            data_extra_key = list(data_extra.keys())[0]
            if data_extra_key == data_key:
                data_extra[item + data_extra_key] = data_extra[data_extra_key]
                del data_extra[data_extra_key]
            data.update(data_extra)
        except: pass
    return data


def hour_convert(a, b):
    return (a + b) % 24


def sched_date():
    # sched_data = cache_object(schedule_json, 'episodes_sched_date', [], False, 4)
    sched_data = schedule_json()
    data = []
    for key, value in sched_data.items():
        # logger(f'key: {key}')
        date_data = value
        for ikey, ivalue in date_data.items():
            events = json.dumps(ivalue)
            ikey = ikey.replace('</span>', '')
            data.append({'title': ikey, 'isfolder': True, 'mode': 'jsonlist', 'jsonevent': events})
    return data


def dd_events_get(params):
    event_data = json.loads(params['jsonevent'])
    ###sorting workaround###
    for i, ev in enumerate(event_data):
        if int(ev.get('time').split(':')[0]) >= 4: event_data[i]["nextdate"] = "0"
        else: event_data[i]["nextdate"] = "1"
    event_data = sorted(event_data, key=lambda d: (d.get('nextdate'), d.get('time')))

    timefix = get_setting('datetime.offset', -4) # EST
    from sys import argv
    import xbmcplugin, xbmcgui
    handle = int(argv[1])
    for item in event_data:
        # logger(f'item: {item}')
        try:
            time_ = item.get('time', '00:00')
            hour = int(time_.split(':')[0])
            new_hour = hour_convert(hour, timefix)
            new_hour = str(new_hour).zfill(2) + ':' + time_.split(':')[1]
            event_ = item.get('event', ' ')
            channels_ = item.get('channels', [])
            channels_.extend(item.get('channels2', []))
            title_ = '[COLOR yellow]' + new_hour + '[/COLOR]' + ' ' + event_
            # logger(f'title_: {title_} len(channels_) :{len(channels_)} channels_: {channels_}')
            for i in channels_:
                title = title_ + ' ' + i.get('channel_name')
                # logger(f'title: {title}')
                tr = i.get("channel_id")
                if tr.isdigit(): iurl = f'/stream/stream-{tr}.php'
                else: iurl = tr if tr.startswith('/') else f'/{tr}'
                li = xbmcgui.ListItem(title)
                li.setProperty("IsPlayable", 'true')
                url_stream = build_url({'mode': 'ltp_play', 'title': title, 'provider': 'ddevent', 'url': iurl})
                isfolder = False
                xbmcplugin.addDirectoryItem(handle=handle, url=url_stream, listitem=li, isFolder=isfolder)
        except: logger(f'item: {item}\nerror: {print_exc()}'); continue
    xbmcplugin.endOfDirectory(handle)
