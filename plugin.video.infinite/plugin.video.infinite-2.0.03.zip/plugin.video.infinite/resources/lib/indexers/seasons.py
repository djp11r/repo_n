# -*- coding: utf-8 -*-
import sys
from traceback import print_exc

from modules.metadata import tvshow_meta
from modules.utils import get_datetime, adjust_premiered_date, make_thread_list
from modules.watched_status import get_database, watched_info_season, get_watched_status_season, get_progress_status_season
from modules.kodi_utils import logger, addon_fanart, empty_poster, set_info, set_category, home, add_items, set_content, end_directory, set_view_mode, make_listitem, build_url, external
from modules.settings import date_offset, watched_indicators, widget_hide_watched, show_specials, mpaa_region, tmdb_api_key

run_plugin = 'RunPlugin(%s)'

def build_season_list(params):
	def _process():
		total_aired_eps, episode_count = meta_get('total_aired_eps'), 0
		for item in season_data:
			try:
				cm = []
				cm_append, item_get = cm.append, item.get
				listitem = make_listitem()
				set_properties = listitem.setProperties
				overview, poster_path, air_date = item_get('overview'), item_get('poster_path'), item_get('air_date')
				season_number, aired_eps = item_get('season_number'), item_get('episode_count')
				season_name = item_get('name', None)
				season_special = season_number == 0
				title = item_get('name', None) or 'Season %s' % season_number
				if custom_order is not None: title = '%s - %s' % (show_title, title)
				poster = 'https://image.tmdb.org/t/p/w780%s' % poster_path if poster_path is not None else show_poster
				thumb = poster or show_landscape or show_fanart
				try: year = air_date.split('-')[0]
				except: year = show_year or '2050'
				plot = overview or show_plot
				try: premiered = adjust_premiered_date(air_date, adjust_hours)[1]
				except: premiered = ''
				unaired = aired_eps == 0
				if unaired or season_special:
					progress, playcount, total_watched, total_unwatched = 0, 0, 0, aired_eps
					if unaired: title = '[COLOR red][I]%s[/I][/COLOR]' % title
					else: title = 'Specials'
				else:
					if season_number < total_seasons:
						episode_count += aired_eps
					else: aired_eps = total_aired_eps - episode_count
					playcount, watched, unwatched = get_watched_status_season(watched_info.get(season_number, None), aired_eps)
					progress = get_progress_status_season(watched, aired_eps)
				visible_progress = 0 if progress == 100 else progress
				url_params = build_url({'mode': 'build_episode_list', 'tmdb_id': tmdb_id, 'season': season_number})
				extras_params = build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'tvshow', 'is_external': is_external})
				options_params = build_url({'mode': 'options_menu_choice', 'content': 'season', 'tmdb_id': tmdb_id, 'poster': show_poster, 'is_external': is_external})
				cm_append(('[B]Extras[/B]', run_plugin % extras_params))
				cm_append(('[B]Options[/B]', run_plugin % options_params))
				if playcount:
					if hide_watched: continue
				elif not unaired and not season_special:
						cm_append(('[B]Mark Watched %s[/B]' % watched_title, run_plugin % build_url({'mode': 'watched_status.mark_season', 'action': 'mark_as_watched',
															'title': show_title, 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season_number})))
				if progress:
					cm_append(('[B]Mark Unwatched %s[/B]' % watched_title, run_plugin % build_url({'mode': 'watched_status.mark_season', 'action': 'mark_as_unwatched',
														'title': show_title, 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season_number})))
				set_properties({'watchedepisodes': str(watched), 'unwatchedepisodes': str(unwatched)})
				set_properties({'totalepisodes': str(aired_eps), 'watchedprogress': str(visible_progress),
								'infinite.extras_params': extras_params, 'infinite.options_params': options_params})
				if is_external:
					cm_append(('[B]Refresh Widgets[/B]', run_plugin % build_url({'mode': 'refresh_widgets'})))
					cm_append(('[B]Reload Widgets[/B]', run_plugin % build_url({'mode': 'kodi_refresh'})))
				item = {'mediatype': 'season', 'trailer': trailer, 'title': title, 'size': '0', 'duration': episode_run_time, 'plot': plot, 'rating': rating, 'premiered': premiered, 'studio': studio, 'year': year,'genre': genre, 'mpaa': mpaa, 'tvshowtitle': show_title, 'imdbnumber': imdb_id, 'votes': votes, 'status': status, 'season': season_number,'playcount': playcount}
				listitem = set_info(listitem, item, {'imdb': imdb_id, 'tmdb': str_tmdb_id, 'tvdb': str_tvdb_id})
				listitem.setLabel(title)
				listitem.setArt({'poster': poster, 'season.poster': poster, 'fanart': show_fanart, 'clearlogo': show_clearlogo, 'landscape': show_landscape, 'thumb': thumb,
								'icon': show_landscape, 'tvshow.poster': poster, 'tvshow.clearlogo': show_clearlogo})
				listitem.addContextMenuItems(cm)
				yield (url_params, listitem, True)
			except: logger(f'build_season_list _process item: {item} Error: {print_exc()}')
	handle, is_external, is_home, category_name = int(sys.argv[1]), external(), home(), 'Season'
	w_indi, adjust_hours, hide_watched = watched_indicators(), date_offset(), is_home and widget_hide_watched()
	current_date = get_datetime()
	watched_title = 'Trakt' if w_indi == 1 else 'infinite'
	meta = tvshow_meta('tmdb_id', params['tmdb_id'], tmdb_api_key(), mpaa_region(), current_date)
	meta_get = meta.get
	tmdb_id, tvdb_id, imdb_id, show_title, show_year = meta_get('tmdb_id'), meta_get('tvdb_id'), meta_get('imdb_id'), meta_get('title'), meta_get('year') or '2050'
	orig_title, status, show_plot = meta_get('original_title', ''), meta_get('status'), meta_get('plot')
	str_tmdb_id, str_tvdb_id, rating, genre = str(tmdb_id), str(tvdb_id), meta_get('rating'), meta_get('genre')
	cast, mpaa, votes, trailer, studio, country = meta_get('cast', []), meta_get('mpaa'), meta_get('votes'), str(meta_get('trailer')), meta_get('studio'), meta_get('country')
	episode_run_time, season_data, total_seasons = meta_get('duration'), meta_get('season_data'), meta_get('total_seasons') or meta_get('seasons', 1)
	show_poster, show_fanart = meta_get('poster') or empty_poster, meta_get('fanart') or addon_fanart()
	show_clearlogo, show_landscape = meta_get('clearlogo') or '', meta_get('landscape') or ''
	custom_order = params.get('custom_order', None)
	if show_specials(): season_data.sort(key=lambda i: (i['season_number'] == 0, i['season_number']))
	elif custom_order is not None: season_data = [i for i in season_data if i['season_number'] == params['season']]
	else:
		season_data = [i for i in season_data if not i['season_number'] == 0]
		season_data.sort(key=lambda k: k['season_number'])
	watched_info = watched_info_season(tmdb_id, get_database(w_indi))
	list_items = list(list(_process()))
	if custom_order is not None: return (list_items[0], custom_order)
	add_items(handle, list_items)
	set_content(handle, 'seasons')
	set_category(handle, show_title)
	end_directory(handle, cacheToDisc=not is_external)
	set_view_mode('view.seasons', 'seasons', is_external)

def single_seasons(seasons_list):
	def _process(item): season_results_append(build_season_list(item))
	season_results = []
	season_results_append = season_results.append
	threads = make_thread_list(_process, seasons_list)
	[i.join() for i in threads]
	return [i for i in season_results if i]
