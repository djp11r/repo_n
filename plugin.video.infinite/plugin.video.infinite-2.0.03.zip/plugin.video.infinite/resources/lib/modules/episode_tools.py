# -*- coding: utf-8 -*-
import sys
import json
import random
from datetime import date
from traceback import print_exc
from modules.sources import Sources
from modules.metadata import episodes_meta, all_episodes_meta, tvshow_meta
from modules.watched_status import get_next_episodes, get_hidden_progress_items, watched_info_episode, get_next, get_watched_status_tvshow, watched_info_tvshow
from modules.utils import adjust_premiered_date, get_datetime, make_thread_list, title_key
from modules.settings import tmdb_api_key, mpaa_region, watched_indicators, date_offset
from modules.kodi_utils import logger, add_dir, get_property, set_property, add_items, make_listitem, set_content, end_directory, set_view_mode, get_icon, get_addon_fanart, build_url, notification
addon_fanart = get_addon_fanart()
window_prop = 'infinite.random_episode_history'


class EpisodeTools:
	def __init__(self, meta, nextep_settings=None):
		self.meta = meta
		self.meta_get = self.meta.get
		self.nextep_settings = nextep_settings

	def next_episode_info(self):
		try:
			play_type = self.nextep_settings['play_type']
			current_date = get_datetime()
			season_data = self.meta_get('season_data')
			current_season, current_episode = int(self.meta_get('season')), int(self.meta_get('episode'))
			season, episode = get_next(current_season, current_episode, [], season_data, 0)
			ep_data = episodes_meta(season, self.meta)
			if not ep_data: return 'no_next_episode'
			ep_data = next((i for i in ep_data if i['episode'] == episode), None)
			if not ep_data: return 'no_next_episode'
			airdate = ep_data['premiered']
			d = airdate.split('-')
			episode_date = date(int(d[0]), int(d[1]), int(d[2]))
			if current_date < episode_date: return 'no_next_episode'
			custom_title = self.meta_get('custom_title', None)
			title = custom_title or self.meta_get('title')
			display_name = '%s - %dx%.2d' % (title, int(season), int(episode))
			self.meta.update({'media_type': 'episode', 'rootname': display_name, 'season': season, 'ep_name': ep_data['title'], 'ep_thumb': ep_data.get('thumb', None),
							'episode': episode, 'premiered': airdate, 'plot': ep_data['plot']})
			url_params = {'media_type': 'episode', 'tmdb_id': self.meta_get('tmdb_id'), 'tvshowtitle': self.meta_get('tvshowtitle'), 'season': season,
						'episode': episode, 'background': 'true', 'nextep_settings': self.nextep_settings, 'play_type': play_type, 'ep_name': ep_data['title']}
			if play_type == 'autoscrape_nextep': url_params['prescrape'] = 'false'
			if custom_title: url_params['custom_title'] = custom_title
			if 'custom_year' in self.meta: url_params['custom_year'] = self.meta_get('custom_year')
		except:
			logger(f'EpisodeTools().next_episode_info self.meta: {self.meta} Error: {print_exc()}')
			url_params = 'error'
		return url_params

	def get_random_episode(self, continual=False, first_run=True):
		try:
			adjust_hours, current_date = date_offset(), get_datetime()
			tmdb_id = self.meta_get('tmdb_id')
			tmdb_key = str(tmdb_id)
			episodes_data = [i for i in all_episodes_meta(self.meta) if i['premiered'] and adjust_premiered_date(i['premiered'], adjust_hours)[0] <= current_date]
			episode_list = []
			if continual:
				try:
					episode_history = json.loads(get_property(window_prop))
					if tmdb_key in episode_history: episode_list = episode_history[tmdb_key]
					else: set_property(window_prop, '')
				except: set_property(window_prop, '')
				episodes_data = [i for i in episodes_data if i not in episode_list]
				if not episodes_data:
					set_property(window_prop, '')
					return self.get_random_episode(continual=True)
			chosen_episode = random.choice(episodes_data)
			if continual:
				episode_list.append(chosen_episode)
				episode_history = {tmdb_key: episode_list}
				set_property(window_prop, json.dumps(episode_history))
			title, season, episode = self.meta['title'], int(chosen_episode['season']), int(chosen_episode['episode'])
			display_name = '%s - %dx%.2d' % (title, season, episode)
			ep_name, plot = chosen_episode['title'], chosen_episode['plot']
			ep_thumb = chosen_episode.get('thumb', None)
			try: premiered = adjust_premiered_date(chosen_episode['premiered'], adjust_hours)[1]
			except: premiered = chosen_episode['premiered']
			self.meta.update({'media_type': 'episode', 'rootname': display_name, 'season': season, 'ep_name': ep_name, 'ep_thumb': ep_thumb,
							'episode': episode, 'premiered': premiered, 'plot': plot})
			url_params = {'mode': 'playback.media', 'media_type': 'episode', 'tmdb_id': tmdb_id, 'tvshowtitle': self.meta_get('tvshowtitle'), 'season': season, 'episode': episode, 'ep_name': ep_name,
						'autoplay': 'true'}
			if continual: url_params['random_continual'] = 'true'
			else: url_params['random'] = 'true'
			if not first_run:
				url_params['background'] = 'true'
				url_params['play_type'] = 'random_continual'
		except: url_params = 'error'
		return url_params

	def play_random(self):
		url_params = self.get_random_episode()
		if url_params == 'error': return notification('Single Random Play Error')
		return Sources().playback_prep(url_params)

	def play_random_continual(self, first_run=True):
		url_params = self.get_random_episode(continual=True, first_run=first_run)
		if url_params == 'error': return notification('Continual Random Play Error')
		return Sources().playback_prep(url_params)

	def auto_nextep(self):
		url_params = self.next_episode_info()
		if url_params == 'error': return notification('Next Episode Error')
		elif url_params == 'no_next_episode': return notification('No Next Episode')
		return Sources().playback_prep(url_params)

def build_next_episode_manager():
	def _process(item):
		try:
			listitem = make_listitem()
			meta, genre, year = {'plot': ' '}, [], 0
			tmdb_id, title = item['media_ids']['tmdb'], item['title']
			if tmdb_id in hidden_list: display, action, sort_value = '[COLOR=grey2]Undrop[/COLOR] [B]%s[/B]' % title, 'undrop', 1
			else:
				meta = tvshow_meta('trakt_dict', item['media_ids'], api_key, mpaa_region_value, current_date)
				total_aired_eps = meta.get('total_aired_eps')
				# logger(f'tmdb_id: {tmdb_id} total_aired_eps: {meta.get("total_aired_eps")}')
				playcount, total_watched, total_unwatched = get_watched_status_tvshow(watched_info.get(str(tmdb_id), None), total_aired_eps)
				display, action, sort_value = f'[COLOR=red]Drop[/COLOR] {title} ~ watched: {total_watched} of {total_aired_eps}', 'drop', 0
				try: genre = meta.get('genre') + [meta.get('status')]
				except: pass
				try: year = int(meta.get('year'))
				except: pass
			meta_get = meta.get
			poster = meta_get('poster') or icon
			fanart = meta_get('fanart') or addon_fanart
			url_params = {'mode': mode, 'action': action, 'media_type': 'shows', 'media_id': tmdb_id, 'section': 'dropped'}
			url = build_url(url_params)
			listitem.setLabel(display)
			listitem.setArt({'poster': poster, 'fanart': fanart, 'icon': poster})
			info_tag = listitem.getVideoInfoTag()
			info_tag.setPlot(' ')
			info_tag.setGenres(genre)
			info_tag.setYear(year)
			append({'listitem': (url, listitem, False), 'sort_title': title, 'sort_value': sort_value})
		except: logger(f'build_next_episode_manager item: {item} Error: {print_exc()}')
	handle = int(sys.argv[1])
	list_items = []
	append = list_items.append
	indicators = watched_indicators()
	current_date = get_datetime()
	api_key, mpaa_region_value = tmdb_api_key(), mpaa_region()
	show_list = get_next_episodes(0)
	hidden_list = get_hidden_progress_items(indicators)
	watched_info = watched_info_tvshow()
	# logger(f'watched_info: {watched_info}')
	if indicators == 0: icon, mode = get_icon('folder'), 'hide_unhide_progress_items'
	else: icon, mode = get_icon('trakt'), 'trakt.hide_unhide_progress_items'
	threads = list(make_thread_list(_process, show_list))
	[i.join() for i in threads]
	item_list = sorted(list_items, key=lambda k: (k['sort_value'], title_key(k['sort_title'])), reverse=False)
	item_list = [i['listitem'] for i in item_list]
	add_items(handle, item_list)
	set_content(handle, 'tvshows')
	end_directory(handle, cacheToDisc=False)
	set_view_mode('view.tvshows', 'tvshows')