# -*- coding: utf-8 -*-

import json
import re
from traceback import print_exc
from urllib.parse import quote_plus, urlencode

import requests

try:
    from modules.kodi_utils import logger, build_url, notification, set_info, execute_builtin, get_addon_fanart, item_next, add_items, set_content, end_directory, set_view_mode, get_infolabel, make_listitem, set_category, external, get_git_url
    from caches.h_cache import main_cache
    addon_fanart = get_addon_fanart()
except:
    import os, sys

    file = os.path.realpath(__file__)
    sys.path.append(os.path.join(os.path.dirname(file), 'modules'))
    from modules.utils import logger
    from modules.h_cache import main_cache
    addon_fanart = ''

from modules.hindi_utils import request, convert_youtube_duration_to_minutes
from modules.dom_parser import parseDOM
from modules.source_utils import normalize

base_link = 'https://www.hindigeetmala.net'


def play_process(choices, thumb):
    for choice in choices:
        try:
            # logger(f'get_yt_links choice: {choice}')
            listitem = make_listitem()
            title = choice['title']
            url_params = {'mode': 'geetm_plvid', 'url': choice['url'], 'title': title}
            url = build_url(url_params)
            listitem.setLabel(label=title)
            choice.update({'imdb_id': title, 'mediatype': 'episode', 'episode': 1, 'season': 0})
            listitem = set_info(listitem, choice, {'imdb': str(title)})
            listitem.setArt({'thumb': thumb})
            # listitem.setProperty('IsPlayable', 'true')
            yield url, listitem, False
        except: logger(f'Error: {print_exc()}')


def geetm_root(params):
    cache_name = 'content_geetmala_chennel'
    list_data = main_cache.get(cache_name)
    # logger(f'from cache list_data: {list_data}')
    if not list_data:
        uri = f'{get_git_url()}/geetmala.json'
        data = request(uri)
        list_data = json.loads(data)
        # logger(f'new list_data: {list_data}')
        if list_data: main_cache.set(cache_name, list_data, expiration=7) # 7days

    # logger(geetmala_data)
    def _process(list_data):
        for item in list_data:
            listitem = make_listitem()
            cm = []
            cm_append = cm.append
            title = item['name']
            url_params = {'mode': 'geetm_list', 'list_name': title, 'ch_name': title, 'url': item['url'], 'image': item['image'], 'pg_no': '1'}
            thumb = item['image']
            url = build_url(url_params)
            listitem.setLabel(title)
            cm_append(('[B]Add to a Shortcut Folder[/B]', 'RunPlugin(%s)' % build_url({'mode': 'menu_editor.shortcut_folder_add_item', 'name': title, 'iconImage': thumb})))
            listitem.addContextMenuItems(cm)
            listitem.setArt({'icon': thumb, 'poster': thumb, 'thumb': thumb, 'fanart': addon_fanart, 'banner': thumb})
            yield url, listitem, True
        # xbmcplugin.addDirectoryItem(int(argv[1]), url, listitem, isFolder=True)

    # item_list = list(_process())
    from sys import argv  # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_external = external()
    add_items(handle, list(_process(list_data)))
    set_content(handle, 'tvshows')
    set_category(handle, 'tvshows')
    end_directory(handle, cacheToDisc=not is_external)
    set_view_mode('view.tvshows', 'tvshows', is_external)


def get_song_list(params):
    url, ch_name, pg_no = params['url'], params['ch_name'], int(params['pg_no'])
    rescrape = params.get('rescrape', 'false')
    if url.endswith('value=') or url == 'YouTube':
        search_text = get_SearchQuery('Hindi Geetmala')
        url += quote_plus(search_text)

    string = f'content_geetm_song_{ch_name}'
    params = {'url': url, 'ch_name': ch_name, 'pg_no': pg_no}
    cache_name = string + urlencode(params)
    song_list = None
    if rescrape == 'true': main_cache.delete(cache_name)
    else: song_list = main_cache.get(cache_name)
    if not song_list:
        if url.startswith('YouTube'):
            movie_t = url.split('YouTube')[1]
            params['query'] = url.split('YouTube')[1]
            song_list = Movie_search().search(params, [])
        else: song_list = make_song_list(params)
        if song_list:
            main_cache.set(cache_name, song_list, expiration=1)  # 1 days cache

    def _process(song_list):
        info = {}
        for item in song_list:
            cm = []
            cm_append = cm.append
            item_get = item.get
            title, thumb, album, artist = item_get('name'), item_get('image'), item_get('album'), item_get('artist')
            url_params = {'mode': item['mode'], 'rescrap': 'false', 'album': album, 'list_name': title, 'ch_name': item['ch_name'], 'url': item['url'], 'thumb': thumb, 'pg_no': item['pg_no']}
            rescrape_params = {'mode': item['mode'], 'rescrap': 'true', 'url': item['url'], 'list_name': title, 'thumb': thumb, 'album': album}
            cm_append((f'[B]Reload[/B] {album}', f'RunPlugin({build_url(rescrape_params)})'))
            is_folder = True
            if 'Next Page:' in title: info['plot'] = 'Go To Next Page....'
            else: info['plot'] = f'album: {album}\nArtist: {artist}'
            listitem = make_listitem()
            listitem.setLabel(title)
            info.update({'imdb_id': title, 'mediatype': 'episode', 'episode': 1, 'season': 0})
            listitem = set_info(listitem, info, {'imdb': str(title)})

            url = build_url(url_params)
            listitem.addContextMenuItems(cm)
            # listitem.setProperty('IsPlayable', 'true')
            listitem.setArt({'icon': thumb, 'poster': thumb, 'thumb': thumb, 'fanart': addon_fanart, 'banner': thumb})
            yield url, listitem, is_folder

    # logger(f'get_song_list item_list: {list(_process())}')
    from sys import argv  # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_external = external()
    if url.startswith('YouTube'):
        add_items(handle, list(play_process(song_list, '')))
        set_content(handle, 'videos')
        set_category(handle, 'videos')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.videos', 'videos', is_external)
    else:
        add_items(handle, list(_process(song_list)))
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.episodes', 'episodes', is_external)


def get_SearchQuery(sitename):
    import xbmc
    keyboard = xbmc.Keyboard()
    keyboard.setHeading(f'Search {sitename}')
    keyboard.doModal()
    return keyboard.getText() if keyboard.isConfirmed() else ''


def make_song_list(params):
    url, ch_name, pg_no = params['url'], params['ch_name'], int(params['pg_no'])
    find_data = re.compile('itemprop="name">(.+?)</span>')
    song_perpage = 25
    songs = []
    nextpg = True
    while len(songs) < song_perpage and nextpg:
        song_page = request(url)
        result = parseDOM(song_page, 'tr', attrs={'itemprop': 'track'})
        for item in result:
            try:
                title = parseDOM(item, 'span', attrs={'itemprop': 'name'})[0]
                vid_url = parseDOM(item, 'a', ret='href')[0]
                img = parseDOM(item, 'img', ret='src')[0]
                album = parseDOM(item, 'span', attrs={'itemprop': 'inAlbum'})[0]
                # album = find_data.findall(album)[0]
                m_name = find_data.findall(album)[0]
                m_year = re.findall(r'\(.+?\)', album, re.MULTILINE)
                m_year = m_year[0].replace('(', '').replace(')', '') if m_year else ''
                album = f'{m_name} - {m_year}'

                artist = parseDOM(item, 'span', attrs={'itemprop': 'byArtist'})[0]
                artist = find_data.findall(artist)[0]
                songs.append({'name': title, 'ch_name': ch_name, 'pg_no': pg_no, 'mode': 'geetm_vid_list', 'album': album, 'artist': artist, 'url': base_link + vid_url, 'image': base_link + img})
            except: pass
        if nextpg:
            pg_no += 1
            if '?page=' not in url: url += f'?page={pg_no}'
            else:
                url = url.split('=')[0]
                url += f'={pg_no}'
        else: nextpg = False

    if nextpg:
        name = f'Next Page: {pg_no}'
        next_pg_dict = {'name': name, 'ch_name': ch_name, 'pg_no': pg_no, 'mode': 'geetm_list', 'album': '', 'artist': '', 'url': url, 'image': item_next}
        songs.append(next_pg_dict)
    # logger('totle from url: %s pg_no: %s song: %s \n %s' % (params['url'], pg_no, len(songs), songs))
    return songs


def resolve_url(url, ltype):
    try:
        import resolveurl
        hmf = resolveurl.HostedMediaFile(url=url)
        return hmf.resolve() if hmf.valid_url() is True else ''
    except Exception as e:
        msg = f'for: {e} Error: {ltype}'
        notification(f'Infinite not resolved\n{msg}', 5000)
        logger(f'from GeetMala resolve_url Error: {msg}')
        return ''


def get_yt_vid_links(url, title, album):
    vid_page = request(url)
    # logger(f'search vid_page {vid_page} ')
    result = parseDOM(vid_page, 'table', attrs={'class': 'b1 w760 alcen'})
    result += parseDOM(vid_page, 'table', attrs={'class': 'b1 allef w100p'})
    choices = []
    try:
        link = parseDOM(result, 'iframe', ret='src')[0]
        if 'youtube.com/embed' in link:
            if v_id := link.replace('https://www.youtube.com/embed/', '').strip():
                v_link = f'plugin://plugin.video.youtube/play/?video_id={v_id}'
                choices.append({'title': f'Song : {title}', 'url': v_link})
    except:
        result = parseDOM(vid_page, 'div', attrs={'class': 'yt_nt'})
        # print(f'result: {result}')
        results = parseDOM(result, 'a', attrs={'class': 'yt_nt'})
        # print(f'results: {results}')
        for item in results:
            if v_id := item.replace('https://www.youtube.com/watch?v=', '').strip():
                v_link = f'plugin://plugin.video.youtube/play/?video_id={v_id}'
                choices.append({'title': f'Song : {title}', 'url': v_link})
        if len(choices) > 1: return choices
    # else:
    #     v_link = parseDOM(result, 'a', ret = 'href')[0]

    links = parseDOM(result, 'tr')
    find_data = re.compile('<td>(.+?)</td>')
    for link in links:
        # logger(f'from Movie link: \n{link}\n>>>>>\n')
        td_data = find_data.findall(link)
        try:
            if 'Watch Full Movie:' in td_data[0]:
                movie_link = parseDOM(td_data[1], 'a', ret='href')
                # logger('from youtube movie links: %s' % movie_link)
                for link_item in movie_link:
                    v_id = link_item.replace('https://www.youtube.com/watch?v=', '').strip()
                    if v_link := f'plugin://plugin.video.youtube/play/?video_id={v_id}':
                        choices.append({'title': f'Movie: {album}', 'url': v_link})
        except: pass
    if len(choices) <= 1: choices = Movie_search().search(album, choices)
    return choices


def get_yt_links(params):
    url, title, album, rescrap, thumb = params['url'], params['list_name'], params['album'], params['rescrap'], params['thumb']
    string = f'content_geetm_yt_links_{title}_{album}'
    choices = main_cache.get(string)
    if not choices or rescrap == 'true':
        # logger(f'---geetmala link: {url}\ntitle: {title}\nAlbum: {album}')
        choices = get_yt_vid_links(url, title, album)
        if choices: main_cache.set(string, choices, expiration=1) # 1 day

    # logger(f'rescrap: {rescrap} choices {choices}')
    from sys import argv  # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_external = external()
    add_items(handle, list(play_process(choices, thumb)))
    set_content(handle, 'videos')
    set_category(handle, 'videos')
    end_directory(handle, cacheToDisc=not is_external)
    set_view_mode('view.videos', 'videos', is_external)


def play(stream, channel=None, xbmc_player=False):
    # logger('play stream: {} channel: {}'.format(stream, channel))
    execute_builtin(f'RunPlugin({stream})')


class Movie_search:
    def __init__(self):
        self.key = 'AIzaSyCjf8izIeXa1oFZo7_HeL0WgrOq1WF_I1k'
        self.search_link = f'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=15&q=%s&key={self.key}'

    def search(self, params, choices):
        try:
            name = params['query']
            query = f'{name} full|Full movie|Movie'
            query_url = self.search_link % quote_plus(query)
            # logger(f'query: {query}')

            # query_url += '&relevanceLanguage=en'
            headers = {'Accept': 'application/json'}
            response = requests.get(query_url, headers=headers).json()
            # logger(f'search json response {response} ')
            if error := response.get('error', []):
                message = error.get('message', [])
                logger(f'message: {message}')
                return None

            json_items = response.get('items', [])
            # logger(f'search json_items {json_items} ')
            # logger(f'search json_items {to_utf8(json_items)} ')
            for search_result in json_items:
                try:
                    query = query.split('-')[0].lower().replace('.', '')
                    item_title = normalize(search_result['snippet']['title'].replace('.', ''))
                    # item_title = replace_html_codes(search_result['snippet']['title'].replace('.', ''))
                    if re.search('Full Movie|Movie', item_title, re.I) and re.search(query, item_title, re.I) and search_result['id']['kind'] == 'youtube#video':
                        vid_id = search_result['id']['videoId']
                        payload = {'id': vid_id, 'part': 'contentDetails', 'key': self.key}
                        url = f'https://www.googleapis.com/youtube/v3/videos/?&{urlencode(payload)}'
                        resp_dict = requests.get(url, headers=headers).json()
                        # resp_dict = self.session.get('https://www.googleapis.com/youtube/v3/videos', params=payload).json()
                        dur = resp_dict['items'][0]['contentDetails']['duration']
                        duration = convert_youtube_duration_to_minutes(dur)
                        # logger(f'dur: {dur} duration: {duration}')
                        if duration > 70:
                            v_link = f'plugin://plugin.video.youtube/play/?video_id={vid_id}'
                            # logger(f'item_title: {item_title} v_link: {v_link}')
                            choices.append({'title': f'Movie: ({duration} minutes) {item_title}', 'url': v_link})
                except: logger(f'Error: {print_exc()}')
        except: logger(f'Error: {print_exc()}')
        # logger(f'choices: {choices}')
        return choices