# -*- coding: utf-8 -*-
import time
from modules.kodi_utils import addon_fanart
from windows.base_window import BaseDialog
from modules.settings import avoid_episode_spoilers
# from modules.kodi_utils import logger

class NextEpisode(BaseDialog):
	episode_status_dict = {'season_premiere': ('Season Premiere', 'b30385b5'), 'mid_season_premiere': ('Mid-Season Premiere', 'b385b503'), 'series_finale': ('Series Finale', 'b38503b5'), 'season_finale': ('Season Finale', 'b3b50385'), 'mid_season_finale': ('Mid-Season Finale', 'b3b58503'), '':  (None, None)}
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.closed = False
		self.start_time = 0
		self.test = kwargs.get('test', False)
		self.meta = kwargs.get('meta')
		self.selected = kwargs.get('default_action', 'cancel')
		self.set_properties()

	def onInit(self):
		try: self.setFocusId(11)
		except: pass
		self.monitor()

	def run(self):
		self.doModal()
		self.clearProperties()
		self.clear_modals()
		return self.selected

	def onAction(self, action):
		if action in self.closing_actions:
			self.selected = 'close'
			self.closed = True
			self.close()

	def onClick(self, controlID):
		self.selected = {10: 'close', 11: 'play', 12: 'cancel'}[controlID]
		self.closed = True
		self.close()

	def set_properties(self):
		episode_type = self.meta.get('episode_type', '')
		self.setProperty('mode', 'next_episode')
		self.setProperty('thumb', self.get_thumb())
		self.setProperty('clearlogo', self.meta.get('clearlogo', ''))
		self.setProperty('episode_label', '%s[B] | [/B]%02dx%02d[B] | [/B]%s[B] | [/B]%s' % (self.meta['title'], self.meta['season'], self.meta['episode'], self.meta['ep_name'], self.meta['premiered']))
		status_label, status_highlight = self.episode_status_dict[episode_type]
		if status_label:
			self.setProperty('episode_status.label', status_label)
			self.setProperty('episode_status.highlight', status_highlight)

	def get_thumb(self):
		if avoid_episode_spoilers(): thumb = self.meta.get('fanart', '') or addon_fanart()
		else: thumb = self.meta.get('ep_thumb', None) or self.meta.get('fanart', '') or addon_fanart()
		return thumb

	def update_progress_bar(self, remaining_time, total_remaining):
		elapsed_time = max((time.time() - self.start_time), 0)
		self.setProperty('elapsed_time', f'{int(elapsed_time)}')
		current_point = (remaining_time / float(total_remaining)) * 100
		try: self.get_control(5000).setPercent(current_point)
		except: pass

	def monitor(self):
		self.start_time = time.time()
		if self.test:
			for remaining_time in range(100, 0, -5):
				if self.closed: break
				if remaining_time == 0: break
				self.update_progress_bar(remaining_time, 100)
				self.sleep(1000)
			return self.close()
		total_time = self.player.getTotalTime()
		total_remaining = total_time - self.player.getTime()
		while self.player.isPlaying():
			remaining_time = round(total_time - self.player.getTime())
			self.update_progress_bar(remaining_time, total_remaining)
			if self.closed: break
			elif self.selected == 'pause' and remaining_time <= 10:
				self.player.pause()
				self.sleep(500)
				break
			self.sleep(1000)
		if self.selected == 'pause':
			end_time = self.start_time + 900
			current_time = self.start_time
			while current_time <= end_time and self.selected == 'pause':
				try:
					current_time = time.time()
					pause_timer = time.strftime('%M:%S', time.gmtime(max(end_time - current_time, 0)))
					self.setProperty('pause_timer', pause_timer)
					self.sleep(1000)
				except: break
			if self.selected != 'cancel': self.player.pause()
		self.close()

class StingersNotification(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.stinger_dict = {'duringcreditsstinger': {'id': 200, 'property': 'color_during'}, 'aftercreditsstinger': {'id': 201, 'property': 'color_after'}}
		self.closed = False
		self.meta = kwargs.get('meta')
		self.stingers = self.meta.get('stinger_keys')
		self.set_properties()
		self.test = kwargs.get('test', False)

	def onInit(self):
		self.make_stingers()
		self.monitor()

	def run(self):
		self.doModal()
		self.clearProperties()
		self.clear_modals()

	def onAction(self, action):
		if action in self.closing_actions:
			self.closed = True
			self.close()

	def make_stingers(self):
		for k, v in self.stinger_dict.items():
			if k in self.stingers:
				self.setProperty(v['property'], 'green')
				self.set_image(v['id'], 'common/overlay_selected.png')
			else:
				self.setProperty(v['property'], 'red')
				self.set_image(v['id'], 'common/close.png')

	def set_properties(self):
		self.setProperty('mode', 'stinger')
		self.setProperty('thumb', self.meta.get('fanart', '')) or addon_fanart()
		self.setProperty('clearlogo', self.meta.get('clearlogo', ''))

	def monitor(self):
		total_time = 10000
		if self.test:
			for remaining_time in range(100, 0, -5):
				if self.closed: break
				if remaining_time == 0: break
				self.sleep(1000)
			return self.close()
		while self.player.isPlaying() and total_time > 0:
			if self.closed: break
			self.sleep(1000)
			total_time -= 1000
		self.close()
