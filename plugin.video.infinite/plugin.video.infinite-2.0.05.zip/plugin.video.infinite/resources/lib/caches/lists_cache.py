# -*- coding: utf-8 -*-
from caches.base_cache import BaseCache, get_timestamp
# from modules.kodi_utils import logger

class ListsCache(BaseCache):
	def __init__(self):
		BaseCache.__init__(self, 'lists_db', 'lists')

	def delete_all_lists(self):
		try:
			dbcon = self.manual_connect('lists_db')
			dbcon.execute('DELETE FROM lists')
			dbcon.execute('VACUUM')
			return True
		except: return False

	def clean_database(self):
		try:
			dbcon = self.manual_connect('lists_db')
			dbcon.execute('DELETE from lists WHERE CAST(expires AS INT) <= ?', (get_timestamp(),))
			dbcon.execute('VACUUM')
			return True
		except: return False

lists_cache = ListsCache()

def lists_cache_object(function, string, args, json=False, expiration=168):
	if data := lists_cache.get(string): return data
	args = tuple(args) if isinstance(args, list) else (args, )
	result = function(*args).json() if json else function(*args)
	lists_cache.set(string, result, expiration=expiration)
	return result