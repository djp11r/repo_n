# -*- coding: utf-8 -*-
from windows import BaseDialog
from modules.settings import get_art_provider
from modules.kodi_utils import Thread, get_visibility, hide_busy_dialog, addon_icon, addon_fanart, local_string as ls
# from modules.kodi_utils import logger

class ResolverDialog(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.is_canceled = False
		self.meta = kwargs.get('meta')
		self.make_items()
		self.set_properties()

	def onInit(self):
		Thread(target=self.busy_dialog_check).start()

	def run(self):
		self.doModal()
		self.is_canceled = True
		self.clearProperties()

	def iscanceled(self):
		return self.is_canceled

	def onAction(self, action):
		if action in self.closing_actions:
			self.is_canceled = True

	def busy_dialog_check(self):
		while not self.is_canceled:
			if get_visibility('Window.IsTopMost(busydialog)'): hide_busy_dialog()
			if self.player.isPlayingVideo(): break
			self.sleep(100)

	def make_items(self):
		self.poster_main, self.poster_backup, self.fanart_main, self.fanart_backup, self.clearlogo_main, self.clearlogo_backup = get_art_provider()
		self.title = self.meta['title']
		self.year = str(self.meta['year'])
		self.fanart = self.meta.get('custom_fanart') or self.meta.get(self.fanart_main) or self.meta.get(self.fanart_backup) or addon_fanart
		self.clearlogo = self.meta.get('custom_clearlogo') or self.meta.get(self.clearlogo_main) or self.meta.get(self.clearlogo_backup) or ''
		if self.meta['media_type'] == 'movie': self.text = self.meta['plot']
		else: self.text = '[B]%02dx%02d - %s[/B][CR][CR]%s' % (self.meta['season'], self.meta['episode'], self.meta['ep_name'], self.meta['plot'])

	def set_properties(self):
		self.setProperty('title', self.title)
		self.setProperty('fanart', self.fanart)
		self.setProperty('clearlogo', self.clearlogo)
		self.setProperty('text', self.text)

	def update(self, content=''):
		try: self.getControl(2001).setText('••••  %s  ••••[CR]••••  %s  ••••' % content)
		except: self.getControl(2001).setText('')
