# -*- coding: utf-8 -*-
import time
import traceback
from datetime import datetime, timedelta
from caches.base_cache import BaseCache
from modules.kodi_utils import get_property, set_property, clear_property, database, hindi_db, hindi_meta_db, logger

like_select = 'SELECT id from maincache where id LIKE %s'
like_delete = 'DELETE FROM maincache WHERE id LIKE %s'
delete = 'DELETE FROM maincache WHERE id=?'
all_list_add = ' OR id LIKE '

class MainCache(BaseCache):
	def __init__(self):
		BaseCache.__init__(self, hindi_db, 'maincache')

	def delete_all_lists(self, alllist=False):
		if alllist: media_list = ["'content_list_%'", "'movies_list_%'", "'shows_list_%'", "'episodes_list_%'", "'Htvshows%'", "'tubitv2_%'", "'Hepiso_%'"]
		else: media_list = ["'content%'", "'shows_list_%'", "'episodes_list_%'", "'Htvshows%'", "'distro_data%'"]
		dbcon = self.connect_database()
		dbcur = self.set_PRAGMAS(dbcon)
		len_media_list = len(media_list)
		for count, item in enumerate(media_list, 1):
			if count == 1: command = like_select % item
			else: command += '%s%s' % (all_list_add, item)
		dbcur.execute(command)
		results = dbcur.fetchall()
		try:
			for item in results:
				try:
					remove_id = str(item[0])
					logger(f"delete_all_lists remove_id: {remove_id}")
					dbcur.execute(delete, (remove_id,))
					self.delete_memory_cache(remove_id)
				except: pass
			dbcon.execute('VACUUM')
		except: logger(f"clean_hindi_lists Error:{traceback.print_exc()}")

	def delete_all_folderscrapers(self):
		dbcon = self.connect_database()
		dbcur = self.set_PRAGMAS(dbcon)
		dbcur.execute(like_select % "'infinite_FOLDERSCRAPER_%'")
		remove_list = [str(i[0]) for i in dbcur.fetchall()]
		if not remove_list: return 'success'
		try:
			dbcur.execute(like_delete % "'infinite_FOLDERSCRAPER_%'")
			dbcon.execute('VACUUM')
			for item in remove_list: self.delete_memory_cache(str(item))
		except: pass

	def clean_expires_lists(self):
		dbcon = self.connect_database()
		dbcur = self.set_PRAGMAS(dbcon)
		dbcur.execute("SELECT * FROM maincache")
		results = dbcur.fetchall()
		if len(results) == 0: return
		for item in results:
			try:
				# logger("id: %s\ndata: %s" % (item[0],item[2]))
				if item[2] < int(time.mktime(datetime.now().timetuple())):
					logger(f"clean_expires_lists deleted id as item[0]: {item[0]}")
					dbcur.execute("DELETE FROM maincache WHERE id=? AND data=? AND expires=?", (item[0], item[1], item[2]))
			except: pass
		dbcon.commit()
		dbcur.execute("VACUUM")
		dbcon.close()
		return

	def delete_one(self, id_item, dbcon=None):
		try:
			dbcon = self.connect_database()
			dbcur = self.set_PRAGMAS(dbcon)
			dbcur.execute("""DELETE FROM maincache WHERE id=?""", (str(id_item),))
			self.delete_memory_cache(str(id_item))
			dbcon.commit()
			dbcon.execute("VACUUM")
			dbcon.close()
		except: return logger(f"delete id_item:{id_item}\nError: {traceback.print_exc()}")


main_cache = MainCache()

def cache_object(function, string, args, json=True, expiration=24):
	# logger('cache_object function: {}, string: {}, url: {}, json: {}, expiration: {}'.format(function, string, url, json, expiration))
	cache = main_cache.get(string)
	# logger('cache_object cache {}'.format(cache))
	if cache is not None: return cache
	if isinstance(args, list): args = tuple(args)
	else: args = (args,)
	if json: result = function(*args).json()
	else: result = function(*args)
	# logger('cache_object result {}'.format(result))
	main_cache.set(string, result, expiration=timedelta(hours=expiration))
	return result


# hindi_meta_db = 'list_data/hindi_metacache.db'  #translate_path('special://home/addons/plugin.video.infinite/resources/lib/indexers/hindi/list_data/metacache.db')
all_tables = ('metadata', 'season_metadata', 'function_cache')
id_types = ('tmdb_id', 'imdb_id', 'tvdb_id')
season_prop, media_prop = 'infinite.meta_season_%s', 'infinite.%s_%s_%s'
GET_MOVIE_SHOW = 'SELECT meta, expires FROM metadata WHERE db_type = ? AND %s = ?'
GET_SEASON = 'SELECT meta, expires FROM season_metadata WHERE tmdb_id = ?'
GET_FUNCTION = 'SELECT string_id, data, expires FROM function_cache WHERE string_id = ?'
GET_ALL = 'SELECT db_type, tmdb_id FROM metadata'
SET_MOVIE_SHOW = 'INSERT OR REPLACE INTO metadata VALUES (?, ?, ?, ?, ?, ?)'
SET_SEASON = 'INSERT INTO season_metadata VALUES (?, ?, ?)'
SET_FUNCTION = 'INSERT INTO function_cache VALUES (?, ?, ?)'
DELETE_MOVIE_SHOW = 'DELETE FROM metadata WHERE db_type = ? AND %s = ?'
DELETE_SEASON = 'DELETE FROM season_metadata WHERE tmdb_id = ?'
DELETE_SEASONS = 'DELETE FROM season_metadata WHERE tmdb_id LIKE ?'
DELETE_FUNCTION = 'DELETE FROM function_cache WHERE string_id = ?'
DELETE_ALL = 'DELETE FROM %s'
string = str

class MetaCache:
	def get(self, media_type, id_type, media_id):
		meta, fanart_data, custom_artwork = None, None, None
		try:
			media_id = string(media_id)
			current_time = self._get_timestamp(datetime.now())
			meta = self.get_memory_cache(media_type, id_type, media_id, current_time)
			if meta is None:
				dbcur = self._connect_database()
				cache_data = dbcur.execute(GET_MOVIE_SHOW % id_type, (media_type, media_id)).fetchone()
				if cache_data:
					meta, expiry = eval(cache_data[0]), cache_data[1]
					if expiry < current_time:
						fanart_data, custom_artwork = self.get_fanart_dict(meta), self.get_custom_artwork(meta)
						self.delete(media_type, id_type, media_id, meta=meta, dbcur=dbcur)
						meta = None
					else: self.set_memory_cache(media_type, id_type, meta, expiry, media_id)
		except: pass
		return meta, fanart_data, custom_artwork

	def get_season(self, prop_string):
		meta = None
		try:
			current_time = self._get_timestamp(datetime.now())
			meta = self.get_memory_cache_season(prop_string, current_time)
			if meta is None:
				dbcur = self._connect_database()
				cache_data = dbcur.execute(GET_SEASON, (prop_string,)).fetchone()
				if cache_data:
					meta, expiry = eval(cache_data[0]), cache_data[1]
					if expiry < current_time:
						self.delete_season(prop_string, dbcur=dbcur)
						meta = None
					else: self.set_memory_cache_season(prop_string, meta, expiry)
		except: pass
		return meta

	def set(self, media_type, id_type, meta, expiration=30, tmdb_id=None):
		try:
			meta_get = meta.get
			expires = self._get_timestamp(datetime.now() + timedelta(days=expiration))
			dbcur = self._connect_database()
			media_id = string(meta_get(id_type))
			dbcur.execute(SET_MOVIE_SHOW, (media_type, string(meta_get('tmdb_id')), meta_get('imdb_id'), string(meta_get('tvdb_id')), repr(meta), expires))
		except: return None
		self.set_memory_cache(media_type, id_type, meta, expires, media_id)

	def set_season(self, prop_string, meta, expiration=30):
		try:
			expires = self._get_timestamp(datetime.now() + timedelta(days=expiration))
			dbcur = self._connect_database()
			dbcur.execute(SET_SEASON, (prop_string, repr(meta), int(expires)))
		except: return None
		self.set_memory_cache_season(prop_string, meta, expires)

	def delete(self, media_type, id_type, media_id, meta=None, dbcur=None):
		try:
			if not dbcur: dbcur = self._connect_database()
			dbcur.execute(DELETE_MOVIE_SHOW % id_type, (media_type, media_id))
			for item in id_types: self.delete_memory_cache(media_type, item, meta[item])
			if media_type == 'tvshow': dbcur.execute(DELETE_SEASONS, (media_id+'%',))
		except: return

	def delete_season(self, prop_string, dbcur=None):
		try:
			if not dbcur: dbcur = self._connect_database()
			dbcur.execute(DELETE_SEASON, (prop_string,))
			self.delete_memory_cache_season(prop_string)
		except: return

	def get_memory_cache(self, media_type, id_type, media_id, current_time):
		result = None
		try:
			prop_string = media_prop % (media_type, id_type, media_id)
			cachedata = get_property(prop_string)
			if cachedata:
				cachedata = eval(cachedata)
				if cachedata[0] > current_time: result = cachedata[1]
		except: pass
		return result

	def get_memory_cache_season(self, prop_string, current_time):
		result = None
		try:
			cachedata = get_property(season_prop % prop_string)
			if cachedata:
				cachedata = eval(cachedata)
				if cachedata[0] > current_time: result = cachedata[1]
		except: pass
		return result

	def set_memory_cache(self, media_type, id_type, meta, expires, media_id):
		try:
			cachedata, prop_string = (expires, meta), media_prop % (media_type, id_type, media_id)
			set_property(prop_string, repr(cachedata))
		except: pass

	def set_memory_cache_season(self, prop_string, meta, expires):
		try:
			cachedata = (expires, meta)
			set_property(season_prop % prop_string, repr(cachedata))
		except: pass

	def delete_memory_cache(self, media_type, id_type, media_id):
		try: clear_property(media_prop % (media_type, id_type, media_id))
		except: pass

	def delete_memory_cache_season(self, prop_string):
		try: clear_property(season_prop % prop_string)
		except: pass

	def get_function(self, prop_string):
		result = None
		try:
			current_time = self._get_timestamp(datetime.now())
			dbcur = self._connect_database()
			dbcur.execute(GET_FUNCTION, (prop_string,))
			cache_data = dbcur.fetchone()
			if cache_data and cache_data[2] > current_time: result = eval(cache_data[1])
			else: dbcur.execute(DELETE_FUNCTION, (prop_string,))
		except: pass
		return result

	def set_function(self, prop_string, result, expiration=1):
		try:
			expires = self._get_timestamp(datetime.now() + expiration)
			dbcur = self._connect_database()
			dbcur.execute(SET_FUNCTION, (prop_string, repr(result), expires))
		except: return

	def delete_all_seasons(self, media_id, dbcur=None):
		if not dbcur: dbcur = self._connect_database()
		for item in range(1,51): self.delete_season('%s_%s' % (media_id, string(item)))

	def delete_all(self):
		try:
			dbcon = database.connect(metacache_db, timeout=240, isolation_level=None)
			dbcur = dbcon.cursor()
			dbcur.execute('''PRAGMA synchronous = OFF''')
			dbcur.execute('''PRAGMA journal_mode = OFF''')
			dbcur.execute(GET_ALL)
			all_entries = dbcur.fetchall()
			for i in all_tables: dbcur.execute(DELETE_ALL % i)
			dbcon.execute('VACUUM')
			for i in all_entries:
				try:
					media_type, tmdb_id = string(i[0]), string(i[1])
					self.delete_memory_cache(media_type, 'tmdb_id', tmdb_id)
					# if media_type == 'tvshow': self.delete_all_seasons(tmdb_id, dbcur=dbcur)
				except: pass
		except: return

	def get_fanart_dict(self, meta):
		if meta.get('fanart_added', False):
			return {'poster2': meta['poster2'], 'fanart2': meta['fanart2'], 'banner': meta['banner'], 'clearart': meta['clearart'],
					'clearlogo2': meta['clearlogo2'], 'landscape': meta['landscape'], 'discart': meta['discart'], 'fanart_added': True}
		else: return None

	def get_custom_artwork(self, meta):
		return {'custom_poster': meta.get('custom_poster', ''), 'custom_fanart': meta.get('custom_fanart', ''), 'custom_clearlogo': meta.get('custom_clearlogo', '')}

	def _connect_database(self):
		dbcon = database.connect(metacache_db, timeout=240, isolation_level=None)
		dbcur = dbcon.cursor()
		dbcur.execute('''PRAGMA synchronous = OFF''')
		dbcur.execute('''PRAGMA journal_mode = OFF''')
		return dbcur

	def _get_timestamp(self, date_time):
		return int(time.mktime(date_time.timetuple()))

	def get_all_data(self, db_type, table_name, no_of_records=10):
		result = []
		try:
			dbcon = self._connect_database()
			dbcur = self._set_PRAGMAS(dbcon)
			if db_type in ('movie', 'tvshow'):
				# dbcur.execute("SELECT * FROM %s WHERE db_type = ?" % table_name, (str(db_type),))
				dbcur.execute("SELECT meta FROM %s WHERE db_type = ?" % table_name, (str(db_type),))
				cache_data = dbcur.fetchall()
				if cache_data:
					nos = 0
					for i in cache_data:
						result.append(i[0])
						nos += 1
						if nos >= no_of_records: break
		except Exception as e:
			logger('trouble with MetaCache.set Error: {}'.format(traceback.print_exc()), e)
		return result


metacache = MetaCache()


def cache_function(function, prop_string, url, expiration=96, json=True):
	data = metacache.get_function(prop_string)
	if data: return data
	if json: result = function(url).json()
	else: result = function(url)
	metacache.set_function(prop_string, result, expiration=timedelta(hours=expiration))
	return result

def delete_meta_cache(silent=False):
	from modules.kodi_utils import confirm_dialog
	try:
		if not silent and not confirm_dialog(): return False
		metacache.delete_all()
		return True
	except: return False
