# -*- coding: utf-8 -*-
from modules import service_functions
from modules.kodi_utils import Thread, xbmc_monitor, logger, local_string as ls

# infinite_str = ls(32036).upper()
OnNotificationActions = service_functions.OnNotificationActions()
OnSettingsChangedActions = service_functions.OnSettingsChangedActions()

class infiniteMonitor(xbmc_monitor):
	def __init__ (self):
		xbmc_monitor.__init__(self)
		self.startUpServices()

	def startUpServices(self):
		try: service_functions.InitializeDatabases().run()
		except Exception as e: logger('error in service: InitializeDatabases', str(e))
		Thread(target=service_functions.DatabaseMaintenance().run).start()
		try: service_functions.CheckSettings().run()
		except Exception as e: logger('error in service: DatabaseMaintenance', str(e))
		try: service_functions.CleanSettings().run()
		except Exception as e: logger('error in service: CleanSettings', str(e))
		try: service_functions.FirstRunActions().run()
		except Exception as e: logger('error in service: FirstRunActions', str(e))
		try: service_functions.ReuseLanguageInvokerCheck().run()
		except Exception as e: logger('error in service: ReuseLanguageInvokerCheck', str(e))
		Thread(target=service_functions.TraktMonitor().run).start()
		Thread(target=service_functions.CustomActions().run, args=('context_menu',)).start()
		Thread(target=service_functions.CustomActions().run, args=('info_dialog',)).start()
		try: service_functions.ClearSubs().run()
		except Exception as e: logger('error in service: ClearSubs', str(e))
		try: service_functions.AutoRun().run()
		except: pass
		try: service_functions.SyncMyAccounts().run()
		except: pass

	def onSettingsChanged(self):
		OnSettingsChangedActions.run()

	def onNotification(self, sender, method, data):
		OnNotificationActions.run(sender, method, data)

	def onAction(self, action):
		pass

infiniteMonitor().waitForAbort()

logger('Settings Monitor Service Finished')
logger('Main Monitor Service Finished')
