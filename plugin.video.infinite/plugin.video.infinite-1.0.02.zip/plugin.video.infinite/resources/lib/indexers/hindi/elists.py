# -*- coding: utf-8 -*-

import json
import re
from traceback import print_exc
from urllib.parse import urlencode, urlparse, quote_plus

try:
    from modules.kodi_utils import set_resolvedurl, logger, kodi_player, build_url, select_dialog, make_listitem, set_info,  notification, add_items, set_content, end_directory, set_view_mode, get_infolabel, set_category, external, get_list_item, nextpage
    from modules.settings import get_git_url
    from modules.utils import normalize
    from modules.source_utils import request, agent, get_page_server, get_link, convert_youtube_duration_to_minutes
    from caches.main_cache import main_cache, cache_object
    from caches.settings_cache import get_setting
    ddurl = get_setting('infinite.live_url', '')
    chnnel_filter = get_setting('infinite.live_channels', 'DAZN, Movistar').split(', ')
except:
    # logger(f'import Exception: {print_exc()}')
    from modules.utils import logger, normalize
    from modules.main_cache import main_cache, cache_object
    from modules.client import request, agent, get_page_server
    from modules.client_utils import get_link
    from modules.hindi_utils import convert_youtube_duration_to_minutes
    import os
    nextpage = ''
    ddurl = 'https://thedaddy.to'
    chnnel_filter = ['DAZN', 'Movistar', 'Espa', 'Alkass', 'Greece', 'Netherland', 'Germany', 'SUR', 'Deportes', 'Galavisi', 'Latino', 'Russia', 'Campeones', 'ES', 'Romania', 'DSTV', 'Italy', 'Argentina', 'Afrique', 'Denmark', 'Brasil', 'Sweden', 'Cosmote', 'Israe', 'Israel', 'Poland', 'Bulgaria', 'Spain', 'Qatar', 'Turkey', 'France', 'MENA', 'DE', 'Portugal', 'Croatia', 'Astro', 'Serbia']
from modules.dom_parser import parseDOM

tvappurl = 'https://thetvapp.to'
header = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7', 'Accept-Encoding': 'gzip, deflate', 'Accept-Language': 'en,en-US;q=0.9', 'Cache-Control': 'no-cache', 'Pragma': 'no-cache', 'Sec-Ch-Ua': '"Not(A:Brand";v="24", "Chromium";v="122"', 'Sec-Ch-Ua-Mobile': '?0', 'Sec-Ch-Ua-Platform': "Windows", 'Sec-Fetch-Dest': 'document', 'Sec-Fetch-Mode': 'navigate', 'Sec-Fetch-Site': 'same-site', 'Sec-Fetch-User': '?1', 'Upgrade-Insecure-Requests': '1', 'DNT': '1', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'}
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0'
play_youtube_url = 'plugin://plugin.video.youtube/play/?video_id'


def get_c_list(params):
    ch_name = params['list_name']
    cache_name = f'content_{ch_name}{urlencode(params)}'
    list_data = main_cache.get(cache_name)
    if not list_data:
        git_url = get_git_url()
        if ch_name == 'youtube': data = request(f'{git_url}/youtub_live.json')
        elif ch_name == 'pluto': data = request(f'{git_url}/pluto.json')
        elif ch_name == 'indianlive': data = request(f'{git_url}/indian_live.json')
        elif ch_name == 'daddy': list_data = ch_dl()
        elif ch_name == 'theapp': list_data = ch_tvapp()
        elif ch_name == 'ddevent': list_data = sched_date()
        if ch_name in ('youtube', 'pluto', 'indianlive'): list_data = eval(str(data)) # loads(data)
        if list_data and ch_name != 'ddevent': main_cache.set(cache_name, list_data, expiration=168) # 7days
        else: main_cache.set(cache_name, list_data, expiration=4) # 6 hrs
    # logger(f'from cache list_data: {list_data}')
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_external = external()
    if list_data:
        add_items(handle, list(get_list_item(list_data, ch_name)))
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.episodes', 'episodes', is_external)
    else:
        notification(f'No links Found for: :{ch_name} Retry')
        end_directory(handle)
        return


def play(params):
    # logger(f'play params {params}')
    url = params['url']
    try:
        direct_player = False
        if params['provider'] in ('daddy', 'ddevent'):
            ourl = relv_daddy(url)
            if ourl: return set_resolvedurl(ourl, params['title'])
        elif params['provider'] == 'theapp': ourl = relv_theapp(url)
        elif params['provider'] == 'youtube':
            items = get_m3u8_url(url)
            list_items = [{'line1': i['title']} for i in items]
            kwargs = {'items': json.dumps(list_items), 'narrow_window': 'false'}
            choice = select_dialog(items, **kwargs)
            if choice == None: return
            ourl = choice['url']
        elif params['provider'] == 'pluto' and 'm3u8' in url: ourl = f'{url}|User-Agent={agent()}&Referer={url}'
        elif params['provider'] == 'crick_live': ourl = url
        else: ourl = f'{url}|User-Agent={agent()}'
        if ourl is None:
            logger(f'--- Playing url: {ourl} \nparams: {params}')
            return notification(f'No links Found for: :{params["title"]} Retry')
        kodi_player(ourl, params['title'], direct_player)
    except:
        logger(f'play provider: {params} - Exception: {print_exc()}')
        return


def splitter(item):
    split = item[0].split('","')
    return (split[0], item[1])

def get_videolist(url):
    if 'https://www.youtube.com/channel' in url: response = request(url)
    else: response = request(f'{url}/videos')
    # logger(response)
    vars_ = re.compile(r'var ytInitialData =.*?[\'|"|{](.+)[\'|"|}][,;]</script>').findall(response)
    # logger(f'>>> : {vars_[0]} \nvars_>>> : {type(vars_)} vars_: {vars_}')

    tab_items = re.findall(r'''(?:videoId|file)['"]*:\s*(?:"|')(.+?)(?:"|')\s*?label\s*["']?\s*[:=]\s*["'](.+?)(?:"|')''', str(vars_[0]), re.I | re.M)

    new_tabitem = tuple(splitter(item) for item in tab_items)
    choices = []
    for item in new_tabitem:
        # logger(f'tab_items>>> : {repr(item)}')
        furl = f'{play_youtube_url}={item[0]}'
        if furl not in str(choices): choices.append({'title': f'{item[1]}', 'mode': 'geetm_plvid', 'url': furl})
        # logger(f'tab_items>>> : {item[0]}\n      {item[1]}')
    logger(f'Total videoId: {len(new_tabitem)} get link from total choices: {len(choices)}')
    return choices


def get_m3u8_url(url):
    # logger(f'get_m3u8_url url: {url}')
    # videolist = get_videolist(url)
    videolist = cache_object(get_videolist, url, [url], False, 4)

    return videolist


def extract_m3u8(response, m3u8_extension='.m3u8', https_prefix='https://', tuner_increment=5, initial_tuner=200):
    end = response.find(m3u8_extension)
    if end == -1: raise ValueError('No .m3u8 found in the response')
    end += len(m3u8_extension)
    tuner = initial_tuner
    # logger(f'extract_m3u8 tuner: {tuner} end: {end}')

    while True:
        # logger(f'extract_m3u8 response[{end - tuner}: {end}]')
        potential_link = response[end - tuner: end]
        if https_prefix in potential_link:
            link = potential_link
            start = link.find(https_prefix)
            end = link.find(m3u8_extension) + len(m3u8_extension)
            break
        else: tuner += tuner_increment
    logger(f'extract_m3u8 length of links: {len(link[start: end])}')
    # logger(f'extract_m3u8  type: {type(link)} length of links: {len(link[start: end])}  : repr {repr(link)} : {link[start: end]}')
    return link[start: end]


def ch_dl():
    url = f'{ddurl}/24-7-channels.php'
    do_adult = False  #xbmcaddon.Addon().getSetting('adult_pw')
    hea = {'Referer': f'{ddurl}/', 'User-Agent': UA}
    resp = request(url, headers=hea)
    # logger(f'resp: {resp}')
    ch_block = re.compile(r'<center><h1(.+?)tab-2', re.M | re.DOTALL).findall(str(resp))
    chan_data = re.compile(r'href=\"(.*)\" target(.*)<strong>(.*)</strong>').findall(str(ch_block[0]))
    # logger(f'chan_data: {chan_data}')
    ch_list = []
    for item in chan_data:
        try:
            url, title = str(item[0]), str(item[2])
            if any(x in title for x in chnnel_filter): continue
            # logger(f'item: {repr(item)}')
            url_params = {'title': title, 'url': url}
            if "18+" not in title: ch_list.append(url_params)
            if do_adult and "18+" in title: ch_list.append(url_params)
        except: logger(f'item: {repr(item)} error: {print_exc()}')
    # logger(f'ch_list: {ch_list}')
    return ch_list

def relv_daddy(link):
    def get_currenturl(link, strmid):
        UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
        url = f'{ddurl}{link}'
        hea = {'Referer': f'{ddurl}/', 'User-Agent': UA}
        resp = request(url, headers=hea)# resp = requests.post(url, headers=hea).text
        # logger(f'play provider url: {url}\nresp1: {resp}')
        urla = re.compile(r'iframe src="(.*?)"').findall(resp)[0]
        hea = {'Referer': url, 'User-Agent': UA, }
        resp = request(urla, headers=hea, timeout=10)# resp = requests.post(urla, headers=hea, timeout=10).text
        # logger(f'play provider urla: {urla}\nresp2: {resp}')
        urlb = get_link(resp)
        if not urlb:
            ddl_alt_p = 'webhdrus.onlinehdhls.ru'
            if strmid.startswith('s2watch_'):
                ch_id = strmid.replace('s2watch_', '')
                urlb = f'https://{ddl_alt_p}/lb/{ch_id}/playlist.m3u8'
            elif strmid.startswith('maxsport_'):
                ch_id = strmid.replace('maxsport_', '')
                urlb = f'https://{ddl_alt_p}/lb/prima{ch_id}/playlist.m3u8'
            if strmid.isdigit():
                ch_id_digit_length = len(strmid)
                if ch_id_digit_length > 5:
                    urlb = f'https://{ddl_alt_p}/lb/bet{strmid}/playlist.m3u8'
                elif ch_id_digit_length == 4:
                    ch_id = strmid[-2:]  #last 2 chars of ch_id
                    ch_id = str(int(ch_id))  #remove leading zero of ch_id
                    urlb = f'https://{ddl_alt_p}/lb/wikiten{ch_id}/playlist.m3u8'
                else:
                    urlb = f'https://{ddl_alt_p}/lb/premium{strmid}/playlist.m3u8'
        parsed_url = urlparse(urla)
        referer = f'{parsed_url.scheme}://{(parsed_url.netloc or parsed_url.path)}'
        referer = quote_plus(referer)
        # urla = urla.replace('id='+ch_id, 'id={}')
        # urlb = urlb.replace(strmid+'/index', '{}/index')
        return f'{urlb}|Referer={referer}/&Origin={referer}&Keep-Alive=true&User-Agent={quote_plus(UA)}'

    strmid = link.split('stream-')[1].replace('.php', '') # re.findall(r'.*?(\d+)\.php', link)[0]
    # ddurls = get_currenturl(link, strmid)
    ddurls = cache_object(get_currenturl, f'content_ddurls{strmid}', [link, strmid], False, 3)
    logger(f'relv_daddy for link: {link} strmid: {strmid} from cache ddurls: {ddurls}')
    return ddurls


def ch_tvapp():
    url = f'{tvappurl}/tv'
    hea = {'User-Agent': UA, }
    resp = request(url, headers=hea, verify=False)
    # logger(f'resp: {resp}')
    html = parseDOM(resp, 'ol', attrs={'class': "list.*?"})[0]#.replace('<span>', '').replace('</span>', '').replace('\n', '').replace('  ', '').replace('@', ' @')
    chan_data = re.findall(r'href\s*=\s*"([^"]+)"\s*class.*?>([^<]+)<\/a>', html, re.DOTALL)

    ch_list = []
    for url, title in chan_data:
        try:
            url = url[:-1] if url.endswith('/') else url
            url = url.replace('/tv/', '')
            # href = f'https://thetvapp.to{url}' if url.startswith('/') else url
            if any(x in title for x in chnnel_filter): continue
            # logger(f'item: {repr(item)}')
            url_params = {'title': title.replace('&amp;', '&'), 'url': url}
            ch_list.append(url_params)
        except: logger(f'chan_data: {repr(chan_data)} error: {print_exc()}')
    # logger(f'ch_list: {ch_list}')
    return ch_list


def relv_theapp(id_):
    stream_url = ''
    header.update({'Origin': 'https://thetvapp.to', 'Referer': 'https://thetvapp.to/',})
    response = get_page_server(f'{tvappurl}/tv/{id_}/', '.col-lg-8', 'thetvapp')
    # logger(f'response: {repr(response)}')
    if not response:
        response = get_page_server(f'{tvappurl}/tv/{id_}/', '#loadVideoBtnOne', 'thetvapp')
    if 'source' in response:
        link = eval(response)
        if link: return f'{link["source"]}|{urlencode(header)}'
    return stream_url




def geetm_root(params):
    cache_name = 'content_geetmala'
    list_data = main_cache.get(cache_name)
    # logger(f'from cache list_data: {list_data}')
    if not list_data:
        uri = f'{get_git_url()}/geetmala.json'
        data = request(uri)
        list_data = eval(str(data))
        # list_data = json.loads(data)
        # logger(f'new list_data: {list_data}')
        if list_data: main_cache.set(cache_name, list_data, expiration=168) # 7days

    from sys import argv
    handle = int(argv[1])
    is_external = external()
    add_items(handle, list(get_list_item(list_data, 'youtube_r', True)))
    set_content(handle, 'tvshows')
    set_category(handle, 'tvshows')
    end_directory(handle, cacheToDisc=not is_external)
    set_view_mode('view.tvshows', 'tvshows', is_external)


def get_song_list(params):
    ourl = params['url']
    rescrape = params.get('rescrape', 'false')
    if ourl.endswith('value=') or ourl == 'YouTube':
        search_text = get_SearchQuery('Hindi Geetmala')
        ourl += quote_plus(search_text)

    cache_name = f'content_{urlencode(params)}'
    song_list = None
    if rescrape == 'true': main_cache.delete(cache_name)
    else: song_list = main_cache.get(cache_name)
    if not song_list:
        if ourl.startswith('YouTube'):
            song_list = Movie_search().search(search_text, [])
        else: song_list = make_song_list(params)
        if song_list:
            main_cache.set(cache_name, song_list, expiration=24)  # 1 days cache

    # logger(f'get_song_list item_list: {list(_process())}')
    from sys import argv
    handle = int(argv[1])
    is_external = external()
    if ourl.startswith('YouTube'):
        add_items(handle, list(get_list_item(song_list, 'youtube')))
        set_content(handle, 'videos')
        set_category(handle, 'videos')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.videos', 'videos', is_external)
    else:
        add_items(handle, list(get_list_item(song_list, 'youtube', True)))
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle, cacheToDisc=not is_external)
        set_view_mode('view.episodes', 'episodes', is_external)


def get_SearchQuery(sitename):
    import xbmc
    keyboard = xbmc.Keyboard()
    keyboard.setHeading(f'Search {sitename}')
    keyboard.doModal()
    return keyboard.getText() if keyboard.isConfirmed() else ''


def make_song_list(params):
    url, rtitle, pg_no = params['url'], params.get('title', ''), params.get('pg_no', '1')
    base_link = 'https://www.hindigeetmala.net'
    find_data = re.compile(r'itemprop="name">(.+?)</span>')
    song_perpage = 25
    songs = []
    nextpg = True
    while len(songs) < song_perpage and nextpg:
        song_page = request(url)
        result = parseDOM(song_page, 'tr', attrs={'itemprop': 'track'})
        for item in result:
            try:
                title = parseDOM(item, 'span', attrs={'itemprop': 'name'})[0]
                vid_url = parseDOM(item, 'a', ret='href')[0]
                img = parseDOM(item, 'img', ret='src')[0]
                try:
                    album = parseDOM(item, 'span', attrs={'itemprop': 'inAlbum'})[0]
                    m_name = find_data.findall(album)[0]
                    m_year = re.findall(r'\(.+?\)', album, re.MULTILINE)
                    m_year = m_year[0].replace('(', '').replace(')', '') if m_year else ''
                    album = f'{m_name} - {m_year}'
                except: album = ''
                try:
                    artist = parseDOM(item, 'span', attrs={'itemprop': 'byArtist'})[0]
                    artist = find_data.findall(artist)[0]
                except: artist = ''
                songs.append({'title': title, 'pg_no': pg_no, 'mode': 'geetm_vid_list', 'album': album, 'plot': f'album: {album}\nArtist: {artist}', 'url': base_link + vid_url, 'poster': base_link + img, 'isfolder': True})
            except: pass
        if nextpg:
            # logger(f'get_yt_vid_links pg_no {type(pg_no)} {repr(pg_no)}')
            pg_no = int(pg_no) + 1
            if '?page=' not in url: url += f'?page={pg_no}'
            else:
                url = url.split('=')[0]
                url += f'={pg_no}'
        else: nextpg = False

    if nextpg:
        xname = re.sub(r'Next Page: \d{1,2}', '', rtitle)
        title = f'{xname} Next Page: {pg_no}'
        next_pg_dict = {'title': title, 'pg_no': str(pg_no), 'mode': 'geetm_list', 'plot': 'Go To Next Page....', 'url': url, 'poster': nextpage, 'isfolder': True}
        songs.append(next_pg_dict)
    # logger('totle from url: %s pg_no: %s song: %s \n %s' % (params['url'], pg_no, len(songs), songs))
    return songs


def get_yt_vid_links(params):
    # logger(f'get_yt_vid_links params {params}')
    title, url, album, thumb = params.get('title'), params.get('url'), params.get('album'), params.get('poster')
    vid_page = request(url)
    # logger(f'search vid_page {vid_page}')
    result = parseDOM(vid_page, 'table', attrs={'class': 'b1 w760 alcen'})
    result += parseDOM(vid_page, 'table', attrs={'class': 'b1 allef w100p'})
    choices = []
    # logger(f'result: {result}')
    choice_param = {'title': f'Song : {title}', 'mode': 'geetm_plvid', 'poster': thumb, }
    try:
        link = parseDOM(result, 'iframe', ret='src')[0]
        if 'youtube.com/embed' in link:
            if v_id := link.replace('https://www.youtube.com/embed/', '').strip():
                v_link = f'{play_youtube_url}={v_id}'
                choices.append(dict(choice_param, **{'url': v_link}))
    except:
        for item in result:
            if r := re.findall(r'''<lite-youtube.+?videoid="([^"]+)''', item, re.DOTALL):
                choices.append(dict(choice_param, **{'url': f'{play_youtube_url}={r[0]}'}))
        song_item = parseDOM(vid_page, 'div', attrs={'class': 'yt_nt'})
        # logger(f'song_item: {song_item}')
        results = parseDOM(song_item, 'a', attrs={'class': 'yt_nt'})
        # logger(f'results: {results}')
        for item in results:
            if v_id := item.replace('https://www.youtube.com/watch?v=', '').strip():
                v_link = f'{play_youtube_url}={v_id}'
                choices.append(dict(choice_param, **{'url': v_link}))

    links = parseDOM(result, 'tr')
    find_data = re.compile(r'<td>(.+?)</td>')
    found_movie = False
    for link in links:
        # logger(f'from Movie link: \n{link}\n>>>>>\n')
        td_data = find_data.findall(link)
        try:
            if 'Watch Full Movie:' in td_data[0]:
                movie_link = parseDOM(td_data[1], 'a', ret='href')
                # logger(f'movie links: {movie_link}')
                for link_item in movie_link:
                    v_id = link_item.replace('https://www.youtube.com/watch?v=', '').strip()
                    if v_link := f'{play_youtube_url}={v_id}':
                        found_movie = True
                        choices.append(dict(choice_param, **{'url': v_link, 'title': f'Movie: {album}'}))
        except: pass
    if not found_movie: choices = Movie_search().search(album, choices)
    return choices


def get_yt_links(params):
    string = f'content_geetm_yt_links_{urlencode(params)}'
    choices = main_cache.get(string)
    if not choices or params.get('rescrap') == 'true':
        # logger(f'get_yt_links url: {url}\ntitle: {title}\nAlbum: {album}')
        choices = get_yt_vid_links(params)
        if choices: main_cache.set(string, choices, expiration=24) # 1 day

    # logger(f'rescrap: {rescrap} choices {choices}')
    from sys import argv
    handle = int(argv[1])
    is_external = external()
    add_items(handle, list(get_list_item(choices, 'youtube')))
    set_content(handle, 'videos')
    set_category(handle, 'videos')
    end_directory(handle, cacheToDisc=not is_external)
    set_view_mode('view.videos', 'videos', is_external)


class Movie_search:
    def __init__(self):
        self.key = 'AIzaSyCjf8izIeXa1oFZo7_HeL0WgrOq1WF_I1k'
        self.search_link = f'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=15&q=%s&key={self.key}'

    def search(self, title, choices):
        try:
            query = f'{title} full|Full movie|Movie'
            query_url = self.search_link % quote_plus(query)
            # logger(f'query: {query}')
            # query_url += '&relevanceLanguage=en'
            headers = {'Accept': 'application/json'}
            response = request(query_url, headers=headers, output='json')# response = requests.get(query_url, headers=headers).json()
            # logger(f'search json response {response}')
            if error := response.get('error', []):
                message = error.get('message', [])
                logger(f'message: {message}')
                return None

            json_items = response.get('items', [])
            # logger(f'search json_items {json_items} json_items {to_utf8(json_items)}')
            for search_result in json_items:
                try:
                    query = title.split('-')[0].lower().replace('.', '')
                    item_title = normalize(search_result['snippet']['title'].replace('.', ''))
                    if re.search(r'Full Movie|Movie', item_title, re.I) and re.search(query, item_title, re.I) and search_result['id']['kind'] == 'youtube#video':
                        vid_id = search_result['id']['videoId']
                        payload = {'id': vid_id, 'part': 'contentDetails', 'key': self.key}
                        url = f'https://www.googleapis.com/youtube/v3/videos/?&{urlencode(payload)}'
                        resp_dict = request(url, headers=headers, output='json') # resp_dict = requests.get(url, headers=headers).json()
                        # resp_dict = self.session.get('https://www.googleapis.com/youtube/v3/videos', params=payload).json()
                        dur = resp_dict['items'][0]['contentDetails']['duration']
                        duration = convert_youtube_duration_to_minutes(dur)
                        # logger(f'dur: {dur} duration: {duration}')
                        if duration > 70:
                            v_link = f'{play_youtube_url}={vid_id}'
                            # logger(f'item_title: {item_title} v_link: {v_link}')
                            choices.append({'title': f'Movie: ({duration} minutes) {item_title}', 'mode': 'geetm_plvid', 'url': v_link})
                except: logger(f'Error: {print_exc()}')
        except: logger(f'Error: {print_exc()}')
        # logger(f'choices: {choices}')
        return choices


def schedule_json():
    hea = {'User-Agent': UA, 'referer': ddurl, }
    data = request(f'{ddurl}/schedule/schedule-generated.json', headers=hea, output='json', verify=False)
    data_key = list(data.keys())[0]
    # logger(f'datakey: {data_key}')
    try:
        data_extra = request(f'{ddurl}/schedule/schedule-extra-generated.json', headers=hea, output='json', verify=False)
        data_extra_key = list(data_extra.keys())[0]
        if data_extra_key == data_key:
            data_extra["EXTRA - " + data_extra_key] = data_extra[data_extra_key]
            del data_extra[data_extra_key]
        data.update(data_extra)
    except: pass
    try:
        data_php = request(f'{ddurl}/schedule/extra2-schedule.php', headers=hea, output='json', verify=False)
        data_php_key = list(data_php.keys())[0]
        if data_php_key == data_key:
            data_php["EXTRA2 - " + data_php_key] = data_php[data_php_key]
            del data_php[data_php_key]
        data.update(data_php)
    except: pass
    try:
        data_php = request(f'{ddurl}/schedule/extra2-schedule-2.php', headers=hea, output='json', verify=False)
        data_php_key = list(data_php.keys())[0]
        if data_php_key == data_key:
            data_php["EXTRA3 - "+data_php_key] = data_php[data_php_key]
            del data_php[data_php_key]
        data.update(data_php)
    except: pass
    return data


def hour_convert(a, b):
    return (a + b) % 24


def sched_date():
    # sched_data = cache_object(schedule_json, 'episodes_sched_date', [], False, 4)
    sched_data = schedule_json()
    data = []
    for key, value in sched_data.items():
        # logger(f'key: {key}')
        date_data = value
        for ikey, ivalue in date_data.items():
            events = json.dumps(ivalue)
            data.append({'title': ikey, 'isfolder': True, 'mode': 'jsonlist', 'jsonevent': events})
    return data


def dd_events_get(params):
    event_data = json.loads(params['jsonevent'])
    ###sorting workaround###
    for i, ev in enumerate(event_data):
        if int(ev.get('time').split(':')[0]) >= 4: event_data[i]["nextdate"] = "0"
        else: event_data[i]["nextdate"] = "1"
    event_data = sorted(event_data, key=lambda d: (d.get('nextdate'), d.get('time')))

    timefix = -4 # EST
    from sys import argv
    import xbmcplugin, xbmcgui
    handle = int(argv[1])
    for item in event_data:
        # logger(f'item: {item}')
        try:
            time_ = item.get('time', '00:00')
            hour = int(time_.split(':')[0])
            new_hour = hour_convert(hour, timefix)
            new_hour = str(new_hour).zfill(2) + ':' + time_.split(':')[1]
            event_ = item.get('event', ' ')
            channels_ = item.get('channels', [])
            channels_.extend(item.get('channels2', []))
            title_ = '[COLOR yellow]' + new_hour + '[/COLOR]' + ' ' + event_
            # logger(f'title_: {title_} len(channels_) :{len(channels_)} channels_: {channels_}')
            for i in channels_:
                title = title_ + ' ' + i.get('channel_name')
                # logger(f'title: {title}')
                tr = i.get("channel_id")
                if tr.isdigit(): iurl = f'/stream/stream-{tr}.php'
                else: iurl = tr if tr.startswith('/') else f'/{tr}'
                li = xbmcgui.ListItem(title)
                li.setProperty("IsPlayable", 'true')
                url_stream = build_url({'mode': 'ltp_play', 'title': title, 'provider': 'ddevent', 'url': iurl})
                isfolder = False
                xbmcplugin.addDirectoryItem(handle=handle, url=url_stream, listitem=li, isFolder=isfolder)
        except: logger(f'error: {print_exc()}'); continue
    xbmcplugin.endOfDirectory(handle)
