# -*- coding: utf-8 -*-
from caches.main_cache import main_cache
from indexers.people import person_search
from modules import kodi_utils
# logger = kodi_utils.logger

json, close_all_dialog, external = kodi_utils.json, kodi_utils.close_all_dialog, kodi_utils.external
build_url, dialog, unquote, execute_builtin, select_dialog = kodi_utils.build_url, kodi_utils.dialog, kodi_utils.unquote, kodi_utils.execute_builtin, kodi_utils.select_dialog
notification, kodi_refresh, numeric_input = kodi_utils.notification, kodi_utils.kodi_refresh, kodi_utils.numeric_input
clear_history_list = [('Delete Movie Search History', 'movie_queries'),
					('Delete TV Show Search History', 'tvshow_queries'),
					('Delete People Search History', 'people_queries'),
					('Delete Keywords Movie Search History', 'keyword_tmdb_movie_queries'),
					('Delete Keywords TV Show Search History', 'keyword_tmdb_tvshow_queries'),
					('Delete Easynews Search History', 'easynews_video_queries'),
					('Delete Movie Sets Search History', 'tmdb_movie_sets_queries')]

def get_query(params):
	close_all_dialog()
	params_query = params.get('query', None)
	query = params_query or dialog.input('')
	if not query: return
	query = unquote(query)
	media_type = params.get('media_type', '')
	search_type = params.get('search_type', 'media_title')
	string = None
	if search_type == 'media_title':
		mode, action, string = ('build_movie_list', 'tmdb_movies_search', 'movie_queries') if media_type == 'movie' else ('build_tvshow_list', 'tmdb_tv_search', 'tvshow_queries')
		url_params = {'mode': mode, 'action': action}
	elif search_type == 'people': string = 'people_queries'
	elif search_type == 'tmdb_keyword':
		url_params, string = {'mode': 'navigator.keyword_results', 'media_type': media_type}, 'keyword_tmdb_%s_queries' % media_type
	elif search_type == 'easynews_video':
		url_params, string = {'mode': 'easynews.search_easynews'}, 'easynews_video_queries'
	elif search_type == 'tmdb_movie_sets':
		url_params, string = {'mode': 'build_movie_list', 'action': 'tmdb_movies_search_sets'}, 'tmdb_movie_sets_queries'
	elif search_type == 'trakt_lists':
		url_params, string = {'mode': 'trakt.list.search_trakt_lists'}, ''
	if string: add_to_search(query, string)
	if search_type == 'people': return person_search(query)
	url_params['query'] = query
	url_params['name'] = 'Search Results for %s' % query
	action = 'ActivateWindow(Videos,%s,return)' if external() else 'Container.Update(%s)'
	return execute_builtin(action % build_url(url_params))

def add_to_search(search_name, search_list):
	try:
		result = cache if (cache := main_cache.get(search_list)) else []
		if search_name in result: result.remove(search_name)
		result.insert(0, search_name)
		result = result[:50]
		main_cache.set(search_list, result, expiration=365)
	except: return

def remove_from_search(params):
	try:
		result = main_cache.get(params['setting_id'])
		result.remove(params.get('query'))
		main_cache.set(params['setting_id'], result, expiration=365)
		notification('Success', 2500)
		kodi_refresh()
	except: return

def clear_search():
	try:
		list_items = [{'line1': item[0]} for item in clear_history_list]
		kwargs = {'items': json.dumps(list_items), 'narrow_window': 'true'}
		setting_id = select_dialog([item[1] for item in clear_history_list], **kwargs)
		if setting_id is None: return
		clear_all(setting_id)
	except: return

def clear_all(setting_id, refresh='false'):
	main_cache.set(setting_id, '', expiration=365)
	notification('Success', 2500)
	if refresh == 'true': kodi_refresh()
