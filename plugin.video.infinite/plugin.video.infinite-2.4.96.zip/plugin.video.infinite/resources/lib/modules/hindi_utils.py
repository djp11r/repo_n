# -*- coding: utf-8 -*-
import datetime
import json
import re

from traceback import print_exc
from urllib.parse import quote_plus

try:
    from caches.h_cache import metacache
    from modules.kodi_utils import logger, nextpage
    from openscrapers.modules.client import request, agent
    from openscrapers.modules.source_utils import get_host
    from openscrapers.modules.scrape_sources import process, prepare_link
    # from openscrapers.modules import pyaes
except:
    import os, sys

    file = os.path.realpath(__file__)
    sys.path.append(os.path.join(os.path.dirname(file), 'modules'))
    from modules.h_cache import metacache
    from modules.utils import logger
    from modules.client import request, agent
    from modules.source_utils import get_host
    from modules.scrape_sources import process, prepare_link
    # from modules import pyaes
    nextpage = ''

from modules.dom_parser import parseDOM
from modules.utils import replace_html_codes

# exctract_date = re.compile(r'(?:\d{1,2}[-/th|st|nd|rd\s]*)?(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)?[a-z\s,.]*(?:\d{1,2}[-/th|st|nd|rd)\s,]*)+(?:\d{2,4})+')
# month_comp = re.compile(r'[Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|August|Sep|September|Oct|October|Nov|November|Dec|December]')
exctract_date = re.compile(r'(\d{1,2}[th|st|nd|rd]* [Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|August|Sep|September|Oct|October|Nov|November|Dec|December]* \d{2,4})', flags=re.I)
exctract_episod = re.compile(r'Episode \d{1,2}', flags=re.I)
season_data = re.compile(r'[sS]eason.+?(\d+)|[sS]eason(\d+)|[sS](\d+)', flags=re.I)
episode_cleaner = re.compile(r'Watch Online|Video Episode Update Online|-', flags=re.I)
episode_data = re.compile(r'[Ee]pisodes.+?(\d+)|[Ee]p (\d+)|[Ee](\d+)', flags=re.I)
ansi_pattern = re.compile(r'(\x9B|\x1B\[)[0-?]*[ -\/]*[@-~]', flags=re.I)
ansi_pattern1 = re.compile(r'[^\x00-\x7f]', flags=re.I)


def metacache_set(mediatype, meta):
    if mediatype == 'movie': metacache.set('movie', 'tmdb_id', meta)
    else: metacache.set('tvshow', 'tmdb_id', meta)


def gettmdb_id(mediatype, title, year, studio):
    return f'{title.lower()}|{year}' if mediatype == 'movie' else f'{studio}|{title.lower()}'


def fetch_meta(mediatype, title, tmdb_id, homepage, season=1, studio='Hindi', poster='hindi_movies.png', plot='', genre=None, year=2022, cast=None, imdb_id='', rating=5.0):
    if genre is None: genre = []
    if cast is None: cast = []
    meta = metacache.get(mediatype, 'tmdb_id', tmdb_id)
    # logger(f'fetch_meta meta: {meta}')
    if meta is None:
        if not plot and re.search('desi-serials|playdesi', str(homepage), re.I):
            plot, rating, genre = get_plot_tvshow(homepage, genre)
        meta = populet_dict(mediatype=mediatype, title=title, season=season, homepage=homepage, studio=studio, poster=poster, tmdb_id=tmdb_id, imdb_id=imdb_id, plot=plot, genre=genre, year=year, cast=cast, rating=rating)
        if imdbdata := get_datajson_imdb(meta):
            logger(f'imdb_id imdbdata: {imdbdata}')
            meta = meta_merge_update(meta, imdbdata)
        metacache_set(mediatype, meta)
    return meta


def meta_merge_update(meta, imdbdata):
    # logger(f'meta_merge_update meta: {meta}\n imdbdata: {imdbdata}')
    try:
        if isinstance(meta['genre'], list) and isinstance(imdbdata['genre'], list):
            genre = meta['genre'] + imdbdata['genre']
            if len(genre) > 0: genre = generes_unify(genre, meta['mediatype'])
            meta.update({'genre': genre})
    except: logger(f'meta_merge_update Error: {print_exc()}')
    if meta['plot'] == '' and imdbdata['plot'] != '': meta.update({'plot': imdbdata['plot']})
    if 'hindi_' in meta['poster'] and imdbdata['poster'] != '': meta.update({'poster': imdbdata['poster']})
    if imdbdata['duration']: meta.update({'duration': imdbdata['duration']})
    if imdbdata['mpaa']: meta.update({'mpaa': imdbdata['mpaa']})
    if imdbdata['imdb_id']: meta.update({'imdb_id': imdbdata['imdb_id']})
    if imdbdata['year']: meta.update({'year': imdbdata['year']})
    if imdbdata['rating']: meta.update({'rating': float(imdbdata['rating'])})
    if imdbdata['episodes'] != 0: meta.update({'episodes': imdbdata['episodes']})
    if imdbdata['seasons'] != 0: meta.update({'seasons': imdbdata['seasons'], 'season': imdbdata['seasons']})
    return meta


def generes_unify(genres, mediatype):
    fgenre = []
    if isinstance(genres, str):
        genre = replace_html_codes(genres)
        genres = genre.split(',')
    for genr in genres:
        genr = genr.replace('<span data-sheets-value="{"1"', '').replace('–', '-').replace('-', '-').replace('.', '')
        genr = replace_html_codes(genr)
        fgenre.append(genr.strip())
    # logger(f'IN genre: {genre} plot: {plot}')
    if not fgenre:
        fgenre = ['Movie'] if mediatype == 'movie' else ['TV']
    if fgenre: fgenre = list(set(fgenre))  #remove duplicate items from list
    return fgenre


def populet_dict(mediatype, title, season, homepage, studio, poster, tmdb_id, imdb_id, plot, genre, year, cast, rating):
    """
    :useges
    meta = populet_dict(mediatype='movie', title=title, year=year, studio=ch_name, plot='', fanart=imgurl, genre='', tvshowtitle=None, imdb_id=imdb)
    :return: dict
    """
    if imdb_id == '': imdb_id = tmdb_id
    try:
        if 'addons\\plugin.video.infinite' in poster:
            poster = f'special://home/addons/{poster.split("addons")[1]}'
            poster = poster.replace('\\', '/')
    except: logger(f'homepath not found: {print_exc()}')
    if cast is None: cast = [{'role': '', 'name': '', 'thumbnail': ''}]
    if not rating: rating = 4
    plot = replace_html_codes(plot)
    plot = plot.replace('\\n', ' ').replace('\\u2009', ' ').replace("\\'", "'").replace('\\r', '').strip()
    if isinstance(studio, str): studio = studio.split(',')
    if not genre: genre = []
    fgenre = generes_unify(genre, mediatype)  #remove duplicate items from list
    dic_meta = {'mediatype': mediatype, 'year': year, 'plot': plot, 'title': title, 'studio': studio, 'poster': poster, 'homepage': homepage, 'genre': fgenre, 'cast': cast, 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'rating': rating, 'clearlogo': '', 'trailer': '', 'votes': 50, 'tagline': '', 'director': [], 'writer': [], 'episodes': 0, 'seasons': 0, 'extra_info': {'status': '', 'collection_id': ''}}
    if mediatype == 'movie': dic_meta.update({'tvdb_id': 'None', 'duration': 5400, 'mpaa': 'R'})
    else: dic_meta.update({'tvdb_id': imdb_id, 'duration': 1320, 'mpaa': 'TV-MA', 'season': season, 'episodes': 2, 'seasons': season, 'episode': 1, 'tvshowtitle': title})
    return dic_meta


def clean_title_for_imdb_search(title):
    title = keepclean_title(title)
    title = re.sub(season_data, '', title)  # remove [Ss]eason 12 or [sS]1 etc
    title = re.sub(r'(\d+)', '', title)
    return title.strip()


def clean_poster_url(poster):
    if '/nopicture/' in poster: poster = '0'
    poster = re.sub(r'(?:_SX|_SY|_UX|_UY|_CR|_AL)(?:\d+|_).+?\.', '_SX500.', poster)
    if poster := replace_html_codes(poster): return poster


def seach_omdbapi(title, meta):
    year = meta['year']
    dType = 'movie' if meta['mediatype'] == 'movie' else 'series'
    api_url = f'http://www.omdbapi.com/?apikey=dd7e2fc7&s={quote_plus(title)}'
    # logger(f'url: {api_url}')
    result = request(api_url)
    item_meta = json.loads(result)
    # logger(f'result: {item_meta}')
    if not item_meta.get('Search'): return meta
    for item in item_meta.get('Search'):
        otitle = item['Title']
        if title.lower() in otitle.lower() and item['Type'] == dType:
            id_year = item['Year']
            id_year = re.sub(r'[^\x00-\x7f]', r'-', id_year)  # remove all non-ASCII characters
            if '-' in id_year: id_year = id_year.split('-')[0]
            if item.get('Year'): meta['year'] = id_year
            if item.get('imdbID'): meta['imdb_id'] = item['imdbID']
            if item.get('Poster'): meta['poster'] = item['Poster']
            # logger(f'item: {item}')
            break
    return meta


def get_datajson_imdb(metadict):
    oimdb_id = metadict['imdb_id']
    title = clean_title_for_imdb_search(metadict['title'])
    if not oimdb_id.startswith('tt'): metadict = seach_omdbapi(title, metadict)
    oimdb_id = metadict['imdb_id']
    if oimdb_id.startswith('tt'):
        url = f'https://www.imdb.com/title/{oimdb_id}/'
        result = request(url)
        if rter_metadict := imdb_json_parser(title, result, metadict):
            return rter_metadict
    if metadict['mediatype'] == 'movie': url = f'https://www.imdb.com/search/title/?title={quote_plus(title)}&title_type=feature,tv_movie&countries=in'
    else: url = f'https://www.imdb.com/search/title/?title={quote_plus(title)}&title_type=tv_series,tv_episode,tv_miniseries&countries=in'
    # url = f'https://www.imdb.com/find/?q={quote_plus(title)}&s=tt&exact=true
    logger(f'for : {title} checking url: {url}')
    result = request(url)
    # result = read_write_file(file_n='www.imdb.com.html')
    return imdb_html_parser(title, result, metadict)


def imdb_json_parser(title, result, metadict):
    try:
        scripts = parseDOM(result, 'script', attrs={'id': '__NEXT_DATA__'})
        item_meta = json.loads(scripts[0])
        item_meta1 = item_meta['props']['pageProps']['aboveTheFoldData']
        # logger(f'item_meta1: {item_meta1}')
        try:
            if year := item_meta1['releaseYear']['year']:
                metadict.update({'year': year})
        except: pass
        try:
            if rating := item_meta1['ratingsSummary']['aggregateRating']:
                metadict.update({'rating': float(rating)})
        except: pass
        try:
            rgen = item_meta1['genres']['genres']
            if genres := [str(x['text']) for x in rgen if x != '']:
                metadict.update({'genre': genres})
            plot = item_meta1['plot']['plotText']['plainText']
            if plot := span_clening(plot):
                metadict.update({'plot': plot})
        except: pass
        try:
            if certf := item_meta1['certificate']['rating']:
                if certf in ('Not Rated', 'Passed'): certf = 'R'
                metadict.update({'mpaa': certf})
        except: pass
        item_meta2 = item_meta['props']['pageProps']['mainColumnData']
        # logger(f'item_meta2: {item_meta2}')
        try:
            if runtime := item_meta2['runtime']['seconds']:
                metadict.update({'duration': runtime})
        except: pass
        try:
            if poster := item_meta2['titleMainImages']['edges'][0]['node']['url']:
                metadict.update({'poster': clean_poster_url(poster)})
        except: pass
        try:
            if seasons := item_meta2['episodes']['seasons'][-1]:
                metadict.update({'seasons': int(seasons.get('number', 1))})
            if episodes := item_meta2['episodes']['episodes']['total']:
                metadict.update({'episodes': int(episodes)})
        except: pass
        if ctitle := item_meta1['titleText']['text']:
            if re.search(title, str(ctitle), re.I): metadict.update({'title': keepclean_title(ctitle)})
    except:
        return
    # logger(f'imdb_json_parser metadict: {metadict}')
    return metadict


def imdb_html_parser(title, result, metadict):
    try:
        items = parseDOM(result, 'div', attrs={'class': 'lister-item mode-advanced'})
        for item in items:
            # logger(f'items: {item}')
            header = parseDOM(item, 'h3', attrs={'class': 'lister-item-header'})
            fheader = parseDOM(header, 'a')
            found_title = clean_title_for_imdb_search(fheader[0])
            # logger(f'title: {repr(title)} foun_title: {repr(found_title)}')
            if re.search(title, str(found_title), re.I):
                href = parseDOM(header, 'a', ret='href')
                if imdb_id := re.search(r'(tt\d*)', str(href)).group():
                    # logger(f'herf: {imdb_id}')
                    metadict['imdb_id'] = imdb_id
                    url = f'https://www.imdb.com/title/{imdb_id}/'
                    result = request(url)
                    if rter_metadict := imdb_json_parser(title, result, metadict):
                        return rter_metadict
                uitem = item
                # logger(f'item: {item}')
                break
        try:
            year_wrapper = parseDOM(uitem, 'span', attrs={'class': 'lister-item-year text-muted unbold'})
            # logger(f'year_wrapper: {year_wrapper}')
            try: year = re.search(r'\d{4}', year_wrapper).group()
            except: year = 2023
            # logger(f'year: {year}')
            if year: metadict.update({'year': year})
        except: pass
        try:
            poster = parseDOM(uitem, 'img', attrs={'class': 'loadlate'}, ret='loadlate')[0]
            # logger(f'poster: {poster}')
            if poster := clean_poster_url(poster):
                # logger(f'poster: {poster}')
                metadict.update({'poster': poster})
        except: pass
        try:
            # genresplot_wrapper = parseDOM(items, 'div', attrs={'class': '.+?GenresAndPlot__ContentParent.+?'})
            # logger(f'Total: {len(genresplot_wrapper)} duration_wrapper: {genresplot_wrapper}')
            genres_wrapper = parseDOM(uitem, 'span', attrs={'class': 'genre'})
            # logger(f'genres_wrapper: {genres_wrapper}')
            if genre := [item.replace('<span class="ipc-chip__text" role="presentation">', '').replace('</span>', '').strip() for item in genres_wrapper if item]:
                # logger(f'genre: {genre}')
                if genre: metadict.update({'genre': genre})
        except: pass
        try:
            plot_wrapper = parseDOM(items, 'p', attrs={'class': 'text-muted'})
            # logger(f'plot_wrapper: {plot_wrapper}')
            # plot = parseDOM(plot_wrapper, 'a')
            if plot := span_clening(plot_wrapper[0]):
                # logger(f'plot: {plot}')
                metadict.update({'plot': plot})
        except: pass
        try:
            rating_wrapper = parseDOM(uitem, 'span', attrs={'class': 'rating-rating.+?'})
            # logger(f'rating_wrapper: {rating_wrapper}')
            if rating := parseDOM(rating_wrapper, 'span', attrs={'class': 'value'}, )[0]:
                # logger(f'rating: {rating}')
                metadict.update({'rating': float(rating)})
        except: pass
    except: logger(f'Error: {print_exc()}')
    # logger(f'imdb_html_parser metadict: {metadict}')
    return metadict


def get_sec_string(str_time):
    ''' Convert 'D days, HH:MM:SS.FFF' to seconds'''
    min_str = re.compile(r'(\d+)[m|min]')
    hrs_str = re.compile(r'(\d+)h')
    hrs_s = min_s = 0
    hrs_s = re.findall(hrs_str, str_time)
    if hrs_s: hrs_s = int(hrs_s[0]) * 60 * 60
    min_s = re.findall(min_str, str_time)
    if min_s: min_s = int(min_s[0]) * 60
    return hrs_s + min_s


def span_clening(span_text):
    span_text = span_text.rsplit('<span>', 1)[0].strip()
    span_text = re.sub('<.+?>|</.+?>', '', span_text)
    # if '...' in span_text: span_text = span_text.split('...')[0]
    span_text.strip().replace('\xa0', ' ').replace('See all certifications', '').replace('See full summary', '')
    if 'add a plot' not in span_text.lower():
        span_text = replace_html_codes(span_text)
        span_text.strip().replace('\\n', '')
    else: span_text = ''
    return span_text


def get_plot_tvshow(show_url=None, genre=None):
    episo_page = request(show_url)
    # episo_page = read_write_file(file_n='www.desi-serials.cc.html')
    # logger(f'episo_page: {episo_page}')
    result1 = parseDOM(episo_page, 'div', attrs={'class': 'main-content col-lg-9'})
    result1 += parseDOM(episo_page, 'div', attrs={'class': 'blog-posts posts-large posts-container'})
    # logger(f'result1: {result1}')
    plot = ''
    genres = []
    rating = 5.0

    result = parseDOM(result1, 'div', attrs={'id': 'content'})
    # logger(f'result: {result[0]}')
    p = parseDOM(result, 'div', attrs={'class': 'page-content'})
    if p := parseDOM(p, 'div', attrs={'class': 'page-content'}):
        title_overview = re.findall(r'<p>(.+?)</p>', str(p))
        # logger(f'title_overview: {title_overview}')
        try: plot = title_overview[0].replace('<br/><br/>', '').replace('\\n', '').strip()
        except: pass
        try:
            rest_ofp = title_overview[1].replace('<br/><br/>', '').replace('\\n', '').strip()
            # logger(f'rest_ofp: {rest_ofp}')
            rating = re.findall(r'Show Rating: </span>\s+(.+?)/.+? <p>', rest_ofp)[0]
            genres = re.findall(r'Genre: </span>\s+(.+?)$', rest_ofp)  #[0]
            # logger(f'rating: {rating}, genre: {genres}')
        except: pass
    else:
        try: plot = re.findall(r'loading="lazy" \/><\/div>(.*?)<p>.+?<span', str(result), re.M)[0].strip()
        except: pass
        try:
            genres = re.findall(r'<span.+?font-weight:bold">(.+?)<\/span>', str(result), re.M)  #[0]
        except: pass
    for item in genres:
        if 'on:' in item: item = item.split(':')[1].strip()
        if item: genre.append(item)
    # logger(f'genre: {genre} plot: {plot}')
    plot = replace_html_codes(plot)
    # plot = f'{genre}\n{plot}'
    return plot, rating, genre


def get_episode_date(name, title=''):
    # logger(f'ep_name In: {name}')
    episode_name = xname = ''
    xname = re.sub(episode_cleaner, '', name)
    xname = xname.replace(title, '').replace('  ', ' ')
    try:
        episode_name = exctract_date.findall(xname)[0]
        episode_name = re.sub(r'(\w)([A-Z])', r'\1 \2', episode_name)
    except: episode_name = exctract_episod.findall(xname)
    if isinstance(episode_name, list):
        try: episode_name = episode_name[0]
        except: episode_name = ''
    if episode_name == '': episode_name = re.sub(r'(\w)([A-Z])', r'\1 \2', xname)
    # logger(f'ep_name Out: {episode_name}')
    # episode_name = episode_name.title()
    return episode_name.strip()


monthdict = {'January': '01', 'February': '02', 'March': '03', 'April': '04', 'May': '05', 'June': '06', 'July': '07', 'August': '08', 'September': '09', 'October': '10', 'November': '11', 'December': '12'}


def get_int_epi(episode):
    if episode_int := re.search(r'(\d{1,2}(st|nd|rd|th))(.*?)(\d{2,4})', episode):
        episode_int = episode_int.group()
        month = monthdict.get(episode_int.split(' ')[1])
        try:
            d = re.search(r'^\d+(st|nd|rd|th)', episode).group()
            day = re.sub(r'(st|nd|rd|th)', '', d)
            day = day.rjust(2, '0')
            # day = re.search(r'\d{2}', episode).group()
            year = re.search(r'\d{4}$', episode).group()
        except: day, year = '0', '0'
        season = day if month is None else f'{month}{day}'
        # logger(f'{season}, {year}')
        return season, year
    else:
        epis_no = re.search(r'\d{1,2}', episode)
        epis_no = epis_no.group() if epis_no else 0
        # logger(f'day: {epis_no}')
        return epis_no, 0


def find_season_in_title(release_title):
    match = 1
    release_title = re.sub(r'\d{4}', '', release_title)  # remove year from title
    regex_list = [r'.+?(\d{1,2})', r'[sS]eason.+?(\d+)', r'[sS]eason(\d+)', r'[sS](\d+)', r'[cC]hapter.+?(\d+)']
    for item in regex_list:
        match = re.search(item, release_title)
        if match:
            try: match = int(str(match[1]).lstrip('0'))
            except: pass
            break
        else: match = 1
        # logger(f'not match: {item}')
    return match


def string_date_to_num(string):
    # logger(f'string: {string} ')
    # date_str = re.search(r'(\d{1,2}(st|nd|rd|th))(.*?)(\d{2,4})', string).group()
    if date_str := re.search(exctract_date, string):
        date_str = date_str.group()
        month = monthdict.get(date_str.split(' ')[1])
        d = re.search(r'^\d+(st|nd|rd|th)', date_str).group()
        day = re.sub('(st|nd|rd|th)', '', d)
        year = re.search(r'\d{4}$', date_str).group()
        return f'{year}-{month:0>2}-{day:0>2}'
    else: return '2023-01-01'


def additional_title_cleaner(title):
    title = title.replace('&lt;', '<').replace('&gt;', '>').replace('&#38;', '&').replace('&nbsp;', '').replace('&#8211;', '-').replace('&#8217;', '\'').replace('&#8230;', ' ')
    title = title.replace('...', '').replace('---', '-').replace("'", '').replace('’', '').replace(':', '')
    return title


def keepclean_title(title, episod=False):
    if title is None: return
    try:
        if cl_title := re.search("(?=.*\d).0", title): title = title.replace('.0', '')
        if ':' in title: title = title.replace(':', ' ')
        if not episod:
            title = re.sub(exctract_date, '', title)  # remove date like 18th April 2021
            title = re.sub(episode_data, '', title)  # remove episod 12 or [Ee]p 1 etc
        # title = re.sub(season_data, '', title)  # remove [Ss]eason 12 or [sS]1 etc
        title = re.sub(ansi_pattern, '', title)  # remove ansi_pattern
        title = re.sub(ansi_pattern1, '', title)  # remove ansi_pattern
        title = re.sub(r'&#(\d+);', '', title)
        title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
        title = title.replace('&quot;', '\'').replace('&amp;', '&')
        title = re.sub(r'([:;\-"\',!_.?~$@])', '', title)  # remove all characters in bracket
        title = re.sub(r'\<[^>]*\>|\([^>]*\)', '', title) # remove like this <anything> or (any thing)
        # title = re.sub(r'\([^>]*\)', '', title)  # remove in bracket like (anything) etc
        # title = re.sub(r'\n|([[].+?[]])|([(].+?[)])|\s(vs|v[.])\s|(:|;|-|"|,|\'|\_|\.|\?)|\(|\)|\[|\]|\{|\}|\s', '', title).lower()
        # title = re.sub(r'\n|([\[({].+?[})\]])|([:;\-"\',!_.?~$@])|\s', '', title)
        title = additional_title_cleaner(title)
        title = title.replace('-', '')
        title = re.sub(r'\s+', ' ', title) # remove Multiple Spaces
        return title.strip()
    except: return title.strip()


def convert_time_str_to_seconds(timestr):
    if re.findall(r'\d{1,2}:\d{2}:\d{2}', timestr): timestr = timestr
    elif re.findall(r'\d{2}:\d{2}', timestr): timestr = f'00:{timestr}'
    ftr = [3600, 60, 1]
    return sum(a * b for a, b in zip(ftr, map(int, timestr.split(':'))))


def _get_timefrom_timestamp(timestamp):
    from datetime import datetime
    return datetime.utcfromtimestamp(timestamp)


def convert_youtube_duration_to_minutes(duration):
    """
    :param duration:
    convert_YouTube_duration_to_minits('P2DT1S')
    172801
    convert_YouTube_duration_to_minits('PT2H12M51S')
    7971
    :return:
    """
    day_time = duration.split('T')
    day_duration = day_time[0].replace('P', '')
    day_list = day_duration.split('D')
    hour = minute = second = day = 0
    if len(day_list) == 2: day = int(day_list[0]) * 60 * 60 * 24  # day_list = day_list[1]
    hour_list = day_time[1].split('H')
    if len(hour_list) == 2:
        hour = int(hour_list[0]) * 60 * 60
        hour_list = hour_list[1]
    else: hour_list = hour_list[0]
    minute_list = hour_list.split('M')
    if len(minute_list) == 2:
        minute = int(minute_list[0]) * 60
        minute_list = minute_list[1]
    else: minute_list = minute_list[0]
    second_list = minute_list.split('S')
    if len(second_list) == 2: second = int(second_list[0])
    minutes = (day + hour + minute + second) / 60
    return int(minutes)


def ordinal(integer):
    int_to_string = str(integer)
    # log(f'{int_to_string}st')
    if int_to_string in {'1', '-1'}: return f'{int_to_string}st'
    elif int_to_string in {'2', '-2'}: return f'{int_to_string}nd'
    elif int_to_string in {'3', '-3'}: return f'{int_to_string}rd'
    elif int_to_string[-1] == '1' and int_to_string[-2] != '1': return f'{int_to_string}st'
    elif int_to_string[-1] == '2' and int_to_string[-2] != '1': return f'{int_to_string}nd'
    elif int_to_string[-1] == '3' and int_to_string[-2] != '1': return f'{int_to_string}rd'
    else: return f'{int_to_string}th'


def get_hind_next_episod(meta):
    e_name = meta['ep_name']
    if 'Episode' in e_name:
        e_name = int(e_name.replace('Episode', ''))
        n_ep_name = f'Episode {e_name + 1}'
        meta.update({'ep_name': n_ep_name, 'episode': e_name + 1})
    else:
        e_name = e_name.replace(' ', '-').lower()
        premiered = meta['premiered']
        current_episode = datetime.datetime.strptime(premiered, "%Y-%m-%d")
        # calculating end date by adding 1 days
        Enddate = current_episode + datetime.timedelta(days=1)
        day = Enddate.strftime('%d').lstrip('0')
        month = Enddate.strftime('%m')
        year = Enddate.strftime('%Y')
        n_premiered = f'{year}-{month}-{day}'
        n_episode = f'{month.lstrip("0")}{day}'
        day = ordinal(day)
        mont = Enddate.strftime('%B')
        n_ep_name = f'{day} {mont} {year}'
        next_ep_name = n_ep_name.replace(' ', '-').lower()
        url = meta['url']
        url = url.replace(e_name, next_ep_name)
        meta.update({'ep_name': n_ep_name, 'episode': n_episode, 'premiered': n_premiered, 'url': url})
    # logger(f'updated meta: {repr(meta)}')
    return meta


def string_escape(s, encoding='utf-8'):
    return s.encode('latin1', 'backslashreplace').decode('unicode-escape')
