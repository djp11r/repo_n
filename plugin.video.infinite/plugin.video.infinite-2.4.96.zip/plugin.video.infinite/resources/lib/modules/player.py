# -*- coding: utf-8 -*-
import re
from apis.trakt_api import make_trakt_slug
from caches.settings_cache import get_setting
from modules import kodi_utils as ku, settings as st, watched_status as ws
logger = ku.logger
from traceback import print_exc
from windows.base_window import open_window
from apis.opensubtitles_api import OpenSubtitlesAPI
set_info, set_inputstream, execute_JSON, path_join = ku.set_info, ku.set_inputstream, ku.execute_JSON, ku.path_join

set_property, clear_property, get_visibility, hide_busy_dialog, xbmc_actor = ku.set_property, ku.clear_property, ku.get_visibility, ku.hide_busy_dialog, ku.xbmc_actor
Thread, json, xbmc_player, execute_builtin, sleep = ku.Thread, ku.json, ku.xbmc_player, ku.execute_builtin, ku.sleep
make_listitem, volume_checker, get_infolabel = ku.make_listitem, ku.volume_checker, ku.get_infolabel
close_all_dialog, notification, poster_empty, fanart_empty = ku.close_all_dialog, ku.notification, ku.empty_poster, ku.get_addon_fanart()
watched_indicators, auto_resume, auto_nextep_settings = st.watched_indicators, st.auto_resume, st.auto_nextep_settings
clear_local_bookmarks, set_bookmark, mark_movie, mark_episode = ws.clear_local_bookmarks, ws.set_bookmark, ws.mark_movie, ws.mark_episode
total_time_errors = ('0.0', '', 0.0, None)
convert_language, translate_path, list_dirs, select_dialog = ku.convert_language, ku.translate_path, ku.list_dirs, ku.select_dialog
playback_settings, get_sub_settings = st.playback_settings, st.get_sub_settings
video_fullscreen_check = 'Window.IsActive(fullscreenvideo)'

class infinitePlayer(xbmc_player):
	def __init__(self):
		xbmc_player.__init__(self)

	def run(self, url=None, obj=None, info=None):
		hide_busy_dialog()
		self.clear_playback_properties()
		self.info = info or {'title': ''}
		if not url: return self.run_error()
		try: return self.play_video(url, obj)
		except: return self.run_error()

	def play_video(self, url, obj):
		self.set_constants(url, obj)
		volume_checker()
		self.play(self.url, self.make_listing())
		if not self.is_generic:
			self.check_playback_start()
			if self.playback_successful: self.monitor()
			else:
				self.sources_object.playback_successful = self.playback_successful
				self.sources_object.cancel_all_playback = self.cancel_all_playback
				if self.cancel_all_playback: self.kill_dialog()
				self.stop()
			try: del self.kodi_monitor
			except: pass

	def check_playback_start(self):
		if isinstance(self.sources_object, str): self.playback_successful = True; return
		resolve_percent = 0
		while self.playback_successful is None:
			hide_busy_dialog()
			if not self.sources_object.progress_dialog: self.playback_successful = True
			elif self.sources_object.progress_dialog.skip_resolved(): self.playback_successful = False
			elif self.sources_object.progress_dialog.iscanceled() or self.kodi_monitor.abortRequested(): self.cancel_all_playback, self.playback_successful = True, False
			elif resolve_percent >= 100: self.playback_successful = False
			elif get_visibility('Window.IsTopMost(okdialog)'):
				execute_builtin('SendClick(okdialog, 11)')
				self.playback_successful = False
			elif self.isPlayingVideo():
				try:
					if self.getTotalTime() not in total_time_errors and get_visibility(video_fullscreen_check): self.playback_successful = True
				except: pass
			resolve_percent = round(resolve_percent + 26.0/100, 1)
			self.sources_object.progress_dialog.update_resolver(percent=round(resolve_percent, 2))
			sleep(100)

	def playback_close_dialogs(self):
		try: self.sources_object.playback_successful = True
		except: self.playback_successful = True
		self.kill_dialog()
		sleep(200)
		close_all_dialog()

	def monitor(self):
		try:
			ensure_dialog_dead, total_check_time = False, 0
			play_random_continual, self.autoplay_nextep, self.autoscrape_nextep, play_random = False, False, False, False
			if self.media_type == 'episode':
				try:
					play_random_continual = self.sources_object.random_continual
					play_random = self.sources_object.random
					disable_autoplay_next_episode = self.sources_object.disable_autoplay_next_episode
					if disable_autoplay_next_episode: notification('Scrape with Custom Values - Autoplay Next Episode Cancelled', 4500)
					if any((play_random_continual, play_random, disable_autoplay_next_episode)): self.autoplay_nextep, self.autoscrape_nextep = False, False
					else: self.autoplay_nextep, self.autoscrape_nextep = self.sources_object.autoplay_nextep, self.sources_object.autoscrape_nextep
				except: play_random_continual, self.autoplay_nextep, self.autoscrape_nextep = False, False, False
			while total_check_time <= 30 and not get_visibility(video_fullscreen_check):
				sleep(250)
				total_check_time += 0.25
			hide_busy_dialog()
			sleep(1000)
			while self.isPlayingVideo():
				try:
					try: self.total_time, self.curr_time = self.getTotalTime(), self.getTime()
					except: sleep(500); continue
					if not ensure_dialog_dead:
						ensure_dialog_dead = True
						self.playback_close_dialogs()
					sleep(1000)
					#if not self.resume_set and self.playback_percent > 0 and self.total_time: self.set_resume_playback()
					if not self.subs_searched: self.run_subtitles()
					self.current_point = round(float(self.curr_time/self.total_time * 100), 1)
					if self.multi_part_source and self.curr_time <= 50:
						self.set_watched, self.multi_part_source = 30, False
					# logger(f'monitor self.media_marked: {self.media_marked} self.current_point: {self.current_point} set_watched: {self.set_watched} self.total_time: {self.total_time}')
					if self.current_point >= self.set_watched:
						if play_random_continual: self.run_random_continual(); break
						if not self.media_marked: self.media_watched_marker()
					if not self.intro_skip and self.skip_start_time <= self.curr_time <= self.skip_end_time:
						# logger(f'monitor intro_skip: {self.intro_skip} self.curr_time: {self.curr_time} self.total_time: {self.total_time}')
						if self.intro_skip_win < 4: self._make_intro_skip(self.skip_end_time, self.skip_style)
					# logger(f'monitor self.autoplay_next_episode: {self.autoplay_next_episode} self.total_time: {self.total_time}')
					if self.autoplay_nextep or self.autoscrape_nextep:
						if not self.nextep_info_gathered: self.info_next_ep()
						# logger(f'monitor round(self.total_time - self.curr_time): {round(self.total_time - self.curr_time)} self.start_prep: {self.start_prep}')
						if round(self.total_time - self.curr_time) <= self.start_prep: self.run_next_ep(); break
					if not self.autoplay_nextep and round(self.total_time - self.curr_time) <= self.skip_end_time*1.1:
						self._make_intro_skip(self.total_time)
				except: pass#logger(f'2monitor Error: {print_exc()}')
			hide_busy_dialog()
			if not self.media_marked: self.media_watched_marker()
			self.clear_playback_properties()
			clear_local_bookmarks()
		except:
			logger(f'1monitor Error: {print_exc()}')
			hide_busy_dialog()
			try: self.sources_object.playback_successful. self.sources_object.cancel_all_playback = False, True
			except: self.playback_successful, self.cancel_all_playback = False, True
			return self.kill_dialog()

	def make_listing(self):
		listitem = make_listitem()
		listitem.setPath(self.url)
		listitem.setContentLookup(False)
		# listitem = set_inputstream(self.url, listitem)
		if self.is_generic:
			info_tag = listitem.getVideoInfoTag()
			info_tag.setMediaType('video')
			info_tag.setTitle(str(self.info.get('title') or ''))
			info_tag.setFilenameAndPath(self.url)
		else:
			# logger(f'infinitePlayer make_listing self.meta: {self.meta}')
			try:
				self.tmdb_id, self.imdb_id, self.tvdb_id = self.meta_get('tmdb_id', ''), self.meta_get('imdb_id', ''), self.meta_get('tvdb_id', '')
				self.media_type, self.title, self.year = self.meta_get('media_type') or self.meta_get('mediatype'), self.meta_get('title'), self.meta_get('year')
				self.season, self.episode = self.meta_get('season', ''), self.meta_get('episode', '')
				self.auto_resume = auto_resume(self.media_type)
				poster = self.meta_get('poster') or poster_empty
				fanart = self.meta_get('fanart') or fanart_empty
				clearlogo = self.meta_get('clearlogo') or ''
				duration, plot, genre, trailer, mpaa = self.meta_get('duration'), self.meta_get('plot'), self.meta_get('genre'), self.meta_get('trailer', ''), self.meta_get('mpaa', 'MA')
				rating, votes, premiered, studio, tagline = self.meta_get('rating', 0.1), self.meta_get('votes', 1), self.meta_get('premiered', '1/1/2023'), self.meta_get('studio', []), self.meta_get('tagline', '')
				self.multi_part_source = ' , ' in self.url
				self.skip_option, self.skip_style = self.meta_get('skip_option'), self.meta_get('skip_style')
				self.skip_time, self.skip_start_time = int(self.skip_option.get('skip')), int(self.skip_option.get('start'))
				self.skip_end_time = self.skip_start_time + self.skip_time + int(self.skip_option.get('eskip'))
				infoLabels = {'trailer': trailer, 'size': '0', 'duration': duration, 'plot': plot, 'imdbnumber': self.imdb_id, 'year': self.year, 'genre': genre, 'rating': rating, 'votes': votes, 'premiered': premiered, 'studio': studio}
				listitem.setLabel(self.title)
				if self.media_type == 'movie':
					#listitem.setArt({'poster': poster, 'fanart': fanart, 'icon': poster, 'clearlogo': clearlogo})
					setUniqueIDs = {'imdb': self.imdb_id, 'tmdb': str(self.tmdb_id)}
					movie = {'mediatype': 'movie', 'title': self.title, 'tagline': self.meta_get('tagline'), 'code': self.imdb_id, 'director': self.meta_get('director'), 'writer': self.meta_get('writer')}
					infoLabels = dict(infoLabels, **movie)
				else:
					listitem.setArt({'tvshow.poster': poster, 'tvshow.clearlogo': clearlogo})
					tv = {'mediatype': 'episode', 'title': self.meta_get('ep_name', self.title), 'tvshowtitle': self.meta_get('tvshowtitle'), 'season': self.season, 'episode': self.episode, 'FileNameAndPath': self.url}
					infoLabels = dict(infoLabels, **tv)
					setUniqueIDs = {'imdb': self.imdb_id, 'tmdb': str(self.tmdb_id), 'tvdb': str(self.tvdb_id)}
				#logger(f'infinitePlayer make_listing infoLabels: {infoLabels}')
				listitem = set_info(listitem, infoLabels, setUniqueIDs)
				listitem.setArt({'poster': poster, 'fanart': fanart, 'icon': poster, 'clearlogo': clearlogo})
			except: logger(f'make_listing Error: {print_exc()}')
			self.set_resume_point(listitem)
			self.set_playback_properties()
		return listitem

	def media_watched_marker(self, force_watched=False):
		self.media_marked = True
		try:
			if self.current_point >= self.set_watched or force_watched:
				watched_function = mark_movie if self.media_type == 'movie' else mark_episode
				watched_params = {'action': 'mark_as_watched', 'tmdb_id': self.tmdb_id, 'title': self.title, 'year': self.year, 'season': self.season, 'episode': self.episode,
									'tvdb_id': self.tvdb_id, 'from_playback': 'true', 'imdb_id': self.imdb_id}
				# logger(f'media_watched_marker watched_params: {watched_params}')
				Thread(target=self.run_media_progress, args=(watched_function, watched_params)).start()
			else:
				clear_property('infinite.random_episode_history')
				if self.current_point >= self.set_resume:
					progress_params = {'media_type': self.media_type, 'tmdb_id': self.tmdb_id, 'curr_time': round(self.curr_time, 2), 'total_time': self.total_time,
									'title': self.title, 'season': self.season, 'episode': self.episode, 'from_playback': 'true'}
					# logger(f'media_watched_marker progress_params: {progress_params}')
					Thread(target=self.run_media_progress, args=(set_bookmark, progress_params)).start()
		except: logger(f'media_watched_marker Error: {print_exc()}')

	def run_media_progress(self, function, params):
		try: function(params)
		except: logger(f'run_media_progress Error: {print_exc()}')

	def run_next_ep(self):
		# logger(f'run_next_ep self.curr_time: {self.curr_time} self.total_time: {self.total_time} self.start_prep: {self.start_prep} self.nextep_settings: {self.nextep_settings}')
		from modules.episode_tools import EpisodeTools
		if not self.media_marked: self.media_watched_marker(force_watched=True)
		EpisodeTools(self.meta, self.nextep_settings).auto_nextep()

	def run_random_continual(self):
		from modules.episode_tools import EpisodeTools
		if not self.media_marked: self.media_watched_marker(force_watched=True)
		EpisodeTools(self.meta).play_random_continual(False)

	def set_resume_point(self, listitem):
		if self.playback_percent > 0.0: listitem.setProperty('StartPercent', str(self.playback_percent))

	def info_next_ep(self):
		self.nextep_info_gathered = True
		try:
			play_type = 'autoplay_nextep' if self.autoplay_nextep else 'autoscrape_nextep'
			nextep_settings = auto_nextep_settings(play_type)
			final_chapter = self.final_chapter() if nextep_settings['use_chapters'] else None
			percentage = 100 - final_chapter if final_chapter else nextep_settings['window_percentage']
			window_time = round((percentage/100) * self.total_time)
			default_action = nextep_settings['default_action']
			self.start_prep = nextep_settings['scraper_time'] + window_time
			self.nextep_settings = {'window_time': window_time, 'default_action': default_action, 'play_type': play_type}
		except: pass

	def final_chapter(self):
		final_chapter = None
		try:
			final = float(get_infolabel('Player.Chapters').split(',')[-1])
			if final >= 90: final_chapter = final
		except: pass
		return final_chapter

	def kill_dialog(self):
		try: self.sources_object._kill_progress_dialog()
		except: close_all_dialog()

	def set_constants(self, url, obj):
		if url.startswith('Direct_'): obj, url = 'video', url.replace('Direct_', '')
		self.url = url
		self.sources_object = obj
		self.is_generic = self.sources_object == 'video'
		self.set_watched, self.set_resume = playback_settings()
		# logger(f'set_constants obj: {self.sources_object.__dict__}\nself.is_generic: {self.is_generic} url: {url}')
		if not self.is_generic:
			try:
				self.meta = json.loads(obj) if isinstance(obj, str) else self.sources_object.meta
			except: logger(f'set_constants Error: {print_exc()}\nobj: {obj} url: {url}')
			self.meta_get, self.kodi_monitor = self.meta.get, ku.monitor
			try: self.playback_percent = self.sources_object.playback_percent
			except: self.playback_percent = self.meta_get('playback_percent') or 0.0
			try: self.playing_filename = self.sources_object.playing_filename
			except: self.playing_filename = self.meta_get('disply_name')
			if isinstance(obj, str):
				try: self.playback_percent = float(self.meta_get('playback_percent'))
				except: self.playback_percent = 0.0
			# logger(f'self.playing_filename: {self.playing_filename} self.playback_percent: {self.playback_percent} self.monitor_playback: {self.monitor_playback} \nurl: {url}\nself.meta type: {type(self.meta)} self.meta: {self.meta}')
			self.media_marked, self.nextep_info_gathered = False, False
			self.playback_successful, self.cancel_all_playback = None, False
			self.resume_set, self.intro_skip, self.subs_searched, self.intro_skip_win = False, False, False, 0

	def set_playback_properties(self):
		try:
			trakt_ids = {'tmdb': self.tmdb_id, 'imdb': self.imdb_id, 'slug': make_trakt_slug(self.title)}
			if self.media_type == 'episode': trakt_ids['tvdb'] = self.tvdb_id
			set_property('script.trakt.ids', json.dumps(trakt_ids))
			if self.playing_filename: set_property('subs.player_filename', self.playing_filename)
		except: pass

	def clear_playback_properties(self):
		clear_property('infinite.window_stack')
		clear_property('script.trakt.ids')
		clear_property('subs.player_filename')

	def run_error(self):
		try: self.sources_object.playback_successful = False
		except: pass
		self.clear_playback_properties()
		notification('Playback Failed', 3500)
		return False

	def run_subtitles(self):
		self.subs_searched = True
		title = self.title if self.media_type == 'movie' else self.meta_get('tvshowtitle')
		try: Thread(target=Subtitles().get, args=(title, self.imdb_id, self.season or None, self.episode or None)).start()
		except: pass

	def _make_intro_skip(self, skip_end_time, window_style='end_skip'):
		# logger(f'_make_intro_skip skip_end_time: {skip_end_time} self.total_time: {self.total_time}')
		self.intro_skip_win += 1
		return open_window(('windows.skip', 'Skip'), 'skipmulti.xml', skip_end_time=skip_end_time, intro_skip_win=self.intro_skip_win, skip_option=self.skip_option, window_style=window_style)


class Subtitles(xbmc_player):
	def __init__(self):
		xbmc_player.__init__(self)
		self.os_api = OpenSubtitlesAPI()
		sub_settings = get_sub_settings()
		self.auto_enable = sub_settings['auto_enable']
		self.subs_action = sub_settings['subs_action']
		self.language = sub_settings['language']
		self.quality = ['bluray', 'hdrip', 'brrip', 'bdrip', 'dvdrip', 'webdl', 'webrip', 'webcap', 'web', 'hdtv', 'hdrip']
		self.audio_preference = sub_settings['audio_preference']
		self.secondary_language = sub_settings['secondary_language']

	def get(self, query, imdb_id, season, episode, secondary_search=False):
		def _notification(line, _time=3500):
			return notification(line, _time)

		def _video_file_subs():
			try: available_sub_language = self.getSubtitles()
			except: available_sub_language = ''
			if available_sub_language == self.language:
				if self.auto_enable == 'true': self.showSubtitles(True)
				_notification('Local Subtitles Found')
				return True
			return False

		def _downloaded_subs():
			files = list_dirs(subtitle_path)[1]
			if len(files) > 0:
				match_lang1 = None
				match_lang2 = None
				files = [i for i in files if i.endswith('.srt')]
				for item in files:
					if item == search_filename:
						match_lang1 = item
						break
				final_match = match_lang1 or match_lang2 or None
				if final_match:
					subtitle = path_join(subtitle_path, final_match)
					_notification('Downloaded Subtitles Found')
					return subtitle
			return False

		def _searched_subs():
			chosen_sub = None
			from os.path import basename
			result = self.os_api.search(query, imdb_id, self.language, season, episode)
			if not result or len(result) == 0: _notification('No Subtitles Found'); return False
			try: video_path = self.getPlayingFile()
			except: video_path = ''
			if '|' in video_path: video_path = video_path.split('|')[0]
			video_path = basename(video_path)
			if query.lower() not in video_path.lower():
				video_path = f'{query} S{season} E{episode}' if season else f'{query}'
			# logger(f'_searched_subs video_path: {video_path}')
			if self.subs_action == '2':
				self.pause()
				choices = [i for i in result if i['SubLanguageID'] == self.language and i['SubSumCD'] == '1']
				if not choices: return False
				dialog_list = [f'[B]{i["SubLanguageID"].upper()}[/B] | [I]{i["MovieReleaseName"]}[/I]' for i in choices]
				list_items = [{'line1': item} for item in dialog_list]
				kwargs = {'items': json.dumps(list_items), 'heading': video_path.replace('%20', ' '), 'enumerate': 'true', 'narrow_window': 'true'}
				chosen_sub = select_dialog(choices, **kwargs)
				self.pause()
				if not chosen_sub: return False
			else:
				try: chosen_sub = [i for i in result if i['MovieReleaseName'].lower() in video_path.lower() and i['SubLanguageID'] == self.language and i['SubSumCD'] == '1'][0]
				except: pass
				if not chosen_sub:
					fmt = re.split(r'\.|\(|\)|\[|\]|\s|\-', video_path)
					fmt = [i.lower() for i in fmt]
					fmt = [i for i in fmt if i in self.quality]
					if season and fmt == '': fmt = 'hdtv'
					result = [i for i in result if i['SubSumCD'] == '1']
					subfilter = [i for i in result if i['SubLanguageID'] == self.language and any(x in i['MovieReleaseName'].lower() for x in fmt) and any(x in i['MovieReleaseName'].lower() for x in self.quality)]
					chosen_sub = subfilter[0] if subfilter else result[0]
			try: lang = convert_language(chosen_sub['SubLanguageID'])
			except: lang = chosen_sub['SubLanguageID']
			sub_format = chosen_sub['SubFormat']
			final_filename = f'{sub_filename}_{lang}.{sub_format}'
			download_url = chosen_sub['ZipDownloadLink']
			temp_zip = path_join(subtitle_path, 'temp.zip')
			temp_path = path_join(subtitle_path, chosen_sub['SubFileName'])
			final_path = path_join(subtitle_path, final_filename)
			subtitle = self.os_api.download(download_url, subtitle_path, temp_zip, temp_path, final_path)
			sleep(1000)
			return subtitle

		if self.subs_action == '0': return
		if self.audio_preference: self.setAudioPrefs()
		sleep(2500)
		imdb_id = re.sub(r'[^0-9]', '', imdb_id)
		subtitle_path = translate_path('special://temp/')
		sub_filename = f'infiniteSubs_{imdb_id}_{season}_{episode}' if season else f'infiniteSubs_{imdb_id}'
		search_filename = f'{sub_filename}_{self.language}.srt'
		subtitle = _video_file_subs()
		if subtitle: return
		subtitle = _downloaded_subs()
		if subtitle: return self.setSubtitles(subtitle)
		subtitle = _searched_subs()
		if subtitle: return self.setSubtitles(subtitle)
		if secondary_search: return _notification('No Subtitles Found')
		if self.secondary_language in (self.language, None, 'None', ''): return _notification('No Subtitles Found')
		self.language = self.secondary_language
		self.get(query, imdb_id, season, episode, secondary_search=True)

	def setAudioPrefs(self):
		try:
			activePlayers = '{"jsonrpc": "2.0", "method": "Player.GetActivePlayers", "id": 1}'
			json_query = execute_JSON(activePlayers)
			json_response = json.loads(json_query)
			activePlayerID = json_response['result'][0]['playerid']
			details_query_dict = {"jsonrpc": "2.0", "method": "Player.GetProperties", "params": {"properties": ["currentaudiostream", "audiostreams", "subtitleenabled", "currentsubtitle", "subtitles"], "playerid": activePlayerID}, "id": 1}
			details_query_string = json.dumps(details_query_dict)
			json_query = execute_JSON(details_query_string)
			json_response = json.loads(json_query)

			if 'result' in json_response and json_response['result'] is not None:
				self.current_audio_stream = json_response['result']['currentaudiostream']
				self.audiostreams = json_response['result']['audiostreams']
				self.evalPrefs()
			# logger(f'json_response: {json_response}')
		except: logger(f'setAudioPrefs Error: {print_exc()}')

	def evalPrefs(self):
		# logger(f'evalPrefs self.audiostreams: {self.audiostreams}')
		try:
			audio_changed = False
			audio = self.evalFilenamePrefs()
			if (audio >= 0) and audio < len(self.audiostreams):
				# logger('Filename preference: Match, selecting audio track {0}'.format(audio))
				self.setAudioStream(audio)
				audio_changed = True
			# else: logger(f'Filename preference: No match found for audio: {audio} Filename: ({self.getPlayingFile()})')
			if not audio_changed:
				trackIndex = self.evalAudioPrefs(self.language)
				if trackIndex == -2: audio_changed = True
				elif trackIndex >= 0:
					logger(f'Audio:: Match found for audio track {trackIndex} languages: {self.language}')
					self.setAudioStream(trackIndex)
					audio_changed = True
		except: logger(f'evalPrefs Error: {print_exc()}')

	def evalFilenamePrefs(self):
		# logger('Evaluating filename preferences using regex')
		try:
			audio = -1
			filename = self.getPlayingFile()
			logger(f'evalFilenamePrefs filename: {filename}')
			reg = re.compile('audiostream[_|.|-]*\d+|subtitle[_|.|-]*\d+', re.I)
			split = re.compile(r'[_|.|-]*', re.I)
			matches = reg.findall(filename)
			fileprefs = []
			for m in matches:
				sp = split.split(m)
				fileprefs.append(sp)

			for pref in fileprefs:
				if len(pref) == 2 and pref[0].lower() == 'audiostream':
					audio = int(pref[1])
					logger(f'audio track extracted from filename: {audio}')
					return audio
			# logger(f'filename: audio: {audio}, filename: {filename})')
			return audio
		except: logger(f'evalFilenamePrefs Error: {print_exc()}')

	def evalAudioPrefs(self, audio_prefs):
		try:
			if audio_prefs is None: return -2
			if (self.current_audio_stream and 'language' in self.current_audio_stream) and audio_prefs == self.current_audio_stream['language']:
				# logger(f'current audio language {self.current_audio_stream["language"]}')
				return -2
			for stream in self.audiostreams:
				if audio_prefs == stream['language']:
					logger(f'Audio language of stream index {stream["index"]} language: {stream["language"]}')
					return stream['index']
			return -2
		except: logger(f'evalAudioPrefs Error: {print_exc()}')
