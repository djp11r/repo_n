# -*- coding: utf-8 -*-
"""
    Venom Add-on
"""

import json
import re
from traceback import print_exc
from urllib.parse import urlencode

import requests

try:
    from modules.kodi_utils import logger, build_url, addon_icon, notification, set_info, execute_builtin, addon_fanart, item_next, add_items, set_content, end_directory, set_view_mode, get_infolabel, make_listitem, set_category, external
    from caches.h_cache import main_cache
    from modules.player import infinitePlayer
except:
    import os, sys
    file = os.path.realpath(__file__)
    sys.path.append(os.path.join(os.path.dirname(file), 'modules'))
    from modules.h_cache import main_cache
    from modules.utils import logger

from modules.hindi_utils import request, keepclean_title
from modules.dom_parser import parseDOM

docu_link = 'https://topdocumentaryfilms.com/'
docu_cat_list = 'https://topdocumentaryfilms.com/watch-online/'


def _process(list_data):
    for item in list_data:
        get_item = item.get
        # logger(f'lists _process item: {item}')
        listitem = make_listitem()
        title, poster, action = get_item('title'), get_item('poster', ''), get_item('action', '')
        thumb = poster if poster.startswith('http') else addon_icon
        url_params = {'mode': action, 'title': title, 'url': item['url'], 'thumb': thumb}
        isfolder = action == 'docu_get_items'
        url = build_url(url_params)
        options_params = {'mode': 'options_menu_choice', 'suggestion': title, 'play_params': json.dumps(url_params)}
        cm = [('[B]Options...[/B]', f'RunPlugin({build_url(options_params)})')]
        listitem.setLabel(title)
        listitem.addContextMenuItems(cm)
        listitem.setArt({'thumb': thumb})
        item.update({'imdb_id': title, 'mediatype': 'episode', 'episode': 1, 'season': 0})
        listitem = set_info(listitem, item, {'imdb': str(title)})
        yield url, listitem, isfolder
    return


def doc_root(params):
    cache_name = f'content_docu_root_{urlencode(params)}'
    docu_data = main_cache.get(cache_name)
    if not docu_data:
        docu_data = get_root_items()
        if docu_data: main_cache.set(cache_name, docu_data, expiration=14)  # 14 days cache

    # docu_data = list(reversed(docu_data))
    # logger(f'total: {len(docu_data)} item_list: {docu_data}')
    from sys import argv
    handle = int(argv[1])
    if docu_data:
        is_external = external()
        add_items(handle, list(_process(docu_data)))
        set_content(handle, 'tvshows')
        set_category(handle, 'tvshows')
        end_directory(handle)
        set_view_mode('view.main', 'tvshows', is_external)
    else:
        notification('No items Found in doc_root.')
        end_directory(handle)
        return


def get_root_items():
    item_list = []
    html = request(docu_cat_list)
    # logger(f'html: {html}')
    cat_list = parseDOM(html, 'div', attrs={'class': 'sitemap-wraper'})
    # logger(f'total: {len(cat_list)} cat_list: {cat_list}')
    for content in cat_list:
        try:
            cat_info = parseDOM(content, 'h2')[0]
            # logger(f'cat_info: {cat_info}')
            cat_url = parseDOM(cat_info, 'a', ret='href')[0]
            # cat_title = parseDOM(cat_info, 'a')[0].encode('utf-8', 'ignore').decode('utf-8').replace('&amp;','&').replace('&#39;',''').replace('&quot;',''').replace('&#39;',''').replace('&#8211;',' - ').replace('&#8217;',''').replace('&#8216;',''').replace('&#038;','&').replace('&acirc;','')
            cat_title = keepclean_title(parseDOM(cat_info, 'a')[0])
            try: cat_icon = parseDOM(content, 'img', ret='data-src')[0]
            except:
                try: cat_icon = parseDOM(content, 'img', ret='src')[0]
                except: cat_icon = ''
            # cat_action = 'docuHeaven&docuCat=%s' % cat_url
            item_list.append({'title': cat_title, 'url': cat_url, 'poster': cat_icon, 'action': 'docu_get_items'})
        except: logger(f'root() Exception: {print_exc()}')
    return item_list


def docu_list(params):
    url, iconImage = params['url'], params['thumb']
    params = {'url': url, 'thumb': iconImage}
    cache_name = f'content_docu_items_{urlencode(params)}'
    docu_data = main_cache.get(cache_name)
    if not docu_data:
        docu_data = docu_list_items(url)
        if docu_data: main_cache.set(cache_name, docu_data, expiration=2)  # 14 days cache

    # docu_data = list(reversed(docu_data))
    # logger(f'total: {len(docu_data)} item_list: {docu_data}')
    from sys import argv
    handle = int(argv[1])
    if docu_data:
        is_external = external()
        add_items(handle, list(_process(docu_data)))
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle)
        set_view_mode('view.main', 'episodes', is_external)
    else:
        notification('No items Found in docu_list.')
        end_directory(handle)
        return


def docu_list_items(url):
    item_list = []
    try:
        html = request(url)
        # logger(f'html: {html}')
        cat_list = parseDOM(html, 'article', attrs={'class': 'module clearfix'})
        # logger(f'cat_list: {cat_list}')
        for content in cat_list:
            try:
                docu_info = parseDOM(content, 'h2')[0]
                # logger(f'docu_info: {docu_info}')
                docu_url = parseDOM(docu_info, 'a', ret='href')[0]
                docu_title = keepclean_title(parseDOM(docu_info, 'a')[0])
                try: docu_icon = parseDOM(content, 'img', ret='data-src')[0]
                except:
                    try: docu_icon = parseDOM(content, 'img', ret='src')[0]
                    except: docu_icon = ''
                # docu_action = 'docuHeaven&docuPlay=%s' % docu_url
                item_list.append({'title': docu_title, 'url': docu_url, 'poster': docu_icon, 'action': 'docu_pls'})
            except: logger(f'docu_list() url:: {url} Error {print_exc()}')
        try:
            navi_content = parseDOM(html, 'div', attrs={'class': 'pagination module'})[0]
            links = parseDOM(navi_content, 'a', ret='href')
            link = links[(len(links) - 1)]
            # docu_action = 'docuHeaven&docuCat=%s' % link
            item_list.append({'title': 'Next Page', 'url': link, 'poster': item_next, 'action': 'docu_get_items'})
        except: logger(f'docu_list() url:: {url} Error {print_exc()}')
    except: logger(f'docu_list() Exception: {print_exc()}')
    # self.addDirectory(self.list)
    # logger(f'total: {len(item_list)} item_list: {item_list}')
    return item_list


def docu_play(params):
    try:
        url = params['url']
        html = request(url)
        # logger(f'html: {html}')
        docu_item = parseDOM(html, 'meta', attrs={'itemprop': 'embedUrl'}, ret='content')[0]
        if 'http:' not in docu_item and 'https:' not in docu_item: docu_item = f'https:{docu_item}'
        url = docu_item
        # docu_title = parseDOM(docu_page, 'meta', attrs={'property':'og:title'}, ret='content')[0].encode('utf-8', 'ignore').decode('utf-8').replace('&amp;','&').replace('&#39;',''').replace('&quot;',''').replace('&#39;',''').replace('&#8211;',' - ').replace('&#8217;',''').replace('&#8216;',''').replace('&#038;','&').replace('&acirc;','')
        docu_title = keepclean_title(parseDOM(html, 'meta', attrs={'property': 'og:title'}, ret='content')[0])
        # logger(f'docu_title: {docu_title} url: {url}')
        if 'youtube' in url:
            if 'videoseries' not in url:
                try: video_id = parseDOM(html, 'div', attrs={'class': 'youtube-player'}, ret='data-id')[0]
                except: video_id = url.split('/')[-1]
                url = f'plugin://plugin.video.youtube/play/?video_id={video_id}'
        elif 'dailymotion' in url:
            video_id = parseDOM(html, 'div', attrs={'class': 'youtube-player'}, ret='data-id')[0]
            url = getDailyMotionStream(video_id)
        else:
            logger(f'Play Documentary: Unknown Host: url: {repr(url)}')
            url = check_hosted_media(url)
        logger(f'Play Documentary: docu_title: {docu_title} url: {repr(url)}')
        # execute_builtin(f'RunPlugin({url})')
        try: infinitePlayer().run(url, 'video', {'title': docu_title})
        except: logger(f'docu_play() docu_title:: {docu_title} Error {print_exc()}')
        # control.notification(message='Unknown Host - Report To Developer: ' + str(url)
        # control.execute('PlayMedia(%s)' % url)
        # item = xbmcgui.ListItem(str(docu_title), iconImage='DefaultVideo.png', thumbnailImage='DefaultVideo.png')
        # iconImage and thumb nailImage removed in Kodi Matrix
        # item.setInfo(type='video', infoLabels={'Title': str(docu_title), 'Plot': str(docu_title)})
        # item.setProperty('IsPlayable','true')
        # item.setPath(url)
        # control.resolve(int(sys.argv[1]), True, item)
    except: logger(f'docu_play() Exception: {print_exc()}')


def sort_key(elem):
    return 1 if elem[0] == 'auto' else int(elem[0].split('@')[0])


def check_hosted_media(vid_url):
    from modules.source_utils import HostedMediaFile
    hmf = HostedMediaFile(url=vid_url)
    if hmf.valid_url() is True:
        return hmf.resolve()
    return


# Code originally written by gujal, as part of the DailyMotion Addon in the official Kodi Repo. Modified to fit the needs here.
def getDailyMotionStream(vid_id):
    headers = {'User-Agent': 'Android'}
    cookie = {'Cookie': 'lang=en_US; ff=off'}
    r = requests.get(f'http://www.dailymotion.com/player/metadata/video/{vid_id}', headers=headers, cookies=cookie, )
    content = r.json()
    if content.get('error') is not None:
        Error = (content['error']['title'])
        logger(f'getDailyMotionStream() Error: {Error}')
        return  #xbmc.executebuiltin('XBMC.Notification(Info:,'+ Error +' ,5000)')
    else:
        cc = content['qualities']
        cc = cc.items()
        cc = sorted(cc, key=sort_key, reverse=True)
        m_url = ''
        other_playable_url = []
        for source, json_source in cc:
            source = source.split('@')[0]
            for item in json_source:
                if m_url := item.get('url', None):
                    if source == 'auto': continue
                    elif int(source) <= 2:
                        if 'video' in item.get('type', None): return m_url
                    elif '.mnft' in m_url: continue
                    other_playable_url.append(m_url)
        if other_playable_url:  # probably not needed, only for last resort
            for m_url in other_playable_url:
                if '.m3u8?auth' in m_url:
                    rr = requests.get(m_url, cookies=r.cookies.get_dict(), headers=headers)
                    if not rr.headers.get('set-cookie'):
                        return re.findall(r'(http.+)', rr.text)[0].split('#cell')[0]
                    logger('adding cookie to url')
                    return (re.findall(r'(http.+)', rr.text)[0].split('#cell')[0] + '|Cookie=' + rr.headers['set-cookie'])