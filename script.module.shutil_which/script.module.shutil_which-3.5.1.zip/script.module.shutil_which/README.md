script.module.shutil_which
==========================

shutil.which library repacked for Kodi

- https://github.com/back-to/script.module.shutil_which

Based on Backport Python 3 shutil.which

- https://docs.python.org/3/library/shutil.html#shutil.which
- https://github.com/minrk/backports.shutil_which
