# -*- coding: utf-8 -*-

import sys, time, datetime
from traceback import print_exc

import xbmc
from resources.lib.modules import control
from resources.lib.modules.control import setting as getSetting, setSetting, notification
from resources.lib.modules.log_utils import log, error
# from caches import clean_databases


def testting():
    test_window()


def test_window(win='progress_scrape'):
    window = None
    use_timer = True
    meta = {'tmdb_id': 21572, 'tvdb_id': 170491, 'imdb_id': 'tt1190931', 'rating': 8.4, 'plot': 'Case 1: The Imposter: Dr. Barnes For twenty years he was an imposter doctor! Dr. Gerald Barnes has a thriving practice specializing in "executive" medical exams. His salary is six-figures and life is good. But there\'s a problem: he\'s not the real Dr. Gerald Barnes. Case 2: Interstate Bank Mart Bandit He leaves no clues behind, only a trail of broken dreams and empty bank accounts. Forty-three robberies in 20 months. The M.O. is always the same. Police say it\'s the work of one man: "The Interstate Bank Mart Bandit!".', 'tagline': '', 'votes': 8, 'premiered': '2007-06-28', 'year': '2007', 'poster': 'https://image.tmdb.org/t/p/w185/bilmBb9Q4sLesr1gdMknSGfQQ7H.jpg', 'fanart': 'https://image.tmdb.org/t/p/w300/z7OINGcfImMIU4bg0EUrrycZWR6.jpg', 'genre': ['Documentary', 'Crime'], 'title': 'American Greed', 'original_title': 'American Greed', 'english_title': '', 'season_data': [{'air_date': '2009-09-09', 'episode_count': 3, 'id': 31339, 'name': 'Specials', 'overview': '', 'poster_path': None, 'season_number': 0}, {'air_date': '2007-06-21', 'episode_count': 6, 'id': 31335, 'name': 'Season 1', 'overview': '', 'poster_path': None, 'season_number': 1}, {'air_date': '2008-01-30', 'episode_count': 10, 'id': 31336, 'name': 'Season 2', 'overview': '', 'poster_path': None, 'season_number': 2}, {'air_date': '2009-01-07', 'episode_count': 8, 'id': 31337, 'name': 'Season 3', 'overview': '', 'poster_path': None, 'season_number': 3}, {'air_date': '2010-02-03', 'episode_count': 12, 'id': 31338, 'name': 'Season 4', 'overview': '', 'poster_path': None, 'season_number': 4}, {'air_date': '2011-01-19', 'episode_count': 14, 'id': 31340, 'name': 'Season 5', 'overview': '', 'poster_path': None, 'season_number': 5}, {'air_date': '2012-01-25', 'episode_count': 17, 'id': 31341, 'name': 'Season 6', 'overview': '', 'poster_path': None, 'season_number': 6}, {'air_date': '2013-02-22', 'episode_count': 13, 'id': 31342, 'name': 'Season 7', 'overview': '', 'poster_path': None, 'season_number': 7}, {'air_date': None, 'episode_count': 1, 'id': 83919, 'name': 'Season 8', 'overview': '', 'poster_path': None, 'season_number': 8}, {'air_date': '2015-01-15', 'episode_count': 6, 'id': 83918, 'name': 'Season 9', 'overview': '', 'poster_path': None, 'season_number': 9}, {'air_date': '2016-03-31', 'episode_count': 12, 'id': 79035, 'name': 'Season 10', 'overview': '', 'poster_path': None, 'season_number': 10}, {'air_date': '2017-01-23', 'episode_count': 5, 'id': 85896, 'name': 'Season 11', 'overview': '', 'poster_path': None, 'season_number': 11}, {'air_date': '2018-02-26', 'episode_count': 20, 'id': 100110, 'name': 'Season 12', 'overview': '', 'poster_path': None, 'season_number': 12}, {'air_date': '2019-08-12', 'episode_count': 16, 'id': 130186, 'name': 'Season 13', 'overview': '', 'poster_path': None, 'season_number': 13}, {'air_date': '2021-01-18', 'episode_count': 7, 'id': 166369, 'name': 'Season 14', 'overview': '', 'poster_path': '/lp4BWrPsfQUY0yTBBbkbdUJkfPm.jpg', 'season_number': 14}, {'air_date': '2021-06-27', 'episode_count': 6, 'id': 200545, 'name': 'Season 15', 'overview': '', 'poster_path': None, 'season_number': 15}], 'alternative_titles': [], 'duration': 2580, 'rootname': 'American Greed - 1x02', 'imdbnumber': 'tt1190931', 'country': [], 'mpaa': '', 'trailer': '', 'country_codes': [], 'writer': [], 'director': [], 'all_trailers': [], 'cast': [], 'studio': ['CNBC'], 'extra_info': {'status': 'Returning Series', 'type': 'Documentary', 'homepage': 'https://www.cnbc.com/american-greed/', 'created_by': 'N/A', 'next_episode_to_air': None, 'last_episode_to_air': {'air_date': '2021-07-12', 'episode_number': 6, 'id': 3071490, 'name': "A Father's Fraud", 'overview': 'Karl Karlsen is a hardworking man with what seems to be a terrible streak of bad luck, as his wife and son both die in accidents nearly 20 years apart; Karl has a secret: their suspicious deaths have been keeping his bank account full.', 'production_code': '', 'runtime': 43, 'season_number': 15, 'show_id': 21572, 'still_path': None, 'vote_average': 0.0, 'vote_count': 0}}, 'total_aired_eps': 153, 'mediatype': 'tvshow', 'total_seasons': 15, 'tvshowtitle': 'American Greed', 'status': 'Returning Series', 'clearlogo': '', 'images': {'backdrops': [{'file_path': '/hLA3vuKSOXmyu7DH804huzlgj9j.jpg'}, {'file_path': '/jqWjO8VDnX56zzBTQSZO0E3Aa7Z.jpg'}], 'logos': [], 'posters': [{'file_path': '/bilmBb9Q4sLesr1gdMknSGfQQ7H.jpg'}]}, 'changed_artwork': {}, 'poster2': '', 'fanart2': '', 'clearlogo2': '', 'banner': '', 'clearart': '', 'landscape': '', 'discart': '', 'keyart': '', 'fanart_added': True, 'media_type': 'episode', 'season': 1, 'episode': 2, 'episode_type': 'season_finale','ep_name': 'The Imposter: Dr. Barnes / Interstate Bank Mart Bandit', 'background': False, 'skip_option': {'title': 'American Greed', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '60'}, 'skip_style': 'netflix', 'url': 'stack://https://hls10x.vidfiles.net/videos/hls/Xfr7iZq8WhU_8biyCi66dw/1663270600/336669/c57c343c19862f3f143cb7c67efe60be/ep.1.v1.1655284255.m3u8|User-Agent=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%3B+rv%3A68.0%29+Gecko%2F20100101+Firefox%2F68.0&Referer=https%3A%2F%2Fmembed.net%2Floadserver.php%3Fid%3DMzM2NjY5', 'bookmark': 0}
    # meta = {'mediatype': 'episode', 'year': 2022, 'plot': 'The Kapil Sharma Show, also known as TKSS, is an Indian Hindi-language stand-up comedy and talk show broadcast by Sony Entertainment Television. Hosted by Kapil Sharma The series revolved around Sharma and his neighbours in the Shantivan Non Co-operative Housing Society.', 'title': 'The Kapil Sharma Show Season 4', 'studio': ['Sony'], 'poster': 'https://www.desi-serials.cc/wp-content/uploads/2022/08/The-Kapil-Sharma-Show-300x169.jpg', 'homepage': 'https://www.desi-serials.cc/watch-online/sony-tv/the-kapil-sharma-show-season-4/', 'genre': ['Saturday  Sunday.', 'Comedy', 'Talk-Show'], 'cast': [], 'tmdb_id': 'Sony|The Kapil Sharma Show Season 4', 'imdb_id': 'tt5747326', 'rating': 7.3, 'clearlogo': '', 'trailer': '', 'votes': 50, 'tagline': '', 'director': [], 'writer': [], 'episodes': 390, 'seasons': '1, 2, 3, 4', 'extra_info': {'status': '', 'collection_id': ''}, 'tvdb_id': 'Sony|the kapil sharma show', 'duration': 3600, 'mpaa': 'TV-MA', 'season': 4, 'episode': 910, 'tvshowtitle': 'The Kapil Sharma Show Season 4', 'playcount': 0, 'original_title': 'The Kapil Sharma Show Season 4', 'total_seasons': '4', 'url': 'https://www.desi-serials.cc/the-kapil-sharma-show-season-4-episode-10th-september-2022-watch-online/441968/', 'fanart': 'https://www.desi-serials.cc/wp-content/uploads/2022/08/The-Kapil-Sharma-Show-300x169.jpg', 'premiered': '2022-09-10', 'ep_name': '10th September 2022', 'overlay': 4, 'media_type': 'episode', 'background': False, 'skip_option': {'title': 'The Kapil Sharma Show', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '300'}, 'skip_style': 'netflix'}
    title = meta.get('title')
    year = meta.get('year')
    imdb = meta.get('imdb_id')
    tvdb =meta.get('tvdb_id')
    season =meta.get('season') 
    episode =meta.get('episode')
    tvshowtitle = meta.get('tvshowtitle')
    premiered = meta.get('premiered')
    if win == 'nextep_win': # windows.next_episode <<<<<<<<<
        from resources.lib.windows.playnext import PlayNextXML
        from resources.lib.windows.playnext_stillwatching import StillWatchingXML
        try:
            window = PlayNextXML('playnext.xml', control.addonPath(control.addonId()), meta=meta, test=True)
            # window = StillWatchingXML('auraplaynext_stillwatching2.xml', control.addonPath(control.addonId()), meta=meta, test=True)
            # window = StillWatchingXML('playnext_stillwatching.xml', control.addonPath(control.addonId()), meta=meta, test=True)
            # use_timer = False
        except: error()
    elif win == 'progress_scrape': # windows.progress_scrape <<<<<<<<<
        from resources.lib.windows.progress_scrape import ProgressScrape
        try: window = ProgressScrape('progress_scrape.xml', control.addonPath(control.addonId()), title=title, year=year, imdb=imdb, tvdb=tvdb, season=season, episode=episode, tvshowtitle=tvshowtitle, premiered=premiered, meta=meta, test=True)
        except: error()
    elif win == 'progress_resolve': # windows.progress_scrape <<<<<<<<<
        from resources.lib.windows.progress_resolve import ProgressResolve
        try: window = ProgressResolve('progress_resolve.xml', control.addonPath(control.addonId()), title=title, year=year, imdb=imdb, tvdb=tvdb, season=season, episode=episode, tvshowtitle=tvshowtitle, meta=meta, test=True)
        except: error()
    if window:
        try: window.run()
        except: error()
        # if use_timer:
        start_time = time.time()
        timeout = 100
        sleep_time = 10
        end_time = start_time + timeout
        try:
            while not window.iscanceled():
                if window.iscanceled():
                    window.close()
                    break
                try: progress_bar = window.getControlProgress(3014)
                except: progress_bar = None
                current_time = time.time()
                current_progress = current_time - start_time
                if win in ('progress_scrape', 'progress_resolve'): window.update(int(current_progress), 'Testings')
                else: window.update(int(current_progress), 'Testings')
                log(f'current_progress: {current_progress} progress_bar: {repr(progress_bar)}')
                if progress_bar is not None: progress_bar.setPercent(f'{current_progress:.2f}')
                time.sleep(10)
        except: log(f'error: {print_exc()}')
    try: del window
    except: error()
