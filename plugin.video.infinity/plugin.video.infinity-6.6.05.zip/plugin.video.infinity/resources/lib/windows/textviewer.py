# -*- coding: utf-8 -*-

from resources.lib.windows.base import BaseDialog
from resources.lib.modules.control import darkColor, setting as getSetting


class TextViewerXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.window_id = 2060
		self.heading = kwargs.get('heading', 'Infinity')
		self.text = kwargs.get('text')
		self.lightordark = getSetting('dialogs.lightordarkmode')
		self.buttonColor = getSetting('dialogs.button.color')
		self.customBackgroundColor = getSetting('dialogs.customcolor')
		self.dark_text_background = darkColor(self.customBackgroundColor)
		self.useCustomTitleColor = getSetting('dialogs.usecolortitle') == 'true'
		self.customTitleColor = getSetting('dialogs.titlebar.color')

	def onInit(self):
		self.set_properties()
		self.setFocusId(self.window_id)

	def run(self):
		self.doModal()
		self.clearProperties()

	def onAction(self, action):
		if action in self.closing_actions or action in self.selection_actions:
			self.close()

	def set_properties(self):
		self.setProperty('infinity.text', self.text)
		self.setProperty('infinity.heading', self.heading)
		self.setProperty('infinity.buttonColor', self.buttonColor)
		if self.useCustomTitleColor:
			#need to use a custom titlebar color
			self.setProperty('infinity.titleBarColor', self.customTitleColor)
			if darkColor(self.customTitleColor) == 'dark':
				self.setProperty('infinity.titleTextColor', 'FFF5F5F5')
			else:
				self.setProperty('infinity.titleTextColor', 'FF302F2F')
			self.setProperty('infinity.headertextcolor', self.customTitleColor)
		if darkColor(self.buttonColor) == 'dark':
			self.setProperty('infinity.buttonTextColor', 'FFF5F5F5')
		else:
			self.setProperty('infinity.buttonTextColor', 'FF302F2F')
		if self.lightordark == '0':
			self.setProperty('infinity.backgroundColor', 'FF302F2F') #setting dark grey for dark mode
			self.setProperty('infinity.textColor', 'FFF5F5F5')
			self.setProperty('infinity.buttonnofocus', 'FF302F2F')
			if not self.useCustomTitleColor:
				self.setProperty('infinity.headertextcolor', self.buttonColor)
				self.setProperty('infinity.titleBarColor', 'FF302F2F')
				self.setProperty('infinity.titleTextColor', 'FFF5F5F5')
			self.setProperty('infinity.buttonTextColorNS', 'FFF5F5F5')
		elif self.lightordark == '1':
			self.setProperty('infinity.backgroundColor', 'FFF5F5F5') #setting dirty white for light mode. (the hell you call me)
			self.setProperty('infinity.textColor', 'FF302F2F')
			self.setProperty('infinity.buttonnofocus', 'FFF5F5F5')
			if not self.useCustomTitleColor:
				self.setProperty('infinity.headertextcolor', self.buttonColor)
				self.setProperty('infinity.titleBarColor', 'FFF5F5F5')
				self.setProperty('infinity.titleTextColor', 'FF302F2F')
			self.setProperty('infinity.buttonTextColorNS', 'FF302F2F')
		elif self.lightordark == '2':
			#ohh now we need a custom color, aren't we just special.
			self.setProperty('infinity.backgroundColor', self.customBackgroundColor) #setting custom color because screw your light or dark mode.
			self.setProperty('infinity.buttonnofocus', self.customBackgroundColor) #set button same as custom background color when not selected
			if self.dark_text_background == 'dark':
				self.setProperty('infinity.textColor', 'FFF5F5F5')
				self.setProperty('infinity.buttonTextColorNS', 'FFF5F5F5')
				if not self.useCustomTitleColor:
					self.setProperty('infinity.headertextcolor', self.buttonColor)
					self.setProperty('infinity.titleTextColor', 'FFF5F5F5')
					self.setProperty('infinity.titleBarColor', self.customBackgroundColor) #setting titletext and background color if not using a custom value
			else:
				self.setProperty('infinity.textColor', 'FF302F2F')
				self.setProperty('infinity.buttonTextColorNS', 'FF302F2F')
				if not self.useCustomTitleColor:
					self.setProperty('infinity.headertextcolor', self.buttonColor)
					self.setProperty('infinity.titleTextColor', 'FF302F2F')
					self.setProperty('infinity.titleBarColor', self.customBackgroundColor)#setting titletext and background color if not using a custom value