# -*- coding: utf-8 -*-
# By infinity for infinity (07/18/22)
"""
	infinity Add-on
"""


import requests
import re
import time
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.database import mdbsync
from resources.lib.modules import cleandate

#mdblist use your own key
#trakt limiting users lists now. lets see if we can start using some other list providers.
#yes I know this needs cleanup.
getLS = control.lang
highlightColor = control.setting('highlight.color')

def _mdb_ts(ts_str):
	#Normalize a MDBList ISO8601 timestamp so cleandate.iso_2_utc() can parse it.
	if not ts_str: return ts_str
	if '.' in ts_str: ts_str = re.sub(r'\.\d+', '', ts_str)  # strip only fractional seconds, preserve Z or tz suffix
	if ts_str.endswith('Z'): ts_str = ts_str[:-1] + '+00:00'
	if len(ts_str) == 7 and ts_str[4] == '-':
		ts_str = ts_str + '-01T00:00:00+00:00'
	elif len(ts_str) == 10 and ts_str[4] == '-' and 'T' not in ts_str:
		ts_str = ts_str + 'T00:00:00+00:00'
	elif 'T' in ts_str and '+' not in ts_str:
		ts_str = ts_str + '+00:00'
	return ts_str

getSetting = control.setting
mdblist_baseurl = 'https://api.mdblist.com'
mdblist_top_list = '/lists/top'
mdblist_user_list = '/lists/user/'
mdblist_liked_list = '/lists/liked'
mdblist_official_list = '/lists/official'
mdblist_page_limit = '?limit=%s' % getSetting('page.item.limit')
_CLIENT_ID = 'YVFS6WW6GT4c2LvaHxHGa8YlB6u9zGgL6KjtDsHg'
session = requests.Session()
retries = Retry(total=4, backoff_factor=0.3, status_forcelist=[429, 500, 502, 503, 504, 520, 521, 522, 524, 530])
session.mount('https://api.mdblist.com', HTTPAdapter(max_retries=retries, pool_maxsize=100))
_mdblist_token = getSetting('mdblist.token')
if not _mdblist_token: _mdblist_token = 'eWEEQ6OzZlqrJsyWhx1jmVGFqnoZu5'
if _mdblist_token:
	session.headers.update({'Authorization': 'Bearer %s' % _mdblist_token})
highlight_color = getSetting('highlight.color')
artPath = control.artPath()
iconLogos = getSetting('icon.logos') != 'Traditional'
mdblist_icon = control.joinPath(control.artPath(), 'mdblist.png')
headers = {}
headers['Content-Type'] = 'application/json'

def getMDBTopList(self, listType):
	try:
		response = session.get(mdblist_baseurl + mdblist_top_list, timeout=20)
		if isinstance(response, dict):
			return None
		items = _map_top_list(response, listType)
		return items
	except: log_utils.error('get MDBList Error: ')
	return None

def getMDBOfficialLists(self, listType):
	try:
		response = session.get(mdblist_baseurl + mdblist_official_list, timeout=20)
		if isinstance(response, dict):
			return None
		items = _map_official_list(response, listType)
		return items
	except: log_utils.error('get MDBList Official Lists Error: ')
	return None

def _map_official_list(response, listType):
    items = []
    items_append = items.append
    icon = 'userlists.png' if iconLogos else 'mdblist.png'
    iconPath = control.joinPath(artPath, icon)
    jsonResponse = response.json()
    for i in jsonResponse:
        item = {}
        item['label'] = i.get('name')
        item['art'] = {'icon': f'{iconPath}'}
        item['params'] = {
            'info': 'mdblist_officiallist',
            'list_name': i.get('name'),
            'list_id': i.get('slug'),
            'list_count': i.get('items'),
            'plugin_category': i.get('name')}
        item['unique_ids'] = {
            'slug': i.get('slug'),
            'mdblist': i.get('id')}
        items_append(item)
    return items

def _map_top_list(response, listType):
    items = []
    items_append = items.append
    icon = 'userlists.png' if iconLogos else 'mdblist.png'
    iconPath = control.joinPath(artPath, icon)
    jsonResponse = response.json()
    for i in jsonResponse:
        if i.get('mediatype') == listType:
            item = {}
            item['label'] = i.get('name')
            item['art'] = {'icon': f'{iconPath}'}
            item['params'] = {
                'info': 'mdblist_userlist',
                'list_name': i.get('name'),
                'list_id': i.get('id'),
                'list_count': i.get('items'),
                'plugin_category': i.get('name')}
            item['unique_ids'] = {
                'mdblist': i.get('id'),
                'slug': i.get('slug'),
                'user': i.get('user_id')}
            items_append(item)
    return items

def getMDBItems(url):
	try:
		response = session.get(url, timeout=20)
		if isinstance(response, dict):
			log_utils.log(response.error, level=log_utils.LOGDEBUG)
			return None
		items = _map_list_items(response)
		return items
	except: log_utils.error('get MDBList Error: ')
	return None

def _map_list_items(response):
    items = []
    items_append = items.append
    icon = 'userlists.png' if iconLogos else 'mdblist.png'
    iconPath = control.joinPath(artPath, icon)
    jsonResponse = response.json()

    # fix to collect all media from shows or movies.
    media_list = jsonResponse.get('movies', []) + jsonResponse.get('shows', [])
    for i in media_list:
        item = {
            'label': i.get('title'),
            'rank': i.get('rank'),
            'adult': i.get('adult'),
            'title': i.get('title'),
            'id': i.get('id'),
            'imdb': i.get('imdb_id'),
            'release_year': i.get('release_year')}
        items_append(item)
    return items

def getMDBUserList(self, listType, addremove=False):
    try:
        response = session.get(mdblist_baseurl + mdblist_user_list + mdblist_page_limit, timeout=20)
        # log_utils.log(f'get MDBList response {repr(response.json())}')
        if isinstance(response, dict): 
            log_utils.log(response.error, level=log_utils.LOGDEBUG)
            return None
        items = _map_user_list_items(response, listType, addremove=addremove)
        return items
    except: log_utils.error('get MDBList Error: ')
    return None

def _map_user_list_items(response, listType, addremove=False):
    items = []
    items_append = items.append
    icon = 'userlists.png' if iconLogos else 'mdblist.png'
    iconPath = control.joinPath(artPath, icon)
    jsonResponse = response.json()
    for i in jsonResponse:
        if i.get('mediatype') == listType or i.get('mediatype') == None:
            item = {}
            item['label'] = i.get('name')
            item['art'] = {'icon': f'{iconPath}'}
            item['params'] = {
                'info': 'mdblist_userlist',
                'list_name': i.get('name'),
                'list_id': i.get('id'),
                'list_count': i.get('items'),
                'plugin_category': i.get('name')}
            item['unique_ids'] = {
                'mdblist': i.get('id'),
                'slug': i.get('slug')}
            if addremove:
                if i.get('dynamic') == False:
                    items_append(item)
            else:
                items_append(item)
    return items

def getMDBLikedLists(self, listType):
    try:
        data = get_request(mdblist_liked_list)
        if data is None:
            return None
        if isinstance(data, dict):
            for key in ('lists', 'liked', 'data', 'results', 'items'):
                if key in data and isinstance(data[key], list):
                    data = data[key]
                    break
            else:
                log_utils.log('getMDBLikedLists: unexpected dict response keys=%s' % list(data.keys()), level=log_utils.LOGDEBUG)
                return None
        if not isinstance(data, list):
            return None
        icon = 'userlists.png' if iconLogos else 'mdblist.png'
        iconPath = control.joinPath(artPath, icon)
        items = []
        for i in data:
            if i.get('mediatype') == listType or i.get('mediatype') is None:
                owner = i.get('user_name', '') or str(i.get('user_id', ''))
                item = {}
                item['label'] = i.get('name')
                item['art'] = {'icon': f'{iconPath}'}
                item['params'] = {
                    'info': 'mdblist_likedlist',
                    'list_name': i.get('name'),
                    'list_id': i.get('id'),
                    'list_count': i.get('items'),
                    'plugin_category': i.get('name'),
                    'list_owner': owner}
                item['unique_ids'] = {
                    'mdblist': i.get('id'),
                    'slug': i.get('slug'),
                    'user': owner}
                items.append(item)
        return items
    except: log_utils.error('getMDBLikedLists Error: ')
    return None

def get_user_watchlist(listType):
    try:

        response = session.get(f"{mdblist_baseurl}/watchlist/items", timeout=20)
        if isinstance(response, dict): 
            log_utils.log(response.error, level=log_utils.LOGDEBUG)
            return None
        items = _map_user_watchlist_items(response, listType)
        return items
    except: log_utils.error('get MDBList Watchlist Error: ')
    return None

def _map_user_watchlist_items(response, listType):
    items = []
    items_append = items.append
    jsonResponse = response.json()
    if listType == 'movie': jsonResponse = jsonResponse.get('movies')
    elif listType == 'tvshow': jsonResponse = jsonResponse.get('shows')
    for i in jsonResponse:
        item = {}
        item['label'] = i.get('title')
        item['rank'] = i.get('rank')
        item['adult'] = i.get('adult')
        item['title'] = i.get('title')
        item['id'] = i.get('id')
        item['imdb'] = i.get('imdb_id')
        item['release_year'] = i.get('release_year')
        watchlist_at = i.get('watchlist_at')
        watchlist_fixed = watchlist_at.replace(" ", "T")[:-3] + "Z"
        item['added'] = watchlist_fixed
        items_append(item)
    return items

def get_user_collection(listType):
    try:
        mediatype = 'movie' if listType == 'movie' else 'show'
        base_url = f"{mdblist_baseurl}/sync/collection?mediatype={mediatype}&limit=1000"
        all_raw = []
        url = base_url
        while url:
            response = session.get(url, timeout=20)
            if isinstance(response, dict):
                log_utils.log(response.error, level=log_utils.LOGDEBUG)
                return None
            data = response.json()
            key = 'movies' if listType == 'movie' else 'shows'
            all_raw.extend(data.get(key) or [])
            next_cursor = data.get('pagination', {}).get('next_cursor')
            url = f"{base_url}&cursor={next_cursor}" if next_cursor else None
        return _map_movie_collection_items(all_raw) if listType == 'movie' else _map_show_collection_items(all_raw)
    except: log_utils.error('get MDBList Collection Error: ')
    return None

def _map_movie_collection_items(raw_list):
    items = []
    for i in raw_list:
        try:
            movie = i.get('movie', {})
            ids = movie.get('ids', {})
            collected_at = i.get('collected_at', '')
            try: collected_fixed = collected_at[:-5] + 'Z' if collected_at else ''
            except: collected_fixed = ''
            items.append({
                'label': movie.get('title'),
                'title': movie.get('title'),
                'release_year': movie.get('year'),
                'imdb': ids.get('imdb', ''),
                'tmdb': str(ids.get('tmdb', '') or ''),
                'tvdb': '',
                'id': ids.get('mdblist', ''),
                'added': collected_fixed,
            })
        except: pass
    return items

def _map_show_collection_items(shows_raw):
    """Map show-level collection results, tolerating legacy episode results."""
    seen = {}
    for i in shows_raw:
        try:
            show = i.get('show') or i.get('episode', {}).get('show') or i
            ids = show.get('ids', {})
            imdb = ids.get('imdb', '')
            tmdb = ids.get('tmdb', 0)
            key = imdb or str(tmdb)
            if not key or key in seen: continue
            collected_at = i.get('collected_at', '')
            try: collected_fixed = collected_at[:-5] + 'Z' if collected_at else ''
            except: collected_fixed = ''
            seen[key] = {
                'label': show.get('title'),
                'title': show.get('title'),
                'release_year': show.get('year'),
                'imdb': imdb,
                'tmdb': str(tmdb or ''),
                'tvdb': '',
                'id': ids.get('mdblist', ''),
                'added': collected_fixed,
            }
        except: pass
    return list(seen.values())

def _map_dropped_show_items(raw_list):
    items = []
    for i in raw_list:
        try:
            show = i.get('show') or i
            ids = show.get('ids', {})
            dropped_at = i.get('dropped_at', '')
            try: dropped_fixed = dropped_at[:-5] + 'Z' if dropped_at else ''
            except: dropped_fixed = ''
            items.append({
                'label': show.get('title'), 'title': show.get('title'),
                'release_year': show.get('year'),
                'imdb': ids.get('imdb', ''), 'tmdb': str(ids.get('tmdb', '') or ''),
                'tvdb': str(ids.get('tvdb', '') or ''), 'id': ids.get('mdblist', ''),
                'added': dropped_fixed,
            })
        except: pass
    return items

def get_user_dropped():
    try:
        base_url = f"{mdblist_baseurl}/sync/dropped?limit=1000"
        all_raw = []
        url = base_url
        while url:
            response = session.get(url, timeout=20)
            if isinstance(response, dict):
                log_utils.log(str(response), level=log_utils.LOGDEBUG)
                return None
            data = response.json()
            all_raw.extend(data.get('shows') or [])
            next_cursor = data.get('pagination', {}).get('next_cursor')
            url = f"{base_url}&cursor={next_cursor}" if next_cursor else None
        return _map_dropped_show_items(all_raw)
    except: log_utils.error('get_user_dropped Error: ')
    return None

def getDroppedActivity(activities=None):
    try:
        if activities: i = activities
        else: i = getActivities()
        if not i: return 0
        dropped_at = i.get('dropped_at')
        if not dropped_at: return 0
        return int(cleandate.iso_2_utc(_mdb_ts(dropped_at)) or 0)
    except: log_utils.error()
    return 0

def sync_dropped(activities=None, forced=False):
    try:
        if forced:
            items = get_user_dropped()
            if items is not None: mdbsync.insert_dropped(items, 'shows_dropped')
        else:
            db_last_dropped = mdbsync.last_sync('last_dropped_at')
            droppedActivity = getDroppedActivity(activities)
            if droppedActivity - db_last_dropped >= 60:
                log_utils.log('Mdb Dropped Sync Update...(local db latest "dropped_at" = %s, mdblist api latest "dropped_at" = %s)' % \
                                    (str(db_last_dropped), str(droppedActivity)), __name__, log_utils.LOGINFO)
                items = get_user_dropped()
                if items is not None: mdbsync.insert_dropped(items, 'shows_dropped')
    except: log_utils.error()

def manager(name, imdb=None, tvdb=None, tmdb=None, watched=None, season=None, episode=None, tvshow=False):
    lists = []
    try:
        if season: season = int(season)
        if episode: episode = int(episode)
        if episode:
            content_type = 'episode'
        elif season:
            content_type = 'season'
        elif tvshow or (tvdb and tvdb != 'None'):
            content_type = 'tvshow'
        else:
            content_type = 'movie'
        items = []
        if watched is not None:
            if watched is True:
                items += [(getLS(33652) % highlight_color, 'unwatch')]
            else:
                items += [(getLS(33651) % highlight_color, 'watch')]
        else:
            items += [(getLS(33651) % highlight_color, 'watch')]
            items += [(getLS(33652) % highlight_color, 'unwatch')]
        if content_type in ('movie', 'episode', 'season'):
            items += [(getLS(40076) % highlight_color, 'scrobbleReset')]
        items += [(getLS(40596) % highlight_color, 'add')]
        items += [(getLS(40597) % highlight_color, 'remove')]
        items += [(getLS(40707) % highlight_color, 'collection_add')]
        items += [(getLS(40708) % highlight_color, 'collection_remove')]
        if content_type == 'tvshow':
            items += [(getLS(40712) % highlight_color, 'dropped_add')]
            items += [(getLS(40713) % highlight_color, 'dropped_remove')]
        if not tvdb or tvdb == 'None':
            from resources.lib.menus import movies
            result = movies.Movies().getMDBUserList(create_directory=False, addremove=True)
        else:
            from resources.lib.menus import tvshows
            result = tvshows.TVshows().getMDBUserList(create_directory=False, addremove=True)
        # log_utils.log('getMDBLikedLists Error: ')
        lists = [(i['name'], i['list_id']) for i in result]
        lists2 = [(i['name'], i['list_id']) for i in result]
        lists = [lists[i//2] for i in range(len(lists)*2)]

        for i in range(0, len(lists), 2):
            lists[i] = ((getLS(33580) % (highlight_color, lists[i][0])), '/lists/%s/items/add' % lists[i][1])
        for i in range(1, len(lists), 2):
            lists[i] = ((getLS(33581) % (highlight_color, lists[i][0])), '/lists/%s/items/remove' % lists[i][1])
        items += lists
        control.hide()
        select = control.selectDialog([i[0] for i in items], heading= ' - ' + getLS(40649))
        if select == -1: return
        if select >= 0:
                if items[select][1] == 'watch':
                    watch(content_type, name, imdb=imdb, tvdb=tvdb, tmdb=tmdb, season=season, episode=episode)
                    return
                if items[select][1] == 'unwatch':
                    unwatch(content_type, name, imdb=imdb, tvdb=tvdb, tmdb=tmdb, season=season, episode=episode)
                    return
                if items[select][1] == 'scrobbleReset':
                    scrobbleReset(imdb=imdb, tmdb=tmdb, tvdb=tvdb, season=season, episode=episode, refresh=True, clear_local=True)
                    return
                if not tvdb or tvdb == 'None': post = {"movies": [{"imdb": imdb}]}
                else:
                    post = {"shows": [{"tmdb": tmdb}]}
                if type(post) == dict or type(post) == list: 
                    import json
                    post = json.dumps(post)
                if items[select][1] == 'add':
                    response = session.post(f"{mdblist_baseurl}/watchlist/items/add", data=post, headers=headers, timeout=20)
                    action = 'add'
                    listid = 'MDBList Watchlist'
                if items[select][1] == 'remove':
                    response = session.post(f"{mdblist_baseurl}/watchlist/items/remove", data=post, headers=headers, timeout=20)
                    action = 'remove'
                    listid = 'MDBList Watchlist'
                if items[select][1] in ('collection_add', 'collection_remove'):
                    import json as _cjson
                    if not tvdb or tvdb == 'None':
                        collection_post = _cjson.dumps({"movies": [{"ids": {"imdb": imdb, "tmdb": int(tmdb) if tmdb not in (None, '', 'None', '0', 0) else None}}]})
                    else:
                        collection_post = _cjson.dumps({"shows": [{"ids": {"imdb": imdb}}]})
                if items[select][1] == 'collection_add':
                    response = session.post(f"{mdblist_baseurl}/sync/collection", data=collection_post, headers=headers, timeout=20)
                    action = 'add'
                    listid = 'MDBList Collection'
                if items[select][1] == 'collection_remove':
                    response = session.post(f"{mdblist_baseurl}/sync/collection/remove", data=collection_post, headers=headers, timeout=20)
                    action = 'remove'
                    listid = 'MDBList Collection'
                if items[select][1] == 'dropped_add':
                    import json as _djson
                    from datetime import datetime as _dt
                    _dpost = _djson.dumps({'shows': [{'ids': {'imdb': imdb}, 'dropped_at': _dt.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')}]})
                    response = session.post(f"{mdblist_baseurl}/sync/dropped", data=_dpost, headers=headers, timeout=20)
                    if response.status_code in (200, 201):
                        mdbsync.insert_dropped([{'imdb': imdb, 'title': name, 'tmdb': str(tmdb or ''), 'tvdb': str(tvdb or '')}], 'shows_dropped', new_sync=False)
                        control.notification(title='MDBList', message='%s added to Dropped' % name, icon=mdblist_icon)
                    else:
                        control.notification(title='MDBList', message='Error: %s' % response.text)
                    control.hide(); return
                if items[select][1] == 'dropped_remove':
                    import json as _djson
                    _dpost = _djson.dumps({'shows': [{'ids': {'imdb': imdb}}]})
                    response = session.post(f"{mdblist_baseurl}/sync/dropped/remove", data=_dpost, headers=headers, timeout=20)
                    if response.status_code in (200, 201):
                        mdbsync.delete_dropped_items([imdb], 'shows_dropped', col_name='imdb')
                        control.notification(title='MDBList', message='%s removed from Dropped' % name, icon=mdblist_icon)
                    else:
                        control.notification(title='MDBList', message='Error: %s' % response.text)
                    control.hide(); return
                for count in range(len(lists)):
                    i = lists[count]
                    if i[1] == '%s' % items[select][1]:
                        response = session.post(mdblist_baseurl + items[select][1], data=post, headers=headers, timeout=20)
                        match = re.search(r'/lists/(\d+)/', i[1])
                        list_id_num = int(match.group(1)) if match else None
                        listid = next((name for name, id in lists2 if id == list_id_num), 'Unknown List')
                        if 'add' in i[1]:
                            action = 'add'
                        if 'remove' in i[1]:    
                            action = 'remove'
                if response.status_code == 200:
                    response = response.json()
                    if action == 'add':
                        if int(response.get('added').get('movies')) > 0:
                            control.notification("Movie Added", "%s added to %s" % (name, listid), icon=mdblist_icon)
                        if int(response.get('added').get('shows')) > 0:
                            control.notification("Show Added", "%s added to %s" % (name, listid), icon=mdblist_icon)
                        if int(response.get('existing').get('movies')) > 0 and int(response.get('added').get('movies')) == 0:
                            control.notification("Error", "%s already on %s" % (name, listid), icon=mdblist_icon)
                        if int(response.get('existing').get('shows')) > 0 and int(response.get('added').get('shows')) == 0:
                            control.notification("Error", "%s already on %s" % (name, listid), icon=mdblist_icon)
                    if action == 'remove':
                        if int(response.get('removed').get('movies')) > 0:
                            control.notification("Movie Removed", "%s removed from %s" % (name, listid), icon=mdblist_icon)
                        if int(response.get('removed').get('shows')) > 0:
                            control.notification("Show Removed", "%s removed from %s" % (name, listid), icon=mdblist_icon)
                elif response.status_code == 403:
                    response = response.json()
                    control.notification("Error", response.get('detail'), icon=mdblist_icon)
                else:
                    control.notification("Error", response.text)

                control.hide()
    except:
        log_utils.error()
        control.hide()

def sync_watch_list(activities=None, forced=False):
    try:
        link = f"{mdblist_baseurl}/watchlist/items"
        if forced:
            items = get_mdb_list_as_json(link,'movie')
            mdbsync.insert_watch_list(items, 'movies_watchlist')
            items = get_mdb_list_as_json(link, 'tvshow')
            mdbsync.insert_watch_list(items, 'shows_watchlist')
            #log_utils.log('Forced - Trakt Watch List Sync Complete', __name__, log_utils.LOGDEBUG)
        else:
            db_last_watchList = mdbsync.last_sync('last_watchlisted_at')
            watchListActivity = getWatchListedActivity(activities)
            if watchListActivity - db_last_watchList >= 60: # do not sync unless 1 min difference or more
                log_utils.log('Mdb Watch List Sync Update...(local db latest "watchlist_at" = %s, mdblist api latest "watchlisted_at" = %s)' % \
                                    (str(db_last_watchList), str(watchListActivity)), __name__, log_utils.LOGINFO)
                items = get_mdb_list_as_json(link,'movie')
                mdbsync.insert_watch_list(items, 'movies_watchlist')
                items = get_mdb_list_as_json(link, 'tvshow')
                mdbsync.insert_watch_list(items, 'shows_watchlist')
    except: log_utils.error()

def get_mdb_collection_as_json(url, listKind):
    try:
        mediatype = 'movie' if listKind == 'movie' else 'show'
        key = 'movies' if listKind == 'movie' else 'shows'
        base_url = f"{url}?mediatype={mediatype}&limit=1000"
        all_raw = []
        current_url = base_url
        while current_url:
            response = session.get(current_url, timeout=20)
            if isinstance(response, dict):
                log_utils.log(response.error, level=log_utils.LOGDEBUG)
                return None
            data = response.json()
            all_raw.extend(data.get(key) or [])
            next_cursor = data.get('pagination', {}).get('next_cursor')
            current_url = f"{base_url}&cursor={next_cursor}" if next_cursor else None
        return _map_movie_collection_items(all_raw) if listKind == 'movie' else _map_show_collection_items(all_raw)
    except: log_utils.error()
    return None

def sync_collection(activities=None, forced=False):
    try:
        link = f"{mdblist_baseurl}/sync/collection"
        if forced:
            items = get_mdb_collection_as_json(link, 'movie')
            if items is not None: mdbsync.insert_collection(items, 'movies_collection')
            items = get_mdb_collection_as_json(link, 'tvshow')
            if items is not None: mdbsync.insert_collection(items, 'shows_collection')
        else:
            db_last_collection = mdbsync.last_sync('last_collected_at')
            collectionActivity = getCollectedActivity(activities)
            if collectionActivity - db_last_collection >= 60:
                log_utils.log('Mdb Collection Sync Update...(local db latest "collected_at" = %s, mdblist api latest "collected_at" = %s)' % \
                                    (str(db_last_collection), str(collectionActivity)), __name__, log_utils.LOGINFO)
                items = get_mdb_collection_as_json(link, 'movie')
                if items is not None: mdbsync.insert_collection(items, 'movies_collection')
                items = get_mdb_collection_as_json(link, 'tvshow')
                if items is not None: mdbsync.insert_collection(items, 'shows_collection')
    except: log_utils.error()

def getCollectedActivity(activities=None):
    try:
        if activities: i = activities
        else: i = getActivities()
        if not i: return 0
        activity = []
        collected_at = i.get('collected_at')
        if collected_at: activity.append(collected_at)
        if not activity: return 0
        activity = [int(cleandate.iso_2_utc(_mdb_ts(i)) or 0) for i in activity]
        activity = sorted(activity, key=int)[-1]
        return activity
    except: log_utils.error()
    return 0

def removeCollectionItems(media_type, imdb_list):
    """Remove items from MDBList collection. media_type: 'movies' or 'shows'. imdb_list: list of IMDb IDs."""
    if not imdb_list: return
    try:
        import json as _json
        total_items = len(imdb_list)
        if media_type == 'movies':
            post = _json.dumps({'movies': [{'ids': {'imdb': i}} for i in imdb_list]})
            table = 'movies_collection'
        else:
            post = _json.dumps({'shows': [{'ids': {'imdb': i}} for i in imdb_list]})
            table = 'shows_collection'
        response = session.post('%s/sync/collection/remove' % mdblist_baseurl, data=post, headers=headers, timeout=20)
        if response.status_code == 200:
            mdbsync.delete_collection_items(imdb_list, table, col_name='imdb')
            control.trigger_widget_refresh()
            control.notification(title='MDBList Collection Manager',
                message='Successfully Removed %s Item%s' % (total_items, 's' if total_items > 1 else ''))
        else:
            control.notification(title='MDBList', message='Error: %s' % response.text)
    except: log_utils.error()

def removeDroppedItems(imdb_list):
    """Remove shows from MDBList dropped. imdb_list: list of IMDb IDs."""
    if not imdb_list: return
    try:
        import json as _json
        total_items = len(imdb_list)
        post = _json.dumps({'shows': [{'ids': {'imdb': i}} for i in imdb_list]})
        response = session.post('%s/sync/dropped/remove' % mdblist_baseurl, data=post, headers=headers, timeout=20)
        if response.status_code in (200, 201):
            mdbsync.delete_dropped_items(imdb_list, 'shows_dropped', col_name='imdb')
            control.trigger_widget_refresh()
            control.notification(title='MDBList Dropped Manager',
                message='Successfully Removed %s Item%s' % (total_items, 's' if total_items > 1 else ''))
        else:
            control.notification(title='MDBList', message='Error: %s' % response.text)
    except: log_utils.error()

def get_mdb_list_as_json(url, listKind):
    response = session.get(url, timeout=20)
    if isinstance(response, dict):
        log_utils.log(response.error, level=log_utils.LOGDEBUG)
        return None
    items = []
    items_append = items.append
    jsonResponse = response.json()
    if listKind == 'movie': jsonResponse = jsonResponse.get('movies')
    elif listKind == 'tvshow': jsonResponse = jsonResponse.get('shows')
    for i in jsonResponse:
        item = {}
        item['label'] = i.get('title')
        item['rank'] = i.get('rank')
        item['adult'] = i.get('adult')
        item['title'] = i.get('title')
        item['id'] = i.get('id')
        item['imdb'] = i.get('imdb_id')
        item['release_year'] = i.get('release_year')
        watchlist_at = i.get('watchlist_at')
        watchlist_fixed = watchlist_at.replace(" ", "T")[:-3] + "Z"
        item['added'] = watchlist_fixed
        items_append(item)
    return items

def get_list_items_for_library(url):
    """Fetch all items from an MDBList list URL with mediatype (movie/tvshow) preserved."""
    try:
        response = session.get(url, timeout=20)
        if isinstance(response, dict):
            log_utils.log(str(response), level=log_utils.LOGDEBUG)
            return None
        items = []
        jsonResponse = response.json()
        for i in jsonResponse.get('movies', []):
            items.append({
                'title': i.get('title', ''),
                'year': str(i.get('release_year', '')) if i.get('release_year') else '',
                'imdb': str(i.get('imdb_id', '')) if i.get('imdb_id') else '',
                'mediatype': 'movie',
            })
        for i in jsonResponse.get('shows', []):
            items.append({
                'title': i.get('title', ''),
                'year': str(i.get('release_year', '')) if i.get('release_year') else '',
                'imdb': str(i.get('imdb_id', '')) if i.get('imdb_id') else '',
                'mediatype': 'tvshow',
            })
        return items
    except:
        log_utils.error('get_list_items_for_library Error: ')
    return None


def getWatchListedActivity(activities=None):
    try:
        i = activities if activities else getActivities()
        if not i: return 0
        if isinstance(i, str):
            import json as _json
            i = _json.loads(i)
        # activity = []
        # activity.append(i['watchlisted_at'])
        # activity = [int(cleandate.iso_2_utc(_mdb_ts(i)) or 0) for i in activity]
        # activity = sorted(activity, key=int)[-1]
        list_updated_at = i['list_updated_at']
        activity = int(cleandate.iso_2_utc(list_updated_at))
        return activity
    except: log_utils.error()
    return 0

def getMDBListCredentialsInfo():
	return bool(getSetting('mdblist.token'))

def getMDBListIndicatorsInfo():
	return getSetting('indicators.alt') == '3'

def mdblistAuth(fromSettings=0):
	try:
		response = session.post(
			'https://api.mdblist.com/oauth/device-authorization/',
			data={'client_id': _CLIENT_ID, 'scope': 'write'},
			timeout=20)
		if response.status_code != 200:
			control.notification(title='MDBList', message='Authorization request failed')
			if fromSettings: control.openSettings('5.4', 'plugin.video.infinity')
			return False
		device_data = response.json()
		device_code = device_data['device_code']
		user_code = device_data['user_code']
		verification_url = device_data.get('verification_url', 'https://mdblist.com/oauth/device/')
		expires_in = int(device_data.get('expires_in', 300))
		interval = int(device_data.get('interval', 5))
		verification_url_display = control.lang(32513) % (highlightColor, verification_url)
		user_code_display = control.lang(32514) % (highlightColor, user_code)
		if control.setting('dialogs.useinfinitydialog') == 'true':
			from resources.lib.modules import tools
			mdb_qr = tools.make_qr(verification_url, 'mdblist_qr.png')
			progressDialog = control.getProgressWindow('MDBList Authorization', mdb_qr, 1)
			progressDialog.set_controls()
			progressDialog.update(0, control.progress_line % (verification_url_display, user_code_display))
		else:
			progressDialog = control.progressDialog
			progressDialog().create('MDBList Authorization',
				control.progress_line % (verification_url_display, user_code_display))
		access_token = None
		refresh_token = ''
		start = time.time()
		try:
			while not progressDialog.iscanceled():
				time_passed = time.time() - start
				if time_passed >= expires_in:
					break
				control.sleep(interval * 1000)
				poll = session.post(
					'https://api.mdblist.com/oauth/token/',
					data={
						'grant_type': 'urn:ietf:params:oauth:grant-type:device_code',
						'device_code': device_code,
						'client_id': _CLIENT_ID},
					timeout=20)
				if poll.status_code == 200:
					access_token = poll.json().get('access_token', '')
					refresh_token = poll.json().get('refresh_token', '')
					break
				progress = int(100 - 100 * time_passed / expires_in)
				progressDialog.update(progress, control.progress_line % (verification_url_display, user_code_display))
		finally:
			progressDialog.close()
		if not access_token:
			control.notification(title='MDBList', message='Authorization failed or timed out')
			if fromSettings: control.openSettings('5.4', 'plugin.video.infinity')
			return False
		control.setSetting('mdblist.token', access_token)
		if refresh_token:
			control.setSetting('mdblist.refresh.token', refresh_token)
		session.headers.update({'Authorization': 'Bearer %s' % access_token})
		control.notification(title='MDBList', message='MDBList Authorized Successfully')
		if fromSettings: control.openSettings('5.4', 'plugin.video.infinity')
		return True
	except:
		log_utils.error()
		if fromSettings: control.openSettings('5.4', 'plugin.video.infinity')
		return False

def mdblistRevoke(fromSettings=0):
	try:
		control.homeWindow.setProperty('infinity.updateSettings', 'false')
		control.setSetting('mdblist.token', '')
		control.setSetting('mdblist.refresh.token', '')
		control.homeWindow.setProperty('infinity.updateSettings', 'true')
		session.headers.pop('Authorization', None)
		clr_mdb = {'mdb_watched_movies': True, 'mdb_watched_episodes': True, 'watched': True, 'bookmarks': True,
			'movies_watchlist': True, 'shows_watchlist': True, 'movies_collection': True, 'shows_collection': True, 'shows_dropped': True}
		mdbsync.delete_mdb_tables(clr_mdb)
		if getSetting('indicators.alt') == '3':
			control.setSetting('indicators.alt', '0')
			control.setSetting('indicators', 'Local')
		if getSetting('scrobble.source') == '3':
			control.setSetting('scrobble.source', '0')
			control.setSetting('scrobble', 'Local')
		control.setSetting('mdblist.markwatched', 'false')
		control.notification(title='MDBList', message='MDBList Authorization Revoked')
	except: log_utils.error()
	finally:
		if fromSettings: control.openSettings('5.4', 'plugin.video.infinity')

def _refresh_token():
	try:
		refresh_token = getSetting('mdblist.refresh.token')
		if not refresh_token:
			return False
		resp = session.post(
			'https://api.mdblist.com/oauth/token/',
			data={'grant_type': 'refresh_token', 'refresh_token': refresh_token, 'client_id': _CLIENT_ID},
			timeout=20
		)
		if resp.status_code == 200:
			data = resp.json()
			access_token = data.get('access_token', '')
			new_refresh = data.get('refresh_token', '')
			if access_token:
				control.setSetting('mdblist.token', access_token)
				if new_refresh:
					control.setSetting('mdblist.refresh.token', new_refresh)
				session.headers.update({'Authorization': 'Bearer %s' % access_token})
				log_utils.log('MDBList token refreshed successfully', level=log_utils.LOGDEBUG)
				return True
		log_utils.log('MDBList token refresh failed: status=%s body=%r' % (resp.status_code, resp.text[:200]), level=log_utils.LOGDEBUG)
		return False
	except:
		log_utils.error()
		return False

def get_request(url, post=None, method='GET', _retried=False):
	try:
		full_url = f"{mdblist_baseurl}{url}"
		import json as _json
		for _attempt in range(2):
			try:
				if method == 'DELETE':
					response = session.delete(full_url, headers=headers, timeout=20)
				elif post is not None:
					response = session.post(full_url, data=_json.dumps(post), headers=headers, timeout=20)
				else:
					response = session.get(full_url, timeout=20)
				break
			except requests.exceptions.ConnectionError:
				# The server may have committed a watched POST before the connection
				# failed. Replaying it can create a second history entry.
				if _attempt == 0 and post is None and method == 'GET':
					log_utils.log('MDBList get_request: connection reset, retrying with fresh connection...', level=log_utils.LOGDEBUG)
					session.close()
				else:
					raise
		if response.status_code in (200, 201, 204):
			try: return response.json()
			except: return {}
		if response.status_code == 401 and not _retried:
			if _refresh_token():
				return get_request(url, post=post, method=method, _retried=True)
			control.notification(title='MDBList', message='MDBList session expired — please re-authenticate in settings')
		log_utils.log('MDBList get_request non-2xx: url=%s status=%s body=%r' % (full_url, response.status_code, response.text[:200]), level=log_utils.LOGDEBUG)
		return None
	except: log_utils.error()
	return None

def getActivities():
	try:
		return get_request('/sync/last_activities')
	except: log_utils.error()
	return None

def get_up_next():
	try:
		result = get_request('/upnext?limit=100&hide_unreleased=true')
		if result is None:
			return []
		items = result if isinstance(result, list) else result.get('items', result.get('shows', []))
		return items
	except: log_utils.error()
	return []

def get_calendar(start, end):
	# MDBList's own /calendar/events — personalized to the user's watchlist/tracked
	# shows, confirmed live (real response shape: {'events': [{'type': 'episode'|'movie',
	# 'title': <show title>, 'episode_title':, 'show_tmdb':, 'season_number':,
	# 'episode_number':, 'start': 'YYYY-MM-DD', ...}]}). Distinct from get_up_next()'s
	# /upnext endpoint (per-show "next episode" only, unreliable for out-of-order
	# watching — see mdblist_progress_list()'s local reconstruction for that case).
	try:
		result = get_request('/calendar/events?limit=1000&start=%s&end=%s' % (start, end))
		if not result: return []
		return result.get('events') or []
	except: log_utils.error()
	return []

def _activities_dict(activities=None):
	try:
		i = activities if activities else getActivities()
		if not i: return {}
		if isinstance(i, str):
			import json as _json
			i = _json.loads(i)
		return i if isinstance(i, dict) else {}
	except: log_utils.error()
	return {}

def _activity_timestamp(value):
	try: return int(cleandate.iso_2_utc(_mdb_ts(value)) or 0) if value else 0
	except: return 0

def getWatchedActivity(activities=None):
	try:
		i = _activities_dict(activities)
		return max(_activity_timestamp(i.get(key)) for key in
			('watched_at', 'season_watched_at', 'episode_watched_at', 'history_at'))
	except: log_utils.error()
	return 0

def getServerTime(activities=None):
	try: return _activity_timestamp(_activities_dict(activities).get('server_time'))
	except: log_utils.error()
	return 0

def getMoviesWatchedActivity():
	try: return mdbsync.last_sync('last_watched_movies_at')
	except: log_utils.error()
	return 0

def getEpisodesWatchedActivity():
	try: return mdbsync.last_sync('last_watched_episodes_at')
	except: log_utils.error()
	return 0

def timeoutsyncMovies():
	return mdbsync.timeout(syncMovies)

def timeoutsyncTVShows():
	return mdbsync.timeout(syncTVShows)

def timeoutsyncSeasons(imdb, tvdb):
	try: return mdbsync.timeout(syncSeasons, imdb, tvdb, returnNone=True)
	except: log_utils.error()

def sync_watchedProgress(activities=None, forced=False):
	try:
		# A new cursor key forces one complete snapshot on upgrade. Legacy builds
		# stored a device wall-clock value which could be ahead of MDBList forever.
		db_last = mdbsync.last_sync('last_watched_sync_at_v2')
		api_last = getWatchedActivity(activities)
		if not forced and db_last and api_last <= db_last: return
		from datetime import datetime as _dt
		since = _dt.utcfromtimestamp(db_last).strftime('%Y-%m-%dT%H:%M:%SZ') if db_last else '1970-01-01T00:00:00Z'
		offset = 0
		limit = 1000
		movie_count = 0
		episode_count = 0
		while True:
			url = f"/sync/watched?since={since}&limit={limit}&offset={offset}"
			data = get_request(url)
			# Do not advance the cursor when the request failed; the next service
			# pass must retry the same activity window.
			if data is None: return
			if not data: break
			for item in data.get('movies', []):
				ids = item.get('movie', {}).get('ids', {})
				imdb = str(ids.get('imdb', ''))
				if not imdb: continue
				mdbsync.upsert_watched_movie(
					imdb=imdb,
					tmdb=str(ids.get('tmdb', '')),
					title=item.get('movie', {}).get('title', ''),
					year=str(item.get('movie', {}).get('year', '')),
					last_watched_at=item.get('last_watched_at', '')
				)
				movie_count += 1
			for item in data.get('episodes', []):
				ep = item.get('episode', {})
				show_ids = ep.get('show', {}).get('ids', {})
				show_imdb = str(show_ids.get('imdb') or '')
				if not show_imdb and not show_ids.get('tmdb'): continue
				mdbsync.upsert_watched_episode(
					show_imdb=show_imdb,
					show_tmdb=str(show_ids.get('tmdb', '')),
					show_tvdb=str(show_ids.get('tvdb', '')),
					season=ep.get('season', 0),
					episode=ep.get('number', 0),
					last_watched_at=item.get('last_watched_at', '')
				)
				episode_count += 1
			pagination = data.get('pagination', {})
			if not pagination.get('has_more', False): break
			offset += limit
		# MDBList explicitly documents server_time as the safe sync cursor.
		checkpoint = getServerTime(activities) or api_last or None
		mdbsync.update_last_watched_at('last_watched_sync_at_v2', checkpoint)
		mdbsync.update_last_watched_at('last_watched_at', checkpoint)
		# invalidate indicator caches so next access fetches fresh data
		mdbsync.cache_delete(mdbsync._hash_function(syncMovies, ()))
		mdbsync.cache_delete(mdbsync._hash_function(syncTVShows, ()))
		_clr_episode_progress_cache()
		log_utils.log('MDBList watched sync applied %s movies and %s episodes (activity=%s, cursor=%s)' %
			(movie_count, episode_count, api_last, checkpoint), level=log_utils.LOGDEBUG)
		return True
	except: log_utils.error()
	return False


def syncMovies():
	try:
		if not getMDBListCredentialsInfo(): return None
		return mdbsync.get_watched_movies() or []
	except: log_utils.error()

def watchedMovies():
	try:
		if not getMDBListCredentialsInfo(): return None
		return mdbsync.get_watched_movies_full() or []
	except: log_utils.error()

def _make_episode_ranges(ep_nums_sorted):
	if not ep_nums_sorted: return []
	ranges = []
	start = end = ep_nums_sorted[0]
	for ep in ep_nums_sorted[1:]:
		if ep == end + 1:
			end = ep
		else:
			ranges.append((start, end))
			start = end = ep
	ranges.append((start, end))
	return ranges

def syncTVShows():
	try:
		if not getMDBListCredentialsInfo(): return None
		episodes = mdbsync.get_watched_episodes()
		if not episodes: return []
		from resources.lib.modules.progress_identity import group_watched_shows
		# Older history can lack TMDb IDs that later playback supplies. Reconcile
		# those aliases before building indicators, preserving split TMDb stories.
		shows = group_watched_shows(episodes)
		indicators = []
		for show in shows:
			by_season = {}
			for season, episode in show['watched_set']:
				by_season.setdefault(season, []).append(episode)
			ep_ranges = {s: _make_episode_ranges(sorted(eps)) for s, eps in by_season.items()}
			total = sum(e - s + 1 for ranges in ep_ranges.values() for s, e in ranges)
			ids = {field: show[field] for field in ('imdb', 'tmdb', 'tvdb')}
			indicators.append((ids, total, ep_ranges))
		return indicators
	except: log_utils.error()

def watchedShows():
	try:
		if not getMDBListCredentialsInfo(): return None
		rows = mdbsync.get_watched_shows()
		if not rows: return []
		return [{'ids': {'imdb': r[0], 'tmdb': r[1], 'tvdb': r[2]}, 'last_watched_at': r[3]} for r in rows]
	except: log_utils.error()

def syncSeasons(imdb, tvdb):
	try:
		if not getMDBListCredentialsInfo(): return None
		if not imdb and not tvdb: return None
		episodes = mdbsync.get_watched_episodes()
		# MDBList's local watched-episode rows never populate show_tvdb (always ''), so
		# comparing "sv == tvdb" against an empty tvdb matched every other show's rows too
		# (both sides ''), silently merging hundreds of unrelated shows' episodes into one
		# season/episode count — only match on a given id when it's actually non-empty.
		show_eps = [(s, e) for (si, st, sv, s, e) in (episodes or []) if (imdb and si == imdb) or (tvdb and sv == tvdb)]
		from collections import defaultdict
		by_season = defaultdict(list)
		for (s, e) in show_eps:
			by_season[int(s)].append(int(e))
		# Get total episode counts per season from TMDb
		from resources.lib.database import cache as _cache
		from resources.lib.indexers import tmdb as _tmdb
		tmdb_id = ''
		try:
			result = _cache.get(_tmdb.TVshows().IdLookup, 96, imdb, tvdb)
			if result: tmdb_id = str(result.get('id', ''))
		except: pass
		season_totals = {}
		if tmdb_id:
			try:
				meta = _cache.get(_tmdb.TVshows().get_showSeasons_meta, 96, tmdb_id)
				if meta:
					status = (meta.get('status') or '').lower()
					ended = status in ('ended', 'canceled', 'cancelled')
					last_ep = meta.get('last_episode_to_air') or {}
					last_aired_sn = int(last_ep.get('season_number', 0)) if last_ep else 0
					last_aired_ep = int(last_ep.get('episode_number', 0)) if last_ep else 0
					for s_item in meta.get('seasons', []):
						sn = int(s_item.get('season_number', 0))
						if sn <= 0: continue
						ep_count = int(s_item.get('episode_count', 0))
						if ended or sn < last_aired_sn:
							season_totals[sn] = ep_count
						elif sn == last_aired_sn:
							season_totals[sn] = last_aired_ep if last_aired_ep > 0 else ep_count
						# sn > last_aired_sn: future/unaired season — omit so fallback uses watched count only
			except: pass
		counts = {}
		completed_seasons = []
		for sn, watched_eps in by_season.items():
			total = season_totals.get(sn, len(watched_eps))
			watched = len(set(watched_eps))
			unwatched = max(0, total - watched)
			counts[sn] = {'total': total, 'watched': watched, 'unwatched': unwatched}
			if total > 0 and watched >= total:
				completed_seasons.append('%01d' % sn)
		# Include aired seasons with no watched episodes so getShowCount totals all seasons, not just watched ones
		for sn, ep_count in season_totals.items():
			if sn not in counts:
				counts[sn] = {'total': ep_count, 'watched': 0, 'unwatched': ep_count}
		return [completed_seasons, counts]
	except: log_utils.error()
	return [[], {}]

def seasonCount(imdb, tvdb):
	try:
		result = syncSeasons(imdb, tvdb)
		if result and len(result) > 1: return result[1]
		return {}
	except: log_utils.error()


def cachesyncMovies(timeout=720):
	try:
		return mdbsync.get(syncMovies, timeout)
	except: log_utils.error()

def cachesyncTVShows(timeout=720):
	try:
		return mdbsync.get(syncTVShows, timeout)
	except: log_utils.error()

def cachesyncSeasons(imdb, tvdb='', timeout=720):
	try:
		imdb = imdb or ''
		tvdb = tvdb or ''
		return mdbsync.get(syncSeasons, timeout, imdb, tvdb)
	except: log_utils.error()

def cachesyncTV(imdb, tvdb):
	try:
		from concurrent.futures import ThreadPoolExecutor
		with ThreadPoolExecutor() as executor:
			executor.submit(cachesyncTVShows, 0)
			executor.submit(cachesyncSeasons, imdb, tvdb, 0)
	except: log_utils.error()

def _clr_episode_progress_cache():
	try:
		from resources.lib.menus.episodes import Episodes
		from resources.lib.database import cache
		ep = Episodes()
		cache.remove(ep.mdblist_progress_list, '/upnext', ep.mdblist_directProgressScrape)
		cache.remove(ep.mdblist_progress_list, 'mdbprogress', ep.mdblist_directProgressScrape)
	except: log_utils.error()


def _scrobble(endpoint, media_type, imdb, tmdb, tvdb, season, episode, percent):
	if tmdb and media_type != 'movie':
		from resources.lib.modules.episode_mapping import supported
		if supported(tmdb): imdb, tvdb = '', ''
	try:
		percent = round(float(percent), 2)
		if media_type == 'movie':
			post = {'movie': {'ids': {'imdb': imdb, 'tmdb': int(tmdb) if tmdb not in (None, '', 'None', '0', 0) else None}}, 'progress': percent}
		else:
			post = {
				'show': {
					'ids': {'imdb': imdb, 'tmdb': int(tmdb) if tmdb not in (None, '', 'None', '0', 0) else None, 'tvdb': int(tvdb) if tvdb not in (None, '', 'None', '0', 0) else None},
					'season': {'number': int(season) if season not in (None, '', 'None') else 1,
						'episode': {'number': int(episode) if episode not in (None, '', 'None') else 1}}
				},
				'progress': percent
			}
		return get_request(endpoint, post=post)
	except: log_utils.error()
	return None

def scrobbleStart(media_type, title='', tvshowtitle='', year='0', imdb='', tmdb='', tvdb='', season='', episode='', watched_percent=0):
	try:
		_scrobble('/scrobble/start', media_type, imdb, tmdb, tvdb, season, episode, watched_percent)
	except: log_utils.error()

def scrobbleMovie(title, year, imdb, tmdb, watched_percent):
	try:
		result = _scrobble('/scrobble/pause', 'movie', imdb, tmdb, '', '', '', watched_percent)
		if result is not None and getSetting('scrobble.notify') == 'true':
			control.notification(message=40657)
		from datetime import datetime as _dt
		paused_at = _dt.utcnow().strftime('%Y-%m-%dT%H:%M:%S.000Z')
		mdbsync.upsert_bookmark(title=title or '', imdb=str(imdb) if imdb else '', tmdb=str(tmdb) if tmdb else '', percent_played=str(watched_percent), paused_at=paused_at)
		control.trigger_widget_refresh()
		log_utils.log('MDBList Scrobble Movie. imdb: %s percent: %s' % (imdb, watched_percent), level=log_utils.LOGDEBUG)
	except: log_utils.error()

def scrobbleEpisode(tvshowtitle, year, imdb, tmdb, tvdb, season, episode, watched_percent):
	try:
		result = _scrobble('/scrobble/pause', 'episode', imdb, tmdb, tvdb, season, episode, watched_percent)
		if result is not None and getSetting('scrobble.notify') == 'true':
			control.notification(message=40657)
		from datetime import datetime as _dt
		paused_at = _dt.utcnow().strftime('%Y-%m-%dT%H:%M:%S.000Z')
		mdbsync.upsert_bookmark(tvshowtitle=tvshowtitle or '', imdb=str(imdb) if imdb else '', tmdb=str(tmdb) if tmdb else '', tvdb=str(tvdb) if tvdb else '', season=str(season) if season is not None else '', episode=str(episode) if episode else '', percent_played=str(watched_percent), paused_at=paused_at)
		control.trigger_widget_refresh()
		log_utils.log('MDBList Scrobble Episode. imdb: %s S%sE%s percent: %s' % (imdb, season, episode, watched_percent), level=log_utils.LOGDEBUG)
	except: log_utils.error()

def _remove_playback_progress(ids, season=None, episode=None):
	if not ids: return False
	items = get_request('/sync/playback')
	if not isinstance(items, list): return False
	targets = []
	for item in items:
		is_episode = item.get('type') == 'episode'
		if is_episode != (season not in (None, '', 'None') or episode not in (None, '', 'None')): continue
		media = item.get('show' if is_episode else 'movie') or {}
		remote_ids = media.get('ids') or {}
		shared = [k for k in ('tmdb', 'imdb', 'tvdb') if ids.get(k) and remote_ids.get(k)]
		if not shared or str(remote_ids[shared[0]]) != str(ids[shared[0]]): continue
		ep = item.get('episode') or {}
		if season not in (None, '', 'None') and int(ep.get('season', -1)) != int(season): continue
		if episode not in (None, '', 'None') and int(ep.get('number', -1)) != int(episode): continue
		targets.append(item['id'])
	for playback_id in targets:
		if get_request('/scrobble/clear', post={'id': playback_id}) is None: return False
	return True


def finishProgressRemoval(succeeded, total):
	if succeeded < total:
		control.notification(title='MDBList', message='Removed playback progress for %s of %s items. Some requests failed; their local progress was retained.' % (succeeded, total))
	return succeeded == total


def scrobbleReset(imdb, tmdb='', tvdb='', season=None, episode=None, refresh=False, clear_local=True, already_watched=False, completed=False):
	if not getMDBListCredentialsInfo(): return False
	try:
		ids = {k: v for k, v in {'imdb': imdb, 'tmdb': int(tmdb) if tmdb not in (None, '', 'None', '0', 0) else None, 'tvdb': int(tvdb) if tvdb not in (None, '', 'None', '0', 0) else None}.items() if v}
		is_episode = episode not in (None, '', 'None')
		if not completed and not _remove_playback_progress(ids, season, episode):
			if refresh: control.notification(title='MDBList', message='Failed to remove MDBList playback progress')
			return False
		if completed and not already_watched and (is_episode or season in (None, '', 'None')):
			result = _post_sync_watched(show_ids=ids, seasons_dict={int(season) if season else 1: [int(episode)]}) if is_episode else _post_sync_watched(movies=[ids])
			if result is None: return False
		if clear_local:
			if is_episode: mdbsync.delete_bookmark(imdb, tvdb or '', season if season is not None else '', episode, tmdb=tmdb)
			elif season not in (None, '', 'None'): mdbsync.delete_bookmarks_for_season(imdb, tvdb or '', season)
			else: mdbsync.delete_bookmark(imdb, tvdb or '', '', '', tmdb=tmdb)
		sync_playbackProgress(forced=True)
		_clr_episode_progress_cache()
		control.trigger_widget_refresh()
		if refresh: control.refresh()
		if getSetting('scrobble.notify') == 'true': control.notification(title='MDBList', message='Successfully Removed MDBList playback progress')
		return True
	except:
		log_utils.error()
		return False


def sync_playbackProgress(forced=False):
	try:
		items = get_request('/sync/playback')
		if items is None: return
		server_ids = set()
		for i in items:
			resume_id = str(i.get('id', ''))
			server_ids.add(resume_id)
			percent_played = str(i.get('progress', '0'))
			paused_at = i.get('paused_at', '')
			if i.get('type') == 'episode':
				show_ids = (i.get('show') or {}).get('ids', {})
				ep = i.get('episode') or {}
				tvshowtitle = (i.get('show') or {}).get('title', '')
				title = ep.get('title', '')
				imdb = str(show_ids.get('imdb', '') or '')
				tmdb = str(show_ids.get('tmdb', '') or '')
				tvdb = str(show_ids.get('tvdb', '') or '')
				season = str(ep.get('season', ''))
				episode = str(ep.get('number', ''))
				mdbsync.upsert_bookmark(tvshowtitle=tvshowtitle, title=title, resume_id=resume_id, imdb=imdb, tmdb=tmdb, tvdb=tvdb, season=season, episode=episode, percent_played=percent_played, paused_at=paused_at)
			else:
				movie_ids = (i.get('movie') or {}).get('ids', {})
				title = (i.get('movie') or {}).get('title', '')
				imdb = str(movie_ids.get('imdb', '') or '')
				tmdb = str(movie_ids.get('tmdb', '') or '')
				mdbsync.upsert_bookmark(title=title, resume_id=resume_id, imdb=imdb, tmdb=tmdb, percent_played=percent_played, paused_at=paused_at)
		mdbsync.delete_synced_bookmarks_not_in(server_ids)
	except: log_utils.error()

def removeWatchlistItems(media_type, imdb_list):
	"""Remove items from MDBList watchlist. media_type: 'movies' or 'shows'. imdb_list: list of IMDb IDs."""
	if not imdb_list: return
	try:
		import json as _json
		total_items = len(imdb_list)
		if media_type == 'movies':
			post = _json.dumps({'movies': [{'imdb': i} for i in imdb_list]})
			table = 'movies_watchlist'
		else:
			post = _json.dumps({'shows': [{'imdb': i} for i in imdb_list]})
			table = 'shows_watchlist'
		response = session.post('%s/watchlist/items/remove' % mdblist_baseurl, data=post, headers=headers, timeout=20)
		if response.status_code == 200:
			mdbsync.delete_watchList_items(imdb_list, table, col_name='imdb')
			control.trigger_widget_refresh()
			control.notification(title='MDBList Watchlist Manager',
				message='Successfully Removed %s Item%s' % (total_items, 's' if total_items > 1 else ''))
		else:
			control.notification(title='MDBList', message='Error: %s' % response.text)
	except: log_utils.error()

def force_mdblistSync():
	if not control.yesnoDialog(control.lang(32056), '', ''): return
	dialog = control.progressDialog
	dialog().create(control.addonName(), 'Preparing MDBList sync...')
	try:
		clr_mdb = {'mdb_watched_movies': True, 'mdb_watched_episodes': True, 'movies_watchlist': True, 'shows_watchlist': True, 'watched': True}
		mdbsync.delete_mdb_tables(clr_mdb)
		dialog.update(0, 'Syncing watchlist...')
		sync_watch_list(forced=True)
		dialog.update(50, 'Syncing watched history...')
		sync_watchedProgress(forced=True)
	finally:
		dialog.close()
	control.notification(message='Forced MDBList Sync Complete')


def _post_sync_watched(movies=None, show_ids=None, seasons_dict=None, watch_time=None):
	try:
		if watch_time: now = watch_time
		else: now = __import__('datetime').datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.000Z')
		post = {}
		if movies:
			post['movies'] = [
				{'ids': {'imdb': m.get('imdb'), 'tmdb': int(m['tmdb']) if m.get('tmdb') else None},
				 'watched_at': now}
				for m in movies
			]
		if show_ids:
			show_entry = {
				'ids': {
					'imdb': show_ids.get('imdb'),
					'tmdb': int(show_ids['tmdb']) if show_ids.get('tmdb') else None,
					'tvdb': int(show_ids['tvdb']) if show_ids.get('tvdb') else None
				},
				'watched_at': now
			}
			if seasons_dict is not None:
				seasons = []
				for sn, eps in seasons_dict.items():
					if eps is None:
						seasons.append({'number': sn, 'watched_at': now})
					elif eps:
						seasons.append({'number': sn, 'episodes': [{'number': en, 'watched_at': now} for en in eps]})
				if seasons:
					show_entry['seasons'] = seasons
					del show_entry['watched_at']
			post['shows'] = [show_entry]
		if not post: return None
		result = get_request('/sync/watched', post=post)
		if isinstance(result, dict) and (result.get('error') or any((result.get('not_found') or {}).values())): return None
		return result
	except: log_utils.error()
	return None


def markMovieAsWatched(imdb, tmdb=''):
	try:
		if _post_sync_watched(movies=[{'imdb': imdb, 'tmdb': tmdb}]) is None: return False
		mdbsync.upsert_watched_movie(imdb=imdb, tmdb=str(tmdb),
			last_watched_at=__import__('datetime').datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.000Z"))
		mdbsync.cache_delete(mdbsync._hash_function(syncMovies, ()))
		log_utils.log('MDBList markMovieAsWatched imdb: %s' % imdb, level=log_utils.LOGDEBUG)
		return True
	except: log_utils.error()

def markMovieAsNotWatched(imdb):
	try:
		result = get_request('/sync/watched/remove', post={'movies': [{'ids': {'imdb': imdb}}]})
		if result is None or (isinstance(result, dict) and (result.get('error') or any((result.get('not_found') or {}).values()))): return False
		mdbsync.delete_watched_movie(imdb)
		mdbsync.cache_delete(mdbsync._hash_function(syncMovies, ()))
		return True
	except: log_utils.error()

def markEpisodeAsWatched(imdb, tvdb, season, episode, tmdb=''):
	try:
		result = _post_sync_watched(show_ids={'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb},
			seasons_dict={int(season) if season else 1: [int(episode) if episode else 1]})
		if result is None:
			log_utils.log('MDBList markEpisodeAsWatched failed: imdb=%s S%sE%s' %
				(imdb, season, episode), level=log_utils.LOGDEBUG)
			return False
		mdbsync.upsert_watched_episode(show_imdb=imdb, show_tvdb=str(tvdb), season=season, episode=episode,
			last_watched_at=__import__('datetime').datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.000Z"))
		mdbsync.cache_delete(mdbsync._hash_function(syncTVShows, ()))
		_clr_episode_progress_cache()
		log_utils.log('MDBList markEpisodeAsWatched imdb: %s S%sE%s' %
			(imdb, season, episode), level=log_utils.LOGDEBUG)
		return True
	except: log_utils.error()

def markEpisodeAsNotWatched(imdb, tvdb, season, episode):
	try:
		result = get_request('/sync/watched/remove', post={'shows': [{'ids': {'imdb': imdb, 'tvdb': int(tvdb) if tvdb not in (None, '', 'None', '0', 0) else None}, 'seasons': [{'number': int(season), 'episodes': [{'number': int(episode)}]}]}]})
		if result is None or (isinstance(result, dict) and (result.get('error') or any((result.get('not_found') or {}).values()))): return False
		mdbsync.delete_watched_episode(imdb, season, episode)
		mdbsync.cache_delete(mdbsync._hash_function(syncTVShows, ()))
		return True
	except: log_utils.error()

def markTVShowAsWatched(imdb, tvdb, tmdb=''):
	try:
		if _post_sync_watched(show_ids={'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb}) is None: return False
		now = __import__('datetime').datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.000Z')
		from resources.lib.database import cache as _cache
		from resources.lib.indexers import tmdb as _tmdb
		try:
			if not tmdb:
				res = _cache.get(_tmdb.TVshows().IdLookup, 96, imdb, tvdb)
				if res: tmdb = str(res.get('id', ''))
		except: pass
		if tmdb:
			try:
				meta = _cache.get(_tmdb.TVshows().get_showSeasons_meta, 96, tmdb)
				for s_item in (meta or {}).get('seasons', []):
					sn = int(s_item.get('season_number', 0))
					ec = int(s_item.get('episode_count', 0))
					if sn > 0 and ec > 0:
						for en in range(1, ec + 1):
							mdbsync.upsert_watched_episode(show_imdb=imdb, show_tvdb=str(tvdb),
								show_tmdb=str(tmdb), season=sn, episode=en, last_watched_at=now)
			except: pass
		_post_sync_watched(show_ids={'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb})
		mdbsync.cache_delete(mdbsync._hash_function(syncTVShows, ()))
		return True
	except: log_utils.error()

def markTVShowAsNotWatched(imdb, tvdb):
	try:
		result = get_request('/sync/watched/remove', post={'shows': [{'ids': {'imdb': imdb, 'tvdb': int(tvdb) if tvdb not in (None, '', 'None', '0', 0) else None}}]})
		if result is None or (isinstance(result, dict) and (result.get('error') or any((result.get('not_found') or {}).values()))): return False
		episodes = mdbsync.get_watched_episodes()
		# See syncSeasons() above: MDBList's local rows never populate show_tvdb (always
		# ''), so matching on an empty tvdb matched every other show's rows too and wiped
		# the entire local watched-episode table on a single unwatch — only match a given
		# id when it's actually non-empty.
		for (si, st, sv, s, e) in episodes:
			if (imdb and si == imdb) or (tvdb and sv == tvdb):
				mdbsync.delete_watched_episode(si, s, e)
		mdbsync.cache_delete(mdbsync._hash_function(syncTVShows, ()))
		return True
	except: log_utils.error()

def markSeasonAsWatched(imdb, tvdb, season, tmdb=''):
	try:
		if _post_sync_watched(show_ids={'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb},
			seasons_dict={int(season): None}) is None: return False
		now = __import__('datetime').datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.000Z')
		season = int(season)
		from resources.lib.database import cache as _cache
		from resources.lib.indexers import tmdb as _tmdb
		tmdb_id = ''
		try:
			res = _cache.get(_tmdb.TVshows().IdLookup, 96, imdb, tvdb)
			if res: tmdb_id = str(res.get('id', ''))
		except: pass
		if tmdb_id:
			try:
				raw = _cache.get(_tmdb.TVshows().get_season_request, 96, tmdb_id, season)
				for ep in (raw or {}).get('episodes', []):
					en = int(ep.get('episode_number', 0))
					if en > 0:
						mdbsync.upsert_watched_episode(show_imdb=imdb, show_tvdb=str(tvdb),
							show_tmdb=str(tmdb), season=season, episode=en, last_watched_at=now)
			except: pass
		mdbsync.cache_delete(mdbsync._hash_function(syncTVShows, ()))
		return True
	except: log_utils.error()

def markSeasonAsNotWatched(imdb, tvdb, season):
	try:
		result = get_request('/sync/watched/remove', post={'shows': [{'ids': {'imdb': imdb, 'tvdb': int(tvdb) if tvdb not in (None, '', 'None', '0', 0) else None}, 'seasons': [{'number': int(season)}]}]})
		if result is None or (isinstance(result, dict) and (result.get('error') or any((result.get('not_found') or {}).values()))): return False
		episodes = mdbsync.get_watched_episodes()
		for (si, st, sv, s, e) in episodes:
			if ((imdb and si == imdb) or (tvdb and sv == tvdb)) and int(s) == int(season):
				mdbsync.delete_watched_episode(si, s, e)
		mdbsync.cache_delete(mdbsync._hash_function(syncTVShows, ()))
		return True
	except: log_utils.error()

def update_syncMovies(imdb, remove_id=False):
	try:
		if remove_id: markMovieAsNotWatched(imdb)
		else: markMovieAsWatched(imdb)
		cachesyncMovies(timeout=0)
	except: log_utils.error()

def watch(content_type, name, imdb=None, tvdb=None, tmdb=None, season=None, episode=None, refresh=True):
	if content_type != 'movie' and tmdb:
		from resources.lib.modules import episode_mapping, anthology_tracking
		if episode_mapping.supported(tmdb):
			return anthology_tracking.manager_write('mdblist', tmdb, season, episode, False, refresh)
	control.busy()
	success = False
	if content_type == 'movie':
		success = markMovieAsWatched(imdb, tmdb or '')
		if success: cachesyncMovies(timeout=0)
	elif content_type == 'tvshow':
		success = markTVShowAsWatched(imdb, tvdb, tmdb or '')
		if success: cachesyncTV(imdb, tvdb)
	elif content_type == 'season':
		success = markSeasonAsWatched(imdb, tvdb, season, tmdb or '')
		if success: cachesyncTV(imdb, tvdb)
	elif content_type == 'episode':
		success = markEpisodeAsWatched(imdb, tvdb, season, episode, tmdb or '')
		if success:
			cachesyncTV(imdb, tvdb)
			_clr_episode_progress_cache()
	control.hide()
	if refresh: control.refresh()
	control.trigger_widget_refresh()
	if season and not episode: name = '%s-Season%s...' % (name, season)
	if season and episode: name = '%s-S%sxE%02d...' % (name, season, int(episode))
	if getSetting('services.general.notifications') == 'true':
		if success is True: control.notification(title='MDBList', message=getLS(40641) % ('[COLOR %s]%s[/COLOR]' % (highlightColor, name)))
		else: control.notification(title='MDBList', message=getLS(40640) % ('[COLOR %s]%s[/COLOR]' % (highlightColor, name)))
	if not success: log_utils.log(getLS(40640) % name + ' : ids={imdb: %s, tvdb: %s}' % (imdb, tvdb), __name__, level=log_utils.LOGDEBUG)

def unwatch(content_type, name, imdb=None, tvdb=None, tmdb=None, season=None, episode=None, refresh=True):
	if content_type != 'movie' and tmdb:
		from resources.lib.modules import episode_mapping, anthology_tracking
		if episode_mapping.supported(tmdb):
			return anthology_tracking.manager_write('mdblist', tmdb, season, episode, True, refresh)
	control.busy()
	success = False
	if content_type == 'movie':
		success = markMovieAsNotWatched(imdb)
		if success: cachesyncMovies(timeout=0)
	elif content_type == 'tvshow':
		success = markTVShowAsNotWatched(imdb, tvdb)
		if success: cachesyncTV(imdb, tvdb)
	elif content_type == 'season':
		success = markSeasonAsNotWatched(imdb, tvdb, season)
		if success: cachesyncTV(imdb, tvdb)
	elif content_type == 'episode':
		success = markEpisodeAsNotWatched(imdb, tvdb, season, episode)
		if success: cachesyncTV(imdb, tvdb)
	control.hide()
	if refresh: control.refresh()
	control.trigger_widget_refresh()
	if season and not episode: name = '%s-Season%s...' % (name, season)
	if season and episode: name = '%s-S%sxE%02d...' % (name, season, int(episode))
	if getSetting('services.general.notifications') == 'true':
		if success is True: control.notification(title='MDBList', message=getLS(40643) % ('[COLOR %s]%s[/COLOR]' % (highlightColor, name)))
		else: control.notification(title='MDBList', message=getLS(40642) % ('[COLOR %s]%s[/COLOR]' % (highlightColor, name)))

def add_to_list(list_id, data):
	url = '/watchlist/items/add' if list_id == 'watchlist' else '/lists/%s/items/add' % list_id
	result = get_request(url, post=data)
	if result['added']['movies'] + result['added']['shows'] == 0: return control.notification(title='MDBList', message=f'Remove from {list_id} MDBList Userlist')
	control.notification(title='MDBList', message=f'Add to {list_id} MDBList Userlist')
	# mdbl_sync_activities()
	return# result

def import_personal():
	def get_list_items(params):
		tmdb_media_converter = {'movie': 'movie', 'tvshow': 'tv', 'show': 'tv'}
		new_contents = []
		new_contents_append = new_contents.append
		result = []#personal_lists_cache.get_list(params['name'], params['author'], update_seen=params.get('update_seen', True), seen=params.get('seen', True))
		result = cache.get(tmdb_indexer().get_list_details, 8, params.get('id'))
		for item in result:
			try:
				media_type = item.get('type')
				media_id = item['id']
				if media_id in (None, 'None', ''): continue
				new_contents_append({"tmdb": f"{media_id}"})
			except: continue
		return new_contents

	from resources.lib.indexers.tmdb import TMDb as tmdb_indexer
	from resources.lib.database import cache
	try:
		tmdb_session_id = getSetting('tmdb.sessionid')
		if tmdb_session_id == '': raise Exception()
		contents = cache.get(tmdb_indexer().get_user_lists, 8)
		for i in range(len(contents)): contents[i].update({'image': 'tmdb.png', 'icon': 'DefaultVideoPlaylists.png', 'action': 'tmdbTvshows'})
	except: log_utils.error()
	# log_utils.log(f'contents: {repr(contents)}')
	list_items = [('%s [I](x%d)[/I]' % (item['name'], item['number_of_items'] if 'number_of_items' in item else '')) for item in contents]
	# log_utils.log(f'list_items: {repr(list_items)}')
	select = control.selectDialog(list_items, 'Select item to import...')
	# log_utils.log(f'select: {repr(select)}')
	if select == -1: return
	params = contents[select]
	# log_utils.log(f'params1: {repr(params)}')
	new_contents = get_list_items(params)
	# log_utils.log(f'contents: {len(new_contents)} {repr(new_contents)}')
	if len(new_contents):
		# items = cache.get(getMDBUserList, 8, 'show', False)
		items = getMDBUserList('show', False)
		# log_utils.log(f'items: {len(items)} {repr(items)}')
		list_items = [('%s [I](x%d)[/I]' % (item['label'], item.get('params').get('list_count'))) for item in items]
		# log_utils.log(f'list_items: {repr(list_items)}')
		select = control.selectDialog(list_items, 'Select item to import...')
		# log_utils.log(f'select: {repr(select)}')
		if select == -1: return
		params = items[select]
		# log_utils.log(f'params1: {repr(params)}')
		list_id = params.get('params').get('list_id')
		data = {"shows": new_contents}
		# log_utils.log(f'list_id: {repr(list_id)} {repr(data)}')
		add_to_list(list_id, data)
	return

def bulk_Watched():
	try:
		mode = 'drop'
		import random
		movie = [{'media_id': '10020', 'title': 'Beauty and the Beast', 'last_played': '2016-07-09T17:54:00.000Z'}, ] 
		tvshow = [{'media_id': '100010', 'season': 3, 'episode': 13, 'title': 'Big Sky', 'last_played': '2023-02-04T05:44:00.000Z', 'total_played': 47},] 
		hidentvshow = [253, 655, 1706, 4613, 2046, 1891, 1398, 4629, 2290, 1972, 578, 2942, 8358, 3764, 7482, 1705, 44652, 57092, 2919, 1405, 1396, 32868, 59580, 51019, 15819, 113852, 58474, 60936, 1409, 39497, 31631, 21510, 5920, 2691, 45094, 62216, 34967, 47318, 40268, 33907, 60855, 61550, 62088, 39702, 1411, 18779, 62336, 60972, 64685, 19885, 67684, 66545, 61933, 62776, 39340, 70215, 48865, 62425, 73467, 66912, 71806, 74140, 77601, 71181, 70721, 39269, 64353, 69889, 62822, 62858, 71411, 66871, 65386, 66857, 80307, 1425, 60802, 83059, 64555, 66282, 66185, 64199, 67419, 2947, 1418, 1399, 67026, 67232, 90665, 73117, 86136, 1424, 79352, 1415, 67744, 69541, 91725, 1403, 37680, 93166, 74712, 62017, 61378, 60573, 66761, 62560, 81292, 96481, 61692, 1407, 61056, 71146, 48866, 61387, 44217, 62649, 64254, 66676, 60585, 67198, 62286, 37759, 88118, 70523, 79593, 48891, 67384, 80968, 39852, 71446, 124271, 62674, 131927, 63639, 71769, 17610, 118357, 129495, 63333, 118815, 60699, 51704, 33025, 57276, 62084, 46533, 61112, 1401, 60574, 123271, 69740, 102395, 67067, 87739, 87108, 66789, 96488, 32573, 34415, 110695, 81358, 76796, 95665, 102016, 81940, 85021, 83851, 122066, 130738, 1402, 81946, 114201, 127643, 71994, 100010, 4569, 71712, 82856, 71694, 93287, 76331, 93812, 46952, 73375, 60059, 68006, 198085, 203762, 62852, 106734, 4614, 65494, 92830, 71728, 60948, 156029, 70128, 116135, 70484, 1395, 223253, 154359, 124416, 71789, 214259, 73586, 118189, 873, 71722, 49010, 79622, 72745, 76231, 86428, 85949, 229403, 210916, 32692, 217211, 206586, 157744, 1421, 46296, 18653, 125282, 78191, 69478, 153657, 62982, 138971]
		data = tvshow
		not_donw= []
		import json as _djson
		from datetime import datetime as _dt
		######### add hiden items
		if mode == 'drop':
			id_lists = []
			utc_now = _dt.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
			for chunk in hidentvshow:  # Process chunks sequentially to avoid request bursts
				# log_utils.log(f'chunk: {repr(chunk)}')
				# data = {'shows': [{'ids': {'tmdb': chunk}}]}
				_dpost = {'ids': {'tmdb': chunk}, 'dropped_at': utc_now}
				id_lists.append(_dpost)
				# if type(post) == dict or type(post) == list: post = _djson.dumps(post)
			post = {"shows": id_lists}
			log_utils.log(f'watched post = {repr(post)}')
			results = get_request('/sync/dropped', post=post)
			# sleep_time = random.randint(400, 1100)
			# control.sleep(sleep_time)
			log_utils.log(f'results = {repr(results)}')
		elif mode == 'watched': ######### mark watch
			id_lists = []
			for chunk in data:  # Process chunks sequentially to avoid request bursts
				# log_utils.log(f'{repr(chunk.get("media_id"))} chunk: {repr(chunk.get("last_played"))}, ')
				tmdb = str(chunk['media_id']) if chunk.get('media_id') else ''
				# post = {"shows": [{"tmdb": tmdb}]}
				show_entry = {
					"tmdb": tmdb,
					'ids': {
						'imdb': chunk.get('imdb') if chunk.get('imdb') else '',
						'tmdb': tmdb,
						'tvdb': str(chunk['tvdb']) if chunk.get('tvdb') else ''}
					, 'watched_at': chunk.get("last_played")}
				# post['shows'] = [show_entry]
				id_lists.append(show_entry)
				# if type(post) == dict or type(post) == list: post = _djson.dumps(post)
			post = {"shows": id_lists}
			log_utils.log(f'watched post = {repr(post)}')
			# results = get_request('/sync/watched', post=post)
			# log_utils.log(f'results = {repr(results)}')
		elif mode == 'add': ######### add to watchlist
			id_lists = []
			for chunk in data:  # Process chunks sequentially to avoid request bursts
				# log_utils.log(f'{repr(chunk.get("media_id"))} chunk: {repr(chunk.get("last_played"))}, ')
				# tmdb = int(chunk['media_id']) if chunk.get('media_id') else None
				# id_lists.append({"tmdb": f"{chunk.get('media_id')}"})
				id_lists.append({"tmdb": f"{chunk}"})
			post = {"shows": id_lists}
			log_utils.log(f'add post = {repr(post)}')
			# results = get_request('/watchlist/items/add', post=post)
			add_to_list('watchlist', post)
			# log_utils.log(f'results = {repr(results)}')
	except: log_utils.error()
	log_utils.log(f'not_donw {repr(not_donw)}')