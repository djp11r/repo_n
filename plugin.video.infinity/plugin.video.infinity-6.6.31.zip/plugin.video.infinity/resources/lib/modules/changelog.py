# -*- coding: utf-8 -*-
"""
	Umbrella Add-on
"""

from resources.lib.modules.control import addonPath, addonVersion, joinPath, existsPath
from resources.lib.windows.textviewer import TextViewerXML


def get(name, full=False):
	nameDict = {'Infinity': 'plugin.video.infinity', 'OpenScrapers': 'script.module.openscrapers'}
	addon_path = addonPath(nameDict[name])
	if not full: changelog_file = joinPath(addon_path, 'changelog.txt')
	else:
		changelog_file = joinPath(addon_path, 'fullchangelog.txt')
	if not existsPath(changelog_file):
		from resources.lib.modules.control import notification
		return notification(message='ChangeLog File not found.')
	with open(changelog_file, mode='r', encoding='utf-8', errors='ignore') as f:
		text = f.read()
	heading = '[B]%s -  v%s - ChangeLog[/B]' % (name, addonVersion)
	windows = TextViewerXML('textviewer.xml', addonPath('plugin.video.infinity'), heading=heading, text=text)
	windows.run()
	del windows