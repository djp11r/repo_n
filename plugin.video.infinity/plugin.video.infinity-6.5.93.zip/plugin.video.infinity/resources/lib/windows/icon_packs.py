# -*- coding: utf-8 -*-
"""
	Umbrella Add-on
"""

from json import dumps as jsdumps
from urllib.parse import quote_plus
import xbmc
from resources.lib.modules.control import dialog, getHighlightColor, setting as getSetting, addonFanart
from resources.lib.windows.base import BaseDialog



class IconPacksView(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.window_id = 2050
		self.results = kwargs.get('results')
		self.selected_items = []
		self.activePack = getSetting('skinpackicons').lower()
		self.fanart = addonFanart()
		self.make_items()
		self.set_properties()

	def onInit(self):
		win = self.getControl(self.window_id)
		win.addItems(self.item_list)
		self.setFocusId(self.window_id)

	def run(self):
		self.doModal()
		self.clearProperties()
		return self.selected_items

	# def onClick(self, controlID):
		# from resources.lib.modules import log_utils
		# log_utils.log('controlID=%s' % controlID)

	def onAction(self, action):
		from resources.lib.modules import log_utils
		log_utils.log('action: %s' % str(action.getId()))
		try:
			if action in self.selection_actions:
				focus_id = self.getFocusId()
				if focus_id == 2050: # listItems
					position = self.get_position(self.window_id)
					chosen_listitem = self.item_list[position]
					if chosen_listitem.getProperty('infinity.isSelected') == 'true':
						chosen_listitem.setProperty('infinity.isSelected', '')
					else:
						chosen_listitem.setProperty('infinity.isSelected', 'true')
				elif focus_id == 2051: # OK Button
					self.close()
				elif focus_id == 2052: # Cancel Button
					self.selected_items = None
					self.close()
			elif action in self.context_actions:
				cm = []
				chosen_listitem = self.item_list[self.get_position(self.window_id)]
				packname = chosen_listitem.getProperty('infinity.title')
				downloaded = chosen_listitem.getProperty('infinity.downloaded')
				url = chosen_listitem.getProperty('infinity.downloadurl')
				active = chosen_listitem.getProperty('infinity.active')
				poster = chosen_listitem.getProperty('infinity.imageurl')
				if downloaded == '1' and active == '0' and str(packname).lower() != 'infinity':
					cm += [('[B]Set as Active Pack[/B]', 'activepack')]
					cm += [('[B]Delete Pack[/B]', 'deletepack')]
				elif downloaded == '1' and active == '0':
					cm += [('[B]Set as Active Pack[/B]', 'activepack')]
				elif downloaded == '0':
					cm += [('[B]Download Pack[/B]', 'downloadpack')]
				else:
					return
				chosen_cm_item = dialog.contextmenu([i[0] for i in cm])
				if chosen_cm_item == -1: return
				cm_action = cm[chosen_cm_item][1]
				if cm_action == 'activepack':
					from resources.lib.modules import skin_packs
					skin_packs.iconPackHandler().set_active_skin_pack(packname)
					self.close()
				elif cm_action == 'downloadpack':
					from resources.lib.modules import skin_packs
					skin_packs.iconPackHandler().download_skin_pack(packname, url, poster)
					self.close()
				elif cm_action == 'deletepack':
					self.close()
					from resources.lib.modules import skin_packs
					skin_packs.iconPackHandler().delete_skin_pack(packname, poster)
					
			elif action in self.closing_actions:
				self.selected_items = None
				self.close()


		except:
			from resources.lib.modules import log_utils
			log_utils.error()
			self.close()

	def make_items(self):
		def builder():
			for count, item in enumerate(self.results, 1):
				try:
					listitem = self.make_listitem()
					listitem.setProperty('infinity.title', item.get('name'))
					listitem.setProperty('infinity.isSelected', '')
					poster = item.get('imageurl', '')
					listitem.setProperty('infinity.poster', poster)
					listitem.setProperty('infinity.downloadurl', item.get('url'))
					listitem.setProperty('infinity.downloaded', item.get('downloaded'))
					if str(item.get('name')).lower() == self.activePack:
						listitem.setProperty('infinity.active', '1')
					else:
						listitem.setProperty('infinity.active', '0')
					yield listitem
				except:
					from resources.lib.modules import log_utils
					log_utils.error()
		try:
			self.item_list = list(builder())
			self.total_results = str(len(self.item_list))
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def set_properties(self):
		try:
			self.setProperty('infinity.highlight.color', getHighlightColor())
			self.setProperty('infinity.fanart', self.fanart)
		except:
			from resources.lib.modules import log_utils
			log_utils.error()