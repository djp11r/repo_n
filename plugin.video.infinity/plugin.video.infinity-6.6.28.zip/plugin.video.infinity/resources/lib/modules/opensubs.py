# -*- coding: utf-8 -*-
"""
	Umbrella Addon
"""
import json
import os
import re
import requests
from urllib.parse import quote
from urllib.request import urlopen, Request
from traceback import print_exc
from difflib import SequenceMatcher
import shutil
from zipfile import ZipFile

# from resources.lib.modules import control
from resources.lib.modules.control import setting, setSetting, okDialog, openSettings, homeWindow, notification, sleep, getUmbrellaVersion, getLangString, temppath
from resources.lib.modules.log_utils import log, error
from resources.lib.database.cache import cache_get, cache_insert
from resources.lib.modules.source_utils import seas_ep_filter
from resources.lib.modules.cleantitle import get_sc
from openscrapers.modules.client import UserAgent
base_url = 'https://api.opensubtitles.com/api/v1'
api_key = 'cQBWQwPugvGVDrpdU9MDRlvdfcu4WNTx'
version = getUmbrellaVersion()
usefull_lang = ('en', 'eng', 'hi')


class Opensubs():
	def __init__(self):
		self.username = setting('opensubsusername', 'GKobu')
		self.password = setting('opensubspassword', 'GKoBu2017')
		self.jwt_token = setting('opensubstoken')
		self.headers = {'Api-Key': api_key, 'User-Agent': 'Umbrella v' + version, 'Content-Type': 'application/json', }
		self.headers1 = {'User-Agent': 'infinite v0.1'}
		self.headers2 = {'User-Agent': UserAgent}
		self.highlight_color = setting('highlight.color')
		self.data = {"username": self.username, "password": self.password, }
		if not self.jwt_token: self.jwt_token = self.get_jwt_token()

	def get_jwt_token(self):
		url = base_url + '/login'
		response = requests.post(url, headers=self.headers, json=self.data)
		log(f'get_jwt_token headers: {self.headers} self.data: {self.data} response.json(): {response}')
		if response.status_code == 200:
			response = response.json()
			log(f'get_jwt_token response: {repr(response)}')
			#setSetting('opensubstoken', response.get('token'))
			return response
		else: return False

	def auth(self):
		if not self.username or not self.password: return False
		if self.jwt_token:
			url = f'{base_url}/infos/user'
			headers2 = dict(self.headers, **{'Authorization': self.jwt_token, })
			response = requests.get(url, headers=headers2)
			if response.status_code == 200: return True
			else: return self.get_jwt_token()
		else: self.get_jwt_token()

	def getSubs(self, title, imdb, year, season=None, episode=None):
		try:
			language = 'en'#xbmc.convertLanguage(setting('subtitles.lang.1'), xbmc.ISO_639_1)
			if season: url = f'{base_url}/subtitles?imdb_id={imdb}&season_number={season}&episode_number={episode}&languages={language}'
			else: url = f'{base_url}/subtitles?imdb_id={imdb}&languages={language}{f"&year={year}" if year else ""}'
			# sub_file_name = f'{title} S{season} E{episode}' if season else f'{title}'
			# srtFile = os.path.join(temppath, f'{get_sc(sub_file_name)}.srt')
			# if existsPath(srtFile): return srtFile
			headers = dict(self.headers, **{'Authorization': self.jwt_token, })
			# log(f'getSubs headers: {headers}\n Imdb:{imdb} Season: {season} Episode: {episode} Language: {language}', level=1)
			try:
				response = requests.get(url, headers=headers)
				jresponse = response.json()
				dresponse = jresponse['data']
				results = []
				for count, x in enumerate(dresponse):
					sub_lang = dresponse[count]['attributes'].get('language')
					if sub_lang not in usefull_lang: continue
					fileName = dresponse[count]['attributes'].get('files')[0].get('file_name')
					fileID = dresponse[count]['attributes'].get('files')[0].get('file_id')
					if season and seas_ep_filter(season, episode, fileName): seq = SequenceMatcher(None, title.lower(), fileName.lower())
					else: seq = SequenceMatcher(None, title.lower(), fileName.lower())
					# log(f'seq: {seq} title.lower(): {title.lower()} fileName.lower(): {fileName.lower()}')
					if seq: results.append({'fileName': fileName, 'fileID': fileID, 'ratio': seq.ratio()})
				results.sort(key=lambda i: i['ratio'], reverse=True)
				if results: return results
			except: error(f'{__name__} imdb: {imdb} url: {url} \nresponse: {repr(response.text)}')
			if not results:
				log(f'getSubs imdb: {imdb} url: {url} \ndresponse: {dresponse}')
				results = []
				result = self.search(title, imdb, season, episode, language)
				try:
					log(f'type: {type(result)} result: {repr(result)}')
					result = result.replace('"isHearingImpaired":false,', '').replace('"isHearingImpaired":true,', '')
					result = eval(result)
					for item in result:
						results.append({'fileName': item.get('media'), 'fileID': item.get('url'), 'ratio': 1})
					# log(f'chosen_sub: {chosen_sub}')
					# if not chosen_sub: return
					# DownloadLink = chosen_sub.get('url') or chosen_sub.get('ZipDownloadLink')
					# log(f'DownloadLink: {DownloadLink}')
					if results: return results
				except: error(f'{__name__} result: {result}')
				try:
					if season:
						try: subfilter = [{'fileName': i.get('MovieReleaseName') or i.get('MovieName'), 'fileID': i.get('fileID') or i.get('ZipDownloadLink'), 'ratio': SequenceMatcher(None, title.lower(), (i.get('MovieReleaseName') or i.get('MovieName')).lower()).ratio()} for i in result if title.lower() in (i.get('MovieReleaseName') or i.get('MovieName')).lower() and str(season) == i.get('SeriesSeason') and str(episode) == i.get('SeriesEpisode') and i.get('SubLanguageID') in usefull_lang and i.get('SubSumCD') == '1'][0]
						except: log(f'error result: {result}')
					if not subfilter:
						try: subfilter = [{'fileName': i.get('MovieReleaseName') or i.get('MovieName'), 'fileID': i.get('fileID') or i.get('ZipDownloadLink'), 'ratio': SequenceMatcher(None, title.lower(), (i.get('MovieReleaseName') or i.get('MovieName')).lower()).ratio()} for i in result if title.lower() in (i.get('MovieReleaseName') or i.get('MovieName')).lower() and i.get('SubLanguageID') in usefull_lang and i.get('SubSumCD') == '1'][0]
						except: log(f'error result: {result}')
						# log(f'2subfilter: {subfilter}')
					for item in subfilter:
						results.append({'fileName': item.get('fileName'), 'fileID': item.get('fileID'), 'ratio': 1})
					# DownloadLink = chosen_sub.get('fileID') or chosen_sub.get('ZipDownloadLink')
					# log(f'DownloadLink: {DownloadLink}')
					return results
				except: error(f'{__name__} error result: {result}')
		except:
			results = []
			return results

	def downloadSubs(self, fileID):
		try:
			try:
				if fileID.startswith('http'): return fileID
			except:
				# error()
				url = f'{base_url}/download'
				headers = dict(self.headers, **{'Authorization': self.jwt_token, })
				# log(f'downloadSubs headers: {headers}')
				data = {"file_id": fileID, }
				response = requests.post(url, headers=headers, json=data)
				response = response.json()
				link = response.get('link')
				log(f'OpenSubs Download Link: {link}', level=1)
				return link
		except:
			error()
			return None

	def getAccountStatus(self):
		try:
			if not self.username or not self.password: return okDialog(title=40503, message='Please enter username and password.')
			response = self.get_jwt_token()
			responseUser = response.get('user')
			responseToken = response.get('token')
			username = self.username
			a_downloads = responseUser.get('allowed_downloads')
			#setSetting('opensubstoken', responseToken)
			openSettings('11.0', 'plugin.video.infinity')
			return okDialog(title=40503, message=getLangString(40508) % (username, a_downloads))
		except:
			error()
			return okDialog(title=40503, message='Error checking opensubs. Please check use your username and not your email to authenticate and password. Press Ok to save and try checking again.')

	def revokeAccess(self):
		try:
			homeWindow.setProperty('infinity.updateSettings', 'false')
			setSetting('opensubsusername', '')
			setSetting('opensubspassword', '')
			setSetting('opensubstoken', '')
			homeWindow.setProperty('infinity.updateSettings', 'true')
			self.jwt_token = ''
			openSettings('11.0', 'plugin.video.infinity')
		except:
			error()

	def search(self, title, imdb_id, season=None, episode=None, language='en'):
		cache_name = f'opensubtitles_{imdb_id}_{language}'
		if season: cache_name += f'_{season}_{episode}'
		if cache := cache_get(cache_name): return cache.get('value')
		if not imdb_id.startswith('tt'): imdb_id = f'tt{imdb_id}'
		url = f'https://subs.wyzie.ru/search?id={imdb_id}{f"&season={season}&episode={episode}" if season else ""}&language={language}&type=srt'
		# log(f'getSubs search url: {url}')
		response = self._get(url, headers=self.headers2, retry=True)
		if not response:
			log(f'Error subs.wyzie search url: {url}')
			url = f'https://rest.opensubtitles.org/search/imdbid-{imdb_id}/query-{quote(title)}{f"/season-{season}/episode-{episode}" if season else ""}/sublanguageid-{language}'
			response = self._get(url, headers=self.headers1, retry=True)
			if not response: return log(f'Error OpenSubtitlesAPI search url: {url}')
		response = response.text
		cache_insert(cache_name, response, expires=48)
		return response

	def download(self, url, headers):
		# log(f'download url: {url}\nfinal_path: {final_path}\nheaders: {headers}', level=1)
		# ('https://dl.opensubtitles.org/en/download/src-api/vrf-f5590bb8/subad/7258810', 'C:\\Users\\JP\\AppData\\Roaming\\Kodi\\cache\\Britannia.S01E04.WEBRip.x264-ION10.srt',)
		if 'subencoding-utf8/' in url: url = url.replace('subencoding-utf8/', '')
		# temp_zip = os.path.join(temppath, 'temp.zip')
		result = self._get(url, stream=True, retry=True, headers=headers)
		# with open(temp_zip, 'wb') as f: shutil.copyfileobj(result.raw, f)
		# with ZipFile(temp_zip, 'r') as zip_file: zip_file.extractall(temppath)
		# delete_file(temp_zip)
		# renameFile(temp_path, final_path)
		# log(f'download url: {temp_zip}\nzip_file: {zip_file}\nheaders: {headers}', level=1)
		# with open(temppath, 'r', encoding='utf-8', errors='ignore') as sub_contents:
			# file = sub_contents.read()
		# ifile = self.cleanup_subtitles(file)
		ifile = self.cleanup_subtitles(result.text)
		srtfile = os.path.join(temppath, 'tempsubs.srt')
		if ifile:
			with open(srtfile, mode='w', encoding='utf-8', errors='replace') as f:
				f.write(ifile)
		return srtfile

	def _get(self, url, stream=False, retry=False, headers=None):
		if not headers: headers = self.headers1
		response = requests.get(url, headers=headers, stream=stream)
		if '200' in str(response): return response
		elif '429' in str(response) and retry:
			notification('OpenSubtitles Rate Limited. Retrying in 10 secs..', 3500)
			sleep(10000)
			return self._get(url, stream, headers=headers)
		else: return

	def cleanup_subtitles(self, sub_contents):
		__url_regex = r'[a-z0-9][a-z0-9-]{0,5}[a-z0-9]\.[a-z0-9]{2,20}\.[a-z]{2,5}'
		fist_last_regex = r'(Support us and become|to remove all ads|Watch any video online|Free Browser extension)'
		__credit_part_regex = r'(sync|synced|fix|fixed|corrected|corrections)'
		__credit_regex = __credit_part_regex + r' ?&? ?' + __credit_part_regex + r'? by'
		all_lines = sub_contents.split('\n')
		cleaned_lines = []
		buffer = []
		garbage = False

		# if all_lines[0].strip() != '': all_lines.insert(0, '')
		if all_lines[-1].strip() != '': all_lines.append('')

		for line in all_lines:
			line = line.strip()
			if garbage and line != '': continue
			garbage = False
			line_contains_ad = (re.search(fist_last_regex, line, re.IGNORECASE) or re.search(__url_regex, line, re.IGNORECASE) or re.search(__credit_regex, line, re.IGNORECASE))

			if line_contains_ad:
				if not re.match(r'^\{\d+\}\{\d+\}', line):
					log(f'(detected ad) {line.encode("ascii", errors="ignore")}')
					garbage = True
					buffer = []
				continue

			if line == '':
				if len(buffer) > 0:
					buffer.insert(0, '')
					cleaned_lines.extend(buffer)
					buffer = []
				continue
			buffer.append(line)
		return '\n'.join(cleaned_lines)