"""Bundled network logos, independent of the selected artwork theme."""
from resources.lib.modules.control import addon_info, joinPath, transPath

_DIRECTORY = joinPath(transPath(addon_info('path')), 'resources', 'artwork', 'networks')


def network_icon(filename):
    return joinPath(_DIRECTORY, filename)
