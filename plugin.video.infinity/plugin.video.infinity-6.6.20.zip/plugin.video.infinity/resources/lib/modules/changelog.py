# -*- coding: utf-8 -*-
"""
	Umbrella Add-on
"""

from resources.lib.modules.control import addonPath, addonVersion, joinPath, existsPath
from resources.lib.windows.textviewer import TextViewerXML


def get(name):
	nameDict = {'Infinity': 'plugin.video.infinity', 'OpenScrapers': 'script.module.openscrapers'}
	addon_path = addonPath(nameDict[name])
	addon_version = addonVersion(nameDict[name])
	changelogfile = joinPath(addon_path, 'changelog.txt')
	if not existsPath(changelogfile):
		from resources.lib.modules.control import notification
		return notification(message='ChangeLog File not found.')
	with open(changelogfile, mode='r', encoding='utf-8', errors='ignore') as f:
		text = f.read()
	heading = '[B]%s -  v%s - ChangeLog[/B]' % (name, addon_version)
	windows = TextViewerXML('textviewer.xml', addonPath('plugin.video.infinity'), heading=heading, text=text)
	windows.run()
	del windows