# -*- coding: utf-8 -*-
"""
	Umbrella Add-on
"""

import xbmc
from resources.lib.modules.control import dialog, sleep, condVisibility
from resources.lib.windows.base import BaseDialog
from resources.lib.modules.control import setting as getSetting

monitor = xbmc.Monitor()


class TraktMovieProgressManagerXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.window_id = 2050
		self.results = kwargs.get('results')
		self.total_results = str(len(self.results))
		self.selected_items = []
		self.highlight_color = getSetting('highlight.color')
		self.make_items()
		self.set_properties()
		self.hasVideo = False

	def onInit(self):
		win = self.getControl(self.window_id)
		win.addItems(self.item_list)
		self.setFocusId(self.window_id)

	def run(self):
		self.doModal()
		self.clearProperties()
		return self.selected_items

	# def onClick(self, controlID):
		# from resources.lib.modules import log_utils
		# log_utils.log('controlID=%s' % controlID)

	def onAction(self, action):
		try:
			if action in self.selection_actions:
				focus_id = self.getFocusId()
				if focus_id == 2050: # listItems
					position = self.get_position(self.window_id)
					chosen_listitem = self.item_list[position]
					imdb = chosen_listitem.getProperty('infinity.imdb')
					if chosen_listitem.getProperty('infinity.isSelected') == 'true':
						chosen_listitem.setProperty('infinity.isSelected', '')
						if imdb in self.selected_items: self.selected_items.remove(imdb)
					else:
						chosen_listitem.setProperty('infinity.isSelected', 'true')
						self.selected_items.append(imdb)
				elif focus_id == 2051: # OK Button
					self.close()
				elif focus_id == 2052: # Cancel Button
					self.selected_items = None
					self.close()
				elif focus_id == 2053: # Select All Button
					for item in self.item_list:
						item.setProperty('infinity.isSelected', 'true')
						self.selected_items.append(item.getProperty('infinity.imdb'))
				elif focus_id == 2045: # Stop Trailer Playback Button
					self.execute_code('PlayerControl(Stop)')
					sleep(500)
					self.setFocusId(self.window_id)

			elif action in self.context_actions:
				cm = []
				chosen_listitem = self.item_list[self.get_position(self.window_id)]
				# media_type = chosen_listitem.getProperty('infinity.media_type')
				source_trailer = chosen_listitem.getProperty('infinity.trailer')
				if not source_trailer:
					from resources.lib.modules import trailer
					source_trailer = trailer.Trailer().worker('movie', chosen_listitem.getProperty('infinity.title'), chosen_listitem.getProperty('infinity.year'), None, chosen_listitem.getProperty('infinity.imdb'))

				if source_trailer: cm += [('[B]Play Trailer[/B]', 'playTrailer')]
				chosen_cm_item = dialog.contextmenu([i[0] for i in cm])
				if chosen_cm_item == -1: return
				cm_action = cm[chosen_cm_item][1]

				if cm_action == 'playTrailer':
					self.execute_code('PlayMedia(%s, 1)' % source_trailer)
					total_sleep = 0
					while True:
						sleep(500)
						total_sleep += 500
						self.hasVideo = condVisibility('Player.HasVideo')
						if self.hasVideo or total_sleep >= 10000: break
					if self.hasVideo:
						self.setFocusId(2045)
						while (condVisibility('Player.HasVideo') and not monitor.abortRequested()):
							self.setProgressBar()
							sleep(1000)
						self.hasVideo = False
						self.progressBarReset()
						self.setFocusId(self.window_id)
					else: self.setFocusId(self.window_id)

			elif action in self.closing_actions:
				self.selected_items = None
				if self.hasVideo: self.execute_code('PlayerControl(Stop)')
				else: self.close()
		except:
			from resources.lib.modules import log_utils
			log_utils.error()
			self.close()

	def setProgressBar(self):
		try: progress_bar = self.getControlProgress(2046)
		except: progress_bar = None
		if progress_bar is not None:
			progress_bar.setPercent(self.calculate_percent())

	def calculate_percent(self):
		return (xbmc.Player().getTime() / float(xbmc.Player().getTotalTime())) * 100

	def progressBarReset(self):
		try: progress_bar = self.getControlProgress(2046)
		except: progress_bar = None
		if progress_bar is not None:
			progress_bar.setPercent(0)

	def make_items(self):
		def builder():
			for count, item in enumerate(self.results, 1):
				try:
					if isinstance(item.get('studio'), list): 
						try: studio = str(item.get('studio')[0])
						except: studio = ''
					else: studio = str(item.get('studio', ''))
					if isinstance(item.get('genre'), list): genre = ' / '.join([i for i in item.get('genre', [])])
					else: genre = str(item.get('genre', ''))
					listitem = self.make_listitem()
					listitem.setProperty('infinity.title', item.get('title'))
					listitem.setProperty('infinity.year', str(item.get('year')))
					# labelProgress = str(round(float(item['progress'] * 100), 1)) + '%'
					labelProgress = str(round(float(item['progress']), 1)) + '%'
					listitem.setProperty('infinity.progress', '[' + labelProgress + ']')
					listitem.setProperty('infinity.isSelected', '')
					listitem.setProperty('infinity.imdb', item.get('imdb'))
					# listitem.setProperty('infinity.tmdb', item.get('tmdb'))
					listitem.setProperty('infinity.rating', str(round(float(item.get('rating', '0')), 1)))
					listitem.setProperty('infinity.trailer', item.get('trailer'))
					listitem.setProperty('infinity.studio', item.get('studio'))
					listitem.setProperty('infinity.genre', item.get('genre', ''))
					listitem.setProperty('infinity.duration', str(item.get('duration')))
					listitem.setProperty('infinity.mpaa', item.get('mpaa') or 'NA')
					listitem.setProperty('infinity.plot', item.get('plot'))
					listitem.setProperty('infinity.poster', item.get('poster', ''))
					listitem.setProperty('infinity.clearlogo', item.get('clearlogo', ''))
					listitem.setProperty('infinity.count', '%02d.)' % count)
					yield listitem
				except:
					from resources.lib.modules import log_utils
					log_utils.error()
		try:
			self.item_list = list(builder())
			self.total_results = str(len(self.item_list))
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def set_properties(self):
		try:
			self.setProperty('infinity.total_results', self.total_results)
			self.setProperty('infinity.highlight.color', self.highlight_color)
		except:
			from resources.lib.modules import log_utils
			log_utils.error()