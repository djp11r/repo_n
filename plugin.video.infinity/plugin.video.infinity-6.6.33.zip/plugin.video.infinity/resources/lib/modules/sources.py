# -*- coding: utf-8 -*-
"""
	infinity Add-on Updated 10-6-24
"""

from datetime import datetime, timedelta
from json import dumps as jsdumps, loads as jsloads
import re
import _strptime # import _strptime to workaround python 2 bug with threads
from sys import exit as sysexit
from threading import Thread
from time import time
from urllib.parse import unquote, quote_plus, urlencode, parse_qsl
import sqlite3 as database
from resources.lib.database import metacache, providerscache
from resources.lib.modules import cleandate
from resources.lib.modules import control
from resources.lib.modules import debrid
from resources.lib.modules import log_utils
from resources.lib.modules import string_tools
from resources.lib.modules import source_preferences
from resources.lib.modules.playback_metadata import normalize as normalize_playback_meta
from resources.lib.modules.source_utils import supported_video_extensions, getFileType, aliases_check
from resources.lib.cloud_scrapers import cloudSources
from resources.lib.internal_scrapers import internalSources
from resources.lib.modules.tools import manual_module_import


homeWindow = control.homeWindow
from traceback import print_exc
from resources.lib.modules.client import request
from openscrapers import sources as fs_sources, check_hosted_media, hosts_list, providerstats, sourcesstats
playerWindow = control.playerWindow
getLS = control.lang
getSetting = control.setting
sourceFile = control.providercacheFile
single_expiry = timedelta(hours=6)
season_expiry = timedelta(hours=48)
show_expiry = timedelta(hours=48)
video_extensions = supported_video_extensions()
internal_scrapers_clouds_list = [('realdebrid', 'rd_cloud', 'rd'), ('premiumize', 'pm_cloud', 'pm'), ('alldebrid', 'ad_cloud', 'ad'),('torbox', 'tb_cloud', 'tb'),('offcloud', 'oc_cloud', 'oc')]

def _natural_sort_key(value):
	return [int(part) if part.isdigit() else part.lower() for part in re.split(r'(\d+)', value or '')]

def _write_provider_cache(cursor, query, values):
	"""Provider cache writes are optional; freshly scraped results are not."""
	if cursor is None: return False
	try:
		cursor.execute(query, values)
		cursor.connection.commit()
		return True
	except database.Error as exc:
		try: cursor.connection.rollback()
		except database.Error: pass
		log_utils.log('Provider cache write skipped: %s' % exc, level=log_utils.LOGWARNING)
		return False

class Sources:
	def __init__(self, all_providers=False, custom_query=False, filterless_scrape=False, rescrapeAll=False):
		self.sources = []
		self.url = None
		self.scraper_sources = []
		self.uncached_chosen = False
		self.isPrescrape = False
		self.all_providers = all_providers
		self.custom_query = custom_query
		self.filterless_scrape = filterless_scrape
		self.time = datetime.now()
		self.getConstants()
		self.enable_playnext = getSetting('enable.playnext') == 'true'
		self.dev_mode = getSetting('dev.mode.enable') == 'true'
		self.dev_disable_single = getSetting('dev.disable.single') == 'true'
		# self.dev_disable_single_filter = getSetting('dev.disable.single.filter') == 'true'
		self.dev_disable_season_packs = getSetting('dev.disable.season.packs') == 'true'
		self.dev_disable_season_filter = getSetting('dev.disable.season.filter') == 'true'
		self.dev_disable_show_packs = getSetting('dev.disable.show.packs') == 'true'
		self.dev_disable_show_filter = getSetting('dev.disable.show.filter') == 'true'
		self.highlight_color = getSetting('scraper.dialog.color')
		self.rescrapeAll = rescrapeAll
		self.retryallsources = getSetting('sources.retryall') == 'true'
		self.uncached_nopopup = getSetting('sources.nocachepopup') == 'true'
		self.providercache_hours = int(getSetting('cache.providers'))
		self.debuglog = control.setting('debug.level') == '1'
		self.external_module = getSetting('external_provider.module')
		self.isHidden = getSetting('progress.dialog') == '4'
		self.useTitleSubs = getSetting('sources.useTitleSubs') == 'true'

	def play(self, title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered, meta, select, rescrape=None):
		# Keep the route identity even when resolution fails after source selection.
		self.playback_request = dict(title=title, year=year, imdb=imdb, tmdb=tmdb, tvdb=tvdb,
			season=season, episode=episode, tvshowtitle=tvshowtitle, premiered=premiered)
		force_selection = select == '0' or rescrape == 'true'
		# if not self.prem_providers:
			# control.sleep(200) ; control.hide()
			# return control.notification(message=33034)
		try:
			control.sleep(200)
			if control.playlist().getposition() == 0 or control.playlist().size() <= 1 or rescrape == 'true':
				playerWindow.clearProperty('infinity.preResolved_nextUrl')
				playerWindow.clearProperty('infinity.preResolved_season')
				playerWindow.clearProperty('infinity.preResolved_episode')
				playerWindow.clearProperty('infinity.preResolved_imdb')
				playerWindow.clearProperty('infinity.preResolved_tmdb')
			preResolved_nextUrl = playerWindow.getProperty('infinity.preResolved_nextUrl')
			if preResolved_nextUrl != '' and not force_selection:
				preResolved_season = playerWindow.getProperty('infinity.preResolved_season')
				preResolved_episode = playerWindow.getProperty('infinity.preResolved_episode')
				preResolved_imdb = playerWindow.getProperty('infinity.preResolved_imdb')
				preResolved_tmdb = playerWindow.getProperty('infinity.preResolved_tmdb')
				from resources.lib.modules.episode_mapping import preresolved_matches
				_match = preresolved_matches(imdb, tmdb, season, episode, preResolved_imdb, preResolved_tmdb, preResolved_season, preResolved_episode)
				playerWindow.clearProperty('infinity.preResolved_nextUrl')
				playerWindow.clearProperty('infinity.preResolved_season')
				playerWindow.clearProperty('infinity.preResolved_episode')
				playerWindow.clearProperty('infinity.preResolved_imdb')
				playerWindow.clearProperty('infinity.preResolved_tmdb')
				if _match:
					control.sleep(500)
					meta = normalize_playback_meta(meta, title=title, year=year, imdb=imdb, tmdb=tmdb,
						tvdb=tvdb, season=season, episode=episode, tvshowtitle=tvshowtitle,
						premiered=premiered, mediatype='movie' if tvshowtitle is None else 'episode')
					self.meta = meta
					homeWindow.setProperty(self.metaProperty, jsdumps(meta))
					if self.debuglog:
						log_utils.log('Playing preResolved_nextUrl = %s' % preResolved_nextUrl, level=log_utils.LOGDEBUG)
					from resources.lib.modules import player
					return player.Player().play_source(title, year, season, episode, imdb, tmdb, tvdb, preResolved_nextUrl, meta)
				else:
					if self.debuglog:
						log_utils.log('preResolved_nextUrl mismatch (wanted S%sE%s imdb=%s, got S%sE%s imdb=%s) - discarding' % (season, episode, imdb, preResolved_season, preResolved_episode, preResolved_imdb), level=log_utils.LOGWARNING)
			if title: title = self.getTitle(title)
			if tvshowtitle: tvshowtitle = self.getTitle(tvshowtitle)
			homeWindow.clearProperty(self.metaProperty)
			homeWindow.setProperty(self.metaProperty, jsdumps(normalize_playback_meta(meta)))
			homeWindow.clearProperty(self.seasonProperty)
			homeWindow.setProperty(self.seasonProperty, season)
			homeWindow.clearProperty(self.episodeProperty)
			homeWindow.setProperty(self.episodeProperty, episode)
			homeWindow.clearProperty(self.titleProperty)
			homeWindow.setProperty(self.titleProperty, title)
			homeWindow.clearProperty(self.imdbProperty)
			homeWindow.setProperty(self.imdbProperty, imdb)
			homeWindow.clearProperty(self.tmdbProperty)
			homeWindow.setProperty(self.tmdbProperty, tmdb)
			homeWindow.clearProperty(self.tvdbProperty)
			homeWindow.setProperty(self.tvdbProperty, tvdb)
			p_label = '[COLOR %s]%s (%s)[/COLOR]' % (self.highlight_color, title, year) if tvshowtitle is None else \
			'[COLOR %s]%s (S%02dE%02d)[/COLOR]' % (self.highlight_color, tvshowtitle, int(season), int(episode))
			homeWindow.clearProperty(self.labelProperty)
			homeWindow.setProperty(self.labelProperty, p_label)
			url = None
			self.mediatype = 'movie' if tvshowtitle is None else 'episode'
			try: meta = jsloads(unquote(meta.replace('%22', '\\"')))
			except: pass
			if meta == None:
				if self.debuglog:
					log_utils.log('No meta was passed in. Trying to find meta now.',level=log_utils.LOGDEBUG)
				self.imdb_user = getSetting('imdbuser').replace('ur', '')
				self.tmdb_key = getSetting('tmdb.apikey')
				if not self.tmdb_key: self.tmdb_key = 'edde6b5e41246ab79a2697cd125e1781'
				self.tvdb_key = getSetting('tvdb.apikey')
				if self.mediatype == 'episode': self.user = str(self.imdb_user) + str(self.tvdb_key)
				else: self.user = str(self.tmdb_key)
				self.lang = control.apiLanguage()['tvdb']
				self.ids = {'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb}
				meta = metacache.fetch([{'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb}], self.lang, self.user)[0]
				if meta != self.ids: meta = dict((k, v) for k, v in iter(meta.items()) if v is not None and v != '')
			self.meta = meta
			def checkLibMeta(): # check Kodi db for meta for library playback.
				def cleanLibArt(art):
					if not art: return ''
					art = unquote(art.replace('image://', ''))
					if art.endswith('/'): art = art[:-1]
					return art
				try:
					if self.mediatype != 'movie': raise Exception()
					# do not add IMDBNUMBER as tmdb scraper puts their id in the key value
					meta = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties" : ["title", "originaltitle", "uniqueid", "year", "premiered", "genre", "studio", "country", "runtime", "rating", "votes", "mpaa", "director", "writer", "cast", "plot", "plotoutline", "tagline", "thumbnail", "art", "file"]}, "id": 1}' % (year, str(int(year) + 1), str(int(year) - 1)))
					meta = jsloads(meta)['result']['movies']
					try:
						meta = [i for i in meta if i.get('uniqueid', {}).get('imdb', '') == imdb]
					except:
						if self.debuglog:
							log_utils.log('Get Meta Failed in checkLibMeta: %s' % str(meta), level=log_utils.LOGDEBUG)
						meta = None
					if meta: meta = meta[0]
					else: raise Exception()
					if 'mediatype' not in meta: meta.update({'mediatype': 'movie'})
					if 'duration' not in meta: meta.update({'duration': meta.get('runtime')}) # Trakt scrobble resume needs this for lib playback
					if 'castandrole' not in meta: meta.update({'castandrole': [(i['name'], i['role']) for i in meta.get('cast')]})
					poster = cleanLibArt(meta.get('art').get('poster', '')) or self.poster
					#fanart = cleanLibArt(meta.get('art').get('fanart', '')) or self.fanart
					fanart = cleanLibArt(meta.get('art').get('fanart', '')) or getattr(self, 'fanart', '') #fix for blank tmdb fanart being passed in self.fanart was crashing this.
					clearart = cleanLibArt(meta.get('art').get('clearart', ''))
					clearlogo = cleanLibArt(meta.get('art').get('clearlogo', ''))
					discart = cleanLibArt(meta.get('art').get('discart'))
					meta.update({'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb, 'poster': poster, 'fanart': fanart, 'clearart': clearart, 'clearlogo': clearlogo, 'discart': discart})
					return meta
				except:
					log_utils.error()
					meta = {}
				try:
					if self.mediatype != 'episode': raise Exception()
					# do not add IMDBNUMBER as tmdb scraper puts their id in the key value
					show_meta = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties" : ["title", "originaltitle", "uniqueid", "mpaa", "year", "genre", "runtime", "thumbnail", "file"]}, "id": 1}' % (year, str(int(year)+1), str(int(year)-1)))
					show_meta = jsloads(show_meta)['result']['tvshows']
					show_meta = [i for i in show_meta if i.get('uniqueid', {}).get('imdb', '') == imdb]
					if show_meta: show_meta = show_meta[0]
					else: raise Exception()
					tvshowid = show_meta['tvshowid']
					meta = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params":{"tvshowid": %d, "filter":{"and": [{"field": "season", "operator": "is", "value": "%s"}, {"field": "episode", "operator": "is", "value": "%s"}]}, "properties": ["title", "season", "episode", "showtitle", "firstaired", "runtime", "rating", "director", "writer", "cast", "plot", "thumbnail", "art", "file"]}, "id": 1}' % (tvshowid, season, episode))
					meta = jsloads(meta)['result']['episodes']
					if meta: meta = meta[0]
					else: raise Exception()
					if 'mediatype' not in meta: meta.update({'mediatype': 'episode'})
					if 'tvshowtitle' not in meta: meta.update({'tvshowtitle': meta.get('showtitle')})
					if 'castandrole' not in meta: meta.update({'castandrole': [(i['name'], i['role']) for i in meta.get('cast')]})
					if 'genre' not in meta: meta.update({'genre': show_meta.get('genre')})
					if 'duration' not in meta: meta.update({'duration': meta.get('runtime')}) # Trakt scrobble resume needs this for lib playback but Kodi lib returns "0" for shows or episodes
					if 'mpaa' not in meta: meta.update({'mpaa': show_meta.get('mpaa')})
					if 'premiered' not in meta: meta.update({'premiered': meta.get('firstaired')})
					if 'year' not in meta: meta.update({'year': show_meta.get('year')}) # shows year not year episode aired
					poster = cleanLibArt(meta.get('art').get('season.poster', '')) or self.poster
					fanart = cleanLibArt(meta.get('art').get('tvshow.fanart', '')) or self.poster
					clearart = cleanLibArt(meta.get('art').get('tvshow.clearart', ''))
					clearlogo = cleanLibArt(meta.get('art').get('tvshow.clearlogo', ''))
					discart = cleanLibArt(meta.get('art').get('discart'))
					meta.update({'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb, 'poster': poster, 'fanart': fanart, 'clearart': clearart, 'clearlogo': clearlogo, 'discart': discart})
					return meta
				except:
					log_utils.error()
					meta = {}
			if self.meta is None or 'videodb' in control.infoLabel('ListItem.FolderPath'):
				self.meta = checkLibMeta() or meta
			self.meta = normalize_playback_meta(self.meta, title=title, year=year, imdb=imdb, tmdb=tmdb,
				tvdb=tvdb, season=season, episode=episode, tvshowtitle=tvshowtitle,
				premiered=premiered, mediatype=self.mediatype)
			meta = self.meta
			homeWindow.setProperty(self.metaProperty, jsdumps(meta))
			if self.mediatype == 'movie':
				# self.sourceDict = self.movie_source
				if getSetting('imdb.Moviemeta.check') == 'true': # check IMDB. TMDB and Trakt differ on a ratio of 1 in 20 and year is off by 1, some meta titles mismatch
					title, year = self.imdb_meta_chk(imdb, title, year)
				if title == 'The F**k-It List': title = 'The Fuck-It List'
			if self.mediatype == 'episode':
				# self.sourceDict = self.episode_source
				if getSetting('imdb.Showmeta.check') == 'true':
					tvshowtitle, year = self.imdb_meta_chk(imdb, tvshowtitle, year)
				if tvshowtitle == 'The End of the F***ing World': tvshowtitle = 'The End of the Fucking World'
				if self.useTitleSubs:
					tvshowtitle = self.subTitle(tvshowtitle)
					if self.meta:
						self.meta.update({'tvshowtitle': tvshowtitle})
						p_label = '[COLOR %s]%s (%s)[/COLOR]' % (self.highlight_color, title, year) if tvshowtitle is None else \
						'[COLOR %s]%s (S%02dE%02d)[/COLOR]' % (self.highlight_color, tvshowtitle, int(season), int(episode))
						homeWindow.clearProperty(self.labelProperty)
						homeWindow.setProperty(self.labelProperty, p_label)
						homeWindow.clearProperty(self.metaProperty)
						homeWindow.setProperty(self.metaProperty, jsdumps(self.meta))
				self.total_seasons, self.season_isAiring = self.get_season_info(imdb, tmdb, tvdb, meta, season)
			# log_utils.log(f'Goto self.getSources Total: {len(self.sourceDict)} self.sourceDict: {repr(self.sourceDict)}')
			if rescrape: self.clr_item_providers(title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered)
			# items = self.getSources(title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered)
			items = providerscache.get(self.getSources, self.providercache_hours, title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered)
			if not items:
				self.url = url
				return self.errorForSources(title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered)
			# log_utils.log(f'total: {len(items)} items: {items}')
			filter = [] ; uncached_items = []
			if getSetting('torrent.remove.uncached') == 'true':
				uncached_items += [i for i in items if re.match(r'^uncached.*torrent', i['source'])]
				filter += [i for i in items if i not in uncached_items]
				if filter: pass
				elif not filter:
					homeWindow.clearProperty('infinity.window_keep_alive')
					if not self.uncached_nopopup:
						if control.yesnoDialog('No cached torrents returned. Would you like to view the uncached torrents to cache yourself?', '', ''):
							control.cancelPlayback()
							select = '0'
							self.uncached_chosen = True
							filter += uncached_items
				items = filter
				if not items:
					self.url = url
					return self.errorForSources(title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered)
			else: uncached_items += [i for i in items if re.match(r'^uncached.*torrent', i['source'])]
			if select is None:
				if episode is not None and self.enable_playnext and getSetting('play.mode.tv') != '0': select = '1'
				elif episode == None:
					select = getSetting('play.mode.movie')
				else: select = getSetting('play.mode.tv')
			title = tvshowtitle if tvshowtitle is not None else title
			self.imdb = imdb ; self.tmdb = tmdb ; self.tvdb = tvdb ; self.title = title ; self.year = year
			self.season = season ; self.episode = episode
			self.ids = {'imdb': self.imdb, 'tmdb': self.tmdb, 'tvdb': self.tvdb}
			if len(items) > 0:
				preference = source_preferences.get(self.meta) if not force_selection else None
				url = None
				if preference:
					matches = source_preferences.matching(items, preference)
					if matches: url = self.sourcesAutoPlay(matches)
				if (preference and not url) or (not preference and select == '0'):
					control.sleep(200)
					return self.sourceSelect(title, items, uncached_items, self.meta)
				else: url = self.sourcesAutoPlay(title, items)
			if url == 'close://' or url is None:
				self.url = url
				return self.errorForSources()
			if season == 'None': season = None
			if episode == 'None': episode = None
			from resources.lib.modules import player
			player.Player().play_source(title, year, season, episode, imdb, tmdb, tvdb, url, self.meta)
		except:
			log_utils.error(f'Error play: {print_exc()}')
			control.cancelPlayback()

	def sourceSelect(self, title, items, uncached_items, meta):
		try:
			control.hide()
			if not self.enable_playnext:
				control.playlist().clear()
			if not items:
				control.sleep(200) ; control.hide() ; sysexit()
			# - compare meta received to database and use largest(eventually switch to a request to fetch missing db meta for item)
			self.imdb_user = getSetting('imdbuser').replace('ur', '')
			self.tmdb_key = getSetting('tmdb.apikey')
			if not self.tmdb_key: self.tmdb_key = 'edde6b5e41246ab79a2697cd125e1781'
			self.tvdb_key = getSetting('tvdb.apikey')
			if self.mediatype == 'episode': self.user = str(self.imdb_user) + str(self.tvdb_key)
			else: self.user = str(self.tmdb_key)
			self.lang = control.apiLanguage()['tvdb']
			meta1 = dict((k, v) for k, v in iter(meta.items()) if v is not None and v != '') if meta else None
			meta2 = metacache.fetch([{'imdb': self.imdb, 'tmdb': self.tmdb, 'tvdb': self.tvdb}], self.lang, self.user)[0]
			if meta2 != self.ids: meta2 = dict((k, v) for k, v in iter(meta2.items()) if v is not None and v != '')
			if meta1 is not None:
				try:
					if len(meta2) > len(meta1):
						meta2.update(meta1)
						meta = meta2
					else: meta = meta1
				except: log_utils.error()
			else: meta = meta2 if meta2 != self.ids else meta1
			self.poster = meta.get('poster') if meta else ''
			self.fanart = meta.get('fanart') if meta else ''
			self.meta = meta
		except: log_utils.error('Error sourceSelect(): ')

		def checkLibMeta(): # check Kodi db for meta for library playback.
			def cleanLibArt(art):
				if not art: return ''
				art = unquote(art.replace('image://', ''))
				if art.endswith('/'): art = art[:-1]
				return art
			try:
				if self.mediatype != 'movie': raise Exception()
				# do not add IMDBNUMBER as tmdb scraper puts their id in the key value
				meta = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties" : ["title", "originaltitle", "uniqueid", "year", "premiered", "genre", "studio", "country", "runtime", "rating", "votes", "mpaa", "director", "writer", "cast", "plot", "plotoutline", "tagline", "thumbnail", "art", "file"]}, "id": 1}' % (self.year, str(int(self.year) + 1), str(int(self.year) - 1)))
				meta = jsloads(meta)['result']['movies']
				try:
					meta = [i for i in meta if i.get('uniqueid', {}).get('imdb', '') == self.imdb]
				except:
					if self.debuglog:
						log_utils.log('Get Meta Failed in checkLibMeta: %s' % str(meta), level=log_utils.LOGDEBUG)
					meta = None
				if meta: meta = meta[0]
				else: raise Exception()
				if 'mediatype' not in meta: meta.update({'mediatype': 'movie'})
				if 'duration' not in meta: meta.update({'duration': meta.get('runtime')}) # Trakt scrobble resume needs this for lib playback
				if 'castandrole' not in meta: meta.update({'castandrole': [(i['name'], i['role']) for i in meta.get('cast')]})
				poster = cleanLibArt(meta.get('art').get('poster', '')) or self.poster
				#fanart = cleanLibArt(meta.get('art').get('fanart', '')) or self.fanart
				fanart = cleanLibArt(meta.get('art').get('fanart', '')) or getattr(self, 'fanart', '')
				clearart = cleanLibArt(meta.get('art').get('clearart', ''))
				clearlogo = cleanLibArt(meta.get('art').get('clearlogo', ''))
				discart = cleanLibArt(meta.get('art').get('discart'))
				meta.update({'imdb': self.imdb, 'tmdb': self.tmdb, 'tvdb': self.tvdb, 'poster': poster, 'fanart': fanart, 'clearart': clearart, 'clearlogo': clearlogo, 'discart': discart})
				return meta
			except:
				log_utils.error()
				meta = {}
			try:
				if self.mediatype != 'episode': raise Exception()
				# do not add IMDBNUMBER as tmdb scraper puts their id in the key value
				show_meta = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties" : ["title", "originaltitle", "uniqueid", "mpaa", "year", "genre", "runtime", "thumbnail", "file"]}, "id": 1}' % (self.year, str(int(self.year)+1), str(int(self.year)-1)))
				show_meta = jsloads(show_meta)['result']['tvshows']
				show_meta = [i for i in show_meta if i.get('uniqueid', {}).get('imdb', '') == self.imdb]
				if show_meta: show_meta = show_meta[0]
				else: raise Exception()
				tvshowid = show_meta['tvshowid']
				meta = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params":{"tvshowid": %d, "filter":{"and": [{"field": "season", "operator": "is", "value": "%s"}, {"field": "episode", "operator": "is", "value": "%s"}]}, "properties": ["title", "season", "episode", "showtitle", "firstaired", "runtime", "rating", "director", "writer", "cast", "plot", "thumbnail", "art", "file"]}, "id": 1}' % (tvshowid, self.season, self.episode))
				meta = jsloads(meta)['result']['episodes']
				if meta: meta = meta[0]
				else: raise Exception()
				if 'mediatype' not in meta: meta.update({'mediatype': 'episode'})
				if 'tvshowtitle' not in meta: meta.update({'tvshowtitle': meta.get('showtitle')})
				if 'castandrole' not in meta: meta.update({'castandrole': [(i['name'], i['role']) for i in meta.get('cast')]})
				if 'genre' not in meta: meta.update({'genre': show_meta.get('genre')})
				if 'duration' not in meta: meta.update({'duration': meta.get('runtime')}) # Trakt scrobble resume needs this for lib playback but Kodi lib returns "0" for shows or episodes
				if 'mpaa' not in meta: meta.update({'mpaa': show_meta.get('mpaa')})
				if 'premiered' not in meta: meta.update({'premiered': meta.get('firstaired')})
				if 'year' not in meta: meta.update({'year': show_meta.get('year')}) # shows year not year episode aired
				poster = cleanLibArt(meta.get('art').get('season.poster', '')) or self.poster
				fanart = cleanLibArt(meta.get('art').get('tvshow.fanart', '')) or self.poster
				clearart = cleanLibArt(meta.get('art').get('tvshow.clearart', ''))
				clearlogo = cleanLibArt(meta.get('art').get('tvshow.clearlogo', ''))
				discart = cleanLibArt(meta.get('art').get('discart'))
				meta.update({'imdb': self.imdb, 'tmdb': self.tmdb, 'tvdb': self.tvdb, 'poster': poster, 'fanart': fanart, 'clearart': clearart, 'clearlogo': clearlogo, 'discart': discart})
				return meta
			except:
				log_utils.error()
				meta = {}
		if self.meta is None or 'videodb' in control.infoLabel('ListItem.FolderPath'):
			self.meta = checkLibMeta()
		try:
			def sourcesDirMeta(metadata): # pass skin minimal meta needed
				if not metadata: return metadata
				if getSetting('prefer.tmdbArt') == 'true': metadata['clearlogo'] = metadata.get('tmdblogo') or metadata.get('clearlogo', '')
				allowed = ['mediatype', 'imdb', 'tmdb', 'tvdb', 'poster', 'tvshow.poster', 'season_poster', 'season_poster', 'fanart', 'clearart', 'clearlogo', 'discart', 'thumb', 'title', 'tvshowtitle', 'year', 'premiered', 'rating', 'plot', 'duration', 'mpaa', 'season', 'episode', 'castandrole']
				return {k: v for k, v in iter(metadata.items()) if k in allowed}
			self.meta = sourcesDirMeta(self.meta)
			if getSetting('uncached.seeder.sort') == 'true':
				uncached_items = sorted(uncached_items, key=lambda k: k['seeders'], reverse=True)
				uncached_items = self.sort_byQuality(source_list=uncached_items)
			if items == uncached_items and not self.uncached_chosen:
				from resources.lib.windows.uncached_results import UncachedResultsXML
				window = UncachedResultsXML('uncached_results.xml', control.addonPath(control.addonId()), uncached=uncached_items, meta=self.meta)
			else:
				from resources.lib.windows.source_results import SourceResultsXML
				window = SourceResultsXML('source_results.xml', control.addonPath(control.addonId()), results=items, uncached=uncached_items, meta=self.meta)
			action, chosen_source = window.run()
			del window
			if action == 'play_Item':
				return self.playItem(title, items, chosen_source.getProperty('infinity.source_dict'), self.meta)
			elif action == 'play_EN_Seekable':
				from resources.lib.modules import player
				player.Player().play(chosen_source)
				return
			else:
				homeWindow.clearProperty('infinity.window_keep_alive')
				try: self.window.close()
				except: pass
				if self.enable_playnext:
					# During continuous playback Kodi holds a valid plugin handle.
					# Resolving with False triggers "Playback Failed". Resolve with
					# True + empty offscreen item instead so no error dialog appears.
					control.playlist().clear()
					try: control.player_class().stop()
					except: pass
					from sys import argv
					control.resolve(int(argv[1]), True, control.item(offscreen=True))
					control.closeOk()
				else:
					control.cancelPlayback()
		except:
			log_utils.error('Error sourceSelect(): ')
			control.cancelPlayback()

	def playItem(self, title, items, chosen_source, meta):
		try:
			# log_utils.log(f'playItem items: {items}\ntitle: {title}\nchosen_source: {chosen_source}\nmeta: {meta}', level=0)
			try: items = jsloads(items)
			except: pass
			try: meta = jsloads(meta)
			except: pass
			try:
				chosen_source = jsloads(chosen_source)
				# log_utils.log(f'playItem items: {items}\nchosen_source[0]: {chosen_source[0]}', level=0)
				try: source_index = items.index(chosen_source[0])
				except: source_index = next((i for i, v in enumerate(items) if v == chosen_source[0]), -1)
				log_utils.log(f'playItem source_index: {source_index}', level=0)
				source_len = len(items)
				next_end = min(source_len, source_index+41)
				sources_next = items[source_index+1:next_end]
				sources_prev = [] if next_end < source_len else items[0:41-(source_len-source_index)]
				if getSetting('sources.useonlyone')== 'true':
					resolve_items = chosen_source
				else:
					resolve_items = [i for i in chosen_source + sources_next + sources_prev]
			except: log_utils.error(f'error: {print_exc()}')
			try:
				poster = meta.get('poster')
			except:
				poster = ''
			header = homeWindow.getProperty(self.labelProperty) + ': Resolving...'
			try:
				if getSetting('progress.dialog') == '0':
					if getSetting('dialogs.useinfinitydialog') == 'true':
						progressDialog = control.getProgressWindow(header, icon=poster)
					else:
						progressDialog = control.progressDialog
						progressDialog.create(header,'')
				elif getSetting('progress.dialog') in ('2', '3', '4'):
					if homeWindow.getProperty('infinity.window_keep_alive') != 'true':
						progressDialog = self.getWindowProgress(title, meta)
						Thread(target=self.window_monitor, args=(progressDialog,)).start()
					else: progressDialog = self.window
				else: raise Exception()
			except:
				homeWindow.clearProperty('infinity.window_keep_alive')
				progressDialog = control.progressDialogBG
				progressDialog.create(header, '')
			total_resol_item = len(resolve_items)
			# log_utils.log(f'total_resol_item: {total_resol_item}')
			for i in range(total_resol_item):
				try:
					resolve_index = items.index(resolve_items[i])+1
					src_provider = resolve_items[i]['debrid'] if resolve_items[i].get('debrid') else ('%s - %s' % (resolve_items[i]['source'], resolve_items[i]['provider']))
					index_info = f'{resolve_index}/{total_resol_item} ~ {src_provider}'
					if getSetting('progress.dialog') == '0':
						if getSetting('dialogs.useinfinitydialog') == 'true':
							label = '[COLOR %s]%s[CR]%s[CR]%s[/COLOR]' % (self.highlight_color, index_info, resolve_items[i]['provider'].upper(), resolve_items[i]['info'])
						else:
							label = '[COLOR %s]%s[CR]%02d - %s[CR]%s[/COLOR]' % (self.highlight_color, index_info, resolve_index, resolve_items[i]['name'], str(round(resolve_items[i]['size'], 2)) + ' GB') # using "[CR]" has some weird delay with progressDialog.update() at times
					elif getSetting('progress.dialog') == '2':
						resolveInfo = resolve_items[i]['info'].replace('/',' ')
						if meta.get('plot'):
							plotLabel = '[COLOR %s]%s[/COLOR][CR][CR]' %  (getSetting('sources.highlight.color'),meta.get('plot'))
						else:
							plotLabel = ''
						label = plotLabel + '[COLOR %s]%s[CR]%s[CR]%s[CR]%s[CR]%02d - %s[/COLOR]' % (self.highlight_color, index_info, resolve_items[i]['provider'].upper(), resolve_items[i]['quality'].upper(), resolveInfo, resolve_index, resolve_items[i]['name'][:30])
					else:
						label = '[COLOR %s]%s[CR]%02d - %s[CR]%s[/COLOR]' % (self.highlight_color, index_info, resolve_index, resolve_items[i]['name'], str(round(resolve_items[i]['size'], 2)) + ' GB') # using "[CR]" has some weird delay with progressDialog.update() at times
					control.sleep(100)
					try:
						if progressDialog.iscanceled(): break
						progressDialog.update(int((100 / float(len(resolve_items))) * i), label)
					except:
						progressDialog.update(int((100 / float(len(resolve_items))) * i), '[COLOR %s]Resolving...[/COLOR]%s' % (self.highlight_color, resolve_items[i]['name']))
					w = Thread(target=self.sourcesResolve, args=(resolve_items[i],))
					w.start()
					for x in range(40):
						try:
							if control.monitor_class().abortRequested(): return sysexit()
							if progressDialog.iscanceled():
								control.notification(message=32398)
								control.cancelPlayback()
								progressDialog.close()
								del progressDialog
								return
						except: pass
						if not w.is_alive(): break
						control.sleep(200)
					if not self.url: continue
					# if not any(x in self.url.lower() for x in video_extensions):
					if not any(x in self.url.lower() for x in video_extensions) and 'plex.direct:' not in self.url and 'torbox' not in self.url and 'tb-cdn' not in self.url and 'plugin://plugin.video.composite_for_plex' not in self.url:
						log_utils.log('Playback not supported for (playItem()): %s' % self.url, level=log_utils.LOGWARNING)
						continue
					if homeWindow.getProperty('infinity.window_keep_alive') != 'true':
						log_utils.log(f'Playing url from playItem(): {self.url}', level=0)
						try: progressDialog.close()
						except: pass
						del progressDialog
					from resources.lib.modules import player
					try:
						player.Player().play_source(
						title,
						getattr(self, 'year', meta.get('year') if isinstance(meta, dict) else None),
						getattr(self, 'season', meta.get('season') if isinstance(meta, dict) else None),
						getattr(self, 'episode', meta.get('episode') if isinstance(meta, dict) else None),
						getattr(self, 'imdb', meta.get('imdb', '') if isinstance(meta, dict) else ''),
						getattr(self, 'tmdb', meta.get('tmdb', '') if isinstance(meta, dict) else ''),
						getattr(self, 'tvdb', meta.get('tvdb', '') if isinstance(meta, dict) else ''),
						self.url, meta
						)
						player.Player().log(f'from playItem Playing url from playItem(): {self.url}', level=0)
						if player.Player().isPlayback(): return self.url
						# else: continue
					except: log_utils.error(f'Error playItem: {i}')
				except: log_utils.error(f'Error playItem: {i}')
			try: progressDialog.close()
			except: pass
			del progressDialog
			self.errorForSources()
		except: log_utils.error('Error playItem: ')

	def getSources(self, title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered, meta=None, preScrape=False):
		self.scrape_tmdb = tmdb
		self.window = None
		if preScrape:
			self.isPrescrape = True
			if tvshowtitle is not None:
				self.mediatype = 'episode'
				self.meta = meta
				self.total_seasons, self.season_isAiring = self.get_season_info(imdb, tmdb, tvdb, meta, season)
			return self.getSources_silent(title, year, imdb, tvdb, season, episode, tvshowtitle, premiered)
		else:
			return self.getSources_dialog(title, year, imdb, tvdb, season, episode, tvshowtitle, premiered)

	def getSources_silent(self, title, year, imdb, tvdb, season, episode, tvshowtitle, premiered, timeout=90):
		try:
			p_label = '[COLOR %s]%s (S%02dE%02d)[/COLOR]' % (self.highlight_color, tvshowtitle, int(season), int(episode))
			homeWindow.clearProperty(self.labelProperty)
			homeWindow.setProperty(self.labelProperty, p_label)
			self.prepareSources()
			sourceDict = self.sourceDict
			scraperDict = [(i[0], i[1], '') for i in sourceDict if getattr(i[1], 'tvshow', None)]
			aliases = []
			try:
				meta = self.meta
				aliases = meta.get('aliases', [])
			except: pass
			threads = []
			# scraperDict = [(i[0], i[1], '') for i in sourceDict]
			if self.season_isAiring == 'false':
				scraperDict.extend([(i[0], i[1], 'season') for i in sourceDict if i[0] in []])
				scraperDict.extend([(i[0], i[1], 'show') for i in sourceDict if i[0] in []])
			trakt_aliases = self.getAliasTitles(imdb, 'episode')
			try: aliases.extend([i for i in trakt_aliases if not i in aliases]) # combine TMDb and Trakt aliases
			except: pass
			try: country_codes = meta.get('country_codes', [])
			except: country_codes = []
			for i in country_codes:
				if i in ('CA', 'US', 'UK', 'GB'):
					if i == 'GB': i = 'UK'
					alias = {'title': tvshowtitle + ' ' + i, 'country': i.lower()}
					if not alias in aliases: aliases.append(alias)
			data = {'title': title, 'year': year, 'imdb': imdb, 'tvdb': tvdb, 'season': season, 'episode': episode, 'tvshowtitle': tvshowtitle, 'aliases': aliases, 'premiered': premiered}
			# if self.debrid_service: data.update({'debrid_service': self.debrid_service, 'debrid_token': self.debrid_token})
			for i in scraperDict:
				name, pack = i[0].upper(), i[2]
				if pack == 'season': name = '%s (season pack)' % name
				elif pack == 'show': name = '%s (show pack)' % name
				threads.append(Thread(target=self.getEpisodeSource, args=(imdb, season, episode, data, i[0], i[1], pack), name=name))
			[i.start() for i in threads]
			end_time = time() + timeout
		except: return log_utils.error()
		while True:
			try:
				if control.monitor_class().abortRequested(): return sysexit()
				try:
					info = [x.getName() for x in threads if x.is_alive() is True]
					if len(info) == 0: break
					if end_time < time(): break
				except:
					log_utils.error()
					break
				control.sleep(100)
			except: log_utils.error()
		del threads[:] # Make sure any remaining providers are stopped.
		self.sources.extend(self.scraper_sources)
		# log_utils.log(f'len(self.sources: {len(self.sources)} self.sources: {self.sources}\n__name__: {__name__}', level=0)
		self.tvshowtitle = tvshowtitle
		self.year = year
		homeWindow.clearProperty('fs_filterless_search')
		if len(self.sources) > 0: self.sourcesFilter()
		return self.sources

	def getSources_dialog(self, title, year, imdb, tvdb, season, episode, tvshowtitle, premiered, timeout=90):
		try:
			content = 'movie' if tvshowtitle is None else 'episode'
			if self.filterless_scrape: homeWindow.setProperty('fs_filterless_search', 'true')
			if self.custom_query == 'true':
				try:
					custom_title = control.dialog.input('[COLOR %s][B]%s[/B][/COLOR]' % (self.highlight_color, getLS(32038)), defaultt=tvshowtitle if tvshowtitle else title)
					if content == 'movie':
						if custom_title: title = custom_title ; self.meta.update({'title': title})
						custom_year = control.dialog.input('[COLOR %s]%s (%s)[/COLOR]' % (self.highlight_color, getLS(32457), getLS(32488)), type=control.numeric_input, defaultt=str(year))
						if custom_year: year = str(custom_year) ; self.meta.update({'year': year})
					else:
						if custom_title: tvshowtitle = custom_title ; self.meta.update({'tvshowtitle': tvshowtitle})
						custom_season = control.dialog.input('[COLOR %s]%s (%s)[/COLOR]' % (self.highlight_color, getLS(32055), getLS(32488)), type=control.numeric_input, defaultt=str(season))
						if custom_season: season = str(custom_season) ; self.meta.update({'season': season})
						custom_episode = control.dialog.input('[COLOR %s]%s (%s)[/COLOR]' % (self.highlight_color, getLS(32325), getLS(32488)), type=control.numeric_input, defaultt=str(episode))
						if custom_episode: episode = str(custom_episode) ; self.meta.update({'episode': episode})
					p_label = '[COLOR %s]%s (%s)[/COLOR]' % (self.highlight_color, title, year) if tvshowtitle is None else '[COLOR %s]%s (S%02dE%02d)[/COLOR]' % (self.highlight_color, tvshowtitle, int(season), int(episode))
					homeWindow.clearProperty(self.labelProperty)
					homeWindow.setProperty(self.labelProperty, p_label)
					homeWindow.clearProperty(self.metaProperty)
					homeWindow.setProperty(self.metaProperty, jsdumps(self.meta))
					homeWindow.clearProperty(self.seasonProperty)
					homeWindow.setProperty(self.seasonProperty, season)
					homeWindow.clearProperty(self.episodeProperty)
					homeWindow.setProperty(self.episodeProperty, episode)
					homeWindow.clearProperty(self.titleProperty)
					homeWindow.setProperty(self.titleProperty, title)
					log_utils.log('Custom query scrape ran using: %s' % p_label, level=log_utils.LOGDEBUG)
				except: log_utils.error()
			#progressDialog = control.progressDialog if getSetting('progress.dialog') == '0' else control.progressDialogBG
			header = homeWindow.getProperty(self.labelProperty) + ': Scraping...'
			try:
				if getSetting('progress.dialog') == '0':
					if getSetting('dialogs.useinfinitydialog') == 'true':
						progressDialog = control.getProgressWindow(header, icon='')
						debrid_message = '[COLOR %s][B]Please wait...[CR]Checking Providers[/B][/COLOR]' % self.highlight_color
					else:
						progressDialog = control.progressDialog
						progressDialog.create(header,'')
						debrid_message = '[COLOR %s][B]Please wait...[CR]Checking Providers[/B][/COLOR]' % self.highlight_color
				elif getSetting('progress.dialog') in ('2', '3','4'):
					try: meta = self.meta
					except: meta = {'title': title, 'year': year, 'imdb': imdb, 'tvdb': tvdb, 'season': season, 'episode': episode, 'tvshowtitle': tvshowtitle}
					progressDialog = self.getWindowProgress(title, meta)
					Thread(target=self.window_monitor, args=(progressDialog,)).start()
					debrid_message = '[COLOR %s][B]Please wait...[CR]Checking Providers[/B][/COLOR]' % self.highlight_color
				else: raise Exception()
			except:
				homeWindow.clearProperty('infinity.window_keep_alive')
				progressDialog = control.progressDialogBG
				progressDialog.create(header, '')
				debrid_message = '[COLOR %s][B]Please wait...  Checking Providers[/B][/COLOR]' % self.highlight_color
			#self.prepareSources()
			progressDialog.update(0, getLS(32600)) # preparing sources
			# log_utils.log('1 len(sourceDict): (%s) sourceDict: (%s)' % (len(sourceDict), sourceDict), __name__, level=0)
			trakt_aliases = self.prepareSources_dialog(progressDialog, imdb, content)
			if trakt_aliases is None:
				homeWindow.clearProperty('infinity.window_keep_alive')
				homeWindow.clearProperty('fs_filterless_search')
				progressDialog.close()
				return []
			sourceDict = self.sourceDict
			if content == 'movie': sourceDict = [(i[0], i[1]) for i in sourceDict if getattr(i[1], 'movie', None)]
			else: sourceDict = [(i[0], i[1]) for i in sourceDict if getattr(i[1], 'tvshow', None)]
			if getSetting('cf.disable') == 'true': sourceDict = [(i[0], i[1]) for i in sourceDict if not any(x in i[0] for x in self.sourcecfDict)]
			#log_utils.log(f'actual using len(sourceDict): {len(sourceDict)} sourceDict: ', __name__, level=0)
			if getSetting('scrapers.prioritize') == 'true':
				sourceDict = [(i[0], i[1], i[1].priority) for i in sourceDict]
				sourceDict = sorted(sourceDict, key=lambda i: i[2]) # sorted by scraper priority
			try: aliases = self.meta.get('aliases', [])
			except: aliases = []
			threads = [] ; threads_append = threads.append
			# log_utils.log(f'>>>> len(sourceDict): ({len(sourceDict)}) sourceDict: ({sourceDict})', __name__, level=0)

			if content == 'movie':
				trakt_aliases = self.getAliasTitles(imdb, content) # cached for 7 days in trakt module called
				try: aliases.extend([i for i in trakt_aliases if not i in aliases]) # combine TMDb and Trakt aliases
				except: pass
				data = {'title': title, 'aliases': aliases, 'year': year, 'imdb': imdb}
				# if self.debrid_service: data.update({'debrid_service': self.debrid_service, 'debrid_token': self.debrid_token})
				for i in sourceDict: threads_append(Thread(target=self.getMovieSource, args=(imdb, data, i[0], i[1]), name=i[0].upper()))
			else:
				scraperDict = [(i[0], i[1], '') for i in sourceDict] if ((not self.dev_mode) or (not self.dev_disable_single)) else []
				if self.season_isAiring == 'false':
					if (not self.dev_mode) or (not self.dev_disable_season_packs): scraperDict.extend([(i[0], i[1], 'season') for i in sourceDict if i[0] in []])
					if (not self.dev_mode) or (not self.dev_disable_show_packs): scraperDict.extend([(i[0], i[1], 'show') for i in sourceDict if i[0] in []])
				trakt_aliases = self.getAliasTitles(imdb, content) # cached for 7 days in trakt module called
				try: aliases.extend([i for i in trakt_aliases if not i in aliases]) # combine TMDb and Trakt aliases
				except: pass
				try: country_codes = self.meta.get('country_codes', [])
				except: country_codes = []
				for i in country_codes:
					if i in ('CA', 'US', 'UK', 'GB'):
						if i == 'GB': i = 'UK'
						alias = {'title': tvshowtitle + ' ' + i, 'country': i.lower()}
						if not alias in aliases: aliases.append(alias)
				aliases = aliases_check(tvshowtitle, aliases)
				# log_utils.log('getSources_dialog aliases = %s' % aliases, __name__)
				# log_utils.log('>>>> len(scraperDict): (%s) scraperDict: (%s)' % (len(scraperDict), scraperDict), __name__, level=0)
				data = {'title': title, 'year': year, 'imdb': imdb, 'tvdb': tvdb, 'season': season, 'episode': episode, 'tvshowtitle': tvshowtitle, 'aliases': aliases, 'premiered': premiered}
				# if self.debrid_service: data.update({'debrid_service': self.debrid_service, 'debrid_token': self.debrid_token})
				for i in scraperDict:
					name, pack = i[0].upper(), i[2]
					# log_utils.log(f'name: {name} pack: {pack} i: {i}')
					if pack == 'season': name = '%s (season pack)' % name
					elif pack == 'show': name = '%s (show pack)' % name
					threads_append(Thread(target=self.getEpisodeSource, args=(imdb, season, episode, data, i[0], i[1], pack), name=name))
			#import web_pdb; web_pdb.set_trace()
			[i.start() for i in threads]
			sdc = getSetting('sources.highlight.color')
			string1 = getLS(32404) % (self.highlight_color, sdc, '%s') # msgid "[COLOR %s]Time elapsed:[/COLOR]  [COLOR %s]%s seconds[/COLOR]"
			string3 = getLS(32406) % (self.highlight_color, sdc, '%s') # msgid "[COLOR %s]Remaining providers:[/COLOR] [COLOR %s]%s[/COLOR]"
			string4 = getLS(32407) % (self.highlight_color, sdc, '%s') # msgid "[COLOR %s]Unfiltered Total: [/COLOR]  [COLOR %s]%s[/COLOR]"
			#string1f = getLS(32404) % (sdc, sdc, '%s') # msgid "[COLOR %s]Time elapsed:[/COLOR]  [COLOR %s]%s seconds[/COLOR]"
			#string3f = getLS(32406) % (sdc, sdc, '%s') # msgid "[COLOR %s]Remaining providers:[/COLOR] [COLOR %s]%s[/COLOR]"
			#string4f = getLS(32407) % (sdc, sdc, '%s') # msgid "[COLOR %s]Unfiltered Total: [/COLOR]  [COLOR %s]%s[/COLOR]"


			try: timeout = int(getSetting('scrapers.timeout'))
			except: pass
			if self.all_providers == 'true': timeout = 90
			start_time = time()
			end_time = start_time + timeout
			quality = getSetting('hosts.quality') or '0'
			line1 = line2 = line3 = ""
			terminate_onCloud = getSetting('terminate.onCloud.sources') == 'true'
			pre_emp_movie = getSetting('preemptive.termination.movie') == 'true'
			pre_emp_limit_movie = int(getSetting('preemptive.limit.movie'))
			pre_emp_res_movie = getSetting('preemptive.res.movie') or '0'
			pre_emp_tv = getSetting('preemptive.termination.tv') == 'true'
			pre_emp_limit_tv = int(getSetting('preemptive.limit.tv'))
			pre_emp_res_tv = getSetting('preemptive.res.tv') or '0'
			#new settings for tv and movie isolated.
			if self.meta.get('plot'): plotLabel = '[CR][COLOR %s]%s[/COLOR][CR]' % (getSetting('sources.highlight.color'), self.meta.get('plot'))
			else: plotLabel = ''
			source_4k = source_1080 = source_720 = source_sd = total = 0
			total_format = '[COLOR %s][B]%s[/B][/COLOR]'
			total_format2 = '[B]%s[/B]'
			pdiag_format = '[COLOR %s]4K:[/COLOR]  %s  |  [COLOR %s]1080p:[/COLOR]  %s  |  [COLOR %s]720p:[/COLOR]  %s  |  [COLOR %s]SD:[/COLOR]  %s' % (
				self.highlight_color, '%s', self.highlight_color, '%s', self.highlight_color, '%s', self.highlight_color, '%s')
			#pdiagfull_format = '[COLOR %s]4K:[/COLOR]  %s  |  [COLOR %s]1080p:[/COLOR]  %s  |  [COLOR %s]720p:[/COLOR]  %s  |  [COLOR %s]SD:[/COLOR]  %s' % (
			#	sdc, '%s', sdc, '%s', sdc, '%s', sdc, '%s')
			control.hide()
		except:
			log_utils.error()
			try: progressDialog.close()
			except: pass
			del progressDialog
			return

		scrape_stopped = False
		while True:
			try:
				if control.monitor_class().abortRequested(): return sysexit()
				try:
					if progressDialog.iscanceled():
						homeWindow.clearProperty('infinity.window_keep_alive')
						# Stop collecting, then validate the sources already found.
						scrape_stopped = True
						break
				except: pass

				if terminate_onCloud:
					if len([e for e in self.scraper_sources if e['source'] == 'cloud']) > 0: break
				if content == 'movie':
					if pre_emp_movie:
						if pre_emp_res_movie == '0' and source_4k >= pre_emp_limit_movie: break
						elif pre_emp_res_movie == '1' and source_1080 >= pre_emp_limit_movie: break
						elif pre_emp_res_movie == '2' and source_720 >= pre_emp_limit_movie: break
						elif pre_emp_res_movie == '3' and source_sd >= pre_emp_limit_movie: break
				else:
					if pre_emp_tv:
						if pre_emp_res_tv == '0' and source_4k >= pre_emp_limit_tv: break
						elif pre_emp_res_tv == '1' and source_1080 >= pre_emp_limit_tv: break
						elif pre_emp_res_tv == '2' and source_720 >= pre_emp_limit_tv: break
						elif pre_emp_res_tv == '3' and source_sd >= pre_emp_limit_tv: break
				if quality == '0':
					source_4k = len([e for e in self.scraper_sources if e['quality'] == '4K'])
					source_1080 = len([e for e in self.scraper_sources if e['quality'] == '1080p'])
					source_720 = len([e for e in self.scraper_sources if e['quality'] == '720p'])
					source_sd = len([e for e in self.scraper_sources if e['quality'] in ('SD', 'SCR', 'CAM')])
				elif quality == '1':
					source_1080 = len([e for e in self.scraper_sources if e['quality'] == '1080p'])
					source_720 = len([e for e in self.scraper_sources if e['quality'] == '720p'])
					source_sd = len([e for e in self.scraper_sources if e['quality'] in ('SD', 'SCR', 'CAM')])
				elif quality == '2':
					source_720 = len([e for e in self.scraper_sources if e['quality'] == '720p'])
					source_sd = len([e for e in self.scraper_sources if e['quality'] in ('SD', 'SCR', 'CAM')])
				else:
					source_sd = len([e for e in self.scraper_sources if e['quality'] in ('SD', 'SCR', 'CAM')])
				total = source_4k + source_1080 + source_720 + source_sd

				source_4k_label = total_format2 % (source_4k) if source_4k == 0 else total_format % (sdc, source_4k)
				source_1080_label = total_format2 % (source_1080) if source_1080 == 0 else total_format % (sdc, source_1080)
				source_720_label = total_format2 % (source_720) if source_720 == 0 else total_format % (sdc, source_720)
				source_sd_label = total_format2 % (source_sd) if source_sd == 0 else total_format % (sdc, source_sd)
				source_total_label = total_format2 % (total) if total == 0 else total_format % (sdc, total)
				try:
					info = [x.getName() for x in threads if x.is_alive() is True]
					line1 = pdiag_format % (source_4k_label, source_1080_label, source_720_label, source_sd_label)
					#line2 = string4 % source_total_label + '     ' + string1 % round(time() - start_time, 1)
					line2 = string1 % round(time() - start_time, 1)
					if len(info) > 6: line3 = string3 % str(len(info))
					elif len(info) > 0: line3 = string3 % (', '.join(info))
					else:
						source_4k = len([e for e in self.scraper_sources if e['quality'] == '4K'])
						source_1080 = len([e for e in self.scraper_sources if e['quality'] == '1080p'])
						source_720 = len([e for e in self.scraper_sources if e['quality'] == '720p'])
						source_sd = len([e for e in self.scraper_sources if e['quality'] in ('SD', 'SCR', 'CAM')])
						source_4k_label = total_format2 % source_4k if source_4k == 0 else total_format % (sdc, source_4k)
						source_1080_label = total_format2 % source_1080 if source_1080 == 0 else total_format % (sdc, source_1080)
						source_720_label = total_format2 % source_720 if source_720 == 0 else total_format % (sdc, source_720)
						source_sd_label = total_format2 % source_sd if source_sd == 0 else total_format % (sdc, source_sd)
						line1 = pdiag_format % (source_4k_label, source_1080_label, source_720_label, source_sd_label)
						if progressDialog != control.progressDialog and progressDialog != control.progressDialogBG:
							progressDialog.update(100, line1 + '[CR]' + line2 + '[CR]' + '')
						elif progressDialog != control.progressDialogBG:
							progressDialog.update(100, line1 + '[CR]' + line2 + '[CR]' + '')
						break
					current_time = time()
					current_progress = current_time - start_time
					#percent = int((current_progress / float(timeout)) * 100)
					percent = int((len(sourceDict) - len(info)) * 100 / len(sourceDict))
					if progressDialog != control.progressDialog and progressDialog != control.progressDialogBG:
						progressDialog.update(max(1, percent), line1 + '[CR]' + line2 + '[CR]' + line3 + '[CR]' + f'{percent}%' + '[CR]' + plotLabel)
					elif progressDialog != control.progressDialogBG: progressDialog.update(max(1, percent), line1 + '[CR]' + line2 + '[CR]' + line3)
					else: progressDialog.update(max(1, percent), line1 + '  ' + string3 % str(len(info)))
					if end_time < current_time: break
				except:
					log_utils.error()
					break
				control.sleep(25)
			except: log_utils.error()
		progressDialog.update(100, debrid_message)
		del threads[:] # Make sure any remaining providers are stopped, only deletes threads not started yet.
		self.sources.extend(self.scraper_sources)
		self.tvshowtitle = tvshowtitle
		self.year = year
		homeWindow.clearProperty('fs_filterless_search')
		# A stopped scrape leaves the dialog canceled; do not reuse that signal
		# to cancel the provider checks needed to make collected sources usable.
		if len(self.sources) > 0: self.sourcesFilter(None if scrape_stopped else progressDialog)
		if homeWindow.getProperty('infinity.window_keep_alive') != 'true':
			try: progressDialog.close()
			except: pass
			del progressDialog
		return self.sources

	def preResolve(self, next_sources, next_meta):
		playerWindow.clearProperty('infinity.preResolved_nextUrl')
		try:
			preference = source_preferences.get(next_meta)
			if preference: next_sources = source_preferences.matching(next_sources, preference)
			#next_sources = [i for i in next_sources if not i.get('cloud_folder')]
			if not next_sources: raise Exception()
			homeWindow.setProperty(self.metaProperty, jsdumps(next_meta))
			if getSetting('autoplay.sd') == 'true': next_sources = [i for i in next_sources if not i['quality'] in ('4K', '1080p', '720p')]
			uncached_filter = [i for i in next_sources if re.match(r'^uncached.*torrent', i['source'])]
			next_sources = [i for i in next_sources if i not in uncached_filter]
		except:
			log_utils.error('preResolve: ')
			return playerWindow.clearProperty('infinity.preResolved_nextUrl')

		homeWindow.setProperty('infinity.preResolving', 'true')
		try:
			for i in range(len(next_sources)):
				try:
					control.sleep(1000)
					try:
						if control.monitor_class().abortRequested(): return sysexit()
						url = self.sourcesResolve(next_sources[i])
						if not url:
							if self.debuglog:
								log_utils.log('preResolve failed for : next_sources[i]=%s' % str(next_sources[i]), level=log_utils.LOGWARNING)
							continue
						# if not any(x in url.lower() for x in video_extensions) and 'plex.direct:' not in self.url and 'torbox' not in self.url and 'tb-cdn' not in self.url and 'plugin://plugin.video.composite_for_plex' not in self.url:
						if not any(x in url.lower() for x in video_extensions):
							if self.debuglog:
								log_utils.log('preResolve Playback not supported for (sourcesAutoPlay()): %s' % url, level=2)
							continue
						if url:
							control.sleep(500)
							player_hasVideo = control.condVisibility('Player.HasVideo')
							if player_hasVideo: # do not setPropery if user stops playback quickly because "onPlayBackStopped" is already called and won't be able to clear it.
								playerWindow.setProperty('infinity.preResolved_nextUrl', url)
								playerWindow.setProperty('infinity.preResolved_season', str(next_meta.get('season', '')))
								playerWindow.setProperty('infinity.preResolved_episode', str(next_meta.get('episode', '')))
								playerWindow.setProperty('infinity.preResolved_imdb', str(next_meta.get('imdb', '')))
								playerWindow.setProperty('infinity.preResolved_tmdb', str(next_meta.get('tmdb', '')))
								if self.debuglog:log_utils.log('preResolved_nextUrl : %s' % url, level=0)
							else:
								if self.debuglog:log_utils.log('player_hasVideo = %s : skipping setting preResolved_nextUrl' % player_hasVideo, level=2)
							break
					except: pass
				except: log_utils.error()
		finally:
			homeWindow.clearProperty('infinity.preResolving')
		control.sleep(200)

	def prepareSources_dialog(self, progressDialog, imdb, content, timeout=30):
		# Keep cache locks and optional Trakt alias requests off the dialog thread.
		result = []
		def prepare():
			try:
				self.prepareSources()
				result.append(self.getAliasTitles(imdb, content) or [])
			except: log_utils.error()
		worker = Thread(target=prepare)
		worker.daemon = True
		worker.start()
		deadline = time() + timeout
		while worker.is_alive():
			if control.monitor_class().abortRequested(): return None
			try:
				if progressDialog.iscanceled(): return None
			except: pass # Background dialogs do not expose cancellation.
			if time() >= deadline:
				log_utils.log('Source preparation timed out; continuing without Trakt aliases', level=log_utils.LOGWARNING)
				return []
			control.sleep(50)
		return result[0] if result else []

	def prepareSources(self):
		try:
			control.makeFile(control.dataPath)
			dbcon = database.connect(sourceFile)
			dbcur = dbcon.cursor()
			dbcur.execute('''CREATE TABLE IF NOT EXISTS rel_src (source TEXT, imdb_id TEXT, season TEXT, episode TEXT, hosts TEXT, added TEXT, UNIQUE(source, imdb_id, season, episode));''')
			dbcur.execute('''CREATE TABLE IF NOT EXISTS rel_aliases (title TEXT, aliases TEXT, UNIQUE(title));''')
			dbcur.connection.commit()
		except: log_utils.error()
		finally:
			try: dbcur.close() ; dbcon.close()
			except: pass

	def getMovieSource(self, imdb, data, source, call):
		# log_utils.log(f'imdb: {imdb}, data: {data}, source: {source}, call: {call}')
		dbcur = None
		try:
			dbcon = database.connect(sourceFile, timeout=60)
			dbcon.execute('''PRAGMA page_size = 32768''')
			dbcon.execute('''PRAGMA journal_mode = WAL''')
			dbcon.execute('''PRAGMA synchronous = OFF''')
			dbcon.execute('''PRAGMA temp_store = memory''')
			dbcon.execute('''PRAGMA mmap_size = 30000000000''')
			dbcur = dbcon.cursor()
		except: pass
		if not imdb: # Fix to stop items passed with null IMDB_id pulling old unrelated sources from the database
			try:
				for table in ["rel_src"]: dbcur.execute('''DELETE FROM {} WHERE (source=? AND imdb_id='' AND season='' AND episode='')'''.format(table), (source, ))
				# dbcur.execute('''DELETE FROM rel_src WHERE (source=? AND imdb_id='' AND season='' AND episode='')''', (source,))
				dbcur.connection.commit()
			except: log_utils.error()
		try:
			sources = []
			db_movie = dbcur.execute('''SELECT * FROM rel_src WHERE (source=? AND imdb_id=? AND season='' AND episode='')''', (source, imdb)).fetchone()
			if db_movie:
				timestamp = cleandate.datetime_from_string(str(db_movie[5]), '%Y-%m-%d %H:%M:%S.%f', False)
				db_movie_valid = abs(self.time - timestamp) < single_expiry
				if db_movie_valid:
					sources = eval(db_movie[4])
					return self.scraper_sources.extend(sources)
		except: log_utils.error()
		title, aliases, year = data.get('title', ''), data.get('aliases', []), data.get('year', '')
		try:
			url = call.movie(imdb, title, title, aliases, year)
		except: log_utils.error(f'call: {call}')
		try:
			sources = []
			sources = call.sources(url, self.hostprDict)
			if sources:
				sources = self.process_sources(sources, source, '%s %s' % (title, year))
				self.scraper_sources.extend(sources)
				_write_provider_cache(dbcur, '''INSERT OR REPLACE INTO rel_aliases Values (?, ?)''', (data.get('title', ''), repr(data.get('aliases', ''))))
				_write_provider_cache(dbcur, '''INSERT OR REPLACE INTO rel_src Values (?, ?, ?, ?, ?, ?)''', (source, imdb, '', '', repr(sources), datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")))
			return self.scraper_sources.extend(sources)
		except: log_utils.error(f'call: {call}')

	def getEpisodeSource(self, imdb, season, episode, data, source, call, pack):
		from resources.lib.modules.episode_mapping import scrape_variants
		variants = [data] if self.custom_query == 'true' else scrape_variants(getattr(self, 'scrape_tmdb', ''), data)
		for variant in variants:
			if control.monitor_class().abortRequested(): return
			cache_id = ('anthology-v1:%s:%s' % (variant['_scrape_tmdb'], variant['_scrape_convention'])) if variant.get('_scrape_tmdb') else imdb
			self._getEpisodeSource(cache_id, variant['season'], variant['episode'], variant, source, call, pack)

	def _getEpisodeSource(self, imdb, season, episode, data, source, call, pack):
		from resources.lib.modules.episode_mapping import tag_sources
		dbcur = None
		try:
			dbcon = database.connect(sourceFile, timeout=60)
			dbcon.execute('''PRAGMA page_size = 32768''')
			dbcon.execute('''PRAGMA journal_mode = WAL''')
			dbcon.execute('''PRAGMA synchronous = OFF''')
			dbcon.execute('''PRAGMA temp_store = memory''')
			dbcon.execute('''PRAGMA mmap_size = 30000000000''')
			dbcur = dbcon.cursor()
		except: pass
		if not imdb: # Fix to stop items passed with null IMDB_id pulling old unrelated sources from the database
			try:
				for table in ["rel_src"]: dbcur.execute('''DELETE FROM {} WHERE (source=? AND imdb_id='' AND season=? AND episode=?)'''.format(table), (source, season, episode))
				dbcur.execute('''DELETE FROM rel_src WHERE (source=? AND imdb_id='' AND season=? AND episode='')''', (source, season))
				for table in ["rel_src"]: dbcur.execute('''DELETE FROM {} WHERE (source=? AND imdb_id='' AND season='' AND episode='')'''.format(table), (source, ))
				dbcur.connection.commit()
			except: log_utils.error()
		if not pack: # singleEpisodes db check
			try:
				db_singleEpisodes = dbcur.execute('''SELECT * FROM rel_src WHERE (source=? AND imdb_id=? AND season=? AND episode=?)''', (source, imdb, season, episode)).fetchone()
				# log_utils.log(f'self.scraper_sources: {len(self.scraper_sources)} db_singleEpisodes: {len(db_singleEpisodes)} db_singleEpisodes: {db_singleEpisodes}')
				if db_singleEpisodes:
					timestamp = cleandate.datetime_from_string(str(db_singleEpisodes[5]), '%Y-%m-%d %H:%M:%S.%f', False)
					db_singleEpisodes_valid = abs(self.time - timestamp) < single_expiry
					if db_singleEpisodes_valid:
						sources = eval(db_singleEpisodes[4])
						return self.scraper_sources.extend(tag_sources(sources, data))
			except: log_utils.error()
		elif pack == 'season': # seasonPacks db check
			try:
				db_seasonPacks = dbcur.execute('''SELECT * FROM rel_src WHERE (source=? AND imdb_id=? AND season=? AND episode='')''', (source, imdb, season)).fetchone()
				if db_seasonPacks:
					timestamp = cleandate.datetime_from_string(str(db_seasonPacks[5]), '%Y-%m-%d %H:%M:%S.%f', False)
					db_seasonPacks_valid = abs(self.time - timestamp) < season_expiry
					if db_seasonPacks_valid:
						sources = eval(db_seasonPacks[4])
						sources = [i for i in sources if not 'episode_start' in i or i['episode_start'] <= int(episode) <= i['episode_end']] # filter out range items that do not apply to current episode for return
						return self.scraper_sources.extend(tag_sources(sources, data))
			except: log_utils.error()
		elif pack == 'show': # showPacks db check
			try:
				db_showPacks = dbcur.execute('''SELECT * FROM rel_src WHERE (source=? AND imdb_id=? AND season='' AND episode='')''', (source, imdb)).fetchone()
				if db_showPacks:
					timestamp = cleandate.datetime_from_string(str(db_showPacks[5]), '%Y-%m-%d %H:%M:%S.%f', False)
					db_showPacks_valid = abs(self.time - timestamp) < show_expiry
					if db_showPacks_valid:
						sources = eval(db_showPacks[4])
						sources = [i for i in sources if i.get('last_season') >= int(season)] # filter out range items that do not apply to current season for return
						return self.scraper_sources.extend(tag_sources(sources, data))
			except: log_utils.error()

		try: #dummy write or threads wait till return from scrapers...write for each is needed
			dbcur.execute('''INSERT OR REPLACE INTO rel_src Values (?, ?, ?, ?, ?, ?)''', ('dummy write', '', '', '', '', ''))
			dbcur.connection.commit()
		except: log_utils.error()
		tvdb, title, tvshowtitle, aliases, premiered, year = data.get('tvdb', ''), data.get('title', ''), data.get('tvshowtitle', ''), data.get('aliases', []), data.get('premiered', ''), data.get('year', '')
		try:
			url = call.tvshow(imdb, tvdb, tvshowtitle, tvshowtitle, aliases, year)
		except: log_utils.error(f'call: {call} pack: {pack}')
		try:
			if url:
				ep_url = call.episode(url, imdb, tvdb, title, premiered, season, episode)
		except: log_utils.error(f'call: {call} pack: {pack}')
		if not pack: # singleEpisodes scraper call
			try:
				# log_utils.log(f'should not b here: {source}')
				sources = []
				sources = call.sources(ep_url, self.hostprDict)
				if sources:
					_write_provider_cache(dbcur, '''INSERT OR REPLACE INTO rel_src Values (?, ?, ?, ?, ?, ?)''', (source, imdb, season, episode, repr(sources), datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")))
					return self.scraper_sources.extend(tag_sources(sources, data))
				# return self.scraper_sources.extend(sources)
			except: return log_utils.error()
		elif pack == 'season': # seasonPacks scraper call
			try:
				sources = []
				sources = call.sources_packs(data, self.hostprDict, bypass_filter=self.dev_disable_season_filter)
				if sources:
					_write_provider_cache(dbcur, '''INSERT OR REPLACE INTO rel_src Values (?, ?, ?, ?, ?, ?)''', (source, imdb, season,'', repr(sources), datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")))
					sources = [i for i in sources if not 'episode_start' in i or i['episode_start'] <= int(episode) <= i['episode_end']] # filter out range items that do not apply to current episode for return
					return self.scraper_sources.extend(tag_sources(sources, data))
				return
			except: return log_utils.error()
		elif pack == 'show': # showPacks scraper call
			try:
				sources = []
				sources = call.sources_packs(data, self.hostprDict, search_series=True, total_seasons=data.get('_scrape_total_seasons', self.total_seasons), bypass_filter=self.dev_disable_show_filter)
				if sources:
					_write_provider_cache(dbcur, '''INSERT OR REPLACE INTO rel_src Values (?, ?, ?, ?, ?, ?)''', (source, imdb, '', '', repr(sources), datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")))
					sources = [i for i in sources if i.get('last_season') >= int(season)] # filter out range items that do not apply to current season for return
					return self.scraper_sources.extend(tag_sources(sources, data))
			except: log_utils.error()

	def sourcesFilter(self, progressDialog=None):
		if not self.isPrescrape: control.busy()
		# log_utils.log(f'1self.sources total {len(self.sources)}: {self.sources}')
		if getSetting('remove.duplicates') == 'true': self.sources = self.filter_dupes()
		# log_utils.log(f'IN self.sources total {len(self.sources)}: {self.sources}')
		if self.mediatype == 'movie':
			if getSetting('source.filtermbysize') == '1':
				try:
					movie_minSize, movie_maxSize = float(getSetting('source.min.moviesize')), float(getSetting('source.max.moviesize'))
					self.sources = [i for i in self.sources if (i.get('size', 0) >= movie_minSize and i.get('size', 0) <= movie_maxSize)]
				except: log_utils.error()
			if getSetting('source.filtermbysize') == '2':
				try:
					duration = self.meta.get('duration') or 5400
					max_size = (0.125 * (0.90 * float(getSetting('source.movie.linespeed', '20'))) * duration)/1000
					self.sources = [i for i in self.sources if (i.get('size', 0) <= max_size)]
				except: log_utils.error()
		else:
			self.sources = [i for i in self.sources if 'movie.collection' not in i.get('name_info', '')] # rare but a few retuned from "complete" show pack scrape returned as "movie.collection"
			if getSetting('source.checkReboots') == 'true':
				try:
					from resources.lib.modules.source_utils import tvshow_reboots
					reboots = tvshow_reboots()
					if self.tvshowtitle in reboots and reboots.get(self.tvshowtitle) == self.year:
						log_utils.log('tvshowtitle(%s) is a REBOOT, filtering for year match per enabled setting' % self.tvshowtitle, level= log_utils.LOGDEBUG)
						self.sources = [i for i in self.sources if self.year in i.get('name')]
				except: log_utils.error()
			if getSetting('source.filterebysize') == '1':
				try:
					episode_minSize, episode_maxSize = float(getSetting('source.min.epsize')), float(getSetting('source.max.epsize'))
					self.sources = [i for i in self.sources if (i.get('size', 0) >= episode_minSize and i.get('size', 0) <= episode_maxSize)]
				except: log_utils.error()
			if getSetting('source.filterebysize') == '2':
				try:
					duration = self.meta.get('duration') or 2400
					max_size = (0.125 * (0.90 * float(getSetting('source.episode.linespeed', '20'))) * duration)/1000
					self.sources = [i for i in self.sources if (i.get('size', 0) <= max_size)]
				except: log_utils.error()
			try: self.sources = self.calc_pack_size()
			except: pass
		# for i in self.sources:
			# try:
				# if 'name_info' in i: info_string = getFileType(name_info=i.get('name_info'))
				# else: info_string = getFileType(url=i.get('url'))
				# i.update({'info': '{} /{}'.format(i.get('info'), info_string).lstrip(' ').lstrip('/').rstrip('/')})
			# except: log_utils.error()
		# log_utils.log(f'b4 remove len(self.sources): {len(self.sources)} :{self.sources}')
		if getSetting('remove.hevc') == 'true':
			self.sources = [i for i in self.sources if 'HEVC' not in i.get('info', '')]
		if getSetting('remove.av1') == 'true':
			self.sources = [i for i in self.sources if ' AV1 ' not in i.get('info', '')]
		if getSetting('remove.atvp') == 'true':
			self.sources = [i for i in self.sources if ' APPLE-TV-PLUS ' not in i.get('info', '')]
		if getSetting('remove.avc') == 'true':
			self.sources = [i for i in self.sources if ' AVC ' not in i.get('info', '')]
		if getSetting('remove.divx') == 'true':
			self.sources = [i for i in self.sources if ' DIVX ' not in i.get('info', '')]
		if getSetting('remove.mp4') == 'true':
			self.sources = [i for i in self.sources if ' MP4 ' not in i.get('info', '')]
		if getSetting('remove.mpeg') == 'true':
			self.sources = [i for i in self.sources if ' MPEG ' not in i.get('info', '')]
		if getSetting('remove.wmv') == 'true':
			self.sources = [i for i in self.sources if ' WMV ' not in i.get('info', '')]
		if getSetting('remove.hdr') == 'true':
			self.sources = [i for i in self.sources if ' HDR ' not in i.get('info', '')] # needs space before and aft because of "HDRIP"
		if getSetting('remove.dolby.vision') == 'true':
			self.sources = [i for i in self.sources if ('DOLBY-VISION' not in i.get('info', '')) or ('DOLBY-VISION' in i.get('info', '') and ' HDR ' in i.get('info', ''))]
		if getSetting('remove.cam.sources') == 'true':
			self.sources = [i for i in self.sources if i['quality'] != 'CAM']
		if getSetting('remove.sd.sources') == 'true':
			if any(i for i in self.sources if any(value in i['quality'] for value in ('4K', '1080p', '720p'))): #only remove SD if better quality does exist
				self.sources = [i for i in self.sources if i['quality'] != 'SD']
		if getSetting('remove.3D.sources') == 'true':
			self.sources = [i for i in self.sources if '3D' not in i.get('info', '')]
		if getSetting('remove.aiupscaled.sources') == 'true':
			self.sources = [i for i in self.sources if ' AI-UPSCALED ' not in i.get('info', '')]
		if getSetting('remove.audio.opus') == 'true':   #start of audio codec filters
			self.sources = [i for i in self.sources if ' OPUS ' not in i.get('info', '')]
		if getSetting('remove.audio.atmos') == 'true':
			self.sources = [i for i in self.sources if ' ATMOS ' not in i.get('info', '')]
		if getSetting('remove.audio.dd') == 'true':
			self.sources = [i for i in self.sources if ' DOLBYDIGITAL ' not in i.get('info', '')]
		if getSetting('remove.audio.ddplus') == 'true':
			self.sources = [i for i in self.sources if ' DD+ ' not in i.get('info', '')]
		if getSetting('remove.audio.dts') == 'true':
			self.sources = [i for i in self.sources if ' DTS ' not in i.get('info', '')]
		if getSetting('remove.audio.dtshd') == 'true':
			self.sources = [i for i in self.sources if ' DTS-HD ' not in i.get('info', '')]
		if getSetting('remove.audio.dtshdma') == 'true':
			self.sources = [i for i in self.sources if ' DTS-HD MA ' not in i.get('info', '')]
		if getSetting('remove.audio.dtsx') == 'true':
			self.sources = [i for i in self.sources if ' DTS-X ' not in i.get('info', '')]
		if getSetting('remove.audio.ddtruehd') == 'true':
			self.sources = [i for i in self.sources if ' DOLBY-TRUEHD ' not in i.get('info', '')]
		if getSetting('remove.audio.aac') == 'true':
			self.sources = [i for i in self.sources if ' AAC ' not in i.get('info', '')]
		if getSetting('remove.audio.mp3') == 'true':
			self.sources = [i for i in self.sources if ' MP3 ' not in i.get('info', '')]
		if getSetting('remove.channel.2ch') == 'true':  # start of audio channel filters
			self.sources = [i for i in self.sources if ' 2CH ' not in i.get('info', '')]
		if getSetting('remove.channel.6ch') == 'true':
			self.sources = [i for i in self.sources if ' 6CH ' not in i.get('info', '')]
		if getSetting('remove.channel.7ch') == 'true':
			self.sources = [i for i in self.sources if ' 7CH ' not in i.get('info', '')]
		if getSetting('remove.channel.8ch') == 'true':
			self.sources = [i for i in self.sources if ' 8CH ' not in i.get('info', '')]
		# log_utils.log(f'af4 remove len(self.sources): {len(self.sources)} :{self.sources}')
		local = [i for i in self.sources if 'local' in i and i['local'] is True] # for library and videoscraper (skips cache check)
		self.sources = [i for i in self.sources if not i in local]
		direct = [i for i in self.sources if i['direct'] == True] # acct scrapers (skips cache check)
		directstart = [] # blank start for enabled only
		#import web_pdb; web_pdb.set_trace()
		if getSetting('easynews.enable') == 'true':
			directstart.extend([i for i in direct if i['provider'] == 'easynews'])
		if getSetting('plexshare.enable') == 'true':
			directstart.extend([i for i in direct if i['provider'] == 'plexshare'])
		if getSetting('gdrive.enable') == 'true':
			directstart.extend([i for i in direct if i['provider'] == 'gdrive'])
		if getSetting('filepursuit.enable') == 'true':
			directstart.extend([i for i in direct if i['provider'] == 'filepursuit'])
		if getSetting('rd_cloud.enabled') == 'true':
			directstart.extend([i for i in direct if i['provider'] == 'rd_cloud'])
		if getSetting('pm_cloud.enabled') == 'true':
			directstart.extend([i for i in direct if i['provider'] == 'pm_cloud'])
		if getSetting('ad_cloud.enabled') == 'true':
			directstart.extend([i for i in direct if i['provider'] == 'ad_cloud'])
		if getSetting('tb_cloud.enabled') == 'true':
			directstart.extend([i for i in direct if i['provider'] == 'tb_cloud'])
		if getSetting('oc_cloud.enabled') == 'true':
			directstart.extend([i for i in direct if i['provider'] == 'oc_cloud'])
		#direct = directstart
		self.sources = [i for i in self.sources if not i in directstart]
		# log_utils.log(f'not directstart self.sources total {len(self.sources)}: {self.sources}')
		from copy import deepcopy
		deepcopy_sources = deepcopy(self.sources)
		deepcopy_sources = [i for i in deepcopy_sources if 'magnet:' in i['url']]
		if deepcopy_sources: hashList = [i['hash'] for i in deepcopy_sources]
		threads = [] ; self.filter = []
		cache_results = []
		hoster_sources = [dict(i) for i in self.sources if 'magnet:' not in i['url']]
		valid_hosters = set([i['source'] for i in self.sources if 'magnet:' not in i['url']])
		control.hide()

		def checkStatus(function, debrid_name, valid_hoster):
			try:
				cached = None
				if deepcopy_sources: cached = function(deepcopy(deepcopy_sources), hashList)
				if cached: results = [dict(list(i.items()) + [('debrid', debrid_name)]) for i in cached] # this makes a new instance so no need for deepcopy beyond the one time done now
				if valid_hoster: results += [dict(list(i.items()) + [('debrid', debrid_name)]) for i in self.sources if i['source'] in valid_hoster and 'magnet:' not in i['url']]
				cache_results.append(results)
			except: log_utils.error()
		for d in self.debrid_resolvers:
			if d.name == 'Real-Debrid' and getSetting('realdebrid.enable') == 'true':
				try:
					valid_hoster = [i for i in valid_hosters if d.valid_url(i)]
					threads.append(Thread(target=checkStatus, args=(self.rd_cache_chk_list, d.name, valid_hoster)))
				except: log_utils.error()
			if d.name == 'Premiumize.me' and getSetting('premiumize.enable') == 'true':
				try:
					valid_hoster = [i for i in valid_hosters if d.valid_url(i)]
					threads.append(Thread(target=checkStatus, args=(self.pm_cache_chk_list, d.name, valid_hoster)))
				except: log_utils.error()
			if d.name == 'AllDebrid' and getSetting('alldebrid.enable') == 'true':
				try:
					valid_hoster = [i for i in valid_hosters if d.valid_url(i)]
					threads.append(Thread(target=checkStatus, args=(self.ad_cache_chk_list, d.name, valid_hoster)))
				except: log_utils.error()
			if d.name == 'Offcloud' and getSetting('offcloud.enable') == 'true':
				try:
					valid_hoster = []
					threads.append(Thread(target=checkStatus, args=(self.oc_cache_chk_list, d.name, valid_hoster)))
				except: log_utils.error()
			# EasyDebrid disabled
			# if d.name == 'EasyDebrid' and getSetting('easydebrid.enable') == 'true':
			# 	try:
			# 		valid_hoster = []
			# 		threads.append(Thread(name=d.name.upper(), target=checkStatus, args=(self.ed_cache_chk_list, d.name, valid_hoster)))
			# 	except: log_utils.error()
			if d.name == 'TorBox' and getSetting('torbox.enable') == 'true':
				try:
					valid_hoster = []
					threads.append(Thread(target=checkStatus, args=(self.tb_cache_chk_list, d.name, valid_hoster)))
				except: log_utils.error()
		if threads:
			for worker in threads:
				worker.daemon = True
				worker.start()
			deadline = time() + 60
			while any(worker.is_alive() for worker in threads):
				cancelled = control.monitor_class().abortRequested()
				try:
					cancelled = cancelled or (progressDialog is not None and progressDialog.iscanceled())
				except: pass
				if cancelled:
					self.sources = []
					homeWindow.clearProperty('infinity.window_keep_alive')
					return
				if time() >= deadline:
					log_utils.log('Provider cache checks timed out; using completed results', level=log_utils.LOGWARNING)
					break
				control.sleep(50)
		# Workers only publish to their local result list, never the active source list.
		for results in list(cache_results): self.filter.extend(results)
		#self.filter += direct # add direct links in to be considered in priority sorting
		self.filter += directstart
		# log_utils.log(f'directstart self.filter total {len(self.filter)}: {self.filter}')
		try:
			if len(self.prem_providers) > 1: # resort for debrid/direct priorty, when more than 1 account, because of order cache check threads finish
				self.prem_providers.sort(key=lambda k: k[1])
				self.prem_providers = [i[0] for i in self.prem_providers]
				self.prem_providers = self.prem_providers + self.free_provider
				#log_utils.log('self.prem_providers sort order=%s' % self.prem_providers, level=0)
				self.filter.sort(key=lambda k: self.prem_providers.index(k['debrid'] if k.get('debrid', '') else k['provider']))
		except: log_utils.error()

		self.filter += local # library and video scraper sources
		# log_utils.log(f'>>>> self.filter total {len(self.filter)}: {self.filter}')
		self.sources = self.filter + self.sources
		# log_utils.log(f'>>>> self.sources total {len(self.sources)}: {self.sources}')
		if getSetting('realdebrid.filter.filename') == 'true':
			_rd_block = re.compile(r'(?i)\b(WEB-DL|WEBRip|BDRip|HDRip|DVDRip|HDTV|AMZN|NF|DSNP|CR|YTS|TGX|TorrentGalaxy|FGT|LOL|KILLERS|EPSiLON|Erai-raws)\b|rartv|rarbg|eztv')
			self.sources = [i for i in self.sources if not (i.get('debrid') == 'Real-Debrid' and _rd_block.search(i.get('name', '')))]

		self.sources = self.sort_byQuality(self.sources)

		quality_rank_maps = {
			'0': {'4K': 0, '1080p': 1, '720p': 2, 'SCR': 3, 'SD': 4, 'CAM': 5},
			'1': {'4K': 5, '1080p': 0, '720p': 1, 'SCR': 2, 'SD': 3, 'CAM': 4},
			'2': {'4K': 5, '1080p': 4, '720p': 0, 'SCR': 1, 'SD': 2, 'CAM': 3},
			'3': {'4K': 5, '1080p': 4, '720p': 3, 'SCR': 0, 'SD': 1, 'CAM': 2},
		}
		_preferred_q = getSetting('hosts.quality') or '0'
		_qmap = quality_rank_maps.get(_preferred_q, quality_rank_maps['0'])
		if self.prem_providers and isinstance(self.prem_providers[0], tuple):
			_sorted_pp = sorted(self.prem_providers, key=lambda k: k[1])
			_prov_list = [i[0] for i in _sorted_pp]
		else:
			_prov_list = list(self.prem_providers)
		def _qrank(src): return _qmap.get(src.get('quality', 'SD'), 5)
		def _prank(src):
			key = src.get('debrid', '') or src.get('provider', '')
			try: return _prov_list.index(key)
			except: return 10**6
		_prefer_smaller = getSetting('source.prefer.smaller') == 'true'
		def _srank(src): return float(src.get('size', 0)) if _prefer_smaller else -float(src.get('size', 0))
		_sort_order = int(getSetting('sources.sort.order') or '0')
		_sort_keys = (
			lambda k: (_qrank(k), _prank(k), _srank(k)),
			lambda k: (_qrank(k), _srank(k), _prank(k)),
			lambda k: (_prank(k), _qrank(k), _srank(k)),
			lambda k: (_prank(k), _srank(k), _qrank(k)),
			lambda k: (_srank(k), _qrank(k), _prank(k)),
			lambda k: (_srank(k), _prank(k), _qrank(k)),
		)
		if getSetting('source.prefer.dolby.audio') == 'true':
			# Keep quality and provider precedence, then prefer Dolby before size.
			def _audio_rank(src):
				tags = {tag.strip().upper() for tag in (src.get('info') or '').split('/')}
				return 0 if tags.intersection(('ATMOS', 'DOLBY-TRUEHD', 'DD+', 'DOLBYDIGITAL', 'DD-EX')) else 1
			def _dolby_sort_key(src):
				ranks = (_qrank(src), _prank(src)) if _sort_order in (0, 1, 4) else (_prank(src), _qrank(src))
				return ranks + (_audio_rank(src), _srank(src))
			self.sources.sort(key=_dolby_sort_key)
		else:
			self.sources.sort(key=_sort_keys[_sort_order])

		if getSetting('source.prioritize.av1') == 'true': # filter to place AV1 sources first
			filter = []
			filter += [i for i in self.sources if 'AV1' in i.get('info', '')]
			filter += [i for i in self.sources if i not in filter]
			self.sources = filter

		if getSetting('source.prioritize.hevc') == 'true': # filter to place HEVC sources first
			filter = []
			filter += [i for i in self.sources if 'HEVC' in i.get('info', '')]
			filter += [i for i in self.sources if i not in filter]
			self.sources = filter

		if getSetting('source.prioritize.hdrdv') == 'true': # filter to place HDR and DOLBY-VISION sources first
			filter = []
			#will need a new setting for put dolby above hdr
			#filter += [i for i in self.sources if any(value in i.get('info', '') for value in (' HDR ', 'DOLBY-VISION'))]
			if getSetting('source.prioritize.dolbyvisionfirst')=='true':
				if not getSetting('remove.dolby.vision') == 'true':
					filter += [i for i in self.sources if 'DOLBY-VISION' in i.get('info', '')] #dolby first... going to need to check on hdr to make sure it is not added twice
				if not getSetting('remove.hdr') == 'true':
					filter += [i for i in self.sources if ' HDR ' in i.get('info', '') and i not in filter] #warning about the spaces above.
			else:
				filter += [i for i in self.sources if any(value in i.get('info', '') for value in (' HDR ', 'DOLBY-VISION'))]
			filter += [i for i in self.sources if i not in filter]
			self.sources = filter

		# log_utils.log(f'b4 gd len self.sources total {len(self.sources)}: {self.sources}')

		filter = [] # filter to place Google Drive files first
		if getSetting('cloud.sources.first') == 'true': filter += [i for i in self.sources if i['source'] == 'cloud']
		filter += [i for i in self.sources if i['provider'] == 'gdrive']
		filter += [i for i in self.sources if i not in filter]
		# log_utils.log(f'after gd self.filter total {len(self.filter)}: {self.filter}')
		# log_utils.log(f'after gd len self.sources total {len(self.sources)}: {self.sources}')
		self.sources = filter
		# log_utils.log(f'>>>>>>>>> self.sources total {len(self.sources)}: {self.sources}')

		self.sources = self.sources[:4000]
		control.hide()
		return self.sources

	def filter_dupes(self):
		filter = []
		append = filter.append
		remove = filter.remove
		# log_utils.log('total sources: %s for (%s) from list' % (len(self.sources), control.homeWindow.getProperty(self.labelProperty)), level=0)
		log_dupes = getSetting('remove.duplicates.logging') == 'false'
		for i in self.sources:
			larger = False
			a = i['url'].lower()
			# log_utils.log('source : %s' % (i), level=0)
			for sublist in filter:
				try:
					if i['source'] == 'cloud': break
					b = sublist['url'].lower()
					if 'magnet:' in a:
						if i['hash'].lower() in b:
							if sublist['provider'] == 'torrentio' or (len(sublist['name']) > len(i['name']) and i['provider'] != 'torrentio'): # favor "torrentio" or keep matching hash with longer name for possible more info
								larger = True
								break
							remove(sublist)
							if log_dupes: log_utils.log('Removing %s - %s (DUPLICATE TORRENT) ALREADY IN :: %s' % (sublist['provider'], b, i['provider']), level=log_utils.LOGDEBUG)
							break
					elif a == b:
						remove(sublist)
						if log_dupes: log_utils.log('Removing %s - %s (DUPLICATE LINK) ALREADY IN :: %s' % (sublist['source'], i['url'], i['provider']), level=log_utils.LOGDEBUG)
						break
				except: log_utils.error('Error filter_dupes: ')
			if not larger: append(i) # sublist['name'] len() was larger, or "torrentio" so do not append
		item_title = homeWindow.getProperty(self.labelProperty)
		if (self.mediatype == 'movie' or (self.mediatype == 'episode' and not self.enable_playnext)):
			if getSetting('remove.duplicates.popup') != 'true':
				control.notification(title=item_title, message='Removed %s duplicate sources from list' % (len(self.sources) - len(filter)))
		if self.debuglog:
			log_utils.log('Removed %s duplicate sources for (%s) from list' % (len(self.sources) - len(filter), item_title), level=log_utils.LOGDEBUG)
		return filter

	def sourcesAutoPlay(self, title, items):
		url = None
		if getSetting('autoplay.sd') == 'true': items = [i for i in items if not i['quality'] in ('4K', '1080p', '720p')]
		header = homeWindow.getProperty(self.labelProperty) + ': Resolving...'
		try:
			poster = self.meta.get('poster')
		except:
			poster = ''
		try:
			if getSetting('progress.dialog') == '0':
				if getSetting('dialogs.useinfinitydialog') == 'true':
					progressDialog = control.getProgressWindow(header, icon=poster)
				else:
					progressDialog = control.progressDialog
					progressDialog.create(header,'')
			elif getSetting('progress.dialog') in ('2', '3', '4'):
				if homeWindow.getProperty('infinity.window_keep_alive') != 'true':
					progressDialog = self.getWindowProgress(self.title, self.meta)
					Thread(target=self.window_monitor, args=(progressDialog,)).start()
				else: progressDialog = self.window
			else: raise Exception()
		except:
			homeWindow.clearProperty('infinity.window_keep_alive')
			progressDialog = control.progressDialogBG
			progressDialog.create(header, '')
		total_items = len(items)
		#monitor = control.monitor_class()
		for i in range(len(items)):
			try:
				src_provider = items[i]['debrid'] if items[i].get('debrid') else ('%s - %s' % (items[i]['source'], items[i]['provider']))
				index_info = f'{i}/{total_items} ~ {src_provider}'
				if getSetting('progress.dialog') == '2':
					resolveInfo = items[i]['info'].replace('/',' ')
					if self.meta.get('plot'):
						plotLabel = '[COLOR %s]%s[/COLOR][CR][CR]' % (getSetting('sources.highlight.color'), self.meta.get('plot'))
					else:
						plotLabel = ''
					label = plotLabel + '[B][COLOR %s]%s[CR]%s[CR]%s[CR]%s[/COLOR][/B]' % (self.highlight_color, index_info, items[i]['provider'].upper(),items[i]['quality'].upper(), resolveInfo)
				else:
					label = '[COLOR %s]%s[CR]%02d[CR]%s[/COLOR]' % (self.highlight_color, src_provider, i+1, items[i]['name'], str(round(items[i]['size'], 2)) + ' GB') # using "[CR]" has some weird delay with progressDialog.update() at times
				control.sleep(100)
				try:
					if progressDialog.iscanceled(): break
					progressDialog.update(int((100 / float(len(items))) * i), label)
				except: progressDialog.update(int((100 / float(len(items))) * i), '[COLOR %s]Resolving...[/COLOR]%s' % (self.highlight_color, items[i]['name']))
				try:
					if control.monitor_class().abortRequested(): return sysexit()
					url = self.sourcesResolve(items[i])
					# if not any(x in url.lower() for x in video_extensions):
					if not any(x in self.url.lower() for x in video_extensions) and 'plex.direct:' not in self.url and 'torbox' not in self.url and 'tb-cdn' not in self.url and 'plugin://plugin.video.composite_for_plex' not in self.url:
						log_utils.log('Playback not supported for (sourcesAutoPlay()): %s' % url, level=log_utils.LOGWARNING)
						continue
					if url:
						from resources.lib.modules import player
						try:
							iplayer = player.Player()
							iplayer.play_source(title, self.meta.get('year'), self.meta.get('season'), self.meta.get('episode'), self.meta.get('imdb', ''), self.meta.get('tmdb', ''), self.meta.get('tvdb', ''), url, self.meta)
							log_utils.log(f'frm sourcesAutoPlay Playing url from playItem(): {self.url}', level=0)
							if iplayer.isPlayback(): return self.url
							else: continue
						except: log_utils.error(f'Error playItem: {i}')
						# log_utils.log('Playing url from (sourcesAutoPlay()): %s' % url, level=0)
						break
				except: pass
			except: log_utils.error()
		if homeWindow.getProperty('infinity.window_keep_alive') != 'true':
			try: progressDialog.close()
			except: pass
			del progressDialog
		return url

	def sourcesResolve(self, item):
		try:
			url = item['url']
			self.url = None
			debrid_provider = item['debrid'] if item.get('debrid') else ''
		except: log_utils.error()
		if 'magnet:' in url:
			if not 'uncached' in item['source']:
				try:
					meta = homeWindow.getProperty(self.metaProperty) # need for CM "download" action
					if meta:
						meta = jsloads(unquote(meta.replace('%22', '\\"')))
						season, episode, title = meta.get('season'), meta.get('episode'), meta.get('title')
					else:
						season = homeWindow.getProperty(self.seasonProperty)
						episode = homeWindow.getProperty(self.episodeProperty)
						title = homeWindow.getProperty(self.titleProperty)
					from resources.lib.modules.episode_mapping import source_coordinates
					season, episode = source_coordinates(item, meta if isinstance(meta, dict) else {}, season, episode)
					if debrid_provider == 'Real-Debrid':
						from resources.lib.debrid.realdebrid import RealDebrid as debrid_function
					elif debrid_provider == 'Premiumize.me':
						from resources.lib.debrid.premiumize import Premiumize as debrid_function
					elif debrid_provider == 'AllDebrid':
						from resources.lib.debrid.alldebrid import AllDebrid as debrid_function
					elif debrid_provider == 'Offcloud':
						from resources.lib.debrid.offcloud import Offcloud as debrid_function
					# elif debrid_provider == 'EasyDebrid':  # EasyDebrid disabled
					# 	from resources.lib.debrid.easydebrid import EasyDebrid as debrid_function
					elif debrid_provider == 'TorBox':
						from resources.lib.debrid.torbox import TorBox as debrid_function
					else: return
					
					premiered = meta.get('premiered') or meta.get('firstaired') if isinstance(meta, dict) else None
					url = debrid_function().resolve_magnet(url, item['hash'], season, episode, title, premiered=premiered)
					self.url = url
					return url
				except:
					log_utils.error()
					return
		else:
			try:
				direct = item['direct']
				if direct:
					urls = url.split(' , ')
					url = 'stack://' + ' , '.join(urls) if len(urls) > 1 else urls[0]
					self.url = url
					return url
				else:
					local = item.get('local', False)
					module_path = f'openscrapers.sources_openscrapers.en.{item["provider"]}'
					# log_utils.log('sourcesResolve item: %s' % item, level=0)
					call = manual_module_import(module_path).source()
					# log_utils.log('sourcesResolve call: %s' % call, level=0)
					url = call.resolve(item['url'])
					# log_utils.log('sourcesResolve url: %s' % url, level=0)
					urls = []
					if url is None or ('://' not in url): raise Exception(f'url: {repr(url)}\nitem: {repr(item)}') # and not local and 'magnet:' not in url):
					url = url[8:] if url.startswith('stack:') else url
					if not local:
						for part in url.split(' , '):
							rpart = check_hosted_media(part)
							if rpart: urls.append(rpart)
					if not urls: return None
					url = 'stack://' + ' , '.join(urls) if len(urls) > 1 else urls[0]
					if url is False or url is None: raise Exception()
					ext = url.split('?')[0].split('&')[0].split('|')[0].rsplit('.')[-1].replace('/', '').lower()
					if ext == 'rar': raise Exception()
					# try:
						# furl = url.split('|')
						# headers = furl[1]
						# headers = quote_plus(headers).replace('%3D', '=') if ' ' in headers else headers
						# headers = dict(parse_qsl(headers))
					# except: headers = {}
					# if url.startswith('http') and '.m3u8' in url:
						# result = request(furl[0], headers=headers, output='geturl', timeout='20')
						# if result is None: raise Exception()
					# elif url.startswith('http'):
						# result = request(furl[0], headers=headers, output='chunk', timeout='20')
						# if result is None: raise Exception()
					log_utils.log('sourcesResolve url: %s' % url, level=0)
					self.url = url
					return url
			except:
				log_utils.error(f'Error sourcesResolve item: {item} : {print_exc()}')
				return

	def debridPackDialog(self, provider, name, magnet_url, info_hash):
		try:
			if provider in ('Real-Debrid', 'RD'):
				from resources.lib.debrid.realdebrid import RealDebrid as debrid_function
			elif provider in ('Premiumize', 'PM'):
				from resources.lib.debrid.premiumize import Premiumize as debrid_function
			elif provider in ('AllDebrid', 'AD'):
				from resources.lib.debrid.alldebrid import AllDebrid as debrid_function
			elif provider in ('Offcloud', 'OC'):
				from resources.lib.debrid.offcloud import Offcloud as debrid_function
			# elif provider in ('EasyDebrid', 'ED'):  # EasyDebrid disabled
			# 	from resources.lib.debrid.easydebrid import EasyDebrid as debrid_function
			elif provider in ('TorBox', 'TB'):
				from resources.lib.debrid.torbox import TorBox as debrid_function
			else: return
			debrid_files = None
			control.busy()
			try: debrid_files = debrid_function().display_magnet_pack(magnet_url, info_hash)
			except: pass
			if not debrid_files:
				control.hide()
				return control.notification(message=32399)
			debrid_files = sorted(debrid_files, key=lambda k: k['filename'].lower())
			display_list = ['%02d | [B]%.2f GB[/B] | [I]%s[/I]' % (count, i['size'], i['filename'].upper()) for count, i in enumerate(debrid_files, 1)]
			control.hide()
			chosen = control.selectDialog(display_list, heading=name)
			if chosen < 0:
				if provider in ('TorBox', 'TB'):
					if not getSetting('torbox.saveToCloud') == 'true':
						torrent_id = debrid_files[0].get('link').split(',')[0]
						debrid_function().delete_torrent(torrent_id)
				return None
			if control.condVisibility("Window.IsActive(source_results.xml)"): # close "source_results.xml" here after selection is made and valid
				control.closeAll()
			control.busy()
			chosen_result = debrid_files[chosen]
			if provider in ('Real-Debrid', 'RD'):
				self.url = debrid_function().unrestrict_link(chosen_result['link'])
			elif provider in ('Premiumize', 'PM'):
				self.url = debrid_function().add_headers_to_url(chosen_result['link'])
			elif provider in ('AllDebrid', 'AD'):
				self.url = debrid_function().unrestrict_link(chosen_result['link'])
			elif provider in ('Offcloud', 'OC'):
				self.url = chosen_result['link']
			# elif provider in ('EasyDebrid', 'ED'):  # EasyDebrid disabled
			# 	self.url = chosen_result['link']
			elif provider in ('TorBox', 'TB'):
				self.url = debrid_function().unrestrict_link(chosen_result['link'])
				if not getSetting('torbox.saveToCloud') == 'true':
					torrent_id = chosen_result.get('link').split(',')[0]
					debrid_function().delete_torrent(torrent_id)
			from resources.lib.modules import player
			meta = jsloads(unquote(homeWindow.getProperty(self.metaProperty).replace('%22', '\\"'))) # needed for CM "showDebridPack" action
			title = meta['tvshowtitle']
			year = meta['year'] if 'year' in meta else None
			season = meta['season'] if 'season' in meta else None
			episode = meta['episode'] if 'episode' in meta else None
			imdb = meta['imdb'] if 'imdb' in meta else None
			tmdb = meta['tmdb'] if 'tmdb' in meta else None
			tvdb = meta['tvdb'] if 'tvdb' in meta else None
			release_title = chosen_result['filename']
			control.hide()
			from resources.lib.modules import source_utils
			if source_utils.seas_ep_filter(season, episode, release_title, premiered=meta.get('premiered') or meta.get('firstaired')):
				return player.Player().play_source(title, year, season, episode, imdb, tmdb, tvdb, self.url, meta, debridPackCall=True) # hack fix for setResolvedUrl issue
			else:
				return player.Player().play(self.url)
		except:
			log_utils.error('Error debridPackDialog: ')
			control.hide()

	def sourceInfo(self, item):
		try:
			from sys import platform as sys_platform
			supported_platform = any(value in sys_platform for value in ('win32', 'linux2'))
			source = jsloads(item)[0]
			list = [('[COLOR %s]url:[/COLOR]  %s' % (self.highlight_color, source.get('url')), source.get('url'))]
			if supported_platform: list += [('[COLOR %s]  -- Copy url To Clipboard[/COLOR]' % self.highlight_color, ' ')] # "&" in magnets causes copy2clip to fail .replace('&', '^&').strip() used in copy2clip() method
			list += [('[COLOR %s]name:[/COLOR]  %s' % (self.highlight_color, source.get('name')), source.get('name'))]
			if supported_platform: list += [('[COLOR %s]  -- Copy name To Clipboard[/COLOR]' % self.highlight_color, ' ')]
			list += [('[COLOR %s]info:[/COLOR]  %s' % (self.highlight_color, source.get('info')), ' ')]
			if 'magnet:' in source.get('url'):
				list += [('[COLOR %s]hash:[/COLOR]  %s' % (self.highlight_color, source.get('hash')), source.get('hash'))]
				if supported_platform: list += [('[COLOR %s]  -- Copy hash To Clipboard[/COLOR]' % self.highlight_color, ' ')]
				list += [('[COLOR %s]seeders:[/COLOR]  %s' % (self.highlight_color, source.get('seeders')), ' ')]
			select = control.selectDialog([i[0] for i in list], 'Source Info')
			if any(x in list[select][0] for x in ('Copy url To Clipboard', 'Copy name To Clipboard', 'Copy hash To Clipboard')):
				from resources.lib.modules.source_utils import copy2clip
				copy2clip(list[select - 1][1])
			return
		except: log_utils.error('Error sourceInfo: ' )

	def alterSources(self, url, meta):
		try:
			if getSetting('play.mode.tv') == '1' or (self.enable_playnext and 'episode' in meta) or getSetting('play.mode.movie') == '1': url += '&select=0'
			else: url += '&select=1'
			control.execute('PlayMedia(%s)' % url)
		except: log_utils.error()

	def errorForSources(self,title=None, year=None, imdb=None, tmdb=None, tvdb=None, season=None, episode=None, tvshowtitle=None, premiered=None):
		try:
			request = getattr(self, 'playback_request', {})
			title = title if title is not None else request.get('title')
			year = year if year is not None else request.get('year')
			imdb = imdb if imdb is not None else request.get('imdb')
			tmdb = tmdb if tmdb is not None else request.get('tmdb')
			tvdb = tvdb if tvdb is not None else request.get('tvdb')
			season = season if season is not None else request.get('season')
			episode = episode if episode is not None else request.get('episode')
			tvshowtitle = tvshowtitle if tvshowtitle is not None else request.get('tvshowtitle')
			premiered = premiered if premiered is not None else request.get('premiered')
			if not title or (tvshowtitle and (season is None or episode is None)):
				control.notification(message=32401)
				return control.cancelPlayback()
			homeWindow.clearProperty('infinity.window_keep_alive')
			control.sleep(200)
			control.hide()
			if getattr(self, 'url', None) == 'close://': control.notification(message=32400)
			elif self.retryallsources:
				if self.rescrapeAll == 'true':
					control.notification(message=32401)
				else:
					control.notification(message=40404)
					control.cancelPlayback()
					control.sleep(200)
					plugin = 'plugin://plugin.video.infinity/'
					if not episode: mediatype = 'movie'
					else: mediatype = 'episode'
					select = getSetting('play.mode.movie') if mediatype == 'movie' else getSetting('play.mode.tv')
					systitle, sysmeta = quote_plus(str(title or '')), quote_plus(jsdumps(self.meta))
					if tvshowtitle:
						url = '%s?action=rescrapeAuto&title=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&season=%s&episode=%s&tvshowtitle=%s&premiered=%s&meta=%s&select=%s' % (
								plugin, systitle, year, imdb, tmdb, tvdb, season, episode, quote_plus(str(tvshowtitle or '')), premiered, sysmeta, select)
					else:
						url = '%s?action=rescrapeAuto&title=%s&year=%s&imdb=%s&tmdb=%s&premiered=%s&meta=%s&select=%s' % (
								plugin, systitle, year, imdb, tmdb, premiered, sysmeta, select)
					return control.execute('PlayMedia(%s)' % url)
#					Sources(all_providers='true', rescrapeAll='true').play(title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered, self.meta, select=select, rescrape='true')
			else: control.notification(message=32401)
			control.cancelPlayback()
		except: log_utils.error()

	def getAliasTitles(self, imdb, content):
		try:
			if content == 'movie':
				from resources.lib.modules.trakt import getMovieAliases
				t = getMovieAliases(imdb)
			else:
				from resources.lib.modules.trakt import getTVShowAliases
				t = getTVShowAliases(imdb)
			if not t: return []
			t = [i for i in t if i.get('country', '').lower() in ('en', '', 'ca', 'us', 'uk', 'gb')]
			return t
		except:
			log_utils.error()
			return []

	def process_sources(self, sources, provider, title):
		for i in sources:
			try:
				info = i.get('info', '')
				if info == []: info = ''
				if 'name' not in i: i.update({'name': i['source']})
				if 'name_info' not in i: i.update({'name_info': ''})
				size= 0
				try: size = i['size']
				except: pass
				if i['quality'] not in ['4K', '1080p', '720p', 'SCR', 'SD', 'CAM']: i['quality'] = 'SD'
				try:
					if 'name_info' in i: info_string = getFileType(name_info=i.get('name_info'))
					else: info_string = getFileType(url=i.get('url'))
					info = '{} /{}'.format(info, info_string).lstrip(' ').lstrip('/').rstrip('/')
				except: pass
				i.update({'provider': provider, 'info': info, 'size': round(size, 2)})
			except: log_utils.log(f'process_sources Error: {print_exc()}')
		return sources

	def getTitle(self, title):
		title = string_tools.normalize(title)
		return title

	def subTitle(self, tvshowtitle):
		#need to make a table and check for substitutions.
		if tvshowtitle:
			try:
				from resources.lib.database import titlesubs
				subtvshowtitle = titlesubs.substitute_get(tvshowtitle)
				if subtvshowtitle:
					tvshowtitle = subtvshowtitle
			except:
				tvshowtitle = tvshowtitle
			return tvshowtitle
		else:
			return None

	def getSubsList(self):
		try:
			control.hide()
			from resources.lib.database import titlesubs
			addedSubs = titlesubs.all_substitutes(self)
			items = [{'originalTitle': i['originalTitle'],'subTitle':i['subTitle']} for i in addedSubs]
			from resources.lib.windows.title_sublist_manager import TitleSublistManagerXML
			window = TitleSublistManagerXML('title_sublist_manager.xml', control.addonPath(control.addonId()), results=items)
			selected_items = window.run()
			if selected_items:
				self.removeSubs(selected_items)
			del window
		except:
			log_utils.error()

	def addNewSub(self):
		original_title = control.dialog.input('[COLOR %s]%s[/COLOR]' % (self.highlight_color,  getLS(40245)), type=control.alpha_input)
		if original_title:
			sub_title = control.dialog.input('[COLOR %s]%s[/COLOR]' % (self.highlight_color, getLS(40247)), type=control.alpha_input)
			if sub_title:
				from resources.lib.database import titlesubs
				addedSubs = titlesubs.sub_insert(original_title, sub_title)
				if addedSubs: control.notification(message=40248)


	def removeSubs(self, items):
		try:
			if len(items) > 0:
				for v in items:
					removeitem = str(v.get('originalTitle'))
					from resources.lib.database import titlesubs
					titlesubs.clear_substitute('substitle', removeitem)
		except:
			log_utils.error()

	def getConstants(self):
		self.metaProperty = 'plugin.video.infinity.container.meta'
		self.seasonProperty = 'plugin.video.infinity.container.season'
		self.episodeProperty = 'plugin.video.infinity.container.episode'
		self.titleProperty = 'plugin.video.infinity.container.title'
		self.imdbProperty = 'plugin.video.infinity.container.imdb'
		self.tmdbProperty = 'plugin.video.infinity.container.tmdb'
		self.tvdbProperty = 'plugin.video.infinity.container.tvdb'
		self.labelProperty = 'plugin.video.infinity.container.label'
		self.sourceDict = []
		if getSetting('provider.external.enabled') == 'true':
			if getSetting('external_provider.module', '') == '':
				#no external_provider_module
				control.notification(message=control.lang(40447))
				self.sourceDict = internalSources()
				self.sourceDict.extend(cloudSources())
			else:
				try:
					# from sys import path
					# path.append(control.transPath('special://home/addons/%s/lib' % getSetting('external_provider.module', '')))
					# from importlib import import_module
					# fs_sources = getattr(import_module(getSetting('external_provider.name')), 'sources')
					if self.all_providers == 'true':
						self.sourceDict = fs_sources(ret_all=True)
						self.sourceDict.extend(internalSources())
					else:
						#import web_pdb; web_pdb.set_trace()
						#self.sourceDict = self.get_internal_scrapers()
						self.sourceDict = fs_sources()
						self.sourceDict.extend(cloudSources())
						self.sourceDict.extend(internalSources())
				except:
					control.notification(message=control.lang(40448))
					self.sourceDict = internalSources()
					self.sourceDict.extend(cloudSources())
		else:
			control.notification(message='No external provider check in setting.')
			self.sourceDict = internalSources()
			self.sourceDict.extend(cloudSources())
		from resources.lib.modules import premium_hosters
		self.debrid_resolvers = []

		self.prem_providers = [] # for sorting by debrid and direct source links priority
		self.free_provider = []
		if control.setting('easynews.user'): self.prem_providers += [('easynews', int(getSetting('easynews.priority')))]
		if control.setting('filepursuittoken'): self.prem_providers += [('filepursuit', int(getSetting('filepursuit.priority')))]
		#if control.setting('furk.user_name'): self.prem_providers += [('furk', int(getSetting('furk.priority')))]
		if control.setting('gdrivetoken'): self.prem_providers += [('gdrive', int(getSetting('gdrive.priority')))]
		if control.setting('plexsharetoken'): self.prem_providers += [('plexshare', int(getSetting('plexshare.priority')))]
		self.free_provider += [item[0] for item in self.sourceDict]
		self.prem_providers += [(d.name, int(d.sort_priority)) for d in self.debrid_resolvers]

		self.hostprDict = hosts_list
		self.sourcecfDict = premium_hosters.sourcecfDict

	def calc_pack_size(self):
		seasoncount, counts = None, None
		try:
			if self.meta: seasoncount, counts = self.meta.get('seasoncount', None), self.meta.get('counts', None)
		except: log_utils.error()
		if not seasoncount or not counts: # check metacache, 2nd fallback
			try:
				imdb_user = getSetting('imdbuser').replace('ur', '')
				tvdb_key = getSetting('tvdb.apikey')
				user = str(imdb_user) + str(tvdb_key)
				meta_lang = control.apiLanguage()['tvdb']
				if self.meta: imdb, tmdb, tvdb = self.meta.get('imdb', ''), self.meta.get('tmdb', ''), self.meta.get('tvdb', '')
				else: imdb, tmdb, tvdb = homeWindow.getProperty(self.imdbProperty), homeWindow.getProperty(self.tmdbProperty), homeWindow.getProperty(self.tvdbProperty)
				ids = [{'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb}]
				meta2 = metacache.fetch(ids, meta_lang, user)[0]
				if not seasoncount: seasoncount = meta2.get('seasoncount', None)
				if not counts: counts = meta2.get('counts', None)
			except: log_utils.error()
		if not seasoncount or not counts: # make request, 3rd fallback
			try:
				if self.meta: season = self.meta.get('season')
				else: season = homeWindow.getProperty(self.seasonProperty)
				from resources.lib.indexers import tmdb as tmdb_indexer
				counts = tmdb_indexer.TVshows().get_counts(tmdb)
				seasoncount = counts[str(season)]
			except:
				log_utils.error()
				return self.sources
		for i in self.sources:
			try:
#				if i['provider'] == 'torrentio' or i['provider'] == 'selfhosted' or i['provider'] == 'elfhosted': continue # torrentio return file size based on episode query already so bypass re-calc
				if i['provider'] in ('torrentio', 'comet', 'knightcrawler', 'mediafusion', 'selfhosted'): continue # torrentio return file size based on episode query already so bypass re-calc
				if 'package' in i:
					dsize = i.get('size')
					if not dsize: continue
					from resources.lib.modules.episode_mapping import MONSTER, bake_off_pack_count
					mapped_count = bake_off_pack_count(i)
					if mapped_count is not None: divider = mapped_count
					elif i.get('scrape_convention') == 'anthology' and i.get('scrape_tmdb') in MONSTER:
						if i['package'] == 'season': divider = MONSTER[i['scrape_tmdb']][1]
						else: divider = sum(v[1] for v in MONSTER.values() if v[0] <= int(i['last_season']))
						if not divider: continue
					elif i['package'] == 'season':
						divider = int(seasoncount)
						if not divider: continue
					else:
						if not counts: continue
						season_count = 1 ; divider = 0
						while season_count <= int(i['last_season']):
							divider += int(counts[str(season_count)])
							season_count += 1
					float_size = float(dsize) / divider
					if round(float_size, 2) == 0: continue
					str_size = '%.2f GB' % float_size
					info = i.get('info', [])
					try: info = [i['info'].split(' / ', 1)[1]]
					except: info = []
					info.insert(0, str_size)
					info = ' / '.join(info)
					i.update({'size': float_size, 'info': info})
				else:
					continue
			except: log_utils.error()
		return self.sources

	def ad_cache_chk_list(self, torrent_List, hashList):
		#if len(torrent_List) == 0: return
		try:
			# from resources.lib.debrid.alldebrid import AllDebrid
			# cached = AllDebrid().check_cache(hashList)
			# if not cached: return None
			# cached = cached['magnets']
			count = 0
			for i in torrent_List:
				# if 'error' in cached[count]: # list index out of range
				# 	count += 1
				# 	continue
				# if cached[count]['instant'] is False:
				# 	if 'package' in i: i.update({'source': 'uncached (pack) torrent'})
				# 	else: i.update({'source': 'uncached torrent'})
				# else:
				# 	if 'package' in i: i.update({'source': 'cached (pack) torrent'})
				# 	else: i.update({'source': 'cached torrent'})
				i.update({'source': 'unchecked'})
				count += 1
			return torrent_List
		except: log_utils.error()

	def pm_cache_chk_list(self, torrent_List, hashList):
		if len(torrent_List) == 0: return
		try:
			from resources.lib.debrid.premiumize import Premiumize
			cached = Premiumize().check_cache_list(hashList)
			if not cached: return None
			count = 0
			for i in torrent_List:
				if cached[count] is False:
					if 'package' in i: i.update({'source': 'uncached (pack) torrent'})
					else: i.update({'source': 'uncached torrent'})
				else:
					if 'package' in i: i.update({'source': 'cached (pack) torrent'})
					else: i.update({'source': 'cached torrent'})
				count += 1
			return torrent_List
		except: log_utils.error()

	def rd_cache_chk_list(self, torrent_List, hashList):
		if len(torrent_List) == 0: return
		try:
			for i in torrent_List:
				i.update({'source': 'unchecked'})
			return torrent_List
		except: log_utils.error()

	def clr_item_providers(self, title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered):
		try:
			providerscache.remove(self.getSources, title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered) # function cache removal of selected item ONLY
			dbcon = database.connect(sourceFile)
			dbcur = dbcon.cursor()
			dbcur.execute('''SELECT count(name) FROM sqlite_master WHERE type='table' AND name='rel_src';''') # table exists so both will
			if dbcur.fetchone()[0] == 1:
				dbcur.execute('''DELETE FROM rel_src WHERE imdb_id=?''', (imdb,)) # DEL the "rel_src" list of cached links
				from resources.lib.modules.episode_mapping import supported
				if supported(tmdb):
					dbcur.execute('DELETE FROM rel_src WHERE imdb_id IN (?, ?)', ('anthology-v1:%s:anthology' % tmdb, 'anthology-v1:%s:split' % tmdb))
				dbcur.connection.commit()
		except: log_utils.error("clr_item_providers: ")
		finally: dbcur.close() ; dbcon.close()

	def imdb_meta_chk(self, imdb, title, year):
		try:
			if not imdb or imdb == '0': return title, year
			from resources.lib.modules.client import _basic_request
			result = _basic_request('https://v2.sg.media-imdb.com/suggestion/t/{}.json'.format(imdb))
			if not result: return title, year
			result = jsloads(result)['d'][0]
			year_ck = str(result.get('y', ''))
			title_ck = self.getTitle(result['l'])
			if not year_ck or not title_ck: return title, year
			if self.mediatype == 'movie':
				if getSetting('imdb.Movietitle.check') == 'true' and (title != title_ck):
					log_utils.log('IMDb Movie title_ck: (%s) does not match meta Movie title passed: (%s)' % (title_ck, title), __name__, level=log_utils.LOGDEBUG)
					title = title_ck
				if getSetting('imdb.Movieyear.check') == 'true' and (year != year_ck):
					log_utils.log('IMDb Movie year_ck: (%s) does not match meta Movie year passed: (%s) for title: (%s)' % (year_ck, year, title), __name__, level=log_utils.LOGDEBUG)
					year = year_ck
			else:
				if getSetting('imdb.Showtitle.check') == 'true' and (title != title_ck):
					log_utils.log('IMDb Show title_ck: (%s) does not match meta tvshowtitle title passed: (%s)' % (title_ck, title), __name__, level=log_utils.LOGDEBUG)
					title = title_ck
				if getSetting('imdb.Showyear.check') == 'true' and (year != year_ck):
					log_utils.log('IMDb Show year_ck: (%s) does not match meta tvshowtitle year passed: (%s) for title: (%s)' % (year_ck, year, title), __name__, level=log_utils.LOGDEBUG)
					year = year_ck
			return title, year
		except:
			log_utils.error()
			return title, year

	def get_season_info(self, imdb, tmdb, tvdb, meta, season):
		total_seasons = None
		season_isAiring = None
		try:
			total_seasons = meta.get('total_seasons', None)
			season_isAiring = meta.get('season_isAiring', None)
		except: pass
		if not total_seasons or season_isAiring is None: # check metacache, 2nd fallback
			try:
				imdb_user = getSetting('imdbuser').replace('ur', '')
				tvdb_key = getSetting('tvdb.apikey')
				user = str(imdb_user) + str(tvdb_key)
				meta_lang = control.apiLanguage()['tvdb']
				ids = [{'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb}]
				meta2 = metacache.fetch(ids, meta_lang, user)[0]
				if not total_seasons: total_seasons = meta2.get('total_seasons', None)
				if season_isAiring is None: season_isAiring = meta2.get('season_isAiring', None)
			except: log_utils.error()
		if not total_seasons: # make request, 3rd fallback
			try:
				from resources.lib.modules.trakt import getSeasons
				total_seasons = getSeasons(imdb, full=False)
				if total_seasons:
					total_seasons = [i['number'] for i in total_seasons]
					season_special = True if 0 in total_seasons else False
					total_seasons = len(total_seasons)
					if season_special: total_seasons = total_seasons - 1
			except: log_utils.error()
		if season_isAiring is None:
			try:
				from resources.lib.indexers import tmdb as tmdb_indexer
				season_isAiring = tmdb_indexer.TVshows().get_season_isAiring(tmdb, season)
				if not season_isAiring: season_isAiring = 'false'
			except: log_utils.error()
		return total_seasons, season_isAiring

	def sort_byQuality(self, source_list):
		filter = []
		quality = getSetting('hosts.quality') or '0'
		if quality == '0': filter += [i for i in source_list if i['quality'] == '4K']
		if quality in ('0', '1'): filter += [i for i in source_list if i['quality'] == '1080p']
		if quality in ('0', '1', '2'): filter += [i for i in source_list if i['quality'] == '720p']
		filter += [i for i in source_list if i['quality'] == 'SCR']
		filter += [i for i in source_list if i['quality'] == 'SD']
		filter += [i for i in source_list if i['quality'] == 'CAM']
		return filter

	def getWindowProgress(self, title, meta):
		from resources.lib.windows.source_progress import WindowProgress
		window = WindowProgress('source_progress.xml', control.addonPath(control.addonId()), title=title, meta=meta)
		Thread(target=window.run).start()
		return window

	def window_monitor(self, window=None):
		if window is None: return
		self.window = window
		homeWindow.setProperty('infinity.window_keep_alive', 'true')
		while homeWindow.getProperty('infinity.window_keep_alive') == 'true': control.sleep(200)
		homeWindow.clearProperty('infinity.window_keep_alive')
		try: self.window.close()
		except: pass
		self.window = None

	def get_internal_scrapers(self):
		settings = ['provider.external', 'provider.plex', 'provider.gdrive']
		#rd_cloud.enabled
		#pm_cloud.enabled
		#ad_cloud.enabled
		#internal_scrapers_clouds_list = [('realdebrid', 'rd_cloud', 'rd'), ('premiumize', 'pm_cloud', 'pm'), ('alldebrid', 'ad_cloud', 'ad')]
		settings_append = settings.append
		for item in internal_scrapers_clouds_list:
			if self.enabled_debrid_check(item[0], item[2]): settings_append(item[1])
		active = [i.split('.')[1] for i in settings if getSetting('%s.enabled' % i) == 'true']
		return active

	def enabled_debrid_check(self, debrid_service, short_name):
		#premiumize.enable
		#realdebrid.enable
		#alldebrid.enable
		if not getSetting('%s.enable' % debrid_service) == 'true': return False
		return self.has_debrid_token(short_name)

	def has_debrid_token(self, debrid_service):
		if debrid_service == 'rd':
			if getSetting('realdebridtoken') in (None, ''): return False
		else:
			if getSetting('%s.token' % debrid_service) in (None, ''): return False
		return True
