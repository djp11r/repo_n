# -*- coding: utf-8 -*-
"""
	Umbrella Add-on
"""

from datetime import datetime
from json import dumps as jsdumps, loads as jsloads
import re
import requests
from traceback import print_exc
from requests.adapters import HTTPAdapter
from threading import Thread, Lock
from urllib3.util.retry import Retry
from urllib.parse import urljoin, urlparse, parse_qsl, urlencode, urlunparse
from resources.lib.database import cache, traktsync
from resources.lib.modules import cleandate
from resources.lib.modules import control
from resources.lib.modules import log_utils
import time
import xbmcaddon as _xbmcaddon

getLS = control.lang
getSetting = control.setting
setSetting = control.setSetting
BASE_URL = 'https://api.trakt.tv'
headers = {'Content-Type': 'application/json', 'trakt-api-key': '', 'trakt-api-version': '2'}
REDIRECT_URI = 'urn:ietf:wg:oauth:2.0:oob'
session = requests.Session()
retries = Retry(total=4, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504, 520, 521, 522, 524, 530])
session.mount('https://api.trakt.tv', HTTPAdapter(max_retries=retries, pool_maxsize=100))
highlight_color = getSetting('highlight.color')
server_notification = getSetting('trakt.server.notifications') == 'true'
service_syncInterval = int(getSetting('background.service.syncInterval')) if getSetting('background.service.syncInterval') else 15
trakt_icon = control.joinPath(control.artPath(), 'trakt.png')
#trakt_qr = control.joinPath(control.artPath(), 'traktqr.png')
trakt_token = getSetting('trakt.user.token')
_reauth_lock = Lock()
_reauth_failed = False
_REAUTH_BUSY_PROP = 'infinity.trakt.reauth.busy'
_TRAKT_TOKEN_PROP = 'infinity.trakt.access_token'
_last_request_time = 0.0
control.homeWindow.setProperty(_TRAKT_TOKEN_PROP, getSetting('trakt.user.token') or '')

def trakt_user_active():
	try: expires_at = float(control.setting('trakt.token.expires'))
	except: expires_at = 0.0
	return time.time() > expires_at

def getTrakt(url, post=None, extended=False, silent=False, retry=0):
	try:
		global _last_request_time
		if time.time() - _last_request_time > 300:	# flush stale pooled connections after 5 min idle
			session.close()
		if not url.startswith(BASE_URL): url = urljoin(BASE_URL, url)
		if headers['trakt-api-key'] == '': headers['trakt-api-key']=traktClientID()
		# if post: post = jsdumps(post)
		if not trakt_user_active():
			current_token = getSetting('trakt.user.token')
			if current_token: headers['Authorization'] = 'Bearer %s' % current_token
		_req_start = time.time()
		for _attempt in range(2):
			try:
				if post: response = session.post(url, data=jsdumps(post), headers=headers, timeout=11)
				else: response = session.get(url, headers=headers, timeout=11)
				_last_request_time = time.time()
				_req_elapsed = _last_request_time - _req_start
				if _req_elapsed > 3.0:
					log_utils.log('TRAKT: slow request (%.1fs): %s' % (_req_elapsed, url), level=log_utils.LOGWARNING)
				elif _req_elapsed > 1.0:
					log_utils.log('TRAKT: request took %.1fs: %s' % (_req_elapsed, url), level=log_utils.LOGDEBUG)
				break
			except requests.exceptions.ConnectionError:
				if _attempt == 0 and not post:	# Only retry GETs; retrying POSTs risks double-submission to /sync/history
					log_utils.log('getTrakt: connection reset, retrying with fresh connection...', level=log_utils.LOGDEBUG)
					session.close()
				else:
					raise
		status_code = str(response.status_code)

		# if status_code.startswith('5') or '<html' in response: # temp to log html maintenance response
		#	log_utils.log('status_code=%s' % status_code, __name__)
		#	log_utils.log('response.headers=%s' % str(response.headers), __name__)
		#	log_utils.log('response=%s' % response, __name__)
		#	log_utils.log('response.text=%s' % str(response.text), __name__)
		#	log_utils.log('response.content=%s' % str(response.content), __name__)

		error_handler(url, response, status_code, retry, silent=silent)
		if response and status_code in ('200', '201'):
			if extended: return response, response.headers
			else: return response
		elif status_code == '409': # Item already scrobbled/exists - not a real failure
			log_utils.log('TRAKT: 409 Conflict (item already scrobbled/exists): %s' % url, level=log_utils.LOGINFO)
			if extended: return response, response.headers
			else: return response
		elif status_code == '401': # Re-Auth token
			log_utils.log(f'status_code: {status_code} (attempt {retry:d}) URL: {url}\nheaders: {headers}\npost: {post}\nresponse: {response.text}', level=1)
			if response.headers.get('x-private-user') == 'true':
				log_utils.log(f'URL:{url} Has a Private User Header:Ignoring', level=log_utils.LOGDEBUG)
				return None
			# Prevent infinite re-auth loops
			if retry >= 2:
				traktRevoke()
				control.notification(title=32315, message=33677)
				log_utils.log('TRAKT: Too many re-auth attempts, stopping to prevent infinite loop', level=log_utils.LOGWARNING)
				return None
			success = refresh_token(f'infinity retry: {retry}')
			if success: return getTrakt(url, extended=extended, silent=silent, retry=retry + 1)
		elif status_code == '429':
			log_utils.log(f'status_code: {status_code} URL: {url}\nheaders: {headers}\npost: {post}', level=1)
			if 'Retry-After' in response.headers: # API REQUESTS ARE BEING THROTTLED, INTRODUCE WAIT TIME (1000 get requests every 5 minutes, 1 post/put/delte every per second)
				throttleTime = response.headers['Retry-After']
				if not silent and server_notification and not control.condVisibility('Player.HasVideo'):
					control.notification(title=32315, message='Trakt Throttling Applied, Sleeping for %s seconds' % throttleTime) # message lang code 33674
				control.sleep((int(throttleTime) + 1) * 1000)
				return getTrakt(url, extended=extended, silent=silent, retry=retry + 1)
		else: return None
	except:
		try: log_utils.error('getTrakt Error: ')
		except: pass
	return None

def error_handler(url, response, status_code, retry, silent=False):
	result = response.json() if 'json' in response.headers.get('Content-Type', '') else response.text
	try:
		error = result.get('error_description')
		if status_code == '400' and 'grant is invalid' in error and retry >= 3:
			traktRevoke()
			log_utils.log('getTrakt() (code:%s) (url:%s): \nresult: %s' % (status_code, url, result), level=1)
			return
	except: error = result
	# if (not silent) and server_notification: control.notification(title=32315, message=error, time=1500)
	if status_code.startswith('5') or (response and isinstance(response, str) and '<html' in response) or not str(response): log_utils.log('Temporary Trakt Server Problem: %s:%s' % (status_code, result), level=1) # covers Maintenance html responses ["Bad Gateway", "We're sorry, but something went wrong (500)"])
	elif status_code == '423': log_utils.log('Locked User Account - Contact Trakt Support: code:%s:result:%s' % (status_code, result), level=1)
	elif status_code == '404': log_utils.log('getTrakt() (code:%s:NOT FOUND): URL=(%s): %s' % (status_code, url, result), level=1)
	elif status_code == '400': log_utils.log('getTrakt() (code:%s:Bad Request for url): URL=(%s): %s' % (status_code, url, result), level=1)

def getTraktAsJson(url, post=None, silent=False):
	try:
		res_headers = {}
		r = getTrakt(url=url, post=post, extended=True, silent=silent)
		if not r: return None
		if isinstance(r, tuple) and len(r) == 2: r, res_headers = r[0], r[1]
		if not r: return None
		r = r.json()
		if 'X-Sort-By' in res_headers and 'X-Sort-How' in res_headers:
			r = sort_list(res_headers.get('X-Sort-By', 'title'), res_headers.get('X-Sort-How', 'asc'), r)
		return r
	except Exception as e:
		log_utils.log('TRAKT: Error in getTraktAsJson: %s' % str(e), level=log_utils.LOGWARNING)
		return None

def get_all_pages(url, silent=False):
	"""Fetch all pages from a paginated Trakt endpoint and return combined results."""
	try:
		# Strip page= and limit= params while preserving all other query params (e.g. extended=full)
		try:
			parsed = urlparse(url)
			params = [(k, v) for k, v in parse_qsl(parsed.query) if k not in ('page', 'limit')]
			url = urlunparse(parsed._replace(query=urlencode(params)))
		except:
			pass

		sep = '&' if '?' in url else '?'
		limit = 250
		page = 1
		results = []
		_sync_start = time.time()

		while True:
			page_url = url + sep + 'page=%d&limit=%d' % (page, limit)
			response = getTrakt(page_url, silent=silent)
			if not response:
				if page == 1:
					log_utils.log('TRAKT: get_all_pages - No response on first page for URL: %s' % url, level=log_utils.LOGWARNING)
					return None
				break

			try:
				page_results = response.json()
			except Exception as e:
				log_utils.log('TRAKT: get_all_pages - JSON decode error on page %d: %s' % (page, str(e)), level=log_utils.LOGWARNING)
				if page == 1: return None
				break

			if not page_results:
				if page == 1: return page_results if page_results is not None else []
				break

			try:
				items_count = len(page_results)
				results.extend(page_results)
				items_this_page = items_count
			except (TypeError, AttributeError) as e:
				log_utils.log('TRAKT: get_all_pages - Cannot process as list on page %d: %s' % (page, str(e)), level=log_utils.LOGWARNING)
				if page == 1: return page_results
				break
			except Exception as e:
				log_utils.log('TRAKT: get_all_pages - Error processing page %d: %s' % (page, str(e)), level=log_utils.LOGWARNING)
				if page == 1: return None
				break
			log_utils.log('TRAKT: get_all_pages page %d: %d items from %s' % (page, items_count, url), level=log_utils.LOGDEBUG)

			# Check pagination headers first — they are authoritative even when Trakt caps
			# the page size below the requested limit (e.g. returns 100 of 250 requested).
			_continue_by_headers = False
			if hasattr(response, 'headers'):
				_hdr_page_count = response.headers.get('X-Pagination-Page-Count')
				_hdr_item_count = response.headers.get('X-Pagination-Item-Count')
				if _hdr_page_count:
					try:
						if page >= int(_hdr_page_count):
							break
						else:
							_continue_by_headers = True  # headers confirm more pages exist
					except (ValueError, TypeError):
						pass
				if _hdr_item_count:
					try:
						if len(results) >= int(_hdr_item_count):
							break
						else:
							_continue_by_headers = True  # headers confirm more items exist
					except (ValueError, TypeError):
						pass

			# Fall back to item-count heuristic ONLY when headers were absent or inconclusive.
			# Without this guard, a Trakt server-side page cap (e.g. 100 items returned despite
			# limit=250) would incorrectly stop pagination even when X-Page-Count says more pages exist.
			if not _continue_by_headers:
				if items_this_page < limit:
					break
				if items_this_page > limit:
					break

			page += 1

			# Safety limit: 400 pages × 250 = 100,000 items max
			if page > 400:
				log_utils.log('TRAKT: get_all_pages reached safety limit of 400 pages for URL: %s' % url, level=log_utils.LOGWARNING)
				break

		if page > 1:
			log_utils.log('TRAKT: get_all_pages - Fetched %d items across %d pages in %.1fs from %s' % (len(results), page, time.time() - _sync_start, url), level=log_utils.LOGINFO)
		
		return results
	except Exception as e:
		log_utils.log('TRAKT: Error in get_all_pages: %s' % str(e), level=log_utils.LOGWARNING)
		return None

def refresh_token(retry=''):
	global _reauth_failed
	if _reauth_failed:
		return False
	# The expired token that triggered the 401 — used to detect if another thread already refreshed
	expired_token = trakt_user_active()
	with _reauth_lock:
		if _reauth_failed:
			return False
		# Cross-process wait: if another process is currently refreshing, wait up to 5 s
		for _ in range(10):
			if control.homeWindow.getProperty(_REAUTH_BUSY_PROP) != 'true':
				break
			control.sleep(500)
		# Double-check: read the token from the shared homeWindow property.
		# homeWindow properties are immediately visible across ALL Kodi processes (no caching).
		# If the token changed since we got our 401, another process already refreshed.
		current_token = control.homeWindow.getProperty(_TRAKT_TOKEN_PROP)
		if current_token and expired_token and current_token != expired_token:
			return True  # Another thread/process already refreshed — caller will retry with new token
		# Claim cross-process busy flag before making the HTTP call
		control.homeWindow.setProperty(_REAUTH_BUSY_PROP, 'true')
		try:
		# if retry > 0:
			# from openscrapers.modules.trakt import refresh_token
			# log_utils.log(f'Syncing refresh_token Trakt Token: {repr(retry)}')
			# success = refresh_token()
			# control.sleep(1000)
			control.sync_accounts(retry)
			control.homeWindow.setProperty(_TRAKT_TOKEN_PROP, getSetting('trakt.user.token'))
		except:
			log_utils.log(f'trakt_refresh_token error: \n {repr(print_exc())}')
			return False
		finally:
			control.homeWindow.setProperty(_REAUTH_BUSY_PROP, '')
		return None


# try:
		# CLIENT_ID = traktClientID()
		# CLIENT_SECRET = traktClientSecret()
		# data = {'client_id': CLIENT_ID, 'client_secret': CLIENT_SECRET, 'redirect_uri': 'urn:ietf:wg:oauth:2.0:oob', 'grant_type': 'refresh_token', 'refresh_token': getSetting('trakt.refreshtoken')}
		# response = session.post(url=f'{BASE_URL}/oauth/token', data=jsdumps(data), timeout=20, headers={'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': CLIENT_ID})
		# error_handler(response.url, response, str(response.status_code))
		# response = getTraktAsJson('/oauth/token', data)
		# if response:
			# control.homeWindow.setProperty('infinity.updateSettings', 'false')
			# token, refresh, expires = response['access_token'], response['refresh_token'], str(time.time() + response['expires_in'])
			# setSetting('trakt.isauthed', 'true')
			# setSetting('trakt.user.token', token)
			# setSetting('trakt.refreshtoken', refresh)
			# setSetting('trakt.token.expires', expires)
			# control.homeWindow.setProperty('infinity.updateSettings', 'true')
			# log_utils.log(f'trakt_refresh_token: expires on {repr(datetime.fromtimestamp(float(expires)))}', level=log_utils.LOGINFO)
			# return token
	# except: log_utils.log(f'refresh_token error: \n {repr(print_exc())}', level=log_utils.LOGINFO)
	# return


def traktAuth(fromSettings=0):
	try:
		from openscrapers.modules.trakt import authTrakt
		log_utils.log('authTrakt Trakt:')
		success = authTrakt()
		control.sleep(1000)
		control.sync_accounts(silent=True)
		control.notification(message=40107, icon=trakt_icon)
		return True
	except: log_utils.log(f'trakt_authenticate error: \n {repr(print_exc())}')
	control.notification(message=40108, icon=trakt_icon)
	return False
	# try:
		# traktDeviceCode = getTraktDeviceCode()
		# deviceCode = getTraktDeviceToken(traktDeviceCode)
		# if deviceCode:
			# deviceCode = deviceCode.json()
			# Use Trakt's provided expiration time instead of hardcoded 24 hours
			# expires_from_trakt = deviceCode.get('expires_in', 86400)  # fallback to 24 hours if not provided
			# expires_at = time.time() + expires_from_trakt
			# control.homeWindow.setProperty('infinity.updateSettings', 'false')
			# control.setSetting('trakt.token.expires', str(expires_at))
			# control.setSetting('trakt.user.token', deviceCode["access_token"])
			# control.homeWindow.setProperty(_TRAKT_TOKEN_PROP, deviceCode["access_token"])
			# control.setSetting('trakt.scrobble', 'true')
			# control.setSetting('resume.source', '1')
			# control.setSetting('trakt.isauthed', 'true')
			# control.setSetting('trakt.authed.clientid', traktClientID())
			# control.homeWindow.setProperty('infinity.updateSettings', 'true')
			# control.setSetting('trakt.refreshtoken', deviceCode["refresh_token"])
			# control.sleep(1000)
			# try:
				# headers['Authorization'] = 'Bearer %s' % deviceCode["access_token"]
				# user = getTrakt('users/me', post=None)
				# username = user.json()
				# control.setSetting('trakt.user.name', str(username['username']))
			# except: pass
			# control.notification(message=40107, icon=trakt_icon)
			# if fromSettings == 1:
				# control.openSettings('5.3', 'plugin.video.infinity')
			# if not control.yesnoDialog('Do you want to set Trakt as your service for your watched and unwatched indicators?','','','Indicators', 'No', 'Yes'): return True
			# global _reauth_failed
			# _reauth_failed = False
			# control.homeWindow.setProperty(_REAUTH_BUSY_PROP, '')
			# control.homeWindow.setProperty('infinity.updateSettings', 'false')
			# control.setSetting('indicators.alt', '1')
			# control.setSetting('scrobble.source', '1')
			# control.homeWindow.setProperty('infinity.updateSettings', 'true')
			# control.setSetting('scrobble', 'Trakt')
			# control.setSetting('indicators', 'Trakt')
			# control.notification(message='Trakt Indicators Enabled - Syncing Watched Data...', icon=trakt_icon)
			# Thread(target=sync_watched, kwargs={'forced': True}).start()
			# return True
		# if fromSettings == 1:
				# control.openSettings('5.3', 'plugin.video.infinity')
		# control.notification(message=40108, icon=trakt_icon)
		# return False
	# except:
		# log_utils.error()

def traktRevoke(fromSettings=0):
	# from openscrapers.modules.trakt import revoke
	# revoke()
	# data = {"token": control.setting('trakt.user.token')}
	# try:
		# getTrakt('oauth/revoke', post=data)
	# except: pass
	control.homeWindow.setProperty('infinity.updateSettings', 'false')
	# control.setSetting('trakt.user.name', '')
	control.setSetting('trakt.token.expires', '')
	control.setSetting('trakt.user.token', '')
	# control.setSetting('trakt.scrobble', 'false')
	# control.setSetting('resume.source', '0')
	control.setSetting('trakt.isauthed','')
	control.setSetting('trakt.refreshtoken', '')
	control.homeWindow.setProperty('infinity.updateSettings', 'true')
	# control.notification(message=40109, icon=trakt_icon)
	try:
		# from resources.lib.database import traktsync
		# clr_traktSync = {'bookmarks': True, 'hiddenProgress': True, 'liked_lists': True, 'movies_collection': True, 'movies_watchlist': True, 'popular_lists': True,
		# 		'public_lists': True, 'shows_collection': True, 'shows_watchlist': True, 'trending_lists': True, 'user_lists': True, 'watched': True}
		# cleared = traktsync.delete_tables(clr_traktSync)
		# if cleared:
			# log_utils.log('Trakt tables cleared after revoke.', level=log_utils.LOGINFO)
		# if getSetting('indicators.alt') == '1':
			# control.setSetting('indicators.alt', '0')
			# control.setSetting('indicators', 'Local')
		if getSetting('scrobble.source') == '1':
			control.setSetting('scrobble.source', '0')
		control.setSetting('trakt.markwatched', 'false')
		global _reauth_failed
		_reauth_failed = False
		control.homeWindow.setProperty(_REAUTH_BUSY_PROP, '')
		control.homeWindow.setProperty(_TRAKT_TOKEN_PROP, '')

		if fromSettings == 1:
			control.openSettings('5.3', 'plugin.video.infinity')
			control.dialog.ok(control.lang(32315), control.lang(40109))
	except:
		log_utils.error()


def getTraktDeviceCode():
	try:
		data = {'client_id': traktClientID()}
		response = getTrakt('oauth/device/code', post=data)
		if response.status_code == 200:
			return response.json()
		log_utils.log('TRAKT: getTraktDeviceCode failed: %s' % response.status_code, level=log_utils.LOGWARNING)
		return None
	except:
		log_utils.error()
		return None

def getTraktDeviceToken(traktDeviceCode):
	try:
		data = {"code": traktDeviceCode["device_code"],
				"client_id": traktClientID(),
				"client_secret": traktClientSecret()}
		start = time.time()
		expires_in = traktDeviceCode['expires_in']
		verification_url = control.lang(32513) % (highlight_color, str(traktDeviceCode['verification_url']))
		user_code = control.lang(32514) % (highlight_color, str(traktDeviceCode['user_code']))
		if control.setting('dialogs.useinfinitydialog') == 'true':
			from resources.lib.modules.tools import make_qr
			trakt_qr = make_qr(f"https://trakt.tv/activate?code={str(traktDeviceCode['user_code'])}")
			progressDialog = control.getProgressWindow(getLS(32073), trakt_qr, 1)
			progressDialog.set_controls()
			progressDialog.update(0, '%s[CR]%s[CR]OR....Scan the [B]QR Code[/B]' % (verification_url, user_code))
		else:
			progressDialog = control.progressDialog
			progressDialog.create(control.lang(32073), control.progress_line % (verification_url, user_code))
		try:
			time_passed = 0
			while not progressDialog.iscanceled() and time_passed < expires_in:
				try:
					#response = getTrakt('oauth/device/token', post=data, silent=True)
					url = urljoin(BASE_URL, 'oauth/device/token')
					response = requests.post(url, json=data,headers=headers, timeout=20)
					if response.status_code == 400:
						time_passed = time.time() - start
						progress = int(100)-int(100 * time_passed / expires_in)
						progressDialog.update(progress, control.progress_line % (verification_url, user_code))
						control.sleep(max(traktDeviceCode['interval'], 1)*1000)
				except requests.HTTPError as e:
					log_utils.log('Request Error: %s' % str(e), __name__, log_utils.LOGDEBUG)
					if e.response.status_code != 400: raise e
					progress = int(100)-int(100 * time_passed / expires_in)
					progressDialog.update(progress)
					control.sleep(max(traktDeviceCode['interval'], 1)*1000)
				else:
					if not response: continue
					else: return response
		finally:
			progressDialog.close()
		return None
	except:
		log_utils.error()

def getTraktAccountInfo():
	from datetime import datetime, timedelta
	try:
		account_info, stats = getTraktAccountSettings()
		username = account_info['user']['username']
		timezone = account_info['account']['timezone']
		joined = control.jsondate_to_datetime(account_info['user']['joined_at'], "%Y-%m-%dT%H:%M:%S.%fZ")
		private = account_info['user']['private']
		vip = account_info['user']['vip']
		if vip: vip = '%s Years' % str(account_info['user']['vip_years'])
		total_given_ratings = stats['ratings']['total']
		movies_collected = stats['movies']['collected']
		movies_watched = stats['movies']['watched']
		movie_minutes = stats['movies']['minutes']
		if movie_minutes == 0: movies_watched_minutes = ['0 days', '0:00:00']
		elif movie_minutes < 1440: movies_watched_minutes = ['0 days', "{:0>8}".format(str(timedelta(minutes=movie_minutes)))]
		else: movies_watched_minutes = ("{:0>8}".format(str(timedelta(minutes=movie_minutes)))).split(', ')
		movies_watched_minutes = control.lang(40111) % (movies_watched_minutes[0], movies_watched_minutes[1].split(':')[0], movies_watched_minutes[1].split(':')[1])
		shows_collected = stats['shows']['collected']
		shows_watched = stats['shows']['watched']
		episodes_watched = stats['episodes']['watched']
		episode_minutes = stats['episodes']['minutes']
		if episode_minutes == 0: episodes_watched_minutes = ['0 days', '0:00:00']
		elif episode_minutes < 1440: episodes_watched_minutes = ['0 days', "{:0>8}".format(str(timedelta(minutes=episode_minutes)))]
		else: episodes_watched_minutes = ("{:0>8}".format(str(timedelta(minutes=episode_minutes)))).split(', ')
		episodes_watched_minutes = control.lang(40111) % (episodes_watched_minutes[0], episodes_watched_minutes[1].split(':')[0], episodes_watched_minutes[1].split(':')[1])
		heading = control.lang(32315)
		items = []
		items += [control.lang(40036) % username]
		items += [control.lang(40112) % timezone]
		items += [control.lang(40113) % joined]
		items += [control.lang(40114) % private]
		items += [control.lang(40115) % vip]
		items += [control.lang(40116) % str(total_given_ratings)]
		items += [control.lang(40117) % (movies_collected, movies_watched, movies_watched_minutes)]
		items += [control.lang(40118) % (shows_collected, shows_watched)]
		items += [control.lang(40119) % (episodes_watched, episodes_watched_minutes)]
		return control.selectDialog(items, heading)
	except:
		log_utils.error()
		return

def getTraktAccountSettings():
	#account_info = self.call("users/settings", with_auth=True)
	#stats = self.call("users/%s/stats" % account_info['user']['ids']['slug'], with_auth=True)
	headers['Authorization'] = 'Bearer %s' % trakt_token
	account_info = getTrakt('users/settings', post=None)
	account_info_encoded = account_info.json()
	stats = getTrakt('users/%s/stats' % account_info_encoded['user']['ids']['slug'])
	stats_encoded = stats.json()
	return account_info_encoded, stats_encoded

def getTraktCredentialsInfo():
	username, token, refresh = getSetting('trakt.user.name').strip(), getSetting('trakt.user.token'), getSetting('trakt.refreshtoken')
	if (username == '' or token == '' or refresh == ''): return False
	return True

def getTraktIndicatorsInfo():
	indicators = getSetting('indicators.alt')
	indicators = True if indicators == '1' else False
	return indicators

def getTraktAddonMovieInfo():
	try: scrobble = control.addon('script.trakt').getSetting('scrobble_movie')
	except: scrobble = ''
	try: ExcludeHTTP = control.addon('script.trakt').getSetting('ExcludeHTTP')
	except: ExcludeHTTP = ''
	try: authorization = control.addon('script.trakt').getSetting('authorization')
	except: authorization = ''
	if scrobble == 'true' and ExcludeHTTP == 'false' and authorization != '':
		return True
	else: return False

def getTraktAddonEpisodeInfo():
	try: scrobble = control.addon('script.trakt').getSetting('scrobble_episode')
	except: scrobble = ''
	try: ExcludeHTTP = control.addon('script.trakt').getSetting('ExcludeHTTP')
	except: ExcludeHTTP = ''
	try: authorization = control.addon('script.trakt').getSetting('authorization')
	except: authorization = ''
	if scrobble == 'true' and ExcludeHTTP == 'false' and authorization != '':
		return True
	else: return False

def watch(content_type, name, imdb=None, tvdb=None, season=None, episode=None, refresh=True):
	control.busy()
	success = False
	if content_type == 'movie':
		success = markMovieAsWatched(imdb)
		if success: update_syncMovies(imdb)
	elif content_type == 'tvshow':
		success = markTVShowAsWatched(imdb, tvdb)
		if success: cachesyncTV(imdb, tvdb)
	elif content_type == 'season':
		success = markSeasonAsWatched(imdb, tvdb, season)
		if success: cachesyncTV(imdb, tvdb)
	elif content_type == 'episode':
		success = markEpisodeAsWatched(imdb, tvdb, season, episode)
		if success: cachesyncTV(imdb, tvdb)
	else: success = False
	control.hide()
	if refresh: control.refresh()
	control.trigger_widget_refresh()
	if season and not episode: name = '%s-Season%s...' % (name, season)
	if season and episode: name = '%s-S%sxE%02d...' % (name, season, int(episode))
	if getSetting('trakt.general.notifications') == 'true':
		if success is True: control.notification(title=32315, message=getLS(35502) % ('[COLOR %s]%s[/COLOR]' % (highlight_color, name)))
		else: control.notification(title=32315, message=getLS(35504) % ('[COLOR %s]%s[/COLOR]' % (highlight_color, name)))
	if not success: log_utils.log(getLS(35504) % name + ' : ids={imdb: %s, tvdb: %s}' % (imdb, tvdb), __name__, level=log_utils.LOGDEBUG)

def unwatch(content_type, name, imdb=None, tvdb=None, season=None, episode=None, refresh=True):
	control.busy()
	success = False
	if content_type == 'movie':
		success = markMovieAsNotWatched(imdb)
		update_syncMovies(imdb, remove_id=True)
	elif content_type == 'tvshow':
		success = markTVShowAsNotWatched(imdb, tvdb)
		cachesyncTV(imdb, tvdb)
	elif content_type == 'season':
		success = markSeasonAsNotWatched(imdb, tvdb, season)
		cachesyncTV(imdb, tvdb)
	elif content_type == 'episode':
		success = markEpisodeAsNotWatched(imdb, tvdb, season, episode)
		cachesyncTV(imdb, tvdb)
	else: success = False
	control.hide()
	if refresh: control.refresh()
	control.trigger_widget_refresh()
	if season and not episode: name = '%s-Season%s...' % (name, season)
	if season and episode: name = '%s-S%sxE%02d...' % (name, season, int(episode))
	if getSetting('trakt.general.notifications') == 'true':
		if success is True: control.notification(title=32315, message=getLS(35503) % ('[COLOR %s]%s[/COLOR]' % (highlight_color, name)))
		else: control.notification(title=32315, message=getLS(35505) % ('[COLOR %s]%s[/COLOR]' % (highlight_color, name)))
	if not success: log_utils.log(getLS(35505) % name + ' : ids={imdb: %s, tvdb: %s}' % (imdb, tvdb), __name__, level=log_utils.LOGDEBUG)

def like_list(list_owner, list_name, list_id):
	try:
		headers['Authorization'] = 'Bearer %s' % trakt_token
		# resp_code = client._basic_request('https://api.trakt.tv/users/%s/lists/%s/like' % (list_owner, list_id), headers=headers, method='POST', ret_code=True)
		resp_code = session.post('https://api.trakt.tv/users/%s/lists/%s/like' % (list_owner, list_id), headers=headers).status_code
		if resp_code == 204:
			control.notification(title=32315, message='Successfuly Liked list:  [COLOR %s]%s[/COLOR]' % (highlight_color, list_name))
			sync_liked_lists()
		else: control.notification(title=32315, message='Failed to Like list %s' % list_name)
		control.refresh()
	except: log_utils.error()

def unlike_list(list_owner, list_name, list_id):
	try:
		headers['Authorization'] = 'Bearer %s' % trakt_token
		# resp_code = client._basic_request('https://api.trakt.tv/users/%s/lists/%s/like' % (list_owner, list_id), headers=headers, method='DELETE', ret_code=True)
		resp_code = session.delete('https://api.trakt.tv/users/%s/lists/%s/like' % (list_owner, list_id), headers=headers).status_code
		if resp_code == 204:
			control.notification(title=32315, message='Successfuly Unliked list:  [COLOR %s]%s[/COLOR]' % (highlight_color, list_name))
			traktsync.delete_liked_list(list_id)
		else: control.notification(title=32315, message='Failed to UnLike list %s' % list_name)
		control.refresh()
	except: log_utils.error()

def remove_liked_lists(trakt_ids):
	if not trakt_ids: return
	success = None
	try:
		headers['Authorization'] = 'Bearer %s' % trakt_token
		for id in trakt_ids:
			list_owner = id.get('list_owner')
			list_id = id.get('trakt_id')
			list_name = id.get('list_name')
			# resp_code = client._basic_request('https://api.trakt.tv/users/%s/lists/%s/like' % (list_owner, list_id), headers=headers, method='DELETE', ret_code=True)
			resp_code = session.delete('https://api.trakt.tv/users/%s/lists/%s/like' % (list_owner, list_id), headers=headers).status_code
			if resp_code == 204:
				control.notification(title=32315, message='Successfuly Unliked list:  [COLOR %s]%s[/COLOR]' % (highlight_color, list_name))
				traktsync.delete_liked_list(list_id)
			else: control.notification(title=32315, message='Failed to UnLike list %s' % list_name)
			control.sleep(1000)
		control.refresh()
	except: log_utils.error()

def rate(imdb=None, tvdb=None, season=None, episode=None):
	return _rating(action='rate', imdb=imdb, tvdb=tvdb, season=season, episode=episode)

def unrate(imdb=None, tvdb=None, season=None, episode=None):
	return _rating(action='unrate', imdb=imdb, tvdb=tvdb, season=season, episode=episode)

def rateShow(imdb=None, tvdb=None, season=None, episode=None):
	if getSetting('trakt.rating') == 1:
		rate(imdb=imdb, tvdb=tvdb, season=season, episode=episode)

def _rating(action, imdb=None, tvdb=None, season=None, episode=None):
	control.busy()
	try:
		addon = 'script.trakt'
		if control.condVisibility('System.HasAddon(%s)' % addon):
			import importlib.util
			data = {}
			data['action'] = action
			if tvdb:
				data['video_id'] = tvdb
				if episode:
					data['media_type'] = 'episode'
					data['dbid'] = 1
					data['season'] = int(season)
					data['episode'] = int(episode)
				elif season:
					data['media_type'] = 'season'
					data['dbid'] = 5
					data['season'] = int(season)
				else:
					data['media_type'] = 'show'
					data['dbid'] = 2
			else:
				data['video_id'] = imdb
				data['media_type'] = 'movie'
				data['dbid'] = 4

			script_path = control.joinPath(control.addonPath(addon), 'resources', 'lib', 'sqlitequeue.py')
			spec = importlib.util.spec_from_file_location("sqlitequeue.py", script_path)
			sqlitequeue = importlib.util.module_from_spec(spec)
			spec.loader.exec_module(sqlitequeue)
			data = {'action': 'manualRating', 'ratingData': data}
			sqlitequeue.SqliteQueue().append(data)
		else:
			control.notification(title=32315, message=33659)
		control.hide()
	except: log_utils.error()

def unHideItems(tvdb_ids):
	if not tvdb_ids: return
	success = None
	try:
		ids = []
		for id in tvdb_ids: ids.append({"ids": {"tvdb": int(id)}})
		post = {"shows": ids}
		success = getTrakt('users/hidden/dropped/remove', post=post)
		if success:
			if 'plugin.video.infinity' in control.infoLabel('Container.PluginName'): control.refresh()
			traktsync.delete_hidden_progress(tvdb_ids)
			control.trigger_widget_refresh()
			return True
	except:
		log_utils.error(f'unHideItems tvdb_ids error: {tvdb_ids}')
		return False

def hideItems(tvdb_ids):
	if not tvdb_ids: return
	success = None
	try:
		ids = []
		for id in tvdb_ids: ids.append({"ids": {"tvdb": int(id)}})
		post = {"shows": ids}
		success = getTrakt('users/hidden/dropped', post=post)
		if success:
			if 'plugin.video.infinity' in control.infoLabel('Container.PluginName'): control.refresh()
			sync_hidden_progress(forced=True)
			control.trigger_widget_refresh()
			return True
	except:
		log_utils.error(f'hideItems tvdb_ids error: {tvdb_ids}')
		return False

def hideItem(name, imdb=None, tvdb=None, season=None, episode=None, refresh=True, tvshow=None):
	success = None
	try:
		control.busy()
		if tvdb: post = {"shows": [{"ids": {"tvdb": tvdb}}]}
		else: post = {"movies": [{"ids": {"imdb": imdb}}]}
		success = getTrakt('users/hidden/dropped', post=post)
		if success:
			control.hide()
			sync_hidden_progress(forced=True)
			if refresh: control.refresh()
			control.trigger_widget_refresh()
			if getSetting('trakt.general.notifications') == 'true':
				control.notification(title=32315, message=getLS(33053) % name)
	except: log_utils.error()

def removeCollectionItems(type, id_list):
	if not id_list: return
	success = None
	try:
		ids = []
		total_items = len(id_list)
		for id in id_list: ids.append({"ids": {"trakt": id}})
		post = {type: ids}
		success = getTrakt('/sync/collection/remove', post=post)
		if success:
			# if 'plugin.video.infinity' in control.infoLabel('Container.PluginName'): control.refresh()
			control.trigger_widget_refresh()
			if type == 'movies': traktsync.delete_collection_items(id_list, 'movies_collection')
			else: traktsync.delete_collection_items(id_list, 'shows_collection')
			if getSetting('trakt.general.notifications') == 'true':
				control.notification(title='Trakt Collection Manager', message='Successfuly Removed %s Item%s' % (total_items, 's' if total_items >1 else ''))
	except: log_utils.error()

def removeWatchlistItems(type, id_list):
	if not id_list: return
	success = None
	try:
		ids = []
		total_items = len(id_list)
		for id in id_list: ids.append({"ids": {"trakt": id}})
		post = {type: ids}
		success = getTrakt('/sync/watchlist/remove', post=post)
		if success:
			# if 'plugin.video.infinity' in control.infoLabel('Container.PluginName'): control.refresh()
			control.trigger_widget_refresh()
			if type == 'movies': traktsync.delete_watchList_items(id_list, 'movies_watchlist')
			else: traktsync.delete_watchList_items(id_list, 'shows_watchlist')
			if getSetting('trakt.general.notifications') == 'true':
				control.notification(title='Trakt Watch List Manager', message='Successfuly Removed %s Item%s' % (total_items, 's' if total_items >1 else ''))
	except: log_utils.error()

def manager(name, imdb=None, tvdb=None, season=None, episode=None, refresh=True, watched=None, unfinished=False, tvshow=None):
	lists = []
	try:
		if season: season = int(season)
		if episode: episode = int(episode)
		media_type = 'Show' if tvdb else 'Movie'
		if watched is not None:
			if watched is True:
				items = [(getLS(33652) % highlight_color, 'unwatch')]
			else:
				items = [(getLS(33651) % highlight_color, 'watch')]
		else:
			items = [(getLS(33651) % highlight_color, 'watch')]
			items += [(getLS(33652) % highlight_color, 'unwatch')]
		if control.condVisibility('System.HasAddon(script.trakt)'):
			items += [(getLS(33653) % highlight_color, 'rate')]
			items += [(getLS(33654) % highlight_color, 'unrate')]
		if tvdb:
			items += [(getLS(40075) % (highlight_color, media_type), 'hideItem')]
			items += [(getLS(35058) % highlight_color, 'hiddenManager')]
		if unfinished is True:
			if media_type == 'Movie': items += [(getLS(35059) % highlight_color, 'unfinishedMovieManager')]
			elif episode: items += [(getLS(35060) % highlight_color, 'unfinishedEpisodeManager')]
		if getSetting('scrobble.source') == '1' or getSetting('trakt.markwatched') == 'true':
			if media_type == 'Movie' or episode:
				items += [(getLS(40076) % highlight_color, 'scrobbleReset')]
		if season or episode:
			items += [(getLS(33573) % highlight_color, '/sync/watchlist')]
			items += [(getLS(33574) % highlight_color, '/sync/watchlist/remove')]
		items += [(getLS(33577) % highlight_color, '/sync/watchlist')]
		items += [(getLS(33578) % highlight_color, '/sync/watchlist/remove')]
		items += [(getLS(33575) % highlight_color, '/sync/collection')]
		items += [(getLS(33576) % highlight_color, '/sync/collection/remove')]
		items += [(getLS(33579), '/users/me/lists/%s/items')]

		result = get_all_pages('/users/me/lists')
		lists = [(i['name'], i['ids']['slug']) for i in result]
		lists = [lists[i//2] for i in range(len(lists)*2)]

		for i in range(0, len(lists), 2):
			lists[i] = ((getLS(33580) % (highlight_color, lists[i][0])), '/users/me/lists/%s/items' % lists[i][1])
		for i in range(1, len(lists), 2):
			lists[i] = ((getLS(33581) % (highlight_color, lists[i][0])), '/users/me/lists/%s/items/remove' % lists[i][1])
		items += lists

		control.hide()
		select = control.selectDialog([i[0] for i in items], heading=control.addonInfo('name') + ' - ' + getLS(32515))

		if select == -1: return
		if select >= 0:
			if items[select][1] == 'watch':
				watch(control.infoLabel('Container.ListItem.DBTYPE'), name, imdb=imdb, tvdb=tvdb, season=season, episode=episode, refresh=refresh)
			elif items[select][1] == 'unwatch':
				unwatch(control.infoLabel('Container.ListItem.DBTYPE'), name, imdb=imdb, tvdb=tvdb, season=season, episode=episode, refresh=refresh)
			elif items[select][1] == 'rate':
				rate(imdb=imdb, tvdb=tvdb, season=season, episode=episode)
			elif items[select][1] == 'unrate':
				unrate(imdb=imdb, tvdb=tvdb, season=season, episode=episode)
			elif items[select][1] == 'hideItem':
				hideItem(name=name, imdb=imdb, tvdb=tvdb, season=season, episode=episode, tvshow=tvshow)
			elif items[select][1] == 'hiddenManager':
				control.execute('RunPlugin(plugin://plugin.video.infinity/?action=shows_traktHiddenManager)')
			elif items[select][1] == 'unfinishedEpisodeManager':
				control.execute('RunPlugin(plugin://plugin.video.infinity/?action=episodes_traktUnfinishedManager)')
			elif items[select][1] == 'unfinishedMovieManager':
				control.execute('RunPlugin(plugin://plugin.video.infinity/?action=movies_traktUnfinishedManager)')
			elif items[select][1] == 'scrobbleReset':
				scrobbleReset(imdb=imdb, tmdb='', tvdb=tvdb, season=season, episode=episode, widgetRefresh=True, clear_local=getSetting('indicators.alt') == '1')
			else:
				if not tvdb: post = {"movies": [{"ids": {"imdb": imdb}}]}
				else:
					if episode:
						if items[select][1] == '/sync/watchlist' or items[select][1] == '/sync/watchlist/remove':
							post = {"shows": [{"ids": {"tvdb": tvdb}}]}
						else:
							post = {"shows": [{"ids": {"tvdb": tvdb}, "seasons": [{"number": season, "episodes": [{"number": episode}]}]}]}
							name = name + ' - ' + '%sx%02d' % (season, episode)
					elif season:
						if items[select][1] == '/sync/watchlist' or items[select][1] == '/sync/watchlist/remove':
							post = {"shows": [{"ids": {"tvdb": tvdb}}]}
						else:
							post = {"shows": [{"ids": {"tvdb": tvdb}, "seasons": [{"number": season}]}]}
							name = name + ' - ' + 'Season %s' % season
					else: post = {"shows": [{"ids": {"tvdb": tvdb}}]}
				if items[select][1] == '/users/me/lists/%s/items':
					slug = listAdd(successNotification=True)
					if slug: getTrakt(items[select][1] % slug, post=post)
				else: getTrakt(items[select][1], post=post)

				if items[select][1] == '/sync/watchlist': sync_watch_list(forced=True)
				if items[select][1] == '/sync/watchlist/remove':
					if media_type == 'Movie': traktsync.delete_watchList_items([imdb], 'movies_watchlist', 'imdb')
					else: traktsync.delete_watchList_items([tvdb], 'shows_watchlist', 'tvdb')
				if items[select][1] == '/sync/collection':
					sync_collection(forced=True)
				if items[select][1] == '/sync/collection/remove':
					if media_type == 'Movie': traktsync.delete_collection_items([imdb], 'movies_collection', 'imdb')
					else: traktsync.delete_collection_items([tvdb], 'shows_collection', 'tvdb')
				if '/users/me/lists/' in items[select][1] and items[select][1].endswith('/remove'):
					control.homeWindow.setProperty('infinity.trakt.userlist.modified', 'true')

				control.hide()
				list = re.search(r'\[B\](.+?)\[/B\]', items[select][0]).group(1)
				message = getLS(33583) if 'remove' in items[select][1] else getLS(33582)
				if items[select][0].startswith('Add'): refresh = False
				control.hide()
				if refresh: control.refresh()
				control.trigger_widget_refresh()
				if getSetting('trakt.general.notifications') == 'true': control.notification(title=name, message=message + ' (%s)' % list)
	except:
		log_utils.error()
		control.hide()

def listAdd(successNotification=True):
	t = getLS(32520)
	k = control.keyboard('', t) ; k.doModal()
	new = k.getText() if k.isConfirmed() else None
	if not new: return
	result = getTrakt('/users/me/lists', post = {"name" : new, "privacy" : "private"})
	try:
		slug = result.json()['ids']['slug']
		if successNotification: control.notification(title=32070, message=33661)
		return slug
	except:
		control.notification(title=32070, message=33584)
		return None

def lists(id=None):
	return cache.get(getTraktAsJson, 48, 'https://api.trakt.tv/users/me/lists' + ('' if not id else ('/' + str(id))))

def list(id):
	return lists(id=id)

def slug(name):
	name = name.strip()
	name = name.lower()
	name = re.sub(r'[^a-z0-9_]', '-', name) # check apostrophe
	name = re.sub(r'--+', '-', name)
	return name

def getActivity():
	try:
		i = getTraktAsJson('/sync/last_activities')
		if not i: return 0
		activity = []
		activity.append(i['movies']['watched_at']) # added 8/30/20
		activity.append(i['movies']['collected_at'])
		activity.append(i['movies']['watchlisted_at'])
		activity.append(i['movies']['paused_at']) # added 8/30/20
		activity.append(i['movies']['hidden_at']) # added 4/02/21
		activity.append(i['episodes']['watched_at']) # added 8/30/20
		activity.append(i['episodes']['collected_at'])
		activity.append(i['episodes']['watchlisted_at'])
		activity.append(i['episodes']['paused_at']) # added 8/30/20
		activity.append(i['shows']['watchlisted_at'])
		activity.append(i['shows']['hidden_at']) # added 4/02/21
		activity.append(i['seasons']['watchlisted_at'])
		activity.append(i['seasons']['hidden_at']) # added 4/02/21
		activity.append(i['lists']['liked_at'])
		activity.append(i['lists']['updated_at'])
		activity = [int(cleandate.iso_2_utc(i)) for i in activity]
		activity = sorted(activity, key=int)[-1]
		return activity
	except: log_utils.error()

def getHiddenActivity(activities=None):
	try:
		if activities: i = activities
		else: i = getTraktAsJson('/sync/last_activities')
		if not i: return 0
		activity = []
		activity.append(i['movies']['hidden_at'])
		activity.append(i['shows']['hidden_at'])
		activity.append(i['seasons']['hidden_at'])
		activity = [int(cleandate.iso_2_utc(i)) for i in activity]
		activity = sorted(activity, key=int)[-1]
		return activity
	except: log_utils.error()

def getWatchedActivity(activities=None):
	try:
		if activities: i = activities
		else: i = getTraktAsJson('/sync/last_activities')
		if not i: return 0
		activity = []
		activity.append(i['movies']['watched_at'])
		activity.append(i['episodes']['watched_at'])
		activity = [int(cleandate.iso_2_utc(i)) for i in activity]
		activity = sorted(activity, key=int)[-1]
		return activity
	except: log_utils.error()

def getMoviesWatchedActivity(activities=None):
	try:
		if activities: i = activities
		else: i = getTraktAsJson('/sync/last_activities')
		if not i: return 0
		activity = []
		activity.append(i['movies']['watched_at'])
		activity = [int(cleandate.iso_2_utc(i)) for i in activity]
		activity = sorted(activity, key=int)[-1]
		return activity
	except: log_utils.error()

def getEpisodesWatchedActivity(activities=None):
	try:
		if activities: i = activities
		else: i = getTraktAsJson('/sync/last_activities')
		if not i: return 0
		activity = []
		activity.append(i['episodes']['watched_at'])
		activity = [int(cleandate.iso_2_utc(i)) for i in activity]
		activity = sorted(activity, key=int)[-1]
		return activity
	except: log_utils.error()

def getCollectedActivity(activities=None):
	try:
		if activities: i = activities
		else: i = getTraktAsJson('/sync/last_activities')
		if not i: return 0
		activity = []
		activity.append(i['movies']['collected_at'])
		activity.append(i['episodes']['collected_at'])
		activity = [int(cleandate.iso_2_utc(i)) for i in activity]
		activity = sorted(activity, key=int)[-1]
		return activity
	except: log_utils.error()

def getWatchListedActivity(activities=None):
	try:
		if activities: i = activities
		else: i = getTraktAsJson('/sync/last_activities')
		if not i: return 0
		activity = []
		activity.append(i['movies']['watchlisted_at'])
		activity.append(i['episodes']['watchlisted_at'])
		activity.append(i['shows']['watchlisted_at'])
		activity.append(i['seasons']['watchlisted_at'])
		activity = [int(cleandate.iso_2_utc(i)) for i in activity]
		activity = sorted(activity, key=int)[-1]
		return activity
	except: log_utils.error()

def getPausedActivity(activities=None):
	try:
		if activities: i = activities
		else: i = getTraktAsJson('/sync/last_activities')
		if not i: return 0
		activity = []
		activity.append(i['movies']['paused_at'])
		activity.append(i['episodes']['paused_at'])
		activity = [int(cleandate.iso_2_utc(i)) for i in activity]
		activity = sorted(activity, key=int)[-1]
		return activity
	except: log_utils.error()

def getListActivity(activities=None):
	try:
		if activities: i = activities
		else: i = getTraktAsJson('/sync/last_activities')
		if not i: return 0
		activity = []
		activity.append(i['lists']['liked_at'])
		activity.append(i['lists']['updated_at'])
		activity = [int(cleandate.iso_2_utc(i)) for i in activity]
		activity = sorted(activity, key=int)[-1]
		return activity
	except: log_utils.error()

def getUserListActivity(activities=None):
	try:
		if activities: i = activities
		else: i = getTraktAsJson('/sync/last_activities')
		if not i: return 0
		activity = []
		activity.append(i['lists']['updated_at'])
		activity = [int(cleandate.iso_2_utc(i)) for i in activity]
		activity = sorted(activity, key=int)[-1]
		return activity
	except: log_utils.error()

def getProgressActivity(activities=None):
	try:
		if activities: i = activities
		else: i = getTraktAsJson('/sync/last_activities')
		if not i: return 0
		activity = []
		activity.append(i['episodes']['watched_at'])
		activity.append(i['shows']['hidden_at'])
		activity.append(i['seasons']['hidden_at'])
		activity = [int(cleandate.iso_2_utc(i)) for i in activity]
		activity = sorted(activity, key=int)[-1]
		return activity
	except: log_utils.error()

def cachesyncMovies(timeout=0):
	indicators = traktsync.get(syncMovies, timeout)
	#if getSetting('sync.watched.library') == 'true':
		#syncMoviesLibrary(indicators)
	return indicators

def syncMovies():
	try:
		if not getTraktCredentialsInfo(): return
		_start = time.time()
		indicators = get_all_pages('/users/me/watched/movies')
		if not indicators: return None
		indicators = [i['movie']['ids'] for i in indicators]
		indicators = [str(i['imdb']) for i in indicators if 'imdb' in i]
		log_utils.log('TRAKT: syncMovies complete: %d movies in %.1fs' % (len(indicators), time.time() - _start), level=log_utils.LOGINFO)
		return indicators
	except: log_utils.error()

def syncMovies_delta(last_sync_at):
	"""Fetch movie watch events since last_sync_at. Returns new IMDb ID list, [] if none, None on error."""
	try:
		if not getTraktCredentialsInfo(): return None
		from datetime import datetime as _dt
		_start = time.time()
		date_from = _dt.utcfromtimestamp(last_sync_at).strftime('%Y-%m-%dT%H:%M:%SZ')
		log_utils.log('TRAKT delta: movies delta started from %s' % date_from, level=log_utils.LOGDEBUG)
		history = get_all_pages('/users/me/history/movies?start_at=%s' % date_from)
		if history is None: return None
		if not history: return []
		seen = set()
		new_ids = []
		for entry in history:
			imdb = str(entry.get('movie', {}).get('ids', {}).get('imdb', ''))
			if imdb and imdb not in seen:
				seen.add(imdb)
				new_ids.append(imdb)
		log_utils.log('TRAKT delta: movies delta complete: %d new movie(s) in %.1fs' % (len(new_ids), time.time() - _start), level=log_utils.LOGINFO)
		return new_ids
	except: log_utils.error(); return None

def timeoutsyncMovies():
	timeout = traktsync.timeout(syncMovies)
	return timeout

def syncMoviesLibrary(indicators):
	if indicators:
		try:
			libMovies = control.jsonrpc('{"jsonrpc": "2.0","method":"VideoLibrary.GetMovies","params":{"properties": ["title", "year", "lastplayed", "playcount", "uniqueid"],"sort": {"order": "ascending", "method": "title"}},"id":1}')
			libMovies = jsloads(libMovies).get('result').get('movies')
		except:
			libMovies = []
		moviebatch = []
		removeBatch = []
		for movie in libMovies:
			if str(movie.get('uniqueid').get('imdb')) not in indicators:
				if movie.get('playcount')== 1:
					removeBatch.append(jsloads('{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails","params":{"movieid":%s, "playcount":0}, "id":3}' % movie.get('movieid')))
					log_utils.log('Movie Marked for Playcount Removal. Movie: %s' % movie.get('label'), level=log_utils.LOGDEBUG)
			for indicator in indicators:
				if str(movie.get('uniqueid').get('imdb')) == str(indicator): #compare imdb ids in library with imdb ids in indicators

						if str(movie.get('playcount')) == '1':
							log_utils.log('Movie Already Marked. Movie: %s' % movie.get('label'),level=log_utils.LOGDEBUG)
						else:
							moviebatch.append(jsloads('{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails","params":{"movieid":%s, "playcount":1}, "id":2}' % movie.get('movieid')))
							log_utils.log('Marked Movie: %s' % movie.get('label'),level=log_utils.LOGDEBUG)
		if len(moviebatch) > 0 or len(removeBatch) > 0:
			moviebatch.extend(removeBatch)
			control.jsonrpc(jsdumps(moviebatch))

def watchedMovies():
	try:
		if not getTraktCredentialsInfo(): return
		return get_all_pages('/users/me/watched/movies?extended=full')
	except: log_utils.error()

def watchedMoviesTime(imdb):
	try:
		imdb = str(imdb)
		items = watchedMovies()
		for item in items:
			if str(item['movie']['ids']['imdb']) == imdb: return item['last_watched_at']
	except: log_utils.error()

def _fetch_watched_movies_dates():
	items = get_all_pages('/users/me/watched/movies')
	if not items: return {}
	return {str(i['movie']['ids']['imdb']): i.get('last_watched_at', '') for i in items if i.get('movie', {}).get('ids', {}).get('imdb')}

def getWatchedMoviesLastWatchedDates():
	"""Returns {imdb_id: last_watched_at} for all watched movies. Used to populate lastplayed for sort-by-date-watched on user lists."""
	try:
		if not getTraktCredentialsInfo(): return {}
		return traktsync.get(_fetch_watched_movies_dates, 60) or {}
	except:
		log_utils.error()
		return {}

def _fetch_watched_shows_dates():
	items = get_all_pages('/users/me/watched/shows')
	if not items: return {}
	return {str(i['show']['ids']['tvdb']): i.get('last_watched_at', '') for i in items if i.get('show', {}).get('ids', {}).get('tvdb')}

def getWatchedShowsLastWatchedDates():
	"""Returns {tvdb_id: last_watched_at} for all watched shows. Used to populate lastplayed for sort-by-date-watched on user lists."""
	try:
		if not getTraktCredentialsInfo(): return {}
		return traktsync.get(_fetch_watched_shows_dates, 60) or {}
	except:
		log_utils.error()
		return {}

def watchedShows():
	try:
		if not getTraktCredentialsInfo(): return
		return get_all_pages('/users/me/watched/shows')
	except: log_utils.error()

def watchedShowsTime(tvdb, season, episode):
	try:
		tvdb = str(tvdb)
		season = int(season)
		episode = int(episode)
		items = watchedShows()
		for item in items:
			if str(item['show']['ids']['tvdb']) == tvdb:
				seasons = item['seasons']
				for s in seasons:
					if s['number'] == season:
						episodes = s['episodes']
						for e in episodes:
							if e['number'] == episode:
								return e['last_watched_at']
	except: log_utils.error()

def cachesyncTV(imdb, tvdb): # sync full watched shows then sync imdb_id "season indicators" and "season counts"
	try:
		threads = [Thread(target=cachesyncTVShows), Thread(target=cachesyncSeasons, args=(imdb, tvdb))]
		[i.start() for i in threads]
		[i.join() for i in threads]
		traktsync.insert_syncSeasons_at()
	except: log_utils.error()

def cachesyncTVShows(timeout=0):
	try:
		indicators = traktsync.get(syncTVShows, timeout)
		#if getSetting('sync.watched.library') == 'true':
			#syncTVShowsLibrary(indicators)
		return indicators
	except:
		return ''

def _make_episode_ranges(ep_nums_sorted):
	if not ep_nums_sorted: return []
	ranges = []
	start = end = ep_nums_sorted[0]
	for ep in ep_nums_sorted[1:]:
		if ep == end + 1:
			end = ep
		else:
			ranges.append((start, end))
			start = end = ep
	ranges.append((start, end))
	return ranges

def syncTVShows(): # sync all watched shows ex. [({'imdb': 'tt12571834', 'tvdb': '384435', 'tmdb': '105161', 'trakt': '163639'}, 16, {1: [(1, 16)]}), ({'imdb': 'tt11761194', 'tvdb': '377593', 'tmdb': '119845', 'trakt': '158621'}, 2, {1: [(1, 2)]})]
	try:
		if not getTraktCredentialsInfo(): return
		# Process page-by-page to avoid loading all raw show data into memory at once.
		# ?extended=full is omitted — only ids/aired_episodes/seasons are used, not show metadata.
		_start = time.time()
		log_utils.log('TRAKT: syncTVShows started', level=log_utils.LOGDEBUG)
		indicators = []
		seen_ids = set()
		page = 1
		limit = 250
		while True:
			response = getTrakt('/users/me/watched/shows?extended=progress&page=%d&limit=%d' % (page, limit))
			if not response: break
			try: page_results = response.json()
			except: break
			if not page_results: break
			for i in page_results:
				try:
					tid = i['show']['ids']['trakt']
					if tid in seen_ids: continue
					seen_ids.add(tid)
					ids = {'imdb': i['show']['ids']['imdb'], 'tvdb': str(i['show']['ids']['tvdb']), 'tmdb': str(i['show']['ids']['tmdb']), 'trakt': str(i['show']['ids']['trakt'])}
					aired = int(i['show'].get('aired_episodes', 0))
# /shows/ID/progress/watched  endpoint only accepts imdb or trakt ID so write all ID's
					episodes = {}
					reset_at = i.get('reset_at')
					for s in i.get('seasons', []):
						if s.get('number', 0) == 0: continue
						ep_nums = sorted(e['number'] for e in s['episodes'] if e.get('last_watched_at') and (reset_at is None or e['last_watched_at'] > reset_at))
						if ep_nums: episodes[s['number']] = _make_episode_ranges(ep_nums)
					indicators.append((ids, aired, episodes))
				except: pass
			log_utils.log('TRAKT: syncTVShows page %d: %d shows fetched' % (page, len(page_results)), level=log_utils.LOGDEBUG)
			if hasattr(response, 'headers'):
				total_pages = response.headers.get('X-Pagination-Page-Count')
				if total_pages:
					try:
						if page >= int(total_pages): break
					except: pass
				total_items = response.headers.get('X-Pagination-Item-Count')
				if total_items:
					try:
						if len(indicators) >= int(total_items): break
					except: pass
			if len(page_results) < limit: break
			page += 1
			if page > 400: break
		log_utils.log('TRAKT: syncTVShows complete: %d shows in %.1fs' % (len(indicators) if indicators else 0, time.time() - _start), level=log_utils.LOGINFO)
		return indicators if indicators else None
	except: log_utils.error()

def syncTVShows_delta(last_sync_at, activity_at=None):
	"""
	Delta sync: fetch shows with episode watches since last_sync_at via history endpoint,
	then pull per-show /progress/watched for only those shows.
	Returns list of (ids, aired, episodes) tuples for changed shows, [] if none, None on error.
	If activity_at is provided and newer than the latest history entry, returns None to trigger
	a full sync (handles the case where an unwatch occurred after the last history entry).
	"""
	try:
		if not getTraktCredentialsInfo(): return None
		from datetime import datetime as _dt
		_start = time.time()
		date_from = _dt.utcfromtimestamp(last_sync_at).strftime('%Y-%m-%dT%H:%M:%SZ')
		log_utils.log('TRAKT delta: shows delta started from %s' % date_from, level=log_utils.LOGDEBUG)
		history = get_all_pages('/users/me/history/shows?start_at=%s' % date_from)
		if history is None: return None
		if not history: return []
		if activity_at:
			from resources.lib.modules import cleandate as _cleandate
			history_latest = max((int(_cleandate.iso_2_utc(e.get('watched_at', ''))) for e in history if e.get('watched_at')), default=0)
			if history_latest and activity_at > history_latest + 30:
				log_utils.log('TRAKT delta: activity gap detected (history_latest=%d, activity_at=%d) — falling back to full sync' % (history_latest, activity_at), level=log_utils.LOGDEBUG)
				return None
		changed_shows = {}
		for entry in history:
			show = entry.get('show', {})
			ids = show.get('ids', {})
			trakt_id = str(ids.get('trakt', ''))
			if trakt_id and trakt_id not in changed_shows:
				changed_shows[trakt_id] = {
					'imdb': str(ids.get('imdb', '')) if ids.get('imdb') else '',
					'tvdb': str(ids.get('tvdb', '')) if ids.get('tvdb') else '',
					'tmdb': str(ids.get('tmdb', '')) if ids.get('tmdb') else '',
					'trakt': trakt_id
				}
		log_utils.log('TRAKT delta: %d show(s) changed (%d history events)' % (len(changed_shows), len(history)), level=log_utils.LOGDEBUG)
		updated_indicators = []
		for trakt_id, show_ids in changed_shows.items():
			progress = getTraktAsJson('/shows/%s/progress/watched' % trakt_id, silent=True)
			if not progress: continue
			aired = int(progress.get('aired', 0))
			reset_at = progress.get('reset_at')
			episodes = {}
			for season in progress.get('seasons', []):
				snum = season.get('number', 0)
				if snum == 0: continue
				ep_nums = sorted(
					ep['number'] for ep in season.get('episodes', [])
					if ep.get('completed') and (reset_at is None or ep.get('last_watched_at', '') > reset_at)
				)
				if ep_nums:
					episodes[snum] = _make_episode_ranges(ep_nums)
			updated_indicators.append((show_ids, aired, episodes))
		log_utils.log('TRAKT delta: shows delta complete: %d shows updated in %.1fs' % (len(updated_indicators), time.time() - _start), level=log_utils.LOGINFO)
		return updated_indicators
	except: log_utils.error(); return None

# def syncTVShowsLibrary(indicators):
# 	if indicators:
# 		try:
# 			libShows = control.jsonrpc('{"jsonrpc": "2.0","method":"VideoLibrary.GetTVShows","params":{"properties": ["title", "year", "lastplayed", "playcount", "uniqueid"],"sort": {"order": "ascending", "method": "title"}},"id":1}')
# 			libShows = jsloads(libShows).get('result').get('tvshows')
# 		except:
# 			libShows = []
# 		episodesMarked = []
# 		removeBatch2 = []
# 		for show in libShows:
# 			if str(show.get('uniqueid').get('imdb')) not in str(indicators):
# 				eps = control.jsonrpc('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.GetEpisodes","params":{"tvshowid":%s, "properties": ["season", "episode", "playcount"]}}' % show.get('tvshowid'))
# 				eps = jsloads(eps).get('result').get('episodes')
# 				for episodes in eps:
				
# 					if episodes.get('playcount') == 1:
# 						removeBatch2.append(jsloads(('{"jsonrpc":"2.0","method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":%s, "playcount":0}, "id":3}' % episodes.get('episodeid'))))
# 						log_utils.log('Show Marked for Playcount Removal. Show: %s' % show.get('label'),level=log_utils.LOGDEBUG)
# 			for indicator in indicators:
# 				if str(show.get('uniqueid').get('imdb')) == str(indicator[0]['imdb']): #compare imdb ids in library with imdb ids in indicators
# 					epsWatched = indicator[2]
# 					eps = control.jsonrpc('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.GetEpisodes","params":{"tvshowid":%s, "properties": ["season", "episode", "playcount"]}}' % show.get('tvshowid'))
# 					eps = jsloads(eps).get('result').get('episodes')
# 					for epis in eps:
# 						if (epis.get('season'), epis.get('episode')) not in epsWatched:
# 							if epis.get('playcount') == 1:
# 								removeBatch2.append(jsloads(('{"jsonrpc":"2.0","method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":%s, "playcount":0}, "id":3}' % epis.get('episodeid'))))
# 								log_utils.log('Marked for playcount removal show: %s season: %s episode: %s' % (show.get('label'), epis.get('season'),epis.get('episode')),level=log_utils.LOGDEBUG)
# 						for ep in epsWatched:
# 							if ep[0] == epis.get('season') and ep[1] == epis.get('episode'):
# 								if epis.get('playcount') == 0:
# 									episodesMarked.append(jsloads(('{"jsonrpc":"2.0","method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":%s, "playcount":1}, "id":2}' % epis.get('episodeid'))))
# 									log_utils.log('Marked show: %s season: %s episode: %s' % (show.get('label'), epis.get('season'),epis.get('episode')),level=log_utils.LOGDEBUG)
# 		if len(episodesMarked) > 0 or len(removeBatch2) > 0:
# 			episodesMarked.extend(removeBatch2)
# 			control.jsonrpc(jsdumps(episodesMarked))

def cachesyncSeasons(imdb, tvdb, trakt=None, timeout=0):
	try:
		imdb = imdb or ''
		tvdb = tvdb or ''
		indicators = traktsync.get(syncSeasons, timeout, imdb, tvdb, trakt=trakt) # named var not included in function md5_hash
		return indicators
	except: log_utils.error()

def syncSeasons(imdb, tvdb, trakt=None): # season indicators and counts for watched shows ex. [['1', '2', '3'], {1: {'total': 8, 'watched': 8, 'unwatched': 0}, 2: {'total': 10, 'watched': 10, 'unwatched': 0}}]
	indicators_and_counts = []
	try:
		if all(not value for value in (imdb, tvdb, trakt)): return
		if not getTraktCredentialsInfo(): return
		id = imdb or trakt
		if not id and tvdb:
			log_utils.log('syncSeasons missing imdb_id, pulling trakt id from watched shows database', level=log_utils.LOGDEBUG)
			db_watched = traktsync.cache_existing(syncTVShows) # pull trakt ID from db because imdb ID is missing
			ids = [i[0] for i in db_watched if i[0].get('tvdb') == tvdb]
			id = ids[0].get('trakt', '') if ids[0].get('trakt') else ''
			if not id:
				log_utils.log("syncSeasons FAILED: missing required imdb and trakt ID's for tvdb=%s" % tvdb, level=log_utils.LOGDEBUG)
				return
		if getSetting('tv.specials') == 'true':
			results = getTraktAsJson('/shows/%s/progress/watched?specials=true&hidden=false&count_specials=true' % id, silent=True) # only imdb or trakt ID allowed
		else:
			results = getTraktAsJson('/shows/%s/progress/watched?specials=false&hidden=false' % id, silent=True)
		if not results: return

		seasons = [{'reset_at': results['reset_at']}, results['seasons']]
		reset_at = seasons[0].get('reset_at','')
		if reset_at:           #added to cover trakt reset watching
			for x in seasons[1]:
				episodesComplete = 0
				for y in x['episodes']:
					last_watched = y.get('last_watched_at', '')
					if last_watched:
						if last_watched < reset_at:
							y['completed'] = False
						else:
							episodesComplete = episodesComplete + 1
					else:
						if last_watched:
							episodesComplete = episodesComplete + 1
				x['completed'] = episodesComplete

		seasons = seasons[1]
###--- future-need tmdb_id passed now ---###
		# next_episode = results['next_episode']
		# # log_utils.log('next_episode=%s' % next_episode)
		# db_watched = traktsync.cache_existing(syncTVShows)
		# ids = [i[0] for i in db_watched if (i[0].get('imdb') == imdb or i[0].get('tvdb') == tvdb)]
		# tmdb = str(ids[0].get('tmdb', '')) if ids[0].get('tmdb') else ''
		# trakt = str(ids[0].get('trakt', '')) if ids[0].get('trakt') else ''
		# traktsync.insert_nextEpisode(imdb, tvdb, tmdb, trakt, next_episode)
#######
		#indicators = [({'imdb': i['show']['ids']['imdb'], 'tvdb': str(i['show']['ids']['tvdb']), 'tmdb': str(i['show']['ids']['tmdb']), 'trakt': str(i['show']['ids']['trakt'])}, \
											#i['show']['aired_episodes'], sum([[(s['number'], e['number']) for e in s['episodes'] if i['reset_at'] is None or e['last_watched_at'] > i['reset_at']] for s in i['seasons']], [])) for i in indicators]
		indicators = [(i['number'], [x['completed'] for x in i['episodes']]) for i in seasons]
		indicators = ['%01d' % int(i[0]) for i in indicators if False not in i[1]]
		indicators_and_counts.append(indicators)
		counts = {season['number']: {'total': season['aired'], 'watched': season['completed'], 'unwatched': max(0, season['aired'] - season['completed'])} for season in seasons}
		indicators_and_counts.append(counts)
		return indicators_and_counts
	except:
		log_utils.error()
		return None

def seasonCount(imdb, tvdb): # return counts for all seasons of a show from traktsync.db
	try:
		counts = traktsync.cache_existing(syncSeasons, imdb, tvdb) # this needs trakt ID
		if not counts: return
		return counts[1]
	except:
		log_utils.error()
		return None

def timeoutsyncTVShows():
	timeout = traktsync.timeout(syncTVShows)
	return timeout

def timeoutsyncSeasons(imdb, tvdb):
	try:
		timeout = traktsync.timeout(syncSeasons, imdb, tvdb, returnNone=True) # returnNone must be named arg or will end up considered part of "*args"
		return timeout
	except: log_utils.error()

def update_syncMovies(imdb, remove_id=False):
	try:
		indicators = traktsync.cache_existing(syncMovies)
		if remove_id: indicators.remove(imdb)
		else: indicators.append(imdb)
		key = traktsync._hash_function(syncMovies, ())
		traktsync.cache_insert(key, repr(indicators))
	except: log_utils.error()

def service_syncSeasons(): # season indicators and counts for watched shows ex. [['1', '2', '3'], {1: {'total': 8, 'watched': 8, 'unwatched': 0}, 2: {'total': 10, 'watched': 10, 'unwatched': 0}}]
	def _compute_one(show_tuple):
		try:
			from resources.lib.indexers.tmdb import TVshows as _TMDbTVshows
			ids = show_tuple[0]
			episodes_dict = show_tuple[2] # {season_num: [(start_ep, end_ep), ...]}
			imdb = ids.get('imdb', '') or ''
			tvdb = str(ids.get('tvdb', '') or '')
			tmdb_id = str(ids.get('tmdb', '') or '')
			if not tmdb_id: return
			tmdb_counts = cache.get(_TMDbTVshows().get_season_aired_counts, 96, tmdb_id) or {} # {str(season_num): aired_episode_count}
			completed, counts = [], {}
			for season_num, ranges in episodes_dict.items():
				watched = sum(end - start + 1 for start, end in ranges)
				total = tmdb_counts.get(str(season_num), 0)
				unwatched = max(0, total - watched)
				counts[season_num] = {'total': total, 'watched': watched, 'unwatched': unwatched}
				if total > 0 and unwatched == 0:
					completed.append('%01d' % int(season_num))
			key = traktsync._hash_function(syncSeasons, (imdb, tvdb))
			traktsync.cache_insert(key, repr([sorted(completed), counts]))
		except: log_utils.error()
	try:
		monitor = control.monitor_class()
		watched_data = traktsync.cache_existing(syncTVShows) # use cached data from service cachesyncTVShows() just written fresh
		if not watched_data: return
		threads = [Thread(target=_compute_one, args=(show_tuple,)) for show_tuple in watched_data]
		_unlimited = getSetting('dev.batch.unlimited') == 'true'
		_bs = max(int(getSetting('dev.batch.size') or '10'), 1)
		_chunk = max(len(threads), 1) if _unlimited else _bs
		for i in range(0, len(threads), _chunk):
			if monitor.abortRequested(): break
			batch = threads[i:i + _chunk]
			[t.start() for t in batch]
			[t.join() for t in batch]
		traktsync.insert_syncSeasons_at()
	except: log_utils.error()

def markMovieAsWatched(imdb):
	try:
		result = getTraktAsJson('/sync/history', {"movies": [{"ids": {"imdb": imdb}}]})
		result = result['added']['movies'] != 0
		if getSetting('debug.level') == '1':
			log_utils.log('Trakt markMovieAsWatched IMDB: %s Result: %s' % (imdb, result), level=log_utils.LOGDEBUG)
		return result
	except: log_utils.error()

def markMovieAsNotWatched(imdb):
	try:
		result = getTraktAsJson('/sync/history/remove', {"movies": [{"ids": {"imdb": imdb}}]})
		return result['deleted']['movies'] != 0
	except: log_utils.error()

def markTVShowAsWatched(imdb, tvdb):
	try:
		result = getTraktAsJson('/sync/history', {"shows": [{"ids": {"imdb": imdb, "tvdb": tvdb}}]})
		if result['added']['episodes'] == 0 and tvdb: # sometimes trakt fails to mark because of imdb_id issues, check tvdb only as fallback if it fails
			control.sleep(1000) # POST 1 call per sec rate-limit
			result = getTraktAsJson('/sync/history', {"shows": [{"ids": {"tvdb": tvdb}}]})
			if not result: return False
		return result['added']['episodes'] != 0
	except: log_utils.error()

def markTVShowAsNotWatched(imdb, tvdb):
	try:
		result = getTraktAsJson('/sync/history/remove', {"shows": [{"ids": {"imdb": imdb, "tvdb": tvdb}}]})
		if not result: return False
		if result['deleted']['episodes'] == 0 and tvdb: # sometimes trakt fails to mark because of imdb_id issues, check tvdb only as fallback if it fails
			control.sleep(1000) # POST 1 call per sec rate-limit
			result = getTraktAsJson('/sync/history/remove', {"shows": [{"ids": {"tvdb": tvdb}}]})
			if not result: return False
		return result['deleted']['episodes'] != 0
	except: log_utils.error()

def markSeasonAsWatched(imdb, tvdb, season):
	try:
		season = int('%01d' % int(season))
		result = getTraktAsJson('/sync/history', {"shows": [{"seasons": [{"number": season}], "ids": {"imdb": imdb, "tvdb": tvdb}}]})
		if not result: return False
		if result['added']['episodes'] == 0 and tvdb: # sometimes trakt fails to mark because of imdb_id issues, check tvdb only as fallback if it fails
			control.sleep(1000) # POST 1 call per sec rate-limit
			result = getTraktAsJson('/sync/history', {"shows": [{"seasons": [{"number": season}], "ids": {"tvdb": tvdb}}]})
			if not result: return False
		return result['added']['episodes'] != 0
	except: log_utils.error()

def markSeasonAsNotWatched(imdb, tvdb, season):
	try:
		season = int('%01d' % int(season))
		result = getTraktAsJson('/sync/history/remove', {"shows": [{"seasons": [{"number": season}], "ids": {"imdb": imdb, "tvdb": tvdb}}]})
		if not result: return False
		if result['deleted']['episodes'] == 0 and tvdb: # sometimes trakt fails to mark because of imdb_id issues, check tvdb only as fallback if it fails
			control.sleep(1000) # POST 1 call per sec rate-limit
			result = getTraktAsJson('/sync/history/remove', {"shows": [{"seasons": [{"number": season}], "ids": {"tvdb": tvdb}}]})
			if not result: return False
		return result['deleted']['episodes'] != 0
	except: log_utils.error()

#commented out function previously here had good information in it. :)
def markEpisodeAsWatched(imdb, tvdb, season, episode):
	try:
		season, episode = int('%01d' % int(season)), int('%01d' % int(episode)) #same
		result = getTraktAsJson('/sync/history', {"shows": [{"seasons": [{"episodes": [{"number": episode}], "number": season}], "ids": {"imdb": imdb, "tvdb": tvdb}}]})
		if not result: return False
		if result['added']['episodes'] == 0 and tvdb:
			control.sleep(1000)
			result = getTraktAsJson('/sync/history', {"shows": [{"seasons": [{"episodes": [{"number": episode}], "number": season}], "ids": {"imdb": tvdb}}]})
			if not result: return False
		return result['added']['episodes'] !=0
	except: log_utils.error()

def markEpisodeAsNotWatched(imdb, tvdb, season, episode):
	try:
		season, episode = int('%01d' % int(season)), int('%01d' % int(episode))
		result = getTraktAsJson('/sync/history/remove', {"shows": [{"seasons": [{"episodes": [{"number": episode}], "number": season}], "ids": {"imdb": imdb, "tvdb": tvdb}}]})
		if not result: return False
		if result['deleted']['episodes'] == 0 and tvdb: # sometimes trakt fails to mark because of imdb_id issues, check tvdb only as fallback if it fails
			control.sleep(1000) # POST 1 call per sec rate-limit
			result = getTraktAsJson('/sync/history/remove', {"shows": [{"seasons": [{"episodes": [{"number": episode}], "number": season}], "ids": {"imdb": tvdb}}]})
			if not result: return False
		return result['deleted']['episodes'] !=0
	except: log_utils.error()

def getMovieTranslation(id, lang, full=False):
	url = '/movies/%s/translations/%s' % (id, lang)
	try:
		item = cache.get(getTraktAsJson, 96, url)
		if item: item = item[0]
		else: return None
		return item if full else item.get('title')
	except: log_utils.error()

def getTVShowTranslation(id, lang, season=None, episode=None, full=False):
	if season and episode: url = '/shows/%s/seasons/%s/episodes/%s/translations/%s' % (id, season, episode, lang)
	else: url = '/shows/%s/translations/%s' % (id, lang)
	try:
		item = cache.get(getTraktAsJson, 96, url)
		if item: item = item[0]
		else: return None
		return item if full else item.get('title')
	except: log_utils.error()

def getMovieSummary(id, full=True):
	try:
		url = '/movies/%s' % id
		if full: url += '?extended=full'
		return cache.get(getTraktAsJson, 48, url)
	except: log_utils.error()

def getTVShowSummary(id, full=True):
	try:
		url = '/shows/%s' % id
		if full: url += '?extended=full'
		return cache.get(getTraktAsJson, 48, url)
	except: log_utils.error()

def getEpisodeSummary(id, season, episode, full=True):
	try:
		url = '/shows/%s/seasons/%s/episodes/%s' % (id, season, episode)
		if full: url += '&extended=full'
		return cache.get(getTraktAsJson, 48, url)
	except: log_utils.error()

def getEpisodeType(id, season, episode, full=True):
	episodeType = ''
	try:
		url = '/shows/%s/seasons/%s/episodes/%s' % (id, season, episode)
		if full: url += '?extended=full'
		episodeMeta = cache.get(getTraktAsJson, 48, url)
		episodeType = episodeMeta.get('episode_type')
	except:
		log_utils.error()
	return episodeType

def getSeasons(id, full=True):
	try:
		url = '/shows/%s/seasons' % (id)
		if full: url += '&extended=full'
		return cache.get(getTraktAsJson, 48, url)
	except: log_utils.error()

def sort_list(sort_key, sort_direction, list_data):
	try:
		reverse = False if sort_direction == 'asc' else True
		if sort_key == 'rank': return sorted(list_data, key=lambda x: x['rank'], reverse=reverse)
		elif sort_key == 'added': return sorted(list_data, key=lambda x: x['listed_at'], reverse=reverse)
		elif sort_key == 'title': return sorted(list_data, key=lambda x: _title_key(x[x['type']].get('title')), reverse=reverse)
		elif sort_key == 'released': return sorted(list_data, key=lambda x: _released_key(x[x['type']]), reverse=reverse)
		elif sort_key == 'runtime': return sorted(list_data, key=lambda x: x[x['type']].get('runtime', 0), reverse=reverse)
		elif sort_key == 'popularity': return sorted(list_data, key=lambda x: x[x['type']].get('votes', 0), reverse=reverse)
		elif sort_key == 'percentage': return sorted(list_data, key=lambda x: x[x['type']].get('rating', 0), reverse=reverse)
		elif sort_key == 'votes': return sorted(list_data, key=lambda x: x[x['type']].get('votes', 0), reverse=reverse)
		else: return list_data
	except: log_utils.error(f'list_data: {list_data}')

def _title_key(title):
	try:
		if not title: title = ''
		articles_en = ['the', 'a', 'an']
		articles_de = ['der', 'die', 'das']
		articles = articles_en + articles_de
		match = re.match(r'^((\w+)\s+)', title.lower())
		if match and match.group(2) in articles: offset = len(match.group(1))
		else: offset = 0
		return title[offset:]
	except: return title

def _released_key(item):
	try:
		if 'released' in item: return item['released'] or '0'
		elif 'first_aired' in item: return item['first_aired'] or '0'
		else: return '0'
	except: log_utils.error()

def getMovieAliases(id):
	try:
		return cache.get(getTraktAsJson, 168, '/movies/%s/aliases' % id)
	except:
		log_utils.error()
		return []

def getTVShowAliases(id):
	try:
		return cache.get(getTraktAsJson, 168, '/shows/%s/aliases' % id)
	except:
		log_utils.error()
		return []

def getPeople(id, content_type, full=True):
	try:
		url = '/%s/%s/people' % (content_type, id)
		if full: url += '?extended=full'
		return cache.get(getTraktAsJson, 96, url)
	except: log_utils.error()

def SearchAll(title, year, full=True):
	try:
		return SearchMovie(title, year, full) , SearchTVShow(title, year, full)
	except:
		log_utils.error()
		return

def SearchMovie(title, year, fields=None, full=True):
	try:
		url = '/search/movie?query=%s' % title
		if year: url += '&year=%s' % year
		if fields: url += '&fields=%s' % fields
		if full: url += '&extended=full'
		return cache.get(getTraktAsJson, 96, url)
	except:
		log_utils.error()
		return

def SearchTVShow(title, year, fields=None, full=True):
	try:
		url = '/search/show?query=%s' % title
		if year: url += '&year=%s' % year
		if fields: url += '&fields=%s' % fields
		if full: url += '&extended=full'
		return cache.get(getTraktAsJson, 96, url)
	except:
		log_utils.error()
		return

def SearchEpisode(title, season, episode, full=True):
	try:
		url = '/search/%s/seasons/%s/episodes/%s' % (title, season, episode)
		if full: url += '&extended=full'
		return cache.get(getTraktAsJson, 96, url)
	except:
		log_utils.error()
		return

def getGenre(content, type, type_id):
	try:
		url = '/search/%s/%s?type=%s&extended=full' % (type, type_id, content)
		result = cache.get(getTraktAsJson, 168, url)
		if not result: return []
		return result[0].get(content, {}).get('genres', [])
	except:
		log_utils.error()
		return []

def IdLookup(id_type, id, type): # ("id_type" can be trakt, imdb, tmdb, tvdb) (type can be one of "movie , show , episode , person , list")
	try:
		url = '/search/%s/%s?type=%s' % (id_type, id, type)
		result = cache.get(getTraktAsJson, 168, url)
		if not result: return None
		return result[0].get(type).get('ids')
	except:
		log_utils.error()
		return None

def scrobbleMovie(imdb, tmdb, watched_percent):
	log_utils.log('Trakt Scrobble Movie Called. Received: imdb: %s tmdb: %s watched_percent: %s' % (imdb, tmdb, watched_percent), level=log_utils.LOGDEBUG)
	try:
		if not imdb.startswith('tt'): imdb = 'tt' + imdb
		success = getTrakt('/scrobble/pause', {"movie": {"ids": {"imdb": imdb}}, "progress": watched_percent})
		if success:
			log_utils.log('Trakt Scrobble Movie Success: imdb: %s s' % (imdb), level=log_utils.LOGDEBUG)
			if getSetting('scrobble.notify') == 'true': control.notification(message=32088)
			control.sleep(1000)
			sync_playbackProgress(forced=True)
			control.trigger_widget_refresh()
		else: control.notification(message=32130)
	except: log_utils.error()

def scrobbleEpisode(imdb, tmdb, tvdb, season, episode, watched_percent):
	#log_utils.log('Trakt Scrobble Episode Called. Received: imdb: %s tmdb: %s season: %s episode: %s watched_percent: %s' % (imdb, tmdb, season, episode, watched_percent), level=log_utils.LOGDEBUG)
	try:
		season, episode = int('%01d' % int(season)), int('%01d' % int(episode))
		success = getTrakt('/scrobble/pause', {"show": {"ids": {"tvdb": tvdb}}, "episode": {"season": season, "number": episode}, "progress": watched_percent})
		if success:
			log_utils.log('Trakt Scrobble Episode Success: imdb: %s s' % (imdb), level=log_utils.LOGDEBUG)
			if getSetting('scrobble.notify') == 'true': control.notification(message=32088)
			control.sleep(1000)
			sync_playbackProgress(forced=True)
			control.trigger_widget_refresh()
		else: control.notification(message=32130)
	except: log_utils.error()

def scrobbleStart(media_type, title='', tvshowtitle='', year='0', imdb='', tmdb='', tvdb='', season='', episode='', watched_percent=0):
	try:
		if media_type == 'movie':
			post = {'movie': {'title': title, 'year': int(year) if year else 0,
			                  'ids': {'imdb': imdb, 'tmdb': int(tmdb) if tmdb else None}},
			        'progress': float(watched_percent)}
		else:
			post = {'show': {'title': tvshowtitle or title, 'year': int(year) if year else 0,
			                 'ids': {'tvdb': int(tvdb) if tvdb else None, 'imdb': imdb}},
			        'episode': {'season': int(season) if season else 1,
			                    'number': int(episode) if episode else 1},
			        'progress': float(watched_percent)}
		getTrakt('/scrobble/start', post)
	except: log_utils.error()

def scrobbleReset(imdb, tmdb=None, tvdb=None, season=None, episode=None, refresh=True, widgetRefresh=False, clear_local=True):
	if not getTraktCredentialsInfo(): return
	if not control.player_class().isPlaying(): control.busy()
	success = False
	try:
		content_type = 'movie' if not episode else 'episode'
		resume_info = traktsync.fetch_bookmarks(imdb, tmdb, tvdb, season, episode, ret_type='resume_info')
		if resume_info == '0': return control.hide() # returns string "0" if no data in db
		headers['Authorization'] = 'Bearer %s' % trakt_token
		headers['trakt-api-key'] = traktClientID()
		success = session.delete('https://api.trakt.tv/sync/playback/%s' % resume_info[1], headers=headers).status_code == 204
		if content_type == 'movie':
			items = [{'type': 'movie', 'movie': {'ids': {'imdb': imdb}}}]
			label_string = resume_info[0]
		else:
			items = [{'type': 'episode', 'episode': {'season': season, 'number': episode}, 'show': {'ids': {'imdb': imdb, 'tvdb': tvdb}}}]
			label_string = resume_info[0] + ' - ' + 'S%02dE%02d' % (int(season), int(episode))
		control.hide()
		if success:
			timestamp = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.000Z")
			items[0].update({'paused_at': timestamp})
			if clear_local: traktsync.delete_bookmark(items)
			if refresh: control.refresh()
			if widgetRefresh: control.trigger_widget_refresh() # skinshortcuts handles the widget_refresh when plyback ends, but not a manual clear from Trakt Manager
			if getSetting('scrobble.notify') == 'true': control.notification(title=32315, message='Successfuly Removed playback progress:  [COLOR %s]%s[/COLOR]' % (highlight_color, label_string))
			log_utils.log('Successfuly Removed Trakt Playback Progress:  %s  with resume_id=%s' % (label_string, str(resume_info[1])), __name__, level=log_utils.LOGDEBUG)
		else:
			#if getSetting('scrobble.notify') == 'true': control.notification(title=32315, message='Failed to Remove playback progress:  [COLOR %s]%s[/COLOR]' % (highlight_color, label_string))
			log_utils.log('Failed to Remove Trakt Playback Progress:  %s  with resume_id=%s' % (label_string, str(resume_info[1])), __name__, level=log_utils.LOGDEBUG)
	except: log_utils.error()

def scrobbleResetItems(imdb_ids, tvdb_dicts=None, refresh=True, widgetRefresh=False):
	if control.player_class().isPlaying(): control.busy()
	success = False
	try:
		content_type = 'movie' if not tvdb_dicts else 'episode'
		if content_type == 'movie':
			total_items = len(imdb_ids)
			resume_info = traktsync.fetch_bookmarks(imdb='', ret_all=True, ret_type='movies')
			for imdb in imdb_ids:
				try:
					resume_info_index = [resume_info.index(i) for i in resume_info if i['imdb'] == imdb][0]
					resume_dict = resume_info[resume_info_index]
					resume_id = resume_dict['resume_id']
					headers['Authorization'] = 'Bearer %s' % trakt_token
					success = session.delete('https://api.trakt.tv/sync/playback/%s' % resume_id, headers=headers).status_code == 204
					if not success: raise Exception()
					items = [{'type': 'movie', 'movie': {'ids': {'imdb': imdb}}}]
					timestamp = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.000Z")
					items[0].update({'paused_at': timestamp})
					traktsync.delete_bookmark(items)
					log_utils.log('Successfuly Removed Trakt Playback Progress: movie title=%s  with resume_id=%s' % (resume_dict['title'], str(resume_id)), __name__, level=log_utils.LOGDEBUG)
					control.sleep(1000)
				except: log_utils.log('Failed to Remove Trakt Playback Progress: movie title=%s  with resume_id=%s' % (resume_dict['title'], str(resume_id)), __name__, level=log_utils.LOGDEBUG)
		else:
			total_items = len(tvdb_dicts)
			resume_info = traktsync.fetch_bookmarks(imdb='', ret_all=True, ret_type='episodes')
			for dict in tvdb_dicts:
				try:
					imdb, tvdb = dict.get('imdb'), dict.get('tvdb')
					season, episode = dict.get('season'), dict.get('episode')
					resume_info_index = [resume_info.index(i) for i in resume_info if i['tvdb'] == tvdb and i['season'] == int(season) and i['episode'] == int(episode)][0]
					resume_dict = resume_info[resume_info_index]
					label_string = resume_dict['tvshowtitle'] + ' - ' + 'S%02dE%02d' % (int(season), int(episode))
					resume_id = resume_dict['resume_id']
					headers['Authorization'] = 'Bearer %s' % trakt_token
					success = session.delete('https://api.trakt.tv/sync/playback/%s' % resume_id, headers=headers).status_code == 204
					if not success: raise Exception()
					items = [{'type': 'episode', 'episode': {'season': season, 'number': episode}, 'show': {'ids': {'imdb': imdb, 'tvdb': tvdb}}}]
					timestamp = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.000Z")
					items[0].update({'paused_at': timestamp})
					traktsync.delete_bookmark(items)
					log_utils.log('Successfuly Removed Trakt Playback Progress:  tvshowtitle=%s  with resume_id=%s' % (label_string, str(resume_id)), __name__, level=log_utils.LOGDEBUG)
					control.sleep(1000)
				except: log_utils.log('Failed to Remove Trakt Playback Progress:  tvshowtitle=%s  with resume_id=%s' % (label_string, str(resume_id)), __name__, level=log_utils.LOGDEBUG)
		control.hide()
		if success:
			if refresh: control.refresh()
			if widgetRefresh: control.trigger_widget_refresh() # skinshortcuts handles the widget_refresh when plyback ends, but not a manual clear from Trakt Manager
			control.notification(title='Trakt Playback Progress Manager', message='Successfuly Removed %s Item%s' % (total_items, 's' if total_items >1 else ''))
			return True
		else: return False
	except:
		log_utils.error()
		control.hide()
		return False


#############    SERVICE SYNC    ######################
def trakt_service_sync():
	monitor = control.monitor_class()
	while not monitor.abortRequested():
		control.sleep(5000) # wait 5sec in case of device wake from sleep
		try:
			internets = control.condVisibility('System.InternetState') #added for some systems have removed Internet State apparently.
			if internets == False:
				internets = control.condVisibility('System.HasNetwork')
				log_utils.log('[ plugin.video.infinity ] Trakt Service Sync HasNetwork: %s '% control.condVisibility('System.HasNetwork'), log_utils.LOGDEBUG)
		except:
			internets = None
			log_utils.error()
		if internets and getTraktCredentialsInfo(): # run service in case user auth's trakt later
			activities = getTraktAsJson('/sync/last_activities', silent=True)
			if not activities : break
			if getSetting('bookmarks') == 'true' and getSetting('resume.source') == '1':
				sync_playbackProgress(activities)
			sync_hidden_progress(activities)  # must run before sync_watchedProgress so display-time filtering is current
			sync_watchedProgress(activities)
			if getSetting('indicators.alt') == '1':
				sync_watched(activities) # writes to traktsync.db as of 1-19-2022
			sync_user_lists(activities)
			sync_liked_lists(activities)
			sync_collection(activities)
			sync_watch_list(activities)
			sync_popular_lists()
			sync_trending_lists()
		if monitor.waitForAbort(60*service_syncInterval): break

def delete_traktSyncDatabase():
	import os
	if not control.yesnoDialog('Are you sure you want to delete the Trakt sync database? This will clear all cached Trakt data and force a full re-sync.', '', ''): return
	try:
		if os.path.exists(control.traktSyncFile):
			os.remove(control.traktSyncFile)
			control.notification(message='Trakt sync database deleted. Run Force Sync to rebuild.')
			log_utils.log('TRAKT: traktsync database deleted by user.', level=log_utils.LOGINFO)
		else:
			control.notification(message='Trakt sync database not found.')
	except Exception as e:
		control.notification(message='Failed to delete Trakt sync database: %s' % str(e))
		log_utils.log('TRAKT: delete_traktSyncDatabase failed: %s' % str(e), level=log_utils.LOGWARNING)

def force_traktSync():
	if not control.yesnoDialog(getLS(32056), '', ''): return
	control.busy()

	# Run lightweight syncs in parallel (no internal threading, safe on low-end devices)
	lightweight = [
		Thread(target=sync_playbackProgress, kwargs={'forced': True}),
		Thread(target=sync_hidden_progress, kwargs={'forced': True}),
		Thread(target=sync_collection, kwargs={'forced': True}),
		Thread(target=sync_watch_list, kwargs={'forced': True}),
		Thread(target=sync_user_lists, kwargs={'forced': True}),
	]
	[t.start() for t in lightweight]
	[t.join() for t in lightweight]
	# Thread-spawning functions run sequentially to cap concurrency on low-end devices
	sync_user_lists(forced=True)
	sync_liked_lists(forced=True)
	sync_popular_lists()  # use TTL-based check — these are public lists, not user-specific
	sync_trending_lists() # use TTL-based check — these are public lists, not user-specific
	sync_watched(forced=True)
	control.hide()
	control.trigger_widget_refresh() # refresh after watched sync, progress will refresh again when done
	control.notification(message='Trakt Sync Complete - Progress List Updating...')
	Thread(target=sync_watchedProgress, kwargs={'forced': True, 'trigger_refresh': True}).start()
	#Thread(target=sync_tvshowProgress, kwargs={'forced': True}).start()

def sync_playbackProgress(activities=None, forced=False):
	try:
		link = '/sync/playback/?extended=full'
		if forced:
			items = get_all_pages(link, silent=True)
			if items: traktsync.insert_bookmarks(items)
			log_utils.log('Forced - Trakt Playback Progress Sync Complete', __name__, log_utils.LOGDEBUG)
		else:
			db_last_paused = traktsync.last_sync('last_paused_at')
			activity = getPausedActivity(activities)
			if activity - db_last_paused >= 2700: # do not sync unless 45 min difference or more
				log_utils.log('Trakt Sync Playback db_last_paused: %s  activity: %s difference: %s' % (db_last_paused, activity,(activity - db_last_paused)),log_utils.LOGDEBUG)
				items = get_all_pages(link, silent=True)
				if items: traktsync.insert_bookmarks(items)
	except: log_utils.error()

def sync_watchedProgress(activities=None, forced=False, trigger_refresh=True):
	try:
		from resources.lib.menus import episodes
		trakt_user = getSetting('trakt.user.name').strip()
		lang = control.apiLanguage()['tmdb']
		direct = getSetting('trakt.directProgress.scrape') == 'true'
		url = 'https://api.trakt.tv/users/me/watched/shows'
		progressActivity = getProgressActivity(activities)
		local_listCache = cache.timeout(episodes.Episodes().trakt_progress_list, url, trakt_user, lang, direct)
		if forced or (progressActivity > local_listCache):
			cache.get(episodes.Episodes().trakt_progress_list, 0, url, trakt_user, lang, direct)
			if forced: log_utils.log('Forced - Trakt Progress List Sync Complete', __name__, log_utils.LOGDEBUG)
			else: log_utils.log('Trakt Progress List Sync Update...(local db latest "list_cached_at" = %s, trakt api latest "progress_activity" = %s)' % (str(local_listCache), str(progressActivity)), __name__, log_utils.LOGDEBUG)
			if trigger_refresh: control.trigger_widget_refresh()
	except: log_utils.error()

def sync_tvshowProgress(activities=None, forced=False):
	try:
		from resources.lib.menus import tvshows
		progressActivity = getProgressActivity(activities)
		local_listCache = cache.timeout(tvshows.TVShows().trakt_tvshow_progress, '')
		if forced or (progressActivity > local_listCache) or (int(time.time()) - local_listCache > 21600):
			cache.get(tvshows.TVShows().trakt_tvshow_progress, 0, '')
			if forced: log_utils.log('Forced - Trakt TVShow Progress Sync Complete', __name__, log_utils.LOGDEBUG)
			else:
				log_utils.log('Trakt TVShow Progress Sync Update...(local db latest "list_cached_at" = %s, trakt api latest "progress_activity" = %s)' % \
									(str(local_listCache), str(progressActivity)), __name__, log_utils.LOGDEBUG)
	except: log_utils.error()

def sync_watched(activities=None, forced=False): # writes to traktsync.db as of 1-19-2022
	try:
		FULL_SYNC_INTERVAL = 86400 # force a full resync every 24h to catch removes/resets
		if forced:
			monitor = control.monitor_class()
			cachesyncMovies()
			#log_utils.log('Forced - Trakt Watched Movie Sync Complete', __name__, log_utils.LOGDEBUG)
			cachesyncTVShows()
			traktsync.insert_syncSeasons_at()
			log_utils.log('Forced - Trakt Watched Sync Complete (movies + shows)', __name__, log_utils.LOGINFO)
			control.sleep(5000) # avoid memory pressure on embedded hardware after heavy initial sync
			if not monitor.abortRequested():
				service_syncSeasons()
		else:
			moviesWatchedActivity = getMoviesWatchedActivity(activities)
			db_movies_last_watched = timeoutsyncMovies()
			if moviesWatchedActivity - db_movies_last_watched >= 30: # do not sync unless 30secs more to allow for variation between trakt post and local db update.
				use_delta = db_movies_last_watched > 0 and (int(time.time()) - db_movies_last_watched) < FULL_SYNC_INTERVAL
				log_utils.log('Trakt Watched Movie Sync Update...(local=%s, remote=%s, path=%s)' % \
								(str(db_movies_last_watched), str(moviesWatchedActivity), 'delta' if use_delta else 'full'), __name__, log_utils.LOGDEBUG)
				if use_delta:
					new_ids = syncMovies_delta(db_movies_last_watched)
					if new_ids and traktsync.merge_watched_movies(new_ids):
						log_utils.log('TRAKT: movies delta merged %d new item(s)' % len(new_ids), __name__, log_utils.LOGDEBUG)
					else:
						log_utils.log('TRAKT: movies delta fallback to full sync (empty=%s)' % str(new_ids == []), __name__, log_utils.LOGDEBUG)
						cachesyncMovies()
				else:
					cachesyncMovies()
			episodesWatchedActivity = getEpisodesWatchedActivity(activities)
			db_last_syncTVShows = timeoutsyncTVShows()
			db_last_syncSeasons = traktsync.last_sync('last_syncSeasons_at')
			if any(episodesWatchedActivity > value for value in (db_last_syncTVShows, db_last_syncSeasons)):
				use_delta = db_last_syncTVShows > 0 and (int(time.time()) - db_last_syncTVShows) < FULL_SYNC_INTERVAL
				log_utils.log('Trakt Watched Shows Sync Update...(local=%s, remote=%s, path=%s)' % \
								(str(min(db_last_syncTVShows, db_last_syncSeasons)), str(episodesWatchedActivity), 'delta' if use_delta else 'full'), __name__, log_utils.LOGDEBUG)
				if use_delta:
					updated = syncTVShows_delta(db_last_syncTVShows, activity_at=episodesWatchedActivity)
					if updated and traktsync.merge_watched_shows(updated):
						log_utils.log('TRAKT: shows delta merged %d show(s)' % len(updated), __name__, log_utils.LOGDEBUG)
					else:
						log_utils.log('TRAKT: shows delta fallback to full sync (empty=%s, gap=%s)' % (str(updated == []), str(updated is None)), __name__, log_utils.LOGDEBUG)
						cachesyncTVShows()
				else:
					cachesyncTVShows()
				if time.time() - db_last_syncSeasons > 14400: # only run season sync every 4 hours in background to avoid memory pressure
					control.sleep(5000)
					service_syncSeasons()
				traktsync.insert_syncSeasons_at()
	except: log_utils.error()

def sync_user_lists(activities=None, forced=False):
	try:
		link = '/users/me/lists'
		list_link = '/users/me/lists/%s/items/%s?page=1&limit=1'
		if forced:
			items = get_all_pages(link, silent=True)
			if not items: return
			for i in items:
				i['content_type'] = ''
				trakt_id = i['ids']['trakt']
				list_items = getTraktAsJson(list_link % (trakt_id, 'movies'), silent=True)
				if not list_items or list_items == '[]': pass
				else: i['content_type'] = 'movies'
				list_items = getTraktAsJson(list_link % (trakt_id, 'shows'), silent=True)
				if not list_items or list_items == '[]': pass
				else: i['content_type'] = 'mixed' if i['content_type'] == 'movies' else 'shows'
				i['list_items'] = list_items
				#control.sleep(200)
			traktsync.insert_user_lists(items)
			log_utils.log('Forced - Trakt User Lists Sync Complete', __name__, log_utils.LOGDEBUG)
		else:
			db_last_lists_updatedat = traktsync.last_sync('last_lists_updatedat')
			user_listActivity = getUserListActivity(activities)
			if user_listActivity > db_last_lists_updatedat:
				log_utils.log('Trakt User Lists Sync Update...(local db latest "lists_updatedat" = %s, trakt api latest "lists_updatedat" = %s)' % \
									(str(db_last_lists_updatedat), str(user_listActivity)), __name__, log_utils.LOGDEBUG)
				clr_traktSync = {'bookmarks': False, 'hiddenProgress': False, 'liked_lists': False, 'movies_collection': False, 'movies_watchlist': False,
							'public_lists': False, 'shows_collection': False, 'shows_watchlist': False, 'user_lists': True, 'watched': False}
				traktsync.delete_tables(clr_traktSync)
				items = get_all_pages(link, silent=True)
				if not items: return
				for i in items:
					i['content_type'] = ''
					trakt_id = i['ids']['trakt']
					list_items = getTraktAsJson(list_link % (trakt_id, 'movies'), silent=True)
					if not list_items or list_items == '[]': pass
					else: i['content_type'] = 'movies'
					list_items = getTraktAsJson(list_link % (trakt_id, 'shows'), silent=True)
					if not list_items or list_items == '[]': pass
					else: i['content_type'] = 'mixed' if i['content_type'] == 'movies' else 'shows'
					i['list_items'] = list_items
					#control.sleep(200)
				traktsync.insert_user_lists(items)
	except: log_utils.error()

def sync_liked_lists(activities=None, forced=False):
	try:
		link = '/users/likes/lists'
		list_link = '/users/%s/lists/%s/items/%s?page=1&limit=1'
		db_last_liked = traktsync.last_sync('last_liked_at')
		listActivity = getListActivity(activities)
		if (listActivity > db_last_liked) or forced:
			if not forced: log_utils.log('Trakt Liked Lists Sync Update...(local db latest "liked_at" = %s, trakt api latest "liked_at" = %s)' % \
								(str(db_last_liked), str(listActivity)), __name__, log_utils.LOGDEBUG)
			clr_traktSync = {'bookmarks': False, 'hiddenProgress': False, 'liked_lists': True, 'movies_collection': False, 'movies_watchlist': False,
							'public_lists': False, 'shows_collection': False, 'shows_watchlist': False, 'user_lists': False, 'watched': False}
			traktsync.delete_tables(clr_traktSync)
			items = get_all_pages(link, silent=True)
			if not items: return
			thrd_items = []
			def items_list(i):
				list_item = i.get('list', {})
				if any(list_item.get('privacy', '') == value for value in ('private', 'friends')): return
				# list_owner = list_item.get('user',{}).get('username')
				list_owner_slug, trakt_id = list_item.get('user', {}).get('ids', {}).get('slug', ''), list_item.get('ids', {}).get('trakt', '')
				if list_item.get('user',{}).get('private') is True:
					log_utils.log(f'marked their list private: {list_item}\n has in Trakt(Liked Lists) and is now causing you errors. Skipping this list')
					unlike_list(list_owner_slug, list_owner_slug, trakt_id)
					return
				if not list_owner_slug: return
				i['list']['content_type'] = ''
				list_items = getTraktAsJson(list_link % (list_owner_slug, trakt_id, 'movies'), silent=True)
				if not list_items or list_items == '[]': pass
				else: i['list']['content_type'] = 'movies'
				list_items = getTraktAsJson(list_link % (list_owner_slug, trakt_id, 'shows'), silent=True)
				if not list_items or list_items == '[]':
					log_utils.log(f'Error sync_liked_lists list_item item: {i}', __name__, log_utils.LOGDEBUG)
					pass
				else: i['list']['content_type'] = 'mixed' if i['list']['content_type'] == 'movies' else 'shows'
				thrd_items.append(i)
			threads = []
			for i in items:
				threads.append(Thread(target=items_list, args=(i,)))
			_unlimited = getSetting('dev.batch.unlimited') == 'true'
			_bs = max(int(getSetting('dev.batch.size') or '10'), 1)
			_chunk = max(len(threads), 1) if _unlimited else _bs
			for i in range(0, len(threads), _chunk):
				batch = threads[i:i + _chunk]
				[t.start() for t in batch]
				[t.join() for t in batch]
			traktsync.insert_liked_lists(thrd_items)
			if forced: log_utils.log('Forced - Trakt Liked Lists Sync Complete', __name__, log_utils.LOGDEBUG)
	except: log_utils.error()

def sync_hidden_progress(activities=None, forced=False):
	try:
		link = '/users/hidden/dropped?type=show'
		if forced:
			items = get_all_pages(link, silent=True)
			if not items: return
			traktsync.insert_hidden_progress(items)
			log_utils.log('Forced - Trakt Dropped Progress Sync Complete', __name__, log_utils.LOGDEBUG)
		else:
			db_last_hidden = traktsync.last_sync('last_hiddenProgress_at')
			hiddenActivity = getHiddenActivity(activities)
			if hiddenActivity > db_last_hidden:
				log_utils.log('Trakt Dropped Progress Sync Update...(local db latest "hidden_at" = %s, trakt api latest "hidden_at" = %s)' % \
									(str(db_last_hidden), str(hiddenActivity)), __name__, log_utils.LOGDEBUG)
				items = get_all_pages(link, silent=True)
				if not items: return
				traktsync.insert_hidden_progress(items)
	except: log_utils.error()

def sync_collection(activities=None, forced=False):
	try:
		link = '/users/me/collection/%s?extended=full'
		if forced:
			items = get_all_pages(link % 'movies', silent=True)
			if items is not None: traktsync.insert_collection(items, 'movies_collection')
			items = get_all_pages(link % 'shows', silent=True)
			if items is not None: traktsync.insert_collection(items, 'shows_collection')
			#log_utils.log('Forced - Trakt Collection Sync Complete', __name__, log_utils.LOGDEBUG)
		else:
			log_utils.log('Trakt Collection Sync Not Forced', __name__, log_utils.LOGDEBUG)
			db_last_collected = traktsync.last_sync('last_collected_at')
			collectedActivity = getCollectedActivity(activities)
			if collectedActivity > db_last_collected:
				log_utils.log('Trakt Collection Sync Update...(local db latest "collected_at" = %s, trakt api latest "collected_at" = %s)' % \
									(str(db_last_collected), str(collectedActivity)), __name__, log_utils.LOGDEBUG)
				clr_traktSync = {'bookmarks': False, 'hiddenProgress': False, 'liked_lists': False, 'movies_collection': True, 'movies_watchlist': False,
							'public_lists': False, 'shows_collection': True, 'shows_watchlist': False, 'user_lists': False, 'watched': False}
				traktsync.delete_tables(clr_traktSync)
				# indicators = cachesyncMovies() # could maybe check watched status here to satisfy sort method
				items = get_all_pages(link % 'movies', silent=True)
				if items is not None: traktsync.insert_collection(items, 'movies_collection')
				# indicators = cachesyncTVShows() # could maybe check watched status here to satisfy sort method
				items = get_all_pages(link % 'shows', silent=True)
				if items is not None: traktsync.insert_collection(items, 'shows_collection')
	except: log_utils.error()

def sync_watch_list(activities=None, forced=False):
	try:
		link = '/users/me/watchlist/%s?extended=full'
		if forced:
			items = get_all_pages(link % 'movies', silent=True)
			traktsync.insert_watch_list(items, 'movies_watchlist')
			items = get_all_pages(link % 'shows', silent=True)
			traktsync.insert_watch_list(items, 'shows_watchlist')
			#log_utils.log('Forced - Trakt Watch List Sync Complete', __name__, log_utils.LOGDEBUG)
		else:
			db_last_watchList = traktsync.last_sync('last_watchlisted_at')
			watchListActivity = getWatchListedActivity(activities)
			log_utils.log('Trakt Watchlist Sync Check...(db time= %s, activity time= %s) will update if over 60: %s' % (str(db_last_watchList), str(watchListActivity), (watchListActivity - db_last_watchList)), __name__, log_utils.LOGDEBUG)
			if watchListActivity - db_last_watchList >= 60: # do not sync unless 1 min difference or more
				log_utils.log('Trakt Watch List Sync Update...(local db latest "watchlist_at" = %s, trakt api latest "watchlisted_at" = %s)' % \
									(str(db_last_watchList), str(watchListActivity)), __name__, log_utils.LOGINFO)
				clr_traktSync = {'bookmarks': False, 'hiddenProgress': False, 'liked_lists': False, 'movies_collection': False, 'movies_watchlist': True,
							'public_lists': False, 'shows_collection': False, 'shows_watchlist': True, 'user_lists': False, 'watched': False}
				traktsync.delete_tables(clr_traktSync)
				items = get_all_pages(link % 'movies', silent=True)
				if not items: return
				traktsync.insert_watch_list(items, 'movies_watchlist')
				items = get_all_pages(link % 'shows', silent=True)
				if not items: return
				traktsync.insert_watch_list(items, 'shows_watchlist')
	except: log_utils.error()

def sync_popular_lists(forced=False):
	try:
		from datetime import timedelta
		link = '/lists/popular?limit=300'
		list_link = '/users/%s/lists/%s/items/%s?page=1&limit=1'
		official_link = '/lists/%s/items/%s?page=1&limit=1'
		db_last_popularList = traktsync.last_sync('last_popularlist_at')
		cache_expiry = (datetime.utcnow() - timedelta(hours=168)).strftime("%Y-%m-%dT%H:%M:%S.000Z")
		cache_expiry = int(cleandate.iso_2_utc(cache_expiry))
		if (cache_expiry > db_last_popularList) or forced:
			if not forced: log_utils.log('Trakt Popular Lists Sync Update...(local db latest "popularlist_at" = %s, cache expiry = %s)' % \
								(str(db_last_popularList), str(cache_expiry)), __name__, log_utils.LOGDEBUG)
			items = getTraktAsJson(link, silent=True)
			if not items: return
			thrd_items = []
			def items_list(i):
				list_item = i.get('list', {})
				if any(list_item.get('privacy', '') == value for value in ('private', 'friends')): return
				list_owner_slug, trakt_id = list_item.get('user', {}).get('ids', {}).get('slug', ''), list_item.get('ids', {}).get('trakt', '')
				if list_item.get('user', {}).get('private') is True:
					log_utils.log(f'marked their list private: {list_item}\n has in Trakt(Liked Lists) and is now causing you errors. Skipping this list')
					unlike_list(list_owner_slug, list_owner_slug, trakt_id)
					return
				trakt_id = list_item.get('ids', {}).get('trakt', '')
				exists = traktsync.fetch_public_list(trakt_id)
				if exists:
					local = int(cleandate.iso_2_utc(exists.get('updated_at', '')))
					remote = int(cleandate.iso_2_utc(list_item.get('updated_at', '')))
					if remote > local: pass
					else: return
				i['list']['content_type'] = ''
				list_owner_slug = list_item.get('user', {}).get('ids', {}).get('slug', '')
				if not list_owner_slug: list_owner_slug = list_item.get('user',{}).get('username')
				if list_item.get('type') == 'official':
					list_items = getTraktAsJson(official_link % (trakt_id, 'movies'), silent=True)
					if list_items and list_items != '[]': i['list']['content_type'] = 'movies'
					list_items = getTraktAsJson(official_link % (trakt_id, 'shows'), silent=True)
					if list_items and list_items != '[]': i['list']['content_type'] = 'mixed' if i['list']['content_type'] == 'movies' else 'shows'
				if list_owner_slug:
					list_items = getTraktAsJson(list_link % (list_owner_slug, trakt_id, 'movies'), silent=True)
					if list_items and list_items != '[]': i['list']['content_type'] = 'movies'
					list_items = getTraktAsJson(list_link % (list_owner_slug, trakt_id, 'shows'), silent=True)
					if list_items and list_items != '[]': i['list']['content_type'] = 'mixed' if i['list']['content_type'] == 'movies' else 'shows'
				if not i['list']['content_type']: return
				thrd_items.append(i)
			threads = []
			for i in items:
				threads.append(Thread(target=items_list, args=(i,)))
			_unlimited = getSetting('dev.batch.unlimited') == 'true'
			_bs = max(int(getSetting('dev.batch.size') or '10'), 1)
			_chunk = max(len(threads), 1) if _unlimited else _bs
			for i in range(0, len(threads), _chunk):
				batch = threads[i:i + _chunk]
				[t.start() for t in batch]
				[t.join() for t in batch]
			traktsync.insert_public_lists(thrd_items, service_type='last_popularlist_at', new_sync=False)
			if forced: log_utils.log('Forced - Trakt Popular Lists Sync Complete', __name__, log_utils.LOGDEBUG)
	except: log_utils.error()

def sync_trending_lists(forced=False):
	try:
		from datetime import timedelta
		link = '/lists/trending?limit=300'
		list_link = '/users/%s/lists/%s/items/%s?page=1&limit=1'
		official_link = '/lists/%s/items/%s?page=1&limit=1'

		db_last_trendingList = traktsync.last_sync('last_trendinglist_at')
		cache_expiry = (datetime.utcnow() - timedelta(hours=24)).strftime("%Y-%m-%dT%H:%M:%S.000Z")
		cache_expiry = int(cleandate.iso_2_utc(cache_expiry))
		if (cache_expiry > db_last_trendingList) or forced:
			if not forced: log_utils.log('Trakt Trending Lists Sync Update...(local db latest "trendinglist_at" = %s, cache expiry = %s)' % \
								(str(db_last_trendingList), str(cache_expiry)), __name__, log_utils.LOGDEBUG)
			items = getTraktAsJson(link, silent=True)
			if not items: return
			thrd_items = []
			def items_list(i):
				list_item = i.get('list', {})
				if any(list_item.get('privacy', '') == value for value in ('private', 'friends')): return
				if list_item.get('user',{}).get('private') is True:
					log_utils.log('(%s) has marked their list private in Trakt(Trending Lists) and is now causing you errors. Skipping this list' % list_item.get('user',{}).get('username'))
					return
				trakt_id = list_item.get('ids', {}).get('trakt', '')
				exists = traktsync.fetch_public_list(trakt_id)
				if exists:
					local = int(cleandate.iso_2_utc(exists.get('updated_at', '')))
					remote = int(cleandate.iso_2_utc(list_item.get('updated_at', '')))
					if remote > local: pass
					else: return
				i['list']['content_type'] = ''
				list_owner_slug = list_item.get('user', {}).get('ids', {}).get('slug', '')
				if not list_owner_slug: list_owner_slug = list_item.get('user', {}).get('username')
				if list_item.get('type') == 'official':
					list_items = getTraktAsJson(official_link % (trakt_id, 'movies'), silent=True)
					if list_items and list_items != '[]': i['list']['content_type'] = 'movies'
					list_items = getTraktAsJson(official_link % (trakt_id, 'shows'), silent=True)
					if list_items and list_items != '[]': i['list']['content_type'] = 'mixed' if i['list']['content_type'] == 'movies' else 'shows'
				if list_owner_slug:
					list_items = getTraktAsJson(list_link % (list_owner_slug, trakt_id, 'movies'), silent=True)
					if list_items and list_items != '[]': i['list']['content_type'] = 'movies'
					list_items = getTraktAsJson(list_link % (list_owner_slug, trakt_id, 'shows'), silent=True)
					if list_items and list_items != '[]': i['list']['content_type'] = 'mixed' if i['list']['content_type'] == 'movies' else 'shows'
				if not i['list']['content_type']: return
				thrd_items.append(i)
			threads = []
			for i in items:
				threads.append(Thread(target=items_list, args=(i,)))
			_unlimited = getSetting('dev.batch.unlimited') == 'true'
			_bs = max(int(getSetting('dev.batch.size') or '10'), 1)
			_chunk = max(len(threads), 1) if _unlimited else _bs
			for i in range(0, len(threads), _chunk):
				batch = threads[i:i + _chunk]
				[t.start() for t in batch]
				[t.join() for t in batch]
			traktsync.insert_public_lists(thrd_items, service_type='last_trendinglist_at', new_sync=False)
			if forced: log_utils.log('Forced - Trakt Trending Lists Sync Complete', __name__, log_utils.LOGDEBUG)
	except: log_utils.error()

def traktClientID():
	traktId = '87e3f055fc4d8fcfd96e61a47463327ca877c51e8597b448e132611c5a677b13'
	if (getSetting('trakt.clientid') != '' and getSetting('trakt.clientid') is not None) and getSetting('traktuserkey.customenabled') == 'true':
		traktId = getSetting('trakt.clientid')
	return traktId
def traktClientSecret():
	traktSecret = '4a1957a52d5feb98fafde53193e51f692fa9bdcd0cc13cf44a5e39975539edf0'
	if (getSetting('trakt.clientsecret') != '' and getSetting('trakt.clientsecret') is not None) and getSetting('traktuserkey.customenabled') == 'true':
		traktSecret = getSetting('trakt.clientsecret')
	return traktSecret

def sync_all_trakt():
	if getTraktCredentialsInfo():
		activities = getTraktAsJson('/sync/last_activities', silent=True)
		if activities:
			if getSetting('bookmarks') == 'true' and getSetting('resume.source') == '1':
				sync_playbackProgress(activities)
			sync_watchedProgress(activities)
			if getSetting('indicators.alt') == '1':
				sync_watched(activities) # writes to traktsync.db as of 1-19-2022
			sync_user_lists(activities)
			sync_liked_lists(activities)
			sync_hidden_progress(activities)
			sync_collection(activities)
			sync_watch_list(activities)
			sync_popular_lists()
			sync_trending_lists()
