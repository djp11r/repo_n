# -*- coding: utf-8 -*-
from resources.lib.modules.service import main

main()