# -*- coding: utf-8 -*-
"""
	Infinity Add-on
"""

from sys import argv
from urllib.parse import parse_qsl
from resources.lib.modules import router

if __name__ == '__main__':

	from resources.lib.modules import log_utils
	# log_utils.log('argv[2]=%s' % argv[2], __name__)
	try:
		url = dict(parse_qsl(argv[2].replace('?', '')))
	except:
		log_utils.error()
		url = {}
	router.router(url)