# -*- coding: utf-8 -*-
"""
	Umbrella Addon
"""

import re
import requests
from resources.lib.modules import control
from resources.lib.modules import log_utils
import xbmc


base_url = 'https://api.opensubtitles.com/api/v1'
api_key = 'cQBWQwPugvGVDrpdU9MDRlvdfcu4WNTx'
version = control.getUmbrellaVersion()


class Opensubs():
	def __init__(self):
		self.username = control.setting('opensubsusername', 'GKobu')
		self.password = control.setting('opensubspassword', 'GKoBu2017')
		self.jwt_token = control.setting('opensubstoken')
		self.headers = {
			'Content-Type': 'application/json',
			'Api-Key': api_key,
			'User-Agent': 'Umbrella v'+version}
		self.headers1 = {'User-Agent': 'infinite v0.1'}
		self.highlight_color = control.setting('highlight.color')

	def auth(self):
		url = base_url + '/login'
		if not self.username or not self.password: return False
		data = {
			"username": self.username,
			"password": self.password,
		}
		if self.jwt_token:
			url = base_url + '/infos/user'
			headers2 = {
			'Content-Type': 'application/json',
			'Api-Key': api_key,
			'Authorization': self.jwt_token,
			'User-Agent': 'Umbrella v'+version
			}
			response = requests.get(url,headers=headers2)
			if response.status_code == 200:
				return True
			else:
				url = base_url + '/login'
				response2 = requests.post(url, headers=self.headers, json=data)
				if response2.status_code == 200:
					response2 = response2.json()
					control.setSetting('opensubstoken', response2.get('token'))
					return True
				else:
					return False

		else:
			response = requests.post(url, headers=self.headers, json=data)
			response = response.json()
			control.setSetting('opensubstoken', response.get('token'))
			return True

	def getSubs(self, title, imdb, year, season=None, episode=None):
		try:
			language = xbmc.convertLanguage(control.setting('subtitles.lang.1'), xbmc.ISO_639_1)
			if season:
				url = base_url + '/subtitles?imdb_id=%s&season_number=%s&episode_number=%s&languages=%s' % (imdb, season, episode,language)
			else:
				url = base_url + '/subtitles?imdb_id=%s&year=%s&languages=%s' % (imdb, year, language)
			headers = {
				'Content-Type': 'application/json',
				'Api-Key': api_key,
				'Authorization': self.jwt_token,
				'User-Agent': 'Umbrella v'+version
				}
			response = requests.get(url,headers=headers)
			response = response.json()
			response = response['data']
			results = []
			from resources.lib.modules import log_utils
			log_utils.log('OpenSubs Searching: Imdb:%s Season: %s Episode: %s Language: %s.' % (imdb, season, episode,language), level=log_utils.LOGDEBUG)
			for count, x in enumerate(response):
				try:
					fileName = response[count]['attributes'].get('files')[0].get('file_name')
					fileID = response[count]['attributes'].get('files')[0].get('file_id')
					results.append({'fileName': fileName, 'fileID': fileID})
				except:
					from resources.lib.modules import log_utils
					log_utils.error()
			return results
		except:
			results = []
			return results

	def downloadSubs(self, fileID, fileName):
		try:
			url = base_url + '/download'
			headers = {
				'Content-Type': 'application/json',
				'Api-Key': api_key,
				'Authorization': self.jwt_token,
				'User-Agent': 'Umbrella v'+version
				}
			data = {
				"file_id": fileID,
			}
			response = requests.post(url, headers=headers, json=data)
			response = response.json()
			link = response.get('link')
			from resources.lib.modules import log_utils
			log_utils.log('OpenSubs Download Link: %s Filename: %s.' % (link, fileName), level=log_utils.LOGDEBUG)
			return link, fileName
		except:
			from resources.lib.modules import log_utils
			log_utils.error()
			return None

	def getAccountStatus(self):
		try:
			url = base_url + '/login'
			if not self.username or not self.password: return control.okDialog(title=40503, message='Please enter username and password.')
			data = {
				"username": self.username,
				"password": self.password,
			}
			headers = {
			'Content-Type': 'application/json',
			'Api-Key': api_key,
			'User-Agent': 'Umbrella v'+version}
			response = requests.post(url,headers=headers, json=data)
			response = response.json()
			responseUser = response.get('user')
			responseToken = response.get('token')
			username = self.username
			a_downloads = responseUser.get('allowed_downloads')
			control.setSetting('opensubstoken', responseToken)
			control.openSettings('15.0', 'plugin.video.infinity')
			return control.okDialog(title=40503, message=control.getLangString(40508) % (username, a_downloads))
		except:
			from resources.lib.modules import log_utils
			log_utils.error()
			return control.okDialog(title=40503, message='Error checking opensubs. Please check use your username and not your email to authenticate and password. Press Ok to save and try checking again.')

	def revokeAccess(self):
		try:
			control.homeWindow.setProperty('infinity.updateSettings', 'false')
			control.setSetting('opensubsusername','')
			control.setSetting('opensubspassword','')
			control.homeWindow.setProperty('infinity.updateSettings', 'true')
			control.setSetting('opensubstoken','')
			self.jwt_token = ''
			control.openSettings('15.0', 'plugin.video.infinity')
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def search(self, query, imdb_id, language, season=None, episode=None):
		cache_name = f'opensubtitles_{imdb_id}_{language}'
		if season: cache_name += f'_{season}_{episode}'
		if cache := main_cache.get(cache_name): return cache
		url = f'https://rest.opensubtitles.org/search/imdbid-{imdb_id}/query-{quote(query)}{f"/season-{season}/episode-{episode}" if season else ""}/sublanguageid-{language}'
		response = self._get(url, retry=True)
		if not response: return logger(f'Error OpenSubtitlesAPI search url: {url}')
		response = json.loads(response.text)
		main_cache.set(cache_name, response, 48)
		return response

	def download(self, url, filepath, temp_zip, temp_path, final_path):
		result = self._get(url, stream=True, retry=True)
		with open(temp_zip, 'wb') as f: shutil.copyfileobj(result.raw, f)
		with ZipFile(temp_zip, 'r') as zip_file: zip_file.extractall(filepath)
		delete_file(temp_zip)
		rename_file(temp_path, final_path)
		with open(final_path, 'r', encoding='utf-8', errors='ignore') as sub_contents:
			file = sub_contents.read()
		ifile = self.cleanup_subtitles(file)
		if ifile:
			with open(final_path, mode='w', encoding='utf-8', errors='ignore') as f:
				f.write(ifile)
		return final_path

	def _get(self, url, stream=False, retry=False):
		response = requests.get(url, headers=self.headers, stream=stream)
		if '200' in str(response): return response
		elif '429' in str(response) and retry:
			notification('OpenSubtitles Rate Limited. Retrying in 10 secs..', 3500)
			sleep(10000)
			return self._get(url, stream)
		else: return

	def cleanup_subtitles(self, sub_contents):
		__url_regex = r'[a-z0-9][a-z0-9-]{0,5}[a-z0-9]\.[a-z0-9]{2,20}\.[a-z]{2,5}'
		fist_last_regex = '(Support us and become|to remove all ads|Watch any video online|Free Browser extension)'
		__credit_part_regex = r'(sync|synced|fix|fixed|corrected|corrections)'
		__credit_regex = __credit_part_regex + r' ?&? ?' + __credit_part_regex + r'? by'
		all_lines = sub_contents.split('\n')
		cleaned_lines = []
		buffer = []
		garbage = False

		if all_lines[0].strip() != '': all_lines.insert(0, '')
		if all_lines[-1].strip() != '': all_lines.append('')

		for line in all_lines:
			line = line.strip()
			if garbage and line != '': continue
			garbage = False
			line_contains_ad = (re.search(fist_last_regex, line, re.IGNORECASE) or re.search(__url_regex, line, re.IGNORECASE) or re.search(__credit_regex, line, re.IGNORECASE))

			if line_contains_ad:
				if not re.match(r'^\{\d+\}\{\d+\}', line):
					logger(f'(detected ad) {line.encode("ascii", errors="ignore")}')
					garbage = True
					buffer = []
				continue

			if line == '':
				if len(buffer) > 0:
					buffer.insert(0, '')
					cleaned_lines.extend(buffer)
					buffer = []
				continue
			buffer.append(line)
		return '\n'.join(cleaned_lines)
