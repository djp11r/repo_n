# -*- coding: utf-8 -*-

import sys, time, datetime
from traceback import print_exc

import xbmc
from resources.lib.modules import control
from resources.lib.modules.control import monitor, homeWindow, sleep, setting as getSetting, setSetting, notification
from resources.lib.modules.log_utils import log, error
from threading import Thread
from resources.lib.database.cache import remove_expi_data


def testting():
    # test_window()
    # from resources.lib.modules.trakt import sync_user_lists
    # sync_user_lists(forced=True)
    from resources.lib.modules.player import Subtitles
    data = Subtitles().get('the cleaning lady', 2021, '', 4, 1)
    log(f'data: {data}')
    


def sub_test():
    from resources.lib.modules.opensubs import Opensubs
    # filter = Opensubs().getSubs('Lie to Me', 'tt1235099', '2009', 3, 10)
    # log(f'filter = {filter}')
    filter = [{'fileName': 'Lie to Me - S03E10 - Rebound', 'fileID': 3197845, 'ratio': 0.4864864864864865}, {'fileName': 'Lie.to.Me.S03E10.HDTV.XviD-LOL', 'fileID': 3195975, 'ratio': 0.358974358974359}, {'fileName': 'Lie to Me - 03x10 - Rebound.LOL.English.C.orig', 'fileID': 3197603, 'ratio': 0.32727272727272727}, {'fileName': 'lie.to.me.s03e10.dvdrip.xvid-reward.English', 'fileID': 3197362, 'ratio': 0.2692307692307692}, {'fileName': 'Lie.to.Me.S03E10.720p.WEB-DL.DD5.1.H.264-NFHD', 'fileID': 9982942, 'ratio': 0.25925925925925924}]
    # log(f'filter = {filter[0]["fileID"]}')
    downloadURL = Opensubs().downloadSubs(filter[0]['fileID'])
    log(f'downloadURL = {downloadURL}')
    downloadURL = 'https://www.opensubtitles.com/download/1E44E7244611FAB76269AC0BE2F8BDD5EA2CFC837CDDFE7B69E31CC102683EAB1212BFAECF5C4AA93D615D4F25E93DEA97D1754BD33BFE20F1B70B81F1D440C7B47B97BCBC4E247A768EF172D2D9A2FC9B140AD638386337A3B89F51CE5EB1E56FA7D82C707BAE36FDA12860C77BFC9B9785D13C160779BF27BA374909CCEEE144E094341D14A95E0804E10B0E84FAD6376E359304B92E5B89F44193CFCF149552E763D21E8978AD7FC02F4B749F757FD1A3B67759BDD09920083FF5141D077083DE70EEAE2A5B57922E888FF57A8EFAC88E35FD6E82736BD2313420AC7FA8BC5448C0E47EB01E9F255AC9F45EBD24B9367A9BAEF7DE411E6DF24DDB69BD0DFBBEA928EC7961B6955173E4B39A87AF22E0FB566E7740D65A2C161F49E4837DA7D7863CB4E28344BE/subfile/Lie%20to%20Me%20-%20S03E10%20-%20Rebound.srt'


def test_window(win='source_progress'):
    window = None
    use_timer = True
    meta = {'mediatype': 'tvshow', 'fanart': 'https://image.tmdb.org/t/p/w780/jqgO8AqwgQelXhmJn6cebWjjMcY.jpg', 'premiered': '1989-07-05', 'year': '1989', 'genre': 'Comedy', 'tmdb': '1400', 'in_production': False, 'last_air_date': '1998-05-14', 'last_episode_to_air': {'id': 63283, 'overview': 'Witnesses testify to the gang\'s (lack of) character as they go on trial for violating a "Good Samaritan Law."', 'name': 'The Finale (2)', 'vote_average': 7.0, 'vote_count': 3, 'air_date': '1998-05-14', 'episode_number': 24, 'episode_type': 'finale', 'production_code': '924', 'runtime': 23, 'season_number': 9, 'show_id': 1400, 'still_path': '/vQ2tMUhbtc9ii1tkNw48HbFGH24.jpg'}, 'tvshowtitle': 'Seinfeld', 'studio': 'NBC', 'total_episodes': 180, 'total_seasons': 9, 'origin_country': 'US', 'original_language': 'en', 'originaltitle': 'Seinfeld', 'plot': "A stand-up comedian and his three offbeat friends weather the pitfalls and payoffs of life in New York City in the '90s. It's a show about nothing.", 'poster': 'https://image.tmdb.org/t/p/w342/aCw8ONfyz3AhngVQa1E2Ss4KSUQ.jpg', 'tvshow_poster': 'https://image.tmdb.org/t/p/w342/aCw8ONfyz3AhngVQa1E2Ss4KSUQ.jpg', 'country_codes': ['US'], 'seasons': [{'air_date': '1990-06-28', 'episode_count': 289, 'id': 3638, 'name': 'Specials', 'overview': '', 'poster_path': '/rOseRl5P1sRPsF1Uaxfu8QyhWgG.jpg', 'season_number': 0, 'vote_average': 0.0}, {'air_date': '1989-07-05', 'episode_count': 5, 'id': 3629, 'name': 'Season 1', 'overview': '', 'poster_path': '/5tnnUOx3fp94UwHMl6tRdkYfEuG.jpg', 'season_number': 1, 'vote_average': 7.1}, {'air_date': '1991-01-23', 'episode_count': 12, 'id': 3630, 'name': 'Season 2', 'overview': '', 'poster_path': '/pnIzg5YwOFrfJnQ31z9T2wviPBF.jpg', 'season_number': 2, 'vote_average': 7.6}, {'air_date': '1991-09-18', 'episode_count': 23, 'id': 3631, 'name': 'Season 3', 'overview': '', 'poster_path': '/nkhwnuxdDrVFKKC6qUPs6G7bvbO.jpg', 'season_number': 3, 'vote_average': 7.6}, {'air_date': '1992-08-12', 'episode_count': 24, 'id': 3632, 'name': 'Season 4', 'overview': '', 'poster_path': '/wR2rnCJ4ErRsaHoMVqd9hi4UDMX.jpg', 'season_number': 4, 'vote_average': 7.8}, {'air_date': '1993-09-16', 'episode_count': 22, 'id': 3633, 'name': 'Season 5', 'overview': '', 'poster_path': '/xVACsCDOOfjkCk5tsNz2qgP6QWH.jpg', 'season_number': 5, 'vote_average': 7.9}, {'air_date': '1994-09-22', 'episode_count': 24, 'id': 3634, 'name': 'Season 6', 'overview': '', 'poster_path': '/lZ1mZVxPxXNCQ96DiueznMwrK5S.jpg', 'season_number': 6, 'vote_average': 7.8}, {'air_date': '1995-09-21', 'episode_count': 24, 'id': 3635, 'name': 'Season 7', 'overview': '', 'poster_path': '/xWOa5ooCisnvavvfOPWbgjxmaaL.jpg', 'season_number': 7, 'vote_average': 7.8}, {'air_date': '1996-09-19', 'episode_count': 22, 'id': 3636, 'name': 'Season 8', 'overview': '', 'poster_path': '/hcjHVDoFwbPS9oO7GdhU8vA8ONd.jpg', 'season_number': 8, 'vote_average': 7.9}, {'air_date': '1997-09-25', 'episode_count': 24, 'id': 3637, 'name': 'Season 9', 'overview': '', 'poster_path': '/otyE0qfPWaKlNgb56j5FQNYPsLb.jpg', 'season_number': 9, 'vote_average': 7.8}], 'status': 'Ended', 'counts': {'0': 289, '1': 5, '2': 12, '3': 23, '4': 24, '5': 22, '6': 24, '7': 24, '8': 22, '9': 24}, 'total_aired_episodes': 180, 'spoken_languages': [{'english_name': 'English', 'iso_639_1': 'en', 'name': 'English'}], 'tagline': 'A show about nothing.', 'type': 'Scripted', 'rating': 8.29, 'votes': 1852, 'castandart': [{'name': 'Jerry Seinfeld', 'role': 'Jerry Seinfeld', 'thumbnail': 'https://image.tmdb.org/t/p/w342/9OSptNQPVCUKZs1J3tqKcwtaB2v.jpg'}, {'name': 'Jason Alexander', 'role': 'George Costanza', 'thumbnail': 'https://image.tmdb.org/t/p/w342/qRezZ2yhM2bmBERt7jVcxo8RVSA.jpg'}, {'name': 'Michael Richards', 'role': 'Cosmo Kramer', 'thumbnail': 'https://image.tmdb.org/t/p/w342/bAYwmBdPJAiFkossWq56pEDmUh4.jpg'}, {'name': 'Julia Louis-Dreyfus', 'role': 'Elaine Benes', 'thumbnail': 'https://image.tmdb.org/t/p/w342/iEfHQNrVbVFesDPjdySom9nqsFg.jpg'}], 'mpaa': 'TV-PG', 'imdb': 'tt0098904', 'imdbnumber': 'tt0098904', 'tvdb': '79169', 'aliases': [], 'trailer': 'plugin://plugin.video.youtube/play/?video_id=hQXKyIG_NS4', 'extended': True, 'poster2': 'https://assets.fanart.tv/fanart/tv/79169/tvposter/seinfeld-538883f9d58ca.jpg', 'banner2': 'https://assets.fanart.tv/fanart/tv/79169/tvbanner/seinfeld-538883b240dd1.jpg', 'fanart2': 'https://assets.fanart.tv/fanart/tv/79169/showbackground/seinfeld-4fcd7c7c8618e.jpg', 'clearlogo': 'https://assets.fanart.tv/fanart/tv/79169/hdtvlogo/seinfeld-503ca4ba0e919.png', 'clearart': 'https://assets.fanart.tv/fanart/tv/79169/hdclearart/seinfeld-51e82fc3a169b.png', 'landscape': 'https://assets.fanart.tv/fanart/tv/79169/tvthumb/seinfeld-5ad12562aae98.jpg', 'season_thumbs': [{'id': '4861', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonthumb/Seinfeld.jpg', 'lang': 'en', 'likes': '1', 'season': '1'}, {'id': '4860', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonthumb/Seinfeld (2).jpg', 'lang': 'en', 'likes': '1', 'season': '2'}, {'id': '4859', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonthumb/Seinfeld (3).jpg', 'lang': 'en', 'likes': '1', 'season': '3'}, {'id': '4858', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonthumb/Seinfeld (4).jpg', 'lang': 'en', 'likes': '1', 'season': '4'}, {'id': '4857', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonthumb/Seinfeld (5).jpg', 'lang': 'en', 'likes': '1', 'season': '5'}, {'id': '4856', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonthumb/Seinfeld (6).jpg', 'lang': 'en', 'likes': '1', 'season': '6'}, {'id': '4855', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonthumb/Seinfeld (7).jpg', 'lang': 'en', 'likes': '1', 'season': '7'}, {'id': '4854', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonthumb/Seinfeld (8).jpg', 'lang': 'en', 'likes': '1', 'season': '8'}, {'id': '4853', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonthumb/Seinfeld (9).jpg', 'lang': 'en', 'likes': '1', 'season': '9'}, {'id': '67289', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonthumb/seinfeld-5820676fd650e.jpg', 'lang': 'en', 'likes': '1', 'season': '4'}, {'id': '67286', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonthumb/seinfeld-5820673a16c96.jpg', 'lang': 'en', 'likes': '1', 'season': '1'}, {'id': '67287', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonthumb/seinfeld-5820674c6f2d5.jpg', 'lang': 'en', 'likes': '1', 'season': '2'}, {'id': '67288', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonthumb/seinfeld-5820675e07b65.jpg', 'lang': 'en', 'likes': '1', 'season': '3'}, {'id': '67295', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonthumb/seinfeld-582067d11a03d.jpg', 'lang': 'en', 'likes': '1', 'season': '0'}, {'id': '67290', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonthumb/seinfeld-5820678024c8e.jpg', 'lang': 'en', 'likes': '1', 'season': '5'}, {'id': '67291', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonthumb/seinfeld-5820678f94527.jpg', 'lang': 'en', 'likes': '1', 'season': '6'}, {'id': '67292', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonthumb/seinfeld-5820679fc9f59.jpg', 'lang': 'en', 'likes': '1', 'season': '7'}, {'id': '67293', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonthumb/seinfeld-582067b01c2c1.jpg', 'lang': 'en', 'likes': '1', 'season': '8'}, {'id': '67294', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonthumb/seinfeld-582067c083713.jpg', 'lang': 'en', 'likes': '1', 'season': '9'}], 'season_posters': [{'id': '41153', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonposter/seinfeld-5390d8db4c036.jpg', 'lang': 'en', 'likes': '3', 'season': '2'}, {'id': '41152', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonposter/seinfeld-5390d8cd31ccb.jpg', 'lang': 'en', 'likes': '3', 'season': '1'}, {'id': '101504', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonposter/seinfeld-5d71e65c58357.jpg', 'lang': 'en', 'likes': '3', 'season': '0'}, {'id': '41154', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonposter/seinfeld-5390d8e78c2ee.jpg', 'lang': 'en', 'likes': '3', 'season': '3'}, {'id': '41155', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonposter/seinfeld-5390d8f55b30d.jpg', 'lang': 'en', 'likes': '3', 'season': '4'}, {'id': '41156', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonposter/seinfeld-5390d9023e21f.jpg', 'lang': 'en', 'likes': '3', 'season': '5'}, {'id': '41157', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonposter/seinfeld-5390d90e2f051.jpg', 'lang': 'en', 'likes': '3', 'season': '6'}, {'id': '41158', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonposter/seinfeld-5390d91d358e0.jpg', 'lang': 'en', 'likes': '3', 'season': '7'}, {'id': '41159', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonposter/seinfeld-5390d92d09bc6.jpg', 'lang': 'en', 'likes': '3', 'season': '8'}, {'id': '41160', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonposter/seinfeld-5390d93e0d6cf.jpg', 'lang': 'en', 'likes': '3', 'season': '9'}, {'id': '41161', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonposter/seinfeld-5390d95f984ed.jpg', 'lang': 'en', 'likes': '3', 'season': '0'}, {'id': '100993', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonposter/seinfeld-5d4ed360d2d0a.jpg', 'lang': 'en', 'likes': '3', 'season': '9'}, {'id': '100985', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonposter/seinfeld-5d4ed2b52f26b.jpg', 'lang': 'en', 'likes': '3', 'season': '1'}, {'id': '100986', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonposter/seinfeld-5d4ed3076d3f0.jpg', 'lang': 'en', 'likes': '3', 'season': '2'}, {'id': '100987', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonposter/seinfeld-5d4ed312bb5c4.jpg', 'lang': 'en', 'likes': '3', 'season': '3'}, {'id': '100988', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonposter/seinfeld-5d4ed325aa2f5.jpg', 'lang': 'en', 'likes': '3', 'season': '4'}, {'id': '100989', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonposter/seinfeld-5d4ed333e9627.jpg', 'lang': 'en', 'likes': '3', 'season': '5'}, {'id': '100990', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonposter/seinfeld-5d4ed33f41dca.jpg', 'lang': 'en', 'likes': '3', 'season': '6'}, {'id': '100991', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonposter/seinfeld-5d4ed34a43687.jpg', 'lang': 'en', 'likes': '3', 'season': '7'}, {'id': '100992', 'url': 'https://assets.fanart.tv/fanart/tv/79169/seasonposter/seinfeld-5d4ed355b6db4.jpg', 'lang': 'en', 'likes': '3', 'season': '8'}]}
    title = meta.get('title')
    if win == 'nextep_win': # windows.next_episode <<<<<<<<<
        from resources.lib.windows.playnext import PlayNextXML
        from resources.lib.windows.playnext_stillwatching import StillWatchingXML
        try:
            window = PlayNextXML('playnext.xml', control.addonPath(control.addonId()), meta=meta, test=True)
            # window = StillWatchingXML('auraplaynext_stillwatching2.xml', control.addonPath(control.addonId()), meta=meta, test=True)
            # window = StillWatchingXML('playnext_stillwatching.xml', control.addonPath(control.addonId()), meta=meta, test=True)
            # use_timer = False
        except: error()
    elif win == 'source_progress': # windows.WindowProgress <<<<<<<<<
        from resources.lib.windows.source_progress import WindowProgress
        try: window = WindowProgress('source_progress.xml', control.addonPath(control.addonId()), title=title, meta=meta)
        except: error()
    if window:
        try: window.run()
        except: error()
        start_time = time.time()
        timeout = 20.01
        sleep_time = 10
        end_time = start_time + timeout
        try:
            homeWindow.setProperty('infinity.window_keep_alive', 'true')
            for i in range(1, 100, 10):
                log(f'end_time: {end_time}')
                try: progress_bar = window.getControlProgress(3014)
                except: progress_bar = None
                current_time = time.time()
                elapsed_time = current_time - start_time
                percent = int((elapsed_time / float(timeout)) * 100)
                log(f'current_time: {current_time} start_time: {start_time}\n elapsed_time >= timeout: {elapsed_time* 100 >= timeout} percent: {percent}')
                if win in ('source_progress', 'progress_resolve'): window.update(int(i), f'Testings elapsed_time: {elapsed_time}')
                elif win == 'nextep_win': window.background_tasks()
                else: window.update(int(i), f'Testings elapsed_time: {elapsed_time}')
                log(f'elapsed_time: {elapsed_time} progress_bar: {repr(progress_bar)}')
                if progress_bar: progress_bar.setPercent(int(elapsed_time))
                sleep(10)
                if percent >= 100: break; window.close()
                if elapsed_time * 100 >= timeout: break; window.close()
                if monitor.abortRequested(): break; window.close()
        except: log(f'error: {print_exc()}')
        log(f'final end_time: {end_time}')
        homeWindow.clearProperty('infinity.window_keep_alive')
        try: del window
        except: error()
