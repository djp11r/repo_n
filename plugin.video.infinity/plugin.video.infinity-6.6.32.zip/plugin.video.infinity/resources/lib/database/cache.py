# -*- coding: utf-8 -*-
"""
	Umbrella Add-on
"""

from ast import literal_eval
from hashlib import md5
from re import sub as re_sub
from sqlite3 import dbapi2 as db
from time import time
from resources.lib.modules import control
import sqlite3
import xbmc
import xbmcvfs
import os
import fnmatch


def get_coalesced(function, duration, *args):
	"""Share overlapping progress rebuilds across Kodi Python invocations.

	The coordination database is separate from the metadata cache: no metadata
	write lock is held while fetching remote data. Only overlapping callers use
	its result, so normal cache expiration/invalidation still applies.
	"""
	started = time()
	key = _hash_function(function, args)
	if not control.existsPath(control.dataPath): control.makeFile(control.dataPath)
	path = control.cacheFile + '.build-' + _generate_md5(key)
	con = db.connect(path, timeout=0.25)
	try:
		while True:
			try:
				con.execute('BEGIN IMMEDIATE')
				break
			except db.OperationalError as exc:
				if 'locked' not in str(exc).lower() and 'busy' not in str(exc).lower(): raise
				if control.monitor.waitForAbort(0.1): return None
		con.execute('CREATE TABLE IF NOT EXISTS result (id INTEGER PRIMARY KEY, completed REAL, value TEXT)')
		row = con.execute('SELECT completed, value FROM result WHERE id=1').fetchone()
		if row and row[0] >= started:
			control.log_refresh_diagnostic('mdb-build-shared-result')
			return literal_eval(row[1])
		result = get(function, duration, *args)
		if result is not None:
			con.execute('INSERT OR REPLACE INTO result VALUES (1, ?, ?)', (time(), repr(result)))
		con.commit()
		return result
	finally:
		con.close()


def get(function, duration, *args):
	"""
	:param function: Function to be executed
	:param duration: Duration of validity of cache in hours
	:param args: Optional arguments for the provided function
	"""
	try:
		key = _hash_function(function, args)
		cache_result = cache_get(key)
		if cache_result:
			from resources.lib.modules import log_utils
			try: result = literal_eval(cache_result['value'])
			except: result = None
			if _is_cache_valid(cache_result['date'], duration):
				return result

		fresh_result = repr(function(*args)) # may need a try-except block for server timeouts

		if cache_result and (result and len(result) == 1) and fresh_result == '[]': # fix for syncSeason mark unwatched season when it's the last item remaining
			if isinstance(result[0], str) and result[0].isdigit():
				remove(function, *args)
				return []

		invalid = False
		try: # Sometimes None is returned as a string instead of None type for "fresh_result"
			if not fresh_result: invalid = True
			elif fresh_result == 'None' or fresh_result == '' or fresh_result == '[]' or fresh_result == '{}': invalid = True
			elif len(fresh_result) == 0: invalid = True
		except: pass

		if invalid: # If the cache is old, but we didn't get "fresh_result", return the old cache
			if cache_result: return result
			else: return None # do not cache_insert() None type, sometimes servers just down momentarily
		else:
			if '404:NOT FOUND' in fresh_result:
				cache_insert(key, None) # cache_insert() "404:NOT FOUND" cases only as None type
				return None
			else: cache_insert(key, fresh_result)
			return literal_eval(fresh_result)
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		return None

def _is_cache_valid(cached_time, cache_timeout):
	now = int(time())
	diff = now - cached_time
	return (cache_timeout * 3600) > diff

def timeout(function, *args):
	try:
		key = _hash_function(function, args)
		result = cache_get(key)
		return int(result['date']) if result else 0
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		return 0

def cache_existing(function, *args):
	try:
		cache_result = cache_get(_hash_function(function, args))
		if cache_result: return literal_eval(cache_result['value'])
		else: return None
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		return None

def cache_get(key):
	dbcon = None
	dbcur = None
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name='cache';''').fetchone()
		if not ck_table: return None
		results = dbcur.execute('''SELECT * FROM cache WHERE key=?''', (key,)).fetchone()
		return results
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		return None
	finally:
		if dbcur: dbcur.close()
		if dbcon: dbcon.close()

def cache_insert(key, value):
	dbcon = None
	dbcur = None
	try:
		# Cache persistence is optional: return fetched data promptly when another
		# plugin invocation holds the database, rather than waiting a minute.
		dbcon = get_connection(timeout=0.25)
		dbcur = get_connection_cursor(dbcon)
		now = int(time())
		dbcur.execute('''CREATE TABLE IF NOT EXISTS cache (key TEXT, value TEXT, date INTEGER, UNIQUE(key));''')
		dbcur.execute('''INSERT OR REPLACE INTO cache Values (?, ?, ?)''', (key, value, now))
		dbcur.connection.commit()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		if dbcur: dbcur.close()
		if dbcon: dbcon.close()

def remove(function, *args):
	try:
		key = _hash_function(function, args)
		key_exists = cache_get(key)
		if key_exists:
			dbcon = get_connection()
			dbcur = get_connection_cursor(dbcon)
			dbcur.execute('''DELETE FROM cache WHERE key=?''', (key,))
			dbcur.connection.commit()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	try: dbcur.close() ; dbcon.close()
	except: pass

def _hash_function(function_instance, *args):
	return _get_function_name(function_instance) + _generate_md5(args)

def _get_function_name(function_instance):
	return re_sub(r'.+\smethod\s|.+function\s|\sat\s.+|\sof\s.+', '', repr(function_instance))

def _generate_md5(*args):
	md5_hash = md5()
	try: [md5_hash.update(str(arg)) for arg in args]
	except: [md5_hash.update(str(arg).encode('utf-8')) for arg in args]
	return str(md5_hash.hexdigest())

def cache_clear(flush_only=False):
	cleared = False
	dbcon = None
	dbcur = None
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		if flush_only:
			dbcur.execute('''DELETE FROM cache''')
			dbcur.connection.commit() # added this for what looks like a 19 bug not found in 18, normal commit is at end
			dbcur.execute('''VACUUM''')
			cleared = True
		else:
			dbcur.execute('''DROP TABLE IF EXISTS cache''')
			dbcur.execute('''VACUUM''')
			dbcur.connection.commit()
			cleared = True
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		cleared = False
	finally:
		if dbcur: dbcur.close()
		if dbcon: dbcon.close()
	return cleared

def clearMovieCache():
	cleared = False
	try:
		if not control.existsPath(control.dataPath): control.makeFile(control.dataPath)
		dbcon = db.connect(control.libCacheSimilar)
		dbcur = dbcon.cursor()
		dbcur.execute('''DROP TABLE IF EXISTS movies''')
		dbcur.connection.commit()
		cleared = True
	except: 
		from resources.lib.modules import log_utils
		log_utils.error()
		cleared = False
	return cleared

def get_connection(timeout=60):
	if not control.existsPath(control.dataPath): control.makeFile(control.dataPath)
	dbcon = db.connect(control.cacheFile, timeout=timeout)
	try:
		dbcon.execute('''PRAGMA page_size = 32768''')
		dbcon.execute('''PRAGMA journal_mode = OFF''')
		dbcon.execute('''PRAGMA synchronous = OFF''')
		dbcon.execute('''PRAGMA temp_store = memory''')
		dbcon.execute('''PRAGMA mmap_size = 30000000000''')
	except:
		dbcon.close()
		raise
	dbcon.row_factory = _dict_factory
	return dbcon

def get_connection_cursor(dbcon):
	dbcur = dbcon.cursor()
	return dbcur

def _dict_factory(cursor, row):
	d = {}
	for idx, col in enumerate(cursor.description): d[col[0]] = row[idx]
	return d

##################
def cache_clear_search():
	cleared = False
	try:
		dbcon = get_connection_search()
		dbcur = dbcon.cursor()
		for t in ('movies', 'tvshow', 'collections', 'furk', 'easynews'):
			dbcur.execute('''DROP TABLE IF EXISTS {}'''.format(t))
			dbcur.execute('''VACUUM''')
			dbcur.connection.commit()
			control.refresh()
			cleared = True
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		cleared = False
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass
	return cleared

def cache_clear_SearchPhrase(table, key):
	cleared = False
	try:
		dbcon = get_connection_search()
		dbcur = dbcon.cursor()
		dbcur.execute('''DELETE FROM {} WHERE term=?;'''.format(table), (key,))
		dbcur.connection.commit()
		control.refresh()
		cleared = True
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		cleared = False
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass
	return cleared

def get_connection_search():
	control.makeFile(control.dataPath)
	conn = db.connect(control.searchFile)
	conn.row_factory = _dict_factory
	return conn
#added to clear old artwork
def cache_clear_thumbnails():
	cleared = False
	thumbnailsPath = xbmcvfs.translatePath('special://profile/Thumbnails/')
	databasePath  = xbmcvfs.translatePath('special://profile/Database/')
	addonPath = xbmcvfs.translatePath('special://home/addons')
	try:
		dbcon = sqlite3.connect(databasePath+'/Textures13.db')
		dbcur = dbcon.cursor()
		icon = dbcur.execute("SELECT cachedurl FROM texture WHERE url ='" + addonPath + "/plugin.video.infinity/icon.png';").fetchone()
		fanart = dbcur.execute("SELECT cachedurl FROM texture WHERE url ='" + addonPath + "/plugin.video.infinity/fanart.jpg';").fetchone()
		if icon is not None:
			if xbmcvfs.exists(thumbnailsPath + icon[0]):
				xbmcvfs.delete(thumbnailsPath + icon[0])
			dbcur.execute("DELETE FROM texture WHERE url ='" + addonPath + "/plugin.video.infinity/icon.png';") #delete the icon
		if fanart is not None:
			if xbmcvfs.exists(thumbnailsPath + fanart[0]):
				xbmcvfs.delete(thumbnailsPath + fanart[0])
			dbcur.execute("DELETE FROM texture WHERE url ='" + addonPath + "/plugin.video.infinity/fanart.jpg';") #delete the fanart
		dbcon.close()
		cleared = True
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		cleared = False
	return cleared

##################
def cache_clear_bookmarks():
	cleared = False
	try:
		dbcon = get_connection_bookmarks()
		dbcur = dbcon.cursor()
		dbcur.execute('''DROP TABLE IF EXISTS bookmark''')
		dbcur.execute('''VACUUM''')
		dbcur.connection.commit()
		cleared = True
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		cleared = False
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass
	return cleared

def cache_clear_bookmark(name, year='0'):
	cleared = False
	try:
		dbcon = get_connection_bookmarks()
		dbcur = dbcon.cursor()
		# idFile = md5()
		# for i in name: idFile.update(str(i))
		# for i in year: idFile.update(str(i))
		# idFile = str(idFile.hexdigest())
		# dbcur.execute("DELETE FROM bookmark WHERE idFile = '%s'" % idFile)
		years = [str(year), str(int(year)+1), str(int(year)-1)]
		dbcur.execute('''DELETE FROM bookmark WHERE Name="%s" AND year IN (%s)''' % (name, ','.join(i for i in years)))
		dbcur.connection.commit()
		control.refresh()
		control.trigger_widget_refresh()
		cleared = True
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		cleared = False
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass
	return cleared

def get_connection_bookmarks():
	control.makeFile(control.dataPath)
	conn = db.connect(control.bookmarksFile)
	conn.row_factory = _dict_factory
	return conn
##################
def clear_local_bookmarks(): # clear all infinity bookmarks from kodi database
	dbcon = dbcur = None
	try:
		dbcon = db.connect(get_video_database_path())
		dbcur = dbcon.cursor()
		dbcur.execute('''SELECT * FROM files WHERE strFilename LIKE "%plugin.video.infinity%"''')
		file_ids = [str(i[0]) for i in dbcur.fetchall()]
		if not file_ids: return
		for table in ('bookmark', 'streamdetails', 'files'):
			dbcur.execute('''DELETE FROM {} WHERE idFile IN ({})'''.format(table, ','.join(file_ids)))
		dbcur.connection.commit()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try:
			if dbcur: dbcur.close()
			if dbcon: dbcon.close()
		except: pass

def clear_local_bookmark(url): # clear all item specific bookmarks from kodi database
	try:
		dbcon = db.connect(get_video_database_path())
		dbcur = dbcon.cursor()
		dbcur.execute('''SELECT * FROM files WHERE strFilename LIKE "%{}%"'''.format(url))
		file_ids = [str(i[0]) for i in dbcur.fetchall()]
		if not file_ids: return
		for table in ('bookmark', 'streamdetails', 'files'):
			dbcur.execute('''DELETE FROM {} WHERE idFile IN ({})'''.format(table, ','.join(file_ids)))
		dbcur.connection.commit()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass

def get_video_database_path():
	database_path_final = False
	database_path = control.absPath(control.joinPath(control.dataPath, '..', '..', 'Database', ))  # doesn't work with mysql
	try:
		# path_db = 'special://profile/Database/%s' % db_name
		def find(pattern, path):
			result = []
			for root, dirs, files in os.walk(path):
				for name in files:
					if 'MyVideos' in name and name.endswith('.db'):
						result.append(control.joinPath(root, name))
			return result
		databasefile = find('MyVideos*.db', database_path)
		databasefile.sort(reverse=True)
		return databasefile[0]
		from resources.lib.modules import log_utils
		# log_utils.log('Umbrella MyVideos file path: %s' % str(database_path_final), 1)
		database_path_final = True
	except:
		from resources.lib.modules import log_utils
		log_utils.log('Umbrella MyVideos file path exception manual selection needed', 1)
		database_path_final = False
	if not database_path_final:
		kodi_version = control.getKodiVersion()
		if kodi_version == 17: database_path_final = control.joinPath(database_path, 'MyVideos107.db')
		elif kodi_version == 18: database_path_final = control.joinPath(database_path, 'MyVideos116.db')
		elif kodi_version == 19: database_path_final = control.joinPath(database_path, 'MyVideos119.db')
		elif kodi_version == 20: database_path_final = control.joinPath(database_path, 'MyVideos121.db')
		elif kodi_version == 21: database_path_final = control.joinPath(database_path, 'MyVideos131.db')
	return database_path_final
##################


def remove_expi_data():
	integrity_check = {
	'cacheFile': ('cache', 'date'),
	'fanarttvCacheFile': ('cache', 'date'),
	'metacacheFile': ('meta', 'time'),
	# 'cacheFile': ('cache', 'date',),
	'providercacheFile': ('rel_src', 'date',),}

	CLEAN = 'DELETE from {} WHERE CAST({} AS INT) <= ?'
	cache_hours = int(time()) - 5184000 # 2*30*24*60*60 2 months old data
	for item, v in integrity_check.items():
		file_db = eval(f'control.{item}')
		query = CLEAN.format(v[0], v[1])
		control.log(f'remove_expi_data from item: {file_db} table: {query}', 1)
		dbcon = get_connection(file_db)
		dbcon.execute(query, (cache_hours,))
		dbcon.commit()
		dbcon.execute('VACUUM')
		dbcon.close()


def limit_cache_size_db(file_db=control.cacheFile, max_size=10):
	remove_expi_data()
	with control.openFile(file_db) as f: s = f.size()
	size = round(float(s)/1048576, 1) # max_size 10 MB
	control.log(f'[ plugin.video.infinity ] limit cache size of db file {size} > {max_size}...', 1)
	if size < max_size: return
	dbcon = get_connection(file_db)
	tables_in_db = dbcon.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
	for table in tables_in_db:
		table = table.get('name')
		control.log(f'DELETE ROW from TABLE: {table}', 1)
		dbcon.execute(f'DELETE FROM {table} WHERE ROWID IN (SELECT ROWID FROM {table} ORDER BY ROWID DESC LIMIT -1 OFFSET 200)')
	# dbcon.execute('DELETE FROM function_cache WHERE ROWID IN (SELECT ROWID FROM function_cache ORDER BY ROWID DESC LIMIT -1 OFFSET 100)')
	# dbcon.execute('DELETE FROM season_metadata WHERE ROWID IN (SELECT ROWID FROM season_metadata ORDER BY ROWID DESC LIMIT -1 OFFSET 100)')
	dbcon.commit()
	dbcon.execute('VACUUM')
	dbcon.close()

def clrCache_version_update(clr_providers=False, clr_metacache=False, clr_cache=False, clr_fanarttv=False, clr_search=False, clr_bookmarks=False):
	try:
		if clr_providers:
			# from resources.lib.database import providerscache
			# providerscache.cache_clear_providers()
			control.deleteFile(control.providercacheFile)
		if clr_metacache:
			from resources.lib.database import metacache
			metacache.cache_clear_meta()
		if clr_cache: cache_clear(flush_only=True)
		if clr_search: cache_clear_search()
		if clr_bookmarks: cache_clear_bookmarks()
		if clr_fanarttv:
			from resources.lib.database import fanarttv_cache
			fanarttv_cache.cache_clear()
		control.notification(message='Forced cache clear for version update complete.')
		from resources.lib.modules import log_utils
		log_utils.log('Forced cache clear for version update complete.', level=log_utils.LOGDEBUG)
	except:
		from resources.lib.modules import log_utils
		log_utils.error()

def update_cache_version():
	versionFile = control.joinPath(control.dataPath, 'cache.v')
	try:
		if not control.existsPath(versionFile):
			f = open(versionFile, 'w')
			f.close()
	except:
		from resources.lib.modules import log_utils
		log_utils.log('Infinity Addon Data Path Does not Exist. Creating Folder....', __name__, level=log_utils.LOGDEBUG)
		ad_folder = control.transPath('special://profile/addon_data/plugin.video.infinity')
		control.makeDirs(ad_folder)
	try:
		with open(versionFile, 'r') as fh: oldVersion = fh.read()
	except: oldVersion = '0'
	try:
		curVersion = control.addon('plugin.video.infinity').getAddonInfo('version')
		if oldVersion != curVersion:
			with open(versionFile, 'w') as fh: fh.write(curVersion)
			return oldVersion, True
		else: return oldVersion, False
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		return oldVersion, False

def get_cache_version():
	versionFile = control.joinPath(control.dataPath, 'cache.v')
	try:
		if not control.existsPath(versionFile):
			f = open(versionFile, 'w')
			f.close()
	except:
		from resources.lib.modules import log_utils
		log_utils.log('Infinity Addon Data Path Does not Exist. Creating Folder....', __name__, log_utils.LOGDEBUG)
		ad_folder = control.transPath('special://profile/addon_data/plugin.video.infinity')
		control.makeDirs(ad_folder)
	try:
		with open(versionFile, 'r') as fh: oldVersion = fh.read()
	except: oldVersion = '0'
	return oldVersion