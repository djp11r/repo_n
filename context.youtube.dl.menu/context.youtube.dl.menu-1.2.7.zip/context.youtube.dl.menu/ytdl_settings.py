# -*- coding: utf-8 -*-
import xbmcaddon

if __name__ == '__main__':
    xbmcaddon.Addon(id='script.module.youtube.dl').openSettings()
