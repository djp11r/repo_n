# -*- coding: utf-8 -*-

import datetime
import os
import re
import sys
from urllib.parse import urlencode, quote_plus, parse_qsl, urlparse

# file = os.path.realpath(__file__)
# sys.path.append(os.path.join(os.path.dirname(file), "modules"))

import json
from modules import dom_parser
from caches.h_cache import main_cache
from modules import kodi_utils
from modules.kodi_utils import notification, local_string as ls, logger, build_url
from modules.indicators_bookmarks import get_resumetime
from modules.utils import to_utf8, replace_html_codes, remove_accents


from live_client import read_write_file, convert_time_str_to_seconds
from modules.live_client import next_icon
from modules.live_client import r_request, agent, wrigtht_json, clean_title, list_data_dir, fanart, unescape
from hindi_sources import scrape_sources, extractJS

remove_meta_keys = kodi_utils.remove_meta_keys
movie_dict_removals = kodi_utils.movie_dict_removals
headers = {"User-Agent": agent(),
           "Sec-Fetch-User": "?1",
           "upgrade-insecure-requests": "1"}

base_link = 'https://rumble.com/'


def rumble(params):
    pg_no = int(params['pg_no'])
    ch_name = params['list_name']
    url = params['url']
    iconImage = params['iconImage']

    def _process():
        for item in rumble_data:
            # logger("desirulez _process item: {}".format(item), __name__)
            listitem = kodi_utils.make_listitem()
            cm = []
            cm_append = cm.append
            title = '%s' % item['title']
            poster = item['image']
            playcount = item['playcount'] if item.get('playcount', None) else 0
            meta.update({
                'vid_type': 'movie',
                'rootname': title,
                'duration': item['duration'],
                'poster': poster,
                'title': title,
                'playcount': playcount, 'query': title, 'episode': '', 'url': item['url']})
            meta_json = json.dumps(meta)
            resumetime = get_resumetime('movie', title)
            if 'Next Page:' in item['title']:
                next_url_params = {'mode': 'vod_movies_list', 'list_name': ch_name, 'url': item['url'], 'pg_no': item['pg_no'], 'iconImage': iconImage}
                url = build_url(next_url_params)
                display = 'Next page: %s' % item['pg_no']
                listitem.setLabel(display)
                listitem.setArt({'icon': next_icon, 'fanart': fanart})
                listitem.setProperty('SpecialSort', 'bottom')
                listitem.setInfo('Video', remove_meta_keys(meta, movie_dict_removals))
                yield url, listitem, True
            else:
                url_params = {'mode': 'vod_prov_scape', 'vid_type': 'movie', 'db_type': 'movie', 'query': title, 'tmdb_id': title, 'meta': meta_json}
                url = build_url(url_params)
                # display = '%s :- %s' % (title, year)
                options_params = {'mode': 'options_menu_choice', 'suggestion': title, 'content': 'movie', 'meta': meta_json}
                rescrape_params = {'mode': 'vod_rescrape', 'play_params': json.dumps(url_params)}
                selectscrape_params = {'mode': 'vod_selectscrape', 'play_params': json.dumps(url_params)}
                cm_append(("[B]Select Source[/B]", 'RunPlugin(%s)' % build_url(selectscrape_params)))
                cm_append((ls(32014), 'RunPlugin(%s)' % build_url(rescrape_params)))
                cm_append((ls(32123), 'RunPlugin(%s)' % build_url({'mode': 'external_scrapers_reset_stats'})))
                cm_append((ls(32646), 'RunPlugin(%s)' % build_url(options_params)))
                listitem.setLabel(title)
                listitem.setProperty('resumetime', resumetime)
                listitem.addContextMenuItems(cm)
                listitem.setArt({'poster': poster, 'icon': poster, 'thumb': poster, 'clearart': poster, 'banner': '', 'fanart': '', 'clearlogo': poster, 'landscape': ''})
                listitem.setUniqueIDs({'imdb': str(title), 'tmdb': str(title)})
                listitem.setInfo('Video', remove_meta_keys(meta, movie_dict_removals))
                yield url, listitem, False

    meta = {}
    string = f"content_list_rumble_{ch_name}_{pg_no}"
    params = {'url': url, 'ch_name': ch_name, 'pg_no': pg_no, 'iconImage': iconImage}
    cache_name = string + urlencode(params)
    rumble_data = main_cache.get(cache_name)
    if not rumble_data:
        rumble_data = make_items_list(params)
        if rumble_data:
            main_cache.set(cache_name, rumble_data, expiration=datetime.timedelta(hours=24))  # 14 days cache
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    __handle__ = int(argv[1])
    if rumble_data:
        kodi_utils.add_items(__handle__, list(_process()))
        kodi_utils.set_content(__handle__, 'movies')
        kodi_utils.end_directory(__handle__)
        kodi_utils.set_view_mode('view.movies', 'movies')
    else:
        notification(f'No rumble Item Found for: :{ch_name}', 900)
        kodi_utils.end_directory(__handle__)
        return


def make_items_list(params):
    url = params['url']
    # title = params['title']
    ch_name = params['ch_name']
    pg_no = params['pg_no']
    headers.update({"Referer": base_link,
                    "Sec-Fetch-Dest": "document",
                    "Sec-Fetch-Mode": "navigate",
                    "Sec-Fetch-Site": "same-origin",})
    result_page = r_request(url, headers=headers).text
    result_page = to_utf8(remove_accents(result_page))
    result_page = result_page.replace('\n', ' ').replace('\t', ' ')
    # read_write_file(read=False, result=result_page)
    # result_page = read_write_file()
    result = dom_parser.parseDOM(result_page, "li", attrs = {"class": "video-listing-entry"})
    shows = []
    for item in result:
        # print(item)
        title = dom_parser.parseDOM(item, "h3", attrs={"class": "video-item--title"})[0]
        vid_url = dom_parser.parseDOM(item, "a", attrs={"class": "video-item--a"}, ret="href")[0]
        img = dom_parser.parseDOM(item, "img", ret="src")[0]
        # duration = dom_parser.parseDOM(item, "span", attrs = {"class": "video-item--duration data-value"})
        duration = re.findall('video-item--duration data-value=(.*?)>', item)[0]
        duration = convert_time_str_to_seconds(duration)
        if not vid_url.startswith('http'): vid_url = f"{base_link}{vid_url}"
        if not img.startswith('http'): img = f"{base_link}{img}"
        # print("title: %s vid_url: %s , img: %s , duration: %s " % (title, vid_url, img, duration))
        shows.append({"url": vid_url,
                      "title": title,
                      "ch_name": ch_name,
                      "pg_no": pg_no,
                      "mode": "vod_tv_geetmp",
                      "image": img,
                      "duration": duration})
    next_p = dom_parser.parseDOM(result_page, "li", attrs={"class": "paginator--li paginator--li--next"})
    if next_p:
        np_url = dom_parser.parseDOM(next_p[0], "a", ret = "href")[0]
        pg_no = re.compile('page=([0-9]+)').findall(np_url)[0]
        # icon = os.path.join(settings.get_theme(), 'item_next.png')
        title = f"Next Page: {pg_no}"
        shows.append({"url": f"{base_link}{np_url}",
                      "title": title,
                      "ch_name": ch_name,
                      "pg_no": pg_no,
                      "mode": "vod_tv_geetmp",
                      "image": 'item_next.png',
                      "duration": "0"})
    # logger(f'totle shows: {len(shows)} shows : {shows}', __name__)
    return shows


def get_vid_play(params):
    url = params['url']
    title = params['title']
    ch_name = params['ch_name']
    pg_no = params['pg_no']
    print(url)
    headers.update({"Referer": url,
                    "sec-fetch-dest": "video",
                    "sec-fetch-mode": "no-cors",
                    "sec-fetch-site": "cross-site",
                    "range": "bytes=0-"})
    # result_page = r_request(url, headers = headers).text
    # result_page = to_utf8(remove_accents(result_page))
    # result_page = result_page.replace('\n', ' ').replace('\t', ' ')
    # read_write_file(read=False, result=result_page)
    result_page = read_write_file()
    # result = dom_parser.parseDOM(result_page, "div", attrs = {"class": "videoPlayer-Rumble-cls"})
    # print(result)
    r = re.search(r'src:\s*"([^"]+)', result_page)
    print(f'link from packed: {r}')
    extractJS(result_page)


# if __name__ == "__main__":
#     import sys
#     print(sys.version_info)
#     try:
#         params = {'url': 'https://rumble.com/category/podcasts',
#                   'title': 'PODCasts',
#                   'ch_name': 'ch name',
#                   'pg_no': 1}
#         # make_items_list(params)
#         items = [{'url': 'https://rumble.com//vf19dp-covid-testing-industrial-complex-too-big-to-fail.html', 'title': 'Covid-Testing-Industrial-Complex: Too Big To Fail', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/9/s/v/G/9svGb.8p1b.2-small-Covid-Testing-Industrial-Co.jpg', 'duration': '31:44'}, {'url': 'https://rumble.com//vf16e7-ep.-1485-bidens-latest-move-is-his-most-radical-yet-the-dan-bongino-show.html', 'title': 'Ep. 1485 Biden’s Latest Move Is His Most Radical Yet - The Dan Bongino Show', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/F/w/u/G/FwuGb.oq1b.2-small-Ep.-1485-Bidens-Latest-Move.jpg', 'duration': '58:38'}, {'url': 'https://rumble.com//vf0iqn-callers-take-aim-at-my-2nd-amendment-views-but-i-stick-to-my-guns.html', 'title': 'Callers Take Aim at my 2nd Amendment Views but I Stick to my Guns', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/F/3/m/G/F3mGb.oq1b.2-small-Callers-Take-Aim-at-my-2nd-.jpg', 'duration': '50:38'}, {'url': 'https://rumble.com//vf0dwz-democrat-gun-grabbers-pounce-after-boulder-the-charlie-kirk-show.html', 'title': 'Democrat Gun Grabbers Pounce After Boulder | The Charlie Kirk Show', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/Z/v/l/G/ZvlGb.oq1b.2-small-Democrat-Gun-Grabbers-Pounc.jpg', 'duration': '1:12:04'}, {'url': 'https://rumble.com//vezywf-fauci-us-covid-lockdowns-no-mistake.html', 'title': 'Fauci: US Covid Lockdowns "No Mistake"', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/V/L/g/G/VLgGb.8p1b.2-small-Fauci-US-Covid-Lockdowns-No.jpg', 'duration': '32:40'}, {'url': 'https://rumble.com//vf01zv-the-great-excuse-dinesh-dsouza-podcast-ep53.html', 'title': 'THE GREAT EXCUSE Dinesh D’Souza Podcast Ep53', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://sp.rmbl.ws/s8/1/B/K/h/G/BKhGb.oq1b.2-small-THE-GREAT-EXCUSE-Dinesh-DSo.jpg', 'duration': '59:37'}, {'url': 'https://rumble.com//vezxir-title-ep.-1484-the-gun-grabbing-begins-the-dan-bongino-show.html', 'title': 'Ep. 1484 The Gun Grabbing Begins! - The Dan Bongino Show', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/Z/j/g/G/ZjgGb.oq1b.5-small-Title-Ep.-1484-The-Gun-Grab.jpg', 'duration': '59:48'}, {'url': 'https://rumble.com//vezusz-the-lefts-lies-about-whiteness-and-gun-control-ep.-1222.html', 'title': 'The Left’s Lies About “Whiteness” And Gun Control | Ep. 1222', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/Z/s/f/G/ZsfGb.oq1b.2-small-The-Lefts-Lies-About-Whiten.jpg', 'duration': '26:22'}, {'url': 'https://rumble.com//veyn7p-exploiting-the-poor-dinesh-dsouza-podcast-ep52.html', 'title': 'EXPLOITING THE POOR Dinesh D’Souza Podcast Ep52', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://sp.rmbl.ws/s8/1/f/G/3/F/fG3Fb.oq1b.2-small-EXPLOITING-THE-POOR-Dinesh-.jpg', 'duration': '1:00:57'}, {'url': 'https://rumble.com//veygi5-what-does-the-right-to-bear-arms-actually-mean.html', 'title': 'What Does the "Right To Bear Arms" Actually Mean?', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/n/y/1/F/ny1Fb.oq1b.5-small-What-Does-the-Right-To-Bear.jpg', 'duration': '47:37'}, {'url': 'https://rumble.com//veyfx7-ep.-1483-tucker-takes-on-kristi-noem-in-must-see-video-the-dan-bongino-show.html', 'title': 'Ep. 1483 Tucker Takes On Kristi Noem In Must See Video - The Dan Bongino Show', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/B/m/1/F/Bm1Fb.oq1b.8-small-Ep.-1483-Tucker-Takes-On-Kr.jpg', 'duration': '1:01:10'}, {'url': 'https://rumble.com//veybp1-if-you-dont-back-gun-control-its-because-you-dont-care-ep.-1221.html', 'title': '"If You Don\'t Back Gun Control, It\'s Because You Don\'t Care" | Ep. 1221', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/1/2/Z/F/12ZFb.oq1b.2-small-If-You-Dont-Back-Gun-Contro.jpg', 'duration': '29:20'}, {'url': 'https://rumble.com//vexoub-marjorie-taylor-greene-on-why-the-left-wants-her-out.html', 'title': 'Marjorie Taylor Greene on Why the Left Wants Her Out!', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/d/O/S/F/dOSFb.oq1b.2-small-Marjorie-Taylor-Greene-on-W.jpg', 'duration': '16:00'}, {'url': 'https://rumble.com//vex7rh-the-border-crisis-and-bidens-big-blame-game.html', 'title': "The Border Crisis & Biden's Big Blame Game | The Charlie Kirk Show", 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/n/o/N/F/noNFb.oq1b.2-small-The-Border-Crisis-and-Biden.jpg', 'duration': '1:13:24'}, {'url': 'https://rumble.com//vex6h7-should-there-be-changes-in-times-v.-sullivan.html', 'title': 'Should there be Changes in Times v. Sullivan?', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/l/0/M/F/l0MFb.oq1b.5-small-Should-there-be-Changes-in-.jpg', 'duration': '37:49'}, {'url': 'https://rumble.com//vex13h-ep.-1482-trump-the-border-and-ufos-the-dan-bongino-show.html', 'title': 'Ep. 1482 Trump, The Border, and UFOs? - The Dan Bongino Show', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/n/h/L/F/nhLFb.oq1b.2-small-Ep.-1482-Trump-The-Border-a.jpg', 'duration': '1:01:52'}, {'url': 'https://rumble.com//vevkdj-huge-win-for-project-veritas-against-new-york-times-viva-frei-vlawg.html', 'title': 'HUGE Win for Project Veritas Against New York TImes - Viva Frei Vlawg', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/N/B/u/F/NBuFb.oq1b.2-small-HUGE-Win-for-Project-Verita.jpg', 'duration': '16:57'}, {'url': 'https://rumble.com//vettzf-facebook-algorithms-have-no-sense-of-humor.html', 'title': 'Facebook Algorithms have no Sense of Humor', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/l/S/a/F/lSaFb.oq1b.2-small-Facebook-Algorithms-have-no.jpg', 'duration': '40:55'}, {'url': 'https://rumble.com//vete6p-ep.-1481-fireworks-erupt-on-capitol-hill-with-fauci-the-dan-bongino-show.html', 'title': 'Ep. 1481 Fireworks Erupt On Capitol Hill With Fauci - The Dan Bongino Show', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/r/S/7/E/rS7Eb.oq1b.2-small-Ep.-1481-Fireworks-Erupt-On.jpg', 'duration': '59:44'}, {'url': 'https://rumble.com//vetaar-the-cancellations-will-continue-until-morale-improves-ep.-1219.html', 'title': 'The Cancellations Will Continue Until Morale Improves | Ep. 1219', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/J/D/6/E/JD6Eb.oq1b.2-small-The-Cancellations-Will-Cont.jpg', 'duration': '31:39'}, {'url': 'https://rumble.com//vet7kf-the-inside-story-of-how-spygate-was-uncoveredlead-investigator-kash-patel-t.html', 'title': 'The Inside Story of How Spygate Was Uncovered—Lead Investigator Kash Patel Tells All', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/p/M/5/E/pM5Eb.oq1b.2-small-The-Inside-Story-of-How-Spy.jpg', 'duration': '43:59'}, {'url': 'https://rumble.com//vesczj-ron-desantis-kicks-crt-to-the-curb-atlanta-shootings-unpacked-the-charlie-k.html', 'title': 'Ron DeSantis Kicks CRT to the Curb + Atlanta Shootings Unpacked | The Charlie Kirk Show', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/_/6/V/E/_6VEb.oq1b.2-small-Ron-DeSantis-Kicks-CRT-to-t.jpg', 'duration': '1:11:01'}, {'url': 'https://rumble.com//ves4m9-ep.-1480-i-have-a-big-announcement-the-dan-bongino-show.html', 'title': 'Ep. 1480 I Have A Big Announcement - The Dan Bongino Show', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/H/r/T/E/HrTEb.oq1b.2-small-Ep.-1480-I-Have-A-Big-Annou.jpg', 'duration': '1:00:47'}, {'url': 'https://rumble.com//ves1w3-the-racist-left-only-cares-about-anti-asian-hate-when-they-can-blame-whiten.html', 'title': 'The Racist Left Only Cares About Anti-Asian Hate When They Can Blame “Whiteness” | Ep. 1218', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/t/A/S/E/tASEb.oq1b.2-small-The-Racist-Left-Only-Cares-.jpg', 'duration': '32:44'}, {'url': 'https://rumble.com//verrqn-interview-why-uvm-professor-aaron-kindsvatter-is-being-asked-to-resign.html', 'title': 'INTERVIEW: Why UVM Professor Aaron Kindsvatter is being asked to resign', 'ch_name': 'ch name', 'pg_no': 1, 'mode': 'vod_tv_geetmp', 'image': 'https://i.rmbl.ws/s8/1/V/m/P/E/VmPEb.oq1b.5-small-INTERVIEW-Why-UVM-Professor.jpg', 'duration': '54:02'}, {'url': 'https://rumble.com//category/podcasts?page=2', 'title': 'Next Page: 2', 'ch_name': 'ch name', 'pg_no': '2', 'mode': 'vod_tv_geetmp', 'image': 'item_next.png', 'duration': '0'}]
#         params = random.choice(items)
#         get_vid_play(params)
#     except Exception as e:
#         traceback.print_exc()
