# -*- coding: utf-8 -*-
from traceback import print_exc
from modules.kodi_utils import logger, get_setting, sleep, close_all_dialog, notification
from modules.watched_status import get_watched_info
from windows.skip import Skip, updateskip_data
from windows.base_window import open_window, create_window
import sys, time, datetime
# from caches import clean_databases
meta = {'tmdb_id': 1421, 'tvdb_id': 95011, 'imdb_id': 'tt1442437', 'rating': 7.811, 'plot': 'The Pritchett-Dunphy-Tucker clan is a wonderfully large and blended family. They give us an honest and often hilarious look into the sometimes warm, sometimes twisted, embrace of the modern family.', 'tagline': 'One big (straight, gay, multi-cultural, traditional) happy family.', 'votes': 2226, 'premiered': '2009-09-23', 'year': '2009', 'poster': 'https://image.tmdb.org/t/p/w185/fu5vEUHgxkAPmX26ISQXqHmlPMq.jpg', 'fanart': 'https://image.tmdb.org/t/p/w300/x4lxFIhhrDI4nWtV8osnYwbGESV.jpg', 'genre': ['Comedy'], 'title': 'Modern Family', 'original_title': 'Modern Family', 'english_title': '', 'season_data': [{ 'air_date': None, 'episode_count': 5, 'id': 147409, 'name': 'Specials', 'overview': '', 'poster_path': '/eyDoM7MTXrlmwOlh6TERdcgzmg2.jpg', 'season_number': 0 }, { 'air_date': '2009-09-23', 'episode_count': 24, 'id': 3751, 'name': 'Season 1', 'overview': 'Modern Family takes a refreshing and funny view of what it means to raise a family in this hectic day and age.  Multi-cultural relationships, adoption, and same-sex marriage are just a few of the timely issues faced by the show’s three wildly-diverse broods.  No matter the size or shape, family always comes first in this hilariously “modern” look at life, love, and laughter.', 'poster_path': '/9rvolF2UCFOSzh9PqozokcVe7XO.jpg', 'season_number': 1 }, { 'air_date': '2019-09-25', 'episode_count': 18, 'id': 127046, 'name': 'Season 11', 'overview': 'Jay and Gloria are navigating life with their youngest son, Joe, while Manny has headed off to college to explore the world on his own terms. Meanwhile, Claire and Phil have officially lost their status as empty-nesters when Haley started her own family and moved back home with her new husband, Dylan, and a set of twins. Luke, is now looking to his next move; and Alex is learning how to balance life outside of academia. Then there’s Mitchell and Cameron, who are still working to understand their gifted teenage daughter, Lily, and juggle busy careers.', 'poster_path': '/oTLdXCBZU3AgVZ3IPeoIV06omU9.jpg', 'season_number': 11 } ], 'alternative_titles': ['A Modern Farewell'], 'duration': 1500, 'rootname': 'Modern Family (2009)', 'imdbnumber': 'tt1442437', 'country': ['United States of America'], 'mpaa': 'TV-PG', 'trailer': 'plugin://plugin.video.youtube/play/?video_id=U7dLXjZfXV8', 'country_codes': ['US'], 'writer': [''], 'director': [], 'all_trailers': [{ 'iso_639_1': 'en', 'iso_3166_1': 'US', 'name': 'Modern Family Season 7 Promo (HD)', 'key': 'U7dLXjZfXV8', 'site': 'YouTube', 'size': 720, 'type': 'Teaser', 'official': False, 'published_at': '2015-09-02T01:50:14.000Z', 'id': '5caeff0c9251412fa621b572' } ], 'cast': [{ 'name': "Ed O'Neill", 'role': 'Jay Pritchett', 'thumbnail': 'https://image.tmdb.org/t/p/w185/4RrxSno3UEtGWuMm4yJoaFzckpL.jpg' }, { 'name': 'Sofía Vergara', 'role': 'Gloria Delgado-Pritchett', 'thumbnail': 'https://image.tmdb.org/t/p/w185/kLkzvEwCUHwqBu4SXBo3pd7si7P.jpg' }, { 'name': 'Reid Ewing', 'role': 'Dylan Marshall', 'thumbnail': 'https://image.tmdb.org/t/p/w185/vvehuMULozr81NCCDEql1pWIrvS.jpg' } ], 'studio': ['ABC'], 'extra_info': { 'status': 'Ended', 'type': 'Scripted', 'homepage': 'http://abc.go.com/shows/modern-family', 'created_by': 'Christopher Lloyd, Steven Levitan', 'next_episode_to_air': None, 'last_episode_to_air': { 'id': 2200642, 'name': 'Finale (2)', 'overview': 'The entire family discovers saying goodbye is much harder than it seems.', 'vote_average': 8.1, 'vote_count': 7, 'air_date': '2020-04-08', 'episode_number': 18, 'production_code': 'BARG18', 'runtime': 25, 'season_number': 11, 'show_id': 1421, 'still_path': '/7ceJ4Qj0tev5zFHjFsout23p8dN.jpg' } }, 'total_aired_eps': 250, 'mediatype': 'tvshow', 'total_seasons': 11, 'tvshowtitle': 'Modern Family', 'status': 'Ended', 'clearlogo': 'https://image.tmdb.org/t/p/original/rbKhglYrECjMZNYtT2QyihOQ5F.png', 'images': { 'poster': ['https://image.tmdb.org/t/p/w185/fu5vEUHgxkAPmX26ISQXqHmlPMq.jpg', 'https://image.tmdb.org/t/p/w185/fCiOen2bpru5JhzlaNkaNWNd9eP.jpg'], 'fanart': ['https://image.tmdb.org/t/p/w300/x4lxFIhhrDI4nWtV8osnYwbGESV.jpg', 'https://image.tmdb.org/t/p/w300/zN1G6IY2G5dQUKm1mYs0h3Hnt5Z.jpg'], 'clearlogo': ['https://image.tmdb.org/t/p/original/rbKhglYrECjMZNYtT2QyihOQ5F.png', 'https://image.tmdb.org/t/p/original/ueBlndUyVTEPl5uq5rcfbVmcVAq.png'], 'banner': ['http://assets.fanart.tv/fanart/tv/95011/tvbanner/modern-family-5237232583556.jpg', 'http://assets.fanart.tv/fanart/tv/95011/tvbanner/modern-family-522e07d880fb0.jpg',], 'clearart': ['http://assets.fanart.tv/fanart/tv/95011/clearart/M_95011 (2).png', 'http://assets.fanart.tv/fanart/tv/95011/clearart/M_95011.png'], 'landscape': ['http://assets.fanart.tv/fanart/tv/95011/tvthumb/modern-family-4e7aa119d2b82.jpg', 'http://assets.fanart.tv/fanart/tv/95011/tvthumb/modern-family-58a1c3df3fa45.jpg'] }, 'poster2': 'http://assets.fanart.tv/fanart/tv/95011/tvposter/modern-family-52da194760e77.jpg', 'fanart2': 'http://assets.fanart.tv/fanart/tv/95011/showbackground/modern-family-541a2417670b2.jpg', 'clearlogo2': 'http://assets.fanart.tv/fanart/tv/95011/hdtvlogo/modern-family-504c210cc58b2.png', 'banner': 'http://assets.fanart.tv/fanart/tv/95011/tvbanner/modern-family-5237232583556.jpg', 'clearart': 'http://assets.fanart.tv/fanart/tv/95011/clearart/M_95011 (2).png', 'landscape': 'http://assets.fanart.tv/fanart/tv/95011/tvthumb/modern-family-4e7aa119d2b82.jpg', 'season_art': { 'seasonposter_0': 'http://assets.fanart.tv/fanart/tv/95011/seasonposter/modern-family-5e97140c459b0.jpg', 'seasonposter_1': 'http://assets.fanart.tv/fanart/tv/95011/seasonposter/modern-family-538a186bf12cf.jpg', 'seasonposter_11': 'http://assets.fanart.tv/fanart/tv/95011/seasonposter/modern-family-5d8b12f5cc033.jpg', 'seasonthumb_4': 'http://assets.fanart.tv/fanart/tv/95011/seasonthumb/modern-family-50a1768d90126.jpg' }, 'discart': '', 'keyart': '', 'fanart_added': True, 'custom_poster': '', 'custom_fanart': '', 'custom_clearlogo': '', 'ep_name': 'Did the Chicken Cross the Road?', 'skip_option': { 'title': 'Modern Family', 'service': 'True', 'skip': '20', 'start': '10', 'eskip': '300' }, 'skip_style': 'netflix', 'display_name': 'Modern Family S10E7', 'media_type': 'episode', 'season': 1, 'episode': 7, 'background': False, 'custom_title': None, 'custom_year': None, 'custom_season': None, 'custom_episode': None }
# meta = {'mediatype': 'episode', 'year': 2022, 'plot': 'The Kapil Sharma Show, also known as TKSS, is an Indian Hindi-language stand-up comedy and talk show broadcast by Sony Entertainment Television. Hosted by Kapil Sharma The series revolved around Sharma and his neighbours in the Shantivan Non Co-operative Housing Society.', 'title': 'The Kapil Sharma Show Season 4', 'studio': ['Sony'], 'poster': 'https://www.desi-serials.cc/wp-content/uploads/2022/08/The-Kapil-Sharma-Show-300x169.jpg', 'homepage': 'https://www.desi-serials.cc/watch-online/sony-tv/the-kapil-sharma-show-season-4/', 'genre': ['Saturday  Sunday.', 'Comedy', 'Talk-Show'], 'cast': [], 'tmdb_id': 'Sony|The Kapil Sharma Show Season 4', 'imdb_id': 'tt5747326', 'rating': 7.3, 'clearlogo': '', 'trailer': '', 'votes': 50, 'tagline': '', 'director': [], 'writer': [], 'episodes': 390, 'seasons': '1, 2, 3, 4', 'extra_info': {'status': '', 'collection_id': ''}, 'tvdb_id': 'Sony|the kapil sharma show', 'duration': 3600, 'mpaa': 'TV-MA', 'season': 4, 'episode': 910, 'tvshowtitle': 'The Kapil Sharma Show Season 4', 'playcount': 0, 'original_title': 'The Kapil Sharma Show Season 4', 'total_seasons': '4', 'url': 'https://www.desi-serials.cc/the-kapil-sharma-show-season-4-episode-10th-september-2022-watch-online/441968/', 'fanart': 'https://www.desi-serials.cc/wp-content/uploads/2022/08/The-Kapil-Sharma-Show-300x169.jpg', 'premiered': '2022-09-10', 'ep_name': '10th September 2022', 'overlay': 4, 'media_type': 'episode', 'background': False, 'skip_option': {'title': 'The Kapil Sharma Show', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '300'}, 'skip_style': 'netflix'}

def testting():
    # update_hindi_metadb()
    test_window()
    #get_meta()
    # get_folders()
    # get_next_ep()
    # get_yt_dl()


def test_window(win='sources_results'):
    if win == 'nextep_win': # windows.next_episode <<<<<<<<<
        action = open_window(('windows.next_episode', 'NextEpisode'), 'next_episode.xml', meta=meta, test=True, default_action='cancel', play_type='autoplay_nextep', focus_button=11)
        if action == 'cancel':
            action = open_window(('windows.skip', 'Skip'), 'skipmulti.xml', skip_option=meta.get('skip_option'), test=True, focus_button=201, window_style='end_skip')
        action = open_window(('windows.next_episode', 'NextEpisode'), 'next_episode.xml', meta=meta, test=True, default_action='cancel', play_type='autoscrape_nextep', focus_button=11)
    elif win == 'infopop': # windows.infopop <<<<<<<<<
        action = open_window(('windows.extras', 'Extras'), 'extras.xml', options_media_type=meta.get('media_type'), meta=meta, is_external='false')
    elif win in ('skip_win', 'updateskip'): # windows.skip <<<<<<<<<<
        skip_option = {'title': 'The Blacklist', 'service': 'True', 'skip': '50', 'start': '10', 'eskip': '300'}
        windowstyle = 'netflix'#'Regular'
        # logger(f'windowstyle: {windowstyle.lower()}')
        if win == 'updateskip': updateskip_data(skip_option)
        else: buttonskip = open_window(('windows.skip', 'Skip'), 'skipmulti.xml', test=True , skip_option=skip_option, focus_button=201, window_style=windowstyle.lower())
        # logger(f'buttonskip: {buttonskip}')
    elif win in ('playback', 'resolver', 'resume', 'progress'): # playback && resolver etc<<<<<<<
        from threading import Thread
        from modules import kodi_utils, settings
        # kwargs = {'meta': meta, 'text': 'ok i see', 'enable_buttons': True, 'true_button': 'Yes', 'false_button': 'No', 'focus_button': 11}
        kwargs = {'meta': meta, 'text': 'ok i see', 'enable_fullscreen': True}
        _threads = []
        start_time = time.time()
        scraper_timeout = int(kodi_utils.get_setting('results.timeout', '30'))
        sleep_time = 100
        end_time = start_time + scraper_timeout
        monitor = kodi_utils.monitor
        ls = kodi_utils.local_string
        if win in ('playback', 'resolver', 'resume'): progress_dialog = create_window(('windows.sources', 'SourcesPlayback'), 'sources_playback.xml', meta=meta)
        if win == 'progress': progress_dialog = create_window(('windows.progress', 'Progress'), 'progress.xml', heading='progress', icon=meta.get('poster'))
        Thread(target=progress_dialog.run).start()
        if win  == 'resolver': progress_dialog.enable_resolver()
        if win == 'resume': progress_dialog.enable_resume(15)
        remaining_providers = ['freeworldnews.tv', 'playersb.com', 'vedshare.com', 'voeunblock8.com', 'youtu.be']
        try:
            while not progress_dialog.iscanceled() and not monitor.abortRequested():
                if progress_dialog.iscanceled(): break
                sources_total = sources_4k = sources_1080p = sources_720p = sources_sd = 5
                current_time = time.time()
                elapsed_time = current_time - start_time
                line1 = ', '.join(remaining_providers).upper()
                percent = int((elapsed_time/float(scraper_timeout))*100)
                try:
                    if win == 'playback': progress_dialog.update_scraper(sources_sd, sources_720p, sources_1080p, sources_4k, sources_total, line1, percent)
                    elif win == 'resolver': progress_dialog.update_resolver(percent=elapsed_time)
                    elif win == 'resume': progress_dialog.update_resumer()
                    elif win == 'progress': progress_dialog.update(percent=elapsed_time)
                except: pass
                kodi_utils.sleep(10)
                # logger(f'percent: {percent} elapsed_time: {elapsed_time}')
                if percent >= 100: break
                if current_time >= end_time: break
        except: logger(f'error: {print_exc()}')
        progress_dialog.close()
        try: del monitor
        except: pass
    elif win == 'sources_results': # windows.select_ok <<<<<<<<<<<<
        results = [{'source': 'tvarticles', 'quality': 'SD', 'info': 'All part: Single', 'url': 'https://tvarticles.org/vidd.php?id=2239785', 'direct': False, 'name': 'The Kapil Sharma Show S1E226', 'name_info': '', 'display_name': 'The Kapil Sharma Show S1E226', 'provider_site': 'tvarticles', 'scrape_provider': 'external', 'extraInfo': 'All part: Single', 'module_path': 'openscrapers.sources_openscrapers.en.desiserials', 'size_label': None, 'size': 0, 'provider_rank': 2, 'quality_rank': 4 }, {'source': 'gdrive', 'name': 'Modern.Family.S11E08.720p.WEB-HD.x264-Pahe.in.mkv', 'name_info': '.720p.web.hd.x264.pahe.in.mkv.', 'quality': '720p', 'url': 'https://gd.djp97s.workers.dev/Modern.Family.S11E08.720p.WEB-HD.x264-Pahe.in.mkv', 'info': 'AVC | WEB | MKV', 'direct': True, 'size': 0.15, 'display_name': 'Modern Family S11E8', 'provider_site': 'gdrive', 'scrape_provider': 'external', 'extraInfo': 'AVC | WEB | MKV', 'module_path': 'openscrapers.sources_openscrapers.en.gdrive', 'size_label': '0.15 GB', 'provider_rank': 2, 'quality_rank': 3 }, {'source': 'mixdrop.co', 'quality': 'SD', 'info': 'MP4 | ', 'url': 'https://mixdrop.co/e/wn6dpeo6szdwlx', 'direct': False, 'name': 'Modern Family S11E8', 'name_info': '', 'display_name': 'Modern Family S11E8', 'provider_site': '123moviestv_me', 'scrape_provider': 'external', 'extraInfo': '', 'module_path': 'openscrapers.sources_openscrapers.en.123moviestv_me', 'size_label': None, 'size': 0, 'provider_rank': 2, 'quality_rank': 4 }]
        scraper_settings = {'highlight_type': 2, 'hoster_highlight': '', 'torrent_highlight': '', 'real-debrid': '', 'premiumize': '', 'alldebrid': '', 'rd_cloud': '', 'pm_cloud': '', 'ad_cloud': '', 'furk': '', 'easynews': '', 'folders': '', '4k': 'FFFF3334', '1080p': 'FFE6B800', '720p': 'FF3C9900', 'sd': 'FFCAFFFF'}
        action = open_window(('windows.sources', 'SourcesResults'), 'sources_results.xml',
				window_format='list', window_style='non_contrast', window_id=2000, results=results, meta=meta,
				scraper_settings=scraper_settings, prescrape=False, filters_ignored=False, uncached_torrents=[])
        if not action: close_all_dialog()
    elif win == 'select_ok_win': # windows.select_ok <<<<<<<<<<<<
        from modules.kodi_utils import local_string, confirm_dialog, ok_dialog, show_text
        confirm_dialog(text=local_string(32855), ok_label=local_string(32824), cancel_label=local_string(32828))
        ok_dialog(text=local_string(32855))
        show_text(heading='Infinite', text=local_string(32855))

def cache_test():
    ctime = datetime.datetime.now()
    current_time = int(time.mktime(ctime.timetuple()))
    clean_databases(current_time, database_check=False, silent=True)
    from modules.source_utils import sources
    providers = sources('true', 'episode')
    from indexers.hindi.lists import youtube_m3u
    youtube_m3u()
    from caches.h_cache import MainCache
    MainCache().clean_hindi_lists()
    logger(providers)
    from caches import clrCache_version_update
    clrCache_version_update(clr_cache=True, clr_navigator=False)
    from apis.trakt_api import trakt_sync_activities
    status = trakt_sync_activities()
    logger(f'status: {status}')

def get_meta():
    from modules import kodi_utils, settings
    from modules.utils import get_datetime
    from modules.metadata import episodes_meta, all_episodes_meta, tvshow_meta
    current_date = get_datetime
    meta_user_info = settings.metadata_user_info()
    ep_data_get = {'media_ids': {'tmdb': 93812}, 'season': 2}
    meta = tvshow_meta('trakt_dict', ep_data_get['media_ids'], meta_user_info, current_date)
    logger(f'meta: {meta}')

def get_folders():
    from scrapers import external, folders
    from modules.settings import get_folderscraper_info
    folder_info, internal_scraper_names = get_folderscraper_info()
    # logger(f'folder_info: {folder_info}\ninternal_scraper_names: {internal_scraper_names}')
    prescrape_scrapers = []
    # info = {'media_type': 'movie', 'title': 'Star Wars: The Last Jedi', 'year': '2017', 'tmdb_id': 181808, 'imdb_id': 'tt2527336', 'aliases': [{'title': 'Star Wars: Episode VIII', 'country': ''}, {'title': 'Star Wars: Episode VIII – The Last Jedi', 'country': ''}, {'title': 'The Last Jedi', 'country': ''}, {'title': 'Star Wars - The Last Jedi - 3D', 'country': ''}, {'title': 'Star Wars: Episode VIII - The Last Jedi: Legendary', 'country': ''}, {'title': 'Star Wars: Episode 8 - The Last Jedi', 'country': ''}, {'title': 'Star Wars Episode VIII - The Last Jedi', 'country': ''}, {'title': 'Star Wars: Episode VIII - The Last Jedi 3D', 'country': ''}, {'title': 'Star Wars։ Episode VIII - The Last Jedi', 'country': ''}, {'title': 'Star Wars 8 - The Last Jedi', 'country': ''}, {'title': 'Star Wars: Episode VIII - The Last Jedi', 'country': ''}, {'title': 'Star Wars։ The Last Jedi (Episode VIII)', 'country': ''}, {'title': 'TLJ', 'country': ''}, {'title': 'Star Wars: The Last Jedi', 'country': ''}, {'title': 'Star Wars: The Last Jedi US', 'country': ''}], 'season': None, 'episode': None, 'tvdb_id': 'None', 'ep_name': None, 'expiry_times': (336, 0, 0), 'total_seasons': 1}
    info = {'media_type': 'episode', 'title': '24', 'year': '2001', 'tmdb_id': 1973, 'imdb_id': 'tt0285331', 'aliases': [{'title': 'Twenty Four', 'country': ''}, {'title': '24: Live Another Day', 'country': ''}, {'title': '24', 'country': ''}, {'title': '24 US', 'country': ''}], 'season': 8, 'episode': 6, 'tvdb_id': 76290, 'ep_name': 'Day 8: 12:00 A.M.-1:00 A.M.', 'expiry_times': (240, 720, 720), 'total_seasons': 9}
    # scrape_provider, scraper_name, folder_path = 'folder1', 'English Enet', 'smb://cp:srusty@ENET/Media/ENet/English Movies/'
    scrape_provider, scraper_name, folder_path = 'folder4', 'D drive TV Shows', 'D:/My Media/TV Shows/'
    folders_sraper = folders.source(scrape_provider, scraper_name, folder_path)
    results = folders_sraper.results(info)
    logger(f'folder_results: {results}')
    scraper_settings = {'highlight_type': 2, 'hoster_highlight': '', 'torrent_highlight': '', 'real-debrid': '', 'premiumize': '', 'alldebrid': '', 'rd_cloud': '', 'pm_cloud': '', 'ad_cloud': '', 'furk': '', 'easynews': '', 'folders': '', '4k': 'FFFF3334', '1080p': 'FFE6B800', '720p': 'FF3C9900', 'sd': 'FFCAFFFF'}
    if not results: notification('no result'); return
    action = open_window(('windows.sources', 'SourcesResults'), 'sources_results.xml',
            window_format='list', window_style='non_contrast', window_id=2000, results=results, meta=meta,
            scraper_settings=scraper_settings, prescrape=False, filters_ignored=False, uncached_torrents=[])
    if not action: close_all_dialog()

def get_next_ep():
    from modules.episode_tools import EpisodeTools
    from modules.settings import auto_nextep_settings
    nextep_settings = auto_nextep_settings('autoplay_nextep')
    # nextep_settings = {'scraper_time': 70, 'window_percentage': 10, 'alert_method': 0, 'default_action': 'play', 'use_chapters': True, 'play_type': 'autoscrape_nextep'}
    logger(f'nextep_settings: {nextep_settings}')
    EpisodeTools(meta, nextep_settings).auto_nextep()
    # logger(f'folder_results: {folder_results}')


def get_yt_dl():
    from modules.downloader import yt_dl
    yt_dl()
    # logger(f'get_yt_dl')
    # logger(f'folder_results: {folder_results}')