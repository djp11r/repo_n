# -*- coding: utf-8 -*-

from json import dumps
import math
import os
import random
import traceback
from urllib.parse import urlencode

import requests
from indexers.hindi.live_client import fanart, icon_dir, icon, next_icon
from modules import kodi_utils
from modules.kodi_utils import notification, logger, build_url
from caches.h_cache import cache_object

iicon = os.path.join(icon_dir, 'hindi_voot_icon.png')

# apiUrl = 'https://apiv2.voot.com/wsv_2_3/'
# ipaddress = get_setting('ipaddress')
apiUrl = 'https://psapi.voot.com/media/voot/v1/'
sortID = 'sortId=mostPopular'
# sortID = 'sortId=a_to_z'
msort = 'sortId=mostPopular'
# msort = 'sortId=a_to_z'
qualities = ['Tablet Main', 'TV Main', 'HLS_TV_HD']
strqual = 0  # qualities[int(_settings('quality'))]


def get_ip_(get_ip=True):
    import re
    url = 'http://bit.ly/1LhsHMX'
    jd = requests.get(url)
    if jd:
        ip = re.compile('address="(.+?)"', re.DOTALL).findall(jd.text)
        if len(ip) > 0:
            return ip
    else:
        return []


ip_list = cache_object(get_ip_, 'get_ip_', 'get_ip', False, 168)
ipaddress = random.choice(ip_list)
# headers = {'User-Agent': 'okhttp/3.4.1', 'X-Forwarded-For': ipaddress}
headers = {"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36",
           "accept": "application/json, text/plain, */*",
           "accept-encoding": "gzip, deflate, br",
           "content-type": "application/json; charset=utf-8",
           "referer": "https://www.voot.com/",
           "usertype": "svod",
           "Content-Version": "V4",
           "origin": "https://www.voot.com",
           'X-Forwarded-For': ipaddress, }


vidquality='None'
def refresh_login():
    #url = "https://us-central1-vootdev.cloudfunctions.net/usersV3/v3/login"
    global vidquality
    url = "https://userauth.voot.com/usersV3/v3/login"
    #web_pdb.set_trace()
    email = ''#_addon.getSetting('email')
    password = ''#_addon.getSetting('password')
    body = {"type": "traditional", "deviceId": "Windows NT 10.0", "deviceBrand": "PC/MAC", "data": {"email": email, "password": password}}

    body = dumps(body)

    jd = requests.post(url, headers=headers, data=body).json()
    if jd.get('data'):
        headers.update({'refreshToken': jd['data']['authToken']['refreshToken']})
        headers.update({'accessToken': jd['data']['authToken']['accessToken']})
        headers.update({'kToken': jd['data']['kToken']})
        headers.update({'kTokenId': jd['data']['kTokenId']})
        headers.update({'kUserId': jd['data']['kUserId']})
        headers.update({'uId': jd['data']['uId']})
        headers.update({'householdId': str(jd['data']['householdId'])})
        headers.update({'ks': jd['data']['ks']})
        vidquality = 'DASHENC_PREMIUMHD'
    else:
        vidquality = 'HLS_PremiumHD'
    return


def get_langs(params):
    """
    Get the list of languages.
    https://apiv2.voot.com/wsv_2_3/media/assetDetails.json?tabId=movieDetail&subTabId=allMovies&rowId=733&language=Hindi%2CEnglish&sortId=mostPopular&type=more&limit=15&offSet=0
    :return: list
    """
    languages = ['Hindi', 'Gujarati']
    langs = []
    for item in languages:
        # url = f'{apiUrl}media/assetDetails.json?tabId=movieDetail&subTabId=allMovies&rowId=733&language={item}&{msort}&type=more&limit=8&offSet=0'
        url = f'{apiUrl}voot-web/content/generic/movies-by-language?language=include:{item}&sort=title:asc,mostpopular:desc&responseType=common'
        jd = requests.get(url, headers=headers).json()
        # tcount = jd['assets'][0]['totalItems']
        tcount = jd['totalAsset']
        langs.append((item, tcount))
    return langs


def getlicense(urlid):
    token = ""
    if headers.get('ks'):
        hdr = {"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36", "content-type": "application/json", "authority": "rest-as.ott.kaltura.com", "accept-encoding": "gzip, deflate, br", "referer": "https://www.voot.com/", "origin": "https://www.voot.com"}
        url = "https://rest-as.ott.kaltura.com/v4_4/api_v3/service/multirequest"
        #web_pdb.set_trace()

        body = {"1": {"service": "asset", "action": "get", "id": urlid, "assetReferenceType": "media", "ks": headers['ks']},
                "2": {"service": "asset", "action": "getPlaybackContext", "assetId": urlid, "assetType": "media", "contextDataParams": {"objectType": "KalturaPlaybackContextOptions", "context": "PLAYBACK"}, "ks": headers['ks']},
                "apiVersion": "5.2.6",
                "ks": headers['ks'],
                "partnerId": 225}
        body = dumps(body)
        jd = requests.post(url, headers=hdr, data=body).json()
        for lictoken in jd['result'][1]['sources']:
            if lictoken.get('type') == 'DASH_LINEAR_APP' or lictoken.get('type') == 'DASHENC_PremiumHD':
                token = lictoken['drm'][1]['licenseURL']
    return token


def get_channels(params):
    """
    Get the list of channels.
    :return: list
    """
    offSet = params['offSet']
    channels = []
    finalpg = True
    pages = 1

    url = f'{apiUrl}voot-web/content/specific/editorial?query=include:0657ce8613bb205d46dd8f3c5e7df829&responseType=common&page={offSet}'
    #web_pdb.set_trace()
    jd = requests.get(url, headers=headers).json()
    # print(jd)
    items = jd['result']
    for item in items:
        title = item.get('name')
        tcount = item.get('sampledCount')
        icon = item['seo'].get('ogImage')
        sbu = item.get('SBU')
        item_id = item.get('id')
        channels.append((title, icon, sbu, item_id, tcount))

    offSet = int(offSet)
    totals = int(jd['totalAsset'])
    itemsLeft = totals - offSet * 10

    if itemsLeft > 0:
        finalpg = False
        pages = int(math.ceil(totals / 10.0))

    if not finalpg:
        title = f'Next Page.. (Currently in Page {offSet} of {pages})'
        offSet += 1

        labels = {}
        channels.append((title, iicon, sbu, offSet, tcount))
    return channels


def get_shows(params):
    """
    Get the list of shows.
    :return: list
    """
    channel = params['channel']
    offSet = params['offSet']
    totals = params['totals']
    #web_pdb.set_trace()
    shows = []
    finalpg = True
    pages = 1
    #
    if channel == 'VSO':
        url = f'{apiUrl}voot-web/content/specific/editorial-clone?query=include:366ef23c7cac2b3d5c7b315744f12a8b&&page={offSet}&responseType=common'
        jd = requests.get(url, headers=headers).json()
        items = jd['result']
        for item in items:
            title = item.get('name')
            tcount = item.get('season') if item.get('season') else 1
            sbu = item.get('SBU')
            item_id = item.get('id')
            icon = f'https://v3img.voot.com/resizeMedium,w_451,h_275/{item["showImage"]}'
            labels = {'title': title, 'genre': item.get('genres'), 'season': item.get('season'), 'plot': item['fullSynopsis'], 'mediatype': 'tvshow', 'year': item['releaseYear']}
            shows.append((title, icon, sbu, item_id, tcount, labels))
    else:
        url = f'{apiUrl}voot-web/content/generic/shows-by-sbu?sbu=include:{channel}&sort=mostpopular:desc&&page={offSet}'
        jd = requests.get(url, headers=headers).json()
        items = jd['result']
        for item in items:
            title = item.get('name')
            tcount = item['meta'].get('season') if item['meta'].get('season') else 1
            sbu = item['meta'].get('SBU')
            item_id = item.get('id')
            icon = f"{item['details']['image'].get('base')}{item['details']['image'].get('id')}.{item['details']['image'].get('type')}"
            labels = {'title': title, 'genre': item['meta'].get('genre'), 'season': item['meta'].get('season'), 'plot': item['meta']['synopsis'].get('full'), 'mediatype': 'tvshow', 'year': item['meta'].get('releaseYear')}
            shows.append((title, icon, sbu, item_id, tcount, labels))

    offSet = int(offSet)
    totals = int(jd['totalAsset'])
    itemsLeft = totals - offSet * 25
    #web_pdb.set_trace()
    if itemsLeft > 0:
        finalpg = False
        pages = int(math.ceil(totals / 10.0))

    if not finalpg:
        title = f'Next Page.. (Currently in Page {offSet} of {pages})'
        offSet += 1
        labels = {}
        shows.append((title, iicon, sbu, offSet, tcount, labels))
    return shows


def get_season(params):
    """
    Get the list of episodes.
    :return: list
    """
    show = params['show']
    offSet = params['offSet']
    totals = params['totals']
    season = []
    #web_pdb.set_trace()
    finalpg = True
    pages = 1
    url = f'{apiUrl}voot-web/content/generic/season-by-show?sort=season:desc&id={show}&page={offSet}&responseType=common'

    jd = requests.get(url, headers=headers).json()
    items = jd['result']
    for item in items:
        title = item.get('seasonName')
        item_id = item.get('seasonId')
        icon = item['seo'].get('ogImage')
        sbu = item.get('SBU')
        labels = {'title': title, 'genre': item.get('genres'), 'plot': item['seo'].get('description'), 'cast': item.get('contributors'), 'tvshowtitle': item['fullTitle'], 'mediatype': 'tvshow', 'season': item.get('season')}
        season.append((title, icon, sbu, item_id, labels, totals))

    offSet = int(offSet)
    totals = int(totals)
    itemsLeft = totals - offSet * 10
    #web_pdb.set_trace()
    if itemsLeft > 0:
        finalpg = False
        pages = int(math.ceil(totals / 10.0))

    if not finalpg:
        title = f'Next Page.. (Currently in Page {offSet} of {pages})'
        offSet += 1

        labels = {}
        season.append((title, iicon, offSet, show, labels, totals))
    return season


def get_episodes(params):
    """
    Get the list of episodes.
    :return: list
    """
    show = params['show']
    offSet = params['offSet']
    # totals = params['totals']
    episodes = []
    url = f'{apiUrl}voot-web/content/generic/series-wise-episode?sort=episode:desc&id={show}&&page={offSet}&responseType=common'

    jd = requests.get(url, headers=headers).json()
    # logger(f'jd: {jd}', __name__)
    totals = jd['totalAsset']
    finalpg = True
    pages = 1
    items = jd['result']
    for item in items:
        title = item['seo'].get('title')
        eid = item.get('id')
        icon = {'poster': item['seo'].get('ogImage'), 'thumb': item['seo'].get('ogImage'),  #'https://v3img.voot.com/resizeMedium,w_175,h_100/'+item.get('image16x9'),
                'icon': item['seo'].get('ogImage'), 'fanart': item['seo'].get('ogImage')}
        labels = {'title': title, 'genre': item.get('genres'), 'cast': item.get('contributors'), 'plot': item.get('fullSynopsis'), 'duration': item['duration'], 'tvshowtitle': item['shortTitle'], 'mediatype': 'episode', 'episode': item.get('episode'), 'season': item.get('season'), 'aired': item.get('telecastDate')[:4] + '-' + item.get('telecastDate')[4:6] + '-' + item.get('telecastDate')[6:], 'year': item.get(
            'releaseYear')}
        #title = 'E%s %s'%(labels.get('episode'), title) if labels.get('episode') else title
        #title = 'S%02d%s'%(int(labels.get('season')), title) if labels.get('season') else title
        #td = item.get('telecastDate')
        #if td:
        #    labels.update({'aired': td[:4] + '-' + td[4:6] + '-' + td[6:]})
        episodes.append((title, icon, eid, labels, totals))

    offSet = int(offSet)
    totals = int(totals)
    itemsLeft = totals - offSet * 10
    #web_pdb.set_trace()
    if itemsLeft > 0:
        finalpg = False
        pages = int(math.ceil(totals / 10.0))

    if not finalpg:
        title = f'Next Page.. (Currently in Page {offSet} of {pages})'
        offSet += 1

        labels = {}
        episodes.append((title, iicon, offSet, labels, totals))
    # logger(f'episodes: {episodes}', __name__)
    return episodes


def get_extra(params):
    """
    Get the list of episodes.
    :return: list
    """
    offSet = params['offSet']
    episodes = []
    url = f'{apiUrl}voot-web/content/specific/editorial-clone?query=include:6e5a6d3746fbfb092fd4b090f8505cd8&&page={offSet}&responseType=common'

    jd = requests.get(url, headers=headers).json()
    totals = jd['totalAsset']
    finalpg = True
    pages = 1
    items = jd['result']
    for item in items:
        title = item['seo'].get('title')
        eid = item.get('id')
        icon = {'poster': item['seo'].get('ogImage'), 'thumb': item['seo'].get('ogImage'), 'icon': item['seo'].get('ogImage'), 'fanart': item['seo'].get('ogImage')}
        labels = {'title': title, 'genre': item.get('genres'), 'cast': item.get('contributors'), 'plot': item.get('fullSynopsis'), 'duration': item['duration'], 'tvshowtitle': item['shortTitle'], 'mediatype': 'episode', 'episode': item.get('episode'), 'season': item.get('season'), 'aired': item.get('telecastDate')[:4] + '-' + item.get('telecastDate')[4:6] + '-' + item.get('telecastDate')[6:], 'year': item.get(
            'releaseYear')}

        episodes.append((title, icon, eid, labels, totals))

    offSet = int(offSet)
    totals = int(totals)
    itemsLeft = totals - offSet * 10

    if itemsLeft > 0:
        finalpg = False
        pages = int(math.ceil(totals / 10.0))

    if not finalpg:
        title = f'Next Page.. (Currently in Page {offSet} of {pages})'
        offSet += 1

        labels = {}
        episodes.append((title, iicon, offSet, labels, totals))

    return episodes


def get_movies(params):
    """
    Get the list of movies.
    :return: list
    title:asc,
    """
    lang = params['lang']
    offSet = params['offSet']
    totals = params['totals']
    movies = []
    totals = int(totals)
    offSet = int(offSet)
    finalpg = True
    pages = 1
    itemsLeft = totals - (offSet) * 10
    if itemsLeft > 0:
        finalpg = False
        pages = int(math.ceil(totals / 10.0))

    url = f'{apiUrl}voot-web/content/generic/movies-by-language?language=include:{lang}&sort=mostpopular:desc&&page={offSet}&responseType=common'
    jd = requests.get(url, headers=headers).json()
    items = jd['result']
    #web_pdb.set_trace()
    for item in items:
        title = item.get('name')
        mid = item.get('id')
        icon = item['seo'].get('ogImage')
        labels = {'title': title, 'genre': item.get('genres'), 'plot': item.get('fullSynopsis'), 'cast': item.get('contributors'), 'duration': item.get('duration'),  #int(item.get('duration', '0'))/60,
                  'mediatype': 'movie', 'mpaa': item.get('age'), 'aired': item.get('telecastDate')[:4] + '-' + item.get('telecastDate')[4:6] + '-' + item.get('telecastDate')[6:], 'year': item.get('releaseYear')}
        movies.append((title, icon, mid, labels))

    if not finalpg:
        title = f'Next Page.. (Currently in Page {offSet} of {pages})'
        offSet += 1
        labels = {}
        movies.append((title, iicon, offSet, labels))

    return movies


def get_live(params):
    """
    Get the list of movies.
    :return: list
    """
    offSet = params['offSet']
    live = []

    totals = 40
    offSet = int(offSet)
    finalpg = True
    pages = 1
    itemsLeft = totals - (offSet) * 10
    if itemsLeft > 0:
        finalpg = False
        pages = int(math.ceil(totals / 10.0))

    url = f'{apiUrl}voot-web/content/specific/editorial?query=include:0657ce8613bb205d46dd8f3c5e7df829&responseType=common&page={offSet}'
    jd = requests.get(url, headers=headers).json()
    items = jd['result']
    for item in items:
        title = item.get('name')
        url = f'{apiUrl}voot-web/view/channel/{item.get("id")}?page=1&premiumTrays=false'
        jd = requests.get(url, headers=headers).json()
        newurl = jd['trays'][0]['apiUrl']
        url = f'{apiUrl}voot-web/{newurl}&responseType=common'
        jd = requests.get(url, headers=headers).json()
        mid = jd['result'][0]['id'] if jd['result'] else item.get('id')
        icon = item['seo'].get('ogImage')
        labels = {'title': title, 'genre': item.get('genres'), 'mediatype': 'movie'}
        live.append((title, icon, mid, labels))

    if not finalpg:
        title = f'Next Page.. (Currently in Page {offSet} of {pages})'
        offSet += 1
        labels = {}
        live.append((title, iicon, offSet, labels))

    return live


def vootapp_root():
    ch_data = [{'name': 'Channels', 'mode': 'vootClist', 'type': 'channels'},
               {'name': 'Movies', 'mode': 'vootMlist', 'type': 'movies'},
               {'name': 'Live', 'mode': 'vootMlist', 'type': 'live'},
               {'name': 'Extra', 'mode': 'vootMlist', 'type': 'extra'}]
    item_list = []
    for item in ch_data:
        cm = []
        cm_append = cm.append
        title = item['name']
        url_params = {'mode': item['mode'], 'title': title, 'offSet': '1', 'type': item['type']}
        url = build_url(url_params)
        options_params = {'mode': 'options_menu_choice', 'suggestion': title, 'play_params': dumps(url_params)}
        cm_append(("[B]Options...[/B]", f'RunPlugin({build_url(options_params)})'))
        listitem = kodi_utils.make_listitem()
        listitem.setLabel(title)
        listitem.addContextMenuItems(cm)
        listitem.setArt({'icon': iicon, 'thumb': iicon, 'fanart': fanart})
        listitem.setInfo('video', {'title': title, 'genre': title})
        item_list.append((url, listitem, True))
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    __handle__ = int(argv[1])
    kodi_utils.add_items(__handle__, item_list)
    kodi_utils.set_content(__handle__, 'tvshows')
    kodi_utils.end_directory(__handle__)
    kodi_utils.set_view_mode('view.tvshows', 'tvshows')


def list_channels(params):
    """
    Create the list of countries in the Kodi interface.
    """
    channels = cache_object(get_channels, 'list_channels', params, False)
    listing = []
    for title, icon, sbu, item_id, tcount in channels:
        listitem = kodi_utils.make_listitem()
        listitem.setLabel(label=f'{title} ({tcount} shows)')
        listitem.setArt({'poster': icon, 'icon': icon, 'thumb': icon, 'fanart': fanart})
        listitem.setInfo('video', {'title': title})
        if 'Next Page' not in title:
            url_params = {'mode': 'voot_lchannel', 'offSet': '1', 'channel': sbu, 'totals': tcount}
        else: url_params = {'mode': 'vootClist', 'offSet': item_id, 'totals': tcount}
        url = build_url(url_params)
        listing.append((url, listitem, True))
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    __handle__ = int(argv[1])
    kodi_utils.add_items(__handle__, listing)
    kodi_utils.set_content(__handle__, 'videos')
    kodi_utils.end_directory(__handle__)
    kodi_utils.set_view_mode('view.videos', 'videos')


def list_shows(params):
    """
    Create the list of channels in the Kodi interface.
    """
    channel = params['channel']
    # offSet = params['offSet']
    totals = params['totals']
    # params = {'channel': channel, 'totals': totals}
    shows = cache_object(get_shows, 'list_shows_%s' % channel, params, False)
    # shows = cache.cacheFunction(get_shows,channel,totals)
    listing = []
    for title, icon, sid, item_id, tcount, labels in shows:
        listitem = kodi_utils.make_listitem()
        listitem.setLabel(label=f'{title} ({tcount} episodes)')
        listitem.setArt({'poster': icon, 'icon': icon, 'thumb': icon, 'fanart': icon})
        listitem.setInfo('video', labels)
        if 'Next Page' not in title:
            url_params = {'mode': 'voot_lshow', 'show': item_id, 'offSet': '1', 'totals': tcount, 'icon': icon}
        else:
            url_params = {'mode': 'voot_lchannel', 'offSet': item_id, 'channel': sid, 'totals': tcount, 'icon': icon}
        url = build_url(url_params)
        listing.append((url, listitem, True))
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    __handle__ = int(argv[1])
    kodi_utils.add_items(__handle__, listing)
    kodi_utils.set_content(__handle__, 'tvshows')
    kodi_utils.end_directory(__handle__)
    kodi_utils.set_view_mode('view.tvshows', 'tvshows')


def list_season(params):
    """
    Create the list of episodes in the Kodi interface.
    """
    show = params['show']
    offSet = params['offSet']
    totals = params['totals']
    # season = cache.cacheFunction(get_season,show,offSet,totals)
    season = cache_object(get_season, f'list_season_{show}', params, False)
    listing = []
    for title,icon,sid,item_id,labels,tcount in season:
        listitem = kodi_utils.make_listitem()
        listitem.setLabel(title)
        if isinstance(icon, dict):
            icon = icon['icon']
        listitem.setArt({'poster': icon,
                          'thumb': icon,
                          'icon': icon,
                          'fanart': icon})
        listitem.setInfo('video', labels)
        if 'Next Page' not in title:
            url_params = {'mode': 'voot_lepisod', 'show': item_id, 'offSet': offSet, 'totals': tcount, 'icon': icon}
        else:
            url_params = {'mode': 'voot_lshow', 'show': item_id, 'offSet': sid, 'totals': tcount}

        is_folder = True
        url = build_url(url_params)
        listing.append((url, listitem, is_folder))
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    __handle__ = int(argv[1])
    kodi_utils.add_items(__handle__, listing)
    kodi_utils.set_content(__handle__, 'episodes')
    kodi_utils.end_directory(__handle__)
    kodi_utils.set_view_mode('view.episodes', 'episodes')


def list_episodes(params):
    """
    Create the list of episodes in the Kodi interface.
    """
    show = params['show']
    offSet = params['offSet']
    totals = params['totals']
    sicon = params['icon']
    # logger('list_episodes params: %s' % (params), __name__)
    # episodes = cache.cacheFunction(get_episodes,show,offSet,totals)
    # params = {'show': show, 'offSet': offSet, 'totals': totals}
    episodes = cache_object(get_episodes, f'list_episodes_{show}', params, False)
    listing = []
    global vidquality
    for title, icon, eid, labels, totals in episodes:
        listitem = kodi_utils.make_listitem()
        listitem.setLabel(title)
        # logger('list_episodes title: %s' % (title), __name__)
        if isinstance(icon, dict):
            icon = icon['icon']
        listitem.setArt({'poster': icon, 'icon': icon, 'thumb': icon, 'fanart': icon})
        listitem.setInfo('video', labels)
        is_folder = False
        if 'Next Page' not in title:
            listitem.setProperty('IsPlayable', 'true')
            url_params = {'mode': 'voot_p_item', 'title': title, 'video': eid, 'quality': vidquality}
        else:
            url_params = {'mode': 'voot_lshow', 'show': show, 'offSet': eid, 'totals': totals, 'icon': sicon}
            is_folder = True
        url = build_url(url_params)
        listing.append((url, listitem, is_folder))
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    __handle__ = int(argv[1])
    kodi_utils.add_items(__handle__, listing)
    kodi_utils.set_content(__handle__, 'episodes')
    kodi_utils.end_directory(__handle__)
    kodi_utils.set_view_mode('view.episodes', 'episodes')


def list_extra(params):
    """
    Create the list of episodes in the Kodi interface.
    """
    offSet = params['offSet']
    episodes = cache_object(get_extra, f'list_extra{offSet}', params, False)
    listing = []

    for title,icon,eid,labels,totals in episodes:
        listitem = kodi_utils.make_listitem()
        listitem.setLabel(title)
        listitem.setArt(icon)
        listitem.setInfo('video', labels)
        is_folder = False
        if 'Next Page' not in title:
            listitem.setProperty('IsPlayable', 'true')
            # url = '{0}?action=play&video={1}&quality={2}'.format(_url, eid,'DASHENC_PREMIUMHD')
            url_params = {'mode': 'voot_p_item', 'video': eid, 'quality': 'DASHENC_PREMIUMHD'}
        else:
            # url = '{0}?action=list_extra&&offSet={1}'.format(_url,eid)
            url_params = {'mode': 'voot_lMovies', 'offSet': eid}
            is_folder = True
        url = build_url(url_params)
        listing.append((url, listitem, is_folder))
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    __handle__ = int(argv[1])
    kodi_utils.add_items(__handle__, listing)
    kodi_utils.set_content(__handle__, 'episodes')
    kodi_utils.end_directory(__handle__)
    kodi_utils.set_view_mode('view.episodes', 'episodes')


def list_langs(params):
    """
    Create the list of countries in the Kodi interface.
    """
    langs = cache_object(get_langs, 'list_langs', params, False)
    listing = []
    for lang, tcount in langs:
        listitem = kodi_utils.make_listitem()
        listitem.setLabel(label=f'{lang} ({tcount} movies)')
        listitem.setInfo('video', {'title': lang, 'genre': lang})
        listitem.setArt({'poster': iicon, 'icon': iicon, 'thumb': iicon, 'fanart': fanart})
        url_params = {'mode': 'voot_lMovies', 'lang': lang, 'offSet': '1', 'totals': tcount}
        url = build_url(url_params)
        listing.append((url, listitem, True))
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    __handle__ = int(argv[1])
    kodi_utils.add_items(__handle__, listing)
    kodi_utils.set_content(__handle__, 'movies')
    kodi_utils.end_directory(__handle__)
    kodi_utils.set_view_mode('view.movies', 'movies')


def list_movies(params):
    """
    Create the list of episodes in the Kodi interface.
    """
    lang = params['lang']
    offSet = params['offSet']
    totals = params['totals']
    # params = {'lang': lang, 'offSet': offSet, 'totals': totals}
    string = "%s_%s_%s" % (lang, offSet, totals)
    movies = cache_object(get_movies, f'list_movies_{string}', params, False)
    listing = []
    global vidquality
    for title, icon, mid, labels in movies:
        listitem = kodi_utils.make_listitem()
        listitem.setLabel(title)
        listitem.setArt({'poster': icon, 'icon': icon, 'thumb': icon, 'fanart': icon})
        listitem.setInfo('video', labels)
        is_folder = False
        if 'Next Page' not in title:
            listitem.setProperty('IsPlayable', 'true')
            url_params = {'mode': 'voot_p_item', 'title': title, 'video': mid, 'quality': vidquality}
        else:
            url_params = {'mode': 'voot_lMovies', 'lang': lang, 'offSet': mid, 'totals': totals}
            is_folder = True
        # logger(f'list_movies url_params: {url_params}', __name__)
        url = build_url(url_params)
        listing.append((url, listitem, is_folder))
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    __handle__ = int(argv[1])
    kodi_utils.add_items(__handle__, listing)
    kodi_utils.set_content(__handle__, 'movies')
    kodi_utils.end_directory(__handle__)
    kodi_utils.set_view_mode('view.movies', 'movies')


def list_live(params):
    """
    Create the list of episodes in the Kodi interface.
    """
    offSet = params['offSet']
    #channels = cache.cacheFunction(get_live,offSet)
    listing=[]

    channels = [(u'Colors Hindi', u'http://v3img.voot.com/v3Storage/channel-logos/COLORS_HINDI.png', u'805985', {'genre': [u'Drama'], 'mediatype': 'movie', 'title': u'Colors Hindi'}),
                (u'Rishtey Cineplex', u'http://v3img.voot.com/v3Storage/channel-logos/CPR-500x500.png', u'979936', {'genre': [], 'mediatype': 'movie', 'title': u'Rishtey Cineplex'}),
                (u'MTV', u'http://v3img.voot.com/v3Storage/assets/500x500_1.png', u'805989', {'genre': [u'Reality'], 'mediatype': 'movie', 'title': u'MTV'}),
                (u'MTV Beats', u'http://v3img.voot.com/v3Storage/channel-logos/MTV_BEATS.png', u'805294', {'genre': [u'Music'], 'mediatype': 'movie', 'title': u'MTV Beats'}),
                (u'Colors Marathi', u'http://v3img.voot.com/v3Storage/channel-logos/COLORS_MARATHI.png', u'793930', {'genre': [u'Drama'], 'mediatype': 'movie', 'title': u'Colors Marathi'}),
                (u'Shemaroo TV', u'http://v3img.voot.com/v3Storage/channel-logos/Shemaroo-TV-logo-500x500.png', u'981709', {'genre': [], 'mediatype': 'movie', 'title': u'Shemaroo TV'}),
                (u'Shemaroo Marathi Bana', u'http://v3img.voot.com/v3Storage/channel-logos/MarathiBana_With-tagline-500x500.png', u'981710', {'genre': [], 'mediatype': 'movie', 'title': u'Shemaroo Marathi Bana'}),
                (u'Sonic', u'https://v3img.voot.com/resizeMedium,w_221,h_125/v3Storage/assets/Live-Tv-Channels-nick-sonic-1606037274998.jpg', u'708552', {'genre': [u'Education'], 'mediatype': 'movie', 'title': u'Sonic'}),
                (u'Nick Jr', u'https://v3img.voot.com/resizeMedium,w_221,h_125/v3Storage/assets/Live-Tv-Channels-nick-jr-1606037359082.jpg', u'553909', {'genre': [u'Education'], 'mediatype': 'movie', 'title': u'Nick Jr'}),
                (u'Nick HD+', u'https://v3img.voot.com/resizeMedium,w_362,h_204/v3Storage/assets/Live-Tv-Channels-nick-hd-1606037295995.jpg', u'639070', {'genre': [u'Education'], 'mediatype': 'movie', 'title': u'Nick HD+'}),
                (u'DD National', u'http://v3img.voot.com/v3Storage/channel-logos/DD-national-test.png', u'966639', {'genre': [u'Education'], 'mediatype': 'movie', 'title': u'DD National'}),
               ]

    for title,icon,mid,labels in channels:
        listitem = kodi_utils.make_listitem()
        listitem.setLabel(title)
        listitem.setArt({'poster': icon,
                          'icon': icon,
                          'thumb': icon,
                          'fanart': icon})
        listitem.setInfo('video', labels)
        is_folder = False
        if 'Next Page' not in title:
            listitem.setProperty('IsPlayable', 'true')
            # url = '{0}?action=play&video={1}&quality={2}'.format(_url, mid,'DASH_LINEAR_APP')
            url_params = {'mode': 'voot_p_item', 'video': mid, 'quality': 'DASH_LINEAR_APP'}
        else:
            # url = '{0}?action=Live&offSet={1}'.format(_url, mid)
            url_params = {'mode': 'voot_lMovies', 'offSet': mid}
            is_folder = True

        url = build_url(url_params)
        listing.append((url, listitem, is_folder))
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    __handle__ = int(argv[1])
    kodi_utils.add_items(__handle__, listing)
    kodi_utils.set_content(__handle__, 'movies')
    kodi_utils.end_directory(__handle__)
    kodi_utils.set_view_mode('view.movies', 'movies')


def play_video_o(params):
    """
    Play a video by the provided path.

    :param path: str
    """
    path = params['video']
    # qualities = ['Tablet Main', 'TV Main', 'Web New', 'HLSFPS_Mobile_SD', 'HLSFPS_Main', 'SBR256', '360_Main']
    qualities = ['Tablet Main', 'TV Main']
    strqual = random.choice(qualities)
    # Create a playable item with a path to play.
    url = f'{apiUrl}playBack.json?mediaId={path}'
    try:
        ipaddress = random.choice(ip_list)
        headers['X-Forwarded-For'] = ipaddress
        jd = requests.get(url, headers=headers).json()
        # logger(f'ipaddress : {ipaddress} jd: {jd}', __name__)
        files = jd['assets'][0]['assets'][0]['items'][0]['files']
        if strqual not in str(files):
            strqual = 'Web New'
        for file in files:
            if file.get('Format') == strqual:
                stream_url = file.get('URL') + '|User-Agent=playkit/android-3.4.5 com.tv.v18.viola/2.1.42 (Linux;Android 5.1.1) ExoPlayerLib/2.7.0'
                stream_url += f'&X-Forwarded-For={ipaddress}'
                from modules.hplayer import FenPlayer
                FenPlayer().run(url, 'video', {'info': params['title'], 'source': ''})
                break
            else:
                notification('Voot - URL Not Found:', 1000)
                break
    except:
        logger(f'- Exception: {traceback.print_exc()}', __name__)
        notification('voot - URL Not Found:', 1000)


def play_video(params):
    """
    Play a video by the provided path.

    """
    #
    # logger('play_video params: %s' % (params), __name__)
    urlid = params['video']
    quality = params['quality']
    token = getlicense(urlid)
    stream_url = ''
    #web_pdb.set_trace()
    if quality == 'DASHENC_PREMIUMHD':
        url = f'{apiUrl}voot-web/asset/{urlid}?responseType=playback_new&playbackType=DASHENC_PREMIUMHD'
        jd = requests.get(url, headers=headers).json()
        stream_url = jd['result'][0]['profileUrls'][0]['profileUrl']
    else:
        url = f'https://apiv2.voot.com/wsv_2_3/playBack.json?mediaId={urlid}'
        jd = requests.get(url, headers=headers).json()
        if jd['total_items'] != 0:
            files = jd['assets'][0]['assets'][0]['items'][0]['files']
            if token == "":
                if 'TV Main' in str(files):
                    urlquality = 'TV Main'
                elif 'HLS_Linear_P' in str(files):
                    urlquality = 'HLS_Linear_P'
                else:
                    urlquality = 'HLS_PremiumHD'
            else:
                urlquality = 'DASHENC_PREMIUMHD'
            for file in files:
                if file.get('Format') == urlquality:
                    stream_url = file.get('URL')
                    break
    if stream_url == '':
        msg = "Need Premium subsription"
        notification('voot - Need Premium subsription:', 2000)
    else:
        logger(f'stream_url: {stream_url}', __name__)
        play_item = kodi_utils.make_listitem()
        play_item.setPath(stream_url)

        """
        play_item = xbmcgui.ListItem(path=path)
        vid_link = play_item.getfilename()
        url = 'https://apiv2.voot.com/wsv_2_3/playBack.json?mediaId=%s'%(vid_link)
        jd = requests.get(url, headers=headers).json()
        files = jd['assets'][0]['assets'][0]['items'][0]['files']
        if strqual not in str(files):
            if 'TV Main'  in str(files):
                strqual = 'TV Main'
            elif 'HLS_Linear_P' in str(files):
                strqual = 'HLS_Linear_P'
            else:
                strqual = 'HLS_PremiumHD'

        if license!="":
            for file in files:
                if file.get('Format') == 'DASH_LINEAR_APP':
                    stream_url = file.get('URL')
                    break
        else:
            for file in files:
                if file.get('Format') == strqual:
                    stream_url = file.get('URL') + '|User-Agent=playkit/android-3.4.5 com.tv.v18.viola/2.1.42 (Linux;Android 5.1.1) ExoPlayerLib/2.7.0'
                    break

        if _settings('EnableIP') == 'true':
            stream_url += '&X-Forwarded-For=%s'%_settings('ipaddress')
        """

        play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')

        if stream_url.find('mpd') != -1:
            play_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            play_item.setMimeType('application/dash+xml')
        else:
            play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            play_item.setMimeType('application/vnd.apple.mpegurl')

        if token != "":
            play_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
            play_item.setProperty('inputstream.adaptive.license_key', token + f'|{urlencode(headers)}&Content-Type=application/octet-stream|R{{SSM}}|')
            play_item.setProperty("inputstream.adaptive.stream_headers", urlencode(headers))
        play_item.setContentLookup(False)

        # Pass the item to the Kodi player.
        from sys import argv
        kodi_utils.set_resolvedurl(int(argv[1]), True, listitem=play_item)


# if __name__ == "__main__":
#     # print('get_langs: %s' % get_langs())
#     # print('get_channels: %s' % get_channels())
#     # params = {'channel': 'COH', 'offSet': 1, 'totals': 25}
#     # print('get_shows: %s' % get_shows(params))
#     # params = {'show': '100574', 'offSet': 1, 'totals': 25}
#     # print('get_season: %s' % get_season(params))
#     # params = {'show': '1106872', 'offSet': 1}
#     # print('get_episodes: %s' % get_episodes(params))
#     # params = {'offSet': 1}
#     # print('get_extra: %s' % get_extra(params))
#     params = {'lang': 'Gujarati', 'offSet': 1, 'totals': 25}
#     print('get_movies: %s' % get_movies(params))
#     params = {'offSet': 1}
#     print('get_live: %s' % get_live(params))
