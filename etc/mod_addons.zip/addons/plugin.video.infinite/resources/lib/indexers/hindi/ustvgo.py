# -*- coding: utf-8 -*-

import datetime
import base64
import re
import traceback
import requests
import json
from urllib.parse import urljoin
from indexers.hindi.live_client import joinPath, r_request, agent, wrigtht_json, list_data_dir, icon, fanart
from modules import kodi_utils
from modules.kodi_utils import notification, logger, build_url
try: from caches.h_cache import main_cache, cache_object
except: from modules.h_cache import main_cache, cache_object
try: ustv_chennel = joinPath(list_data_dir, "ustvgo_new.json")
except: ustv_chennel = "list_data/ustvgo_new.json"
base_link = 'https://ustvgo.tv' # https://ustv247.tv/
remove_meta_keys = kodi_utils.remove_meta_keys
tvshow_dict_removals = kodi_utils.tvshow_dict_removals


def ustv_root():
    cache_name = "content_list_ustv_root"
    ch_data = main_cache.get(cache_name)
    if not ch_data:
        ch_data = get_ch_data()
        # logger("##### - NEW ch_data: ")
        if ch_data:
            wrigtht_json(ustv_chennel, json.dumps(ch_data))
            main_cache.set(cache_name, ch_data, expiration=datetime.timedelta(hours=168))  # 1 days cache
    if len(ch_data) < 1:
        with open(ustv_chennel, 'r') as f:
            ch_data = json.load(f)
    # ch_data = sorted(ch_data, key=lambda k: k['ch_no'])
    # item_list = list(_process(ch_data))
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    __handle__ = int(argv[1])
    kodi_utils.add_items(__handle__, list(_process(ch_data)))
    kodi_utils.set_content(__handle__, 'episodes')
    kodi_utils.end_directory(__handle__)
    kodi_utils.set_view_mode('view.episodes', 'episodes')


def _process(list_data):
    for i in list_data:
        # logger(f"desirulez _process item: {i}")
        if i['vid_url']:
            listitem = kodi_utils.make_listitem()
            cm = []
            cm_append = cm.append
            name = i['title']
            if i['poster'].startswith('http'): thumb = i['poster']
            else: thumb = icon
            url_params = {'mode': i['action'], 'title': name, 'url': i['url'], 'vid_url': i['vid_url']}
            url = build_url(url_params)
            options_params = {
                    'mode': 'options_menu_choice',
                    'suggestion': name,
                    'play_params': json.dumps(url_params)}
            cm_append(("[B]Options...[/B]", f'RunPlugin({build_url(options_params)})'))
            listitem.setLabel(name)
            listitem.addContextMenuItems(cm)
            listitem.setArt({'thumb': thumb})
            listitem.setInfo('video', remove_meta_keys(i, tvshow_dict_removals))
            yield url, listitem, False
    return


def retrieve_new_token(argf=None):
    renew_token_node = 'https://ustvgo.tv/data.php'
    renew_token_node_post_data = {"stream": "NFL"}
    # logger("retrieve_new_token Working some black magic..")
    stream_url = requests.post(renew_token_node, headers={"User-Agent": agent()}, data=renew_token_node_post_data, ).text
    # auth_token = stream_url.split("wmsAuthSign=")[1]
    # logger("stream_url: %s"% stream_url)
    result = re.compile('https://(.+?)/.+?wmsAuthSign=(.+?)$', re.MULTILINE | re.DOTALL).findall(stream_url)
    # logger("auth_token: %s"% result)
    auth_token = {"cdn_nodes": result[0][0], "auth_token": result[0][1]}
    return auth_token


def play(params):
    try:
        # logger(f"params : {params}")
        title = params['title']
        # url = params['url']
        # auth_token = retrieve_new_token()
        auth_token = cache_object(function=retrieve_new_token, string='content_list_ustvgo_auth_token', url='', json=False, expiration=3.6)
        # headers = {'User-Agent': agent(), 'Referer': base_link}
        try:
            # x = random.randrange(3)
            # cdn_nodes = ['h1.ustvgo.la', 's6.ustvgo.org', 's8.ustvgo.org', 's9.ustvgo.org', 's11.ustvgo.org']
            if title == "The Weather Channel": link = params['vid_url']
            else: link = params['vid_url'] % (auth_token['cdn_nodes'], auth_token['auth_token'])
            link = f'{link}|User-Agent={agent()}&Referer={params["url"]}'
            logger("link3: %s" % link)
            from modules.hplayer import FenPlayer
            FenPlayer().run(link, 'video', {'info': title, 'source': ''})
        except:
            auth_token = cache_object(function=retrieve_new_token, string='content_list_ustvgo_auth_token', url='', json=False, expiration=0.1)
            logger(f'---USTVgo - Exception: {traceback.print_exc()}', __name__)
            notification('USTVgo - VPN Locked Or The Code Has Changed:', 2000)
            return
    except:
        logger(f'---USTVgo - Exception: {traceback.print_exc()}', __name__)
        notification('USTVgo - Exception:', 900)
        return


def play_old(params):
    try:
        # logger(f"params : {params}")
        title = params['title']
        url = params['url']
        headers = {
            'User-Agent': agent(),
            'Referer': base_link}
        link = r_request(url, headers=headers).text
        # link = base_link + str([i for i in re.findall("<iframe src='(.+?)'", link)][0].split("'")[0])
        link = str([i for i in re.findall("<iframe src='(.+?)'", link)][0].split("'")[0])
        # logger("link: %s"% link)
        if link.startswith('/'):
            link = urljoin(base_link, link)
        # logger("link: %s"% link)
        link = r_request(link, headers=headers).text
        try:
            # code = link[link.find("encrypted"):]
            # code = code[:code.find("</script>")]
            # file_code = re.findall(r"file.+", code)[0]
            # file_code = "var link = " + file_code[file_code.find(":") + 1: file_code.find(",")]
            # code = code[:code.find("var player")]
            # code = code + file_code
            # crypto_min = base_link + "/Crypto/crypto.min.js"
            # addional_code = r_request(crypto_min, headers = headers).text
            # code = addional_code + code
            # context = js2py.EvalJs(enable_require=True)
            # link = context.eval(code)
            # logger('link1: %s' % link.replace("\r","").replace("\n",""))
            # link = ''.join(['{}'.format(line.rstrip('\n')) for line in str(link)])
            # link = link.replace("\r","").replace("\n","")
            # logger(f'link2: {link}')
            # logger("code: %s"% link)
            # code = re.findall(r'atob\(\'(.+?)\'', link)
            code = re.findall(r'hls_src=\'(.+?)\';', link)
            # logger("urls: %s"% code)
            # link = base64.b64decode(code[0])
            # if not isinstance(link, str):
                # link = link.decode('utf-8')
            link = f'{code[0]}|User-Agent={agent()}&Referer={base_link}'
            logger(f"link to play: {link}")
            from modules.hplayer import FenPlayer
            info = {'info': title, 'source': ''}
            FenPlayer().run(link, 'video', info)
        except:
            notification('USTVgo - VPN Locked Or The Code Has Changed:', 2000)
            return
    except:
        logger(f'---USTVgo - Exception: \n{traceback.print_exc()}\n', __name__)
        notification('USTVgo - Exception:', 900)
        return


def get_dict_per_name(list_of_dict, key_value):
    for item in list_of_dict:
        if item['title'] == key_value:
            my_item = item
            list_of_dict.remove(item)
            break
    else:
        my_item = None
    return list_of_dict, my_item


def get_ch_data():
    with open(ustv_chennel) as f:
        list_of_dict = json.load(f)
    ch_lists = []
    result = r_request(base_link).text
    # result = to_utf8(remove_accents(result))
    # result = result.replace('\n', ' ')
    # read_write_file(file_n='ustv.html', read=False, result=result)
    # result = read_write_file(file_n='ustv.html')
    ch_url = re.findall('<li><strong><a href="(.+?)">(.+?)</a>', result)
    # logger(f">>> nos of url : {len(ch_url)}")
    ch_no = 3
    for item in ch_url:
        # logger(f">>> nos of item : {item}")
        ch_name = item[1].replace('#038;', '').replace('&amp;', '&').replace('Animal', 'Animal Planet').replace('CW', 'The CW').strip()
        # ch_name = ch_name.replace('Animal', 'Animal Planet').replace('CW', 'The CW').strip()
        list_of_dict, ch_dict = get_dict_per_name(list_of_dict, ch_name)
        # logger(f">>> item: {ch_dict}")
        if ch_name == 'FoxNews':
            ch_no = 1
        elif ch_name == 'FoxBusiness':
            ch_no = 2
        else:
            ch_no += 1

        if ch_dict:
            ch_dict.update({'url': item[0], 'ch_no': ch_no})
            ch_lists.append(ch_dict)
        else:
            result = r_request(item[0]).text
            # result = to_utf8(remove_accents(result))
            # result = result.replace('\n', ' ')
            # read_write_file(file_n='ustv2.html', read=False, result=result)
            # result = read_write_file(file_n='ustv2.html')
            ch_stub = re.findall(r'<iframe src=[\'|"]\/clappr\.php\?stream=(.+?)[\'|"] allowfullscreen', result)
            if ch_stub: vid_url = 'https://%s/' + '%s' % ch_stub[0] + '/myStream/playlist.m3u8?wmsAuthSign=%s'
            else: vid_url = "https://%s/Boomerang/myStream/playlist.m3u8?wmsAuthSign=%s"
            ch_lists.append({'ch_no': ch_no, 'action': 'ltp_ustv', 'poster': '', 'title': ch_name, 'url': item[0], 'vid_url': vid_url})
    # logger(f">>> list_of_dict: {list_of_dict}")
    # logger(f">>> nos of item in local but not found new : {len(list_of_dict)}")
    ch_lists = ch_lists + list_of_dict
    ch_lists = sorted(ch_lists, key=lambda k: k['ch_no'])
    # ch_lists = json.loads(str(ch_lists))
    # logger(f">>> list_of_dict: {json.dumps(ch_lists)}")
    # logger(f">>> nos of item in ch_lists : {len(ch_lists)}")
    return ch_lists


# if __name__ == "__main__":
#     get_ch_data()
