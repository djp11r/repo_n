# -*- coding: utf-8 -*-
# -Created By Tempest

import base64
import re
import traceback
from sys import exit as sysexit

from indexers.hindi.live_client import r_request, agent, icon, fanart

from modules import kodi_utils
from modules.kodi_utils import notification, logger, build_url


class myustv:
    def __init__(self):
        self.thumb = icon
        self.list = []
        self.base_link = 'http://myustv.com'
        self.headers = {
            'User-Agent': agent(),
            'Referer': self.base_link}

    def root(self):
        urls = ['http://myustv.com//watch/category/united-states-usa-tv-channel', 'http://myustv.com/watch/category/united-states-usa-tv-channel/page/2/', 'http://myustv.com/watch/category/united-states-usa-tv-channel/page/3/', 'http://myustv.com/watch/category/united-states-usa-tv-channel/page/4/', 'http://myustv.com/watch/category/united-states-usa-tv-channel/page/5/',
                'http://myustv.com/watch/category/united-states-usa-tv-channel/page/6/', 'http://myustv.com/watch/category/soccer-streams/']
        for url in urls:
            url = r_request(url, headers = self.headers).text
            # logger(url)
            if url:
                pattern = r'<div class="td_module_1 td_module_wrap td-animation-stack">\s+<div class="td-module-image">\s+<div class="td-module-thumb"><a href="(.+?)" rel="bookmark" class="td-image-wrap" title="(.+?)"><img .+? src="(.+?)"'
                url = re.findall(pattern, url.content, re.MULTILINE)
                for item in url:
                    self.list.append({
                        'name': item[1].replace('#038;', ''),
                        'url': item[0],
                        'image': item[2],
                        'action': 'ltp_myustv'})
        self.addDirectory(self.list)  # return self.list

    def play(self, url, title):
        try:
            stream = r_request(url, headers = self.headers).text
            stream = re.compile(r'var link= atob\("(.+?)"\);').findall(stream)[0]
            link = base64.b64decode(stream)
            # try:
            #     link = str(link, "utf-8")
            # except:
            #     link = link
            if "https" in link:
                link = f'{link}|User-Agent={agent()}&Referer={url}&verifypeer=false'
            else:
                link = f'{link}|User-Agent={agent()}&Referer={url}'
            from modules.hplayer import FenPlayer
            # info = {'info': params['title']}
            FenPlayer().run(link, 'video', {'info': title})
        except:
            logger(f'---myustv - Exception: \n{traceback.print_exc()}\n', __name__)
            notification('Infinite No Channel Found', 500)
            return

    def addDirectory(self, items, isfolder=True):
        if items is None or len(items) is 0:
            notification('Infinite No Channel Found', 2000)
            sysexit()
        from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
        __handle__ = int(argv[1])
        for i in items:
            try:
                name = i['name']
                if i['image'].startswith('http'):
                    thumb = i['image']
                else:
                    thumb = self.thumb
                url_params = {'mode': i['action'], 'title': name, 'url': i['url']}
                url = build_url(url_params)

                # logger(f'>>>> {url}', __name__)
                listitem = kodi_utils.make_listitem()
                listitem.setLabel(name)
                listitem.setProperty('IsPlayable', 'true')
                listitem.setInfo("mediatype", "video")
                listitem.setArt({
                    'icon': thumb,
                    'fanart': fanart})
                kodi_utils.add_item(handle=__handle__, url=url, listitem=listitem, isFolder=isfolder)
            except Exception:
                pass
        kodi_utils.set_content(__handle__, 'addons')
        kodi_utils.end_directory(__handle__)
