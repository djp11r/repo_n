# -*- coding: utf-8 -*-
import json
import os
import re
import sys
import traceback

from urllib.parse import quote_plus, urljoin

from indexers.hindi.live_client import r_request, agent, unescape, find_season_in_title, next_icon
from caches.h_cache import metacache
from modules.dom_parser import parseDOM
from modules.utils import to_utf8, replace_html_codes, remove_accents
from modules.kodi_utils import logger

desirule_url = "https://www.desirulez.cc:443"


def fetch_meta(mediatype, title, homepage, poster='hindi_movies.png', studio='Hindi', plot='', genre='', year=2022, cast=[], imdb_id='', rating=5.0):
    title_tm = keepclean_title(title, mediatype)
    if mediatype == 'movie': tmdb_id = f'{title_tm.lower()}|{year}'
    else: tmdb_id = f'{studio}|{title_tm.lower()}'
    meta = metacache.get(mediatype, 'tmdb_id', tmdb_id)
    # logger(f'shows desirulez meta: {str(meta)}')
    if meta is None:
        imdbdata = {}
        meta = populet_dict(mediatype=mediatype, title=title, homepage=homepage, poster=poster, studio=studio, tmdb_id=tmdb_id, plot=plot, genre=genre, year=year, cast=cast, imdb_id=imdb_id, rating=rating)
        try: imdbdata = get_datajson_imdb(title, year, mediatype)
        except: pass
        if imdbdata:
            logger(f'imdb_id imdbdata: {imdbdata}')
            meta = meta_merge_update(meta, imdbdata)
        metacache.set(mediatype, to_utf8(meta))
    return meta


def uniquify(string):
    """
    Remove duplicates
    :param string: 'Comedy, Drama, Biography, Drama, Sport'
    :return: 'Comedy, Biography, Drama, Sport'
    """
    output = []
    # seen = set()
    # for word in string.split(','):
    #     if word not in seen:
    #         output.append(word.strip())
    #         seen.add(word)
    # logger(seen)
    [output.append(n.strip()) for n in string.split(',') if n.strip() not in output]
    return ', '.join(output)


def get_tv_shows_desitelly(params):
    # logger(f"params: {params}")
    base_url = params['url']
    ch_name = params['ch_name']
    # iconImage = params['iconImage']
    show_page = r_request(base_url, headers={"User-Agent": agent(), }).text
    # show_page = read_write_file(file_n='www.desi-serials.cc.html')
    # rawResult = parseDOM(show_page, "ul", attrs={"class": "children"})
    result = parseDOM(show_page, "div", attrs={"class": "vc_column_container col-md-3"})
    result += parseDOM(show_page, "div", attrs={"class": "vc_column_container col-md-4"})
    # logger(f"result shows: {result}")
    shows = []
    nos_items = 0
    for item in result:
        if item:
            # nos_items += 1
            # if nos_items > 2: break
            url = parseDOM(item, 'a', ret='href')[0]
            lch_name = url.split('/')
            chan_name = lch_name[4]
            # logger(f"chan_name: {chan_name} lch_name:{lch_name}")
            if chan_name:
                imgurl = parseDOM(item, 'img', ret='src')
                if type(imgurl) is list and len(imgurl) > 0: imgurl = imgurl[0]
                # logger(f"url: {url} imgurl:{imgurl}")
                if "www.desi-serials.cc" in base_url:
                    # logger(f"item: {item} ")
                    if imgurl.startswith('/images'): imgurl = "https://www.desi-serials.cc{}".format(imgurl)
                    try:
                        title = parseDOM(item, "a", attrs={"class": "porto-sicon-title-link"})[0]
                        title_overview = parseDOM(item, "div", attrs={"class": "porto-sicon-header"})[0]
                        genre = re.findall(r'<\/h5>\s+(.+?)$', title_overview)
                        # logger(f"1 desi-serials title: {title} ,genre: {genre} ")
                    except:
                        title_overview = parseDOM(item, "div", attrs={"class": "porto-sicon-header"})[0]
                        title_overview = re.findall(r'porto-sicon-title-link.+>(.+?)<\/a><\/h5>(.+?)$', title_overview)[0]
                        title = title_overview[0]
                        genre = title_overview[1]
                        # logger(f"2 desi-serials title: {title} ,genre: {genre} ")
                else:
                    if imgurl.startswith('/images'): imgurl = f"https://playdesi.tv{imgurl}"
                    genre = parseDOM(item, 'p')[0]
                    title = parseDOM(item, 'h4', attrs={"class": "porto-sicon-title"})[0]
                    # logger(f"for playdesi: title: {title} ,genre: {genre} ")
                title = title.replace('(Gujarati)', '')
                title = unescape(title)
                # fmt = re.sub(r'([Ss]eason) \d{1,2}|[Ss]\d{1,2}', '', title) # clean title from (Season 1|Season 2|S01|S02)
                tmdb_id = f'{ch_name}|{title}'
                meta = metacache.get('tvshow', 'tmdb_id', tmdb_id)
                if meta is None:
                    # logger(f"@@@@@@\ntmdb_id : {tmdb_id}")
                    plotdata, rating, genre = get_plot_tvshow(url)
                    # genre += genrex
                    # logger(f'1 plotdata: {plotdata}')
                    # plotdata = unescape(plotdata)
                    # if type(genre) is list: genre = ', '.join(x.strip() for x in genre if x != '')
                    # genre = genre.replace('.', '').replace(' :', ',')
                    # if plotdata: plotdata = f": {genre} :- \n: {plotdata}"
                    # else: plotdata = f": {genre} :-"
                    meta = fetch_meta(mediatype='tvshow', title=title, studio=ch_name, plot=plotdata, poster=imgurl, homepage=url, genre=genre, rating=rating)
    #             shows.append({"url": url, "title": title, "ch_name": ch_name, "tmdb_id": tmdb_id, "meta": meta})
    # logger(f'len(shows): {len(shows)} shows :  {shows}')
    # return shows


def get_plot_tvshow(show_url=None):
    episo_page = r_request(show_url, headers={"User-Agent": agent(), }).text
    # episo_page = read_write_file(file_n='www.desi-serials.cc.html')
    # logger(f"episo_page: {episo_page}")
    result1 = parseDOM(episo_page, "div", attrs={"class": "main-content col-lg-9"})
    result1 += parseDOM(episo_page, "div", attrs={"class": "blog-posts posts-large posts-container"})
    # logger(f"result1: {result1}")
    # ## for overview <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    plot = genre = ''
    rating = 5.0

    result = parseDOM(result1, "div", attrs={"id": "content"})
    # logger(f"result: {result[0]}")
    p = parseDOM(result, 'div', attrs={"class": "page-content"})
    p = parseDOM(p, 'div', attrs={"class": "page-content"})
    # logger(f"p1: {p}")
    if p:
        title_overview = re.findall(r'<p>(.+?)</p>', str(p))
        # logger(f"title_overview: {title_overview}")
        try: plot = title_overview[0].replace('<br/><br/>', '').replace('\\n', '').strip()
        except: pass
        # logger(f"plot: {plot}")
        try:
            rest_ofp = title_overview[1].replace('<br/><br/>', '').replace('\\n', '').strip()
            # logger(f"rating: {rest_ofp}")
            rating = re.findall(r'Show Rating: </span>\s+(.+?)/.+? <p>', rest_ofp)[0]
            # logger(f"rating: {rating}")
            genre = re.findall(r'Genre: </span>\s+(.+?)$', rest_ofp)[0]
            # logger(f"plot: {plot}\nrating: {rating}, genre: {genre}")
        except: pass
    else:
        # logger(f'result:  {result}')
        try: plot = re.findall(r'loading="lazy" \/><\/div>(.*?)<p>.+?<span', str(result), re.M)[0].strip()
        except: pass
        try:
            genre = re.findall(r'<span.+?font-weight:bold">(.+?)<\/span>', str(result), re.M)[0]
            if 'on:' in genre:
                genre = genre.split(':')[1].strip()
                # genre = genre.replace('Show is Aired on:', '').strip()
        except: pass
    # logger(f"genre: {genre} plot: {plot}")

    if type(genre) is list: genre = ', '.join(x.strip() for x in genre if x != '')
    genre = genre.replace('.', '').replace(' :', ',').replace('&#8211;', ' ').replace('&#8230;', '').strip()
    plot = unescape(plot)
    plot = f'{genre}\n{plot}'
    return plot, rating, genre


def meta_merge_update(meta, imdbdata):
    # logger(f'meta_merge_update meta: {meta}\n imdbdata: {imdbdata}')
    try:
        if imdbdata['genre'] != '':
            if meta['genre'] == '': genre = f"{imdbdata['genre']}"
            else: genre = f"{meta['genre']}, {imdbdata['genre']}"
            # genre.replace('.', '').replace(' :', ',')
            meta.update({'genre': uniquify(genre)})
    except: logger(f'shows desirulez Error: {traceback.print_exc()}', __name__)
    if meta['plot'] == '' and imdbdata['plot'] != '':
        # plot = unescape(imdbdata['plot'])
        meta.update({'plot': imdbdata['plot']})
    if 'hindi_' in meta['poster'] and imdbdata['poster'] != '': meta.update({'poster': imdbdata['poster']})
    if imdbdata['duration']: meta.update({'duration': imdbdata['duration']})
    if imdbdata['mpaa']: meta.update({'mpaa': imdbdata['mpaa']})
    if imdbdata['imdb_id']: meta.update({'imdb_id': imdbdata['imdb_id']})
    if imdbdata['year']: meta.update({'year': imdbdata['year']})
    if imdbdata['rating'] != '': meta.update({'rating': imdbdata['rating']})
    if imdbdata['episodes'] != 0: meta.update({'episodes': imdbdata['episodes']})
    if imdbdata['seasons'] != 0: meta.update({'seasons': imdbdata['seasons']})
    return meta


def get_movies_desicinemas():
    params = {'pg_no': '1', 'ch_name': 'Hindi'}
    pg_no = params['pg_no']
    ch_name = params['ch_name']

    m_url = 'https://desicinemas.tv/movies/'
    # m_url = 'https://desicinemas.tv/movies/page/2/'
    result = r_request(m_url, headers={"User-Agent": agent(), }).text
    result = to_utf8(remove_accents(result))
    result = result.replace('\n', ' ')
    # result = read_write_file(file_n='https://desicinemas.tv.html')
    # logger(f'result: {result}')
    # result = parseDOM(result, "div", attrs={"class": "Main Container"})
    results = parseDOM(result, "li", attrs={"class": "TPostMv post-.+?"})
    # logger(f"total episodes: {len(result)} result: {result}")
    movies = []
    # r = [(parseDOM(i, 'a', ret='href'), parseDOM(i, 'a', ret='title'), parseDOM(i, 'a')[0]) for i in results]
    # logger(f'r: {r}\n >>>.')
    nos_items = 0
    for i in results:
        nos_items += 1
        # if nos_items > 5: break
        # logger(f'item: {i}\n >>>.')
        try:
            url = parseDOM(i, 'a', ret='href')[0]
            title = parseDOM(i, "h2", attrs={"class": "Title"})[0]
            try:
                year = parseDOM(i, "span", attrs={"class": "Qlty Yr"})[0]
                if not year: year = parseDOM(i, "span", attrs={"class": "Date"})[0]
            except: year = '2021'
            # logger(f'genre: {year}\n >>>.')
            # logger(f'cast: {cast} genre: {genre}')
            # logger(f'url: {Descri}')
            if '(Punjabi)' in title: continue
            title = unescape(title.title())
            tmdb_id = f"{title}|{year}"
            imgurl = parseDOM(i, 'img', ret='data-src')[0]
            Descri = parseDOM(i, "div", attrs={"class": "Description"})[0]
            plot = unescape(parseDOM(Descri, "p")[0])
            genre = parseDOM(Descri, "p", attrs={"class": "Genre"})
            genre = parseDOM(genre, "a")
            if type(genre) is list: genre = ', '.join(x.strip() for x in genre if x != '')
            cast = parseDOM(Descri, "p", attrs={"class": "Cast"})
            cast = parseDOM(cast, "a")
            meta = fetch_meta(mediatype='movie', title=title, year=year, plot=plot, poster=imgurl, homepage=url, genre=genre, cast=cast)

            movies.append({
                'year': year,
                'ch_name': ch_name,
                'url': url,
                'tmdb_id': tmdb_id,
                'meta': meta,
                'pg_no': pg_no,
                'title': f'{title}'})
        except:
            logger(f"get_movies_desicinemas {traceback.print_exc()}", __name__)
    # logger(f'total movies: {len(movies)} movies: {movies}')

    # ## Next page
    next_p = parseDOM(result, "div", attrs={"class": "nav-links"})
    # logger(f"next_p: {next_p}")
    if next_p:
        try:
            # next_p_u = parseDOM(next_p, "a", attrs={"class": "page-link"}, ret="href")[1]
            next_p_u = parseDOM(next_p, "a", ret="href")[-1]
            # logger(f"next_p_u: {next_p_u}")
            pg_no = re.compile('/([0-9]+)/').findall(next_p_u)[0]
            # logger(f"pg_no: {pg_no}")
            title = f"Next Page: {pg_no}"
            movies.append({
                    'year': '',
                    'ch_name': ch_name,
                    'url': next_p_u,
                    'tmdb_id': '',
                    'meta': {'poster': next_icon, 'plot': f"For More: {ch_name} Movies Go To: {title}", 'genre': ['-']},
                    'pg_no': pg_no,
                    'title': title})
        except: logger(f"get_movies_desicinemas {traceback.print_exc()}", __name__)
    # logger(f'total movies: {len(movies)} movies: {movies}')
    # return movies


def get_movies_desirulez():
    non_str_list = ['+', 'season', 'episode']
    params = {'pg_no': '1', 'ch_name': 'Hindi'}
    pg_no = params['pg_no']
    ch_name = params['ch_name']

    m_url = 'https://www.desirulez.cc:443/forumdisplay.php?f=20'
    # m_url = 'http://www.desirulez.cc/latest-and-exclusive-movie-hq-2.html'
    movies_page = r_request(m_url, headers={"User-Agent": agent(), }).text
    # movies_page = read_write_file(file_n='www.desirulez.cc:443.html')
    # result = parseDOM(m_page, "div", attrs={"class": "Main Container"})
    result = parseDOM(movies_page, "h3", attrs={"class": "threadtitle"})
    movies = []
    nos_items = 0
    for item in result:
        nos_items += 1
        if nos_items > 50: break
        # logger(f'item: {item}')
        try: title = parseDOM(item, "a", attrs={"class": "title threadtitle_unread"})[0]
        except:
            title = parseDOM(item, "a", attrs={"class": "title"})
            title = title[0] if title else parseDOM(item, "a")[0]
        # title = title#.encode('ascii', 'ignore')
        # logger(f'title: {title}')
        try: parsed = re.compile(r'(.+) [\(](\d+|\w+ \d+|\w+)[\)]').findall(str(title))[0]
        except: parsed = '', ''
        title = parsed[0]
        year = parsed[1]
        if not re.search(r'\d{4}', year):
            try: year = re.search(r'\d{4}', title).group()
            except: year = 2022
        # logger(f'title: {title} year: {year}')
        url = parseDOM(item, "a", ret="href")
        if not url: url = parseDOM(item, "a", attrs={"class": "title"}, ret="href")
        if type(url) is list and len(url) > 0: url = str(url[0])
        url = urljoin(desirule_url, url) if not url.startswith(desirule_url) else url
        if title and not any([x in title for x in non_str_list]):
            tmdb_id = f"{title.strip().title()}|{year}"
            meta = fetch_meta(mediatype='movie', title=title, year=year, homepage=url)
            movies.append({'year': year, 'ch_name': ch_name, 'url': url, 'tmdb_id': tmdb_id, 'meta': meta, 'pg_no': pg_no, 'title': f'{title}'})

    next_p = parseDOM(movies_page, "span", attrs={"class": "prev_next"})
    if next_p:
        next_p_url = parseDOM(next_p, "a", attrs={"rel": "next"}, ret="href")[0]
        if "?" in next_p_url: url = next_p_url.split("?")[0]
        else: url = next_p_url
        try:
            pg_no = re.compile(r'page\d{1,2}').findall(url)[0]
            pg_no = pg_no.replace('page', '')
            # logger(f"pg_no: {pg_no}")
        except:
            pg_no = '1'  #re.compile('-([0-9]+).html').findall(url)[0]
        title = f"Next Page: {pg_no}"
        if url.startswith('forumdisplay'):
            url = f"https://www.desirulez.cc:443/{url}"
        movies.append({'year': '', 'ch_name': ch_name, 'url': url, 'tmdb_id': '', 'meta': {'poster': next_icon, 'plot': f"For More: {ch_name} Movies Go To: {title}", 'genre': ''}, 'pg_no': pg_no, 'title': title})
    # movies = json.dumps(movies, default = hindi_sources.dumper, indent = 2)
    # logger(f'total movies: {len(movies)} movies: {movies}')


def populet_dict(mediatype, title, homepage, poster, studio, tmdb_id, plot, genre, year, cast, imdb_id, rating):
    """
    :useges
    meta = populet_dict(mediatype='movie', title=title, year=year,
                        studio=ch_name, plot='', fanart=imgurl,
                        genre='', tvshowtitle=None, imdb_id=imdb)
    :param mediatype:
    :param title:
    :param studio:
    :param homepage:
    :param poster:
    :param tmdb_id:
    :param plot:
    :param year:
    :param genre:
    :param cast:
    :param imdb_id:
    :param rating:
    :return: dict
    """
    # if not year: year = 2021
    # if mediatype == 'movie': tmdb_id = f'{title}|{year}'
    # else: tmdb_id = f'{studio}|{title}'
    if imdb_id == '': imdb_id = tmdb_id
    try:
        special_path = 'special://home/addons'
        if 'addons\\plugin.video.infinite' in poster:
            poster = "%s%s" % (special_path, poster.split('addons')[1])
            poster = poster.replace('\\', '/')#.replace('\\/', '/')
    except:
        logger(f"homepath not found: {traceback.print_exc()}")
    if cast is None: cast = [{'role': '', 'name': '', 'thumbnail': ''}]
    # logger(f'IN genre: {genre} plot: {plot}')
    # if type(genre) is list: genre = ', '.join(x.strip() for x in genre if x != '')
    # genre = genre.replace('.', '').replace(' :', ',').replace('&#8211;', ' ')
    # if plot: plot = f": {genre} :- \n: {unescape(plot)}"
    # else: plot = f": {genre} :-"
    # logger(f'OUT genre: {genre} plot: {plot}')
    dic_meta = {'mediatype': mediatype,
                'year': year,
                'plot': plot,
                'title': title,
                'studio': studio,
                'poster': poster,
                'homepage': homepage,
                'genre': genre, #'Animation, Music, Documentary',
                'cast': cast,
                'tmdb_id': tmdb_id,
                'imdb_id': imdb_id,
                'rating': rating,
                'clearlogo': '', 'trailer': '',
                'votes': 50, 'tagline': '', 'director': '',
                'writer': '', 'episodes': 0, 'seasons': 0,
                'extra_info': {'status': '', 'collection_id': ''}}
    if mediatype == 'movie':
        dic_meta.update({
                      'tvdb_id': 'None',
                      'duration': 5400,
                      'mpaa': 'R'})
                      # 'search_title': '%s %s' % (title, year), 'original_title': '%s' % title, 'rootname': '%s %s' % (title, year)}
                      # 'fanart': '', 'imdbnumber': '', 'premiered': '', 'clearart': '', 'rating': 8.0,
                      # 'alternative_titles': [], 'fanart_added': False, 'landscape': '',
                      # 'extra_info': {'status': 'Released', 'revenue': '$0', 'collection_name': None,
                      #                'budget': '$0', 'collection_id': None, 'homepage': ''},
                      # 'votes': 50, 'mpaa': '', 'writer': '', 'director': '', 'banner': '',
                      # 'all_trailers': [], 'discart': '', 'clearlogo': '', 'tagline': '', 'trailer': ''}
    else:
        dic_meta.update({
                        'tvdb_id': imdb_id,
                        'duration': 1320,
                        'mpaa': 'TV-MA',
                        'episode': '',
                        'tvshowtitle': title})

                   # 'rootname': '%s %s' % (title, year), 'original_title': '%s' % title, 'search_title': '%s' % title,
                   # 'fanart': '', 'clearart': '', 'imdbnumber': '', 'premiered': '',
                   # 'season_data': [{'poster_path': '', 'name': '', 'air_date': '', 'overview': '',
                   #                  'episode_count': 2, 'season_number': 1, 'id': ''},
                   #                 {'poster_path': '', 'name': 'Season 1', 'air_date': '', 'overview': '',
                   #                  'episode_count': 13, 'season_number': 1, 'id': ''}],
                   # 'landscape': '', 'total_seasons': 1, 'banner': '', 'clearlogo': '',
                   # 'extra_info': {'status': 'Series', 'next_episode_to_air': 'N/A', 'created_by': '',
                   #                'homepage': '', 'last_episode_to_air': '', 'type': 'Scripted'},
                   # 'alternative_titles': [], 'total_episodes': 75, 'fanart_added': False, 'rating': 8.5,
                   # 'votes': 40, 'mpaa': 'TV-14', 'writer': '', 'director': '', 'all_trailers': [],
                   # 'discart': '', 'tagline': '', 'season_summary': {'airedEpisodes': 10, 'airedSeasons': 1,
                   #                                                  'seasonNumbers': ['1']}, 'trailer': ''}

    # if mediatype == 'movie': dic_link = movie_dic_meta
    # else: dic_link = tv_dic_meta
    return dic_meta


def get_meta_from_db(type):
    metas = metacache.get_all(type, 'metadata', 1000)
    # metas = metacache.get_all('tvshow', 'metadata', 500)
    # # logger(metas)
    metalist = []
    for meta in metas:
        result = eval(meta)
        metalist.append(result)
        # logger(result.get('title'))
    # logger(metalist)
    return metalist


def imdb_search(title, year, mediatype):
    imdb_id = None
    if 'Season' in title: title = title.split('Season')[0].strip()
    # url = 'https://www.imdb.com/find?q=%s&s=tt&exact=true&ref_=fn_al_tt_ex' % quote_plus(title)
    if mediatype == 'movie': search_url = f'https://www.imdb.com/find?q={quote_plus(title)}&s=tt&ttype=ft&ref_=fn_ft'
    else:  search_url = f'https://www.imdb.com/find?q={quote_plus(title)}&s=tt&ttype=tv&ref_=fn_tv'
    # search_url = f'https://www.imdb.com/find?q={quote_plus(title)}&ref_=nv_sr_sm'
    # logger(f'>>>>>>> imdb_item_search url: {search_url}')
    try:
        result = r_request(search_url, headers={"User-Agent": agent(), }).text
        # result = to_utf8(remove_accents(result))
        # result = result.replace('\n', ' ')
        # result = read_write_file(file_n='www.imdb.com.html')
        # result = py_tools.ensure_str(result)
        items = parseDOM(result, 'table', attrs={'class': 'findList'})  # items += parseDOM(result, 'div', attrs={'class': 'list_item.+?'})  # items += parseDOM(result, 'div', attrs={'class': 'lister-list.+?'})
    except Exception:
        logger(f"imdb_item_search Error: {traceback.print_exc()}")
        return None
    # logger(f"items: {items}")
    # m_dict = {}
    for item in items:
        # logger(f"item: {item}")
        found_title = parseDOM(item, 'a')[1]
        if ':' in found_title: found_title = found_title.split(':')[0]
        # logger(f"b4 clean title: {found_title}")
        # found_title = unescape(found_title)
        # found_title = re.sub(r'\(\d+\)', '', found_title)
        # logger(f"title: {repr(title.lower())} otitle: {repr(found_title.lower())}")
        # if found_title.lower() in title.lower():
        imdb_id = re.findall(r'(tt\d*)', str(item))[0]
        break

    if not imdb_id:
        if title == 'war': imdb_id = 'tt7430722'
        elif title == 'line of descent': imdb_id = 'tt2257284'
        elif title == 'ishq aaj kal ': imdb_id = 'tt11199474'
        elif title == 'is she raju': imdb_id = 'tt9861220'
        elif title == 'good newwz': imdb_id = 'tt8504014'
        elif title == 'bhoot part one: The Haunted Ship': imdb_id = 'tt10463030'
        elif title == 'gandi baat': imdb_id = 'tt8228316'
        elif title == 'meera mathur': imdb_id = 'tt14941996'
        elif title == 'haseen dillruba': imdb_id = 'tt11027830'
        elif title == 'kem chho': imdb_id = 'tt11569584'
    return imdb_id


def get_datajson_imdb(title, year, mediatype='movie', oimdb_id=None):
    if not oimdb_id: oimdb_id = imdb_search(title, year, mediatype)
    if mediatype == 'movie':
        cduration = 5400
        cmpaa = 'MA'
    else:
        cduration = 1500
        cmpaa = 'TV-MA'
    url = f'https://www.imdb.com/title/{oimdb_id}/'
    logger(f'data may b on url: {url}')
    if not oimdb_id: return
    result = r_request(url, headers={"User-Agent": agent(), }).text
    # result = read_write_file(file_n='www.imdb.com.html')
    genres = ''
    metadict = {'title': '', 'year': '', 'rating': 5.0, 'plot': '', 'imdb_id': oimdb_id, 'mpaa': cmpaa, 'duration': cduration, 'genre': '', 'poster': '', 'episodes': 0, 'seasons': 0}
    try:
        items = parseDOM(result, 'script', attrs={'id': '__NEXT_DATA__'})
        # logger(f'items type: {type(items)} items: {repr(items)}')
        # logger(f'Total: {len(items)}')
        data_items = re.findall(r'"data":(.+?)}}', items[0])
        for item in data_items:
            if oimdb_id in item and "topTrendingSetsPredefined" not in item:
                item_dict = item+"}}"
                # logger(f'item type: {len(item)} data_items: {item_dict}')
                item_meta = json.loads(item_dict)
                item_meta = item_meta["title"]
                # logger(f'type: {item_meta["id"]}')
                # item_meta = v["data"]["title"]
                # logger(f'data: {item_meta}')
                title = item_meta['titleText']['text']
                # logger(f'titleText   : {title}')
                try:
                    year = item_meta['releaseYear']['year']
                    # logger(f'year        : {year}')
                    metadict.update({'year': year})
                except: pass
                try:
                    ratings = item_meta['ratingsSummary']['aggregateRating']
                    # logger(f'ratings     : {ratings}')
                    metadict.update({'rating': ratings})
                except: pass
                try:
                    rgen = item_meta['genres']['genres']
                    # logger(f'rgen: {rgen}')
                    genres = ', '.join(str(x['text']) for x in rgen if x != '')
                    # logger(f'rgen: {genres}')
                    metadict.update({'genre': genres})
                except: pass
                try:
                    plot = item_meta['plot']['plotText']['plainText']
                    # logger(f'plot        : {plot}')
                    plot = unescape(plot)
                    if plot: plot = f": {genres} :- \n: {plot}"
                    else: plot = f": {genres} :-"
                    metadict.update({'plot': plot})
                except: pass
                # imdb_id = item_meta['id']
                # logger(f'id          : {imdb_id}')
                try:
                    certf = item_meta['certificate']['rating']
                    # logger(f'rating      : {certf}')
                    metadict.update({'mpaa': certf})
                except: pass
                try:
                    runtime = item_meta['runtime']['seconds']
                    # logger(f'runtime     : {runtime}')
                    metadict.update({'duration': runtime})
                except: pass
                try:
                    poster = item_meta['primaryImage']['url']
                    # logger(f'url         : {poster}')
                    metadict.update({'poster': poster})
                except: pass
                try:
                    episodes = item_meta['episodes']['episodes']['total']
                    seasons = item_meta['episodes']['seasons']
                    seasons = ', '.join(str(x['number']) for x in seasons if str(x) != '')  # seasons = [x['number'] for x in seasons if x != '']
                    # seasons = ', '.join(seasons)
                    # logger(f'episodes: {episodes} seasons: {seasons}')
                    metadict.update({'episodes': episodes, 'seasons': seasons})
                except: pass
                metadict.update({'title': title})
    except:
        logger(f"get_datajson_imdb Error: {traceback.print_exc()}")
        items = parseDOM(result, 'div', attrs={'class': 'ipc-page-content-container.+?'})
        try:
            title_wrapper = parseDOM(items, 'div', attrs={'class': 'TitleBlock__TitleContainer.+?'})
            # logger(f'total: {len(title_wrapper)} items: {title_wrapper}')
            title = parseDOM(title_wrapper, 'h1', attrs={'class': 'TitleHeader__TitleText.+?'})[0]
        except: title = title
        try:
            year_wrapper = parseDOM(items, 'span', attrs={'class': 'TitleBlockMetaData__ListItemText.+?'})
            year = re.findall(r'(\d{4})', year_wrapper[0])[0]
        except: year = year
        try:
            duration_wrapper = parseDOM(items, 'ul', attrs={'class': '.+?TitleBlockMetaDat.+?'})
            duration = parseDOM(duration_wrapper, 'li', attrs={'class': 'ipc-inline-list__item'})
            # logger(f'Total: {len(duration)} duration_wrapper: {duration}')
            if mediatype == 'movie': duration = duration[1]
            else: duration = duration[2]
            dur = duration.replace('<!-- -->', '')
            duration = get_sec_string(dur)  # logger(f'duration: {duration}')
        except: duration = cduration
        # logger(f'duration: {duration} year: {year} title_wrapper: {title}')
        try:
            poster = parseDOM(items, 'img', attrs={'class': '.+?ipc-image.+?'}, ret='src')[0]
            # logger(f'poster: {poster}')
            if '/nopicture/' in poster: poster = '0'
            poster = re.sub(r'(?:_SX|_SY|_UX|_UY|_CR|_AL)(?:\d+|_).+?\.', '_SX500.', poster)
            poster = replace_html_codes(poster)
        except: poster = 'hindi_movies.png'
        try:
            # genresplot_wrapper = parseDOM(items, 'div', attrs={'class': '.+?GenresAndPlot__ContentParent.+?'})
            # logger(f'Total: {len(genresplot_wrapper)} duration_wrapper: {genresplot_wrapper}')
            genres_wrapper = parseDOM(items, 'a', attrs={'class': '.+?GenresAndPlot__GenreChip.+?'})
            genres = [item.replace('<span class="ipc-chip__text" role="presentation">', '').replace('</span>', '') for item in genres_wrapper if item]
            # logger(f'Total: {len(genres)} genres: {genres}')
            # logger(f'genres: {genres}')
            if not genres: genres = ''
            else:
                if type(genres) is list: genres = ', '.join(x.strip() for x in genres if x != '')
                genres = genres.replace('.', '').replace(' :', ',').replace('&#8211;', ' ')
        except: genres = ''
        try:
            plot_wrapper = parseDOM(items, 'p', attrs={'class': '.+?GenresAndPlot__Plot.+?'})
            # logger(f'plot_wrapper: {plot_wrapper}')
            plot = parseDOM(plot_wrapper, 'span', attrs={'class': 'GenresAndPlot__TextContainerBreakpoint.+?'})[0]
            plot = span_clening(plot)
            logger(f'plot: {plot}')
        except: plot = ''
        try:
            rating_wrapper = parseDOM(items, 'div', attrs={'class': 'AggregateRatingButton__ContentWrap.+?'})
            rating = parseDOM(rating_wrapper, 'span', attrs={'class': 'AggregateRatingButton__RatingScore.+?'})[0]
            # logger(f'Total: {len(rating)} rating_wrapper: {rating}')
            logger(f'rating: {rating}')
        except: rating = 4.5
        try:
            mpaa_wrapper = parseDOM(items, 'div', attrs={'class': 'UserRatingButton.+?'})
            mpaa = parseDOM(mpaa_wrapper, 'div', attrs={'data-testid': 'hero-rating-bar.+?'})
            mpaa = mpaa[0].strip()
            if mpaa == 'Rate': mpaa = cmpaa  # logger(f'mpaa: {mpaa}')
        except: mpaa = cmpaa
        if plot: plot = f": {genres} :- \n: {unescape(plot)}"
        else: plot = f": {genres} :-"
        metadict.update({'title': title, 'year': year, 'rating': rating, 'plot': plot, 'mpaa': mpaa, 'duration': duration, 'genre': genres, 'poster': poster})

    # logger(f'>>> {metadict}')
    return metadict


def get_sec_string(str_time):
    min_str = re.compile(r'(\d+)[m|min]')
    hrs_str = re.compile(r'(\d+)h')
    hrs_s = re.findall(hrs_str, str_time)
    if hrs_s: hrs_s = int(hrs_s[0]) * 60 * 60
    else: hrs_s = 0
    min_s = re.findall(min_str, str_time)
    if min_s: min_s = int(min_s[0]) * 60
    else: min_s = 0
    duration = hrs_s + min_s
    # logger(duration)
    return duration


def span_clening(span_text):
    span_text = span_text.rsplit('<span>', 1)[0].strip()
    span_text = re.sub('<.+?>|</.+?>', '', span_text)
    span_text = re.sub('\xa0', ' ', span_text)
    span_text = re.sub('See all certifications', '', span_text)
    if '...' in span_text: span_text = span_text.split('...')[0]
    if 'add a plot' not in span_text.lower():
        span_text = replace_html_codes(span_text)
        span_text = unescape(span_text)
        span_text.strip().replace('\\n', '')
    else: span_text = ''
    return span_text


def get_duplic(links_list):
    # links_list = [{'title': 'Anwar Ka Ajab Kissa','tmdb_id': 'Anwar Ka Ajab Kissa|2013'}, {'title': 'Anwar Ka Ajab Kissa','tmdb_id': 'Anwar Ka Ajab Kissa|2020'}, {'title': 'Ardhangini','tmdb_id': 'Ardhangini|1959'}, {'title': "Class Of '83",'tmdb_id': "Class Of '83|2020"}, {'title': 'Class Of 83','tmdb_id': 'Class Of 83|2020'}, {'title': 'Julie','tmdb_id': 'Julie|1975'}, {'title': 'Julie','tmdb_id': 'Julie|Season 1'} ]
    # logger(f"strating len: {len(links_list)}")
    uniqueValues = list()
    duplicateValues = list()
    duplicatedict = []
    for d in links_list:
        if d["title"].lower() not in uniqueValues:
            uniqueValues.append(d["title"].lower())
        else:
            duplicateValues.append(d["title"])
            duplicatedict.append(d)
    # logger(f"List of Duplicate values in Dictionary: {duplicateValues} \n {duplicatedict}")
    return duplicateValues


def get_duplicate_dict_from_db_and_fixed():

    db_type = 'tvshow'
    # db_type = 'movie'
    metalist = get_meta_from_db(db_type)
    keyValList = get_duplic(metalist)
    logger(f"len of keyValList: {len(keyValList)} keyValList: {keyValList}")
    expectedResult = [d for d in metalist if d['title'] in keyValList]
    logger(f"len of expectedResult: {len(expectedResult)} expectedResult: {expectedResult}")
    # expectedResult = []

    newdict = []
    for d1 in expectedResult:
        for d2 in expectedResult:
            if d1["title"] == d2["title"]:
                if d1["plot"] == "" and d2["plot"] != "":
                    d1.update({"plot": d2["plot"],
                               "genre": d2["genre"],
                               "cast": d2["cast"]})
                if d1["year"] == "0000":
                    d1.update({"year": d2["year"]})
                logger(d1["tmdb_id"], d2["tmdb_id"])
            if d1 not in newdict:
                newdict.append(d1)
    logger(f"final len newdict: {len(newdict)} newdict: {newdict}")
    # newdict = []
    # for i in newdict:
    #     metacache.set(db_type, to_utf8(i))


def get_non_plot():
    mediatype = 'movie'
    mediatype = 'tvshow'
    metalist = get_meta_from_db(mediatype)
    # metalist = get_meta_from_db('tvshow')
    upd_data = 0
    non_data_list = []
    for d in metalist:
        if 'Awards' in d['title']: continue
        logger(f'\ntitle: {d["title"]} >>>> plot: {d["plot"]}')
        # plot = unescape(d["plot"])
        # logger(f'final data: {plot}')
        # d.update({'plot': plot})
        # logger('')

        if d["genre"] is None or d["genre"] == '' or d["genre"] == ['-'] or d["plot"] is None:
            logger('')
            logger(f"title: {d['title']} genre: {d['genre']} plot: {d['plot']}")
            upd_data += 1
            # if upd_data > 2: break
            logger(d)
            logger(f'init data: {d}')
            imdbdata = get_datajson_imdb(d['title'], d['year'], mediatype)
            logger(f'imdbdata: {imdbdata}')
            if imdbdata:
                d = meta_merge_update(d, imdbdata)
            logger(f'final data: {d}')
            if d['mediatype'] == 'tvshow': metacache.set('tvshow', to_utf8(d))
            else: metacache.set('movie', to_utf8(d))
    # logger(non_data_list)


def set_meta(type, meta):
    if type == 'movie': metacache.set('movie', to_utf8(meta))
    else: metacache.set('tvshow', to_utf8(meta))


def getmeta_n_update_common():
    # db_type = 'tvshow'
    db_type = 'movie'
    metalist = get_meta_from_db(db_type)
    upd_data = 0
    ansi_pattern = re.compile(r'[^\x00-\x7f]')
    items = non_data_list = []
    new_search = False
    for d in metalist:
        # if 'House Of Cards' in d['title']: d.update({'imdb_id': 'tt1856010'})
        # elif 'Elite' in d['title']: d.update({'imdb_id': 'tt7134908'})
        # elif 'Aashram' in d['title']: d.update({'imdb_id': 'tt12805346'})
        # elif 'Hai Taubba' in d['title']: d.update({'imdb_id': 'tt14564446'})
        # elif 'Dil Hi Toh Hai' in d['title']: d.update({'imdb_id': 'tt8523124'})
        # elif 'Bang Baang' in d['title']: d.update({'imdb_id': 'tt13155198'})
        # elif 'Modi Cm To Pm' in d['title']: d.update({'imdb_id': 'tt10094918'})
        # elif 'What Are The Odds' in d['title']: d.update({'imdb_id': 'tt12327140'})
        # elif 'Gullak' in d['title']: d.update({'imdb_id': 'tt10530900'})
        # elif 'Super Dancer' in d['title']: d.update({'imdb_id': 'tt10370866'})
        # elif 'Sa Re Ga Ma Pa' in d['title']: d.update({'imdb_id': 'tt1755864'})
        # elif 'Hawkeye' in d['title']: d.update({'genre': 'Action'})

        if d["genre"] is None or d["genre"] == '':
            logger(f"title: {d['title']} genre: {d['genre']}  imdb_id: {d['imdb_id']}")
            new_search = True
        if d["plot"] is None or d["plot"] == ':  :-':
            logger(f"title: {d['title']} plot: {d['plot']}  imdb_id: {d['imdb_id']}")
            new_search = True
        if d["duration"] is None or d["duration"] == 0:
            logger(f"title: {d['title']} duration: {d['duration']}  imdb_id: {d['imdb_id']}")
            new_search = True
        if ':' in d["genre"] or '.' in d["genre"]:
            logger(f"title: {d['title']} genre: {d['genre']}")
            d.update({'genre': d["genre"].replace(' :', ',').replace('.', '')})
        if '\nPlot:' in d["plot"] or 'Add a Plot' in d["plot"]:
            logger(f"title: {d['title']} plot: {d['plot']}")
            plot = d["plot"].replace('\nPlot:', '\n:')
            d.update({'plot': plot})
            if 'Add a Plot' in d["plot"]:
                plot = d["plot"].replace('Add a Plot', ': %s :-' % d["genre"])
                d.update({'plot': plot})
        # logger(f"title: {d['title']} genre: {d['genre']}")
        if d['plot']:
            plot = re.sub(ansi_pattern, '', d['plot'])
            plot = plot.replace('&quot;', '\"').replace('&amp;', '&')
            d.update({'plot': plot})
        # imdbid = re.findall(r'(tt\d*)', str(d['imdb_id']))
        # metacache.set(db_type, to_utf8(d))
        # logger(f"imdbid : {imdbid}")
        if new_search and re.findall(r'(tt\d*)', str(d['imdb_id'])):
            upd_data += 1
            if upd_data > 15: break
            logger(f"imdbid : {d['imdb_id']}")
            imdbdata = get_datajson_imdb(d['title'], d['year'], d['mediatype'], oimdb_id=d['imdb_id'])
            if imdbdata:
                logger(f'imdb_id imdbdata: {imdbdata}')
                d = meta_merge_update(d, imdbdata)
            metacache.set(db_type, to_utf8(d))
            new_search = False
            # logger(f" meta: {meta}")
        # genre = uniquify(d["genre"])
        # logger(f" genre: {genre}")
        # d.update({'genre': genre})
        # items += d["genre"].split(',')
        # non_data_list.append(items)
        # set_meta(db_type, d)


def getmeta_n_update_byid():
    db_type = 'tvshow'
    #db_type =  'movie'
    tmdb_id = 'Eros Now|Modi: Journey of a common man'
    imdb_id = 'Eros Now|Modi: Journey of a common man'
    meta = metacache.get(db_type, 'tmdb_id', tmdb_id)
    n_genre = 'Biography, Drama'
    n_plot = "An inspiring journey of Narendra Modi, from his childhood to his entry into politics."
    year = 2020
    duration = 1320
    rating = 8.0
    mpaa = 'TV-MA'

    plot = f': {n_genre} :-\n{n_plot}'
    if not meta["genre"]:
        meta.update({'genre': n_genre})
    if not meta["plot"]:
        logger(f"title: {meta['title']} plot: {meta['plot']}")
        # meta.update({'plot': plot})
    meta.update({'imdb_id': imdb_id, 'duration': duration, 'rating': rating, 'year': year, 'mpaa': mpaa,
                 'plot': plot, 'genre': n_genre,
                 'poster': 'https://www.desi-serials.cc/wp-content/uploads/2020/11/indian-idol-season-12-300x169.jpg'})
    logger(meta)
    # set_meta(db_type, meta)


def getmeta_n_check_common():
    # db_type = 'tvshow'
    db_type = 'movie'
    metalist = get_meta_from_db(db_type)
    upd_data = 0
    items = non_data_list = []
    for d in metalist:
        # if d["plot"] is None or d["plot"] == '':
        if 'Awards & Concerts' in d['title']:
            d.update({'genre': ''})
        elif 'Dhadkan Zindagi Ki' in d['title']:
            logger(f"genre:  {d['genre'].replace('&#8211;', '-')}")
            logger(f"plot:  {d['plot'].replace('&#8211;', '-')}")
            d.update({'genre': d['genre'].replace('&#8211;', '-'), 'plot': d['plot'].replace('&#8211;', '-')})

        if not d['genre']:
            logger('')
            logger(f"title: {d['title']} genre: {d['genre']}")
            logger(f"duration: {d['duration']} mpaa: {d['mpaa']} rating: {d['rating']} genre: {d['genre']}")
            if 'Ek Thi Begum' in d['title']:
                d.update({'genre': 'Crime, Drama'})
            elif 'Hawkeye' in d['title']:
                d.update({'genre': 'Action'})
            # elif 'Kaamna' in d['title']:
                # d.update({'genre': 'Monday – Friday, Drama'})

        if db_type == "movie":
            if 'Not Rated' in d["mpaa"] or 'TV-MA' in d["mpaa"] or 'MA' in d["mpaa"]:
                # logger(f"title: {d['title']} genre: {d['mpaa']}")
                d.update({'mpaa': 'R'})
            if 'TV-14' in d["mpaa"]:
                # logger(f"title: {d['title']} genre: {d['mpaa']}")
                d.update({'mpaa': 'PG-13'})
        else:
            if 'Not Rated' in d["mpaa"] or 'MA-17' in d["mpaa"] or 'MA' in d["mpaa"]:
                # logger(f"title: {d['title']} genre: {d['mpaa']}")
                d.update({'mpaa': 'TV-MA'})
            if 'TV-14' in d["mpaa"]:
                # logger(f"title: {d['title']} genre: {d['mpaa']}")
                d.update({'mpaa': 'TV-PG'})
        set_meta(db_type, d)


def keepclean_title(title, mediatype):
    if title is None: return
    exctract_date = re.compile(r'(\d{1,2}[th|st|nd|rd]* [Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|August|Sep|September|Oct|October|Nov|November|Dec|December]* \d{2,4})')
    episode_data = re.compile(r'[Ee]pisodes.+?(\d+)|[Ee]p (\d+)|[Ee](\d+)|[sS]eason.+?(\d+)|[sS]eason(\d+)|[sS](\d+)|[cC]hapter.+?(\d+)|seaon.+?(\d+)')
    # ansi_pattern = re.compile(r"(\x9B|\x1B\[)[0-?]*[ -\/]*[@-~]")
    ansi_pattern = re.compile(r'[^\x00-\x7f]')
    try:
        if ':' in title: title = title.split(':')[0]
        if mediatype != 'movie':
            title = re.sub(exctract_date, '', title)  # remove date like 18th April 2021
            title = re.sub(episode_data, '', title)  # remove episod 12 or season 1 etc
        title = re.sub(ansi_pattern, '', title)  # remove ansi_pattern
        title = re.sub(r'&#(\d+);', '', title)
        title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
        title = title.replace('&quot;', '\"').replace('&amp;', '&')
        title = re.sub(r'([:;\-"\',!_?~$@])', '', title)  # remove all characters in bracket
        title = re.sub(r'\<[^>]*\>|\([^>]*\)', '', title)  # remove like this <any thing> or (any thing)
        return title.strip()
    except: return title


def get_tmdb_id_common():
    db_type = 'tvshow'
    db_type = 'movie'
    # metalist = get_meta_from_db(db_type)

    from h_cache import MetaCache
    old_metacache = MetaCache('list_data/lagcy_metacache.db')
    old_metas = old_metacache.get_all(db_type, 'metadata', 2000)
    # metas = metacache.get_all('tvshow', 'metadata', 500)
    # # logger(metas)
    old_meta_list = []
    for meta in old_metas:
        result = eval(meta)
        old_meta_list.append(result)

    upd_data = 0
    items = non_data_list = []
    for d in old_meta_list:
        meta = metacache.get(db_type, 'tmdb_id', d['tmdb_id'])
        if not meta:
            print(f'd: {d["tmdb_id"]}')
            items.append(d)
        # chnname, tmdb_id = d['tmdb_id'].split('|')
        # if db_type != 'movie':
        #     namecl = keepclean_title(tmdb_id, db_type)
        #     newtmdb = "{}|{}".format(chnname, namecl.lower())
        # else:
        #     namecl = keepclean_title(chnname, db_type)
        #     newtmdb = "{}|{}".format(namecl.lower(), tmdb_id)
        # logger(f"title: {d['tmdb_id']} tmdb_id: {newtmdb}")
        # # if d["plot"] is None or d["plot"] == '':
        # d.update({'tmdb_id': newtmdb})
        # set_meta(db_type, d)
        # if db_type == 'movie': old_metacache.set('movie', to_utf8(d))
        # else: old_metacache.set('tvshow', to_utf8(d))
    print(items)


# if __name__ == "__main__":
#     testing = True
#     # metacache.check_database()
#     try:
#         logger(sys.version_info)
#         regul_tv = [{'ch_name': 'Sab TV', 'pg_no': '1', 'url': 'https://www.desi-serials.cc/sab-tv-hd/'},
#                     {'ch_name': 'Sony', 'pg_no': '1', 'url': 'https://www.desi-serials.cc/sony-tv/'},
#                     {'ch_name': 'Colors', 'pg_no': '1', 'url': 'https://www.desi-serials.cc/color-tv-hd/'},
#                     {'ch_name': 'Zee', 'pg_no': '1', 'url': 'https://www.desi-serials.cc/zee-tv/'},
#                     {'ch_name': 'Star Plus', 'pg_no': '1', 'url': 'https://www.desi-serials.cc/star-plus-hdepisodes/'}]
#         web_tv = [{'ch_name': 'SonyLiv', 'pg_no': '1', 'url': 'https://playdesi.tv/sonyliv/'},
#                   {'ch_name': 'Gujarati web series', 'pg_no': '1', 'url': 'https://playdesi.tv/gujarati-web-series/'},
#                   {'ch_name': 'Voot', 'pg_no': '1', 'url': 'https://playdesi.tv/voot/'},
#                   {'ch_name': 'Zee5 Web Series', 'pg_no': '1', 'url': 'https://playdesi.tv/zee5/'},
#                   {'ch_name': 'Mx Player', 'pg_no': '1', 'url': 'https://playdesi.tv/mx-player/'},
#                   {'ch_name': 'Amazon Prime', 'pg_no': '1', 'url': 'https://playdesi.tv/amazon-prime/'},
#                   {'ch_name': 'Netflix', 'pg_no': '1', 'url': 'https://playdesi.tv/netflix/'},
#                   {'ch_name': 'ALT Balaji Web Series', 'pg_no': '1', 'url': 'https://playdesi.tv/alt-balaji/'},
#                   {'ch_name': 'HotStar Web Series', 'pg_no': '1', 'url': 'https://playdesi.tv/hotstar/'},
#                   {'ch_name': 'HotStar Quix Web Series', 'pg_no': '1', 'url': 'https://playdesi.tv/hot-star-quix/'},
#                   {'ch_name': 'Eros Now', 'pg_no': '1', 'url': 'https://playdesi.tv/eros-now/'}]
#
#         if testing:
#             chnl = 0
#             # getmeta_n_check_common()
#             # get_duplicate_dict_from_db_and_fixed()
#             param = {'ch_name': 'Gujarati web series', 'pg_no': '1', 'url': 'https://playdesi.tv/gujarati-web-series/'}
#             ### >>>>>> for test
#             # get_datajson_imdb('kaun banegi shikharwati', '2022', 'tvshow')
#             # get_non_plot()
#             # get_non_plot()
#             # get_movies_desirulez()
#             # get_movies_desicinemas()
#             get_tv_shows_desitelly(param)
#         else:
#             import time
#             selec_tv_ch = [{'ch_name': 'Colors', 'pg_no': '1', 'url': 'https://www.desi-serials.cc/color-tv-hd/'},
#                     {'ch_name': 'Zee', 'pg_no': '1', 'url': 'https://www.desi-serials.cc/zee-tv/'}]
#             chnl = 0
#             # for param in web_tv:
#             #     chnl += 1
#             #     # if chnl > 1: break
#             #     get_tv_shows_desitelly(param)
#             #     time.sleep(5)
#             # get_movies_desirulez()
#             # get_movies_desicinemas()
#             # get_non_plot()
#             # get_duplicate_dict_from_db_and_fixed()
#     except Exception as e:
#         logger(f'Error {e}: {traceback.format_exc()}')
