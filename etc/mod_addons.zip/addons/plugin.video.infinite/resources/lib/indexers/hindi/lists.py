# -*- coding: utf-8 -*-

import datetime
import base64
import json
import re
import traceback
from urllib.parse import urlencode

from modules import dom_parser

try:
    import xbmcvfs
    from modules import kodi_utils
    from modules.kodi_utils import logger, build_url
    from modules.utils import normalize
    from indexers.hindi.live_client import r_request, agent, list_data_dir, icon, fanart, joinPath, read_write_file, string_escape
    from caches.h_cache import main_cache
    remove_meta_keys = kodi_utils.remove_meta_keys
    movie_dict_removals = kodi_utils.movie_dict_removals
    movie_dict_removals += ("tvg_name", "subtitles", "tvg_language", "tvg_country", "tvg_url", "radio")
    path_exists = xbmcvfs.exists
except:
    # logger(f'import Exception: {traceback.print_exc()}')
    from modules.utils import logger, normalize
    from modules.live_client import r_request, agent, list_data_dir, icon, fanart, joinPath, read_write_file, string_escape
    from modules.h_cache import main_cache
    import os
    path_exists = os.path.exists


def youtube_m3u(params):
    ch_name = params['list_name']
    rescrape = params['rescrape']
    iconImage = params['iconImage']
    string = "content_list_youtube_m3u_%s" % (ch_name)
    params = {
        'ch_name': ch_name,
        'rescrape': rescrape,
        'iconImage': iconImage}
    cache_name = string + urlencode(params)
    if rescrape == 'true':
        main_cache.delete(cache_name)
        list_data = None
    else:
        list_data = main_cache.get(cache_name)
        # logger(f"from cache list_data: {list_data}")
    if not list_data:
        # uri = "https://raw.githubusercontent.com/benmoose39/YouTube_to_m3u/main/youtube.m3u"
        # page = r_request(uri).text
        uri = "https://bitbucket.org/jai_s/repojp/raw/HEAD/etc/allxml/youtub_live.json"
        data = r_request(uri).text
        if not data:
            youtub_live = joinPath(list_data_dir, "youtub_live.json")
            with open(youtub_live, 'r', encoding='utf-8') as f:
                data = f.read()
        list_data = json.loads(data)
        # list_data = m3u2list(normalize(page), iconImage)
        # logger(f"new list_data: {list_data}")
        if list_data: main_cache.set(cache_name, list_data, expiration=datetime.timedelta(hours=12))
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    __handle__ = int(argv[1])
    if list_data:
        item_list = list(_process(list_data, 'youtube_m3u'))
        kodi_utils.add_items(__handle__, item_list)
        kodi_utils.set_content(__handle__, 'episodes')
        kodi_utils.end_directory(__handle__)
        kodi_utils.set_view_mode('view.episodes', 'episodes')
    else:
        kodi_utils.notification(f'No links Found for: :{ch_name} Retry', 900)
        kodi_utils.end_directory(__handle__)
        return


def m3u2list(result, f_name='youtube.json'):
    nondesiralbe = ('Marathi', 'Malayalam', 'Tamil', 'Urdu', 'Albania', 'Exyu', 'Telugu', 'Kannada', 'Odisha', 'Malayalam', 'Radio', 'Türk', 'East Africa', 'France', 'Pakistan', 'Taiwan News', 'Music')
    matches = re.compile('^#EXTINF:-?[0-9]*(.*?),([^\"]*?)\n(.*?)$', re.M).findall(result)
    li = []
    for params, display_name, url in matches:
        item_data = {"params": params, "display_name": display_name.strip(), "url": url.strip()}
        li.append(item_data)
    chList = []
    for channel in li:
        item_data = {"title": channel["display_name"], "url": channel["url"], "poster":  "icon.png", "action": "ltp_pluto"}
        matches = re.compile(' (.*?)="(.*?)"').findall(channel["params"])
        desirable = True
        for field, value in matches:
            field = field.strip().lower().replace('-', '_')
            if field == 'tvg_logo':
                field = 'poster'
                if value == "": value = "icon.png"
            if field == 'group_title':
                if value.strip() in nondesiralbe:
                    desirable = False
            # logger(f"field: {field} value: {value}")
            item_data[field] = value.strip()
        if desirable: chList.append(item_data)
    # filter out some channel based on nondesiralbe list
    # chList = [i for i in chList if not (i['group_title'] in nondesiralbe)]
    # change key name in list of dict
    # for dict_object in chList:
    #     dict_object['poster'] = dict_object.pop('tvg_logo')
        #  # If the key happens to not exist. you could define a default key as well:
        # d['new_key'] = d.pop('missing_key', 'default_value')

    if chList is not []:
        with open(f_name, "w", encoding='utf-8') as f:
            f.write(json.dumps(chList))
        return chList
    return chList


def pluto():
    pluto_chennel = joinPath(list_data_dir, "pluto.json")
    if not path_exists(pluto_chennel):
        # uri = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL1RlbXBlc3QwNTgwL3htbC9tYXN0ZXIvcGx1dG8ubTN1'
        # try: uri = base64.b64decode(uri.encode('ascii')).decode('ascii')
        # except: uri = base64.b64decode(uri.encode('ascii'))
        # uri = "https://raw.githubusercontent.com/Tempest0580/xml/master/webos.m3u8"
        uri = "https://raw.githubusercontent.com/Tempest0580/xml/master/pluto.m3u"
        page = r_request(uri).text
        page = m3u2list(page, pluto_chennel)
    else:
        with open(pluto_chennel, 'r') as f:
            page = json.load(f)

    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    __handle__ = int(argv[1])
    kodi_utils.add_items(__handle__, list(_process(page, 'pluto')))
    kodi_utils.set_content(__handle__, 'episodes')
    kodi_utils.end_directory(__handle__)
    kodi_utils.set_view_mode('view.episodes', 'episodes')


def indian_live():
    pluto_chennel = joinPath(list_data_dir, "indian_live.json")
    # pluto_chennel1 = joinPath(list_data_dir, "indian_live.html")
    # logger(f'indian_live: {pluto_chennel}')
    if not path_exists(pluto_chennel):
        uri = 'https://raw.githubusercontent.com/Vikassm73/AjaykRepo/main/Zips/India.m3u'
        page = r_request(uri).text
        # page = read_write_file(file_n='raw.githubusercontent.com.html')
        # with open(pluto_chennel1, 'r', encoding='utf-8') as f:
            # page = f.read()
        page = m3u2list(page, pluto_chennel)
        # logger(f'page: {page}')
    else:
        with open(pluto_chennel, 'r') as f:
            page = json.load(f)
    # logger(f'total: {len(page)} page: {page}')
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    __handle__ = int(argv[1])
    kodi_utils.add_items(__handle__, list(_process(page, 'indian_live')))
    kodi_utils.set_content(__handle__, 'episodes')
    kodi_utils.end_directory(__handle__)
    kodi_utils.set_view_mode('view.episodes', 'episodes')


def gratis():
    pluto_chennel = joinPath(list_data_dir, "gratisiptv.json")
    if not path_exists(pluto_chennel):
        page = get_gratisiptv(pluto_chennel)
    else:
        with open(pluto_chennel, 'r') as f:
            page = json.load(f)

    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    __handle__ = int(argv[1])
    kodi_utils.add_items(__handle__, list(_process(page, 'gratis')))
    kodi_utils.set_content(__handle__, 'episodes')
    kodi_utils.end_directory(__handle__)
    kodi_utils.set_view_mode('view.episodes', 'episodes')


def _process(list_data, provider):
    for i in list_data:
        # logger(f"lists _process item: {item}", __name__)
        listitem = kodi_utils.make_listitem()
        cm = []
        name = i['title']
        poster = i.get('poster', '')
        if poster.startswith('http'): thumb = i['poster']
        else: thumb = icon
        url_params = {'mode': i['action'], 'title': name, 'url': i['url'], 'provider': provider}
        url = build_url(url_params)
        options_params = {
                'mode': 'options_menu_choice',
                'suggestion': name,
                'play_params': json.dumps(url_params)}
        cm.append(("[B]Options...[/B]", f'RunPlugin({build_url(options_params)})'))
        listitem.setLabel(name)
        listitem.addContextMenuItems(cm)
        listitem.setArt({'thumb': thumb})
        listitem.setInfo('video', remove_meta_keys(i, movie_dict_removals))
        yield url, listitem, False
    return


def play(params):
    # logger(f'play params "{params}"', __name__)
    url = params['url']
    try:
        if params['provider'] == 'pluto':
            if 'm3u8' in url: url = '%s|User-Agent=%s&Referer=%s' % (url, agent(), url)
        elif params['provider'] == 'youtube_m3u':
            # logger(f'--- Playing title: {params["title"]} url: {params["url"]}', __name__)
            cache_name = f"content_list_play_{params['url']}"
            url = main_cache.get(cache_name)
            if not url or 'benmoose39' in url:
                url = get_m3u8_url(params['url'])
                if url: main_cache.set(cache_name, url, expiration=datetime.timedelta(hours=3))
        else: url = f'{url}|User-Agent={agent()}' #url = f'{url}|User-Agent={agent()}&Upgrade-Insecure-Requests=1'
        logger(f'--- Playing "{params["title"]}". {url}', __name__)
        from modules.hplayer import FenPlayer
        info = {'info': params['title'], 'source': ''}
        FenPlayer().run(url, 'video', info)
    except:
        logger(f'play provider: {params["provider"]} - Exception: {traceback.print_exc()}', __name__)
        return


def get_gratisiptv(pluto_chennel):
    base_url = "https://www.gratisiptv.com/america-ip-tv-m3u/american-usa/"
    headers = {'User-Agent': agent()}
    stream = r_request(base_url, headers=headers).text
    # page = read_write_file(file_n='test.html', read=False, result=stream)
    # page = read_write_file(file_n = 'test.html', read = True)
    result = dom_parser.parseDOM(stream, "h2", attrs={"class": "entry-title"})
    if result:
        url = dom_parser.parseDOM(result[0], "a", ret="href")[0]
        # logger(url)
        stream = r_request(url, headers=headers).text
        # page = read_write_file(file_n='test.m3u', read=False, result=stream)
        # page = read_write_file(file_n = 'test.m3u', read = True)
        m3u_url = dom_parser.parseDOM(stream, "pre")
        # logger(m3u_url)
        # logger(re.findall(r'(https?://[^\s]+)', m3u_url[0]))
        f_url = re.findall(r'(https?://[^\s]+)', m3u_url[0])[0]
        # logger(f_url)
        stream = r_request(f_url, headers=headers).text
        # page = read_write_file(file_n='usa.m3u', read=False, result=stream)
        # page = read_write_file(file_n = 'usa.m3u', read = True)
        ch_list = m3u2list(stream, pluto_chennel)
        return ch_list


def get_m3u8_url(url):
    # logger(f"get_m3u8_url url: {url}")
    response = r_request(url).text
    # response = read_write_file('www.youtube.com.html')
    # response = to_utf8(response)
    # logger(response)
    vars_ = re.compile(r'var ytInitialData =.*?[\'|"|{](.+)[\'|"|}][,;]</script>').findall(response)
    # logger(f"vars_>>> : {vars_}")
    ytInitialData = string_escape(vars_[0])
    # logger(f"ytInitialData: {ytInitialData}")
    videoId = re.findall(r'(compactvideoRenderer|videoRenderer)\":\{\"videoId\":\"(.+?)\",', ytInitialData, re.IGNORECASE)
    logger(f"from get_m3u8_url videoId: {videoId}")
    live_yturl = 'https://www.youtube.com/watch?v=%s' % videoId[0][1]
    # logger(f"live_yturl: {live_yturl}")
    response = r_request(live_yturl).text
    # logger(f'<<<--->>> \n{response}\n<<<--->>>', __name__)
    if '.m3u8' not in response:
        m3u_url = 'https://raw.githubusercontent.com/benmoose39/YouTube_to_m3u/main/assets/moose_na.m3u'
        # if windows:
            # # logger("if window")
            # return m3u_url
        # os.system(f'wget {url} -O temp.txt')
        # response = ''.join(open('temp.txt').readlines())
        # logger(f'wget <<<--->>> \n{response}\n<<<--->>>', __name__)
        # if '.m3u8' not in response:
            # logger(">>>")
        return m3u_url
    end = response.find('.m3u8') + 5
    tuner = 100
    while True:
        if 'https://' in response[end - tuner: end]:
            link = response[end - tuner: end]
            start = link.find('https://')
            end = link.find('.m3u8') + 5
            break
        else:
            tuner += 5
    # logger(f"{link[start: end]}")
    m3u_url = link[start: end]
    return m3u_url


# def m3u_parser(result=None, f_name=''):
#     if result.strip().startswith('#EXTM3U') and '#EXTINF' in result:
#         ch_list = []
#         items = re.compile('.+?#EXTINF:.+? tvg-logo=\"(.*?)\".+?,(.+?)$\n(.+?)\n', re.MULTILINE | re.DOTALL).findall(result)
#         # items = re.compile('.+?#EXTINF:.+? tvg-logo=\"(.*?)\".+?,(.+?)$\n(.+?)\n').findall(result)
#         if not items: items = re.compile(r'#EXTINF:.+?,(.+?)$\n(.+?)\n', re.MULTILINE | re.DOTALL).findall(result)
#         # logger(f'total: {len(items)} items: {items}')
#         for i in items:
#             try: poster = i[0].strip()
#             except: poster = ''
#             try:
#                 title = i[1].strip()
#                 url = i[2].strip()
#             except:
#                 title = i[0].strip()
#                 url = i[1].strip()
#                 poster = ''
#
#             ch_list.append({
#                 "title": title,
#                 "poster": poster,
#                 "url": url,
#                 "action": "ltp_pluto"})
#
#         if ch_list is not []:
#             with open(f_name, "w") as f:
#                 f.write(json.dumps(ch_list))
#         return ch_list


# def get_vardata():
#     from modules.hindi_sources import string_escape
#     response = read_write_file(file_n='Siddhivinayak.html')
#     response = response.replace(r'\/', '/')
#     # vars = re.findall(">var ytInitialData = '(.+?)';", response)
#     # vars = re.compile(r'var ytInitialData =.*?[\'|"](.+)[\'|"][,;]</script>', re.M | re.S).findall(response)
#     vars = re.compile(r'var ytInitialData =.*?[\'|"](.+)[\'|"][,;]</script>').findall(response)
#     ytInitialData = string_escape(vars[0])
#     logger(f"ytInitialData var: {vars[0]}")
#     logger(f"ytInitialData var: {ytInitialData}")
#     # logger(f"ytInitialData var: {vars[0].encode('utf8').decode('unicode_escape')}")
#     # videoId = re.findall(r'videoRenderer":\{"videoId":"(.+?)",', string_escape(vars[0]), re.IGNORECASE)
#     videoId = re.findall(r'(compactvideoRenderer|videoRenderer)\":\{\"videoId\":\"(.+?)\",', response, re.IGNORECASE)
#     # vars = re.findall('videoId[\'|"]:[\'|"](.+?)[\'|"],', vars[0])
#     # for var in vars:
#     logger(f"videoId: {videoId}")
    # live_yturl = 'https://www.youtube.com/watch?v=%s' % vars[0]
    # logger(f"live_yturl: {live_yturl}")
    # final_yturl = get_m3u8_url(live_yturl)
    # logger(f"final_yturl: {final_yturl}")

    # channel_metadata = var[0].encode('utf8').decode('unicode_escape')
    # channel_metadata = json.loads(channel_metadata)
    # levelone = channel_metadata["contents"]["singleColumnBrowseResultsRenderer"]["tabs"][0]
    # # logger(levelone)
    # leveltwo = levelone["tabRenderer"]["content"]["sectionListRenderer"]["contents"][0]["itemSectionRenderer"]["contents"][0]["channelFeaturedVideoRenderer"]["videoId"]
    # # logger(f"videoId leveltwo: {leveltwo}")
    # live_yturl = 'https://www.youtube.com/watch?v=%s' % leveltwo
    # # logger(f"live_yturl: {live_yturl}")
    # final_yturl = get_m3u8_url(live_yturl)
    # logger(f"final_yturl: {final_yturl}")


# if __name__ == "__main__":
#     # import random
#     # indian_live()
#     # get_vardata()
#     with open('list_data/youtub_live.json', 'r', encoding='utf-8') as f:
#         page = json.load(f)
#     item = random.choice(page)
#     logger(item)
#     # logger(f"final url: {item['url']}")
#     url = get_m3u8_url(item['url'])
#     logger(f"final url: {url}")
