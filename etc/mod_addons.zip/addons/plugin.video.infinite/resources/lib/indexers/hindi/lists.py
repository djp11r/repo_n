# -*- coding: utf-8 -*-

import json
import re
from traceback import print_exc
from urllib.parse import urlencode

try:
    from modules.kodi_utils import logger, build_url, addon_icon, make_listitem, set_info,  notification, add_items, set_content, end_directory, set_view_mode, get_infolabel, set_category, external, get_git_url
    from modules.utils import normalize
    from caches.h_cache import main_cache
except:
    # logger(f'import Exception: {print_exc()}')
    from modules.utils import logger, normalize
    from modules.h_cache import main_cache
    import os

from modules.hindi_utils import request, agent

selective = [{'title': 'Fox News', 'url': 'https://daddylivehd.one/tv/albaplayer/stream-347/?serv=1/', 'action': 'ltp_pluto'},
    {'title': 'Fox Business [Geo-blocked]', 'url': 'http://199.66.95.242/1/1172/index.m3u8?token=test', 'action': 'ltp_pluto'},
    {'title': 'Fox 5 Atlanta (WAGA)', 'url': 'https://live-news-manifest.tubi.video/live-news-manifest/csm/extlive/tubiprd01,WAGA.m3u8', 'poster': 'https://i.imgur.com/qdYfhpZ.jpg', 'action': 'ltp_pluto'},
    {'title': 'LiveNOW from FOX (720p)', 'url': 'https://lnc-fox-live-now.tubi.video/index.m3u8', 'action': 'ltp_pluto'},
    {'title': 'Fox Weather', 'url': 'https://csm-e-eb.csm.tubi.video/csm/extlive/tubiprd01,Fox-Weather.m3u8', 'action': 'ltp_pluto'},
    {'title': 'Fox Weather', 'url': 'https://live-news-manifest.tubi.video/live-news-manifest/csm/extlive/tubiprd01,Fox-Weather.m3u8', 'action': 'ltp_pluto'},
    {'title': 'Fox Weather', 'url': 'https://247wlive.foxweather.com/stream/index.m3u8', 'poster': 'https://i.imgur.com/ojLdgOg.png', 'action': 'ltp_pluto'}]


def youtube_m3u(params):
    ch_name = params['list_name']
    iconImage = params['iconImage']
    # params = {'ch_name': ch_name, 'rescrape': rescrape, 'iconImage': iconImage}
    cache_name = f'content_youtube_m3u_{ch_name}{urlencode(params)}'
    list_data = None
    list_data = main_cache.get(cache_name)
    # logger(f'from cache list_data: {list_data}')
    if not list_data:
        # uri = 'https://raw.githubusercontent.com/benmoose39/YouTube_to_m3u/main/youtube.m3u'
        # page = request(uri)
        # list_data = m3u2list(normalize(page))
        uri = f'{get_git_url()}/youtub_live.json'
        data = request(uri)
        list_data = json.loads(data)
        # logger(f'new list_data: {list_data}')
        if list_data: main_cache.set(cache_name, list_data, expiration=7) # 7days
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_external = external()
    if list_data:
        item_list = list(_process(list_data, 'youtube_m3u'))
        add_items(handle, item_list)
        set_content(handle, 'episodes')
        set_category(handle, 'episodes')
        end_directory(handle)
        set_view_mode('view.episodes', 'episodes', is_external)
    else:
        notification(f'No links Found for: :{ch_name} Retry', 900)
        end_directory(handle)
        return


def pluto(params):
    cache_name = 'content_pluto_'
    list_data = None
    list_data = main_cache.get(cache_name)

    if not list_data:
        # uri = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL1RlbXBlc3QwNTgwL3htbC9tYXN0ZXIvcGx1dG8ubTN1'
        # try: uri = base64.b64decode(uri.encode('ascii')).decode('ascii')
        # except: uri = base64.b64decode(uri.encode('ascii'))
        uri = f'{get_git_url()}/pluto.json'
        data = request(uri)
        list_data = json.loads(data)
        # uri = 'https://raw.githubusercontent.com/Tempest0580/xml/master/webos.m3u8'
        # uri = 'https://raw.githubusercontent.com/Tempest0580/xml/master/pluto.m3u'
        # page = request(uri)
        # list_data = m3u2list(page)
        if list_data: main_cache.set(cache_name, list_data, expiration=7) # 7days
    # else:
        # with open(pluto_chennel, 'r') as f:
            # page = json.load(f)

    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_external = external()
    add_items(handle, list(_process(list_data, 'pluto')))
    set_content(handle, 'episodes')
    set_category(handle, 'episodes')
    end_directory(handle)
    set_view_mode('view.episodes', 'episodes', is_external)


def indian_live(params):
    cache_name = 'content_indian_live'
    list_data = None
    list_data = main_cache.get(cache_name)

    if not list_data:
        # uri = 'https://raw.githubusercontent.com/Vikassm73/AjaykRepo/main/Zips/India.m3u'
        # page = request(uri)
        # # page = read_write_file(file_n='raw.githubusercontent.com.html')
        # # with open(pluto_chennel1, 'r', encoding='utf-8') as f:
            # # page = f.read()
        # list_data = m3u2list(page)
        uri = f'{get_git_url()}/indian_live.json'
        data = request(uri)
        list_data = json.loads(data)
        if list_data: main_cache.set(cache_name, list_data, expiration=7) # 7days
        # logger(f'page: {page}')
    # else:
        # with open(pluto_chennel, 'r') as f:
            # page = json.load(f)
    # logger(f'total: {len(page)} page: {page}')
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_external = external()
    add_items(handle, list(_process(list_data, 'indian_live')))
    set_content(handle, 'episodes')
    set_category(handle, 'episodes')
    end_directory(handle)
    set_view_mode('view.episodes', 'episodes', is_external)


def cricket_live(params):
    cache_name = 'content_cricket_live'
    list_data = None
    list_data = main_cache.get(cache_name)

    if not list_data:
        # Made From  https://www.github.com/sabbiriptv
        uri = f'{get_git_url()}/crick_live.json'
        data = request(uri)
        # crick_live = 'D:/GitHub/matrix_plus/data_dir/crick_live.json'
        # with open(crick_live, mode='r', encoding='utf-8', errors='ignore') as f:
            # data = f.read()
        list_data = json.loads(data)
        if list_data: main_cache.set(cache_name, list_data, expiration=7) # 7days
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    handle = int(argv[1])
    is_external = external()
    add_items(handle, list(_process(list_data, 'crick_live')))
    set_content(handle, 'episodes')
    set_category(handle, 'episodes')
    end_directory(handle)
    set_view_mode('view.episodes', 'episodes', is_external)


def _process(list_data, provider):
    if provider == 'indian_live': list_data = selective + list_data
    for i in list_data:
        # logger(f'lists _process item: {item}')
        listitem = make_listitem()
        title = i['title']
        poster = i.get('poster', '')
        thumb = i['poster'] if poster.startswith('http') else addon_icon
        url_params = {'mode': i['action'], 'title': title, 'url': i['url'], 'provider': provider}
        url = build_url(url_params)
        options_params = {'mode': 'options_menu_choice', 'suggestion': title, 'play_params': json.dumps(url_params)}
        cm = [('[B]Options...[/B]', f'RunPlugin({build_url(options_params)})')]
        listitem.setLabel(title)
        listitem.addContextMenuItems(cm)
        listitem.setArt({'thumb': thumb})
        i.update({'imdb_id': title, 'mediatype': 'episode', 'episode': 1, 'season': 0})
        listitem = set_info(listitem, i, {'imdb': str(title)})
        yield url, listitem, False
    return


def play(params):
    # logger(f'play params '{params}'')
    url = params['url']
    try:
        if params['provider'] == 'pluto' and 'm3u8' in url: ourl = f'{url}|User-Agent={agent()}&Referer={url}'
        elif params['provider'] == 'youtube_m3u': ourl = get_m3u8_url(params['url'])
        elif params['provider'] == 'crick_live': ourl = url
        elif params['title'] == 'Fox News': ourl = 'https://webudit.webdicdn.lol/lb/premium347/index.m3u8'
        else: ourl = f'{url}|User-Agent={agent()}' #url = f'{url}|User-Agent={agent()}&Upgrade-Insecure-Requests=1'
        logger(f'--- Playing title: {params["title"]}  url: {ourl}')
        from modules.player import infinitePlayer
        # infoLabels = {'title': params['title']}
        if not ourl: return notification(f'No links Found for: :{params["title"]} Retry', 900)
        infinitePlayer().run(ourl, 'video', {'title': params['title']})
    except:
        logger(f'play provider: {params["provider"]} - Exception: {print_exc()}')
        return


def get_videoId(from_func, response):
    vars_ = re.compile(r'var ytInitialData =.*?[\'|"|{](.+)[\'|"|}][,;]</script>').findall(response)
    # logger(f'vars_>>> : {vars_}')
    ytInitialData = str(vars_[0])
    # logger(f'ytInitialData: {ytInitialData}')
    # logger(f'ytInitialData: {string_escape(vars_[0])}')
    return re.findall(r'(compactvideoRenderer|videoRenderer)\":\{\"videoId\":\"(.+?)\",', ytInitialData, re.IGNORECASE,)


def get_m3u8_url(url):
    # logger(f'get_m3u8_url url: {url}')
    furl = None
    if 'https://www.youtube.com/channel' in url: response = request(url)
    else: response = request(f'{url}/videos')
    # response = read_write_file('www.youtube.com.html')
    # response = to_utf8(response)
    # logger(response)
    videoIds = get_videoId('get_m3u8_url', response)
    videoId_counter = 0
    for videoId in videoIds:
        furl = None
        videoId_counter += 1
        live_yturl = f'https://www.youtube.com/watch?v={videoId[1]}'
        # logger(f'live_yturl: {live_yturl}')
        response = request(live_yturl)
        # logger(f'<<<--->>> \n{response}\n<<<--->>>')
        if '.m3u8' in response:
            # logger(f'get_m3u8_url response: {response}')
            furl = extract_m3u8(response)
            if furl: break
    logger(f'Total videoId: {len(videoIds)} get link from videoId_counter: {videoId_counter}')
    if furl: return furl
    else: return None


def extract_m3u8(response):
    end = response.find('.m3u8') + 5
    tuner = 100
    while True:
        if 'https://' in response[end - tuner: end]:
            link = response[end - tuner: end]
            start = link.find('https://')
            end = link.find('.m3u8') + 5
            break
        else: tuner += 5
    # logger(f'extract_m3u8: {link[start: end]}')
    return link[start: end]