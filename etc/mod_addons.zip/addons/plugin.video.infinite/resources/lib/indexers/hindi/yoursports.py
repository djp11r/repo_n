# -*- coding: utf-8 -*-

import datetime
import base64
import json
import os
import re
import traceback

from indexers.hindi.live_client import r_request, agent, wrigtht_json, list_data_dir, icon, fanart
from modules import kodi_utils
from modules.kodi_utils import notification, logger, build_url
from caches.h_cache import main_cache

ustv_chennel = os.path.join(list_data_dir, "yoursports.json")
base_link = 'http://yoursports.stream'
slink = 'http://yoursports.stream/ing/'
headers = {'User-Agent': agent(), 'Referer': base_link}
remove_meta_keys = kodi_utils.remove_meta_keys
tvshow_dict_removals = kodi_utils.tvshow_dict_removals


def yoursports_root():
    cache_name = "content_list_yoursports_root"
    ch_data = main_cache.get(cache_name)
    if not ch_data:
        ch_data = get_ch_data()
        # logger("##### - NEW ch_data: ")
        if ch_data:
            wrigtht_json(ustv_chennel, json.dumps(ch_data))
            main_cache.set(cache_name, ch_data, expiration=datetime.timedelta(hours=48))  # 1 days cache
    if len(ch_data) < 1:
        with open(ustv_chennel, 'r') as f:
            ch_data = json.load(f)
    ch_data = sorted(ch_data, key = lambda k: k['ch_no'])
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    __handle__ = int(argv[1])
    kodi_utils.add_items(__handle__, list(_process(ch_data)))
    kodi_utils.set_content(__handle__, 'episodes')
    kodi_utils.end_directory(__handle__)
    kodi_utils.set_view_mode('view.episodes', 'episodes')


def _process(list_data):
    for i in list_data:
        # logger("yoursports _process item: {}".format(i), __name__)
        if i['vid_url']:
            listitem = kodi_utils.make_listitem()
            cm = []
            cm_append = cm.append
            # name = i['title']
            if i['poster'].startswith('http'):
                thumb = i['poster']
            else:
                thumb = icon
            url_params = {'mode': i['action'], 'title': i['title'], 'url': i['url'], 'vid_url': i['vid_url']}
            url = build_url(url_params)
            options_params = {
                    'mode': 'options_menu_choice',
                    'suggestion': i['title'],
                    'play_params': json.dumps(url_params)}
            cm_append(("[B]Options...[/B]", f'RunPlugin({build_url(options_params)})'))
            listitem.setLabel(i['title'])
            listitem.addContextMenuItems(cm)
            listitem.setArt({'thumb': thumb})
            listitem.setInfo('video', remove_meta_keys(i, tvshow_dict_removals))
            yield url, listitem, False
    return


def play(params):
    try:
        # logger(f"play params : {params}")
        title = params['title']
        url = params['url']
        stream = r_request(url, headers=headers).text
        link = re.compile("rbnhd = '(.+?)'").findall(stream)[0]
        link = base64.b64decode(link)
        if link.startswith('/'):
            link = base_link + link
        link = f'{link}|User-Agent={headers}&Referer={url}'
        # control.execute('PlayMedia(%s)' % link)
        from modules.hplayer import FenPlayer
        FenPlayer().run(link, 'video', {'info': title})
    except:
        logger(f'---yoursports - Exception: \n{traceback.print_exc()}\n', __name__)
        notification('yoursports - Exception:', 900)
        return


def get_dict_per_name(list_of_dict, key_value):
    for item in list_of_dict:
        if item['title'] == key_value:
            my_item = item
            list_of_dict.remove(item)
            break
    else:
        my_item = None
    return list_of_dict, my_item


def get_ch_data():
    from indexers.hindi.live_client import icon
    with open(ustv_chennel) as f:
        list_of_dict = json.load(f)
    ch_lists = []
    url = 'http://yoursports.stream/games.js?x='
    ch_name = ['FOX News', 'FOX Business', 'ABC News', 'CBS News', 'MNX Movies', 'CBS', 'HBO Red', 'HBO Signature', 'HBO Hits', 'HBO Family', 'HBO', 'TBS', 'TNT', 'BET', 'FOX', 'DIY', 'HGTV', 'Documentaries 4 U', 'Tennis Channel: The T', 'Comedy Central', 'CMT', 'TV Land', 'ABC', 'Sharjah Sport', 'Weather Nation', 'Atlanta TV', 'Bloomberg Plus', 'Bloomberg USA', 'Fox Sports 1', 'Paramount Network', 'Fox Sports 2', 'Big Ten Network']
    # ch_list = []
    url = r_request(url, headers=headers).text
    url = url.split('scope.tv=[')[1]
    url = re.findall("chan:'(.+?)',url:'(.+?)'", url)
    url = [(i[0], slink + i[1]) for i in url]
    ch_no = 3
    for item in url:
        name = item[0]
        if name in ch_name:
            list_of_dict, ch_dict = get_dict_per_name(list_of_dict, name)
            # iicon = icon
            if name == 'FOX News':
                ch_no = 1
                # iicon = "https://upload.wikimedia.org/wikipedia/commons/thumb/6/67/Fox_News_Channel_logo.svg/300px-Fox_News_Channel_logo.svg.png"
            elif name == 'FOX Business':
                ch_no = 2
                # iicon = "https://upload.wikimedia.org/wikipedia/en/thumb/8/8a/Fox_Business.svg/420px-Fox_Business.svg.png"
            else:
                iicon = icon
                ch_no += 1
            if ch_dict:
                ch_dict.update({'url': item[1], 'ch_no': ch_no})
                ch_lists.append(ch_dict)
            else:
                ch_lists.append({'ch_no': ch_no, 'action': 'ltp_yoursports', 'poster': '', 'title': ch_name, 'url': item[1], 'vid_url': item[1]})
            
            # ch_list.append({'ch_no': ch_no, 'i['title']': item[0], 'url': item[1], 'vid_url': item[1], 'poster': iicon, 'action': 'ltp_yoursports'})
    ch_lists = ch_lists + list_of_dict
    logger(f">>> Total: {len(ch_lists)}list_of_dict: {ch_lists}")
    # ch_list = sorted(ch_list, key = lambda i: i['ch_no'])
    return ch_lists
