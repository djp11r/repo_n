# -*- coding: utf-8 -*-

import datetime
import re
import traceback
import json
# from urllib.parse import urljoin
try: import xbmcgui
except:pass
from indexers.hindi.live_client import joinPath, r_request, agent, wrigtht_json, list_data_dir, icon, fanart
from modules import kodi_utils
from modules.kodi_utils import notification, logger, build_url
# from modules.utils import to_utf8, replace_html_codes, remove_accents
try: from caches.h_cache import main_cache
except: from modules.h_cache import main_cache

ustv_chennel = joinPath(list_data_dir, "weboasis.json")
base_link = 'http://streamwat.ch/'
headers = {"User-Agent": agent()}
remove_meta_keys = kodi_utils.remove_meta_keys
tvshow_dict_removals = kodi_utils.tvshow_dict_removals


def weboasis_root():
    cache_name = "content_list_weboasis_root"
    ch_data = main_cache.get(cache_name)
    if not ch_data:
        # ch_data = get_ch_data()
        with open(ustv_chennel, 'r') as f:
            ch_data = json.load(f)
        # logger("##### - NEW ch_data: ")
        if ch_data:
            # wrigtht_json(ustv_chennel, json.dumps(ch_data))
            main_cache.set(cache_name, ch_data, expiration=datetime.timedelta(hours=168))  # 1 days cache
    # if len(ch_data) < 1:
    #     with open(ustv_chennel, 'r') as f:
    #         ch_data = json.load(f)
    # ch_data = sorted(ch_data, key=lambda k: k['ch_no'])
    # item_list = list(_process(ch_data))
    from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
    __handle__ = int(argv[1])
    kodi_utils.add_items(__handle__, list(_process(ch_data)))
    kodi_utils.set_content(__handle__, 'episodes')
    kodi_utils.end_directory(__handle__)
    kodi_utils.set_view_mode('view.episodes', 'episodes')


def _process(list_data):
    for i in list_data:
        # logger(f"desirulez _process item: {i}", __name__)
        if i['vid_url']:
            listitem = kodi_utils.make_listitem()
            cm = []
            cm_append = cm.append
            name = i['title']
            if i['poster'].startswith('http'): thumb = i['poster']
            else: thumb = icon
            url_params = {'mode': i['action'], 'title': name, 'url': i['url'], 'vid_url': i['vid_url']}
            url = build_url(url_params)
            options_params = {
                    'mode': 'options_menu_choice',
                    'suggestion': name,
                    'play_params': json.dumps(url_params)}
            cm_append(("[B]Options...[/B]", f'RunPlugin({build_url(options_params)})'))
            listitem.setLabel(name)
            listitem.addContextMenuItems(cm)
            listitem.setArt({'thumb': thumb})
            listitem.setInfo('video', remove_meta_keys(i, tvshow_dict_removals))
            yield url, listitem, False
    return


def resolve(url):
    try:
        link = url + 'player.min.js' if url.endswith('/') else url + '/player.min.js'
        page = r_request(link, headers={'referer': base_link}).text
        link = re.findall(r'playM3u8\("(.+?)"\)', page)[0]
        return link
    except:
        logger(f'WebOasis resolve Exception: \n{traceback.print_exc()}\n', __name__)
        notification('WebOasis - resolve Error:', 2000)
        return


def play(params):
    try:
        url = params['url']
        title = params['title']
        if 'http://streamwat.ch/' in url:
            link = resolve(url)
        else:
            link = url
        # control.execute('PlayMedia(%s)' % link)
        from modules.hplayer import FenPlayer
        FenPlayer().run(link, 'video', {'info': title, 'source': ''})
    except:
        logger(f'WebOasis play - Exception: \n{traceback.print_exc()}\n', __name__)
        notification('WebOasis - play The Code Has Changed:', 2000)
        return


def change_ch_no_name(list_of_dict):
    for item in list_of_dict:
        if item['title'] == "ABC News":
            item['ch_no'] = 19
        if item['title'] == "FOX News":
            item['ch_no'] = 1
            break
    return list_of_dict


def get_ch_data():
    # with open(ustv_chennel) as f:
    #     list_of_dict = json.load(f)
    ch_lists = []
    headers['Referer'] = base_link
    # print(f'headers: {headers}')
    result = r_request(base_link, headers).text
    # result = to_utf8(remove_accents(result))
    # result = result.replace('\n', ' ')
    # read_write_file(file_n='ustv.html', read=False, result=result)
    # result = read_write_file(file_n='ustv.html')
    channels = re.findall('<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)"></picture></div></a>', result)
    logger(f">>> nos of url : {len(channels)} channels: {channels}")
    ch_no = 0
    for link, jpg, ch_name in channels:
        # logger(f">>> nos of ch_name : {str(ch_name)}")
        url = base_link + link
        image = base_link + jpg
        ch_no += 1
        ch_lists.append({'ch_no': ch_no, 'action': 'ltp_weboasis', 'poster': image, 'title': ch_name, 'url': url, 'vid_url': url})
    ch_lists = change_ch_no_name(ch_lists)

    ch_lists = sorted(ch_lists, key=lambda k: k['ch_no'])
    # ch_lists = json.loads(str(ch_lists))
    logger(f">>> list_of_dict: {json.dumps(ch_lists)}")
    logger(f">>> nos of item in ch_lists : {len(ch_lists)}")
    return ch_lists


# if __name__ == "__main__":
#     get_ch_data()
