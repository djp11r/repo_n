# -*- coding: utf-8 -*-
import datetime
import json
import random
import re
import traceback
# import time

try:
    from urlparse import parse_qs, urlparse
except ImportError:
    from urllib.parse import parse_qs, urlparse
try:
    from urllib import urlencode, quote_plus
except ImportError:
    from urllib.parse import urlencode, quote_plus

from requests import Session, exceptions
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
from urllib3.exceptions import MaxRetryError
#from openscrapers.modules import client
from openscrapers.modules import jsunpack
from openscrapers.modules import log_utils
from openscrapers.modules import dom_parser
from openscrapers.modules.utils import byteify
from openscrapers.modules import py_tools


def get_page(url, headers=None, data=None, proxy=False, timeout=30):

    fheaders = {
        "x-requested-with": "XMLHttpRequest",
        "Accept-Language": "en-US,en;q=0.5",
        "User-Agent": u_agent(),
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        }
    if headers:
        fheaders.update(headers)
    if 'Referer' in fheaders: pass
    else: fheaders['Referer'] = '%s://%s/' % (urlparse(url).scheme, urlparse(url).netloc)
    # create session with retry
    session = Session()
    retries = Retry(
            total=3,  # number of total retries
            connect=1,  # retry once in case we can't connect to url
            read=1,  # retry once in case we can't read the response from url
            redirect=3,  # retry once in case we're redirect by url
            backoff_factor=0.5,  # The pause between for each retry
            status_forcelist=[429, 500, 502, 503, 504],  # this is a list of statuses to consider to be an error and retry. definitely retry if url is unwell
            method_whitelist=frozenset(['GET', 'POST']))

    session.mount('https://', HTTPAdapter(max_retries=retries))
    session.mount('http://', HTTPAdapter(max_retries=retries))

    # # sample proxy, does not work, set your own proxy
    if proxy:
        # proxies = {"https": "https://381.177.84.291:9040"}
        proxies = {
            "http": proxy,
            "https": proxy}
        session.proxies.update(proxies)
        # # get request if not used session.proxies.update(proxies)
        # response = session.get(url, proxies=proxies)
    try:
        if data: # if data provided the post payload data to url
            response = session.post(url, headers=fheaders, data=data, timeout=int(timeout))
        else:
            response = session.get(url, headers=fheaders, timeout=int(timeout))
        # print(response.headers)
        # print(response.text)
        # print(response.request.headers)
        response.raise_for_status()
    except exceptions.SSLError:
        response = session.get(url, headers=fheaders, timeout=int(timeout), verify=False)
    except exceptions.ConnectionError as err:
        print("get_page print_exc: {}\nError: {}".format(traceback.print_exc(), err))
        return
    except MaxRetryError as e:
        log_utils.log("retry: {}".format(e), log_utils.LOGDEBUG)
        return
    # print("response.headers: {}".format(response.headers))
    if response.status_code in [301, 307, 308, 503]:
        log_utils.log("response.headers: {}".format(response.headers), log_utils.LOGDEBUG)
        if 'cloudflare' in str(response.headers).lower():
            try:
                import cfscrape
                cfscraper = cfscrape.create_scraper()
                response = cfscraper.get(url, headers=fheaders)
            except Exception as e:
                log_utils.log("Error: {}".format(e))
                return

    return response.text


def keep_readable(text):
    text = text.replace('&#8216;', "'")
    text = text.replace('&#8217;', "'")
    text = text.replace('&#8220;', '"')
    text = text.replace('&#8221;', '"')
    text = text.replace('&#8211;', ' ')
    text = text.replace('&#8230;', ' ')
    text = text.replace("&amp;", "&")
    text = text.replace("-", "")
    # text = text.encode('ascii', 'ignore').decode('unicode_escape').strip()
    return text


def getcontent(crawl_response):
    #print(crawl_response.getheaders())
    content = crawl_response.content

    encoding = crawl_response.headers.get("Content-Encoding")
    # response.headers.get('Content-Encoding') == "deflate":
    #charest and content_type
    # message = crawl_response.info()
    content_type = crawl_response.headers.get("Content-Type")
    if content_type != 'text/html':
        pass

    if not encoding:
        pass
    else:
        # Decompress
        try:
            if encoding == 'br':
                import brotli
                content = brotli.decompress(content)

            if encoding == 'gzip':
                import gzip
                content = gzip.decompress(content)
        except Exception as e:
            # print("Error: decompress: {}".format(e))
            pass

        #charset
    charset = None
    # charset = message.get_content_charset(None)
    charset = crawl_response.headers.get("charset")

    if not charset:
        charset = crawl_response.headers.get("charset")
        if not charset:
            import chardet
            result = chardet.detect(content)
            charset = result['encoding']
        else:
            charset = charset[0]
    if not charset:  # default set utf-8
        charset = 'utf-8'
    # print("charset: {}".format(charset))

    # if charset != 'utf-8':  # convert utf-8
    #     content = content.encode('utf-8', errors = 'ignore').decode("utf-8")
    # else:
    # content = content.decode(charset, errors = 'ignore').encode('utf-8', errors = 'ignore')
    content = content.decode('iso-8859-1')
    # content = content.decode("utf-8")
    content = content.replace('\n', '').replace('\t', '').replace('\r', '')
    # OR
    # content = replace_html_codes(content)
    return content


def scraper_debug(provider):
    import traceback
    msg = '%s - Exception: \n%s' % (provider, traceback.print_exc())
    print(msg)
    log_utils.log(msg, log_utils.LOGDEBUG)


def dumper(obj):
    try:
        return obj.toJSON()
    except:
        return obj.decode("utf-8")


def getVideoID(url):
    try:
        return re.compile('(id|url|v|si|sin|sim|data-config|file|dm|wat|vid)=(.+?)##').findall(url + '##')[0][1]
    except:
        return


def get_mod_url(url):
    try:
        url_id = getVideoID(url)
        if not url_id:
            return
        if 'flow.php' in url:
            iurl = 'https://flow.business-loans.pw/embed17/%s' % url_id
        elif 'flix.php' in url:
            iurl = 'https://flow.business-loans.pw/nflix17/%s' % url_id
        elif 'daily' in url:
            iurl = 'https://flow.business-loans.pw/plyr17/%s' % url_id
        elif 'tere-sheher-mein' in url:
            iurl = 'https://flow.business-loans.pw/plyr2/%s' % url_id
        elif 'ishqbaaz' in url:
            iurl = 'http://flow.bestarticles.me/embed2//%s' % url_id
        return iurl
    except:
        return


def urlRewrite(url):
    # "https://vkprime.com/embed-7pws6soif1cn.html"
    # "https://vkspeed.com/embed-nji2heqsr6y4.html"
    url_dics = [{
        'host': 'vkprime.php',
        'url': 'http://vkprime.com/embed-%s.html'}, {
        'host': 'vkspeed.php',
        'url': 'http://vkspeed.com/embed-%s.html'}, {
        'host': 'speed.php',
        'url': 'http://vkspeed.com/embed-%s-600x380.html'}]
    try:
        videoID = getVideoID(url)
        for i in url_dics:
            try:
                if re.compile(i['host']).findall(url)[0]:
                    return i['url'] % videoID
            except:
                pass
        return url
    except:
        return url


def byte_to_str(bytes_or_str):
    if isinstance(bytes_or_str, bytes): # Check if it's in bytes
        bytes_or_str = bytes_or_str.decode('utf-8')
    #     print(bytes_or_str.decode('utf-8'))
    # else:
    #     print("Object not of byte type")
    return bytes_or_str


def host(url):
    try: url = byte_to_str(url)
    except: pass
    host = re.findall(r'([\w]+[.][\w]+)$', urlparse(url.strip().lower()).netloc)[0]
    return str(host.split('.')[0])


def to_utf8(obj):
    try:
        if isinstance(obj, unicode):
            obj = obj.encode('utf-8', 'ignore')
        elif isinstance(obj, dict):
            import copy
            obj = copy.deepcopy(obj)
            for key, val in obj.items():
                obj[key] = to_utf8(val)
        elif obj is not None and hasattr(obj, "__iter__"):
            obj = obj.__class__([to_utf8(x) for x in obj])
        else: pass
    except: pass
    return obj


def stringify_nodes(data):
    if isinstance(data, list): 
        return [stringify_nodes(x) for x in data]
    elif isinstance(data, dict):
        dkeys = list(data.keys())
        for i, k in enumerate(dkeys):
            try:
                dkeys[i] = k.decode()
            except:
                pass
        data = dict(zip(dkeys, list(data.values())))
        return {stringify_nodes(key): stringify_nodes(val) for key, val in data.items()}
    elif isinstance(data, bytes):
        try:
            return data.decode()
        except:
            return data
    else:
        return data


def clean_title(title):
    cleanup = ['Watch', 'Onilne', 'Tamil', 'Dubbed', 'WAtch ', 'Free', 'Full', 'AMZN', 'SCR', 'DvDRip', 'DvDScr', 'Full Movie Online Free', 'Uncensored', 'Full Movie Online', 'Watch Online ', 'Free HD', 'Online Full Movie', 'Downlaod', 'Bluray', 'Full Free', 'Malayalam Movie', ' Malayalam ', 'Full Movies', 'Full Movie', 'Free Online', 'Movie Online',
               'Watch', 'movie', 'Movie ', 'Songs', 'Hindi', 'Korean', 'Web', 'tamil', 'RIP', 'Tamil Movie', ' Hindi', 'Hilarious Comedy Scenes', 'Super Comedy Scenes', 'Ultimate Comedy Scenes', 'Watch...', 'BDRip', 'Super comedy Scenes', 'Comedy Scenes', 'hilarious comedy Scenes', '...', 'Telugu Movie', 'Sun TV Show', 'Vijay TV Show',
               'Gujarati', 'WebDL', 'WEB', 'Film', 'ESUBS', 'Web', '~', 'Sun Tv Show', 'Download', 'Starring', u'\u2013', 'Tamil Full Movie', 'Tamil Horror Movie', 'Tamil Dubbed Movie', '|', '-', ' Full ', u'\u2019', '/', 'Pre HDRip', '(DVDScr Audio)', 'PDVDRip', 'DVDSCR', '(HQ Audio)', 'HQ', ' Telugu', 'BRRip', 'DVDScr', 'DVDscr', 'PreDVDRip', 'DVDRip',
               'DVDRIP', 'WEBRip', 'Rip', ' Punjabi', 'TCRip', 'HDRip', 'HDTVRip', 'HD-TC', 'HDTV', 'TVRip', '720p', 'DVD', 'HD', ' Dubbed', '( )', '720p', '(UNCUT)', 'UNCUT', '(Clear Audio)', 'DTHRip', '(Line Audio)', ' Kannada', ' Hollywood', 'TS', 'CAM', 'Online Full', '[+18]', 'Streaming Free', 'Permalink to ', 'And Download', '()', 'Full English', ' English', 'Online', ' Tamil', ' Bengali',
               ' Bhojpuri', 'Print Free', 'DL']

    for word in cleanup:
        if word in title:
            title = title.replace(word, '')

    title = title.strip()
    title = title.encode('utf8')
    return title


def safe_string(obj):
    try:
        try:
            return str(obj)
        except UnicodeEncodeError:
            return obj.encode('utf-8', 'ignore').decode('ascii', 'ignore')
        except:
            return ""
    except:
        return obj


def replace_html_codes(txt):
    try:
        from HTMLParser import HTMLParser
        unescape = HTMLParser().unescape
    except ImportError:
        from html.parser import HTMLParser
        from html import unescape
    txt = safe_string(txt)
    txt = byteify(txt)
    txt = re.sub("(&#[0-9]+)([^;^0-9]+)", "\\1;\\2", txt)
    txt = unescape(txt)
    txt = txt.replace("&quot;", "\"")
    txt = txt.replace("&amp;", "&")
    return txt


non_str_list = ['tvnation.me/include', 'tvarticles.me/ad', 'drivewire.xyz', 'olangal.', 'magnet:',
                'desihome.', 'thiruttuvcd', '.filmlinks4u', 'cineview', 'bollyheaven', 'videolinkz',
                'moviefk.co', 'goo.gl', 'imdb.', 'mgid.', 'atemda.', 'movierulz.ht', 'facebook.',
                'twitter.', 'm2pub', 'abcmalayalam', 'india4movie.co', 'embedupload.',
                '#', 'tamilraja.', 'multiup.', 'filesupload.', 'fileorbs.', 'tamil.ws',
                'insurance-donate.', '.blogspot.', 'yodesi.net', 'desi-tashan.', 'yomasti.co/ads',
                'ads.yodesi', '/ads/', 'mylifeads.', 'yaartv.', 'steepto.', '/movierulztv',
                '/email-protection', 'oneload.xyz', 'tvnation.me/drive.php?']

embed_list = ['cineview', 'bollyheaven', 'videolinkz', 'vidzcode', 'escr.', 'embedzone', 'embedsr',
              'fullmovie-hd', 'links4.pw', 'esr.', 'embedscr', 'embedrip', 'movembed',
              'power4link.us', 'adly.biz', 'watchmoviesonline4u', 'nobuffer.info', 'yomasti.co',
              'hd-rulez.', 'techking.me', 'onlinemoviesworld.xyz', 'cinebix.com', 'vids.xyz',
              'desihome.', 'loan-', 'filmshowonline.', 'hinditwostop.', 'media.php',
              'hindistoponline', 'telly-news.', 'tellytimes.', 'techking.', 'business-','businessvoip.',
              'toptencar.', 'serialinsurance.', 'youpdates', 'loanadvisor.', 'tamilray.',
              'embedrip.', 'xpressvids.', 'beststopapne.', 'bestinforoom.', '?trembed=',
              'tamilserene.', 'etcscrs.', 'etcsr1.', 'etcrips.']


def threadwrap(func, extr_iurl, que):
    """
    :useges:
    from Queue import Queue
    que = Queue()
    furls = hindi_sources.threadwrap(hindi_sources.link_extractor, extr_iurl, que)
    print('ilink: %s' % str(que.get()))
    :param func:
    :param extr_iurl:
    :param que:
    :param furls:

    :return:
    """
    threads = []
    # from Queue import Queue
    import threading
    # que = Queue()
    # print('extr_iurl: {}'.format(extr_iurl))
    for iurl in extr_iurl:
        # print('iurl: {}'.format(iurl))
        threads.append(threading.Thread(target=lambda q, arg: q.put(func(iurl)), args=(que, iurl)))
    [i.start() for i in threads]
    [i.join() for i in threads]
    # print('ilink: %s' % threads)
    # if str(que.get()) is not None:
    # while not que.empty():
    #     print('ilink: %s' % str(que.get()))
    #     if str(que.get()) is not None:
    #         furls.append(que.get())
    # return furls


def get_source_dict(urls, sources, ihost=None):
    # log_utils.log('urls: %s' % urls)
    if ihost is None:
        ihost = host(urls[0])
    # print ('ihost {} len(urls) {} type of urls {}'.format(ihost, len(urls), type(urls)))
    direct = False
    if ihost in ['bestarticles', 'loans', 'tvlogy', 'CDN']:
        direct = True

    if len(urls) > 1:
        j = 0
        for ji in urls:
            if any(re.findall(r'speed|vkprime', str(ji), re.IGNORECASE)):
                j += 1
                sources.append({
                    'source': ihost,
                    'quality': 'HD',
                    'language': 'en',
                    'info': 'Part:%s' % j,
                    'url': ji,
                    'direct': False,
                    'debridonly': False})

    if len(urls) > 1:
        unfo = 'All parts: %s' % str(len(urls))
        url = ' , '.join(urls)
    else:
        unfo = 'All part: Single'
        url = urls[0]
    sources.append({
        'source': ihost,
        'quality': 'HD',
        'language': 'en',
        'info': unfo,
        'url': url,
        'direct': direct,
        'debridonly': False})

    return sources


def append_headers(headers):
    return '|%s' % '&'.join(['%s=%s' % (key, quote_plus(headers[key])) for key in headers])


def link_extractor(url, headers=None):
    # log_utils.log('link_extractor url: {}'.format(url))
    try:
        if headers is None:
            headers = {'User-Agent': u_agent(), 'Referer': url, }
        # print('headers: {}'.format(headers))
        result = get_page(url, headers=headers)
        # result = to_utf8(remove_accents(result))
        # result = result.replace('\n', ' ')
        # read_write_file(read=False, result=result)
        # result = read_write_file()
        # log_utils.log('link_extractor result: {}'.format(result))
        links = dom_parser.parseDOM(result, 'iframe', ret='src')
        links += re.findall(r'"(?:file|src)":"([^"]+m3u8)', result)
        # log_utils.log('link_extractor links: {}'.format(links))
        # if not links: return # None, None
        for link in links:
            # print('link_extractor link: {}'.format(link))
            if 'vkprime' in link or 'speed' in link or 'watchvideo.us' in link:
                vidhost = host(link)
                return vidhost, link
            elif 'flow.' in link:# or not link.endswith('.html'):
                # print('link_extractor flow in  link : {}'.format(link))
                vidhost, vidurl = link_extractor2(link, headers)
                return vidhost, vidurl
            elif not any([x in link for x in non_str_list]) or not any([x in link for x in embed_list]):
                vidhost, vidurl = resolve_url(link)
                return vidhost, vidurl
    except Exception as e:
        log_utils.log('Error: in link_extractor: {}'.format(e))
        # pass
    return None, None


def link_cfscraper_extractor(url, headers=None):
    # print('link_cfscraper_extractor url: {}'.format(url))
    if headers is None:
        headers = {'User-Agent': u_agent(), 'Referer': url}
    data = get_page(url, headers=headers)
    # print('shtml ', data)
    redirect_url = meta_redirect(data)
    # print('redirect_url: ', redirect_url)
    data = get_page(redirect_url, headers=headers)
    # print('data: ', data)
    _frame_regex = r'(?:iframe|source).+?(?:src)=(?:\"|\')(.+?)(?:\"|\')'
    links = re.compile(_frame_regex, re.IGNORECASE).findall(data)
    # print('data regex links: ', links)

    vidhost = vidurl = None
    for link in links:
        if not link.endswith('.html') and 'index.php?' not in link:
            # print('flow.tvlogy: {}'.format(link))
            data = get_page(link, headers = headers)
            vidurl = re.findall(r'"(?:file|src)":"([^"]+m3u8)', data)[0]
            print('vidurl: {}'.format(vidurl))
            vhdr = {'Range': 'bytes=0-'}
            headers.update(vhdr)
            vidurl += append_headers(headers)
            # print('vidurl: {}'.format(vidurl))
            vidhost = 'CDN'
            if vidurl:
                # print('vidhost: {} vidurl: {}'.format(vidhost, vidurl))
                return vidhost, vidurl
    return vidhost, vidurl


def find_match(regex, text, index=0):
    results = re.findall(text, regex, flags=re.DOTALL | re.IGNORECASE)
    return results[index]


def meta_redirect(content):
    redirect_re = re.compile('<meta[^>]*?url=(.*?)["\']', re.IGNORECASE)
    match = redirect_re.search(str(content))
    # print('match ', match.groups()[0].strip())
    redirect_url = None
    if match:
        url = match.groups()[0].strip()
        if url.startswith('http://tellygossips.net/'):
            redirect_url = url
    return redirect_url


def link_extractor2(url, headers=None):
    # print('link_extractor2 url: {}'.format(url))
    if headers is None:
        headers = {'User-Agent': u_agent(), 'Referer': url}
    try:
        shtml = get_page(url, headers=headers)
    except:
        log_utils.log('link_extractor2 shtml traceback.print_exc(): {}'.format(traceback.print_exc()))
        return None, None

    try:
        vidurl = re.findall(r'"(?:file|src)":"([^"]+m3u8)', shtml)[0]#.encode('utf8')
        vhdr = {'Range': 'bytes=0-'}
        headers.update(vhdr)
        vidurl += append_headers(headers)
        vidhost = 'CDN'
        # log_utils.log("link_extractor2 1 : {}".format(vidurl))
        if vidurl:
            return vidhost, vidurl
    except:
        try:
            links = dom_parser.parseDOM(shtml, 'iframe', ret='src')
            for link in links:
                if 'vkprime' in link or 'speed' in link or 'watchvideo.us' in link:
                    # log_utils.log("link_extractor2 2 : {}".format(link))
                    vidhost = host(link)
                    return vidhost, link
        except: return None, None
    return None, None


def resolve_url(url):
    try:
        import resolveurl
        if resolveurl.HostedMediaFile(url):
            # log_utils.log('-------> from iframe not from non_str_list & embed_list  link : %s' % url)
            vidhost = host(url)
            return vidhost, url
        else:
            log_utils.log('Resolveurl cannot resolve : {}'.format(url))
    except:
        log_utils.log('resolve_url from iframe not from non_str_list & embed_list  link : %s' % url)
    return None, None


def resolve_media(url, headers=None):
    if headers is None:
        headers = {'User-Agent': u_agent(), }
    result = get_page(url, headers=headers)
    # log_utils.log(result)
    # links = dom_parser.parseDOM(result, 'div', attrs = {'id': 'content'})
    # log_utils.log('resolve_media links: {}'.format(links))
    links = dom_parser.parseDOM(result, 'iframe', ret='src')
    log_utils.log('resolve_media links: {}'.format(links))
    # links = [dom_parser.parseDOM(i, 'iframe', ret = 'src')[0] for i in links]
    # log_utils.log('resolve_media links src: {}'.format(links))
    try:
        if len(links) == 0:
            return None, None
        for strurl in links:
            log_utils.log('resolve_media strurl link : %s' % strurl)
            if any([x in strurl for x in ['apnevideotwo', 'player.business']]):
                vidhost = 'CDN'
                return vidhost, strurl
            elif 'apnevideoone' in strurl:
                shtml = get_page(url, headers=headers)
                vidurl = re.findall(r'link_play\s*=\s*\[{"file":"([^"]+)', shtml)[0]#.encode('utf8')
                vhdr = {'Origin': 'https://apnevideoone.co'}
                vidurl = '{0}|{1}'.format(vidurl, urlencode(vhdr))
                vidhost = 'CDN'
                return vidhost, vidurl
            elif 'flow.' in strurl:
                # log_utils.log('resolve_media flow. link : %s' % strurl)
                vidhost, vidurl = link_extractor2(strurl, headers)
                # log_utils.log('resolve_media all Scraped link : %s : %s' % (vidhost, vidurl))
                return vidhost, vidurl
            elif not any([x in strurl for x in non_str_list]) and not any([x in strurl for x in embed_list]):
                vidhost, vidurl = resolve_url(strurl)
                return vidhost, vidurl
    except Exception as e:
        log_utils.log('Error: in resolve_media: %s\nurl: %s' % (e, url))
        return None, None


def scrape_sources(html, result_blacklist=None, scheme='http'):
    def __parse_to_list(_html, regex):
        _blacklist = ['.jpg', '.jpeg', '.gif', '.png', '.js', '.css', '.htm', '.html', '.php', '.srt', '.sub', '.xml', '.swf', '.vtt', '.mpd']
        _blacklist = set(_blacklist + result_blacklist)
        streams = []
        labels = []
        for r in re.finditer(regex, _html, re.DOTALL):
            match = r.groupdict()
            stream_url = match['url'].replace('&amp;', '&')
            file_name = urlparse(stream_url[:-1]).path.split('/')[-1] if stream_url.endswith("/") else urlparse(stream_url).path.split('/')[-1]
            label = match.get('label', file_name)
            if label is None:
                label = file_name
            blocked = not file_name or any(item in file_name.lower() for item in _blacklist) or any(item in label for item in _blacklist)
            if stream_url.startswith('//'):
                stream_url = scheme + ':' + stream_url
            if '://' not in stream_url or blocked or (stream_url in streams) or any(stream_url == t[1] for t in source_list):
                continue
            labels.append(label)
            streams.append(stream_url)
        matches = zip(labels, streams)
        # log_utils.log('found quality: %s - link: %s' % (labels, streams))
        return matches #labels, streams

    if result_blacklist is None:
        result_blacklist = []
    elif isinstance(result_blacklist, str):
        result_blacklist = [result_blacklist]

    # html = html.replace(r"\/", "/")
    html += get_packed_data(html)

    source_list = []
    all_regexs = [r'''["']?label\s*["']?\s*[:=]\s*["']?(?P<label>[^"',]+)["']?(?:[^}\]]+)["']?\s*file\s*["']?\s*[:=,]?\s*["'](?P<url>[^"']+)''',
                 r'''["']?\s*file\s*["']?\s*[:=,]?\s*["'](?P<url>[^"']+)(?:[^}>\]]+)["']?\s*label\s*["']?\s*[:=]\s*["']?(?P<label>[^"',]+)''',
                 r'''video[^><]+src\s*[=:]\s*['"](?P<url>[^'"]+)''',
                 r'''source\s+src\s*=\s*['"](?P<url>[^'"]+)['"](?:.*?data-res\s*=\s*['"](?P<label>[^'"]+))?''',
                 r'''["']?\s*(?:file|url)\s*["']?\s*[:=]\s*["'](?P<url>[^"']+)''',
                 r'''param\s+name\s*=\s*"src"\s*value\s*=\s*"(?P<url>[^"]+)''',
                 '''(?i)<iframe.+?src=["']([^'"]+)''']
    # for regex in all_regexs:
    #     qulity , url = __parse_to_list(html, regex)
    #     if url:
    #         source_list.append(url)

    source_list += __parse_to_list(html, r'''["']?label\s*["']?\s*[:=]\s*["']?(?P<label>[^"',]+)["']?(?:[^}\]]+)["']?\s*file\s*["']?\s*[:=,]?\s*["'](?P<url>[^"']+)''')
    source_list += __parse_to_list(html, r'''["']?\s*(?:file|src)\s*["']?\s*[:=,]?\s*["'](?P<url>[^"']+)(?:[^}>\]]+)["']?\s*label\s*["']?\s*[:=]\s*["']?(?P<label>[^"',]+)''')
    source_list += __parse_to_list(html, r'''video[^><]+src\s*[=:]\s*['"](?P<url>[^'"]+)''')
    source_list += __parse_to_list(html, r'''source\s+src\s*=\s*['"](?P<url>[^'"]+)['"](?:.*?res\s*=\s*['"](?P<label>[^'"]+))?''')
    source_list += __parse_to_list(html, r'''["'](?:file|url)["']\s*[:=]\s*["'](?P<url>[^"']+)''')
    source_list += __parse_to_list(html, r'''param\s+name\s*=\s*"src"\s*value\s*=\s*"(?P<url>[^"]+)''')

    # source_list += __parse_to_list(html, r'''["']?\s*file\s*["']?\s*[:=,]?\s*["'](?P<url>[^"']+)(?:[^}>\]]+)["']?\s*label\s*["']?\s*[:=]\s*["']?(?P<label>[^"',]+)''')
    # source_list += __parse_to_list(html, r'''source\s+src\s*=\s*['"](?P<url>[^'"]+)['"](?:.*?data-res\s*=\s*['"](?P<label>[^'"]+))?''')
    source_list += __parse_to_list(html, r'''["']?\s*(?:file|url)\s*["']?\s*[:=]\s*["'](?P<url>[^"']+)''')

    # source_list += __parse_to_list(html, '''(?i)<iframe.+?src=["']([^'"]+)''')
    log_utils.log('@@@@ last source_list [%s]' % source_list, __name__)

    return source_list


def get_packed_data(html):
    packed_data = ''
    for match in re.finditer(r'(eval\s*\(function.*?)</script>', html, re.DOTALL | re.I):
        try:
            js_data = jsunpack.unpack(match.group(1))
            js_data = js_data.replace('\\', '')
            packed_data += js_data
        except:
            pass

    return packed_data


def test_patterns(text, patterns=[]):
    """Given source text and a list of patterns, look for
    matches for each pattern within the text and print
    them to stdout.
    useges:
    test_patterns('abbaaabbbbaaaaa',
              [ 'ab*',     # a followed by zero or more b
                'ab+',     # a followed by one or more b
                'ab?',     # a followed by zero or one b
                'ab{3}',   # a followed by three b
                'ab{2,3}', # a followed by two to three b
                ])
    :return:
    """
    # Show the character positions and input text
    log_utils.log(''.join(str(i / 10 or ' ') for i in range(len(text))))
    log_utils.log(''.join(str(i % 10) for i in range(len(text))))
    log_utils.log(text)

    # Look for each pattern in the text and print the results
    for pattern in patterns:
        log_utils.log('Matching "%s"' % pattern)
        for match in re.finditer(pattern, text):
            s = match.start()
            e = match.end()
            log_utils.log('  %2d : %2d = "%s"' % (s, e - 1, text[s:e]))
    return


def regex_patterns():
    """
    get text between 2 marker
    as-is will fail with an AttributeError if there are no "AAA" and "ZZZ" in text
    """
    text = 'gfgfdAAA1234ZZZuijjk'
    data = re.search(r"(?<=AAA).*?(?=ZZZ)", text).group(0)
    print('data: %s' % data)
    """Get URL and Lable from:
    value="87"/>
    <td class="line-content">  sources:[{file: 'https://hls2x.vidembed.net/load/hls/YcZQc1FGQYWuj_fAI2F7Pg/1625270480/242436/a8d172bb473a8ba8e2feddc34c478e4b/ep.11.1618011076.m3u8',label: 'hls P','type' : 'hls'}],</td>
    </tr>
    """
    result = """value="87"/>
    <td class="line-content">  sources:[{file: 'https://hls2x.vidembed.net/load/hls/YcZQc1FGQYWuj_fAI2F7Pg/1625270480/242436/a8d172bb473a8ba8e2feddc34c478e4b/ep.11.1618011076.m3u8',label: 'hls P','type' : 'hls'}],</td>
    </tr>"""
    data = re.search(r'''["']?\s*(?:file|src)\s*["']?\s*[:=,]?\s*["'](?P<url>[^"']+)(?:[^}>\]]+)["']?\s*label\s*["']?\s*[:=]\s*["']?(?P<label>[^"',]+)''', result)
    print('data: %s' % data.group('url'))
    print('data: %s' % data.group('label'))
    """It will remove all the control characters"""
    text = "Saina\xa0(2021)"
    result = re.sub(r'[^\x00-\x7f]', '', text)
    print(result)
    """clean title from (Season 1|Season 2|S01|S02)"""
    text = "suite Season 1|F.B.I. Season 2|S01|S02"
    result = re.sub(r'([Ss]eason) \d{1,2}|[Ss]\d{1,2}', '', text)
    print(result)
    """Removing Digits from a String"""
    text = "The film Pulp Fiction was released in year 1994"
    result = re.sub(r"\d", "", text)
    print(result) # The film Pulp Fiction was released in year
    """Removing Alphabet Letters from a String"""
    text = "The film Pulp Fiction was released in year 1994"
    result = re.sub(r"[a-z]", "", text, flags=re.I)
    print(result) # 1994
    """Removing Word Characters"""
    text = "The film, '@Pulp Fiction' was ? released in % $ year 1994."
    result = re.sub(r"\w", "", text, flags=re.I)
    print(result) # , '@ '  ?   % $  .
    """Removing Non-Word Characters"""
    text = "The film, '@Pulp Fiction' was ? released in % $ year 1994."
    result = re.sub(r"\W", "", text, flags=re.I)
    print(result) # ThefilmPulpFictionwasreleasedinyear1994
    """Grouping Multiple Patterns"""
    text = "The film, '@Pulp Fiction' was ? released _ in % $ year 1994."
    result = re.sub(r"[,@\'?\.$%_]", "", text, flags=re.I)
    print(result) # The film Pulp Fiction was  released  in   year 1994
    """Removing Multiple Spaces"""
    text = "The film      Pulp Fiction      was released in   year 1994."
    result = re.sub(r"\s+", " ", text, flags=re.I)
    print(result) # The film Pulp Fiction was released in year 1994.
    """Removing Spaces from Start and End"""
    text = "         The film Pulp Fiction was released in year 1994"
    result = re.sub(r"^\s+", "", text)
    print(result)
    """"remove space at the end of the string"""
    text = "The film Pulp Fiction was released in year 1994      "
    result = re.sub(r"\s+$", "", text)
    print(result) # The film Pulp Fiction was released in year 1994
    """Removing a Single Character"""
    text = "The film Pulp Fiction     s was b released in year 1994"
    result = re.sub(r"\s+[a-zA-Z]\s+", " ", text)
    print(result) # The film Pulp Fiction was released in year 1994
    """Splitting a String"""
    text = "The film      Pulp   Fiction was released in year 1994      "
    result = re.split(r"\s+", text)
    print(result) # ['The', 'film', 'Pulp', 'Fiction', 'was', 'released', 'in', 'year', '1994', '']
    text = "The film, Pulp Fiction, was released in year 1994"
    result = re.split(r"\,", text)
    print(result) # ['The film', ' Pulp Fiction', ' was released in year 1994']
    """Finding All Instances"""
    text = "I want to buy a mobile between 200 and 400 euros"
    result = re.findall(r"\d+", text)
    print(result) # ['200', '400']
    """"""


def extractJS(data, function=False, variable=False, match=False, evaluate=False, values=False):
    log_utils.log("")
    scripts = dom_parser.parseDOM(data, "script")
    if len(scripts) == 0:
        log_utils.log("Couldn't find any script tags. Assuming javascript file was given.")
        scripts = [data]

    lst = []
    log_utils.log("Extracting", 4)
    for script in scripts:
        tmp_lst = []
        if function:
            tmp_lst = re.compile(r'\(.*?\).*?;', re.M | re.S).findall(script)
            # tmp_lst = re.compile(function + r'\(.*?\).*?;', re.M | re.S).findall(script)
        elif variable:
            # tmp_lst = re.compile(variable.replace("[", r"\[").replace("]", r"\]") + '[ ]+=.*?;', re.M | re.S).findall(script)
            # log_utils.log(">>>> script: " + repr(script), 4)
            tmp_lst = re.compile(r'var.*?=.*?(.+)[,;]{1}', re.M | re.S).findall(script)
            # print('tmp_lst: ' + repr(tmp_lst))
            # log_utils.log("????tmp_lst: " + repr(tmp_lst), 4)
        else:
            tmp_lst = [script]
        if len(tmp_lst) > 0:
            log_utils.log("Found: " + repr(tmp_lst), 4)
            lst += tmp_lst
        else:
            log_utils.log("Found nothing on: " + script, 4)

    lst = [i for i in lst if i != u''] # remove empty item from list
    test = range(0, len(lst))
    print("lst: >>>>> {}".format(lst))

    # test.reverse()
    for i in test:
        if match and lst[i].find(match) == -1:
            log_utils.log("Removing item: " + repr(lst[i]), 10)
            del lst[i]
        else:
            log_utils.log("Cleaning item: " + repr(lst[i]), 4)
            if lst[i][0] == u"\n":
                lst[i] == lst[i][1:]
            if lst[i][len(lst) - 1] == u"\n":
                lst[i] == lst[i][:len(lst) - 2]
            lst[i] = lst[i].strip()

    if values or evaluate:
        for i in range(0, len(lst)):
            log_utils.log("Getting values %s" % lst[i])
            if function:
                if evaluate:  # include the ( ) for evaluation
                    data = re.compile(r"(\(.*?\))", re.M | re.S).findall(lst[i])
                else:
                    data = re.compile(r"\((.*?)\)", re.M | re.S).findall(lst[i])
            elif variable:
                tlst = re.compile(variable + r".*?=.*?;", re.M | re.S).findall(lst[i])
                data = []
                for tmp in tlst:  # This breaks for some stuff. "ad_tag": "http://ad-emea.doubleclick.net/N4061/pfadx/com.ytpwatch.entertainment/main_563326'' # ends early, must end with }
                    cont_char = tmp[0]
                    cont_char = tmp[tmp.find("=") + 1:].strip()
                    cont_char = cont_char[0]
                    if cont_char in "'\"":
                        log_utils.log("Using %s as quotation mark" % cont_char, 1)
                        tmp = tmp[tmp.find(cont_char) + 1:tmp.rfind(cont_char)]
                    else:
                        log_utils.log("No quotation mark found", 1)
                        tmp = tmp[tmp.find("=") + 1: tmp.rfind(";")]

                    tmp = tmp.strip()
                    if len(tmp) > 0:
                        data.append(tmp)
            else:
                log_utils.log("ERROR: Don't know what to extract values from")

            log_utils.log("Values extracted: %s" % repr(data))
            if len(data) > 0:
                lst[i] = data[0]

    if evaluate:
        for i in range(0, len(lst)):
            log_utils.log("Evaluating %s" % lst[i])
            data = lst[i].strip()
            try:
                try:
                    lst[i] = json.loads(data)
                except:
                    log_utils.log("Couldn't json.loads, trying eval")
                    lst[i] = eval(data)
            except:
                log_utils.log("Couldn't eval: %s from %s" % (repr(data), repr(lst[i])))

    log_utils.log("Done: " + str(len(lst)))
    return lst


def u_agent():
    return random.choice(["Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36",
                          "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36",
                          "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36", "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 UBrowser/6.1.2909.1022 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36",
                          "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 UBrowser/6.1.2909.1022 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36",
                          "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 UBrowser/6.0.1471.813 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 UBrowser/6.1.2015.1007 Safari/537.36",
                          "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 UBrowser/6.1.2107.204 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 UBrowser/6.1.2909.1213 Safari/537.36",
                          "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 UBrowser/6.0.1308.1016 Safari/420815", "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 UBrowser/6.1.2015.1007 Safari/537.36",
                          "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 UBrowser/6.1.2909.1022 Safari/537.36", "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 UBrowser/6.1.2909.1022 Safari/537.36,gzip(gfe)",
                          "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 UBrowser/6.1.2015.1007 Safari/537.36",
                          "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 UBrowser/6.0.1471.914 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 UBrowser/6.1.2015.1007 Safari/537.36",
                          "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 UBrowser/6.1.2909.1022 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/50.0.2661.102 Chrome/50.0.2661.102 Safari/537.36",
                          "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36",
                          "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36",
                          "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36", "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36",
                          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 YaBrowser/19.6.0.1226 Yowser/2.5 Safari/537.36",
                          "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36",
                          "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36",
                          "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36",
                          "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36",
                          "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36", "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36",
                          "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.137 Safari/537.36",
                          "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.137 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.137 Safari/537.36", "Mozilla/5.0 (Linux; Android 8.0.0;) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Mobile Safari/537.36",
                          "Mozilla/5.0 (iPhone; CPU iPhone OS 12_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/80.0.3987.95 Mobile/15E148 Safari/605.1", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/74.0", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.13; rv:61.0) Gecko/20100101 Firefox/74.0", "Mozilla/5.0 (X11; Linux i586; rv:31.0) Gecko/20100101 Firefox/74.0",
                          "Mozilla/5.0 (Android 8.0.0; Mobile; rv:61.0) Gecko/61.0 Firefox/68.0", "Mozilla/5.0 (iPhone; CPU iPhone OS 12_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) FxiOS/23.0 Mobile/16B92 Safari/605.1.15", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0 Safari/605.1.15",
                          "Mozilla/5.0 (iPhone; CPU iPhone OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0 Mobile/15E148 Safari/604.1", "Mozilla/5.0 (iPad; CPU OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0 Mobile/15E148 Safari/604.1",
                          "Mozilla/5.0 (iPod Touch; CPU iPhone OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0 Mobile/15E148 Safari/604.1", "Mozilla/5.0 (Windows NT 10.0; Trident/7.0; rv:11.0) like Gecko"])


urlReWriteDict = [{'host': 'vidwatch.php', 'url': 'http://vidwatch.me/embed-%s.html'}, {'host': 'speedwatch.php', 'url': 'http://speedwatch.us/embed-%s.html'}, {'host': 'logy.php', 'url': 'http://tvlogy.to/embed1/%s'}, {'host': 'vkprime.php', 'url': 'http://vkprime.com/embed-%s.html'}, {'host': 'vkspeed.php', 'url': 'http://vkspeed.com/embed-%s-600x380.html'}, {'host': 'watchvideo.php', 'url': 'http://watchvideo.us/embed-%s.html'}, {'host': 'watchers.php', 'url': 'http://watchers.to/embed-%s-725x410.html'}, {'host': 'player.php', 'url': 'https://watchshare.net/embed/%s'}, {'host': 'speed.php', 'url': 'http://vkspeed.com/embed-%s-600x380.html'}, {'host': 'irshare.php', 'url': 'https://irshare.net/embed-%s/'}, {'host': 'tune.php', 'url': 'https://tune.pk/player/embed_player.php?vid=%s'}, {'host': 'xpressvids.info', 'url': 'https://watchshare.net/embed/%s'}, {'host': 'letwatch.php', 'url': 'http://letwatch.us/embed-%s-650x400.html'}, {'host': 'lw.php', 'url': 'http://letwatch.us/embed-%s-650x400.html'}, {'host': 'let.php', 'url': 'http://letwatch.us/embed-%s-650x400.html'}, {'host': 'playwire.php', 'url': 'http://config.playwire.com/%s/player.json'}, {'host': 'pw.php', 'url': 'http://config.playwire.com/%s/player.json'}, {'host': 'ddaily.php', 'url': 'http://www.dailymotion.com/embed/video/%s'}, {'host': 'dm.php', 'url': 'http://www.dailymotion.com/embed/video/%s'}, {'host': 'speedplay.php', 'url': 'http://speedplay.me/embed-%s.html'}, {'host': 'cloudy.php', 'url': 'http://www.cloudy.ec/embed.php?id=%s&width=650&height=410'}, {'host': 'tvlogy.php', 'url': 'http://tvlogy.to/watch.php?v=%s'}, {'host': 'idowatch.php', 'url': 'http://idowatch.us/embed-%s.html'}, {'host': 'playu.php', 'url': 'http://playu.net/embed-%s-700x440.html'}, {'host': 'nowvideo.php', 'url': 'http://embed.nowvideo.sx/embed.php?v=%s&amp;wmode=direct&amp;autoplay=true&controls=false'}, {'host': 'nv.php', 'url': 'http://embed.nowvideo.sx/embed.php?v=%s&amp;wmode=direct&amp;autoplay=true&controls=false'}, {'host': 'openload.php', 'url': 'https://openload.co/embed/%s/'}, {'host': 'thevideo.php', 'url': 'http://www.thevideo.me/embed-%s-650x400.html'}, {'host': 'vodlocker.php', 'url': 'http://vodlocker.com/embed-%s-650x400.html'}, {'host': 'vidto.php', 'url': 'http://vidto.me/embed-%s-640x360.html'}, {'host': 'vidzi.php', 'url': 'http://vidzi.tv/embed-%s-640x360.html'}, {'host': 'vidgg.php', 'url': 'http://www.vidgg.to/embed/?id=%s&amp;px=1'}, {'host': 'aurora.php', 'url': 'http://www.auroravid.to/embed/?v=%s&amp;px=1'}, {'host': 'cloudtime.php', 'url': 'http://www.cloudtime.to/embed/?v=%s&amp;px=1'}, {'host': 'vidoza.php', 'url': 'https://vidoza.net/embed-%s/'}, {'host': 'estream.php', 'url': 'http://estream.to/embed-%s.html'}, {'host': 'goflicker.php', 'url': 'http://goflicker.com/embed-%s-520x400.html'}]


def ordinal(integer):
    int_to_string = str(integer)

    if int_to_string == '1' or int_to_string == '-1':
        # print(int_to_string + 'st')
        return int_to_string + 'st'
    elif int_to_string == '2' or int_to_string == '-2':
        # print(int_to_string + 'nd')
        return int_to_string + 'nd'
    elif int_to_string == '3' or int_to_string == '-3':
        # print(int_to_string + 'rd')
        return int_to_string + 'rd'
    elif int_to_string[-1] == '1' and int_to_string[-2] != '1':
        # print(int_to_string + 'st')
        return int_to_string + 'st'
    elif int_to_string[-1] == '2' and int_to_string[-2] != '1':
        # print(int_to_string + 'nd')
        return int_to_string + 'nd'
    elif int_to_string[-1] == '3' and int_to_string[-2] != '1':
        # print(int_to_string + 'rd')
        return int_to_string + 'rd'
    else:
        # print(int_to_string + 'th')
        return int_to_string + 'th'


def daterange(weekend=False):
    weekday_dict = []
    weekend_dict = []
    end_date = datetime.date.today()  # end_date = date(2018, 1, 1)
    start_date = (end_date - datetime.timedelta(.25*365 / 12))  # start_date = date(2017, 1, 1)
    # print("start_date : {}".format(start_date))
    for n in range(int((end_date - start_date).days)):
        d = start_date + datetime.timedelta(n)
        weekno = d.weekday()
        # print("start_date : {} :: {}".format(d, weekno))
        day = d.strftime("%d").lstrip('0')
        day = ordinal(day)
        mont = d.strftime("%B")
        year = d.strftime("%Y")
        if weekend and weekno >= 5:
            weekend_dict.append('{} {} {}'.format(day, mont, year))
        if weekno < 5:
            weekday_dict.append('{} {} {}'.format(day, mont, year))
    if weekend:
        return weekend_dict
    else:
        return weekday_dict


def get_hindi_show_episod():
    title = ['Taarak Mehta Ka Ooltah Chashmah', 'Mere Sai', 'Crime Patrol', 'the kapil sharma show', 'bigg boss']

    tvshowtitle = random.choice(title)
    if tvshowtitle in 'the kapil sharma show':
        episodes = daterange(weekend=True)
    else:
        episodes = daterange()
    episode = random.choice(episodes)
    serattearm = '%s-%s' % (tvshowtitle, episode)
    return serattearm.lower().replace(' ', '-').replace('.', '-')


def open_file_wrapper(file, mode='r', encoding='utf-8'):
    """
    use:
    json_path = os.path.join(path, filename)
    with open_file_wrapper(json_path)() as json_result:
        return json.load(json_result)
    """
    if py_tools.isPY2:
        return lambda: open(file, mode)
    return lambda: open(file, mode, encoding=encoding)


def read_write_file(file_n='test.html', read=True, result=''):
    """
    :useged:
    from openscrapers.modules.hindi_sources import read_write_file
    read_write_file('test_%s.html' % hdlr, read=False, result=r)
    :param file_n:
    :param read:
    :param result:
    :return:

    """
    if read:
        with open_file_wrapper(file_n, mode='r')() as f:
            result = f.read()
        return result
    else:
        try:
            result = result.replace('\n', ' ').replace('\t', '').replace('&nbsp;', '').replace('&#8211;', '')
            with open_file_wrapper(file_n, mode='w')() as f:
                f.write(py_tools.ensure_str(result))
        except:
            print(traceback.print_exc())


# if __name__ == '__main__':
#     regex_patterns()
