# -*- coding: UTF-8 -*-

# import json
import re

# try: from urllib import quote_plus
# except ImportError: from urllib.parse import quote_plus
import requests
from openscrapers.modules import client
from openscrapers.modules.hindi_sources import get_page, scraper_debug, get_source_dict, urlRewrite, link_extractor, host


class source:

    def __init__(self):
        self.priority = 3
        self.language = ['en']
        self.name = "desitelly"
        self.domains = ['desitellybox.me']
        self.base_link = 'https://www.desitellybox.me/'
        self.headers = {'User-Agent': client.agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # scraper_debug("From: {} \nimdb {} \ntvdb {}\n tvshowtitle {}, localtvshowtitle {}, aliases {}, year {} ".format(self.name, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))
        try:
            query = '%s' % tvshowtitle
            url = query
            # scraper_debug('>>> #### 0AAAA - desitelly EP url : %s' % ( url))
            return url
        except:
            scraper_debug('desitelly tvshow')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # scraper_debug("From: {} \ntvdb {}".format(self.name, tvdb))
        try:
            if type(tvdb) == int:
                return
            if '|' in tvdb:
                # scraper_debug("type desitelly tvdb %s" % type(tvdb))
                tvdb = tvdb.split('|')
                # ch_name = tvdb[0]
                title = tvdb[1].lower().replace(' ', '-')
                episode = episode.lower().replace(' ', '-').replace('.', '')
                if 'bigg-boss' in title:
                    title = 'bigg-boss-14'
                url = '%s/%s-%s-episode-watch-online/' % (self.base_link, title, episode)
                if 'episode-' in episode:
                    url = '%s/%s-watch-online-%s/' % (self.base_link, title, episode)
                # scraper_debug('\nout episode url :  %s \nepisode: %s' % (url, episode))
                return url
                # scraper_debug('\nout episode url :  %s \nepisode: %s' % (url, episode))
                # if episode in url:
                    # # scraper_debug('>>>> episode url :  %s \nepisode: %s' % (url, episode))
                    # return url
            else: return
        except:
            scraper_debug('desitelly episode')
            return

    def sources(self, url, hostDict, hostprDict):
        # scraper_debug("From: {} \nurl {}".format(self.name, url))
        sources = []
        try:
            if not url: return sources
            result = requests.get(url, headers = self.headers).text
            if not result:
                return sources
            result = client.parseDOM(result, 'div', attrs = {'class': 'entry_content'})
            # scraper_debug(result)
            items = client.parseDOM(result, 'p')
            # scraper_debug(items)
            for item in items:
                # scraper_debug(item)
                urls = client.parseDOM(item, 'a', ret = 'href')
                # scraper_debug('....\n%s' % urls)
                furls = []
                vidhost = None
                for j in range(0, len(urls)):
                    # scraper_debug('....\n%s' % urls[j])
                    try:
                        headers = {'Referer': urls[j]}
                        self.headers.update(headers)
                        result = requests.get(urls[j], headers = self.headers).text
                        if result:
                            links = client.parseDOM(result, 'iframe', ret = 'src')
                            for link in links:
                                if 'vkprime' in link or 'speed' in link or 'watchvideo.us' in link:
                                    vidhost = host(link)
                                    furls.append(link)
                                elif 'flow.' in link:
                                    vidhost = 'CDN'
                                    furls.append(urls[j])
                    except:
                        pass
                if len(furls) > 0:
                    sources = get_source_dict(furls, sources, vidhost)
            # dumper = dumper
            # scraper_debug('SOURCES \n\n%s' % json.dumps(sources, default = dumper, indent = 2))
            return sources
        except:
            scraper_debug('desitelly sources')
            return sources

    def resolve(self, url):
        # scraper_debug('In type of url {} url: {}'.format(type(url), url))
        if not any(re.findall(r'dailymotion|vup|streamtape|vidoza|mixdrop|mystream|doodstream|watchvideo|vkprime|vkspeed', url, re.IGNORECASE)):
            if ' , ' in url: iurl = url.split(' , ')
            else: iurl = [url]
            # scraper_debug('In len of iurl {} iurl: {}'.format(len(iurl), iurl))
            furl = []
            for i in range(0, len(iurl)):
                host, url = link_extractor(iurl[i])
                if url: furl.append(url)
            # scraper_debug('desitelly len furl: {} type furl {} furl: {}'.format(len(furl), type(furl), furl))
            if len(furl) > 0:
                if len(furl) > 2: url = ' , '.join(furl)
                else: url = furl[0]
            # scraper_debug('desitelly type of url {} url: {}'.format(type(url), url))
        return url
