# -*- coding: UTF-8 -*-

# import json
# import re
import re

try: from urllib import quote_plus
except ImportError: from urllib.parse import quote_plus

import requests
from openscrapers.modules import client
from openscrapers.modules.hindi_sources import scraper_debug, get_source_dict, link_extractor, host


class source:

    def __init__(self):
        self.priority = 4
        self.language = ['en']
        self.name = "playdesi"
        self.domains = ['playdesi.org']
        self.base_link = 'https://playdesi.tv'
        self.headers = {'User-Agent': client.agent(), }

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # scraper_debug("From: {} \nimdb {} \ntvdb {}\n tvshowtitle {}, localtvshowtitle {}, aliases {}, year {} ".format(self.name, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))
        try:
            query = '%s' % (tvshowtitle)
            url = query
            # scraper_debug('>>> #### 0AAAA - yodesi EP url : %s' % ( url))
            return url
        except:
            scraper_debug('playdesi tvshow')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # scraper_debug("From: {} \nurl {} ... \nimdb {} .. \ntvdb {}\n title {}, premiered {}, season {}, episode {} ".format(self.name, url, imdb, tvdb, title, premiered, season, episode))
        try:
            if type(tvdb) == int:
                return
            if '|' in tvdb:
                # scraper_debug("type playdesi tvdb %s" % type(tvdb))
                tvdb = tvdb.split('|')
                # ch_name = tvdb[0]
                title = tvdb[1].lower().replace(' ', '-').replace('.', '')
                episode = episode.lower().replace(' ', '-').replace('.', '')
                query = '{}-{}-watch-online'.format(title, episode)
                url = '%s/%s/' % (self.base_link, quote_plus(query))
                return url
                # scraper_debug('\nout episode url :  %s \nepisode: %s' % (url, episode))
                # if episode in url:
                    # scraper_debug('episode url :  %s \nepisode: %s' % (url, episode))
                    # return url
            else: return
        except:
            scraper_debug('playdesi episode')
            return

    def sources(self, url, hostDict, hostprDict):
        # scraper_debug("From: {} \nurl: {} ... \n{} .. \n{}".format(self.name, url, hostDict, hostprDict))
        sources = []
        try:
            if not url:	return sources
            # scraper_debug('url: %s' % url)
            result = requests.get(url, headers = self.headers).text
            if not result:
                return
            result = client.parseDOM(result, 'div', attrs = {'class': 'entry-content'})
            # scraper_debug('result: %s' % result)
            items = client.parseDOM(result, 'p')
            for item in items:
                urls = client.parseDOM(item, 'a', ret = 'href')
                # scraper_debug('url: %s' % urls)
                furls = []
                vidhost = None
                for j in range(0, len(urls)):
                    try:
                        headers = {'Referer': urls[j]}
                        self.headers.update(headers)
                        result = requests.get(urls[j], headers = self.headers).text
                        if result:
                            links = client.parseDOM(result, 'iframe', ret = 'src')
                            for link in links:
                                # print('link: {}'.format(link))
                                if 'vkprime' in link or 'speed' in link or 'watchvideo.us' in link:
                                    vidhost = host(link)
                                    furls.append(link)
                                elif any(re.findall(r'index.php|embed|plyr20a|nflix20', link, re.IGNORECASE)):
                                    vidhost = 'CDN'
                                    furls.append(urls[j])
                    except:
                        pass
                if len(furls) > 0:
                    sources = get_source_dict(furls, sources, vidhost)
            # dumper = dumper
            # scraper_debug('SOURCES \n\n%s' % json.dumps(sources, default = dumper, indent = 2))
            return sources
        except:
            scraper_debug('playdesi sources')
            return sources

    def resolve(self, url):
        # scraper_debug('In type of url {} url: {}'.format(type(url), url))
        if not any(re.findall(r'dailymotion|vup|streamtape|vidoza|mixdrop|mystream|doodstream|watchvideo|vkprime|vkspeed', url, re.IGNORECASE)):
            if ' , ' in url: iurl = url.split(' , ')
            else: iurl = [url]
            # scraper_debug('In len of iurl {} iurl: {}'.format(len(iurl), iurl))
            furl = []
            for i in range(0, len(iurl)):
                host, url = link_extractor(iurl[i])
                if url:
                    furl.append(url)
            # scraper_debug('playdesi len furl: {} type furl {} furl: {}'.format(len(furl), type(furl), furl))
            if len(furl) > 0:
                if len(furl) > 2: url = ' , '.join(furl)
                else: url = furl[0]
            # scraper_debug('playdesi type of url {} url: {}'.format(type(url), url))
        return url
