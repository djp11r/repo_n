# -*- coding: UTF-8 -*-
# import json
import re, traceback

import requests
from openscrapers.modules import client, log_utils
from openscrapers.modules.hindi_sources import scraper_debug, get_source_dict, urlRewrite, get_mod_url, link_extractor, getVideoID


class source:

    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.name = "desirulez"
        self.domains = ['desirulez.cc']
        self.base_link = 'http://www.desirulez.cc'
        self.base_link_2 = 'http://www.desirulez.me'
        self.base_link_3 = 'http://www.desirulez.net'
        self.headers = {'User-Agent': client.agent(), }

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            # scraper_debug("From: {} \nimdb: {} \ntitle: {}\nlocaltitle: {} \naliases: {}\nyear: {} ".format(self.name, imdb, title, localtitle, aliases, year))
            url = aliases
            return url
        except:
            log_utils.error('desirulez')
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # scraper_debug("From: {} \nimdb {} \ntvdb {}\ntvshowtitle {}\nlocaltvshowtitle {} \naliases {}\n year {} ".format(self.name, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))
        try:
            tvshowtitle = tvshowtitle.lower().replace(' ', '-').replace('.', '-')
            if "indian-idol" in tvshowtitle:
                tvshowtitle = 'indian-idol-2020-season-12-a-6674'
            elif "super-dancer" in tvshowtitle.lower():
                tvshowtitle = "super-dancer-chapter-4-a-6732"
            elif "dance-deewane" in tvshowtitle.lower():
                tvshowtitle = "dance-deewane-3-a-6749"
            query = '%s/%s' % (self.base_link, tvshowtitle)
            url = query
            # scraper_debug('desirulez tvshow url : %s' % url)
            return url
        except:
            log_utils.error('desirulez tv')
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # scraper_debug("From: {} tvdb {} url: {} episode: {}".format(self.name, tvdb, url, episode))
        try:
            if type(tvdb) == int: return

            if '|' in tvdb:
                # scraper_debug("type episode %s" % type(episode))
                exctract_date = re.compile(r' Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|August|Sep|September|Oct|October|Nov|November|Dec|December ')
                q_item = re.sub(exctract_date, '', episode)
                q_item = q_item.replace('  ', '-')
                # scraper_debug('desirulez episode q_item: {} episode >>>  : {}'.format(q_item, episode))
                episode = episode.lower().replace(' ', '-').replace('.', '-')
                # season = season.lower().replace(' ', '-').replace('.', '-')
                # scraper_debug('desirulez episode type: {} url >>>  : {}'.format(type(url), url))
                result = requests.get(url, headers=self.headers).text
                # episo_page = result.decode('iso-8859-1').encode('utf-8')
                # result = client.parseDOM(result, "h3", attrs = {
                #     "class": "title threadtitle_unread"})
                result = client.parseDOM(result, "h3", attrs={"class": "threadtitle"})
                # scraper_debug('desirulez episode result 2  : %s' % result)
                url = ''
                for item in result:
                    # scraper_debug('desirulez episode item : \n%s\n' % item)
                    urls = client.parseDOM(item, "a", ret="href")
                    for url in urls:
                        # scraper_debug('q_item: %s episode: %s url :  %s ' % (q_item, episode, url))
                        if 'watch-online' in url and (episode in url or q_item in url): # and season in url:
                            # scraper_debug('>>>> episode url :  %s \nepisode: %s' % (url, episode))
                            return url
                if url == '': return ''
            else: return
        except:
            log_utils.error('desirulez episode: {}'.format(traceback.format_exc()))
            return

    def sources(self, url, hostDict, hostprDict):
        # scraper_debug("From sources : {} \nurl {}".format(self.name, url))
        sources = []
        try:
            if not url: return sources
            result = requests.get(url, headers = self.headers).text
            if not result: return sources

            # result = result.decode('iso-8859-1').encode('utf-8')
            result = result.replace('\n', '')
            links = client.parseDOM(result, 'blockquote', attrs = {'class': r'.*?postcontent.*?'})
            # scraper_debug(links[0])
            # pattern = re.compile(r'(?<=font color)(.+?)(((?=font color)|##)+)', re.S)  # all a in after font color
            pattern = re.compile(r'(?<=<b>)(.+?)((?=<b>)|##)', re.S)  # find all a after <b> and before <b>
            ndata = re.findall(pattern, links[0] + '##') # add ## to get to the end of string
            for ai in ndata:
                urls = re.findall(r'href=[\'"]?([^\'" >]+)', ai[0])
                host = None
                if len(urls) > 0:
                    # log_utils.log('desirulez total: %s urls: %s' % (len(urls), urls))
                    for i in range(0, len(urls)):
                        try:
                            # scraper_debug('retun url and host %s iurl: %s' % ('host', urls[i]))
                            if any(re.findall(r'speed|vkprime', urls[i], re.IGNORECASE)):
                                urls[i] = urlRewrite(urls[i])
                            elif any(re.findall(r'business-loans.pw|bestarticles|tvnation.me', urls[i], re.IGNORECASE)) and 'drive.php' not in urls[i]:
                                iurl = get_mod_url(urls[i])
                                # scraper_debug('In urls[i]: %s Out iurl: %s' % (urls[i], iurl))
                                if iurl: urls[i] = urls[i]
                                # headers = {'Referer': urls[i]}
                                # self.headers.update(headers)
                                # result = requests.get(iurl, headers = self.headers).text
                                # if result:
                                #     host = 'CDN'
                                #     urls[i] = urls[i]
                                # else: urls[i] = None
                            elif 'articlesmania.me' in urls[i]:
                                # scraper_debug('>>> articlesmania iurl: %s' % (urls[i]))
                                urls[i] = urls[i]
                                # host, url = link_extractor(urls[i])
                                # if url: urls[i] = urls[i]
                                # else: urls[i] = None
                            else: urls[i] = None
                        except: urls[i] = None

                    if urls[0] is not None and len(urls) > 0:
                        sources = get_source_dict(urls, sources, host)
                urls = []
            # scraper_debug('SOURCES %s\n\n%s' % (self.name, json.dumps(sources, default = dumper, indent = 2)))
            return sources
        except:
            log_utils.error('desirulez source: {}'.format(traceback.format_exc()))
            return sources

    def resolve(self, url):
        # scraper_debug('In type of url {} url: {}'.format(type(url), url))
        # if 'vkprime' not in url and 'vkspeed' not in url:
        if not any(re.findall(r'dailymotion|vup|streamtape|vidoza|mixdrop|mystream|doodstream|watchvideo|vkprime|vkspeed', url, re.IGNORECASE)):
            if ' , ' in url: iurl = url.split(' , ')
            else: iurl = [url]
            # scraper_debug('In len of iurl {} iurl: {}'.format(len(iurl), iurl))
            furl = []
            for i in range(0, len(iurl)):
                # scraper_debug('iurl[i]: {}'.format(iurl[i]))
                host, url = link_extractor(iurl[i])
                if url: furl.append(url)
            # scraper_debug('desirulez len furl: {} type furl {} furl: {}'.format(len(furl), type(furl), furl))
            if len(furl) > 0:
                if len(furl) > 2: url = ' , '.join(furl)
                else: url = furl[0]
            # scraper_debug('desirulez type of url {} url: {}'.format(type(url), url))
        return url
