# -*- coding: UTF-8 -*-

from __future__ import print_function
import os
from sys import stdout
import traceback
from pkgutil import walk_packages

import requests


try:
	from .modules import cfscrape
	cfScraper = cfscrape.create_scraper()
except: pass

from six.moves.urllib_parse import parse_qs, urljoin, urlparse, urlencode, quote, unquote, quote_plus, unquote_plus
from openscrapers.modules.log_utils import log, error, LOGWARNING
from openscrapers.modules.py_tools import ensure_text
from openscrapers.modules import source_utils

try:
	from openscrapers.modules.control import setting as getSetting
	#import xbmcaddon
	#__addon__ = xbmcaddon.Addon(id='script.module.openscrapers')
	debug = getSetting('debug.enabled') == 'true'
	provider = getSetting('module.provider').lower()
	testing = False
except:
	try:  # use code that works the same in Python 2 and 3
		range, _print = xrange, print

		def print(*args, **kwargs):
			flush = kwargs.pop('flush', False)
			_print(*args, **kwargs)
			if flush:
				kwargs.get('file', stdout).flush()
	except NameError:
		pass
	log = error = print
	LOGWARNING = 'LOGWARNING'
	__addon__ = None
	debug = True
	testing = True
	provider = 'sources_openscrapers'


def sources(specified_folders=None):
	try:
		sourceDict = []
		sourceFolder = getScraperFolder()
		sourceFolderLocation = os.path.join(os.path.dirname(__file__), sourceFolder)
		sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
		sourceSubFolders = [x for x in sourceSubFolders if x not in ['__pycache__', 'modules', 'cfscrape', 'pyaes']]
		# print("len(sourceSubFolders): %s sourceSubFolders: %s " % (len(sourceSubFolders), sourceSubFolders))
		if specified_folders:
			sourceSubFolders = specified_folders
		for i in sourceSubFolders:
			for loader, module_name, is_pkg in walk_packages([os.path.join(sourceFolderLocation, i)]):
				if is_pkg: continue
				if enabledCheck(module_name):
					try:
						module = loader.find_module(module_name).load_module(module_name)
						sourceDict.append((module_name, module.source()))
					except Exception as e:
						if debug: log('Error: Loading module: "%s": %s' % (module_name, traceback.format_exc()))
		return sourceDict
	except:
		log('Error: sources: "%s"' % traceback.print_exc())
		return []

def getScraperFolder():
	try:
		sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
		sourceSubFolders = [x for x in sourceSubFolders if x not in ['__pycache__', 'help', 'modules', 'cfscrape', 'pyaes']]
		return [i for i in sourceSubFolders if 'openscrapers' in i.lower()][0]
	except:
		error()
		return 'sources_openscrapers'

def enabledCheck(module_name):
	try:
		if getSetting('provider.' + module_name) == 'true': return True
		else: return False
	except:
		# error()
		return True

def pack_sources():
	return []


def providerSources():
	sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
	return getModuleName(sourceSubFolders)


def providerNames():
	providerList = []
	provider = getSetting('module.provider')
	sourceFolder = getScraperFolder(provider)
	sourceFolderLocation = os.path.join(os.path.dirname(__file__), sourceFolder)
	sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
	for i in sourceSubFolders:
		for loader, module_name, is_pkg in walk_packages([os.path.join(sourceFolderLocation, i)]):
			if is_pkg: continue
			correctName = module_name.split('_')[0]
			providerList.append(correctName)
	return providerList


def getAllHosters():
	def _sources(sourceFolder, appendList):
		sourceFolderLocation = os.path.join(os.path.dirname(__file__), sourceFolder)
		sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
		for i in sourceSubFolders:
			for loader, module_name, is_pkg in walk_packages([os.path.join(sourceFolderLocation, i)]):
				if is_pkg: continue
				try: mn = str(module_name).split('_')[0]
				except: mn = str(module_name)
				appendList.append(mn)
	sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
	appendList = []
	for item in sourceSubFolders:
		if item not in ['__pycache__', 'modules', 'cfscrape', 'pyaes']:
			_sources(item, appendList)
	return list(set(appendList))


def getModuleName(scraper_folders):
	nameList = []
	for s in scraper_folders:
		if not s in ['__pycache__', 'modules', 'cfscrape', 'pyaes']:
			try: nameList.append(s.split('_')[1].lower().title())
			except: pass
	return nameList
